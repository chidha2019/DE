import { fileURLToPath, URL } from "node:url";

import react from "@vitejs/plugin-react";
import { defineConfig, loadEnv } from "vite";

/**
 * Dev server proxies `/ingestion/*` and `/query/*` to the two FastAPI services so the
 * SPA never deals with CORS; nginx does the same in the production image.
 */
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "");
  const ingestionTarget = env.VITE_INGESTION_PROXY_TARGET ?? "http://localhost:8001";
  const queryTarget = env.VITE_QUERY_PROXY_TARGET ?? "http://localhost:8002";

  return {
    plugins: [react()],
    resolve: {
      alias: { "@": fileURLToPath(new URL("./src", import.meta.url)) },
    },
    server: {
      port: 5173,
      strictPort: false,
      proxy: {
        "/ingestion": {
          target: ingestionTarget,
          changeOrigin: true,
          rewrite: (path) => path.replace(/^\/ingestion/, ""),
        },
        "/query": {
          target: queryTarget,
          changeOrigin: true,
          rewrite: (path) => path.replace(/^\/query/, ""),
        },
      },
    },
    build: {
      sourcemap: mode !== "production",
      chunkSizeWarningLimit: 900,
      rollupOptions: {
        output: {
          manualChunks: {
            react: ["react", "react-dom", "react-router-dom"],
            query: ["@tanstack/react-query"],
            charts: ["recharts"],
            graph: ["react-force-graph-2d"],
            markdown: ["react-markdown", "remark-gfm"],
          },
        },
      },
    },
  };
});
