import {
  ArrowUpRight,
  BookOpenCheck,
  ChevronDown,
  CircleCheck,
  CircleDashed,
  CodeXml,
  DraftingCompass,
  FileSearch,
  ListChecks,
  Network,
  Package,
  Sparkles,
  Stethoscope,
  type LucideIcon,
} from "lucide-react";
import { useState } from "react";
import { Link } from "react-router-dom";

import type { WorkerCapability, WorkerSkill } from "@/api/types";
import { Button } from "@/components/ui/button";
import { READINESS, SKILL_ICON, TIER, packageName, sentence } from "@/components/worker/worker-meta";
import { cn } from "@/lib/utils";

const LOOK: Record<string, { icon: LucideIcon; tile: string }> = {
  understand: { icon: FileSearch, tile: "from-sky-500/25 to-sky-500/5 text-sky-600 ring-sky-500/30 dark:text-sky-300" },
  design: { icon: DraftingCompass, tile: "from-violet-500/25 to-violet-500/5 text-violet-600 ring-violet-500/30 dark:text-violet-300" },
  prepare: { icon: CodeXml, tile: "from-teal-500/25 to-teal-500/5 text-teal-600 ring-teal-500/30 dark:text-teal-300" },
  validate: { icon: ListChecks, tile: "from-emerald-500/25 to-emerald-500/5 text-emerald-600 ring-emerald-500/30 dark:text-emerald-300" },
  investigate: { icon: Stethoscope, tile: "from-amber-500/25 to-amber-500/5 text-amber-600 ring-amber-500/30 dark:text-amber-300" },
  explain: { icon: Network, tile: "from-fuchsia-500/25 to-fuchsia-500/5 text-fuchsia-600 ring-fuchsia-500/30 dark:text-fuchsia-300" },
};

/** What the worker can deliver, each capability ready only when what its headline ability needs is connected. */
export function CapabilityCards({ capabilities, skills, onOpenIntegrity }: { capabilities: WorkerCapability[]; skills: WorkerSkill[]; onOpenIntegrity: () => void }) {
  const ready = capabilities.filter((c) => c.readiness === "available").length;
  return (
    <section className="space-y-3" aria-labelledby="capabilities-title">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div>
          <h3 id="capabilities-title" className="font-display text-lg font-medium">
            What it can deliver
          </h3>
          <p className="max-w-3xl text-xs text-muted-foreground">
            A capability shows as available only when its route, tools, context and permissions are connected. An installed skill package guides the work; it
            does not make it runnable.
          </p>
        </div>
        <span className="rounded-full border border-border/70 bg-card px-2.5 py-1 text-xs tabular-nums text-muted-foreground">
          {ready} of {capabilities.length} available
        </span>
      </div>
      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {capabilities.map((c) => (
          <CapabilityCard key={c.key} capability={c} skills={skills} onOpenIntegrity={onOpenIntegrity} />
        ))}
      </div>
    </section>
  );
}

function CapabilityCard({ capability: c, skills, onOpenIntegrity }: { capability: WorkerCapability; skills: WorkerSkill[]; onOpenIntegrity: () => void }) {
  const [open, setOpen] = useState(false);
  const look = LOOK[c.key] ?? { icon: Sparkles, tile: "from-primary/25 to-primary/5 text-primary ring-primary/30" };
  const Icon = look.icon;
  const state = READINESS[c.readiness];
  const detailsId = `capability-${c.key}-details`;
  return (
    <article className="surface flex min-w-0 flex-col gap-3 p-4">
      <header className="flex items-start gap-3">
        <span className={cn("flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br ring-1", look.tile)} aria-hidden="true">
          <Icon className="h-5 w-5" />
        </span>
        <div className="min-w-0 flex-1">
          <h4 className="font-display text-base font-medium leading-tight">{c.title}</h4>
          <span className={cn("mt-1 inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[11px] font-medium", state.pill)}>
            <span className={cn("h-1.5 w-1.5 rounded-full", state.dot)} /> {state.label}
          </span>
        </div>
      </header>
      <p className="text-sm leading-snug">{c.outcome}</p>
      {c.readiness !== "available" && c.reason ? <p className="rounded-lg bg-muted/60 px-2.5 py-1.5 text-[11.5px] text-muted-foreground">{c.reason}</p> : null}

      <ul className="space-y-1" aria-label={`What ${c.title} can do now`}>
        {c.abilities.map((a) => {
          const ok = a.status === "available";
          return (
            <li key={a.label} className="flex items-start gap-2 text-[12px]">
              {ok ? (
                <CircleCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-500" aria-label="available" />
              ) : (
                <CircleDashed className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" aria-label={READINESS[a.status].label} />
              )}
              <span className={cn("min-w-0", !ok && "text-muted-foreground")}>
                {a.label}
                {!ok ? (
                  <span className="block text-[11px]" title={a.reason}>
                    {READINESS[a.status].label}
                    {a.optional ? " · the rest works without it" : ""}
                  </span>
                ) : null}
              </span>
            </li>
          );
        })}
      </ul>

      {c.needs_input ? (
        <p className="text-[11.5px] text-muted-foreground">
          <span className="font-medium text-foreground">Needs input:</span> {c.needs_input}
        </p>
      ) : null}

      <div className="mt-auto flex flex-wrap items-center gap-2 border-t border-border/60 pt-3">
        {c.link.startsWith("#") ? (
          <Button size="sm" className="h-8" variant={c.readiness === "available" ? "default" : "outline"} onClick={onOpenIntegrity}>
            {c.action}
          </Button>
        ) : (
          <Button asChild size="sm" className="h-8" variant={c.readiness === "available" ? "default" : "outline"}>
            <Link to={c.link}>
              {c.action} <ArrowUpRight className="h-3.5 w-3.5" />
            </Link>
          </Button>
        )}
        {c.more_action && c.more_link ? (
          <Button asChild size="sm" variant="outline" className="h-8">
            <Link to={c.more_link}>{c.more_action}</Link>
          </Button>
        ) : null}
        <button
          type="button"
          className="ml-auto inline-flex items-center gap-1 rounded-md px-1.5 py-1 text-xs font-medium text-primary hover:bg-primary/10"
          aria-expanded={open}
          aria-controls={detailsId}
          onClick={() => setOpen((v) => !v)}
        >
          Skills & tools <ChevronDown className={cn("h-3.5 w-3.5 transition-transform", open && "rotate-180")} />
        </button>
      </div>
      {open ? <SkillsAndTools id={detailsId} capability={c} skills={skills} /> : null}
    </article>
  );
}

function Heading({ children }: { children: React.ReactNode }) {
  return <div className="mb-1 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">{children}</div>;
}

function SkillsAndTools({ id, capability: c, skills }: { id: string; capability: WorkerCapability; skills: WorkerSkill[] }) {
  const mine = c.skills.map((key) => skills.find((s) => s.key === key)).filter((s): s is WorkerSkill => Boolean(s));
  const released = mine.flatMap((s) => [
    ...(s.source === "package" && s.package ? [{ name: packageName(s.package), role: "governs the skill", key: `${s.key}:${s.package}` }] : []),
    ...(s.playbooks ?? []).map((p) => ({ name: p.name, role: `playbook · ${p.checks.length} checks`, key: `${s.key}:${p.package}` })),
  ]);
  return (
    <div id={id} className="space-y-3 rounded-xl border border-border/70 bg-muted/30 p-3 text-[12px]">
      <div>
        <Heading>Assigned specialist</Heading>
        <ul className="space-y-1">
          {mine.map((s) => {
            const SkillIcon = SKILL_ICON[s.key] ?? Sparkles;
            return (
              <li key={s.key} className="flex flex-wrap items-center gap-1.5">
                <SkillIcon className="h-3.5 w-3.5 text-primary" aria-hidden="true" />
                <span className="font-medium">{s.name}</span>
                <span className="rounded-md border border-border/70 px-1.5 py-px font-mono text-[10px] text-muted-foreground" title={TIER[s.tier].meaning}>
                  {TIER[s.tier].label}
                </span>
              </li>
            );
          })}
        </ul>
      </div>
      <div>
        <Heading>Released skills</Heading>
        {released.length ? (
          <ul className="space-y-1">
            {released.map((r) => (
              <li key={r.key} className="flex flex-wrap items-center gap-1.5">
                {r.role.startsWith("playbook") ? <BookOpenCheck className="h-3.5 w-3.5 text-primary" aria-hidden="true" /> : <Package className="h-3.5 w-3.5 text-primary" aria-hidden="true" />}
                <span className="font-mono text-[11px]">{r.name}</span>
                <span className="text-[11px] text-muted-foreground">{r.role}</span>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-muted-foreground">None installed: the hub&apos;s own skill does the work.</p>
        )}
      </div>
      <div>
        <Heading>Required context</Heading>
        <ul className="space-y-1">
          {c.context.length ? (
            c.context.map((n) => (
              <li key={n.key} className="flex items-start gap-1.5">
                {n.ok ? <CircleCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-500" aria-label="in place" /> : <CircleDashed className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" aria-label="missing" />}
                <span className="min-w-0">
                  <span className="font-medium">{n.label}</span> <span className="text-muted-foreground">· {sentence(n.detail)}</span>
                </span>
              </li>
            ))
          ) : (
            <li className="text-muted-foreground">Nothing beyond the hub itself.</li>
          )}
        </ul>
      </div>
      <div>
        <Heading>Tools</Heading>
        <div className="flex flex-wrap gap-1">
          {c.tools.map((t) => (
            <span key={t} className="rounded-md border border-border/70 bg-background/70 px-1.5 py-px text-[11px]">
              {t}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
