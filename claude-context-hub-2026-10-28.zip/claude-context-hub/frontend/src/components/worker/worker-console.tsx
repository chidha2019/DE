import {
  Activity as ActivityIcon,
  ArrowUpRight,
  BadgeCheck,
  BookOpenCheck,
  ChevronDown,
  CircleAlert,
  CircleCheck,
  CircleDashed,
  CircleSlash,
  CircleX,
  Eye,
  Flag,
  GitBranch,
  Hand,
  Hash,
  Inbox,
  Layers,
  LoaderCircle,
  Package,
  Pause,
  Play,
  Radar,
  RefreshCw,
  ScanSearch,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  Stethoscope,
  Sunrise,
  ThumbsUp,
  type LucideIcon,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useLocation } from "react-router-dom";

import type {
  IntegrityStatus,
  WorkerIntegrity,
  WorkerItem,
  WorkerJournalEntry,
  WorkerJournalKind,
  WorkerPlaybook,
  WorkerSkill,
  WorkerSnapshot,
  WorkerTier,
} from "@/api/types";
import { Companion, type CompanionMood } from "@/components/personas/companion";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { CapabilityCards } from "@/components/worker/capability-cards";
import { CurrentWork } from "@/components/worker/current-work";
import { SKILL_ICON, TIER, sentence } from "@/components/worker/worker-meta";
import { useWorker, useWorkerDecision, useWorkerPause, useWorkerSweep } from "@/hooks/queries";
import { describeError } from "@/lib/api-client";
import { formatInt, formatRelative } from "@/lib/format";
import { cn } from "@/lib/utils";

const KIND: Record<WorkerJournalKind, { icon: LucideIcon; tone: string; label: string }> = {
  shift: { icon: Sunrise, tone: "text-muted-foreground", label: "shift" },
  observed: { icon: Eye, tone: "text-violet-600 dark:text-violet-300", label: "picked up" },
  diagnosed: { icon: Stethoscope, tone: "text-violet-600 dark:text-violet-300", label: "diagnosed" },
  proposed: { icon: Hand, tone: "text-amber-600 dark:text-amber-300", label: "asked" },
  approved: { icon: ThumbsUp, tone: "text-sky-600 dark:text-sky-300", label: "approved" },
  acted: { icon: Play, tone: "text-sky-600 dark:text-sky-300", label: "acted" },
  done: { icon: CircleCheck, tone: "text-emerald-600 dark:text-emerald-300", label: "done" },
  failed: { icon: CircleX, tone: "text-destructive", label: "failed" },
  dismissed: { icon: CircleSlash, tone: "text-muted-foreground", label: "dismissed" },
};

const EVIDENCE_KEYS: [string, string][] = [
  ["connector", "connector"],
  ["jira_key", "ticket"],
  ["repo", "repository"],
  ["tables", "tables"],
  ["risks", "risks"],
  ["count", "count"],
  ["documents_failed", "documents failed"],
];

/** The current time, re-read every second so "last sweep" reads live. */
function useClock(): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, []);
  return now;
}

function since(iso: string | null, now: number): string {
  if (!iso) return "not yet";
  const s = Math.max(0, Math.round((now - Date.parse(iso)) / 1000));
  return s < 60 ? `${s} s ago` : s < 3600 ? `${Math.round(s / 60)} min ago` : formatRelative(iso);
}

function clock(iso: string): string {
  return new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

/** The integrity panel lives in Activity: open it, then scroll once it has rendered. */
function useIntegrityJump(loaded: boolean) {
  const { hash } = useLocation();
  const [activityOpen, setActivityOpen] = useState(hash === "#integrity");
  const jump = () => {
    setActivityOpen(true);
    window.setTimeout(() => document.getElementById("integrity")?.scrollIntoView({ behavior: "smooth", block: "start" }), 60);
  };
  useEffect(() => {
    if (loaded && hash === "#integrity") {
      setActivityOpen(true);
      window.setTimeout(() => document.getElementById("integrity")?.scrollIntoView({ behavior: "smooth", block: "start" }), 60);
    }
  }, [loaded, hash]);
  return { activityOpen, setActivityOpen, jump };
}

/** The Data Engineer digital worker: what it can deliver, the work in flight, what waits for you, then its activity. */
export function WorkerConsole({ worker = "data_engineer" }: { worker?: string }) {
  const q = useWorker(worker);
  const decide = useWorkerDecision(worker);
  const sweep = useWorkerSweep(worker);
  const pause = useWorkerPause(worker);
  const now = useClock();
  const snap = q.data;
  const { activityOpen, setActivityOpen, jump } = useIntegrityJump(Boolean(snap));

  if (q.isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-40 w-full rounded-2xl" />
        <Skeleton className="h-64 w-full rounded-2xl" />
      </div>
    );
  }
  if (!snap) {
    return (
      <div className="surface flex items-start gap-2 p-5 text-sm text-destructive">
        <CircleAlert className="mt-0.5 h-4 w-4" /> The digital worker could not be reached: {describeError(q.error)}
      </div>
    );
  }

  const waiting = snap.items.filter((i) => i.status === "waiting");
  const found = snap.items.filter((i) => i.status === "diagnosed" || i.status === "detected");
  const running = snap.items.filter((i) => i.status === "running");
  const closed = snap.items.filter((i) => i.status === "done" || i.status === "failed" || i.status === "dismissed");
  const act = (item: WorkerItem, decision: "approve" | "dismiss" | "done", checks?: string[]) => decide.mutate({ key: item.key, decision, checks });
  const busyKey = decide.isPending ? decide.variables?.key : undefined;

  return (
    <div className="space-y-5">
      <Header snap={snap} sweeping={sweep.isPending} onSweep={() => sweep.mutate(undefined)} onPause={() => pause.mutate(!snap.paused)} pausing={pause.isPending} />
      {decide.error ? (
        <p className="flex items-center gap-1.5 text-xs text-destructive">
          <CircleAlert className="h-3.5 w-3.5" /> {describeError(decide.error)}
        </p>
      ) : null}

      <CapabilityCards capabilities={snap.capabilities ?? []} skills={snap.skills} onOpenIntegrity={jump} />
      <CurrentWork running={running} />

      <section className="surface relative overflow-hidden p-4 sm:p-5" aria-labelledby="decisions-title">
        <div className="pointer-events-none absolute -right-16 -top-20 h-48 w-48 rounded-full bg-amber-400/15 blur-3xl" aria-hidden="true" />
        <div className="relative mb-3 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-amber-500/15 text-amber-600 dark:text-amber-300">
              <Inbox className="h-4 w-4" />
            </span>
            <div>
              <h3 id="decisions-title" className="font-display text-base font-medium leading-tight">
                Decisions needed
              </h3>
              <p className="text-xs text-muted-foreground">Steps the worker prepared and may not take alone. Nothing here runs until you approve it.</p>
            </div>
          </div>
          <Badge variant={waiting.length ? "warning" : "success"}>{waiting.length ? `${waiting.length} to decide` : "nothing waiting"}</Badge>
        </div>
        {waiting.length ? (
          <div className="relative grid gap-3 lg:grid-cols-2">
            {waiting.map((item) => (
              <WorkCard key={item.key} item={item} skills={snap.skills} busy={busyKey === item.key} onDecide={act} emphasis />
            ))}
          </div>
        ) : (
          <p className="relative rounded-xl border border-dashed p-4 text-sm text-muted-foreground">
            Nothing waits on you. Approvals land here with the playbook checks to confirm.
          </p>
        )}
        {found.length ? (
          <div className="relative mt-5">
            <h4 className="mb-2 flex items-center gap-1.5 text-sm font-medium">
              <Radar className="h-4 w-4 text-violet-500" aria-hidden="true" /> Found for you to review <span className="tabular-nums text-muted-foreground">· {found.length}</span>
            </h4>
            <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
              {found.map((item) => (
                <WorkCard key={item.key} item={item} skills={snap.skills} busy={busyKey === item.key} onDecide={act} />
              ))}
            </div>
          </div>
        ) : null}
      </section>

      <Activity snap={snap} now={now} open={activityOpen} onToggle={() => setActivityOpen((v) => !v)}>
        <Stats snap={snap} />
        <div className="grid gap-5 xl:grid-cols-[minmax(0,1.55fr)_minmax(0,1fr)]">
          <div className="min-w-0 space-y-5">
            <Lane title="Running" hint="Steps in flight; the worker follows each one until it finishes." icon={LoaderCircle} tone="sky" items={running} empty="Nothing running right now.">
              {(item) => <WorkCard key={item.key} item={item} skills={snap.skills} busy={false} onDecide={act} />}
            </Lane>
            <Lane title="Closed today" hint="Done, failed or dismissed since midnight." icon={CircleCheck} tone="emerald" items={closed} empty="Nothing closed yet today." compact>
              {(item) => <ClosedRow key={item.key} item={item} />}
            </Lane>
          </div>
          <Journal entries={snap.journal} chainOk={snap.chain_ok} />
        </div>
        {snap.integrity ? <IntegrityPanel integrity={snap.integrity} /> : null}
        <Skills skills={snap.skills} />
        <TierLegend ceiling={snap.autonomy} />
      </Activity>
    </div>
  );
}

// ----------------------------------------------------------------------------- activity
function Activity({ snap, now, open, onToggle, children }: { snap: WorkerSnapshot; now: number; open: boolean; onToggle: () => void; children: React.ReactNode }) {
  const c = snap.counts;
  return (
    <section className="surface" aria-labelledby="activity-title">
      <button type="button" onClick={onToggle} aria-expanded={open} aria-controls="worker-activity" className="flex w-full items-center gap-3 rounded-2xl p-4 text-left hover:bg-muted/30 sm:px-5">
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-primary/12 text-primary">
          <ActivityIcon className="h-4 w-4" />
        </span>
        <span className="min-w-0 flex-1">
          <span id="activity-title" className="block font-display text-base font-medium leading-tight">
            Activity
          </span>
          <span className="block text-xs text-muted-foreground">
            Sweeps every {snap.tick_seconds} s · last {since(snap.last_tick, now)} · {formatInt(c.signals)} signals watched · {formatInt(c.done_today)} done today · journal{" "}
            {snap.chain_ok ? "verified" : "does not verify"}
          </span>
        </span>
        <span className="hidden text-xs text-muted-foreground sm:inline">{open ? "Hide" : "Show"} the journal, skills and checks</span>
        <ChevronDown className={cn("h-4 w-4 shrink-0 text-muted-foreground transition-transform", open && "rotate-180")} />
      </button>
      {open ? (
        <div id="worker-activity" className="space-y-5 border-t border-border/60 p-4 sm:p-5">
          {children}
        </div>
      ) : null}
    </section>
  );
}

function Stats({ snap }: { snap: WorkerSnapshot }) {
  const c = snap.counts;
  const stats: { label: string; value: number; tone: string }[] = [
    { label: "waiting for you", value: c.waiting, tone: "text-amber-600 dark:text-amber-300" },
    { label: "running", value: c.running, tone: "text-sky-600 dark:text-sky-300" },
    { label: "open findings", value: Math.max(0, c.open - c.waiting - c.running), tone: "text-violet-600 dark:text-violet-300" },
    { label: "done today", value: c.done_today, tone: "text-emerald-600 dark:text-emerald-300" },
    { label: "signals watched", value: c.signals, tone: "text-foreground" },
  ];
  return (
    <div className="space-y-2">
      <p className="flex items-center gap-2 text-sm">
        {c.running && !snap.paused ? <LoaderCircle className="h-4 w-4 shrink-0 animate-spin text-sky-500" /> : <Sparkles className="h-4 w-4 shrink-0 text-primary" />}
        <span className="min-w-0">{snap.now}</span>
      </p>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
        {stats.map((s) => (
          <div key={s.label} className="rounded-xl border border-border/70 bg-background/60 px-3 py-2">
            <div className={cn("font-display text-xl font-medium tabular-nums", s.tone)}>{formatInt(s.value)}</div>
            <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{s.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ----------------------------------------------------------------------------- the hero
function Header({
  snap,
  sweeping,
  onSweep,
  onPause,
  pausing,
}: {
  snap: WorkerSnapshot;
  sweeping: boolean;
  onSweep: () => void;
  onPause: () => void;
  pausing: boolean;
}) {
  const c = snap.counts;
  const mood: CompanionMood = snap.paused ? "sleeping" : c.running ? "thinking" : c.waiting ? "listening" : "idle";
  const capabilities = snap.capabilities ?? [];
  const ready = capabilities.filter((x) => x.readiness === "available").length;
  return (
    <section className="surface relative overflow-hidden p-4 sm:p-5">
      <div className="hero-grid pointer-events-none absolute inset-0 opacity-30" aria-hidden="true" />
      <div className="pointer-events-none absolute -left-20 -top-24 h-56 w-56 rounded-full bg-teal-500/15 blur-3xl" aria-hidden="true" />
      <div className="relative flex flex-wrap items-center gap-4">
        <Companion persona="data_engineer" mood={mood} size="4rem" interactive={false} className="shrink-0" />
        <div className="min-w-0 flex-1 space-y-1">
          <div className="flex flex-wrap items-center gap-2">
            {snap.paused ? (
              <Badge variant="warning">
                <Pause className="mr-1 h-3 w-3" /> paused
              </Badge>
            ) : (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/12 px-2 py-0.5 text-[11px] font-medium text-emerald-700 dark:text-emerald-300">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-500 opacity-60 motion-reduce:hidden" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
                </span>
                on shift
              </span>
            )}
            <span className="inline-flex items-center gap-1 rounded-full border border-primary/30 bg-primary/10 px-2 py-0.5 text-[11px] font-medium text-primary" title={TIER[snap.autonomy].meaning}>
              <ShieldCheck className="h-3 w-3" /> ceiling {TIER[snap.autonomy].label}
            </span>
          </div>
          <h2 className="font-display text-2xl font-medium tracking-tight">Data Engineer digital worker</h2>
          <p className="text-sm">
            Ready to deliver{" "}
            <span className="font-medium tabular-nums">
              {ready} of {capabilities.length}
            </span>{" "}
            capabilities
            <span className="text-muted-foreground"> · </span>
            {c.waiting ? (
              <a href="#decisions-title" className="font-medium text-amber-700 hover:underline dark:text-amber-300">
                {c.waiting} decision{c.waiting === 1 ? "" : "s"} waiting for you
              </a>
            ) : (
              <span className="text-muted-foreground">nothing waiting for you</span>
            )}
          </p>
          <p className="text-xs text-muted-foreground">It prepares, checks and proposes on its own, and asks before anything that writes.</p>
        </div>
        <div className="flex shrink-0 flex-wrap gap-2">
          <Button size="sm" variant="outline" onClick={onSweep} disabled={sweeping || snap.paused}>
            <RefreshCw className={cn("h-3.5 w-3.5", sweeping && "animate-spin")} /> Sweep now
          </Button>
          <Button size="sm" variant={snap.paused ? "default" : "outline"} onClick={onPause} disabled={pausing}>
            {snap.paused ? <Play className="h-3.5 w-3.5" /> : <Pause className="h-3.5 w-3.5" />} {snap.paused ? "Resume" : "Pause"}
          </Button>
        </div>
      </div>
    </section>
  );
}

// ----------------------------------------------------------------------------- work items
const LANE_TONE = {
  violet: "bg-violet-500/12 text-violet-600 dark:text-violet-300",
  sky: "bg-sky-500/12 text-sky-600 dark:text-sky-300",
  emerald: "bg-emerald-500/12 text-emerald-600 dark:text-emerald-300",
} as const;

function Lane({
  title,
  hint,
  icon: Icon,
  tone,
  items,
  empty,
  compact,
  children,
}: {
  title: string;
  hint: string;
  icon: LucideIcon;
  tone: keyof typeof LANE_TONE;
  items: WorkerItem[];
  empty: string;
  compact?: boolean;
  children: (item: WorkerItem) => React.ReactNode;
}) {
  return (
    <section className="surface p-4 sm:p-5">
      <div className="mb-3 flex items-center gap-2">
        <span className={cn("flex h-8 w-8 items-center justify-center rounded-xl", LANE_TONE[tone])}>
          <Icon className={cn("h-4 w-4", Icon === LoaderCircle && items.length && "animate-spin")} />
        </span>
        <div className="min-w-0 flex-1">
          <h3 className="font-display text-base font-medium leading-tight">
            {title} <span className="tabular-nums text-muted-foreground">· {items.length}</span>
          </h3>
          <p className="text-xs text-muted-foreground">{hint}</p>
        </div>
      </div>
      {items.length ? (
        <div className={cn(compact ? "divide-y divide-border/60" : "grid gap-3 md:grid-cols-2")}>{items.map((item) => children(item))}</div>
      ) : (
        <p className="text-sm text-muted-foreground">{empty}</p>
      )}
    </section>
  );
}

function Evidence({ item }: { item: WorkerItem }) {
  const ev = item.evidence;
  const chips = EVIDENCE_KEYS.filter(([k]) => ev[k] !== undefined && ev[k] !== null && ev[k] !== "").map(([k, label]) => `${label}: ${String(ev[k])}`);
  const runId = typeof ev.run_id === "string" ? ev.run_id : null;
  const started = (ev.started ?? null) as { kind?: string; id?: string } | null;
  const first = Array.isArray(ev.first) ? (ev.first as string[]) : [];
  return (
    <div className="space-y-1.5">
      {chips.length || runId || started?.id ? (
        <div className="flex flex-wrap gap-1">
          {chips.map((c) => (
            <span key={c} className="rounded-md border border-border/70 bg-background/70 px-1.5 py-px font-mono text-[10.5px] text-foreground/80">
              {c}
            </span>
          ))}
          {runId ? <span className="rounded-md border border-border/70 bg-background/70 px-1.5 py-px font-mono text-[10.5px] text-muted-foreground">run {runId.slice(0, 8)}</span> : null}
          {started?.id ? (
            <span className="rounded-md border border-sky-500/40 bg-sky-500/10 px-1.5 py-px font-mono text-[10.5px] text-sky-700 dark:text-sky-300">
              started {started.kind} {started.id.slice(0, 8)}
            </span>
          ) : null}
        </div>
      ) : null}
      {first.length ? <p className="truncate font-mono text-[10.5px] text-muted-foreground">{first.join(" · ")}</p> : null}
      {typeof ev.error === "string" && ev.error ? (
        <p className="line-clamp-2 rounded-md bg-muted/60 px-2 py-1 font-mono text-[10.5px] text-muted-foreground" title={ev.error}>
          {ev.error}
        </p>
      ) : null}
    </div>
  );
}

function WorkCard({
  item,
  skills,
  busy,
  onDecide,
  emphasis,
}: {
  item: WorkerItem;
  skills: WorkerSkill[];
  busy: boolean;
  onDecide: (item: WorkerItem, decision: "approve" | "dismiss" | "done", checks?: string[]) => void;
  emphasis?: boolean;
}) {
  const [ticked, setTicked] = useState<string[]>([]);
  const skill = skills.find((s) => s.key === item.skill);
  const Icon = SKILL_ICON[item.skill] ?? Sparkles;
  const action = item.action;
  const canApprove = item.status === "waiting" && action !== null && action.kind !== "open";
  // The done-when checks of the playbooks bound to this skill, ticked before approving.
  const checklist = canApprove ? (skill?.playbooks ?? []).filter((p) => p.checks.length) : [];
  const toggle = (check: string) => setTicked((t) => (t.includes(check) ? t.filter((c) => c !== check) : [...t, check]));
  return (
    <article
      className={cn(
        "flex min-w-0 flex-col gap-2 rounded-2xl border bg-card/80 p-3.5 transition-shadow hover:shadow-md",
        emphasis ? "border-amber-500/40 shadow-[0_10px_30px_-22px_hsl(38_92%_50%)]" : "border-border/70",
      )}
    >
      <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
        <span className="inline-flex items-center gap-1 rounded-md bg-primary/10 px-1.5 py-0.5 font-medium text-primary">
          <Icon className="h-3 w-3" /> {skill?.name ?? item.skill}
        </span>
        <span className="rounded-md border border-border/70 px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground" title={TIER[item.tier].meaning}>
          {item.tier}
        </span>
        <span className="ml-auto text-muted-foreground" title={item.created_at}>
          picked up {formatRelative(item.created_at)}
        </span>
      </div>
      <h4 className="font-medium leading-snug">{item.title}</h4>
      {item.detail ? <p className="text-xs text-muted-foreground">{item.detail}</p> : null}
      <Evidence item={item} />
      {checklist.length ? <ApprovalChecklist playbooks={checklist} ticked={ticked} onToggle={toggle} /> : null}
      <div className="mt-auto flex flex-wrap items-center gap-2 pt-1">
        {item.status === "running" ? (
          <span className="inline-flex items-center gap-1.5 text-xs text-sky-700 dark:text-sky-300">
            <LoaderCircle className="h-3.5 w-3.5 animate-spin" /> following it
          </span>
        ) : null}
        {canApprove && action ? (
          <Button size="sm" className="h-8" disabled={busy} onClick={() => onDecide(item, "approve", ticked)}>
            {busy ? <LoaderCircle className="h-3.5 w-3.5 animate-spin" /> : <ThumbsUp className="h-3.5 w-3.5" />} Approve: {action.label}
          </Button>
        ) : null}
        {action?.link ? (
          <Button asChild size="sm" variant={canApprove ? "ghost" : "outline"} className="h-8">
            <Link to={action.link}>
              {action.kind === "open" ? action.label : "Open"} <ArrowUpRight className="h-3.5 w-3.5" />
            </Link>
          </Button>
        ) : null}
        {item.status !== "running" ? (
          <>
            {!canApprove ? (
              <Button size="sm" variant="ghost" className="h-8 text-muted-foreground" disabled={busy} onClick={() => onDecide(item, "done")}>
                <CircleCheck className="h-3.5 w-3.5" /> Mark done
              </Button>
            ) : null}
            <Button size="sm" variant="ghost" className="h-8 text-muted-foreground" disabled={busy} onClick={() => onDecide(item, "dismiss")}>
              <CircleSlash className="h-3.5 w-3.5" /> Dismiss
            </Button>
          </>
        ) : null}
      </div>
    </article>
  );
}

function ApprovalChecklist({ playbooks, ticked, onToggle }: { playbooks: WorkerPlaybook[]; ticked: string[]; onToggle: (check: string) => void }) {
  const checks = playbooks.flatMap((p) => p.checks);
  const done = checks.filter((c) => ticked.includes(c)).length;
  return (
    <div className="rounded-xl border border-border/70 bg-muted/30 p-2.5">
      <div className="mb-1.5 flex items-center gap-1.5 text-[11px]">
        <BookOpenCheck className="h-3.5 w-3.5 text-primary" />
        <span className="font-medium">Before you approve</span>
        <span className="ml-auto tabular-nums text-muted-foreground">
          {done} of {checks.length} confirmed
        </span>
      </div>
      <div className="space-y-2">
        {playbooks.map((p) => (
          <fieldset key={p.package} className="min-w-0">
            <legend className="mb-0.5 max-w-full truncate text-[10px] font-medium uppercase tracking-wide text-muted-foreground" title={p.description}>
              {p.name}
            </legend>
            {p.checks.map((check) => (
              <label key={check} className="flex cursor-pointer items-start gap-2 rounded-md px-1 py-0.5 text-[11.5px] hover:bg-muted/60">
                <input type="checkbox" className="mt-0.5 accent-[hsl(var(--primary))]" checked={ticked.includes(check)} onChange={() => onToggle(check)} />
                <span>{sentence(check)}</span>
              </label>
            ))}
          </fieldset>
        ))}
      </div>
      <p className="mt-1.5 text-[10.5px] text-muted-foreground">The journal records each check as confirmed or open. An open check does not block the approval.</p>
    </div>
  );
}

type ChecklistRow = { playbook: string; check: string; confirmed: boolean };

function JournalChecklist({ rows }: { rows: ChecklistRow[] }) {
  return (
    <details className="mt-1 text-[11px]">
      <summary className="cursor-pointer text-muted-foreground hover:text-foreground">Playbook checks</summary>
      <ul className="mt-1 space-y-0.5">
        {rows.map((r) => (
          <li key={`${r.playbook}:${r.check}`} className="flex items-start gap-1.5" title={r.playbook}>
            {r.confirmed ? (
              <CircleCheck className="mt-0.5 h-3 w-3 shrink-0 text-emerald-500" />
            ) : (
              <CircleDashed className="mt-0.5 h-3 w-3 shrink-0 text-muted-foreground" />
            )}
            <span className={r.confirmed ? undefined : "text-muted-foreground"}>
              {sentence(r.check)}
              {r.confirmed ? "" : " (open)"}
            </span>
          </li>
        ))}
      </ul>
    </details>
  );
}

function ClosedRow({ item }: { item: WorkerItem }) {
  const meta =
    item.status === "done"
      ? { icon: CircleCheck, tone: "text-emerald-600 dark:text-emerald-300", label: "done" }
      : item.status === "failed"
        ? { icon: CircleX, tone: "text-destructive", label: "failed" }
        : { icon: CircleSlash, tone: "text-muted-foreground", label: "dismissed" };
  const Icon = meta.icon;
  return (
    <div className="flex min-w-0 items-center gap-2 py-2 text-sm">
      <Icon className={cn("h-4 w-4 shrink-0", meta.tone)} />
      <span className="min-w-0 flex-1 truncate">{item.title}</span>
      <span className="shrink-0 text-xs text-muted-foreground">
        {meta.label}
        {item.decided_by ? ` by ${item.decided_by}` : ""} · {formatRelative(item.updated_at)}
      </span>
    </div>
  );
}

// ----------------------------------------------------------------------------- the journal
function Journal({ entries, chainOk }: { entries: WorkerJournalEntry[]; chainOk: boolean }) {
  // Entries that arrive after the page opened are highlighted as they land.
  const baseline = useRef<number | null>(null);
  const top = entries[0]?.id ?? 0;
  useEffect(() => {
    if (baseline.current === null && entries.length) baseline.current = top;
  }, [entries.length, top]);
  const fresh = baseline.current ?? top;
  const shown = useMemo(() => entries.slice(0, 40), [entries]);
  return (
    <section className="surface flex min-w-0 flex-col p-4 sm:p-5 xl:max-h-[52rem]">
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-primary/12 text-primary">
          <Hash className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <h3 className="font-display text-base font-medium leading-tight">Journal</h3>
          <p className="text-xs text-muted-foreground">Every step, newest first. Each entry is hashed over the one before it.</p>
        </div>
        {chainOk ? (
          <Badge variant="success" title="Every entry shown hashes to its own record and links to the one before it">
            <BadgeCheck className="mr-1 h-3 w-3" /> chain verified
          </Badge>
        ) : (
          <Badge variant="destructive">
            <ShieldAlert className="mr-1 h-3 w-3" /> chain broken
          </Badge>
        )}
      </div>
      <ol className="min-h-0 flex-1 overflow-y-auto pr-1">
        {shown.map((e, i) => {
          const meta = KIND[e.kind];
          const Icon = meta.icon;
          return (
            <li key={e.id} className={cn("relative flex gap-3 rounded-lg py-2 pl-1 pr-1", e.id > fresh && "worker-new")}>
              {i < shown.length - 1 ? <span className="absolute left-[19px] top-9 h-[calc(100%-1.5rem)] w-px bg-border" aria-hidden="true" /> : null}
              <span className={cn("relative z-10 flex h-[30px] w-[30px] shrink-0 items-center justify-center rounded-full border bg-card", meta.tone)}>
                <Icon className="h-3.5 w-3.5" />
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-baseline gap-x-2 text-[11px] text-muted-foreground">
                  <span className="font-mono tabular-nums">{clock(e.at)}</span>
                  <span className={cn("font-medium", meta.tone)}>{meta.label}</span>
                  {e.skill ? <span>· {e.skill}</span> : null}
                  <span className="ml-auto font-mono text-[10px] opacity-70" title={e.record_hash}>
                    #{e.record_hash.slice(0, 7)}
                  </span>
                </div>
                <p className="break-words text-sm leading-snug">{e.message}</p>
                {Array.isArray(e.evidence?.checklist) ? <JournalChecklist rows={e.evidence.checklist as ChecklistRow[]} /> : null}
              </div>
            </li>
          );
        })}
      </ol>
    </section>
  );
}

// ----------------------------------------------------------------------------- planned against live
const STATUS: Record<IntegrityStatus, { label: string; bar: string; pill: string; order: number }> = {
  planned_only: { label: "planned only", bar: "bg-rose-500/70", pill: "border-rose-500/40 bg-rose-500/10 text-rose-700 dark:text-rose-300", order: 0 },
  empty: { label: "empty", bar: "bg-amber-500", pill: "border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300", order: 1 },
  exists: { label: "exists, rows unknown", bar: "bg-sky-500", pill: "border-sky-500/40 bg-sky-500/10 text-sky-700 dark:text-sky-300", order: 2 },
  live: { label: "live", bar: "bg-emerald-500", pill: "border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300", order: 3 },
};

/** Every declared table against the warehouse, origin by origin, the ones that hold no rows first with what reads them. */
function IntegrityPanel({ integrity }: { integrity: WorkerIntegrity }) {
  const [showLive, setShowLive] = useState(false);
  const tables = [...integrity.tables].sort((a, b) => STATUS[a.status].order - STATUS[b.status].order || a.table.localeCompare(b.table));
  const shown = showLive ? tables : tables.filter((t) => t.status !== "live");
  const live = tables.length - tables.filter((t) => t.status !== "live").length;
  return (
    <section id="integrity" className="surface scroll-mt-6 p-4 sm:p-5">
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-rose-500/12 text-rose-600 dark:text-rose-300">
          <ScanSearch className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <h3 className="font-display text-base font-medium leading-tight">Planned vs live</h3>
          <p className="text-xs text-muted-foreground">
            Every table a repository or design document declares, against what the warehouse holds. A declared table no run ever wrote to is a plan, not a
            table; a plan that reads one cannot be approved.
          </p>
        </div>
        {integrity.checked_at ? <span className="text-[11px] text-muted-foreground">checked {formatRelative(integrity.checked_at)}</span> : null}
      </div>
      {!integrity.available ? (
        <p className="flex items-start gap-2 rounded-xl border border-amber-500/40 bg-amber-500/5 p-3 text-sm">
          <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" />
          <span>
            Not checked: {integrity.problem}. The worker reports nothing rather than guess, and keeps earlier findings open until it can see again.
          </span>
        </p>
      ) : (
        <div className="space-y-4">
          <div className="grid gap-2 md:grid-cols-2">
            {integrity.origins.map((o) => (
              <div key={o.origin} className="min-w-0 rounded-xl border border-border/70 bg-background/60 p-3">
                <div className="flex min-w-0 items-center gap-2">
                  {o.kind === "repo" ? <GitBranch className="h-3.5 w-3.5 shrink-0 text-primary" /> : <Layers className="h-3.5 w-3.5 shrink-0 text-primary" />}
                  <span className="min-w-0 flex-1 truncate font-mono text-xs font-medium" title={o.origin}>
                    {o.origin}
                  </span>
                  <span className="text-[11px] tabular-nums text-muted-foreground">{o.declared} declared</span>
                </div>
                <div className="mt-2 flex h-2 gap-0.5 overflow-hidden rounded-full bg-muted/60" role="img" aria-label={`${o.live} live, ${o.empty} empty, ${o.planned_only} planned only`}>
                  {(["live", "exists", "empty", "planned_only"] as IntegrityStatus[]).map((s) =>
                    o[s] ? <span key={s} className={cn("h-full rounded-full", STATUS[s].bar)} style={{ width: `${(o[s] / Math.max(1, o.declared)) * 100}%` }} /> : null,
                  )}
                </div>
                <div className="mt-1.5 flex flex-wrap gap-x-3 gap-y-0.5 text-[11px] tabular-nums text-muted-foreground">
                  <span className="text-emerald-700 dark:text-emerald-300">{o.live} live</span>
                  {o.empty ? <span className="text-amber-700 dark:text-amber-300">{o.empty} empty</span> : null}
                  {o.exists ? <span className="text-sky-700 dark:text-sky-300">{o.exists} rows unknown</span> : null}
                  {o.planned_only ? <span className="text-rose-700 dark:text-rose-300">{o.planned_only} planned only</span> : null}
                  {o.aliases ? <span>{o.aliases} loaded under another name</span> : null}
                </div>
              </div>
            ))}
          </div>
          {shown.length ? (
            <div className="overflow-x-auto rounded-xl border border-border/60">
              <table className="w-full text-xs">
                <thead className="bg-muted/40 text-[10px] uppercase tracking-wide text-muted-foreground">
                  <tr>
                    <th className="px-3 py-1.5 text-left font-medium">Declared table</th>
                    <th className="px-3 py-1.5 text-left font-medium">Status</th>
                    <th className="px-3 py-1.5 text-left font-medium">In the warehouse</th>
                    <th className="px-3 py-1.5 text-right font-medium">Rows</th>
                    <th className="px-3 py-1.5 text-left font-medium">What reads it</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/50">
                  {shown.map((t) => (
                    <tr key={`${t.origin}-${t.table}`} className="align-top">
                      <td className="px-3 py-1.5">
                        <div className="font-mono font-medium">{t.table}</div>
                        <div className="truncate text-[10.5px] text-muted-foreground">{t.origin}</div>
                      </td>
                      <td className="px-3 py-1.5">
                        <span className={cn("inline-flex whitespace-nowrap rounded-md border px-1.5 py-px text-[10.5px] font-medium", STATUS[t.status].pill)}>
                          {STATUS[t.status].label}
                        </span>
                      </td>
                      <td className="px-3 py-1.5 font-mono text-[10.5px] text-muted-foreground">
                        {t.observed ?? "not there"}
                        {t.loaded_as ? <div className="font-sans">loaded as {t.loaded_as}</div> : null}
                      </td>
                      <td className="px-3 py-1.5 text-right tabular-nums">{t.rows === null ? "–" : formatInt(t.rows)}</td>
                      <td className="px-3 py-1.5">
                        {t.readers.length ? (
                          <ul className="space-y-0.5">
                            {t.readers.map((r) => (
                              <li key={r} className={cn(t.status !== "live" && "text-rose-700 dark:text-rose-300")}>
                                {r}
                              </li>
                            ))}
                          </ul>
                        ) : (
                          <span className="text-muted-foreground">nothing declared</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">Every declared table is live.</p>
          )}
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-muted-foreground">
            {live ? (
              <button type="button" className="font-medium text-primary hover:underline" onClick={() => setShowLive((v) => !v)}>
                {showLive ? "Hide" : "Show"} the {live} live table{live === 1 ? "" : "s"}
              </button>
            ) : null}
            <span>
              The catalog holds {formatInt(integrity.observed)} tables; {formatInt(integrity.undeclared)} of them are declared nowhere.
            </span>
          </div>
        </div>
      )}
    </section>
  );
}

// ----------------------------------------------------------------------------- skills and tiers
function Skills({ skills }: { skills: WorkerSkill[] }) {
  return (
    <section className="space-y-3">
      <div>
        <h3 className="font-display text-lg font-medium">Skills</h3>
        <p className="text-xs text-muted-foreground">
          What the worker can do, how far it may go alone, and the gate its output must pass. A SKILL.md package in the worker&apos;s folder describes the
          skill of the same name; a playbook bound to a skill adds its red flags and done-when checks, never its tier or gate.
        </p>
      </div>
      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {skills.map((s) => {
          const Icon = SKILL_ICON[s.key] ?? Package;
          return (
            <article key={s.key} className="surface flex min-w-0 flex-col gap-2 p-4">
              <div className="flex items-start gap-2.5">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-primary/12 text-primary">
                  <Icon className="h-4 w-4" />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <h4 className="font-medium">{s.name}</h4>
                    <span className="rounded-md border border-border/70 px-1.5 py-px font-mono text-[10px] text-muted-foreground" title={TIER[s.tier].meaning}>
                      {TIER[s.tier].label}
                    </span>
                  </div>
                  {s.package ? (
                    <span className="mt-0.5 inline-flex items-center gap-1 text-[10.5px] text-muted-foreground">
                      <Package className="h-3 w-3" /> {s.package}
                      {s.where ? "" : " · reference only, no hub adapter yet"}
                    </span>
                  ) : null}
                </div>
              </div>
              <p className="text-xs text-muted-foreground">{s.description}</p>
              {s.gate ? (
                <p className="flex items-start gap-1.5 rounded-lg bg-muted/50 px-2 py-1.5 text-[11.5px]">
                  <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" /> <span>{s.gate}</span>
                </p>
              ) : null}
              {s.stops.length ? (
                <ul className="space-y-0.5 text-[11px] text-muted-foreground">
                  {s.stops.map((stop) => (
                    <li key={stop} className="flex items-start gap-1.5">
                      <CircleAlert className="mt-0.5 h-3 w-3 shrink-0 text-amber-500" /> {stop}
                    </li>
                  ))}
                </ul>
              ) : null}
              {s.rules?.length ? (
                <div>
                  <div className="mb-1 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">Rules from the package</div>
                  <ul className="space-y-0.5 text-[11.5px]">
                    {s.rules.map((rule) => (
                      <li key={rule} className="flex items-start gap-1.5">
                        <BadgeCheck className="mt-0.5 h-3 w-3 shrink-0 text-primary" /> {rule}
                      </li>
                    ))}
                  </ul>
                </div>
              ) : null}
              {s.red_flags?.length || s.checks?.length ? <Guidance redFlags={s.red_flags} checks={s.checks} /> : null}
              {s.playbooks?.length ? <Playbooks playbooks={s.playbooks} /> : null}
              <div className="mt-auto flex flex-wrap items-center gap-x-3 gap-y-1 border-t border-border/60 pt-2 text-[11px] text-muted-foreground">
                <span className="tabular-nums">{s.open} open</span>
                <span className="tabular-nums">
                  {s.succeeded}/{s.handled} succeeded
                </span>
                {s.last_at ? <span>last {formatRelative(s.last_at)}</span> : null}
                {s.where ? (
                  <Link to={s.where} className="ml-auto inline-flex items-center gap-0.5 font-medium text-primary hover:underline">
                    where it works <ArrowUpRight className="h-3 w-3" />
                  </Link>
                ) : null}
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}

function Guidance({ redFlags, checks, rules = [] }: { redFlags: string[]; checks: string[]; rules?: string[] }) {
  const groups: { title: string; items: string[]; icon: LucideIcon; tone: string }[] = [
    { title: "Red flags", items: redFlags, icon: Flag, tone: "text-rose-500" },
    { title: "Done when", items: checks, icon: CircleCheck, tone: "text-emerald-500" },
    { title: "Rules", items: rules, icon: BadgeCheck, tone: "text-primary" },
  ];
  return (
    <div className="space-y-1.5 text-[11px]">
      {groups
        .filter((g) => g.items.length)
        .map(({ title, items, icon: Icon, tone }) => (
          <div key={title}>
            <div className="mb-0.5 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">{title}</div>
            <ul className="space-y-0.5">
              {items.map((item) => (
                <li key={item} className="flex items-start gap-1.5">
                  <Icon className={`mt-0.5 h-3 w-3 shrink-0 ${tone}`} /> {sentence(item)}
                </li>
              ))}
            </ul>
          </div>
        ))}
    </div>
  );
}

function Playbooks({ playbooks }: { playbooks: WorkerPlaybook[] }) {
  return (
    <div className="space-y-1">
      <div className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">Playbooks</div>
      {playbooks.map((p) => (
        <details key={p.package} className="group rounded-lg border border-border/60 px-2 py-1.5">
          <summary className="flex cursor-pointer list-none items-center gap-1.5 text-[11.5px] [&::-webkit-details-marker]:hidden" title={p.package}>
            <BookOpenCheck className="h-3.5 w-3.5 shrink-0 text-primary" />
            <span className="min-w-0 flex-1 truncate font-medium">{p.name}</span>
            <span className="shrink-0 tabular-nums text-[10.5px] text-muted-foreground">
              {p.red_flags.length} flags · {p.checks.length} checks
            </span>
            <ChevronDown className="h-3 w-3 shrink-0 text-muted-foreground transition-transform group-open:rotate-180" />
          </summary>
          <div className="mt-1.5 space-y-2">
            {p.description ? <p className="text-[11px] text-muted-foreground">{p.description}</p> : null}
            <Guidance redFlags={p.red_flags} checks={p.checks} rules={p.rules} />
          </div>
        </details>
      ))}
    </div>
  );
}

function TierLegend({ ceiling }: { ceiling: WorkerTier }) {
  const order: WorkerTier[] = ["T0", "T1", "T2", "T3"];
  const reach = order.indexOf(ceiling);
  return (
    <section className="surface p-4">
      <h3 className="font-display text-base font-medium">Autonomy</h3>
      <p className="mb-3 text-xs text-muted-foreground">How far the worker may go without you. Its ceiling is {TIER[ceiling].label}; each skill can be held lower.</p>
      <ol className="grid gap-2 sm:grid-cols-4">
        {order.map((t, i) => (
          <li
            key={t}
            className={cn(
              "rounded-xl border px-3 py-2",
              i <= reach ? "border-primary/40 bg-primary/5" : "border-dashed border-border text-muted-foreground",
              i === reach && "shadow-[0_0_0_3px_hsl(var(--primary)/0.12)]",
            )}
          >
            <div className="font-mono text-xs font-medium">{TIER[t].label}</div>
            <div className="text-[11px] text-muted-foreground">{TIER[t].meaning}</div>
          </li>
        ))}
      </ol>
    </section>
  );
}
