import { ArrowRight, ArrowUpRight, Briefcase, LoaderCircle } from "lucide-react";
import { Link } from "react-router-dom";

import type { IntentRecord, IntentStatus, WorkerItem } from "@/api/types";
import { Skeleton } from "@/components/ui/skeleton";
import { useIntents } from "@/hooks/queries";
import { formatInt, formatRelative } from "@/lib/format";
import { cn } from "@/lib/utils";

const TRACK = ["Read", "Plan", "Approve", "Build", "Load"] as const;
const STAGE: Record<IntentStatus, number> = {
  received: 0,
  clarifying: 0,
  planning: 1,
  modeling: 1,
  waiting: 1,
  spec_proposed: 2,
  approved: 3,
  coding: 3,
  pr_open: 3,
  running: 4,
  loaded: 5,
  done: 5,
  rejected: 2,
  failed: 4,
};
const FINISHED = new Set<IntentStatus>(["loaded", "done", "rejected", "failed"]);
const DAY_MS = 24 * 3600 * 1000;

/** Which capability a skill's work belongs to, for the worker's own running items. */
const SKILL_CAPABILITY: Record<string, string> = {
  "run-triage": "Investigate failures",
  "catalog-sync": "Investigate failures",
  "pipeline-builder": "Prepare pipelines",
  "silver-compiler": "Design Silver & Gold",
  "schema-integrity": "Validate the work",
  "catalog-curator": "Validate the work",
  "repo-crawler": "Explain dependencies",
};

type State = "active" | "waiting" | "blocked" | "done" | "failed";
type Output = { label: string; href?: string | null };
interface Row {
  key: string;
  title: string;
  ref: string | null;
  link: string | null;
  capability: string;
  stage: number | null;
  state: State;
  step: string;
  outputs: Output[];
  decision: { label: string; href: string | null; external?: boolean } | null;
  updated: string;
}

const STATE_TONE: Record<State, string> = {
  active: "bg-sky-500",
  waiting: "bg-amber-500",
  blocked: "bg-rose-500",
  done: "bg-emerald-500",
  failed: "bg-destructive",
};

function plural(n: number, word: string): string {
  return `${formatInt(n)} ${word}${n === 1 ? "" : "s"}`;
}

function intentRow(i: IntentRecord): Row {
  const spec = i.spec;
  const blockers = spec?.blockers ?? [];
  const asked = i.questions.length;
  const runFailed = i.run?.status === "failed";
  const [step, state]: [string, State] = (() => {
    switch (i.status) {
      case "received":
        return ["Reading the ticket", "active"];
      case "clarifying":
        return [`Waiting on ${plural(asked, "answer")} in Jira`, "waiting"];
      case "planning":
        return ["Planning the delivery", "active"];
      case "modeling":
        return ["Designing the model and dry-running it", "active"];
      case "waiting":
        return ["Waiting for the layer below to be loaded", "waiting"];
      case "spec_proposed":
        return blockers.length ? ["Plan blocked: a table it reads holds no rows", "blocked"] : ["Plan ready for your approval", "waiting"];
      case "approved":
      case "coding":
        return ["Generating the pipeline and its tests", "active"];
      case "pr_open":
        return ["Pull request open for review", "waiting"];
      case "running":
        return ["Running in Snowflake", "active"];
      case "loaded":
        return ["Loaded and checked", "done"];
      case "done":
        return ["Delivered", "done"];
      case "rejected":
        return ["Plan rejected", "failed"];
      case "failed":
        return [runFailed ? "The run failed" : "Failed", "failed"];
    }
  })();

  const outputs: Output[] = [];
  if (spec?.models?.length) outputs.push({ label: `${plural(spec.models.length, "table")} modelled` });
  else if (spec?.tables?.length) outputs.push({ label: `${plural(spec.tables.length, "table")} planned` });
  if (spec?.risks?.length) outputs.push({ label: plural(spec.risks.length, "risk") });
  if (i.coder?.files?.length) {
    const tests = i.coder.tests_passed === true ? ", tests pass" : i.coder.tests_passed === false ? ", tests fail" : "";
    outputs.push({ label: `${plural(i.coder.files.length, "file")} generated${tests}` });
  }
  if (i.pr_url) outputs.push({ label: "Pull request", href: i.pr_url });
  if (i.run) {
    const checks = i.run.checks;
    if (i.run.statements) outputs.push({ label: `${plural(i.run.statements, "statement")} run` });
    if (checks.length) outputs.push({ label: `${checks.filter((c) => c.passed).length}/${checks.length} checks passed` });
    const rows = (i.run.models ?? []).reduce((n, m) => n + (m.rows || 0), 0);
    if (rows) outputs.push({ label: `${formatInt(rows)} rows in the layer` });
  }

  const page = `/intents/${i.id}`;
  const decision: Row["decision"] =
    i.status === "clarifying"
      ? { label: "Answer in Jira", href: i.jira_url, external: true }
      : i.status === "spec_proposed"
        ? blockers.length
          ? { label: "Load the tables it reads, then re-plan", href: page }
          : { label: "Approve the plan", href: page }
        : i.status === "pr_open"
          ? { label: "Review the pull request", href: i.pr_url, external: true }
          : i.status === "failed" || runFailed
            ? { label: "Read the failure", href: page }
            : null;

  const kind = spec?.kind;
  const capability = STAGE[i.status] === 0 ? "Understand a request" : kind === "model_layer" || kind === "gold_fact" ? "Design Silver & Gold" : "Prepare pipelines";
  return { key: i.id, title: i.title, ref: i.jira_key, link: page, capability, stage: STAGE[i.status], state, step, outputs, decision, updated: i.updated_at };
}

function itemRow(item: WorkerItem): Row {
  const started = (item.evidence.started ?? null) as { kind?: string; id?: string } | null;
  return {
    key: item.key,
    title: item.title,
    ref: null,
    link: item.action?.link ?? null,
    capability: SKILL_CAPABILITY[item.skill] ?? "Digital worker",
    stage: null,
    state: "active",
    step: "Following it until it finishes",
    outputs: started?.id ? [{ label: `${started.kind ?? "run"} ${started.id.slice(0, 8)} started` }] : [],
    decision: null,
    updated: item.updated_at,
  };
}

/** The work in flight, left to right: what it is, the step it is on, what it has produced and what it waits on you for. */
export function CurrentWork({ running }: { running: WorkerItem[] }) {
  const intents = useIntents({ status: null, limit: 25, offset: 0 });
  const now = Date.now();
  const recent = (intents.data?.items ?? []).filter((i) => !FINISHED.has(i.status) || now - Date.parse(i.updated_at) < DAY_MS);
  // An intent the worker follows is already a row of its own.
  const rows = [...recent.map(intentRow), ...running.filter((r) => !r.key.startsWith("intent:")).map(itemRow)].sort(
    (a, b) => Number(a.state === "done") - Number(b.state === "done") || Date.parse(b.updated) - Date.parse(a.updated),
  );

  return (
    <section className="surface p-4 sm:p-5" aria-labelledby="current-work-title">
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-primary/12 text-primary">
          <Briefcase className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <h3 id="current-work-title" className="font-display text-base font-medium leading-tight">
            Current work
          </h3>
          <p className="text-xs text-muted-foreground">Requests in flight and what finished in the last day.</p>
        </div>
      </div>

      {intents.isLoading ? (
        <Skeleton className="h-24 w-full rounded-xl" />
      ) : rows.length ? (
        <div className="overflow-hidden rounded-xl border border-border/70">
          <div className="hidden grid-cols-[minmax(0,1.3fr)_minmax(0,1.2fr)_minmax(0,1.2fr)_minmax(0,0.9fr)] gap-3 border-b border-border/70 bg-muted/40 px-3 py-2 text-[10px] font-medium uppercase tracking-wide text-muted-foreground lg:grid">
            {["Current work", "Current step", "Outputs", "Decisions needed"].map((h, n) => (
              <span key={h} className="flex items-center gap-1.5">
                {h}
                {n < 3 ? <ArrowRight className="h-3 w-3 opacity-60" aria-hidden="true" /> : null}
              </span>
            ))}
          </div>
          <ul className="divide-y divide-border/60">
            {rows.map((r) => (
              <WorkRow key={r.key} row={r} />
            ))}
          </ul>
        </div>
      ) : (
        <p className="rounded-xl border border-dashed p-4 text-sm text-muted-foreground">
          No work in flight.{" "}
          <Link to="/intents" className="font-medium text-primary hover:underline">
            Start from Jira
          </Link>{" "}
          to give the worker a request.
        </p>
      )}
    </section>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return <span className="mb-0.5 block text-[10px] font-medium uppercase tracking-wide text-muted-foreground lg:hidden">{children}</span>;
}

function WorkRow({ row: r }: { row: Row }) {
  return (
    <li className="grid gap-3 px-3 py-3 lg:grid-cols-[minmax(0,1.3fr)_minmax(0,1.2fr)_minmax(0,1.2fr)_minmax(0,0.9fr)]">
      <div className="min-w-0">
        <Label>Current work</Label>
        <div className="flex flex-wrap items-center gap-1.5">
          {r.ref ? <span className="rounded-md bg-primary/10 px-1.5 py-px font-mono text-[11px] font-medium text-primary">{r.ref}</span> : null}
          <span className="rounded-md border border-border/70 px-1.5 py-px text-[10.5px] text-muted-foreground">{r.capability}</span>
        </div>
        {r.link ? (
          <Link to={r.link} className="mt-1 block text-sm font-medium leading-snug hover:underline">
            {r.title}
          </Link>
        ) : (
          <p className="mt-1 text-sm font-medium leading-snug">{r.title}</p>
        )}
        <span className="text-[11px] text-muted-foreground">updated {formatRelative(r.updated)}</span>
      </div>

      <div className="min-w-0">
        <Label>Current step</Label>
        <p className="flex items-start gap-1.5 text-[12.5px]">
          {r.state === "active" ? (
            <LoaderCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 animate-spin text-sky-500 motion-reduce:animate-none" aria-hidden="true" />
          ) : (
            <span className={cn("mt-1.5 h-2 w-2 shrink-0 rounded-full", STATE_TONE[r.state])} aria-hidden="true" />
          )}
          <span>{r.step}</span>
        </p>
        {r.stage !== null ? <Track stage={r.stage} state={r.state} /> : null}
      </div>

      <div className="min-w-0">
        <Label>Outputs</Label>
        {r.outputs.length ? (
          <div className="flex flex-wrap gap-1">
            {r.outputs.map((o) =>
              o.href ? (
                <a key={o.label} href={o.href} target="_blank" rel="noreferrer" className="inline-flex items-center gap-0.5 rounded-md border border-primary/40 bg-primary/10 px-1.5 py-px text-[11px] text-primary hover:underline">
                  {o.label} <ArrowUpRight className="h-3 w-3" />
                </a>
              ) : (
                <span key={o.label} className="rounded-md border border-border/70 bg-background/70 px-1.5 py-px text-[11px]">
                  {o.label}
                </span>
              ),
            )}
          </div>
        ) : (
          <span className="text-[12px] text-muted-foreground">Nothing yet</span>
        )}
      </div>

      <div className="min-w-0">
        <Label>Decisions needed</Label>
        {r.decision ? (
          r.decision.href ? (
            r.decision.external ? (
              <a href={r.decision.href} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-[12.5px] font-medium text-amber-700 hover:underline dark:text-amber-300">
                {r.decision.label} <ArrowUpRight className="h-3.5 w-3.5" />
              </a>
            ) : (
              <Link to={r.decision.href} className="inline-flex items-center gap-1 text-[12.5px] font-medium text-amber-700 hover:underline dark:text-amber-300">
                {r.decision.label} <ArrowUpRight className="h-3.5 w-3.5" />
              </Link>
            )
          ) : (
            <span className="text-[12.5px] font-medium text-amber-700 dark:text-amber-300">{r.decision.label}</span>
          )
        ) : (
          <span className="text-[12px] text-muted-foreground">None</span>
        )}
      </div>
    </li>
  );
}

function Track({ stage, state }: { stage: number; state: State }) {
  return (
    <ol className="mt-2 flex gap-1" aria-label={`Step ${Math.min(stage + 1, TRACK.length)} of ${TRACK.length}`}>
      {TRACK.map((name, n) => {
        const done = n < stage;
        const here = n === stage;
        return (
          <li key={name} className="min-w-0 flex-1" title={name}>
            <span className={cn("block h-1.5 rounded-full", done ? "bg-emerald-500/70" : here ? STATE_TONE[state] : "bg-muted")} />
            <span className={cn("mt-0.5 block truncate text-[9.5px]", here ? "font-medium text-foreground" : "text-muted-foreground")}>{name}</span>
          </li>
        );
      })}
    </ol>
  );
}
