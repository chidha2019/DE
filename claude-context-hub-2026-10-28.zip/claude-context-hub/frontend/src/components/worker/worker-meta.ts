import { BookOpenCheck, GitBranch, Layers, RefreshCcw, ScanSearch, Stethoscope, Workflow, type LucideIcon } from "lucide-react";

import type { Readiness, WorkerTier } from "@/api/types";

/** The hub skill each icon stands for, wherever the worker's skills are shown. */
export const SKILL_ICON: Record<string, LucideIcon> = {
  "run-triage": Stethoscope,
  "pipeline-builder": Workflow,
  "silver-compiler": Layers,
  "catalog-sync": RefreshCcw,
  "catalog-curator": BookOpenCheck,
  "repo-crawler": GitBranch,
  "schema-integrity": ScanSearch,
};

export const TIER: Record<WorkerTier, { label: string; meaning: string }> = {
  T0: { label: "T0 · watch", meaning: "Watches and reports; changes nothing." },
  T1: { label: "T1 · diagnose", meaning: "Diagnoses and proposes on its own; a person acts." },
  T2: { label: "T2 · act once approved", meaning: "Acts only after a person approves the step." },
  T3: { label: "T3 · act alone", meaning: "Would act without asking. Not granted to this worker." },
};

export const READINESS: Record<Readiness, { label: string; pill: string; dot: string }> = {
  available: { label: "Available", pill: "border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300", dot: "bg-emerald-500" },
  missing_connection: { label: "Missing connection", pill: "border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300", dot: "bg-amber-500" },
  missing_rules: { label: "Missing rules", pill: "border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300", dot: "bg-amber-500" },
  tool_unavailable: { label: "Tool unavailable", pill: "border-rose-500/40 bg-rose-500/10 text-rose-700 dark:text-rose-300", dot: "bg-rose-500" },
};

/** A package's display name: its folder, without the SKILL.md. */
export function packageName(path: string | null | undefined): string {
  if (!path) return "";
  const parts = path.replace(/\\/g, "/").split("/").filter(Boolean);
  return (parts.length > 1 ? parts[parts.length - 2] : parts[0]) ?? "";
}

export const sentence = (text: string) => text.charAt(0).toUpperCase() + text.slice(1);
