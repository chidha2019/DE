import { FlaskConical, Radio } from "lucide-react";
import { useId } from "react";
import {
  Area,
  AreaChart,
  Bar as ChartBar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  type TooltipProps,
} from "recharts";

import { Bar, Sparkline } from "@/components/landing/kpi-cards";
import { Companion } from "@/components/personas/companion";
import { SectionCard } from "@/components/personas/persona-shell";
import { useGlossaryCoverage, useSemanticCatalog } from "@/hooks/queries";
import { formatInt } from "@/lib/format";
import { PERSONA_GENIE } from "@/lib/persona-genie";
import { PERSONA_SAMPLES, type SampleKpi, type SampleSection, type SampleSeries, type SampleStatus } from "@/lib/persona-samples";
import type { PersonaKey } from "@/lib/personas";
import { rgba } from "@/lib/tones";
import { cn } from "@/lib/utils";

const STATUS: Record<SampleStatus, { label: string; color: string }> = {
  ok: { label: "Healthy", color: "#10B981" },
  warn: { label: "Watch", color: "#F59E0B" },
  bad: { label: "Attention", color: "#EF4444" },
  info: { label: "Planned", color: "#0EA5E9" },
};

// Table cells that read as a state get a coloured chip; anything else stays neutral.
const WORDS: Record<string, SampleStatus> = {
  deployed: "ok",
  passed: "ok",
  healthy: "ok",
  classified: "ok",
  rotated: "ok",
  production: "ok",
  staging: "info",
  "rolled back": "warn",
  "in review": "warn",
  "not classified": "warn",
  due: "warn",
  open: "warn",
  high: "warn",
  stale: "warn",
  drift: "bad",
  overdue: "bad",
  failed: "bad",
  critical: "bad",
};

const AXIS = { fontSize: 11, fill: "#64748b" };

/** A workspace drawn from sample data: what the persona will see once its sources are connected. */
export function SampleWorkspace({ persona, tab }: { persona: PersonaKey; tab: string }) {
  const spec = PERSONA_SAMPLES[persona];
  if (!spec) return null;
  const overview = tab === "overview";
  const sections = overview ? spec.sections : spec.sections.filter((s) => s.tabs.includes(tab));
  return (
    <div className="space-y-4">
      <SampleBanner persona={persona} connect={spec.connect} />
      {overview ? (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
          {spec.kpis.map((kpi) => (kpi.live ? <LiveKpiCard key={kpi.label} kpi={kpi} /> : <KpiCard key={kpi.label} kpi={kpi} />))}
        </div>
      ) : null}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {pair(sections).map(({ section, wide }) => (
          <Section key={section.key} section={section} wide={wide} />
        ))}
      </div>
    </div>
  );
}

/** Half-width sections sit side by side in order; one left without a partner takes the whole row. */
function pair(sections: SampleSection[]): { section: SampleSection; wide: boolean }[] {
  const out: { section: SampleSection; wide: boolean }[] = [];
  for (let i = 0; i < sections.length; i++) {
    const section = sections[i];
    if (!section) continue;
    const next = sections[i + 1];
    if (!section.wide && next && !next.wide) {
      out.push({ section, wide: false }, { section: next, wide: false });
      i++;
    } else out.push({ section, wide: true });
  }
  return out;
}

function SampleBanner({ persona, connect }: { persona: PersonaKey; connect: string }) {
  const [h, s, l] = PERSONA_GENIE[persona].color;
  const tint = (alpha: number) => `hsl(${h} ${s}% ${l}% / ${alpha})`;
  return (
    <div
      className="relative flex items-center gap-3 overflow-hidden rounded-2xl border px-4 py-3"
      style={{ borderColor: tint(0.3), background: `linear-gradient(100deg, ${tint(0.14)}, transparent 70%)` }}
    >
      <Companion persona={persona} size="2.4rem" interactive={false} />
      <div className="min-w-0 text-sm">
        <div className="flex flex-wrap items-center gap-2 font-medium">
          Preview with sample data
          <SampleTag />
        </div>
        <p className="text-xs text-muted-foreground">{connect}</p>
      </div>
    </div>
  );
}

function SampleTag({ live }: { live?: boolean }) {
  const Icon = live ? Radio : FlaskConical;
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center gap-1 rounded-full px-1.5 py-0.5 text-[10px] font-medium",
        live ? "bg-emerald-500/12 text-emerald-600 dark:text-emerald-400" : "bg-muted text-muted-foreground",
      )}
      title={live ? "Read from the hub" : "Illustrative numbers until the source is connected"}
    >
      <Icon className="h-3 w-3" />
      {live ? "Live" : "Sample"}
    </span>
  );
}

// ---------------------------------------------------------------- KPI cards

interface KpiReading {
  value: string;
  delta: string;
  share?: number;
}

function KpiCard({ kpi, reading }: { kpi: SampleKpi; reading?: KpiReading }) {
  const c = kpi.color;
  const live = Boolean(kpi.live);
  const value = reading?.value ?? kpi.value;
  const delta = reading?.delta ?? kpi.delta;
  const tone = live ? "text-muted-foreground" : kpi.good ? "text-emerald-600 dark:text-emerald-400" : "text-rose-600 dark:text-rose-400";
  return (
    <div
      className="group relative flex min-w-0 flex-col overflow-hidden rounded-2xl border bg-card/90 p-4 shadow-sm"
      style={{ borderColor: rgba(c, 0.28) }}
      title={kpi.hint}
    >
      <span
        className="pointer-events-none absolute -right-12 -top-14 h-36 w-36 rounded-full opacity-25 blur-3xl transition-opacity duration-300 group-hover:opacity-45"
        style={{ background: c }}
        aria-hidden="true"
      />
      <span className="absolute inset-x-0 top-0 h-0.5" style={{ background: `linear-gradient(90deg, ${c}, transparent 75%)` }} aria-hidden="true" />
      <div className="relative flex items-center justify-between gap-2.5">
        <span
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-white"
          style={{ background: `linear-gradient(145deg, ${rgba(c, 0.75)}, ${c})`, boxShadow: `0 10px 22px -12px ${c}` }}
          aria-hidden="true"
        >
          <kpi.icon className="h-[18px] w-[18px]" />
        </span>
        <SampleTag live={live} />
      </div>
      <div className="relative mt-2.5 text-xs font-medium text-muted-foreground">{kpi.label}</div>
      <div className="relative mt-1.5 font-display text-3xl font-medium leading-none tracking-tight tabular-nums">
        {value}
        {kpi.unit ? <span className="ml-1 text-base text-muted-foreground">{kpi.unit}</span> : null}
      </div>
      <div className="relative mt-2">
        {kpi.spark ? <Sparkline values={shape(kpi.spark)} color={c} /> : null}
        {reading?.share !== undefined ? <Bar share={reading.share} color={c} /> : null}
      </div>
      <div className="relative mt-auto pt-2 text-[11px]">
        <span className={cn("font-medium", tone)}>{delta}</span>
        <span className="text-muted-foreground"> · {kpi.hint}</span>
      </div>
    </div>
  );
}

/** Stretches a series between its own low and high so small moves (an AUC of 0.82 to 0.86) still show. */
function shape(values: number[]): number[] {
  const lo = Math.min(...values);
  const span = Math.max(...values) - lo || 1;
  return values.map((v) => 1 + ((v - lo) / span) * 9);
}

/** A KPI read from the hub: the review queue, tables placed in a business area, and glossary terms in use. */
function LiveKpiCard({ kpi }: { kpi: SampleKpi }) {
  const coverage = useGlossaryCoverage().data;
  const catalog = useSemanticCatalog().data;
  let reading: KpiReading | undefined;
  if (kpi.live === "review" && coverage) {
    const decided = coverage.links_accepted + coverage.links_rejected;
    const all = decided + coverage.links_suggested;
    reading = {
      value: formatInt(coverage.links_suggested),
      delta: `${formatInt(coverage.links_accepted)} approved, ${formatInt(coverage.links_rejected)} rejected`,
      share: all ? decided / all : 0,
    };
  } else if (kpi.live === "placed" && catalog) {
    const tables = catalog.counts.entities;
    reading = {
      value: tables ? String(Math.round((catalog.entities_placed / tables) * 100)) : "–",
      delta: `${formatInt(catalog.entities_placed)} of ${formatInt(tables)} tables`,
      share: tables ? catalog.entities_placed / tables : 0,
    };
  } else if (kpi.live === "terms" && coverage) {
    reading = {
      value: formatInt(coverage.terms_linked),
      delta: `of ${formatInt(coverage.terms_total)} terms`,
      share: coverage.terms_total ? coverage.terms_linked / coverage.terms_total : 0,
    };
  }
  return <KpiCard kpi={kpi} reading={reading} />;
}

// ---------------------------------------------------------------- sections

function Section({ section, wide }: { section: SampleSection; wide: boolean }) {
  const flush = section.kind === "table";
  return (
    <SectionCard className={cn("min-w-0", wide && "lg:col-span-2")} title={section.title} description={section.description} actions={<SampleTag />}>
      <div className={flush ? undefined : "px-6 pb-6"}>
        {section.kind === "bars" || section.kind === "area" || section.kind === "line" ? <SeriesChart section={section} /> : null}
        {section.kind === "donut" ? <Donut section={section} /> : null}
        {section.kind === "table" ? <SampleTable section={section} /> : null}
        {section.kind === "cards" ? <StatusCards section={section} /> : null}
        {section.kind === "timeline" ? <Timeline section={section} /> : null}
        {section.kind === "meters" ? <Meters section={section} /> : null}
      </div>
    </SectionCard>
  );
}

type Of<K extends SampleSection["kind"]> = Extract<SampleSection, { kind: K }>;

function number(v: unknown): string {
  return typeof v === "number" ? (Number.isInteger(v) ? formatInt(v) : String(Number(v.toFixed(2)))) : String(v ?? "");
}

function Tip({ active, payload, label, series }: TooltipProps<number, string> & { series: SampleSeries[] }) {
  if (!active || !payload?.length) return null;
  const row = payload[0]?.payload as Record<string, string | number>;
  return (
    <div className="rounded-xl border border-border/80 bg-popover px-3 py-2 text-xs text-popover-foreground shadow-lg">
      <div className="mb-1 font-medium">{label}</div>
      {series.map((s) => (
        <div key={s.key} className="flex items-center justify-between gap-4">
          <span className="flex items-center gap-1.5 text-muted-foreground">
            <span className="h-2 w-2 rounded-sm" style={{ background: s.color }} /> {s.label}
          </span>
          <span className="font-mono tabular-nums">{number(row[s.key])}</span>
        </div>
      ))}
    </div>
  );
}

/** A category name on one line; recharts would otherwise wrap names like "premium change" to fit the axis. */
function NameTick({ x, y, payload }: { x?: number; y?: number; payload?: { value: string } }) {
  return (
    <text x={x} y={y} dy={4} textAnchor="end" fontSize={11} fill="#64748b">
      {payload?.value}
    </text>
  );
}

/** Bars, stacked areas or lines over a short window; a single series of named bars lies on its side so the names fit. */
function SeriesChart({ section }: { section: Of<"bars" | "area" | "line"> }) {
  const gid = useId().replace(/:/g, "");
  const { series, data, x } = section;
  const sideways = section.kind === "bars" && series.length === 1;
  const stack = section.stacked ? "stack" : undefined;
  const gradients = (
    <defs>
      {series.map((s) => (
        <linearGradient key={s.key} id={`${gid}-${s.key}`} x1="0" x2={sideways ? "1" : "0"} y1="0" y2={sideways ? "0" : "1"}>
          <stop offset="0%" stopColor={s.color} stopOpacity={section.kind === "area" ? 0.45 : sideways ? 0.6 : 0.95} />
          <stop offset="100%" stopColor={s.color} stopOpacity={section.kind === "area" ? 0.04 : sideways ? 0.95 : 0.55} />
        </linearGradient>
      ))}
    </defs>
  );
  const grid = <CartesianGrid stroke="#64748b" strokeOpacity={0.14} strokeDasharray="3 4" vertical={sideways} horizontal={!sideways} />;
  const tooltip = (
    <Tooltip
      content={<Tip series={series} />}
      cursor={section.kind === "bars" ? { fill: "hsl(var(--primary) / 0.06)", radius: 8 } : { stroke: "#64748b", strokeOpacity: 0.3 }}
    />
  );
  const margin = { top: 8, right: 12, bottom: 0, left: sideways ? 4 : -16 };

  let chart;
  if (section.kind === "bars") {
    chart = (
      <BarChart data={data} layout={sideways ? "vertical" : "horizontal"} margin={margin} barCategoryGap={sideways ? "22%" : "28%"}>
        {gradients}
        {grid}
        {sideways ? (
          <XAxis type="number" tick={AXIS} axisLine={false} tickLine={false} tickFormatter={number} />
        ) : (
          <XAxis dataKey={x} tick={AXIS} axisLine={false} tickLine={false} />
        )}
        {sideways ? (
          <YAxis type="category" dataKey={x} tick={<NameTick />} axisLine={false} tickLine={false} width={124} />
        ) : (
          <YAxis tick={AXIS} axisLine={false} tickLine={false} allowDecimals={false} />
        )}
        {tooltip}
        {series.map((s) => (
          <ChartBar
            key={s.key}
            dataKey={s.key}
            name={s.label}
            stackId={stack}
            fill={`url(#${gid}-${s.key})`}
            radius={sideways ? [2, 6, 6, 2] : [6, 6, 2, 2]}
            maxBarSize={sideways ? 18 : 40}
          />
        ))}
      </BarChart>
    );
  } else if (section.kind === "area") {
    chart = (
      <AreaChart data={data} margin={margin}>
        {gradients}
        {grid}
        <XAxis dataKey={x} tick={AXIS} axisLine={false} tickLine={false} />
        <YAxis tick={AXIS} axisLine={false} tickLine={false} tickFormatter={number} />
        {tooltip}
        {series.map((s) => (
          <Area key={s.key} type="monotone" dataKey={s.key} name={s.label} stackId={stack} stroke={s.color} strokeWidth={2} fill={`url(#${gid}-${s.key})`} />
        ))}
      </AreaChart>
    );
  } else {
    chart = (
      <LineChart data={data} margin={margin}>
        {grid}
        <XAxis dataKey={x} tick={AXIS} axisLine={false} tickLine={false} />
        <YAxis tick={AXIS} axisLine={false} tickLine={false} domain={["auto", "auto"]} tickFormatter={number} />
        {tooltip}
        {series.map((s) => (
          <Line
            key={s.key}
            type="monotone"
            dataKey={s.key}
            name={s.label}
            stroke={s.color}
            strokeWidth={2.2}
            dot={{ r: 2.5, fill: s.color, strokeWidth: 0 }}
            activeDot={{ r: 4 }}
          />
        ))}
      </LineChart>
    );
  }
  return (
    <div className="w-full">
      <div className="h-[220px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          {chart}
        </ResponsiveContainer>
      </div>
      {series.length > 1 ? (
        <div className="mt-1 flex flex-wrap justify-center gap-3 text-[11px] text-muted-foreground">
          {series.map((s) => (
            <span key={s.key} className="inline-flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-sm" style={{ background: s.color }} /> {s.label}
            </span>
          ))}
        </div>
      ) : null}
    </div>
  );
}

function Donut({ section }: { section: Of<"donut"> }) {
  const total = section.data.reduce((n, d) => n + d.value, 0);
  return (
    <div className="flex flex-col items-center gap-5 sm:flex-row">
      <div className="relative h-44 w-44 shrink-0">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={section.data}
              dataKey="value"
              nameKey="label"
              innerRadius="70%"
              outerRadius="100%"
              paddingAngle={2}
              cornerRadius={4}
              stroke="none"
              isAnimationActive={false}
            >
              {section.data.map((d) => (
                <Cell key={d.label} fill={d.color} />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center">
          <div className="font-display text-2xl font-medium leading-none tabular-nums">{section.center.value}</div>
          <div className="mt-1 text-[11px] text-muted-foreground">{section.center.label}</div>
        </div>
      </div>
      <ul className="w-full min-w-0 space-y-2.5">
        {section.data.map((d) => (
          <li key={d.label}>
            <div className="flex items-center justify-between gap-3 text-xs">
              <span className="flex min-w-0 items-center gap-1.5">
                <span className="h-2.5 w-2.5 shrink-0 rounded-sm" style={{ background: d.color }} />
                <span className="truncate">{d.label}</span>
              </span>
              <span className="shrink-0 tabular-nums text-muted-foreground">
                <span className="font-medium text-foreground">{formatInt(d.value)}</span> · {total ? Math.round((d.value / total) * 100) : 0}%
              </span>
            </div>
            <div className="mt-1">
              <Bar share={total ? d.value / total : 0} color={d.color} />
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function StatusChip({ text }: { text: string }) {
  const status = WORDS[text.toLowerCase()];
  const color = status ? STATUS[status].color : "#94A3B8";
  return (
    <span
      className="inline-flex items-center gap-1 whitespace-nowrap rounded-full px-2 py-0.5 text-[11px] font-medium"
      style={{ background: rgba(color, 0.12), color }}
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: color }} />
      {text}
    </span>
  );
}

function SampleTable({ section }: { section: Of<"table"> }) {
  return (
    <div className="overflow-x-auto border-t border-border/60">
      <table className="w-full text-sm">
        <thead>
          <tr className="text-left text-[11px] uppercase tracking-wide text-muted-foreground">
            {section.columns.map((c) => (
              <th key={c.key} className="whitespace-nowrap px-3 py-2 font-medium first:pl-6 last:pr-6">
                {c.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {section.rows.map((row, i) => (
            <tr key={i} className="border-t border-border/50 transition-colors hover:bg-muted/30">
              {section.columns.map((c) => {
                const text = row[c.key] ?? "";
                return (
                  <td
                    key={c.key}
                    className={cn(
                      "px-3 py-2.5 align-middle first:pl-6 last:pr-6",
                      c.kind === "mono" && "whitespace-nowrap font-mono text-xs",
                      c.kind === "muted" && "whitespace-nowrap text-xs text-muted-foreground",
                    )}
                  >
                    {c.kind === "status" ? <StatusChip text={text} /> : text}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function StatusCards({ section }: { section: Of<"cards"> }) {
  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
      {section.items.map((item) => {
        const status = STATUS[item.status];
        return (
          <div key={item.title} className="relative overflow-hidden rounded-xl border bg-background/40 p-3.5" style={{ borderColor: rgba(status.color, 0.3) }}>
            <span
              className="absolute inset-x-0 top-0 h-0.5"
              style={{ background: `linear-gradient(90deg, ${status.color}, transparent 80%)` }}
              aria-hidden="true"
            />
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="truncate font-mono text-sm font-medium">{item.title}</div>
                <div className="truncate text-[11px] text-muted-foreground">{item.subtitle}</div>
              </div>
              <span
                className="inline-flex shrink-0 items-center gap-1 rounded-full px-1.5 py-0.5 text-[10px] font-medium"
                style={{ background: rgba(status.color, 0.12), color: status.color }}
              >
                <span className="h-1.5 w-1.5 rounded-full" style={{ background: status.color }} />
                {status.label}
              </span>
            </div>
            <dl className="mt-3 space-y-1.5 text-xs">
              {item.facts.map((f) => (
                <div key={f.label} className="flex items-baseline justify-between gap-3">
                  <dt className="truncate text-muted-foreground">{f.label}</dt>
                  <dd className="shrink-0 font-medium tabular-nums">{f.value}</dd>
                </div>
              ))}
            </dl>
          </div>
        );
      })}
    </div>
  );
}

function Timeline({ section }: { section: Of<"timeline"> }) {
  return (
    <ol className="relative space-y-4 pl-6 before:absolute before:bottom-2 before:left-[6px] before:top-2 before:w-px before:bg-border">
      {section.items.map((item) => {
        const color = STATUS[item.status].color;
        return (
          <li key={item.title} className="relative">
            <span
              className="absolute -left-6 top-1 h-3.5 w-3.5 rounded-full border-2 border-card"
              style={{ background: color, boxShadow: `0 0 0 3px ${rgba(color, 0.18)}` }}
              aria-hidden="true"
            />
            <div className="flex flex-wrap items-baseline justify-between gap-x-3">
              <span className="text-sm font-medium">{item.title}</span>
              <span className="text-[11px] text-muted-foreground">{item.when}</span>
            </div>
            <p className="mt-0.5 text-xs text-muted-foreground">{item.detail}</p>
          </li>
        );
      })}
    </ol>
  );
}

function Meters({ section }: { section: Of<"meters"> }) {
  return (
    <ul className="space-y-3.5">
      {section.items.map((m) => (
        <li key={m.label}>
          <div className="flex items-baseline justify-between gap-3 text-xs">
            <span className="min-w-0 truncate font-medium">{m.label}</span>
            <span className="shrink-0 font-medium tabular-nums" style={{ color: m.color }}>
              {m.value}%
            </span>
          </div>
          <div className="mt-1.5">
            <Bar share={m.value / 100} color={m.color} />
          </div>
          <div className="mt-1 text-[11px] text-muted-foreground">{m.detail}</div>
        </li>
      ))}
    </ul>
  );
}
