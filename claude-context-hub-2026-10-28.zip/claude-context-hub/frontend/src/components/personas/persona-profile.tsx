import { AlertCircle, ArrowDownRight, ArrowRight, ArrowUpRight, ChevronDown, Clock, Share2, Sparkles, Target, Wrench } from "lucide-react";
import { useState, type ReactNode } from "react";
import { Link, useNavigate } from "react-router-dom";

import type { KpiValue } from "@/api/types";
import { STATUS_LABEL, formatKpi, formatTarget, statusVariant, summariseKpis } from "@/components/personas/kpi-tiles";
import { SectionCard } from "@/components/personas/persona-shell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useAnalystReport, useEngineeringKpis, usePlatformReport, useQualityReport } from "@/hooks/queries";
import { EMPTY_PROFILE, PERSONA_PROFILES, TREND_WINDOWS, WINDOWED_KPIS, type GoalSource, type PersonaGoal } from "@/lib/persona-profiles";
import { formatDateTime } from "@/lib/format";
import { PERSONAS, type Persona } from "@/lib/personas";
import { cn } from "@/lib/utils";

type KpiMap = Map<string, KpiValue>;
type BySource = Record<GoalSource, KpiMap | undefined>;

function byKey(groups: Array<{ kpis: KpiValue[] }> | undefined): KpiMap | undefined {
  return groups ? new Map(groups.flatMap((g) => g.kpis).map((k) => [k.key, k] as const)) : undefined;
}

/** Fetches only the reports this persona's goals use, plus the longer baseline for trends. */
function useGoalKpis(goals: PersonaGoal[]): { now: BySource; base: BySource } {
  const needs = (src: GoalSource) => goals.some((g) => g.source === src);
  const trends = (src: GoalSource) => goals.some((g) => g.source === src && WINDOWED_KPIS.has(g.kpi));
  const w = TREND_WINDOWS;
  const eng = useEngineeringKpis(w.engineering.now, { enabled: needs("engineering") });
  const engBase = useEngineeringKpis(w.engineering.base, { enabled: trends("engineering") });
  const qa = useQualityReport(w.quality.now, { enabled: needs("quality") });
  const qaBase = useQualityReport(w.quality.base, { enabled: trends("quality") });
  const plat = usePlatformReport(w.platform.now, { enabled: needs("platform") });
  const platBase = usePlatformReport(w.platform.base, { enabled: trends("platform") });
  const ba = useAnalystReport(w.analyst.now, { enabled: needs("analyst") });
  const baBase = useAnalystReport(w.analyst.base, { enabled: trends("analyst") });
  return {
    now: { engineering: byKey(eng.data?.groups), quality: byKey(qa.data?.groups), platform: byKey(plat.data?.groups), analyst: byKey(ba.data?.groups) },
    base: {
      engineering: byKey(engBase.data?.groups),
      quality: byKey(qaBase.data?.groups),
      platform: byKey(platBase.data?.groups),
      analyst: byKey(baBase.data?.groups),
    },
  };
}

/** Some KPIs report a bare ISO timestamp as their detail; show it as a readable date. */
function readableDetail(detail: string): string {
  const iso = detail.length >= 19 && detail[4] === "-" && detail[10] === "T" && !Number.isNaN(Date.parse(detail));
  return iso ? `as of ${formatDateTime(detail)}` : detail;
}

function windowText(source: GoalSource, size: number): string {
  return source === "platform" ? `last ${size} hours` : `last ${size} days`;
}

function Trend({ goal, kpi, base }: { goal: PersonaGoal; kpi: KpiValue; base: KpiValue | undefined }) {
  if (!WINDOWED_KPIS.has(goal.kpi)) {
    return (
      <span
        className="shrink-0 text-[11px] text-muted-foreground"
        title="Measured as it is now. The hub does not keep this KPI's history yet, so there is no trend."
      >
        snapshot
      </span>
    );
  }
  const w = TREND_WINDOWS[goal.source];
  if (!base) return <span className="shrink-0 text-[11px] text-muted-foreground">{w.label}</span>;
  if (kpi.value === null || base.value === null) {
    return (
      <span className="shrink-0 text-[11px] text-muted-foreground" title={`No data in the ${windowText(goal.source, w.base)} to compare with.`}>
        no baseline
      </span>
    );
  }
  const diff = kpi.value - base.value;
  const title = `${windowText(goal.source, w.now)}: ${formatKpi(kpi)}. ${windowText(goal.source, w.base)}: ${formatKpi(base)}.`;
  if (Math.abs(diff) / Math.max(Math.abs(base.value), 1) < 0.01) {
    return (
      <span className="inline-flex shrink-0 items-center gap-1 text-[11px] text-muted-foreground" title={title}>
        <ArrowRight className="h-3 w-3" /> steady {w.label}
      </span>
    );
  }
  const better = kpi.direction === "higher" ? diff > 0 : diff < 0;
  const Icon = diff > 0 ? ArrowUpRight : ArrowDownRight;
  return (
    <span className={cn("inline-flex shrink-0 items-center gap-1 text-[11px]", better ? "text-success" : "text-destructive")} title={title}>
      <Icon className="h-3 w-3" />
      {better ? "better" : "worse"} {w.label} ({formatKpi(base)})
    </span>
  );
}

const BAR_TONE: Record<KpiValue["status"], string> = {
  ok: "bg-success",
  warn: "bg-warning",
  bad: "bg-destructive",
  info: "bg-muted-foreground/60",
  na: "bg-muted-foreground/40",
};

/** Value against target, for percentages only. */
function GoalBar({ kpi }: { kpi: KpiValue }) {
  if (kpi.unit !== "percent" || kpi.value === null) return null;
  const value = Math.min(100, Math.max(0, kpi.value));
  const target = kpi.target === null ? null : Math.min(100, Math.max(0, kpi.target));
  return (
    <div className="relative mt-2 h-1.5 rounded-full bg-muted">
      <div className={cn("h-full rounded-full", BAR_TONE[kpi.status])} style={{ width: `${value}%` }} />
      {target !== null ? (
        <div
          className="absolute -top-0.5 h-2.5 w-0.5 rounded bg-foreground/70"
          style={{ left: `calc(${target}% - 1px)` }}
          title={formatTarget(kpi) ?? undefined}
        />
      ) : null}
    </div>
  );
}

function GoalRow({ goal, kpi, base }: { goal: PersonaGoal; kpi: KpiValue | undefined; base: KpiValue | undefined }) {
  if (!kpi) {
    return (
      <li className="px-5 py-3">
        <div className="text-sm font-medium">{goal.kpi}</div>
        <p className="mt-0.5 text-xs text-muted-foreground">
          {goal.why} Not reported by the {goal.source} report.
        </p>
      </li>
    );
  }
  return (
    <li className="px-5 py-3">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
            <span className="text-sm font-medium">{kpi.label}</span>
            <Badge variant={statusVariant(kpi.status)} className="h-4 px-1 text-[10px]">
              {STATUS_LABEL[kpi.status]}
            </Badge>
          </div>
          <p className="mt-0.5 text-xs text-muted-foreground">{goal.why}</p>
        </div>
        <div className="shrink-0 text-right">
          <div className="text-lg font-semibold leading-tight tabular-nums">{formatKpi(kpi)}</div>
          <div className="text-[11px] text-muted-foreground">{formatTarget(kpi) ?? "no target"}</div>
        </div>
      </div>
      <GoalBar kpi={kpi} />
      <div className="mt-1.5 flex items-center justify-between gap-3">
        <span className="min-w-0 truncate text-[11px] text-muted-foreground" title={kpi.detail}>
          {readableDetail(kpi.detail)}
        </span>
        <Trend goal={goal} kpi={kpi} base={base} />
      </div>
    </li>
  );
}

function Heading({ icon: Icon, children }: { icon: typeof Target; children: ReactNode }) {
  return (
    <span className="inline-flex items-center gap-2">
      <Icon className="h-4 w-4 text-primary" />
      {children}
    </span>
  );
}

/**
 * Who the persona is and how they are doing: role, ownership, goals bound to live KPIs,
 * a typical day, pain points, sample Genie questions, hand-offs and tools.
 * `allKpis` adds a "Show all KPIs" disclosure under the goals.
 */
export function PersonaProfile({ persona, allKpis }: { persona: Persona; allKpis?: ReactNode }) {
  const profile = PERSONA_PROFILES[persona.key] ?? EMPTY_PROFILE;
  const navigate = useNavigate();
  const { now, base } = useGoalKpis(profile.goals);
  const [showAll, setShowAll] = useState(false);
  const rows = profile.goals.map((goal) => ({ goal, report: now[goal.source], kpi: now[goal.source]?.get(goal.kpi), base: base[goal.source]?.get(goal.kpi) }));
  const loaded = rows.every((r) => r.report !== undefined);
  const verdicts = summariseKpis(rows.flatMap((r) => (r.kpi ? [r.kpi] : [])));

  return (
    <div className="space-y-4">
      <Card className="surface p-5">
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-5">
          <div className="lg:col-span-3">
            <div className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">Role</div>
            <p className="mt-1 text-sm leading-relaxed">{profile.role}</p>
          </div>
          <div className="lg:col-span-2">
            <div className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">Owns</div>
            <div className="mt-1.5 flex flex-wrap gap-1.5">
              {profile.owns.map((o) => (
                <Badge key={o} variant="outline" className="font-normal">
                  {o}
                </Badge>
              ))}
            </div>
          </div>
        </div>
      </Card>

      <section className="grid grid-cols-1 gap-4 lg:grid-cols-5">
        <SectionCard
          className="lg:col-span-3"
          title={<Heading icon={Target}>Goals</Heading>}
          description="Live targets from the hub's own reports. Change a target with ECH_KPI_TARGET_* in .env."
          actions={
            loaded ? (
              <div className="flex shrink-0 flex-wrap justify-end gap-1">
                {verdicts.ok ? <Badge variant="success">{verdicts.ok} on target</Badge> : null}
                {verdicts.warn ? <Badge variant="warning">{verdicts.warn} watch</Badge> : null}
                {verdicts.bad ? <Badge variant="destructive">{verdicts.bad} off target</Badge> : null}
              </div>
            ) : null
          }
        >
          {loaded ? (
            <ul className="divide-y border-t">
              {rows.map((r) => (
                <GoalRow key={`${r.goal.source}.${r.goal.kpi}`} goal={r.goal} kpi={r.kpi} base={r.base} />
              ))}
            </ul>
          ) : (
            <div className="space-y-2 px-5 pb-5">
              {profile.goals.map((g) => (
                <Skeleton key={g.kpi} className="h-14 w-full" />
              ))}
            </div>
          )}
          {allKpis ? (
            <div className="border-t px-3 py-2">
              <Button variant="ghost" size="sm" className="text-xs" aria-expanded={showAll} onClick={() => setShowAll((v) => !v)}>
                {showAll ? "Hide all KPIs" : "Show all KPIs"}
                <ChevronDown className={cn("ml-1 h-3.5 w-3.5 transition-transform", showAll && "rotate-180")} />
              </Button>
            </div>
          ) : null}
        </SectionCard>

        <SectionCard
          className="lg:col-span-2"
          title={<Heading icon={Clock}>A typical day</Heading>}
          description="Where the time goes, and where in the hub it happens."
        >
          <ol className="space-y-3 px-5 pb-5">
            {profile.day.map((d) => (
              <li key={d.when} className="flex gap-3">
                <span className="w-11 shrink-0 pt-px font-mono text-xs text-muted-foreground">{d.when}</span>
                <span className="border-l pl-3 text-sm">{d.what}</span>
              </li>
            ))}
          </ol>
        </SectionCard>
      </section>

      {allKpis && showAll ? <section aria-label="All KPIs">{allKpis}</section> : null}

      <section className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
        <SectionCard title={<Heading icon={AlertCircle}>Pain points</Heading>}>
          <ul className="space-y-2 px-5 pb-5">
            {profile.painPoints.map((p) => (
              <li key={p} className="flex gap-2 text-sm">
                <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-muted-foreground" />
                <span>{p}</span>
              </li>
            ))}
          </ul>
        </SectionCard>

        <SectionCard title={<Heading icon={Sparkles}>Ask Genie</Heading>} description="Click to ask in this persona's Genie space.">
          <div className="flex flex-col gap-2 px-5 pb-5">
            {profile.questions.map((q) => (
              <button
                key={q}
                type="button"
                onClick={() => navigate(`${persona.path}/ask`, { state: { question: q } })}
                className="rounded-lg border bg-background/40 px-3 py-2 text-left text-sm transition-colors hover:border-primary/50 hover:bg-primary/5"
              >
                {q}
              </button>
            ))}
          </div>
        </SectionCard>

        <SectionCard title={<Heading icon={Share2}>Hand-offs</Heading>} description="Who picks up the work next.">
          <ul className="space-y-2 px-5 pb-5">
            {profile.handoffs.map((h) => {
              const to = PERSONAS[h.to];
              const Icon = to.icon;
              return (
                <li key={h.to}>
                  <Link to={to.path} className="group flex gap-3 rounded-lg p-1.5 -mx-1.5 hover:bg-muted/60">
                    <Icon className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground group-hover:text-primary" />
                    <span className="min-w-0">
                      <span className="block text-sm font-medium">{to.label}</span>
                      <span className="block text-xs text-muted-foreground">{h.what}</span>
                    </span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </SectionCard>

        <SectionCard title={<Heading icon={Wrench}>Tools</Heading>} description="Where the work gets done.">
          <ul className="space-y-1 px-5 pb-5">
            {profile.tools.map((t) => (
              <li key={t.to}>
                <Link to={t.to} className="group flex items-start gap-2 rounded-lg p-1.5 -mx-1.5 hover:bg-muted/60">
                  <span className="min-w-0 flex-1">
                    <span className="block text-sm font-medium group-hover:text-primary">{t.label}</span>
                    <span className="block text-xs text-muted-foreground">{t.why}</span>
                  </span>
                  <ArrowUpRight className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground group-hover:text-primary" />
                </Link>
              </li>
            ))}
          </ul>
        </SectionCard>
      </section>
    </div>
  );
}
