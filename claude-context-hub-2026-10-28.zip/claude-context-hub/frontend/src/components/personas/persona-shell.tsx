import {
  Activity,
  BrainCircuit,
  Bug,
  CalendarClock,
  Columns3,
  Container,
  Fingerprint,
  GitPullRequestArrow,
  KeyRound,
  ListTodo,
  PackageCheck,
  Rocket,
  UsersRound,
  BookA,
  BookOpen,
  Boxes,
  Cable,
  ChartColumnBig,
  Earth,
  Gauge,
  HardDrive,
  HeartPulse,
  LayoutDashboard,
  Layers,
  ListChecks,
  Orbit,
  Server,
  ShieldAlert,
  ShieldCheck,
  Siren,
  Sparkles,
  Target,
  Waypoints,
  Workflow,
  type LucideIcon,
} from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { Link } from "react-router-dom";

import { HeroFlow, PageHero } from "@/components/layout/page-hero";
import { ViewSwitcher } from "@/components/layout/view-switcher";
import { KindBadge } from "@/components/semantic/badges";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Companion } from "@/components/personas/companion";
import { PERSONA_LIST, type Persona, type PersonaKey } from "@/lib/personas";
import { cn } from "@/lib/utils";

interface Flow {
  title: string;
  source: { label: string; caption: string };
  targets: { label: string; caption: string; icon: LucideIcon }[];
  footer: string;
}

const FLOWS: Record<PersonaKey, Flow> = {
  data_engineer: {
    title: "From a ticket to a validated pipeline.",
    source: { label: "Jira request", caption: "what is needed, in plain words" },
    targets: [
      { label: "Model", caption: "Silver & Gold, dry-run read-only", icon: Layers },
      { label: "Pipeline", caption: "code and tests, run once approved", icon: Workflow },
      { label: "Validated", caption: "checks, lineage and impact", icon: ListChecks },
    ],
    footer: "You approve every step that writes.",
  },
  business_analyst: {
    title: "Governed definitions. Plain answers.",
    source: { label: "Metric views", caption: "declared on the platform" },
    targets: [
      { label: "Metrics catalog", caption: "what each number means", icon: ShieldCheck },
      { label: "Glossary", caption: "business terms across datasets", icon: BookOpen },
      { label: "Genie", caption: "answers in business language", icon: Sparkles },
    ],
    footer: "Certified where it is declared. Flagged where it is not.",
  },
  qa_engineer: {
    title: "Evidence first. Then the release.",
    source: { label: "Runs · catalog · audit", caption: "what actually happened" },
    targets: [
      { label: "Quality gates", caption: "targets with verdicts", icon: ListChecks },
      { label: "Failures", caption: "runs, documents, requests", icon: ShieldAlert },
      { label: "Genie", caption: "checks as SQL assertions", icon: Sparkles },
    ],
    footer: "Green means measured, not assumed.",
  },
  architect: {
    title: "Many platforms. One model.",
    source: { label: "Platforms", caption: "Databricks · Snowflake · sources" },
    targets: [
      { label: "Business model", caption: "subject areas and stars", icon: Boxes },
      { label: "Integrations", caption: "every way in and out", icon: Cable },
      { label: "Genie", caption: "design trade-offs, cited", icon: Sparkles },
    ],
    footer: "Conformed where it is shared. Owned where it is declared.",
  },
  sre: {
    title: "Know what is broken. Before anyone asks.",
    source: { label: "Services", caption: "ingestion · query · stores" },
    targets: [
      { label: "SLOs", caption: "latency, errors, budget", icon: Gauge },
      { label: "Capacity", caption: "rows, bytes, vectors", icon: HardDrive },
      { label: "Runs", caption: "stalled, failed, pending", icon: Activity },
    ],
    footer: "Symptom, cause, fix, verification.",
  },
  devops: {
    title: "Small changes. Shipped often. Restored fast.",
    source: { label: "Repositories", caption: "hub · lakehouse pipelines" },
    targets: [
      { label: "CI/CD", caption: "build, test, scan, sign", icon: GitPullRequestArrow },
      { label: "Environments", caption: "dev · staging · prod", icon: Container },
      { label: "Deployments", caption: "frequency, lead time", icon: Rocket },
    ],
    footer: "Sample data until CI is connected.",
  },
  devsecops: {
    title: "Secure by default. Verified on every change.",
    source: { label: "Code & images", caption: "repos · containers · IaC" },
    targets: [
      { label: "Vulnerabilities", caption: "CVEs with fixes", icon: Bug },
      { label: "Secrets", caption: "found, rotated", icon: KeyRound },
      { label: "Supply chain", caption: "SBOM, signatures", icon: PackageCheck },
    ],
    footer: "Sample data until scanners are connected.",
  },
  data_steward: {
    title: "Meaning, owned and approved.",
    source: { label: "Glossary", caption: "terms · suggestions · domains" },
    targets: [
      { label: "Review queue", caption: "approve or reject", icon: ListChecks },
      { label: "Ownership", caption: "owners and stewards", icon: UsersRound },
      { label: "Semantic Hub", caption: "tables by business area", icon: Layers },
    ],
    footer: "Live review numbers, sample stewardship tasks.",
  },
  data_scientist: {
    title: "Governed data in. Trusted models out.",
    source: { label: "Semantic Hub", caption: "certified tables and columns" },
    targets: [
      { label: "Features", caption: "fresh, point-in-time", icon: Columns3 },
      { label: "Models", caption: "registry and stages", icon: BrainCircuit },
      { label: "Monitoring", caption: "accuracy and drift", icon: Activity },
    ],
    footer: "Sample registry until one is connected.",
  },
  compliance: {
    title: "Controlled. Evidenced. On time.",
    source: { label: "Controls", caption: "SOX · GDPR · Solvency II" },
    targets: [
      { label: "Testing", caption: "passed, failed, due", icon: ShieldCheck },
      { label: "Privacy", caption: "PII by table", icon: Fingerprint },
      { label: "Filings", caption: "deadlines and feeds", icon: CalendarClock },
    ],
    footer: "Sample control data until a GRC tool is connected.",
  },
};

interface PersonaShellProps {
  persona: Persona;
  active: string;
  /** The chat tab manages its own scrolling; everything else scrolls as a page. */
  fill?: boolean;
  actions?: ReactNode;
  children: ReactNode;
}

const TAB_ICONS: Record<string, LucideIcon> = {
  overview: LayoutDashboard,
  pipelines: Workflow,
  health: HeartPulse,
  lineage: Waypoints,
  metrics: ChartColumnBig,
  glossary: BookA,
  domains: Boxes,
  gates: ShieldCheck,
  failures: Siren,
  review: ListChecks,
  landscape: Earth,
  model: Orbit,
  integrations: Cable,
  services: Server,
  slos: Target,
  capacity: Gauge,
  observability: Activity,
  deployments: Rocket,
  delivery: GitPullRequestArrow,
  environments: Container,
  vulnerabilities: Bug,
  secrets: KeyRound,
  supply: PackageCheck,
  stewardship: ListTodo,
  ownership: UsersRound,
  models: BrainCircuit,
  datamodels: Layers,
  features: Columns3,
  controls: ShieldCheck,
  privacy: Fingerprint,
  filings: CalendarClock,
  ask: Sparkles,
};

/** Hero + the persona's pill tabs; each tab is a route so it can be bookmarked and linked. */
export function PersonaShell({ persona, active, fill, actions, children }: PersonaShellProps) {
  const flow = FLOWS[persona.key];
  const heroActions = (
    <div className="flex flex-wrap items-center gap-2">
      {actions}
      <PersonaSwitcher current={persona.key} />
    </div>
  );
  // One row: the copy on the left, the flow drawn horizontally on the right, so the tabs and
  // the workspace stay in view without scrolling.
  const hero = (
    <PageHero
      slim
      eyebrow={`Persona · ${persona.label}`}
      icon={persona.icon}
      title={persona.label}
      lead={persona.tagline}
      sub={persona.description}
      actions={heroActions}
      aside={<HeroFlow layout="row" title={flow.title} icon={persona.icon} source={flow.source} targets={flow.targets} footer={flow.footer} />}
    />
  );
  const tabs = (
    <ViewSwitcher
      size="md"
      label={`${persona.label} sections`}
      value={active}
      views={persona.tabs.map((tab) => ({ key: tab.key, label: tab.label, icon: TAB_ICONS[tab.key] ?? LayoutDashboard, to: `${persona.path}/${tab.key}` }))}
    />
  );

  if (fill) {
    // The chat needs the height: a one-row banner, and the page scrolls on short screens
    // instead of squeezing the conversation into a strip.
    return (
      <div className="flex min-h-0 flex-1 flex-col overflow-y-auto">
        <div className="shrink-0 space-y-3 px-6 pt-5">
          <PageHero slim eyebrow={`Persona · ${persona.label}`} icon={persona.icon} title={persona.label} lead={persona.tagline} actions={heroActions} />
          {tabs}
        </div>
        <div className="flex min-h-[34rem] flex-1 flex-col px-6 pb-6 pt-4">{children}</div>
      </div>
    );
  }
  return (
    <div className="min-h-0 flex-1 overflow-auto p-6">
      <div className="space-y-4">
        {hero}
        {tabs}
      </div>
      <div className="mt-6">{children}</div>
    </div>
  );
}

/** The other workspaces as their companions, plus the hub; sits in the hero of every persona page. */
function PersonaSwitcher({ current }: { current: PersonaKey }) {
  return (
    <div className="flex items-center gap-1 rounded-full border border-border/80 bg-background/50 p-1 pl-2.5 backdrop-blur" title="Switch workspace">
      <Link to="/personas" className="mr-1 text-[11px] font-medium text-muted-foreground hover:text-foreground">
        All personas
      </Link>
      {PERSONA_LIST.filter((p) => p.key !== current).map((p) => (
        <Link key={p.key} to={p.path} title={`${p.label} workspace`} className="rounded-full transition-transform hover:-translate-y-0.5">
          <Companion persona={p.key} size="1.9rem" interactive={false} />
        </Link>
      ))}
    </div>
  );
}

export function SectionCard({
  title,
  description,
  actions,
  children,
  className,
}: {
  title: ReactNode;
  description?: ReactNode;
  actions?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <Card className={cn("surface", className)}>
      <CardHeader className="flex-row items-start justify-between space-y-0">
        <div>
          <CardTitle className="text-sm">{title}</CardTitle>
          {description ? <CardDescription>{description}</CardDescription> : null}
        </div>
        {actions}
      </CardHeader>
      <CardContent className="p-0">{children}</CardContent>
    </Card>
  );
}

/** A dataset reference that opens the Semantic Hub detail. */
export function AssetLink({ id, fqn, name, kind }: { id: string; fqn: string; name?: string; kind?: string }) {
  return (
    <span className="inline-flex max-w-full items-center gap-1.5">
      <Link to={`/semantic/${id}`} className="truncate font-mono text-xs hover:underline" title={fqn}>
        {name ?? fqn}
      </Link>
      {kind ? <KindBadge kind={kind} /> : null}
    </span>
  );
}

export function EmptyRow({ children, colSpan }: { children: ReactNode; colSpan: number }) {
  return (
    <tr>
      <td colSpan={colSpan} className="px-4 py-8 text-center text-sm text-muted-foreground">
        {children}
      </td>
    </tr>
  );
}

/** Trailing-edge debounce for search boxes. */
export function useDebounced(value: string, ms = 250): string {
  const [debounced, setDebounced] = useState(value.trim());
  useEffect(() => {
    const timer = window.setTimeout(() => setDebounced(value.trim()), ms);
    return () => window.clearTimeout(timer);
  }, [value, ms]);
  return debounced;
}
