import { createElement, useState } from "react";

import { PersonaIcon3D } from "@/components/personas/persona-icon-3d";
import { PERSONA_GENIE } from "@/lib/persona-genie";
import { PERSONA_LIST, type PersonaKey } from "@/lib/personas";
import { cn } from "@/lib/utils";

export type CompanionMood = "idle" | "listening" | "thinking" | "happy" | "sad" | "sleeping";

interface CompanionProps {
  persona?: PersonaKey;
  mood?: CompanionMood;
  /** Rendered size: pixels, or any CSS length such as "11rem" (the drawing is square). */
  size?: number | string;
  /** Speech bubble text; nothing is shown when null. */
  say?: string | null;
  /** Where the bubble sits: beside the icon, or above it anchored to its left or right edge. */
  bubble?: "right" | "top-left" | "top-right";
  onPoke?: () => void;
  /** False renders a plain figure (no button), for use inside links and cards. */
  interactive?: boolean;
  /** True keeps it from bobbing; for small avatars repeated down a list. */
  still?: boolean;
  className?: string;
}

/**
 * The workspace's companion, drawn as its 3D icon (Genie's own when no persona is given). It bobs gently, lifts
 * while you type, sways with thinking dots while Genie works, hops when an answer lands, droops on an error and
 * dims with a few z's when no model is configured. Click it to make it hop and offer a tip.
 */
export function Companion({ persona, mood = "idle", size = 120, say = null, bubble = "right", onPoke, interactive = true, still = false, className }: CompanionProps) {
  const [hop, setHop] = useState(false);
  const [hover, setHover] = useState(false);
  const length = typeof size === "number" ? `${size}px` : size;
  const name = persona ? (PERSONA_LIST.find((p) => p.key === persona)?.label ?? PERSONA_GENIE[persona].petName) : "Genie";
  const [h] = persona ? PERSONA_GENIE[persona].color : [172];
  const ink = `hsl(${h} 45% 30%)`;
  const shown: CompanionMood = hop ? "happy" : mood;

  const poke = () => {
    setHop(true);
    window.setTimeout(() => setHop(false), 900);
    onPoke?.();
  };

  return (
    <div className={cn("companion relative inline-block select-none", still && "companion-still", className)} style={{ width: length, height: length }}>
      {say ? (
        <div key={say} role="status" className={cn("companion-bubble", `companion-bubble-${bubble}`)}>
          {say}
        </div>
      ) : null}
      {createElement(
        interactive ? "button" : "div",
        {
          ...(interactive
            ? { type: "button", onClick: poke, "aria-label": `${name} companion, ${mood}. Click for a tip.`, title: `${name} · click for a tip` }
            : { "aria-hidden": true }),
          onMouseEnter: () => setHover(true),
          onMouseLeave: () => setHover(false),
          className: cn("companion-3d relative block h-full w-full rounded-2xl focus:outline-none focus-visible:ring-2 focus-visible:ring-ring", `companion-${shown}`),
        },
        <>
          <span className="companion-float absolute inset-0 flex items-end justify-center" style={{ transformOrigin: "50% 100%" }}>
            <PersonaIcon3D persona={persona} size={`calc(${length} * 0.82)`} active={hover || mood === "listening" || hop} />
          </span>
          <MoodMarks mood={shown} ink={ink} />
        </>,
      )}
    </div>
  );
}

/** What the mood adds around the icon: thinking dots, z's, sparkles or a drop, drawn on a 120-unit square. */
function MoodMarks({ mood, ink }: { mood: CompanionMood; ink: string }) {
  if (mood !== "thinking" && mood !== "sleeping" && mood !== "happy" && mood !== "sad") return null;
  return (
    <svg viewBox="0 0 120 120" className="pointer-events-none absolute inset-0 h-full w-full overflow-visible" aria-hidden="true">
      {mood === "thinking" ? (
        <g className="companion-dots" fill={ink} opacity="0.8">
          <circle cx="98" cy="20" r="4" />
          <circle cx="108" cy="12" r="4.5" style={{ animationDelay: "0.15s" }} />
          <circle cx="118" cy="4" r="5" style={{ animationDelay: "0.3s" }} />
        </g>
      ) : null}
      {mood === "sleeping" ? (
        <g className="companion-zzz" fill={ink} fontFamily="ui-sans-serif, system-ui, sans-serif" fontWeight="700">
          <text x="96" y="24" fontSize="14">
            z
          </text>
          <text x="105" y="14" fontSize="12" style={{ animationDelay: "0.7s" }}>
            z
          </text>
          <text x="113" y="5" fontSize="10" style={{ animationDelay: "1.4s" }}>
            z
          </text>
        </g>
      ) : null}
      {mood === "happy" ? (
        <g className="companion-sparkle" fill="hsl(45 95% 58%)">
          <path d="M104 10 l2.6 6.4 6.4 2.6 -6.4 2.6 -2.6 6.4 -2.6 -6.4 -6.4 -2.6 6.4 -2.6z" />
          <path d="M10 26 l1.9 4.6 4.6 1.9 -4.6 1.9 -1.9 4.6 -1.9 -4.6 -4.6 -1.9 4.6 -1.9z" style={{ animationDelay: "0.35s" }} />
          <path d="M112 50 l1.4 3.4 3.4 1.4 -3.4 1.4 -1.4 3.4 -1.4 -3.4 -3.4 -1.4 3.4 -1.4z" style={{ animationDelay: "0.6s" }} />
        </g>
      ) : null}
      {mood === "sad" ? <path className="companion-drop" d="M100 22 q5 7 0 12 q-5 -5 0 -12z" fill="hsl(200 85% 62%)" /> : null}
    </svg>
  );
}
