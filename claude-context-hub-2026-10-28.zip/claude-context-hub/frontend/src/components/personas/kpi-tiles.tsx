import type { KpiTarget, KpiValue } from "@/api/types";
import { EmptyRow } from "@/components/personas/persona-shell";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatInt } from "@/lib/format";
import { cn } from "@/lib/utils";

/** Verdict styling shared by every scorecard (Data Engineer KPIs, QA gates, SRE SLOs). */
export const STATUS_TONE: Record<KpiValue["status"], string> = {
  ok: "border-success/40 bg-success/5",
  warn: "border-warning/50 bg-warning/5",
  bad: "border-destructive/50 bg-destructive/5",
  info: "border-border bg-card",
  na: "border-dashed bg-card",
};

export const STATUS_LABEL: Record<KpiValue["status"], string> = { ok: "on target", warn: "watch", bad: "off target", info: "no target", na: "no data" };

export function formatKpi(k: KpiValue): string {
  if (k.value === null) return "–";
  switch (k.unit) {
    case "percent":
      return `${k.value.toFixed(k.value % 1 === 0 ? 0 : 1)}%`;
    case "hours":
      return `${k.value.toFixed(1)} h`;
    case "seconds":
      return k.value >= 120 ? `${(k.value / 60).toFixed(1)} min` : `${k.value.toFixed(0)} s`;
    case "ms":
      return k.value >= 1000 ? `${(k.value / 1000).toFixed(2)} s` : `${k.value.toFixed(0)} ms`;
    case "per_minute":
      return `${k.value.toFixed(1)}/min`;
    default:
      return formatInt(k.value);
  }
}

export function targetUnit(unit: KpiTarget["unit"]): string {
  return unit === "percent" ? "%" : unit === "hours" ? " h" : unit === "seconds" ? " s" : unit === "ms" ? " ms" : "";
}

export function formatTarget(k: KpiValue): string | null {
  if (k.target === null) return null;
  const sign = k.direction === "higher" ? "≥" : "≤";
  return `target ${sign} ${k.target}${targetUnit(k.unit)}`;
}

export function statusVariant(status: KpiValue["status"]): "success" | "warning" | "destructive" | "muted" {
  return status === "ok" ? "success" : status === "warn" ? "warning" : status === "bad" ? "destructive" : "muted";
}

export function KpiTile({ kpi }: { kpi: KpiValue }) {
  const target = formatTarget(kpi);
  return (
    <div className={cn("rounded-lg border p-3", STATUS_TONE[kpi.status])} title={kpi.detail}>
      <div className="flex items-start justify-between gap-2">
        <span className="text-xs text-muted-foreground">{kpi.label}</span>
        <Badge variant={statusVariant(kpi.status)} className="h-4 shrink-0 px-1 text-[10px]">
          {STATUS_LABEL[kpi.status]}
        </Badge>
      </div>
      <div className="mt-1 text-2xl font-semibold tabular-nums leading-tight">{formatKpi(kpi)}</div>
      <div className="mt-1 truncate text-[11px] text-muted-foreground">{target ?? kpi.detail}</div>
      {target && kpi.detail ? <div className="truncate text-[11px] text-muted-foreground">{kpi.detail}</div> : null}
    </div>
  );
}

/** Count of verdicts across groups, for the line next to a window picker. */
export function summariseKpis(kpis: KpiValue[]): Record<KpiValue["status"], number> {
  return kpis.reduce(
    (acc, k) => {
      acc[k.status] += 1;
      return acc;
    },
    { ok: 0, warn: 0, bad: 0, info: 0, na: 0 } as Record<KpiValue["status"], number>,
  );
}

export function KpiSummaryLine({ kpis, suffix }: { kpis: KpiValue[]; suffix?: string }) {
  const s = summariseKpis(kpis);
  return (
    <span className="text-xs text-muted-foreground">
      <span className="text-success">{s.ok} on target</span> · <span className="text-warning">{s.warn} to watch</span> ·{" "}
      <span className="text-destructive">{s.bad} off target</span>
      {suffix ? ` · ${suffix}` : ""}
    </span>
  );
}

/** One row per target: active value, default and the environment variable that overrides it. */
export function TargetsTable({ targets }: { targets: KpiTarget[] | undefined }) {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>KPI</TableHead>
          <TableHead className="text-right">Target</TableHead>
          <TableHead className="text-right">Default</TableHead>
          <TableHead>Variable</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {targets?.map((t) => (
          <TableRow key={t.key}>
            <TableCell className="text-xs">{t.label}</TableCell>
            <TableCell className="text-right font-mono text-xs">
              {t.direction === "higher" ? "≥" : "≤"} {t.value}
              {targetUnit(t.unit)}
              {t.overridden ? (
                <Badge variant="info" className="ml-2 h-4 px-1 text-[10px]">
                  custom
                </Badge>
              ) : null}
            </TableCell>
            <TableCell className="text-right font-mono text-xs text-muted-foreground">
              {t.default}
              {targetUnit(t.unit)}
            </TableCell>
            <TableCell className="font-mono text-[11px] text-muted-foreground">{t.env_var}</TableCell>
          </TableRow>
        ))}
        {targets && targets.length === 0 ? <EmptyRow colSpan={4}>No targets configured.</EmptyRow> : null}
      </TableBody>
    </Table>
  );
}
