import {
  Activity,
  BadgeCheck,
  BookCheck,
  Boxes,
  BrainCircuit,
  Bug,
  ChartColumnBig,
  ClipboardCheck,
  Database,
  DraftingCompass,
  FlaskConical,
  Gauge,
  InfinityIcon,
  KeyRound,
  Rocket,
  Scale,
  SearchCheck,
  ShieldCheck,
  Sparkles,
  Tag,
  Workflow,
  type LucideIcon,
} from "lucide-react";
import type { CSSProperties } from "react";

import { NEUTRAL_COLOR, PERSONA_GENIE } from "@/lib/persona-genie";
import type { PersonaKey } from "@/lib/personas";
import { cn } from "@/lib/utils";

/** Each workspace as an object: the main glyph on the tile and the tool on its badge. */
const GLYPHS: Record<PersonaKey, { glyph: LucideIcon; badge: LucideIcon }> = {
  data_engineer: { glyph: Database, badge: Workflow },
  business_analyst: { glyph: ChartColumnBig, badge: SearchCheck },
  qa_engineer: { glyph: ClipboardCheck, badge: Bug },
  architect: { glyph: Boxes, badge: DraftingCompass },
  sre: { glyph: Gauge, badge: Activity },
  devops: { glyph: InfinityIcon, badge: Rocket },
  devsecops: { glyph: ShieldCheck, badge: KeyRound },
  data_steward: { glyph: BookCheck, badge: Tag },
  data_scientist: { glyph: FlaskConical, badge: BrainCircuit },
  compliance: { glyph: Scale, badge: BadgeCheck },
};

interface PersonaIcon3DProps {
  persona?: PersonaKey;
  /** Rendered width: any CSS length; the drawing keeps its proportions. */
  size?: string;
  /** Lifted and turned towards the viewer, as when its card is hovered. */
  active?: boolean;
  className?: string;
}

/**
 * A workspace's icon as a small 3D object: an extruded, lit tile in the persona's colour with its glyph floating
 * above the face and a badge for the tool it leans on. Drawn in CSS (see .p3d in index.css), so it themes and scales.
 */
export function PersonaIcon3D({ persona, size = "3.5rem", active = false, className }: PersonaIcon3DProps) {
  const [h, s, l] = persona ? PERSONA_GENIE[persona].color : NEUTRAL_COLOR;
  // Without a persona it is Genie's own icon.
  const Glyph = persona ? GLYPHS[persona].glyph : Sparkles;
  const Badge = persona ? GLYPHS[persona].badge : null;
  const style = { "--p3d-size": size, "--p3d-h": h, "--p3d-s": `${s}%`, "--p3d-l": `${l}%` } as CSSProperties;
  return (
    <span className={cn("p3d", active && "is-active", className)} style={style} aria-hidden="true">
      <span className="p3d-floor" />
      <span className="p3d-body">
        <span className="p3d-face">
          <span className="p3d-gloss" />
        </span>
        <Glyph className="p3d-glyph" strokeWidth={2.1} />
        {Badge ? (
          <span className="p3d-badge">
            <Badge strokeWidth={2.4} />
          </span>
        ) : null}
      </span>
    </span>
  );
}
