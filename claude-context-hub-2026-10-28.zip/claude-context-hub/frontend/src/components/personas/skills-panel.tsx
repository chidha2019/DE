import { ArrowRight, type LucideIcon } from "lucide-react";
import { Link } from "react-router-dom";

import type { KpiValue } from "@/api/types";
import { Badge } from "@/components/ui/badge";

export type SkillTone = "default" | "success" | "warning" | "destructive";

export interface Skill {
  name: string;
  /** One line on what the engineer can do with it. */
  meaning: string;
  /** Where in the console it happens. */
  to: string;
  icon: LucideIcon;
  /** Live evidence, when the hub has a number for it. */
  status?: { label: string; tone?: SkillTone } | null;
}

export interface SkillFamily {
  label: string;
  blurb: string;
  icon: LucideIcon;
  skills: Skill[];
}

/** A KPI verdict as a badge tone; no target or no data is neutral. */
export function kpiTone(k: KpiValue | undefined): SkillTone {
  if (!k || k.status === "na" || k.status === "info") return "default";
  return k.status === "ok" ? "success" : k.status === "warn" ? "warning" : "destructive";
}

const BADGE: Record<SkillTone, "muted" | "success" | "warning" | "destructive"> = {
  default: "muted",
  success: "success",
  warning: "warning",
  destructive: "destructive",
};

/** What a workspace can do, as families of skills with live evidence; every row opens the place that does it. */
export function SkillsPanel({ families, title = "Skills", description }: { families: SkillFamily[]; title?: string; description?: string }) {
  const total = families.reduce((n, f) => n + f.skills.length, 0);
  return (
    <section>
      <div className="mb-3 flex flex-wrap items-end justify-between gap-2">
        <div>
          <h2 className="font-display text-lg font-medium">
            {title} <span className="text-muted-foreground">· {total}</span>
          </h2>
          {description ? <p className="text-xs text-muted-foreground">{description}</p> : null}
        </div>
      </div>
      <div className="tile-grid">
        {families.map((family) => (
          <div key={family.label} className="surface flex flex-col p-4">
            <div className="flex items-center gap-2.5">
              <span className="icon-tile h-9 w-9">
                <family.icon className="h-4 w-4" />
              </span>
              <div className="min-w-0">
                <div className="text-sm font-medium">{family.label}</div>
                <div className="truncate text-[11px] text-muted-foreground">{family.blurb}</div>
              </div>
            </div>
            <ul className="mt-2 divide-y divide-border/60">
              {family.skills.map((skill) => (
                <li key={skill.name}>
                  <Link to={skill.to} className="group flex items-start gap-2.5 py-2.5 text-muted-foreground transition-colors hover:text-foreground">
                    <skill.icon className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-xs font-medium text-foreground">{skill.name}</span>
                        {skill.status ? (
                          <Badge variant={BADGE[skill.status.tone ?? "default"]} className="h-4 px-1 text-[10px] font-normal">
                            {skill.status.label}
                          </Badge>
                        ) : null}
                      </div>
                      <div className="text-[11px] leading-snug">{skill.meaning}</div>
                    </div>
                    <ArrowRight className="mt-1 h-3.5 w-3.5 shrink-0 opacity-0 transition-all group-hover:translate-x-0.5 group-hover:opacity-100" />
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </section>
  );
}
