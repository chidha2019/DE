import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Activity, BellRing, CheckCircle2, ExternalLink, FileText, Gauge, LayoutDashboard, RefreshCw, ShieldAlert, Siren } from "lucide-react";
import { Link } from "react-router-dom";

import { observabilityApi } from "@/api/endpoints";
import type { DashboardProvisionResult, GrafanaAlertRule, GrafanaDashboardSummary } from "@/api/types";
import { MetricCard } from "@/components/dashboard/metric-card";
import { SectionCard } from "@/components/personas/persona-shell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatInt, formatRelative } from "@/lib/format";
import { cn } from "@/lib/utils";

/** Grafana, read live every 30 s; not configured is a normal answer, not an error. */
export function useGrafanaObservability() {
  return useQuery({ queryKey: ["observability", "grafana"], queryFn: observabilityApi.grafana, refetchInterval: 30_000 });
}

const STATE: Record<string, { label: string; cls: string; dot: string }> = {
  firing: { label: "Firing", cls: "border-destructive/40 bg-destructive/10 text-destructive", dot: "animate-pulse-dot bg-destructive" },
  pending: { label: "Pending", cls: "border-warning/40 bg-warning/10 text-warning", dot: "bg-warning" },
  error: { label: "Error", cls: "border-destructive/40 bg-destructive/10 text-destructive", dot: "bg-destructive" },
  nodata: { label: "No data", cls: "border-warning/40 bg-warning/10 text-warning", dot: "bg-warning" },
  inactive: { label: "Normal", cls: "border-success/40 bg-success/10 text-success", dot: "bg-success" },
  normal: { label: "Normal", cls: "border-success/40 bg-success/10 text-success", dot: "bg-success" },
};

function StateBadge({ state }: { state: string }) {
  const s = STATE[state] ?? { label: state, cls: "border-border bg-muted/60 text-muted-foreground", dot: "bg-muted-foreground/50" };
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[10px] font-medium", s.cls)}>
      <span className={cn("h-1.5 w-1.5 rounded-full", s.dot)} aria-hidden="true" />
      {s.label}
    </span>
  );
}

function Empty({ children }: { children: string }) {
  return <div className="rounded-xl border border-dashed border-border/80 px-3 py-6 text-center text-xs text-muted-foreground">{children}</div>;
}

function OpenLink({ href, label = "Open" }: { href: string | null; label?: string }) {
  if (!href) return null;
  return (
    <a href={href} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-xs text-primary hover:underline">
      {label} <ExternalLink className="h-3 w-3" />
    </a>
  );
}

function ConnectGrafana({ reason, documents }: { reason: string | null; documents: number }) {
  return (
    <div className="surface relative overflow-hidden p-6">
      <div className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-[hsl(28_95%_54%)]/20 blur-3xl" aria-hidden="true" />
      <div className="relative flex flex-wrap items-start gap-5">
        <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border text-white" style={{ background: "linear-gradient(135deg, hsl(28 95% 54%), hsl(28 95% 54% / 0.62))", borderColor: "hsl(28 95% 54% / 0.5)" }}>
          <Activity className="h-7 w-7" />
        </span>
        <div className="min-w-0 flex-1">
          <h3 className="font-display text-lg font-medium">Connect Grafana to see alerts and dashboards here</h3>
          <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
            With a read-only service-account token the hub reads your Grafana Cloud stack live: firing and pending alert rules, every dashboard with its folder and tags, and the queries behind them. The same token lets the Grafana connector ingest dashboards and rules so Genie can answer which dashboards use which tables.
          </p>
          <div className="mt-3 flex flex-wrap gap-1">
            {["GRAFANA_URL", "GRAFANA_TOKEN"].map((name) => (
              <code key={name} className="rounded-md border border-border/70 bg-muted/50 px-1.5 py-0.5 font-mono text-[11px]">
                {name}
              </code>
            ))}
          </div>
          <p className="mt-2 text-xs text-muted-foreground">{reason ?? "Set both in the root .env, then restart the query and ingestion services."} Values are read by name and never shown.</p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button size="sm" asChild>
              <Link to="/connectors">Open the connector catalogue</Link>
            </Button>
            <Button size="sm" variant="outline" asChild>
              <a href="https://grafana.com/docs/grafana/latest/administration/service-accounts/" target="_blank" rel="noreferrer">
                Service accounts in Grafana <ExternalLink className="h-3 w-3" />
              </a>
            </Button>
          </div>
          {documents ? <p className="mt-3 text-xs text-muted-foreground">{formatInt(documents)} Grafana documents are already in the hub from an earlier run.</p> : null}
        </div>
      </div>
    </div>
  );
}

/** The hub's own metrics in Grafana: how to ship them (Alloy) and the dashboard the hub can provision. */
function HubMetricsCard({ hubDashboardUrl }: { hubDashboardUrl: string | null }) {
  const qc = useQueryClient();
  const provision = useMutation({
    mutationFn: observabilityApi.provisionDashboard,
    onSuccess: (result: DashboardProvisionResult) => {
      if (result.ok) void qc.invalidateQueries({ queryKey: ["observability", "grafana"] });
    },
  });
  const result = provision.data;
  const url = result?.ok && result.url ? result.url : hubDashboardUrl;
  return (
    <SectionCard title="The hub's own metrics in Grafana" description="Both services export Prometheus metrics; Alloy ships them to your stack and the hub provisions its dashboard.">
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-xl border border-border/60 bg-background/50 p-3">
          <div className="flex items-center gap-2 text-sm font-medium">
            <span className="icon-tile h-8 w-8">
              <Activity className="h-4 w-4" />
            </span>
            Ship metrics with Grafana Alloy
          </div>
          <p className="mt-2 text-xs text-muted-foreground">
            Grafana Cloud cannot scrape a laptop, so an Alloy container pulls <code className="font-mono">/metrics</code> from both services every 15 s and remote-writes them. Set the three values from your stack's Prometheus "Send metrics" page, then start it:
          </p>
          <div className="mt-2 flex flex-wrap gap-1">
            {["GRAFANA_CLOUD_PROM_URL", "GRAFANA_CLOUD_PROM_USER", "GRAFANA_CLOUD_PROM_TOKEN"].map((name) => (
              <code key={name} className="rounded-md border border-border/70 bg-muted/50 px-1.5 py-0.5 font-mono text-[11px]">
                {name}
              </code>
            ))}
          </div>
          <pre className="mt-2 overflow-x-auto rounded-lg border border-border/60 bg-muted/40 px-3 py-2 font-mono text-[11px]">docker compose --profile observability up -d alloy</pre>
        </div>
        <div className="rounded-xl border border-border/60 bg-background/50 p-3">
          <div className="flex items-center gap-2 text-sm font-medium">
            <span className="icon-tile h-8 w-8">
              <Gauge className="h-4 w-4" />
            </span>
            Hub dashboard
            {url ? (
              <Badge variant="success" className="h-4 px-1 text-[9px]">
                provisioned
              </Badge>
            ) : (
              <Badge variant="muted" className="h-4 px-1 text-[9px]">
                not yet
              </Badge>
            )}
          </div>
          <p className="mt-2 text-xs text-muted-foreground">
            Serving, retrieval and ingestion panels over the metrics Alloy ships: request rate, error rate, p95 latency, retrieval stages, embeddings, documents by connector, graph sync. Provisioning creates or updates it by uid and needs a token with the Editor role.
          </p>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <Button size="sm" variant={url ? "outline" : "default"} onClick={() => provision.mutate()} disabled={provision.isPending}>
              <RefreshCw className={cn("h-3.5 w-3.5", provision.isPending && "animate-spin")} /> {url ? "Update dashboard" : "Provision dashboard"}
            </Button>
            {url ? (
              <Button size="sm" variant="ghost" asChild>
                <a href={url} target="_blank" rel="noreferrer">
                  Open in Grafana <ExternalLink className="h-3 w-3" />
                </a>
              </Button>
            ) : null}
          </div>
          {result && !result.ok ? <p className="mt-2 text-xs text-destructive">{result.reason}</p> : null}
          {result?.ok ? <p className="mt-2 text-xs text-success">Dashboard version {result.version ?? "?"} saved.</p> : null}
          {provision.isError ? <p className="mt-2 text-xs text-destructive">The query service did not answer.</p> : null}
        </div>
      </div>
    </SectionCard>
  );
}

function AlertRow({ rule }: { rule: GrafanaAlertRule }) {
  return (
    <li className="flex items-start gap-3 rounded-xl border border-border/60 bg-background/50 px-3 py-2">
      <span className={cn("icon-tile mt-0.5 h-8 w-8", rule.state === "firing" && "border-destructive/40 bg-destructive/10 text-destructive")}>
        {rule.state === "firing" ? <Siren className="h-4 w-4" /> : <BellRing className="h-4 w-4" />}
      </span>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <span className="truncate text-sm font-medium">{rule.title}</span>
          <StateBadge state={rule.state} />
          {rule.severity ? (
            <Badge variant={rule.severity === "critical" ? "destructive" : "warning"} className="h-4 px-1 text-[9px]">
              {rule.severity}
            </Badge>
          ) : null}
        </div>
        {rule.summary ? <div className="mt-0.5 line-clamp-2 text-xs text-muted-foreground">{rule.summary}</div> : null}
        <div className="mt-1 flex flex-wrap items-center gap-x-3 text-[11px] text-muted-foreground">
          {rule.group ? <span>group {rule.group}</span> : null}
          {rule.active_alerts ? <span>{rule.active_alerts} active instance{rule.active_alerts === 1 ? "" : "s"}</span> : null}
          <OpenLink href={rule.url} label="Open in Grafana" />
        </div>
      </div>
    </li>
  );
}

function DashboardTile({ d }: { d: GrafanaDashboardSummary }) {
  return (
    <a href={d.url ?? "#"} target="_blank" rel="noreferrer" className="group flex items-start gap-2.5 rounded-xl border border-border/60 bg-background/50 px-3 py-2 transition-colors hover:border-primary/40 hover:bg-primary/5">
      <span className="icon-tile mt-0.5 h-8 w-8">
        <LayoutDashboard className="h-4 w-4" />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block truncate text-sm font-medium">{d.title}</span>
        <span className="block truncate text-[11px] text-muted-foreground">{d.folder ?? "General"}{d.tags.length ? ` · ${d.tags.join(", ")}` : ""}</span>
      </span>
      <ExternalLink className="mt-1 h-3.5 w-3.5 shrink-0 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
    </a>
  );
}

/** The SRE workspace's Observability tab: Grafana alerts and dashboards, live. */
export function ObservabilityPanel() {
  const obs = useGrafanaObservability();
  const d = obs.data;

  if (obs.isLoading) {
    return (
      <div className="stat-grid">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-24" />
        ))}
      </div>
    );
  }
  if (obs.isError) return <div className="rounded-xl border border-destructive/40 bg-destructive/10 p-4 text-sm text-destructive">The query service did not answer. Check that it is running, then refresh.</div>;
  if (!d || !d.configured) return <ConnectGrafana reason={d?.reason ?? null} documents={d?.documents ?? 0} />;

  const active = d.alert_rules.filter((r) => r.state === "firing" || r.state === "pending" || r.state === "error" || r.state === "nodata");
  const quiet = d.alert_rules.filter((r) => !active.includes(r));

  return (
    <div className="space-y-6">
      {!d.healthy ? (
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-warning/40 bg-warning/10 p-3 text-sm text-warning">
          <span className="inline-flex items-center gap-2">
            <ShieldAlert className="h-4 w-4" /> Grafana did not answer: {d.reason ?? "unknown error"}
          </span>
          <Button size="sm" variant="outline" onClick={() => void obs.refetch()}>
            <RefreshCw className="h-3.5 w-3.5" /> Retry
          </Button>
        </div>
      ) : null}

      <section className="stat-grid">
        <MetricCard title="Firing" value={formatInt(d.firing)} hint={d.firing ? "needs attention now" : "nothing firing"} icon={Siren} tone={d.firing ? "destructive" : "success"} />
        <MetricCard title="Pending" value={formatInt(d.pending)} hint="above threshold, inside the for-duration" icon={BellRing} tone={d.pending ? "warning" : "default"} />
        <MetricCard title="Alert rules" value={formatInt(d.rules_total)} hint={d.org ? `${d.org}${d.version ? ` · Grafana ${d.version}` : ""}` : undefined} icon={ShieldAlert} />
        <MetricCard title="Dashboards" value={formatInt(d.dashboards.length)} hint={d.url ? d.url.replace(/^https?:\/\//, "") : undefined} icon={LayoutDashboard} />
        <MetricCard title="In the hub" value={formatInt(d.documents)} hint="dashboards and rules ingested for Genie" icon={FileText} tone={d.documents ? "success" : "warning"} />
      </section>

      <div className="grid gap-4 xl:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)]">
        <SectionCard
          title="Alerts needing attention"
          description={`Firing, pending, errored and no-data rules · refreshed ${formatRelative(d.generated_at)}`}
          actions={
            <Button size="sm" variant="ghost" onClick={() => void obs.refetch()} disabled={obs.isFetching}>
              <RefreshCw className={cn("h-3.5 w-3.5", obs.isFetching && "animate-spin")} />
            </Button>
          }
        >
          {active.length ? (
            <ul className="space-y-2">
              {active.map((r) => (
                <AlertRow key={r.uid ?? r.title} rule={r} />
              ))}
            </ul>
          ) : (
            <div className="flex items-center gap-2 rounded-xl border border-success/30 bg-success/5 px-3 py-4 text-sm text-success">
              <CheckCircle2 className="h-4 w-4" /> No alert is firing or pending.
            </div>
          )}
        </SectionCard>

        <SectionCard title="Dashboards" description="Every dashboard on the stack, with folder and tags. Opens in Grafana.">
          {d.dashboards.length ? (
            <div className="grid gap-2" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(14rem, 1fr))" }}>
              {d.dashboards.map((dash) => (
                <DashboardTile key={dash.uid} d={dash} />
              ))}
            </div>
          ) : (
            <Empty>No dashboards on this stack yet.</Empty>
          )}
        </SectionCard>
      </div>

      <HubMetricsCard hubDashboardUrl={d.hub_dashboard_url} />

      <SectionCard title="All alert rules" description="State, severity and folder for every Grafana-managed rule.">
        {d.alert_rules.length ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Rule</TableHead>
                <TableHead>State</TableHead>
                <TableHead>Severity</TableHead>
                <TableHead>Group</TableHead>
                <TableHead>Health</TableHead>
                <TableHead className="text-right">Link</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[...active, ...quiet].map((r) => (
                <TableRow key={r.uid ?? r.title}>
                  <TableCell className="max-w-[24rem]">
                    <div className="truncate font-medium">{r.title}</div>
                    {r.summary ? <div className="truncate text-[11px] text-muted-foreground">{r.summary}</div> : null}
                  </TableCell>
                  <TableCell>
                    <StateBadge state={r.state} />
                  </TableCell>
                  <TableCell className="text-xs">{r.severity ?? "—"}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{r.group ?? "—"}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{r.health ?? "—"}</TableCell>
                  <TableCell className="text-right">
                    <OpenLink href={r.url} />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <Empty>No Grafana-managed alert rules on this stack.</Empty>
        )}
      </SectionCard>

      <p className="text-xs text-muted-foreground">
        Run the Grafana connector from the <Link to="/connectors" className="text-primary hover:underline">connector catalogue</Link> to index these dashboards and rules, with the tables and metrics their queries reference, so Genie can answer which dashboards depend on which data.
      </p>
    </div>
  );
}
