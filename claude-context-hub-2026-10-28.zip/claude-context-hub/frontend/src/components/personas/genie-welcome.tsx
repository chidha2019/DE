import { ArrowRight, Sparkles, Wrench } from "lucide-react";
import { useEffect, useState } from "react";

import type { GenieSpace, GenieStatus } from "@/api/types";
import { Companion } from "@/components/personas/companion";
import { useOverview, useSemanticOverview } from "@/hooks/queries";
import { formatCompact } from "@/lib/format";
import { PERSONA_GENIE, TOOL_ICONS } from "@/lib/persona-genie";
import { PERSONAS, type PersonaKey } from "@/lib/personas";

interface PersonaWelcomeProps {
  persona: PersonaKey;
  space: GenieSpace;
  status: GenieStatus | undefined;
  onAsk: (question: string) => void;
  disabled?: boolean;
}

/** The empty state of a persona's Genie: the companion, what it can do, live context, questions to try. */
export function PersonaWelcome({ persona, space, status, onAsk, disabled }: PersonaWelcomeProps) {
  const meta = PERSONAS[persona];
  const genie = PERSONA_GENIE[persona];
  const semantic = useSemanticOverview();
  const overview = useOverview();
  const [tip, setTip] = useState<number | null>(null);
  const s = semantic.data;
  const o = overview.data;

  // A poked tip stays for a while, then the greeting returns.
  useEffect(() => {
    if (tip === null) return;
    const timer = window.setTimeout(() => setTip(null), 7000);
    return () => window.clearTimeout(timer);
  }, [tip]);

  const say = disabled ? "Zzz… give me a model and I'll wake up." : tip === null ? genie.greeting : (genie.tips[tip % genie.tips.length] ?? genie.greeting);
  const stats: Array<{ label: string; value: number | undefined }> = [
    { label: "assets", value: s?.assets },
    { label: "facts", value: s?.by_kind.fact },
    { label: "dimensions", value: s?.by_kind.dimension },
    { label: "governed metrics", value: s?.declared_metrics },
    { label: "documents", value: o?.documents_total },
    { label: "graph nodes", value: o?.graph_nodes_total },
  ];
  const [h, sat, light] = genie.color;
  const accent = `hsl(${h} ${sat}% ${light}%)`;

  return (
    <div className="min-h-0 flex-1 overflow-y-auto px-6 py-6">
      <div className="mx-auto max-w-7xl space-y-6">
        <section className="surface relative overflow-hidden p-6 md:p-8 lg:p-10">
          <div className="hero-grid pointer-events-none absolute inset-0 opacity-70" />
          <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full opacity-25 blur-3xl" style={{ background: `radial-gradient(circle, ${accent}, transparent 70%)` }} />
          <div className="relative grid gap-6 md:grid-cols-[17rem_1fr] md:items-center">
            <div className="flex justify-center pt-12 md:justify-start">
              <Companion persona={persona} mood={disabled ? "sleeping" : "idle"} size="11rem" say={say} bubble="top-left" onPoke={() => setTip((t) => (t ?? -1) + 1)} />
            </div>
            <div className="min-w-0">
              <p className="text-[10px] font-medium uppercase tracking-[0.16em]" style={{ color: accent }}>
                Meet {genie.petName} · your {meta.label} companion
              </p>
              <h2 className="mt-1 font-display text-2xl font-medium tracking-tight md:text-3xl lg:text-4xl">
                {space.name} Genie<span style={{ color: accent }}>.</span>
              </h2>
              <p className="mt-2 max-w-3xl text-sm text-muted-foreground lg:text-[15px]">{genie.intro}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                {stats.map((st) => (
                  <span key={st.label} className="inline-flex items-baseline gap-1 rounded-full border border-border/80 bg-background/60 px-2.5 py-1 text-xs">
                    <span className="font-semibold tabular-nums">{st.value === undefined ? "…" : formatCompact(st.value)}</span>
                    <span className="text-muted-foreground">{st.label}</span>
                  </span>
                ))}
              </div>
              <div className="mt-3 flex flex-wrap items-center gap-1.5 text-[11px] text-muted-foreground">
                <Wrench className="h-3 w-3" />
                <span>reaches for</span>
                {genie.tools.map((tool) => {
                  const Icon = TOOL_ICONS[tool] ?? Sparkles;
                  return (
                    <span key={tool} className="inline-flex items-center gap-1 rounded-md border border-border/80 bg-card/70 px-1.5 py-0.5 font-mono text-[10px] text-foreground/80">
                      <Icon className="h-3 w-3" style={{ color: accent }} />
                      {tool}
                    </span>
                  );
                })}
              </div>
              {status && !status.configured ? (
                <p className="mt-3 rounded-lg border border-warning/40 bg-warning/10 px-3 py-2 text-xs text-warning">
                  {status.reason ?? "No model is configured. Set DATABRICKS_HOST and DATABRICKS_TOKEN (or ANTHROPIC_API_KEY) for the query service."}
                </p>
              ) : null}
            </div>
          </div>
        </section>

        <section className="tile-grid gap-3">
          {genie.capabilities.map((c) => (
            <div key={c.title} className="surface flex gap-3 p-4 transition-transform hover:-translate-y-0.5">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border" style={{ borderColor: `${accent.slice(0, -1)} / 0.4)`, background: `${accent.slice(0, -1)} / 0.12)`, color: accent }}>
                <c.icon className="h-5 w-5" />
              </div>
              <div className="min-w-0">
                <div className="text-sm font-medium">{c.title}</div>
                <p className="mt-0.5 text-xs text-muted-foreground">{c.detail}</p>
              </div>
            </div>
          ))}
        </section>

        {space.sample_questions.length ? (
          <section>
            <div className="mb-3 flex flex-wrap items-center gap-2">
              <Sparkles className="h-4 w-4" style={{ color: accent }} />
              <h3 className="text-sm font-medium">Try asking</h3>
              <span className="text-xs text-muted-foreground">Click one to send it to {genie.petName}.</span>
            </div>
            <div className="kpi-grid kpi-grid-wide">
              {space.sample_questions.map((q, i) => (
                <button
                  key={q}
                  type="button"
                  disabled={disabled}
                  onClick={() => onAsk(q)}
                  className="surface group flex items-start gap-3 p-4 text-left text-sm transition-all hover:-translate-y-0.5 hover:shadow-glow disabled:opacity-50 disabled:hover:translate-y-0 disabled:hover:shadow-none"
                >
                  <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border text-[11px] font-semibold tabular-nums" style={{ borderColor: `${accent.slice(0, -1)} / 0.5)`, color: accent }}>
                    {i + 1}
                  </span>
                  <span className="min-w-0 flex-1 leading-snug">{q}</span>
                  <ArrowRight className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground opacity-0 transition-all group-hover:translate-x-0.5 group-hover:opacity-100" />
                </button>
              ))}
            </div>
          </section>
        ) : null}
      </div>
    </div>
  );
}
