import { ExternalLink, MessageSquarePlus } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";

import { ChatThread } from "@/components/genie/chat-thread";
import { Composer } from "@/components/genie/composer";
import { Companion, type CompanionMood } from "@/components/personas/companion";
import { PersonaWelcome } from "@/components/personas/genie-welcome";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useGenieSpaces, useGenieStatus } from "@/hooks/queries";
import { useGenieChat } from "@/hooks/use-genie-chat";
import { PERSONA_GENIE, thinkingLine } from "@/lib/persona-genie";
import { PERSONAS, type PersonaKey } from "@/lib/personas";

/** Genie bound to the persona's own space; the conversation stays inside the workspace tab. */
export function PersonaChat({ persona }: { persona: PersonaKey }) {
  const spaces = useGenieSpaces();
  const status = useGenieStatus();
  const location = useLocation();
  const navigate = useNavigate();
  const genie = PERSONA_GENIE[persona];
  const space = spaces.data?.find((s) => s.persona === persona) ?? null;
  const [conversationId, setConversationId] = useState<string | null>(null);
  const chat = useGenieChat(space?.id ?? null, conversationId, { onConversation: (c) => setConversationId(c.id) });

  const configured = status.data?.configured ?? false;
  const showEmpty = chat.messages.length === 0 && !chat.live && !chat.loading;

  // Another tab can hand over a question (`navigate(".../ask", { state: { question } })`).
  const handedOver = (location.state as { question?: string } | null)?.question ?? null;
  const asked = useRef<string | null>(null);
  useEffect(() => {
    if (!handedOver || !space || !configured || asked.current === handedOver) return;
    asked.current = handedOver;
    void chat.ask(handedOver);
    navigate(location.pathname, { replace: true, state: null });
  }, [handedOver, space, configured, chat, navigate, location.pathname]);

  // ---------------------------------------------------------------- the companion's mood
  const [typing, setTyping] = useState(false);
  const [happy, setHappy] = useState(false);
  const [tip, setTip] = useState<number | null>(null);
  const wasPending = useRef(false);

  // Celebrate an answer that arrived while we were waiting (not one loaded from history).
  useEffect(() => {
    if (chat.pending) {
      wasPending.current = true;
      return;
    }
    if (!wasPending.current) return;
    wasPending.current = false;
    if (chat.error) return;
    setHappy(true);
    const timer = window.setTimeout(() => setHappy(false), 4500);
    return () => window.clearTimeout(timer);
  }, [chat.pending, chat.error]);

  useEffect(() => {
    if (tip === null) return;
    const timer = window.setTimeout(() => setTip(null), 7000);
    return () => window.clearTimeout(timer);
  }, [tip]);

  const mood: CompanionMood = !configured ? "sleeping" : chat.pending ? "thinking" : chat.error ? "sad" : happy ? "happy" : typing ? "listening" : "idle";
  const lastStep = chat.live?.steps[chat.live.steps.length - 1];
  const liveText = chat.live?.text ?? "";
  const lastAnswer = [...chat.messages].reverse().find((m) => m.role === "assistant");
  const citations = lastAnswer?.citations.length ?? 0;
  const say = useMemo(() => {
    switch (mood) {
      case "sleeping":
        return "Zzz… no model configured.";
      case "thinking":
        if (lastStep && !lastStep.done) return thinkingLine(lastStep.tool);
        return liveText ? "Writing it up…" : "Thinking…";
      case "sad":
        return "Oops. That one went wrong; the thread has the details.";
      case "happy":
        return citations ? `Done — ${citations} source${citations === 1 ? "" : "s"} cited.` : "Done!";
      case "listening":
        return "I'm listening…";
      default:
        return tip === null ? null : (genie.tips[tip % genie.tips.length] ?? null);
    }
  }, [mood, lastStep, liveText, citations, tip, genie.tips]);

  if (spaces.isLoading) return <Skeleton className="h-64 w-full" />;
  if (!space) {
    return (
      <div className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">
        The {PERSONAS[persona].label} Genie space is missing. Apply the migrations (docker compose build migrate, then docker compose run --rm migrate) to create it.
      </div>
    );
  }

  const label = PERSONAS[persona].label;
  const article = /^[aeiou]/i.test(label) ? "an" : "a";

  return (
    <div className="flex min-h-0 flex-1 flex-col overflow-hidden rounded-2xl border border-border/80 bg-card/80 backdrop-blur">
      <div className="flex items-center justify-between gap-3 border-b border-border/80 px-4 py-2 text-xs text-muted-foreground">
        <div className="flex min-w-0 items-center gap-2">
          <Companion persona={persona} mood={mood} size="1.875rem" className="shrink-0" />
          <span className="truncate">
            <span className="font-medium text-foreground">{genie.petName}</span> · {space.name} space · {space.description}
          </span>
        </div>
        <div className="flex shrink-0 gap-1">
          {conversationId ? (
            <Button variant="ghost" size="sm" onClick={() => setConversationId(null)}>
              <MessageSquarePlus className="h-3.5 w-3.5" /> New chat
            </Button>
          ) : null}
          <Button variant="ghost" size="sm" asChild>
            <Link to={conversationId ? `/genie/${conversationId}` : "/genie"}>
              <ExternalLink className="h-3.5 w-3.5" /> Open in Genie
            </Link>
          </Button>
        </div>
      </div>
      {showEmpty ? (
        <PersonaWelcome persona={persona} space={space} status={status.data} onAsk={chat.ask} disabled={!configured} />
      ) : (
        <div className="relative flex min-h-0 flex-1 flex-col">
          <ChatThread messages={chat.messages} live={chat.live} error={chat.error} onAsk={chat.ask} persona={persona} />
          <div className="pointer-events-none absolute bottom-3 right-5 z-10 hidden md:block">
            <div className="pointer-events-auto">
              <Companion persona={persona} mood={mood} size="5.5rem" say={say} bubble="top-right" onPoke={() => setTip((t) => (t ?? -1) + 1)} />
            </div>
          </div>
        </div>
      )}
      <Composer
        onSend={chat.ask}
        onStop={chat.stop}
        pending={chat.pending}
        disabled={!configured}
        disabledReason={status.data?.reason ?? "Genie has no model configured"}
        placeholder={`Ask ${genie.petName} as ${article} ${label.toLowerCase()}…`}
        onActivity={setTyping}
      />
    </div>
  );
}
