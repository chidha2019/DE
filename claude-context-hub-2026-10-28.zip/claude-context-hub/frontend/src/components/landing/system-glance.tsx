import { Cable, Clock, Database, Network, Server, Sparkles, type LucideIcon } from "lucide-react";
import type { ReactNode } from "react";

import { BrandMark } from "@/components/connectors/brand-mark";
import { useConnectors, useEngineeringKpis, useGenieStatus, useOverview, usePlatformReport, useSemanticOverview, useServiceHealth } from "@/hooks/queries";
import { formatBytes, formatCompact, formatInt, formatRelative } from "@/lib/format";
import { rgba } from "@/lib/tones";
import { cn } from "@/lib/utils";

type Tone = "ok" | "warn" | "bad" | "na";

const DOT: Record<Tone, string> = {
  ok: "bg-success",
  warn: "bg-warning",
  bad: "bg-destructive",
  na: "bg-muted-foreground/40",
};

function Dot({ tone, pulse }: { tone: Tone; pulse?: boolean }) {
  return <span className={cn("inline-block h-1.5 w-1.5 shrink-0 rounded-full", DOT[tone], pulse && tone === "ok" && "animate-pulse-dot")} aria-hidden="true" />;
}

function Tile({ icon: Icon, title, tone, color, children }: { icon: LucideIcon; title: string; tone: Tone; color: string; children: ReactNode }) {
  return (
    <div
      className="group relative overflow-hidden rounded-2xl border bg-card/70 p-3 transition-shadow hover:shadow-md short:p-2.5"
      style={{ borderColor: rgba(color, 0.22) }}
    >
      <span
        className="pointer-events-none absolute -right-10 -top-12 h-28 w-28 rounded-full opacity-20 blur-2xl transition-opacity group-hover:opacity-40"
        style={{ background: color }}
        aria-hidden="true"
      />
      <div className="relative flex items-center gap-2">
        <span
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl text-white"
          style={{ background: `linear-gradient(145deg, ${rgba(color, 0.72)}, ${color})`, boxShadow: `0 8px 18px -10px ${color}` }}
          aria-hidden="true"
        >
          <Icon className="h-4 w-4" />
        </span>
        <span className="text-sm font-medium">{title}</span>
        <span className="ml-auto">
          <Dot tone={tone} pulse />
        </span>
      </div>
      <div className="relative mt-2 space-y-1 short:mt-1.5 short:space-y-0.5">{children}</div>
    </div>
  );
}

const RING: Record<Tone, string> = { ok: "#10B981", warn: "#F59E0B", bad: "#EF4444", na: "#94A3B8" };

/** The share of health checks passing, as a ring with the count inside. */
function HealthRing({ passing, total, tone }: { passing: number; total: number; tone: Tone }) {
  const r = 20;
  const c = 2 * Math.PI * r;
  const share = total ? passing / total : 0;
  const color = RING[tone];
  return (
    <span className="relative flex h-14 w-14 shrink-0 items-center justify-center short:h-12 short:w-12">
      <svg viewBox="0 0 48 48" className="absolute inset-0 -rotate-90" aria-hidden="true">
        <circle cx="24" cy="24" r={r} fill="none" stroke={rgba(color, 0.15)} strokeWidth="4.5" />
        <circle
          cx="24"
          cy="24"
          r={r}
          fill="none"
          stroke={color}
          strokeWidth="4.5"
          strokeLinecap="round"
          strokeDasharray={`${(share * c).toFixed(2)} ${c.toFixed(2)}`}
          className="transition-all duration-700"
        />
      </svg>
      <span className="font-display text-sm font-medium tabular-nums">{total ? `${passing}/${total}` : "…"}</span>
    </span>
  );
}

function Big({ value, label }: { value: string; label: string }) {
  return (
    <div>
      <div className="font-display text-xl font-medium leading-tight tabular-nums">{value}</div>
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</div>
    </div>
  );
}

function Line({ children }: { children: ReactNode }) {
  return <div className="truncate text-xs text-muted-foreground">{children}</div>;
}

/** Is everything up, and how big is it: services, connectors, stores, models and the catalog sync, live. */
export function SystemGlance() {
  const ingestion = useServiceHealth("ingestion");
  const query = useServiceHealth("query");
  const connectors = useConnectors();
  const kpis = useEngineeringKpis(7);
  const overview = useOverview();
  const platform = usePlatformReport(24);
  const genie = useGenieStatus();
  const semantic = useSemanticOverview();

  const o = overview.data;
  const p = platform.data;
  const s = semantic.data;
  const g = genie.data;
  const freshness = new Map((kpis.data?.connectors ?? []).map((c) => [c.connector, c] as const));
  const services = [
    { label: "Ingestion", q: ingestion },
    { label: "Query", q: query },
  ];
  const checks = services.flatMap((sv) => (sv.q.data ? [sv.q.data.status === "ok", ...Object.values(sv.q.data.checks)] : []));
  const passing = checks.filter(Boolean).length;
  const servicesTone: Tone = services.some((sv) => sv.q.isError)
    ? "bad"
    : services.every((sv) => sv.q.data?.status === "ok")
      ? "ok"
      : services.some((sv) => sv.q.data)
        ? "warn"
        : "na";
  const connectorList = connectors.data ?? [];
  const connectorsTone: Tone = !connectors.data ? "na" : connectorList.length === 0 ? "warn" : connectorList.every((c) => c.healthy) ? "ok" : "warn";
  const pending = o?.documents_graph_pending ?? 0;
  const syncAgeH = s?.last_synced_at ? (Date.now() - new Date(s.last_synced_at).getTime()) / 36e5 : null;
  const syncTone: Tone = syncAgeH === null ? "na" : syncAgeH <= 24 ? "ok" : syncAgeH <= 72 ? "warn" : "bad";
  const overallTone: Tone = servicesTone === "bad" ? "bad" : servicesTone === "ok" && connectorsTone === "ok" ? "ok" : servicesTone === "na" ? "na" : "warn";

  return (
    <div className="glance surface relative overflow-hidden p-4 sm:p-5 short:p-4">
      <div className="hero-grid pointer-events-none absolute inset-0 opacity-40" aria-hidden="true" />
      <div className="pointer-events-none absolute -right-20 -top-24 h-56 w-56 rounded-full bg-primary/15 blur-3xl" aria-hidden="true" />
      <div className="relative">
        <header className="flex flex-wrap items-center gap-3">
          <HealthRing passing={passing} total={checks.length} tone={overallTone} />
          <div className="min-w-0 flex-1">
            <div className="text-[10px] font-medium uppercase tracking-[0.2em] text-primary">System at a glance</div>
            <div className="font-display text-lg font-medium leading-tight">
              {!checks.length
                ? "Checking the services…"
                : overallTone === "ok"
                  ? "All systems operational"
                  : overallTone === "bad"
                    ? "A service needs attention"
                    : "Up, with something to watch"}
            </div>
            <div className="text-[11px] text-muted-foreground short:hidden">
              Is everything up, and how big is it? Live health checks, stores, models and the last sync.
            </div>
          </div>
        </header>

        <div className="glance-tiles mt-4 short:mt-3 short:gap-2">
          <Tile icon={Server} title="Services" color="#0EA5E9" tone={servicesTone}>
            {services.map((sv) => {
              const h = sv.q.data;
              const tone: Tone = sv.q.isError ? "bad" : !h ? "na" : h.status === "ok" ? "ok" : "warn";
              return (
                <div key={sv.label} className="flex flex-wrap items-center justify-between gap-x-2 text-xs">
                  <span className="flex min-w-0 items-center gap-1.5">
                    <Dot tone={tone} />
                    <span className="truncate">
                      {sv.label} {h ? <span className="text-muted-foreground">v{h.version}</span> : null}
                    </span>
                  </span>
                  <span className="flex shrink-0 items-center gap-2 text-[10px] text-muted-foreground">
                    {sv.q.isError ? (
                      <span className="text-destructive">unreachable</span>
                    ) : h ? (
                      Object.entries(h.checks).map(([name, ok]) => (
                        <span key={name} className="inline-flex items-center gap-1">
                          <Dot tone={ok ? "ok" : "bad"} />
                          {name}
                        </span>
                      ))
                    ) : (
                      "checking…"
                    )}
                  </span>
                </div>
              );
            })}
          </Tile>

          <Tile icon={Cable} title="Connectors" color="#8B5CF6" tone={connectorsTone}>
            {connectorList.map((c) => {
              const f = freshness.get(c.name);
              return (
                <div key={c.name} className="flex flex-wrap items-center justify-between gap-x-2 text-xs">
                  <span className="flex min-w-0 items-center gap-1.5">
                    <BrandMark icon={c.source_system} size="xs" />
                    <span className="truncate">{c.display_name}</span>
                    <Dot tone={c.healthy ? "ok" : "bad"} />
                  </span>
                  <span className="shrink-0 text-[10px] text-muted-foreground">
                    {f?.last_success_at ? `last run ${formatRelative(f.last_success_at)}` : "no run yet"}
                    {f && f.failed ? <span className="text-destructive"> · {f.failed} failed</span> : null}
                  </span>
                </div>
              );
            })}
            {connectors.data && connectorList.length === 0 ? <Line>No connectors configured.</Line> : null}
            {!connectors.data ? <Line>checking…</Line> : null}
          </Tile>

          <Tile icon={Database} title="Postgres + pgvector" color="#3B82F6" tone={p ? "ok" : "na"}>
            <Big value={p ? formatBytes(p.database_bytes) : "…"} label="on disk" />
            <Line>{o ? `${formatCompact(o.documents_total)} documents · ${formatCompact(o.chunks_total)} chunks` : "…"}</Line>
            <Line>{o ? `${formatCompact(o.embeddings_total)} vectors · ${o.vector_dimensions} dims` : "…"}</Line>
          </Tile>

          <Tile icon={Network} title="Neo4j graph" color="#14B8A6" tone={!o ? "na" : pending ? "warn" : "ok"}>
            <Big value={o ? formatCompact(o.graph_nodes_total) : "…"} label="nodes" />
            <Line>{o ? `${formatCompact(o.graph_edges_total)} edges` : "…"}</Line>
            <Line>{o ? (pending ? `${formatInt(pending)} documents pending sync` : "in sync with Postgres") : "…"}</Line>
          </Tile>

          <Tile icon={Sparkles} title="Models" color="#EC4899" tone={!g ? "na" : g.configured ? "ok" : "warn"}>
            <Line>
              <span className="text-foreground">Genie</span> ·{" "}
              {g ? (g.configured ? `${g.model}${g.provider ? ` via ${g.provider}` : ""}` : (g.reason ?? "not configured")) : "…"}
            </Line>
            <Line>
              <span className="text-foreground">Embeddings</span> · {o ? `${o.embedding_model} · ${o.vector_dimensions} dims` : "…"}
            </Line>
          </Tile>

          <Tile icon={Clock} title="Catalog sync" color="#10B981" tone={syncTone}>
            <Big value={s?.last_synced_at ? formatRelative(s.last_synced_at) : "…"} label="last sync" />
            <Line>{s ? `${formatInt(s.assets)} assets · ${formatInt(s.relationships)} relationships` : "…"}</Line>
            <Line>{o ? (o.runs_active ? `${o.runs_active} run(s) active now` : "no run active") : "…"}</Line>
          </Tile>
        </div>
      </div>
    </div>
  );
}
