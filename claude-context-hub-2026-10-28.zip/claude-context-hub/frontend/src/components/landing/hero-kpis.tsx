import { ArrowUpRight, FileText, Layers, MessageSquare, Network, ShieldCheck, Workflow, type LucideIcon } from "lucide-react";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { Link } from "react-router-dom";

import type { RunActivityPoint } from "@/api/types";
import { Bar, Ring, Sparkline } from "@/components/landing/kpi-cards";
import { CompositionBar, kindSegments } from "@/components/semantic/visuals";
import { useArchitectureReport, useGenieSpaces, useOverview, useSemanticOverview } from "@/hooks/queries";
import { formatCompact, formatInt, formatRelative } from "@/lib/format";
import { rgba } from "@/lib/tones";

/** Counts up from zero the first time a value arrives, then follows refetches directly. */
function useCountUp(target: number | undefined, duration = 1100): number | undefined {
  const [value, setValue] = useState<number | undefined>(undefined);
  const started = useRef(false);
  useEffect(() => {
    if (target === undefined) return;
    if (started.current) {
      setValue(target);
      return;
    }
    started.current = true;
    const t0 = performance.now();
    let frame = 0;
    const tick = (now: number) => {
      const p = Math.min(1, (now - t0) / duration);
      setValue(Math.round(target * (1 - Math.pow(1 - p, 3))));
      if (p < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [target, duration]);
  return value;
}

interface HeroKpiProps {
  icon: LucideIcon;
  color: string;
  label: string;
  value: number | undefined;
  suffix?: string;
  caption: ReactNode;
  visual: ReactNode;
  to: string;
}

/** One number the hub holds, counted up on arrival, with a small picture of what is behind it. */
function HeroKpi({ icon: Icon, color, label, value, suffix, caption, visual, to }: HeroKpiProps) {
  const shown = useCountUp(value);
  return (
    <Link
      to={to}
      className="group relative flex min-w-0 flex-col overflow-hidden rounded-2xl border bg-card/80 p-4 shadow-sm backdrop-blur transition-all duration-300 hover:-translate-y-1 hover:shadow-xl short:p-3"
      style={{ borderColor: rgba(color, 0.25) }}
    >
      <span
        className="pointer-events-none absolute -bottom-16 -right-12 h-40 w-40 rounded-full opacity-20 blur-3xl transition-opacity duration-300 group-hover:opacity-50"
        style={{ background: color }}
        aria-hidden="true"
      />
      <span
        className="absolute inset-x-4 top-0 h-[3px] rounded-b-full"
        style={{ background: `linear-gradient(90deg, ${color}, ${rgba(color, 0)})` }}
        aria-hidden="true"
      />
      <div className="relative flex items-start justify-between gap-2">
        <span className="text-[10px] font-medium uppercase tracking-[0.18em] text-muted-foreground">{label}</span>
        <span
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-white transition-transform duration-300 group-hover:rotate-[-6deg] group-hover:scale-110 short:h-7 short:w-7"
          style={{ background: `linear-gradient(145deg, ${rgba(color, 0.7)}, ${color})`, boxShadow: `0 10px 24px -12px ${color}` }}
          aria-hidden="true"
        >
          <Icon className="h-[18px] w-[18px]" />
        </span>
      </div>
      <div className="relative mt-1 font-display text-4xl font-medium leading-none tracking-tight tabular-nums short:text-3xl">
        {shown === undefined ? <span className="inline-block h-8 w-16 animate-pulse rounded-lg bg-muted align-middle" /> : formatCompact(shown)}
        {suffix && shown !== undefined ? <span className="ml-1.5 align-baseline text-sm font-normal text-muted-foreground">{suffix}</span> : null}
      </div>
      <div className="relative mt-3 min-h-[2.25rem] short:mt-2 short:min-h-[1.75rem]">{visual}</div>
      <div className="relative mt-auto flex items-end justify-between gap-2 pt-2 text-[11px] leading-snug text-muted-foreground short:pt-1.5">
        <span className="line-clamp-2 min-w-0">{caption}</span>
        <ArrowUpRight className="h-3.5 w-3.5 shrink-0 opacity-0 transition-opacity group-hover:opacity-100" style={{ color }} />
      </div>
    </Link>
  );
}

/** What the hub knows, in six numbers: documents, catalog, governed metrics, graph, Genie and pipeline runs. */
export function HeroKpis({ pulse }: { pulse: RunActivityPoint[] | undefined }) {
  const overview = useOverview();
  const semantic = useSemanticOverview();
  const architecture = useArchitectureReport();
  const spaces = useGenieSpaces();
  const o = overview.data;
  const s = semantic.data;
  const governed = architecture.data?.governed_metrics ?? s?.declared_metrics;
  const conversations = spaces.data?.reduce((n, sp) => n + sp.conversation_count, 0);
  const embedded = o && o.chunks_total ? o.embeddings_total / o.chunks_total : 0;
  const pending = o?.documents_graph_pending ?? 0;
  const synced = o && o.documents_total ? 1 - pending / o.documents_total : 0;
  const topSpaces = [...(spaces.data ?? [])].sort((a, b) => b.conversation_count - a.conversation_count).slice(0, 3);
  const runs7d = pulse?.reduce((n, d) => n + d.completed + d.failed + d.cancelled, 0);

  return (
    <div className="home-kpis">
      <HeroKpi
        icon={FileText}
        color="#0EA5E9"
        label="Documents indexed"
        value={o?.documents_total}
        to="/knowledge/documents"
        visual={
          <div className="space-y-1">
            <Bar share={embedded} color="#0EA5E9" />
            <div className="text-[10px] text-muted-foreground">{o ? `${Math.round(embedded * 100)}% of chunks embedded for search` : "…"}</div>
          </div>
        }
        caption={o ? `${formatCompact(o.chunks_total)} chunks · ${formatCompact(o.embeddings_total)} vectors · ${o.vector_dimensions} dims` : "…"}
      />
      <HeroKpi
        icon={Layers}
        color="#10B981"
        label="Catalog assets"
        value={s?.assets}
        suffix="tables"
        to="/semantic"
        visual={
          s ? (
            <div className="space-y-1">
              <CompositionBar segments={kindSegments(s.by_kind)} legend={false} height="h-2" />
              <div className="truncate text-[10px] text-muted-foreground">
                {Object.entries(s.by_kind)
                  .filter(([, n]) => n)
                  .map(([k, n]) => `${n} ${k}`)
                  .join(" · ")}
              </div>
            </div>
          ) : null
        }
        caption={s ? `${formatCompact(s.fields)} columns · ${formatInt(s.relationships)} relationships` : "…"}
      />
      <HeroKpi
        icon={ShieldCheck}
        color="#8B5CF6"
        label="Governed metrics"
        value={governed}
        suffix={s ? `of ${formatInt(s.metrics)}` : undefined}
        to="/analyst"
        visual={
          <div className="flex items-center gap-2.5">
            <Ring share={s && s.metrics ? (governed ?? 0) / s.metrics : 0} color="#8B5CF6" />
            <span className="text-[10px] leading-snug text-muted-foreground">
              {governed
                ? "declared or curated, with a definition and an owner"
                : "none yet: declare them in Snowflake semantic views or curate them in the Analyst workspace"}
            </span>
          </div>
        }
        caption={s ? `${formatInt(s.metrics)} metrics found; governed ones are what Genie trusts first` : "…"}
      />
      <HeroKpi
        icon={Network}
        color="#14B8A6"
        label="Knowledge graph"
        value={o?.graph_nodes_total}
        suffix="nodes"
        to="/knowledge"
        visual={
          <div className="space-y-1">
            <Bar share={synced} color="#14B8A6" />
            <div className="text-[10px] text-muted-foreground">
              {o ? (pending ? `${formatInt(pending)} documents waiting to sync` : "every document in sync with the graph") : "…"}
            </div>
          </div>
        }
        caption={o ? `${formatCompact(o.graph_edges_total)} relationships in Neo4j` : "…"}
      />
      <HeroKpi
        icon={MessageSquare}
        color="#EC4899"
        label="Genie chats"
        value={conversations}
        to="/genie"
        visual={
          <div className="flex flex-wrap gap-1">
            {topSpaces.map((sp) => (
              <span
                key={sp.id}
                className="max-w-full truncate rounded-md px-1.5 py-0.5 text-[10px]"
                style={{ background: rgba("#EC4899", 0.1), color: "#DB2777" }}
              >
                {sp.name} · {sp.conversation_count}
              </span>
            ))}
          </div>
        }
        caption={spaces.data ? `${spaces.data.length} spaces, each scoped to a persona's sources` : "…"}
      />
      <HeroKpi
        icon={Workflow}
        color="#F59E0B"
        label="Pipeline runs"
        value={o?.runs_total}
        to="/pipelines"
        visual={<Sparkline values={(pulse ?? []).map((d) => d.completed + d.failed + d.cancelled)} color="#F59E0B" />}
        caption={o ? `${runs7d === undefined ? "…" : formatInt(runs7d)} this week · last ${o.last_run_at ? formatRelative(o.last_run_at) : "never"}` : "…"}
      />
    </div>
  );
}
