import {
  ArrowRight,
  BadgeCheck,
  Bot,
  BrainCircuit,
  Cable,
  CalendarClock,
  ChartLine,
  History,
  LockKeyhole,
  Orbit,
  Route,
  Scale,
  ShieldCheck,
  UserRoundCheck,
  Waypoints,
  Workflow,
  Zap,
  type LucideIcon,
} from "lucide-react";
import { Link } from "react-router-dom";

import type { Integration, KpiGroup } from "@/api/types";
import { BrandMark } from "@/components/connectors/brand-mark";
import {
  useArchitectureReport,
  useConnectors,
  useGenieSpaces,
  useGenieStatus,
  useOverview,
  usePlatformReport,
  useQualityReport,
  useSemanticOverview,
} from "@/hooks/queries";
import { formatCompact, formatInt, formatRelative } from "@/lib/format";
import { PERSONA_LIST } from "@/lib/personas";
import { rgba } from "@/lib/tones";
import { cn } from "@/lib/utils";

type Tone = "ok" | "warn" | "bad" | "na";

const TONE_LABEL: Record<Tone, string> = { ok: "Live", warn: "Partial", bad: "Attention", na: "Planned" };
const TONE_HEX: Record<Tone, string> = { ok: "#10B981", warn: "#F59E0B", bad: "#EF4444", na: "#94A3B8" };
/** How far a layer is built: live fills the meter, partial two thirds, planned or failing one third. */
const MATURITY: Record<Tone, number> = { ok: 3, warn: 2, bad: 1, na: 1 };

function StatusPill({ tone }: { tone: Tone }) {
  const color = TONE_HEX[tone];
  return (
    <span
      className="inline-flex shrink-0 items-center gap-1.5 rounded-full px-2 py-0.5 text-[10px] font-medium"
      style={{ background: rgba(color, 0.12), color }}
    >
      <span className="relative flex h-1.5 w-1.5">
        {tone === "ok" ? <span className="absolute inline-flex h-full w-full animate-ping rounded-full opacity-60" style={{ background: color }} /> : null}
        <span className="relative inline-flex h-1.5 w-1.5 rounded-full" style={{ background: color }} />
      </span>
      {TONE_LABEL[tone]}
    </span>
  );
}

function Maturity({ tone, color }: { tone: Tone; color: string }) {
  const filled = MATURITY[tone];
  return (
    <span className="flex gap-0.5" title={`${filled} of 3: ${TONE_LABEL[tone].toLowerCase()}`} aria-label={`maturity ${filled} of 3`}>
      {[0, 1, 2].map((i) => (
        <span key={i} className="h-1.5 w-4 rounded-full" style={{ background: i < filled ? color : rgba(color, 0.18) }} />
      ))}
    </span>
  );
}

function Tile({ icon: Icon, color, size = "md" }: { icon: LucideIcon; color: string; size?: "md" | "lg" }) {
  return (
    <span
      className={cn("flex shrink-0 items-center justify-center text-white", size === "lg" ? "h-11 w-11 rounded-2xl" : "h-8 w-8 rounded-xl")}
      style={{ background: `linear-gradient(145deg, ${rgba(color, 0.78)}, ${color})`, boxShadow: `0 10px 22px -12px ${color}` }}
      aria-hidden="true"
    >
      <Icon className={size === "lg" ? "h-5 w-5" : "h-4 w-4"} />
    </span>
  );
}

/** Three lanes of moving data between two columns; the packets start at different times so the flow reads as continuous. */
function Flow() {
  return (
    <div className="hidden flex-col justify-center gap-10 lg:flex" aria-hidden="true">
      {[0, 0.9, 1.7].map((delay) => (
        <div key={delay} className="relative h-2">
          <div className="context-lane absolute inset-x-0 top-1/2 h-[2px] -translate-y-1/2 opacity-70" />
          <span className="context-packet" style={{ animationDelay: `${delay}s` }} />
        </div>
      ))}
      <ArrowRight className="mx-auto h-4 w-4 text-primary/70" />
    </div>
  );
}

interface RowSpec {
  key: string;
  label: string;
  caption: string;
  tone: Tone;
  to?: string;
  icon?: LucideIcon;
  brand?: string;
  color?: string;
}

function Row({ row }: { row: RowSpec }) {
  const body = (
    <>
      {row.brand ? <BrandMark icon={row.brand} size="sm" /> : row.icon ? <Tile icon={row.icon} color={row.color ?? "#14B8A6"} /> : null}
      <span className="min-w-0 flex-1">
        <span className="flex items-center justify-between gap-2">
          <span className={cn("truncate text-sm font-medium leading-tight", row.tone === "na" && "text-muted-foreground")}>{row.label}</span>
          <span
            className="h-2 w-2 shrink-0 rounded-full"
            style={{ background: TONE_HEX[row.tone], boxShadow: row.tone === "ok" ? `0 0 8px ${TONE_HEX.ok}` : undefined }}
            title={TONE_LABEL[row.tone]}
          />
        </span>
        <span className="line-clamp-2 text-[11px] leading-snug text-muted-foreground">{row.caption}</span>
      </span>
    </>
  );
  const cls = cn("flex items-center gap-2.5 rounded-xl px-2 py-2 transition-all", row.tone === "na" && "opacity-70");
  return row.to ? (
    <Link to={row.to} className={cn(cls, "hover:bg-primary/10 hover:shadow-sm")}>
      {body}
    </Link>
  ) : (
    <div className={cls}>{body}</div>
  );
}

function Panel({ title, icon: Icon, color, rows }: { title: string; icon: LucideIcon; color: string; rows: RowSpec[] }) {
  const live = rows.filter((r) => r.tone === "ok").length;
  return (
    <div className="relative overflow-hidden rounded-2xl border bg-card/80 p-3 shadow-sm backdrop-blur" style={{ borderColor: rgba(color, 0.28) }}>
      <div
        className="pointer-events-none absolute -right-10 -top-12 h-32 w-32 rounded-full opacity-40 blur-3xl"
        style={{ background: color }}
        aria-hidden="true"
      />
      <div className="relative mb-2 flex items-center gap-2 px-1">
        <Tile icon={Icon} color={color} />
        <div className="min-w-0 flex-1">
          <div className="text-[10px] font-medium uppercase tracking-[0.2em] text-muted-foreground">{title}</div>
          <div className="text-xs text-foreground/80">
            {live} of {rows.length} live
          </div>
        </div>
      </div>
      <div className="relative space-y-0.5">
        {rows.map((r) => (
          <Row key={r.key} row={r} />
        ))}
      </div>
    </div>
  );
}

interface Fact {
  value: string;
  label: string;
}

interface LayerSpec {
  key: string;
  icon: LucideIcon;
  color: string;
  title: string;
  lead: string;
  tone: Tone;
  facts: Fact[];
  gap: string;
  to: string;
}

/** One layer of meaning: what it holds, how built it is, its live numbers and what is still to come. */
function LayerCard({ layer }: { layer: LayerSpec }) {
  const c = layer.color;
  return (
    <Link
      to={layer.to}
      className="group relative block overflow-hidden rounded-2xl border bg-card/90 p-3.5 pl-4 shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg"
      style={{ borderColor: rgba(c, 0.3) }}
    >
      <span className="absolute inset-y-0 left-0 w-1" style={{ background: `linear-gradient(180deg, ${c}, ${rgba(c, 0.35)})` }} aria-hidden="true" />
      <span
        className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full opacity-20 blur-3xl transition-opacity duration-300 group-hover:opacity-40"
        style={{ background: c }}
        aria-hidden="true"
      />
      <div className="relative flex flex-wrap items-center gap-x-5 gap-y-3">
        <div className="flex min-w-0 flex-1 basis-[15rem] items-center gap-3">
          <Tile icon={layer.icon} color={c} size="lg" />
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-display text-[15px] font-medium tracking-tight">{layer.title}</span>
              <StatusPill tone={layer.tone} />
              <Maturity tone={layer.tone} color={c} />
            </div>
            <div className="mt-0.5 text-xs leading-snug text-muted-foreground">{layer.lead}</div>
          </div>
        </div>
        <div className="grid min-w-0 flex-[1.35] basis-[17rem] grid-cols-3 gap-1.5">
          {layer.facts.map((f) => (
            <div key={f.label} className="min-w-0 rounded-xl px-2.5 py-1.5" style={{ background: rgba(c, 0.07) }}>
              <div className="truncate font-display text-lg font-medium leading-tight tabular-nums" style={{ color: c }} title={f.value}>
                {f.value}
              </div>
              <div className="line-clamp-2 text-[10px] leading-tight text-muted-foreground" title={f.label}>
                {f.label}
              </div>
            </div>
          ))}
        </div>
      </div>
      <div
        className="relative mt-2.5 flex items-center gap-1.5 rounded-lg border border-dashed px-2.5 py-1 text-[11px] text-muted-foreground"
        style={{ borderColor: rgba(c, 0.35) }}
      >
        <span className="shrink-0 font-medium" style={{ color: c }}>
          Next
        </span>
        <span className="truncate">{layer.gap}</span>
      </div>
    </Link>
  );
}

/** The emblem above the layers: the hub's context core, softly pulsing while it is live. */
function CoreEmblem() {
  return (
    <div className="mb-3 flex items-center justify-center gap-3">
      <span className="relative flex h-11 w-11 items-center justify-center">
        <span className="context-halo absolute inset-0 rounded-full bg-primary/40" aria-hidden="true" />
        <span className="relative flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-primary to-[#0EA5E9] text-white shadow-[0_10px_30px_-10px_hsl(var(--primary))]">
          <Orbit className="h-5 w-5" />
        </span>
      </span>
      <div>
        <div className="font-display text-sm font-medium uppercase tracking-[0.3em] text-primary">Context layer</div>
        <div className="text-[11px] text-muted-foreground">Maintained · Governed · Connected</div>
      </div>
    </div>
  );
}

interface FoundationSpec extends RowSpec {
  icon: LucideIcon;
  color: string;
  meter?: { done: number; total: number };
}

function FoundationTile({ row }: { row: FoundationSpec }) {
  const share = row.meter && row.meter.total ? row.meter.done / row.meter.total : null;
  return (
    <div className="relative overflow-hidden rounded-xl border bg-card/80 px-3 py-2.5" style={{ borderColor: rgba(row.color, 0.25) }}>
      <div className="flex items-start gap-2.5">
        <Tile icon={row.icon} color={row.color} />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-0.5">
            <span className="text-sm font-medium leading-tight">{row.label}</span>
            <StatusPill tone={row.tone} />
          </div>
          <div className="mt-0.5 line-clamp-2 text-[11px] leading-snug text-muted-foreground">{row.caption}</div>
          {share !== null && row.meter ? (
            <div className="mt-1.5 flex items-center gap-2">
              <span className="h-1.5 flex-1 overflow-hidden rounded-full" style={{ background: rgba(row.color, 0.15) }}>
                <span className="block h-full rounded-full transition-all" style={{ width: `${Math.round(share * 100)}%`, background: row.color }} />
              </span>
              <span className="font-mono text-[10px] tabular-nums text-muted-foreground">
                {row.meter.done}/{row.meter.total}
              </span>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}

const sumKeys = (map: Record<string, number> | undefined, ...keys: string[]) => keys.reduce((n, k) => n + (map?.[k] ?? 0), 0);

function scored(group: KpiGroup | undefined) {
  return (group?.kpis ?? []).filter((k) => k.status !== "na" && k.status !== "info");
}

function gateTone(group: KpiGroup | undefined): Tone {
  const kpis = scored(group);
  if (!group || !kpis.length) return "na";
  if (kpis.some((k) => k.status === "bad")) return "bad";
  if (kpis.some((k) => k.status === "warn")) return "warn";
  return "ok";
}

function gates(group: KpiGroup | undefined): { done: number; total: number } {
  const kpis = scored(group);
  return { done: kpis.filter((k) => k.status === "ok").length, total: kpis.length };
}

/** One source row: the backend's detail line ("43 assets in 1 catalog(s) · 43 documents") plus connector health. */
function sourceRow(i: Integration, healthy: Map<string, boolean>): RowSpec {
  const connected = healthy.get(i.key);
  const tone: Tone = i.status === "configured" ? (connected === false ? "bad" : "ok") : i.status === "available" ? "warn" : "na";
  const caption =
    i.status === "configured"
      ? connected === false
        ? `${i.detail} · connector unhealthy`
        : i.detail
      : i.status === "available"
        ? `${i.detail} · not configured`
        : "not connected";
  return { key: i.key, brand: i.key, label: i.label, caption, tone, to: "/connectors" };
}

/** Sources → four layers of meaning → who uses it, on a governance foundation, filled with the hub's live numbers. */
export function ContextLayer() {
  const architecture = useArchitectureReport();
  const connectors = useConnectors();
  const overview = useOverview();
  const semantic = useSemanticOverview();
  const quality = useQualityReport(7);
  const platform = usePlatformReport(24);
  const genie = useGenieStatus();
  const spaces = useGenieSpaces();

  const a = architecture.data;
  const o = overview.data;
  const s = semantic.data;
  const q = quality.data;
  const p = platform.data;
  const g = genie.data;

  const healthy = new Map((connectors.data ?? []).map((c) => [c.source_system as string, c.healthy] as const));
  const sources: RowSpec[] = a
    ? a.integrations.filter((i) => i.kind === "source").map((i) => sourceRow(i, healthy))
    : (connectors.data ?? []).map((c) => ({
        key: c.name,
        brand: c.source_system,
        label: c.display_name,
        caption: c.healthy ? "connected" : "unhealthy",
        tone: c.healthy ? "ok" : "bad",
        to: "/connectors",
      }));

  const rel = a?.relationships_by_kind;
  const keysJoins = sumKeys(rel, "foreign_key", "join_declared", "join_inferred");
  const lineage = sumKeys(rel, "lineage_upstream", "lineage_downstream");
  const curated = a?.metrics_by_source?.curated ?? 0;
  const governed = a?.governed_metrics ?? s?.declared_metrics ?? 0;
  const targets = q?.targets.length ?? 0;
  const conversations = spaces.data?.reduce((n, sp) => n + sp.conversation_count, 0) ?? 0;
  const requests24h = p?.requests.reduce((n, r) => n + r.requests, 0) ?? 0;
  const reviewQueue = q?.review_queue.length ?? 0;
  const n = (v: number | undefined) => (v === undefined ? "…" : formatCompact(v));

  const layers: LayerSpec[] = [
    {
      key: "relationships",
      icon: Waypoints,
      color: "#0EA5E9",
      title: "Relationships",
      lead: "How entities connect across systems",
      tone: a ? "ok" : "na",
      facts: [
        { value: n(keysJoins), label: "keys & joins" },
        { value: n(o?.graph_nodes_total), label: `graph nodes · ${n(o?.graph_edges_total)} edges` },
        { value: n(lineage), label: "lineage links" },
      ],
      gap: "entity resolution and hierarchies across systems",
      to: "/knowledge",
    },
    {
      key: "rules",
      icon: Scale,
      color: "#8B5CF6",
      title: "Rules & policies",
      lead: "Operational logic that guides decisions",
      tone: a ? "warn" : "na",
      facts: [
        { value: n(governed), label: "governed metrics" },
        { value: n(curated), label: "curated by review" },
        { value: n(targets), label: "KPI targets" },
      ],
      gap: "business rules and approval workflows",
      to: "/semantic",
    },
    {
      key: "history",
      icon: History,
      color: "#F59E0B",
      title: "History & behavior",
      lead: "What has happened and what was done",
      tone: o ? "warn" : "na",
      facts: [
        { value: n(o?.runs_total), label: "pipeline runs" },
        { value: n(requests24h), label: "requests audited, 24h" },
        { value: n(conversations), label: "Genie conversations" },
      ],
      gap: "outcome patterns learned from decisions",
      to: "/pipelines",
    },
    {
      key: "temporal",
      icon: CalendarClock,
      color: "#10B981",
      title: "Temporal context",
      lead: "What was true, when it was true",
      tone: "na",
      facts: [
        { value: s?.last_synced_at ? formatRelative(s.last_synced_at) : "…", label: "catalog synced" },
        { value: o?.last_run_at ? formatRelative(o.last_run_at) : "…", label: "last pipeline run" },
        { value: "on", label: "document versioning" },
      ],
      gap: "effective dates, versioned entities and restatements",
      to: "/knowledge/documents",
    },
  ];

  const consumers: RowSpec[] = [
    {
      key: "agents",
      icon: Bot,
      color: "#EC4899",
      label: "AI agents",
      caption: g
        ? g.configured
          ? `Genie · ${spaces.data?.length ?? 0} spaces · ${formatInt(conversations)} conversations`
          : "Genie · no model configured"
        : "…",
      tone: g ? (g.configured ? "ok" : "warn") : "na",
      to: "/genie",
    },
    {
      key: "analytics",
      icon: ChartLine,
      color: "#0EA5E9",
      label: "Analytics & insights",
      caption: `${PERSONA_LIST.length} persona workspaces · ${q ? `${q.gates_passed}/${q.gates_total} gates passing` : "…"}`,
      tone: q ? "ok" : "na",
      to: "/personas",
    },
    {
      key: "hitl",
      icon: UserRoundCheck,
      color: "#10B981",
      label: "Human-in-the-loop",
      caption: q ? (reviewQueue ? `${formatInt(reviewQueue)} proposals awaiting review` : "review queue is clear") : "…",
      tone: q ? "ok" : "na",
      to: "/glossary/review",
    },
    { key: "ml", icon: BrainCircuit, color: "#8B5CF6", label: "Machine learning models", caption: "not connected yet", tone: "na" },
    { key: "decisions", icon: Zap, color: "#F59E0B", label: "Automated decisions", caption: "not connected yet", tone: "na" },
  ];

  const review = q?.groups.find((grp) => grp.key === "review");
  const integrity = q?.groups.find((grp) => grp.key === "integrity");
  const ingestion = q?.groups.find((grp) => grp.key === "ingestion");
  const qualityTones = [integrity, ingestion].map(gateTone);
  const qualityTone: Tone = !q ? "na" : qualityTones.includes("bad") ? "bad" : qualityTones.includes("warn") ? "warn" : "ok";
  const foundation: FoundationSpec[] = [
    {
      key: "governance",
      icon: ShieldCheck,
      color: "#8B5CF6",
      label: "Data governance",
      caption: q ? `review gates · ${formatInt(curated)} curated names and metrics with provenance` : "…",
      tone: gateTone(review),
      meter: q ? gates(review) : undefined,
    },
    {
      key: "quality",
      icon: BadgeCheck,
      color: "#10B981",
      label: "Data quality",
      caption: q ? `quality gates · ${formatInt(o?.documents_graph_pending ?? 0)} documents pending graph sync` : "…",
      tone: qualityTone,
      meter: q ? { done: q.gates_passed, total: q.gates_total } : undefined,
    },
    {
      key: "lineage",
      icon: Route,
      color: "#0EA5E9",
      label: "Lineage & provenance",
      caption: a ? `${formatInt(lineage)} lineage links · every Genie answer cites its sources` : "…",
      tone: a ? (lineage ? "ok" : "warn") : "na",
    },
    {
      key: "security",
      icon: LockKeyhole,
      color: "#64748B",
      label: "Security & privacy",
      caption: "credentials stay in the environment · sign-in and roles not yet built",
      tone: "na",
    },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(15rem,19rem)_3.5rem_minmax(0,1fr)_3.5rem_minmax(15rem,19rem)] lg:items-center">
        <Panel title="Data sources" icon={Cable} color="#0EA5E9" rows={sources} />
        <Flow />
        <div className="relative rounded-3xl border border-primary/20 bg-gradient-to-br from-primary/[0.07] via-card/60 to-[#8B5CF6]/[0.06] p-4 shadow-[inset_0_1px_0_0_hsl(var(--primary)/0.15)]">
          <div className="hero-grid pointer-events-none absolute inset-0 rounded-3xl opacity-30" aria-hidden="true" />
          <div className="relative">
            <CoreEmblem />
            <div className="space-y-2.5">
              {layers.map((layer) => (
                <LayerCard key={layer.key} layer={layer} />
              ))}
            </div>
          </div>
        </div>
        <Flow />
        <Panel title="AI agents & intelligence" icon={Workflow} color="#EC4899" rows={consumers} />
      </div>
      <div className="relative rounded-2xl border border-dashed border-primary/30 bg-card/40 p-3">
        <div className="mb-2.5 flex items-center gap-2 px-1 text-[10px] font-medium uppercase tracking-[0.24em] text-muted-foreground">
          <ShieldCheck className="h-3.5 w-3.5 text-primary" />
          Governance & quality · the foundation under every layer
        </div>
        <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2 xl:grid-cols-4">
          {foundation.map((row) => (
            <FoundationTile key={row.key} row={row} />
          ))}
        </div>
      </div>
      <p className="text-center text-xs text-muted-foreground">
        The context layer sits between your data and your AI systems, holding the meaning, relationships, rules and history needed for accurate, consistent and
        trustworthy answers.
      </p>
    </div>
  );
}
