import {
  Activity,
  Ban,
  BookOpen,
  Briefcase,
  Cable,
  CircleCheck,
  CircleX,
  FileCheck2,
  FileUp,
  FileX2,
  Flag,
  Info,
  Lightbulb,
  LoaderCircle,
  Network,
  Play,
  Plus,
  Radio,
  Search,
  Settings2,
  Sparkles,
  Trash2,
  TriangleAlert,
  Waypoints,
  type LucideIcon,
} from "lucide-react";
import type { ReactNode } from "react";

import type { RunEvent } from "@/api/types";
import { useAudit, useRuns } from "@/hooks/queries";
import { useRunEventStream, type SseState } from "@/hooks/use-sse";
import { formatInt, formatMs, formatRelative, shortId } from "@/lib/format";
import { rgba } from "@/lib/tones";
import { cn } from "@/lib/utils";

interface Visual {
  icon: LucideIcon;
  color: string;
}

const STATE_LABEL: Record<SseState, { label: string; color: string; pulse: boolean }> = {
  open: { label: "Live", color: "#10B981", pulse: true },
  connecting: { label: "Connecting", color: "#94A3B8", pulse: false },
  reconnecting: { label: "Reconnecting", color: "#F59E0B", pulse: false },
  closed: { label: "Offline", color: "#EF4444", pulse: false },
};

/** What an ingestion event looks like: its type, or its message when the message names a step of the sync. */
function eventVisual(e: RunEvent): Visual {
  if (e.level === "error") return { icon: CircleX, color: "#EF4444" };
  if (e.level === "warning") return { icon: TriangleAlert, color: "#F59E0B" };
  if (e.message.startsWith("Line of business")) return { icon: Briefcase, color: "#EC4899" };
  if (e.message.startsWith("Semantic layer")) return { icon: Waypoints, color: "#0EA5E9" };
  switch (e.event_type) {
    case "run.started":
      return { icon: Play, color: "#0EA5E9" };
    case "run.completed":
      return { icon: CircleCheck, color: "#10B981" };
    case "run.failed":
      return { icon: CircleX, color: "#EF4444" };
    case "run.cancelled":
      return { icon: Ban, color: "#F59E0B" };
    case "run.progress":
      return { icon: LoaderCircle, color: "#8B5CF6" };
    case "document.upserted":
      return { icon: FileCheck2, color: "#14B8A6" };
    case "document.failed":
      return { icon: FileX2, color: "#EF4444" };
    default:
      return { icon: Info, color: "#64748B" };
  }
}

function HeaderTile({ icon: Icon, color }: Visual) {
  return (
    <span
      className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-white"
      style={{ background: `linear-gradient(145deg, ${rgba(color, 0.75)}, ${color})`, boxShadow: `0 10px 22px -12px ${color}` }}
      aria-hidden="true"
    >
      <Icon className="h-[18px] w-[18px]" />
    </span>
  );
}

/** One step on a timeline: a tinted node joined to the next by a thin line. */
function TimelineItem({ visual, title, meta, when, fresh }: { visual: Visual; title: ReactNode; meta: ReactNode; when: string; fresh?: boolean }) {
  const Icon = visual.icon;
  return (
    <li className={cn("group/item relative flex gap-3 pb-2.5 last:pb-0", fresh && "animate-in fade-in slide-in-from-top-1")}>
      <span className="absolute bottom-0 left-[15px] top-8 w-px bg-border/70 group-last/item:hidden" aria-hidden="true" />
      <span
        className="relative flex h-8 w-8 shrink-0 items-center justify-center rounded-xl"
        style={{ background: rgba(visual.color, 0.13), color: visual.color, boxShadow: `inset 0 0 0 1px ${rgba(visual.color, 0.3)}` }}
      >
        <Icon className="h-4 w-4" />
      </span>
      <div className="min-w-0 flex-1 pt-0.5">
        <div className="flex items-start justify-between gap-2">
          <div className="line-clamp-2 text-[13px] leading-snug text-foreground/90">{title}</div>
          <span className="shrink-0 whitespace-nowrap pt-0.5 text-[10px] text-muted-foreground">{when}</span>
        </div>
        <div className="mt-0.5 flex flex-wrap items-center gap-x-1.5 gap-y-0.5 text-[10px] text-muted-foreground">{meta}</div>
      </div>
    </li>
  );
}

function Tag({ children, color }: { children: ReactNode; color?: string }) {
  return (
    <span className="rounded-md px-1.5 py-px font-mono" style={color ? { background: rgba(color, 0.1), color } : undefined}>
      {children}
    </span>
  );
}

function eventKey(e: RunEvent): string {
  return `${e.run_id}-${e.seq}`;
}

/** The ingestion event stream, newest first: runs starting, progressing and finishing, documents landing or failing. */
export function LivePipelineFeed({ limit = 8 }: { limit?: number }) {
  const stream = useRunEventStream({ maxEvents: 80 });
  const events = [...stream.events].reverse().slice(0, limit);
  const state = STATE_LABEL[stream.state];
  // The event bus lives in memory, so after a restart there is nothing to replay: show the latest runs instead.
  const runs = useRuns({ status: null, limit });
  const recent = events.length === 0 ? (runs.data?.items ?? []) : [];
  return (
    <div className="surface flex h-full flex-col p-4">
      <header className="flex items-center gap-2.5">
        <HeaderTile icon={Radio} color="#8B5CF6" />
        <div className="min-w-0 flex-1">
          <div className="text-sm font-medium">Live from the pipelines</div>
          <div className="text-[11px] text-muted-foreground">Server-sent events from the ingestion service, as they happen.</div>
        </div>
        <span
          className="inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[10px] font-medium"
          style={{ background: rgba(state.color, 0.12), color: state.color }}
        >
          <span className="relative flex h-1.5 w-1.5">
            {state.pulse ? (
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full opacity-60" style={{ background: state.color }} />
            ) : null}
            <span className="relative inline-flex h-1.5 w-1.5 rounded-full" style={{ background: state.color }} />
          </span>
          {state.label}
        </span>
      </header>
      <ul className="mt-4 flex-1 overflow-hidden">
        {events.map((e) => {
          const visual = eventVisual(e);
          return (
            <TimelineItem
              key={eventKey(e)}
              fresh
              visual={visual}
              title={e.message}
              when={formatRelative(e.created_at)}
              meta={
                <>
                  <Tag color={visual.color}>{e.event_type}</Tag>
                  <span>run {shortId(e.run_id)}</span>
                  {e.status ? <span>· {e.status}</span> : null}
                </>
              }
            />
          );
        })}
        {recent.map((run) => {
          const visual =
            run.status === "failed"
              ? { icon: CircleX, color: "#EF4444" }
              : run.status === "completed"
                ? { icon: CircleCheck, color: "#10B981" }
                : { icon: LoaderCircle, color: "#8B5CF6" };
          return (
            <TimelineItem
              key={run.id}
              visual={visual}
              title={
                run.status === "failed" && run.error
                  ? run.error
                  : `${formatInt(run.stats.documents_upserted ?? 0)} documents upserted · ${formatInt(run.stats.documents_seen ?? 0)} seen${run.duration_seconds !== null ? ` · ${Math.round(run.duration_seconds)} s` : ""}`
              }
              when={formatRelative(run.finished_at ?? run.started_at ?? run.created_at)}
              meta={
                <>
                  <Tag color={visual.color}>run.{run.status}</Tag>
                  <span>{run.connector_name}</span>
                  <span>· run {shortId(run.id)}</span>
                </>
              }
            />
          );
        })}
        {events.length === 0 && recent.length === 0 ? (
          <li className="rounded-xl border border-dashed border-border/80 px-3 py-6 text-center text-xs text-muted-foreground">
            {stream.state === "open"
              ? "Connected. Events appear here the moment a run starts, progresses or finishes."
              : "Connecting to the ingestion event stream…"}
          </li>
        ) : null}
      </ul>
      {events.length === 0 && recent.length ? (
        <p className="pt-2 text-[10px] text-muted-foreground">Stream connected and quiet; showing the latest runs until the next event arrives.</p>
      ) : null}
    </div>
  );
}

const ACTION: Record<string, Visual & { label: string }> = {
  "context.retrieve": { label: "Context retrieved for an agent", icon: Search, color: "#14B8A6" },
  "genie.ask": { label: "Genie answered a question", icon: Sparkles, color: "#EC4899" },
  "document.ingest": { label: "Document ingested", icon: FileUp, color: "#8B5CF6" },
  "document.delete": { label: "Document deleted", icon: Trash2, color: "#EF4444" },
  "graph.reconcile": { label: "Graph reconciled", icon: Network, color: "#0EA5E9" },
  "pipeline.trigger": { label: "Pipeline triggered", icon: Play, color: "#0EA5E9" },
  "pipeline.finished": { label: "Pipeline finished", icon: Flag, color: "#10B981" },
  "pipeline.update": { label: "Pipeline settings changed", icon: Settings2, color: "#8B5CF6" },
  "pipeline.create": { label: "Pipeline created", icon: Plus, color: "#10B981" },
  "pipeline.delete": { label: "Pipeline deleted", icon: Trash2, color: "#EF4444" },
};

function actionVisual(action: string): Visual & { label: string } {
  const known = ACTION[action];
  if (known) return known;
  if (action.startsWith("connector")) return { label: action, icon: Cable, color: "#0EA5E9" };
  if (action.startsWith("glossary")) return { label: action, icon: BookOpen, color: "#F59E0B" };
  if (action.startsWith("intent")) return { label: action, icon: Lightbulb, color: "#8B5CF6" };
  return { label: action, icon: Activity, color: "#64748B" };
}

/** The audit log, newest first: what agents, people and pipelines did through the API. */
export function RecentActivity({ limit = 8 }: { limit?: number }) {
  const audit = useAudit(limit);
  const rows = audit.data ?? [];
  return (
    <div className="surface flex h-full flex-col p-4">
      <header className="flex items-center gap-2.5">
        <HeaderTile icon={Activity} color="#0EA5E9" />
        <div className="min-w-0 flex-1">
          <div className="text-sm font-medium">Recent activity</div>
          <div className="text-[11px] text-muted-foreground">Audited API calls: retrievals, Genie answers, ingestion, reconciliation.</div>
        </div>
      </header>
      <ul className="mt-4 flex-1 overflow-hidden">
        {rows.map((r) => {
          const v = actionVisual(r.action);
          const failed = r.status !== "ok";
          return (
            <TimelineItem
              key={r.id}
              visual={failed ? { icon: CircleX, color: "#EF4444" } : v}
              title={
                <>
                  {v.label}
                  {failed ? <span className="ml-1.5 text-[11px] text-destructive">failed</span> : null}
                </>
              }
              when={formatRelative(r.created_at)}
              meta={
                <>
                  <Tag color={failed ? "#EF4444" : v.color}>{r.action}</Tag>
                  {r.latency_ms !== null ? <span>{formatMs(r.latency_ms)}</span> : null}
                  {r.actor ? <span>· {r.actor}</span> : null}
                </>
              }
            />
          );
        })}
        {audit.data && rows.length === 0 ? (
          <li className="rounded-xl border border-dashed border-border/80 px-3 py-6 text-center text-xs text-muted-foreground">
            Nothing audited yet. Ask Genie or call the retrieval API.
          </li>
        ) : null}
      </ul>
    </div>
  );
}
