import { useEffect, useRef } from "react";

interface Particle {
  ring: number;
  angle: number;
  radius: number;
  speed: number;
  size: number;
  alpha: number;
  wobble: number;
}

/** Ink-dot orbital artwork: a dense core with tilted rings, drifting slowly. */
export function HeroArt({ color }: { color: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const colorRef = useRef(color);
  colorRef.current = color;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let frame = 0;
    let width = 0;
    let height = 0;

    // Deterministic pseudo-random so the artwork is the same on every visit.
    let seed = 7;
    const rand = () => {
      seed = (seed * 16807) % 2147483647;
      return (seed - 1) / 2147483646;
    };
    const gauss = () => (rand() + rand() + rand() + rand() - 2) / 2;

    const particles: Particle[] = [];
    for (let i = 0; i < 1500; i += 1) {
      particles.push({ ring: -1, angle: rand() * Math.PI * 2, radius: Math.abs(gauss()) * 0.34 + 0.02, speed: (rand() - 0.5) * 0.0006, size: 0.8 + rand() * 1.4, alpha: 0.25 + rand() * 0.55, wobble: rand() * Math.PI * 2 });
    }
    const rings = [
      { r: 0.62, tilt: 0.32, spread: 0.035, count: 900 },
      { r: 0.8, tilt: 0.55, spread: 0.03, count: 800 },
      { r: 0.96, tilt: 0.18, spread: 0.045, count: 700 },
    ];
    rings.forEach((ring, index) => {
      for (let i = 0; i < ring.count; i += 1) {
        particles.push({ ring: index, angle: rand() * Math.PI * 2, radius: ring.r + gauss() * ring.spread, speed: 0.0009 + index * 0.0003, size: 0.7 + rand() * 1.3, alpha: 0.2 + rand() * 0.5, wobble: rand() * Math.PI * 2 });
      }
    });
    for (let i = 0; i < 500; i += 1) {
      particles.push({ ring: -2, angle: rand() * Math.PI * 2, radius: 0.3 + rand() * 0.85, speed: (rand() - 0.5) * 0.0004, size: 0.5 + rand(), alpha: 0.08 + rand() * 0.2, wobble: rand() * Math.PI * 2 });
    }

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = rect.width;
      height = rect.height;
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    const draw = (t: number) => {
      ctx.clearRect(0, 0, width, height);
      const cx = width / 2;
      const cy = height / 2;
      const scale = Math.min(width, height) * 0.42;
      ctx.fillStyle = colorRef.current;
      for (const p of particles) {
        const angle = p.angle + t * p.speed;
        let x: number;
        let y: number;
        if (p.ring >= 0) {
          const ring = rings[p.ring];
          const tilt = ring ? ring.tilt : 0.3;
          x = Math.cos(angle) * p.radius;
          y = Math.sin(angle) * p.radius * tilt;
          const rot = (p.ring - 1) * 0.5;
          const rx = x * Math.cos(rot) - y * Math.sin(rot);
          const ry = x * Math.sin(rot) + y * Math.cos(rot);
          x = rx;
          y = ry - 0.12;
        } else {
          const breathe = 1 + Math.sin(t * 0.0008 + p.wobble) * 0.03;
          x = Math.cos(angle) * p.radius * breathe;
          y = Math.sin(angle) * p.radius * breathe * (p.ring === -1 ? 1.15 : 0.9);
        }
        ctx.globalAlpha = p.alpha;
        ctx.beginPath();
        ctx.arc(cx + x * scale, cy + y * scale, p.size, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    };

    resize();
    draw(0);
    const observer = new ResizeObserver(() => {
      resize();
      draw(performance.now());
    });
    observer.observe(canvas);
    if (!reduceMotion) {
      const loop = (t: number) => {
        draw(t);
        frame = window.requestAnimationFrame(loop);
      };
      frame = window.requestAnimationFrame(loop);
    }
    return () => {
      window.cancelAnimationFrame(frame);
      observer.disconnect();
    };
  }, []);

  return <canvas ref={canvasRef} className="aspect-[4/3] w-full" aria-label="Connected context artwork" role="img" />;
}
