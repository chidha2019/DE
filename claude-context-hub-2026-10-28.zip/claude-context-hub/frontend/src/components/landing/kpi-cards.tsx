import { ArrowUpRight, BookCheck, Clock3, FileStack, Gauge, ShieldAlert, TrendingUp, type LucideIcon } from "lucide-react";
import { useId } from "react";
import { Link } from "react-router-dom";

import type { KpiStatus, KpiValue, RunActivityPoint } from "@/api/types";
import { useGlossaryCoverage, useOverview, usePlatformReport, useSemanticCatalog } from "@/hooks/queries";
import { formatCompact, formatInt, formatRelative } from "@/lib/format";
import { rgba } from "@/lib/tones";
import { cn } from "@/lib/utils";

type Tone = "ok" | "warn" | "bad" | "na";
const STATUS: Record<Tone, { label: string; color: string }> = {
  ok: { label: "Healthy", color: "#10B981" },
  warn: { label: "Watch", color: "#F59E0B" },
  bad: { label: "Attention", color: "#EF4444" },
  na: { label: "No data", color: "#94A3B8" },
};

const toneOf = (status: KpiStatus | undefined): Tone => (status === "ok" || status === "warn" || status === "bad" ? status : "na");

/** A small area chart of a week, drawn in plain SVG so it costs nothing to render in a card. */
export function Sparkline({ values, color }: { values: number[]; color: string }) {
  const id = useId();
  if (!values.length) return null;
  const max = Math.max(1, ...values);
  const w = 120;
  const h = 34;
  const step = values.length > 1 ? w / (values.length - 1) : w;
  const pts = values.map((v, i) => [i * step, h - 3 - (v / max) * (h - 6)] as const);
  const line = pts.map(([x, y], i) => `${i ? "L" : "M"}${x.toFixed(1)},${y.toFixed(1)}`).join(" ");
  const area = `${line} L${w},${h} L0,${h} Z`;
  const last = pts[pts.length - 1];
  return (
    <svg viewBox={`-4 0 ${w + 8} ${h}`} className="h-9 w-full overflow-visible" preserveAspectRatio="none" aria-hidden="true">
      <defs>
        <linearGradient id={id} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.35" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#${id})`} />
      <path d={line} fill="none" stroke={color} strokeWidth="1.8" strokeLinejoin="round" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
      {last ? <circle cx={last[0]} cy={last[1]} r="2.6" fill={color} /> : null}
    </svg>
  );
}

/** A share as a ring, for "how much of it is done". */
export function Ring({ share, color }: { share: number; color: string }) {
  const r = 15;
  const c = 2 * Math.PI * r;
  return (
    <svg viewBox="0 0 36 36" className="h-12 w-12 -rotate-90" aria-hidden="true">
      <circle cx="18" cy="18" r={r} fill="none" stroke={rgba(color, 0.15)} strokeWidth="4" />
      <circle
        cx="18"
        cy="18"
        r={r}
        fill="none"
        stroke={color}
        strokeWidth="4"
        strokeLinecap="round"
        strokeDasharray={`${(Math.max(0, Math.min(1, share)) * c).toFixed(2)} ${c.toFixed(2)}`}
      />
    </svg>
  );
}

export function Bar({ share, color }: { share: number; color: string }) {
  return (
    <span className="block h-2 w-full overflow-hidden rounded-full" style={{ background: rgba(color, 0.14) }}>
      <span
        className="block h-full rounded-full"
        style={{ width: `${Math.round(Math.max(0, Math.min(1, share)) * 100)}%`, background: `linear-gradient(90deg, ${rgba(color, 0.7)}, ${color})` }}
      />
    </span>
  );
}

interface CardSpec {
  key: string;
  icon: LucideIcon;
  color: string;
  label: string;
  value: string;
  unit?: string;
  tone: Tone;
  caption: string;
  target?: string;
  to: string;
  visual: { kind: "spark"; values: number[] } | { kind: "ring"; share: number } | { kind: "bar"; share: number } | { kind: "none" };
}

function KpiCard({ card }: { card: CardSpec }) {
  const status = STATUS[card.tone];
  const c = card.color;
  return (
    <Link
      to={card.to}
      className="group relative flex min-w-0 flex-col overflow-hidden rounded-2xl border bg-card/90 p-4 shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg"
      style={{ borderColor: rgba(c, 0.28) }}
    >
      <span
        className="pointer-events-none absolute -right-12 -top-14 h-36 w-36 rounded-full opacity-25 blur-3xl transition-opacity duration-300 group-hover:opacity-45"
        style={{ background: c }}
        aria-hidden="true"
      />
      <span className="absolute inset-x-0 top-0 h-0.5" style={{ background: `linear-gradient(90deg, ${c}, transparent 75%)` }} aria-hidden="true" />
      <div className="relative flex items-center justify-between gap-2.5">
        <span
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-white"
          style={{ background: `linear-gradient(145deg, ${rgba(c, 0.75)}, ${c})`, boxShadow: `0 10px 22px -12px ${c}` }}
          aria-hidden="true"
        >
          <card.icon className="h-[18px] w-[18px]" />
        </span>
        <span
          className="inline-flex shrink-0 items-center gap-1 rounded-full px-1.5 py-0.5 text-[10px] font-medium"
          style={{ background: rgba(status.color, 0.12), color: status.color }}
        >
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: status.color }} />
          {status.label}
        </span>
      </div>
      <div className="relative mt-2.5 text-xs font-medium text-muted-foreground">{card.label}</div>
      <div className="relative mt-1.5 flex items-end justify-between gap-3">
        <div className="min-w-0">
          <div className="font-display text-3xl font-medium leading-none tracking-tight tabular-nums">
            {card.value}
            {card.unit ? <span className="ml-1 text-base text-muted-foreground">{card.unit}</span> : null}
          </div>
        </div>
        {card.visual.kind === "ring" ? <Ring share={card.visual.share} color={c} /> : null}
      </div>
      <div className="relative mt-2">
        {card.visual.kind === "spark" ? <Sparkline values={card.visual.values} color={c} /> : null}
        {card.visual.kind === "bar" ? <Bar share={card.visual.share} color={c} /> : null}
      </div>
      <div className="relative mt-auto flex items-end justify-between gap-2 pt-2 text-[11px] text-muted-foreground">
        <span className="line-clamp-2 min-w-0">
          {card.caption}
          {card.target ? <span className="text-foreground/60"> · {card.target}</span> : null}
        </span>
        <ArrowUpRight className="h-3.5 w-3.5 shrink-0 opacity-0 transition-opacity group-hover:opacity-100" style={{ color: c }} />
      </div>
    </Link>
  );
}

function hours(value: number): { value: string; unit: string } {
  if (value < 1) return { value: formatInt(Math.round(value * 60)), unit: "min" };
  if (value < 48) return { value: value.toFixed(value < 10 ? 1 : 0), unit: "h" };
  return { value: formatInt(Math.round(value / 24)), unit: "days" };
}

/** Six numbers that say whether the hub is healthy right now: runs, freshness, volume, speed, errors and business meaning. */
export function LiveKpis({ pulse }: { pulse: RunActivityPoint[] | undefined }) {
  const overview = useOverview();
  const platform = usePlatformReport(24);
  const catalog = useSemanticCatalog();
  const coverage = useGlossaryCoverage();
  const o = overview.data;
  const p = platform.data;
  const kpi = (key: string): KpiValue | undefined => p?.groups.flatMap((g) => g.kpis).find((k) => k.key === key);

  const completed = pulse?.reduce((n, d) => n + d.completed, 0) ?? 0;
  const failed = pulse?.reduce((n, d) => n + d.failed, 0) ?? 0;
  const cancelled = pulse?.reduce((n, d) => n + d.cancelled, 0) ?? 0;
  const decided = completed + failed;
  const success = decided ? completed / decided : null;
  const documents7d = pulse?.reduce((n, d) => n + d.documents, 0);

  const sync = kpi("catalog_sync_age_h");
  const p95 = kpi("retrieval_p95_ms");
  const errors = kpi("request_error_rate");
  const audited = kpi("audited_requests");
  const budget = p?.error_budget;

  const c = catalog.data;
  const tables = c?.counts.entities ?? 0;
  const placed = c?.entities_placed ?? 0;
  const placedShare = tables ? placed / tables : 0;
  const waiting = coverage.data?.links_suggested ?? 0;
  const fresh = sync?.value != null ? hours(sync.value) : null;

  const cards: CardSpec[] = [
    {
      key: "success",
      icon: TrendingUp,
      color: "#10B981",
      label: "Run success · 7 days",
      value: success === null ? "–" : `${Math.round(success * 100)}`,
      unit: success === null ? undefined : "%",
      tone: success === null ? "na" : success >= 0.95 ? "ok" : success >= 0.8 ? "warn" : "bad",
      caption: pulse
        ? `${formatInt(completed + failed + cancelled)} runs · ${formatInt(failed)} failed${cancelled ? ` · ${formatInt(cancelled)} cancelled` : ""}`
        : "…",
      to: "/pipelines?tab=history",
      visual: { kind: "spark", values: (pulse ?? []).map((d) => d.completed + d.failed + d.cancelled) },
    },
    {
      key: "freshness",
      icon: Clock3,
      color: "#0EA5E9",
      label: "Data freshness",
      value: fresh?.value ?? "–",
      unit: fresh?.unit,
      tone: toneOf(sync?.status),
      caption: o?.last_run_at ? `since the last catalog sync · last run ${formatRelative(o.last_run_at)}` : "since the last catalog sync",
      target: sync?.target != null ? `target under ${sync.target} h` : undefined,
      to: "/pipelines",
      visual: { kind: "bar", share: sync?.value != null && sync.target ? 1 - Math.min(1, sync.value / sync.target) : 0 },
    },
    {
      key: "documents",
      icon: FileStack,
      color: "#8B5CF6",
      label: "Documents landed · 7 days",
      value: documents7d === undefined ? "–" : formatCompact(documents7d),
      tone: documents7d === undefined ? "na" : documents7d > 0 ? "ok" : "warn",
      caption: o
        ? `${formatCompact(o.documents_total)} indexed · ${formatCompact(o.chunks_total)} chunks · ${formatCompact(o.graph_nodes_total)} graph nodes`
        : "…",
      to: "/knowledge/documents",
      visual: { kind: "spark", values: (pulse ?? []).map((d) => d.documents) },
    },
    {
      key: "p95",
      icon: Gauge,
      color: "#14B8A6",
      label: "Retrieval speed · p95, 24 h",
      value: p95?.value != null ? formatInt(Math.round(p95.value)) : "–",
      unit: p95?.value != null ? "ms" : undefined,
      tone: toneOf(p95?.status),
      caption: audited?.value != null ? `${formatInt(audited.value)} requests audited` : "…",
      target: p95?.target != null ? `target ${formatInt(p95.target)} ms` : undefined,
      to: "/sre",
      visual: { kind: "bar", share: p95?.value != null && p95.target ? Math.min(1, p95.value / p95.target) : 0 },
    },
    {
      key: "errors",
      icon: ShieldAlert,
      color: "#F43F5E",
      label: "Request errors · 24 h",
      value: errors?.value != null ? errors.value.toFixed(1) : "–",
      unit: errors?.value != null ? "%" : undefined,
      tone: toneOf(errors?.status),
      caption: budget
        ? `${formatInt(budget.errors)} of ${formatInt(budget.requests)} requests failed${budget.consumed_pct != null ? ` · error budget ${Math.round(budget.consumed_pct)}% used` : ""}`
        : "…",
      target: errors?.target != null ? `target ${errors.target}%` : undefined,
      to: "/sre",
      visual: { kind: "bar", share: budget?.consumed_pct != null ? Math.min(1, budget.consumed_pct / 100) : 0 },
    },
    {
      key: "meaning",
      icon: BookCheck,
      color: "#F59E0B",
      label: "Tables with a business area",
      value: c ? `${Math.round(placedShare * 100)}` : "–",
      unit: c ? "%" : undefined,
      tone: !c ? "na" : placedShare >= 0.9 ? "ok" : placedShare >= 0.5 ? "warn" : "bad",
      caption: c ? `${formatInt(placed)} of ${formatInt(tables)} tables${waiting ? ` · ${formatInt(waiting)} suggestions waiting` : ""}` : "…",
      to: waiting ? "/glossary/review" : "/semantic",
      visual: { kind: "ring", share: placedShare },
    },
  ];

  return (
    <div className={cn("grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-6")}>
      {cards.map((card) => (
        <KpiCard key={card.key} card={card} />
      ))}
    </div>
  );
}
