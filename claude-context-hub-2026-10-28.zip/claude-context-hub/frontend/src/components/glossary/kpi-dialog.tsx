import { Link2, Search, X } from "lucide-react";
import { useEffect, useState } from "react";

import type { GlossaryKpi } from "@/api/types";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useSemanticMetrics, useUpdateKpi } from "@/hooks/queries";
import { describeError } from "@/lib/api-client";
import { cn } from "@/lib/utils";

const PERIODS = ["daily", "weekly", "monthly", "quarterly", "annual"];
const UNITS = ["percent", "ratio", "count", "currency", "days"];

function num(value: string): number | null {
  const t = value.trim();
  if (!t) return null;
  const n = Number(t);
  return Number.isFinite(n) ? n : null;
}

function KpiForm({ kpi, onClose }: { kpi: GlossaryKpi; onClose: () => void }) {
  const update = useUpdateKpi();
  const [target, setTarget] = useState(kpi.target_value === null ? "" : String(kpi.target_value));
  const [warn, setWarn] = useState(kpi.warn_value === null ? "" : String(kpi.warn_value));
  const [owner, setOwner] = useState(kpi.owner);
  const [grain, setGrain] = useState(kpi.grain);
  const [period, setPeriod] = useState(kpi.period);
  const [unit, setUnit] = useState(kpi.unit);
  const [direction, setDirection] = useState<"higher" | "lower">(kpi.direction);
  const [definition, setDefinition] = useState(kpi.definition);
  const [formula, setFormula] = useState(kpi.formula);
  const [metricId, setMetricId] = useState<string | null>(kpi.metric_id);
  const [metricLabel, setMetricLabel] = useState<string | null>(kpi.metric_name ? `${kpi.metric_name} · ${kpi.metric_asset_fqn ?? ""}` : null);
  const [query, setQuery] = useState("");
  const [debounced, setDebounced] = useState("");
  useEffect(() => {
    const t = window.setTimeout(() => setDebounced(query.trim()), 250);
    return () => window.clearTimeout(t);
  }, [query]);
  const metrics = useSemanticMetrics({ search: debounced || null, limit: 12 });

  const save = () => {
    update.mutate(
      {
        id: kpi.id,
        body: {
          target_value: num(target),
          warn_value: num(warn),
          owner: owner.trim(),
          grain: grain.trim(),
          period,
          unit,
          direction,
          definition: definition.trim(),
          formula: formula.trim(),
          ...(metricId ? { metric_id: metricId } : { clear_metric: kpi.metric_id !== null }),
        },
      },
      { onSuccess: onClose },
    );
  };

  return (
    <>
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="grid gap-1.5 sm:col-span-2">
          <Label htmlFor="kpi-def">Definition</Label>
          <Textarea id="kpi-def" value={definition} onChange={(e) => setDefinition(e.target.value)} rows={2} className="text-sm" />
        </div>
        <div className="grid gap-1.5 sm:col-span-2">
          <Label htmlFor="kpi-formula">Formula</Label>
          <Input id="kpi-formula" value={formula} onChange={(e) => setFormula(e.target.value)} className="h-8 font-mono text-xs" />
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="kpi-grain">Grain</Label>
          <Input id="kpi-grain" value={grain} onChange={(e) => setGrain(e.target.value)} className="h-8 text-sm" placeholder="policy, claim, portfolio…" />
        </div>
        <div className="grid gap-1.5">
          <Label>Period</Label>
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="h-8 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {(PERIODS.includes(period) ? PERIODS : [period, ...PERIODS]).map((p) => (
                <SelectItem key={p} value={p} className="text-xs">
                  {p}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="grid gap-1.5">
          <Label>Unit</Label>
          <Select value={unit} onValueChange={setUnit}>
            <SelectTrigger className="h-8 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {(UNITS.includes(unit) ? UNITS : [unit, ...UNITS]).map((u) => (
                <SelectItem key={u} value={u} className="text-xs">
                  {u}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="grid gap-1.5">
          <Label>Direction</Label>
          <Select value={direction} onValueChange={(v) => setDirection(v as "higher" | "lower")}>
            <SelectTrigger className="h-8 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="higher" className="text-xs">
                Higher is better
              </SelectItem>
              <SelectItem value="lower" className="text-xs">
                Lower is better
              </SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="kpi-target">Target</Label>
          <Input id="kpi-target" value={target} onChange={(e) => setTarget(e.target.value)} inputMode="decimal" className="h-8 font-mono text-sm" placeholder="e.g. 85" />
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="kpi-warn">Warning threshold</Label>
          <Input id="kpi-warn" value={warn} onChange={(e) => setWarn(e.target.value)} inputMode="decimal" className="h-8 font-mono text-sm" placeholder="e.g. 80" />
        </div>
        <div className="grid gap-1.5 sm:col-span-2">
          <Label htmlFor="kpi-owner">Owner</Label>
          <Input id="kpi-owner" value={owner} onChange={(e) => setOwner(e.target.value)} className="h-8 text-sm" placeholder="team or person accountable" />
        </div>
      </div>

      <div className="grid gap-1.5 border-t border-border/60 pt-3">
        <Label>Governed metric</Label>
        {metricId ? (
          <div className="flex items-center gap-2 rounded-lg border border-primary/40 bg-primary/10 px-2.5 py-1.5 text-xs">
            <Link2 className="h-3.5 w-3.5 shrink-0 text-primary" />
            <span className="min-w-0 flex-1 truncate" title={metricLabel ?? metricId}>
              {metricLabel ?? metricId}
            </span>
            <button
              type="button"
              className="text-muted-foreground hover:text-foreground"
              onClick={() => {
                setMetricId(null);
                setMetricLabel(null);
              }}
              title="Unbind"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        ) : (
          <p className="text-xs text-muted-foreground">Not bound. Pick the metric that computes this KPI; accepting a metric link for the KPI&apos;s term also binds it.</p>
        )}
        <div className="relative">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search governed metrics by name" className="h-8 pl-8 text-xs" />
        </div>
        <div className="max-h-44 overflow-y-auto rounded-lg border border-border/60">
          {metrics.data?.items.length ? (
            metrics.data.items.map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => {
                  setMetricId(m.id);
                  setMetricLabel(`${m.name} · ${m.asset_fqn}`);
                }}
                className={cn("flex w-full items-center gap-2 px-2.5 py-1.5 text-left text-xs hover:bg-muted/50", m.id === metricId && "bg-primary/10")}
              >
                <span className="font-mono">{m.name}</span>
                <span className="min-w-0 flex-1 truncate text-[10px] text-muted-foreground">{m.asset_fqn}</span>
                <span className="text-[10px] text-muted-foreground">{m.source}</span>
              </button>
            ))
          ) : (
            <p className="px-2.5 py-2 text-xs text-muted-foreground">{metrics.isLoading ? "Loading…" : "No metrics match."}</p>
          )}
        </div>
      </div>

      {update.error ? <p className="text-xs text-destructive">{describeError(update.error)}</p> : null}
      <div className="flex items-center justify-end gap-2">
        <Button variant="outline" size="sm" onClick={onClose}>
          Cancel
        </Button>
        <Button size="sm" onClick={save} disabled={update.isPending}>
          Save
        </Button>
      </div>
    </>
  );
}

/** Edit a KPI's definition, grain, period, unit, direction, targets and the metric that computes it. */
export function KpiDialog({ kpi, onClose }: { kpi: GlossaryKpi | null; onClose: () => void }) {
  return (
    <Dialog open={kpi !== null} onOpenChange={(open) => (open ? undefined : onClose())}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>{kpi?.name ?? "KPI"}</DialogTitle>
          <DialogDescription>
            {kpi?.domain_name ?? "No domain"}
            {kpi?.term_name ? ` · term ${kpi.term_name}` : ""}
            {kpi?.standard_ref ? ` · ${kpi.standard_ref}` : ""}. Edits mark the KPI curated.
          </DialogDescription>
        </DialogHeader>
        {kpi ? <KpiForm key={kpi.id} kpi={kpi} onClose={onClose} /> : null}
      </DialogContent>
    </Dialog>
  );
}
