import { ArrowRight, ChevronRight, CircleCheck, CircleX, ExternalLink, Layers } from "lucide-react";
import { useState } from "react";
import { Link } from "react-router-dom";

import type { GlossaryDomainNode, TermLink, TermLinkGroup, TermTargetType } from "@/api/types";
import { ConfidenceMeter, SourceBadge, TargetTypeBadge, domainIndex } from "@/components/glossary/visuals";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useDecideTermLink, useDecideTermLinks, useTermLinkGroups } from "@/hooks/queries";
import { formatInt } from "@/lib/format";
import { cn } from "@/lib/utils";

const PAGE = 50;
const NOUN: Record<TermTargetType, [string, string]> = { field: ["table", "tables"], metric: ["table", "tables"], asset: ["dataset", "datasets"] };

function pct(value: number): string {
  return `${Math.round(value * 100)}%`;
}

/** One table's link inside a group: accept or reject it alone when it is the exception. */
function GroupItem({ link }: { link: TermLink }) {
  const decide = useDecideTermLink();
  return (
    <li className="grid items-center gap-x-3 gap-y-1 px-3 py-1.5 text-xs md:grid-cols-[minmax(0,1.3fr)_minmax(0,1.4fr)_auto_auto]">
      <span className="flex min-w-0 items-center gap-2">
        <span className="truncate font-mono" title={link.target_context ?? ""}>
          {link.target_context ?? "?"}
        </span>
        {link.asset_id ? (
          <Link to={`/semantic/${link.asset_id}`} className="shrink-0 text-primary hover:underline" aria-label="Open dataset" title="Open dataset">
            <ExternalLink className="h-3 w-3" />
          </Link>
        ) : null}
      </span>
      <span className="hidden truncate text-[10px] text-muted-foreground md:inline" title={link.rationale}>
        {link.rationale}
      </span>
      <span className="flex items-center gap-2">
        <ConfidenceMeter value={link.confidence} />
        <SourceBadge source={link.source} model={link.model} />
      </span>
      <span className="flex justify-end gap-1">
        <Button
          size="sm"
          variant="ghost"
          className="h-6 px-1.5 text-success"
          disabled={decide.isPending}
          onClick={() => decide.mutate({ id: link.id, body: { decision: "accept" } })}
          title="Accept for this table only"
        >
          <CircleCheck className="h-3.5 w-3.5" />
        </Button>
        <Button
          size="sm"
          variant="ghost"
          className="h-6 px-1.5 text-muted-foreground"
          disabled={decide.isPending}
          onClick={() => decide.mutate({ id: link.id, body: { decision: "reject" } })}
          title="Reject for this table only"
        >
          <CircleX className="h-3.5 w-3.5" />
        </Button>
      </span>
    </li>
  );
}

function GroupRow({ group, color, domainName }: { group: TermLinkGroup; color: string; domainName: string | undefined }) {
  const [open, setOpen] = useState(false);
  const decide = useDecideTermLinks();
  const ids = group.links.map((l) => l.id);
  const [one, many] = NOUN[group.target_type];
  const where = `${formatInt(group.count)} ${group.count === 1 ? one : many}`;
  const range = group.min_confidence === group.max_confidence ? pct(group.max_confidence) : `${pct(group.min_confidence)}–${pct(group.max_confidence)}`;
  const label = group.count === 1 ? "" : ` all ${formatInt(group.count)}`;
  return (
    <section className="surface overflow-hidden">
      <div className="grid items-center gap-x-3 gap-y-2 px-3 py-2.5 text-xs md:grid-cols-[minmax(0,1fr)_auto_minmax(0,1.2fr)_auto_auto]">
        <button type="button" onClick={() => setOpen((v) => !v)} aria-expanded={open} className="flex min-w-0 items-center gap-2 text-left">
          <ChevronRight className={cn("h-3.5 w-3.5 shrink-0 text-muted-foreground transition-transform", open && "rotate-90")} />
          <TargetTypeBadge type={group.target_type} />
          <span className="truncate font-mono text-[13px]" title={group.target_label}>
            {group.target_label || "?"}
          </span>
        </button>
        <ArrowRight className="hidden h-3.5 w-3.5 text-muted-foreground md:block" aria-hidden="true" />
        <span className="flex min-w-0 items-center gap-1.5">
          <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: `hsl(${color})` }} aria-hidden="true" />
          <span className="truncate font-medium">{group.term_name}</span>
          {domainName ? <span className="shrink-0 text-[10px] text-muted-foreground">· {domainName}</span> : null}
        </span>
        <span className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-2 py-0.5 text-[11px] font-medium text-primary"
            title="Show the tables"
          >
            <Layers className="h-3 w-3" /> {where}
          </button>
          <span className="font-mono text-[11px] text-muted-foreground" title="confidence across the group">
            {range}
          </span>
          {group.sources.map((s) => (
            <SourceBadge key={s} source={s} />
          ))}
        </span>
        <span className="flex justify-end gap-1">
          <Button
            size="sm"
            variant="outline"
            className="h-7 gap-1 px-2 text-success"
            disabled={decide.isPending}
            onClick={() => decide.mutate({ ids, decision: "accept" })}
            title={`Accept for ${where}: synonyms are copied and datasets get the term's domain`}
          >
            <CircleCheck className="h-3.5 w-3.5" /> Accept{label}
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="h-7 gap-1 px-2 text-muted-foreground"
            disabled={decide.isPending}
            onClick={() => decide.mutate({ ids, decision: "reject" })}
            title={`Reject for ${where}`}
          >
            <CircleX className="h-3.5 w-3.5" /> Reject{label}
          </Button>
        </span>
      </div>
      {open ? (
        <ul className="divide-y divide-border/50 border-t border-border/60 bg-muted/20">
          {group.links.map((l) => (
            <GroupItem key={l.id} link={l} />
          ))}
        </ul>
      ) : null}
    </section>
  );
}

/** The review queue by column name and term, biggest groups first: one decision covers every table, open a group for exceptions. */
export function GroupedReview({ domains, type, running }: { domains: GlossaryDomainNode[] | undefined; type: TermTargetType | null; running: boolean }) {
  const [offset, setOffset] = useState(0);
  const groups = useTermLinkGroups({ status: "suggested", target_type: type, term_status: "reviewed", limit: PAGE, offset }, running ? 3000 : false);
  const index = domainIndex(domains);
  const items = groups.data?.items ?? [];
  const total = groups.data?.total ?? 0;
  const links = items.reduce((n, g) => n + g.count, 0);
  if (groups.isLoading && !groups.data) {
    return (
      <div className="space-y-2">
        {[0, 1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-12 w-full" />
        ))}
      </div>
    );
  }
  if (groups.data && !items.length) {
    return (
      <div className="surface p-8 text-center text-sm text-muted-foreground">
        Nothing to review. Run the mapping to get proposals for datasets, columns and metrics.
      </div>
    );
  }
  return (
    <div className="space-y-2">
      <p className="text-xs text-muted-foreground">
        {formatInt(total)} decisions{offset === 0 && total <= PAGE ? ` for ${formatInt(links)} suggestions` : ""}. The same column with the same term is one
        row: accept or reject it for every table at once, or open it to decide a table on its own.
      </p>
      {items.map((g) => {
        const info = g.domain_key ? index[g.domain_key] : undefined;
        return <GroupRow key={g.key} group={g} color={info?.color ?? "200 10% 55%"} domainName={info ? (info.parentName ?? info.name) : undefined} />;
      })}
      {total > PAGE ? (
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>
            {offset + 1}–{Math.min(offset + PAGE, total)} of {formatInt(total)} decisions
          </span>
          <div className="flex gap-1">
            <Button size="sm" variant="outline" disabled={offset === 0} onClick={() => setOffset(Math.max(0, offset - PAGE))}>
              Previous
            </Button>
            <Button size="sm" variant="outline" disabled={offset + PAGE >= total} onClick={() => setOffset(offset + PAGE)}>
              Next
            </Button>
          </div>
        </div>
      ) : null}
    </div>
  );
}
