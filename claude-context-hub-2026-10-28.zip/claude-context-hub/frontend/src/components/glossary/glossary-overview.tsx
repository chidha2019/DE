import { ArrowRight, Info, RefreshCw, Sparkles, WandSparkles } from "lucide-react";
import { Link } from "react-router-dom";

import type { GlossaryAutoMapRun, GlossaryAutoMapStatus, GlossaryCoverage, GlossaryMapRun } from "@/api/types";
import { CompositionBar, Gauge } from "@/components/semantic/visuals";
import { Button } from "@/components/ui/button";
import { formatInt, formatRelative } from "@/lib/format";
import { cn } from "@/lib/utils";

function RunProgress({ run }: { run: GlossaryMapRun }) {
  const finished = run.done + run.failed;
  const pct = run.total ? Math.round((finished / run.total) * 100) : 100;
  if (run.status !== "running") {
    const failed = run.status === "failed";
    return (
      <div className={cn("flex flex-wrap items-center gap-2 text-xs", failed ? "text-destructive" : "text-muted-foreground")} title={run.error ?? undefined}>
        <Info className="h-3.5 w-3.5 shrink-0" />
        <span>{run.message ?? (failed ? (run.error ?? "The run failed.") : "Done.")}</span>
        {run.rule_links + run.model_links + run.terms_proposed > 0 ? (
          <Link to="/glossary/review" className="text-primary hover:underline">
            Review the proposals
          </Link>
        ) : null}
      </div>
    );
  }
  return (
    <div className="flex min-w-0 flex-wrap items-center gap-2 text-xs text-muted-foreground">
      <div className="h-1.5 w-28 overflow-hidden rounded-full bg-muted">
        <div className="h-full bg-primary transition-all" style={{ width: `${pct}%` }} />
      </div>
      <span>
        {finished}/{run.total} {run.mode === "propose" ? "batches" : "datasets"}
        {run.failed ? <span className="text-destructive"> · {run.failed} failed</span> : null}
      </span>
      <span className="font-mono text-[10px]">
        {run.mode === "propose" ? `${formatInt(run.terms_proposed)} terms · ${formatInt(run.model_links)} links` : `${formatInt(run.rule_links + run.model_links)} proposed`}
      </span>
      {run.current ? (
        <span className="hidden max-w-[16rem] truncate font-mono text-[10px] md:inline" title={run.current}>
          {run.current}
        </span>
      ) : null}
    </div>
  );
}

const PLATFORM: Record<string, string> = { snowflake: "Snowflake", databricks: "Databricks" };

function plural(n: number, word: string) {
  return `${formatInt(n)} ${word}${n === 1 ? "" : "s"}`;
}

function LastPass({ pass }: { pass: GlossaryAutoMapRun }) {
  const when = formatRelative(pass.finished_at ?? pass.started_at);
  const sync = `${PLATFORM[pass.source_system] ?? pass.source_system} sync`;
  if (pass.status === "failed") {
    return (
      <span className="text-destructive" title={pass.error ?? undefined}>
        After the {sync} {when}: mapping failed{pass.error ? ` (${pass.error})` : ""}. The next sync tries again.
      </span>
    );
  }
  const proposed = pass.rule_links + pass.model_links;
  return (
    <span>
      After the {sync} {when}: name rules on {plural(pass.datasets, "dataset")}
      {pass.model_datasets ? `, Claude on ${formatInt(pass.model_datasets)} new or changed` : ""}
      {pass.unchanged ? `, ${formatInt(pass.unchanged)} unchanged skipped` : ""}
      {pass.model_failed ? <span className="text-destructive">, {formatInt(pass.model_failed)} failed</span> : null}.{" "}
      {proposed ? (
        <Link to="/glossary/review" className="text-primary hover:underline">
          {plural(proposed, "new proposal")} to review
        </Link>
      ) : (
        "No new proposals."
      )}
    </span>
  );
}

/** Mapping after every sync: what it does, and what the last pass proposed. */
function AutoMapPanel({ auto, live }: { auto: GlossaryAutoMapStatus; live: GlossaryMapRun | null }) {
  const last = auto.runs[0];
  const running = last?.status === "running";
  return (
    <div className="flex items-start gap-3 rounded-xl border border-primary/20 bg-primary/5 px-3 py-2.5 text-xs">
      <span className="icon-tile mt-0.5 h-8 w-8">
        <RefreshCw className={cn("h-4 w-4", running && "animate-spin")} />
      </span>
      <div className="min-w-0 flex-1 space-y-1">
        <div className="font-medium text-foreground">{auto.enabled ? "Maps after every Snowflake or Databricks sync" : "Mapping after syncs is off"}</div>
        <div className="text-muted-foreground">
          {!auto.enabled ? (
            "Set ECH_GLOSSARY_AUTO_MAP=true to propose links after each sync."
          ) : running ? (
            live ? <RunProgress run={live} /> : `Mapping after a ${PLATFORM[last.source_system] ?? last.source_system} sync…`
          ) : last ? (
            <LastPass pass={last} />
          ) : (
            `Name rules on every dataset${auto.model_available ? ", Claude on new or changed ones" : ""}. Waiting for the next sync.`
          )}
        </div>
      </div>
    </div>
  );
}

interface GlossaryOverviewProps {
  coverage: GlossaryCoverage | undefined;
  run: GlossaryMapRun | null;
  auto?: GlossaryAutoMapStatus;
  autoLive?: GlossaryMapRun | null;
  onMap: () => void;
  mapPending: boolean;
  onPropose: () => void;
  proposePending: boolean;
  error?: string | null;
}

/** The top of the glossary: how much vocabulary there is, how much of the catalog carries it, and the Claude runs. */
export function GlossaryOverview({ coverage: c, run, auto, autoLive = null, onMap, mapPending, onPropose, proposePending, error }: GlossaryOverviewProps) {
  const ratio = (n: number, d: number) => (d ? n / d : 0);
  const of = (n: number, d: number) => `${formatInt(n)} of ${formatInt(d)}`;
  const running = run?.status === "running";
  const links = c
    ? [
        { key: "suggested", label: "To review", value: c.links_suggested, color: "38 92% 52%" },
        { key: "accepted", label: "Accepted", value: c.links_accepted, color: "160 70% 45%" },
        { key: "rejected", label: "Rejected", value: c.links_rejected, color: "200 10% 55%" },
      ]
    : [];
  const gauges = c
    ? [
        { value: ratio(c.assets_with_domain, c.assets_total), label: "Placed", sub: of(c.assets_with_domain, c.assets_total), hint: "datasets with a business domain" },
        { value: ratio(c.assets_with_terms, c.assets_total), label: "Datasets", sub: of(c.assets_with_terms, c.assets_total), hint: "datasets carrying at least one accepted term" },
        { value: ratio(c.fields_with_terms, c.fields_total), label: "Columns", sub: of(c.fields_with_terms, c.fields_total), hint: "columns linked to a term" },
        { value: ratio(c.fields_with_synonyms, c.fields_total), label: "Synonyms", sub: of(c.fields_with_synonyms, c.fields_total), hint: "columns with synonyms for search and Genie" },
        { value: ratio(c.metrics_with_terms, c.metrics_total), label: "Metrics", sub: of(c.metrics_with_terms, c.metrics_total), hint: "metrics linked to a term" },
        { value: ratio(c.kpis_with_metric, c.kpis_total), label: "KPIs bound", sub: of(c.kpis_with_metric, c.kpis_total), hint: "KPI definitions bound to a governed metric" },
      ]
    : [];

  return (
    <section className="surface relative overflow-hidden p-4">
      <div className="hero-grid pointer-events-none absolute inset-0 opacity-50" aria-hidden="true" />
      <div className="pointer-events-none absolute -right-20 -top-24 h-56 w-56 rounded-full bg-primary/10 blur-3xl" aria-hidden="true" />
      <div className="relative grid gap-5 2xl:grid-cols-[minmax(0,1fr)_minmax(0,1.25fr)]">
        <div className="flex min-w-0 flex-col gap-4">
          <div>
            <div className="text-[10px] font-medium uppercase tracking-[0.2em] text-primary">Business meaning</div>
            <div className="mt-1 flex flex-wrap items-baseline gap-x-2">
              <span className="font-display text-4xl font-medium leading-none tabular-nums">{formatInt(c?.terms_total)}</span>
              <span className="text-sm text-muted-foreground">
                canonical terms in {formatInt(c?.domains_total)} domains · {formatInt(c?.kpis_total)} KPI definitions · {formatInt(c?.terms_linked)} terms in use
                {c?.terms_proposed ? <span className="text-warning"> · {formatInt(c.terms_proposed)} proposed</span> : null}
              </span>
            </div>
            <CompositionBar segments={links} height="h-2.5" className="mt-3" />
          </div>
          <div className="mt-auto flex flex-wrap items-center gap-3">
            <Button
              size="sm"
              onClick={onMap}
              disabled={mapPending || running}
              title={
                c?.model_available
                  ? "Match names and synonyms, then ask Claude to map every dataset, column and metric to a term"
                  : "Claude is not configured: only the name and synonym rules will run"
              }
            >
              <WandSparkles className="h-3.5 w-3.5" /> {running && run?.mode === "map" ? "Mapping…" : c?.model_available ? "Map with Claude" : "Map by name rules"}
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={onPropose}
              disabled={!c?.model_available || proposePending || running}
              title={
                c?.model_available
                  ? "Ask Claude for new terms, with definitions, synonyms and a domain, for the columns and metrics no term covers"
                  : "Claude is not configured"
              }
            >
              <Sparkles className="h-3.5 w-3.5" /> {running && run?.mode === "propose" ? "Proposing…" : "Propose new terms"}
            </Button>
            {run ? (
              <RunProgress run={run} />
            ) : (
              <span className="text-[11px] text-muted-foreground">Map applies the vocabulary to the catalog; propose grows the vocabulary from it. Nothing applies until you accept it.</span>
            )}
            {error ? <span className="text-xs text-destructive">{error}</span> : null}
          </div>
          {auto ? <AutoMapPanel auto={auto} live={autoLive} /> : null}
        </div>

        <div className="min-w-0">
          <div className="flex items-center justify-between gap-2">
            <div className="text-[10px] font-medium uppercase tracking-[0.2em] text-muted-foreground">Coverage · accepted links only</div>
            {c?.links_suggested ? (
              <Link to="/glossary/review" className="flex items-center gap-1 text-[11px] text-primary hover:underline">
                {formatInt(c.links_suggested)} proposals to review <ArrowRight className="h-3 w-3" />
              </Link>
            ) : null}
          </div>
          <div className="mt-2 grid gap-2" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(7.5rem, 1fr))" }}>
            {gauges.map((g) => (
              <div key={g.label} className="flex items-center justify-center rounded-xl border border-border/60 bg-background/40 px-2 py-2">
                <Gauge value={g.value} label={g.label} sub={g.sub} hint={g.hint} size={60} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
