import { ArrowRight, CheckCheck, CircleCheck, CircleX, ExternalLink } from "lucide-react";
import { useMemo, useState } from "react";
import { Link } from "react-router-dom";

import type { GlossaryDomainNode, TermLink, TermLinkStatus, TermTargetType } from "@/api/types";
import { GroupedReview } from "@/components/glossary/grouped-review";
import { ProposedTerms } from "@/components/glossary/proposed-terms";
import { ConfidenceMeter, SourceBadge, TargetTypeBadge, domainIndex } from "@/components/glossary/visuals";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useDecideTermLink, useTermLinks } from "@/hooks/queries";
import { formatDateTime, formatInt } from "@/lib/format";
import { cn } from "@/lib/utils";

const PAGE = 100;
const STATUSES: { key: TermLinkStatus; label: string }[] = [
  { key: "suggested", label: "To review" },
  { key: "accepted", label: "Accepted" },
  { key: "rejected", label: "Rejected" },
];
const TYPES: { key: TermTargetType | null; label: string }[] = [
  { key: null, label: "All" },
  { key: "asset", label: "Datasets" },
  { key: "field", label: "Columns" },
  { key: "metric", label: "Metrics" },
];

/** Proposed term links grouped by dataset, with accept and reject; accepted and rejected links for the record. */
export function ReviewQueue({ domains, running }: { domains: GlossaryDomainNode[] | undefined; running: boolean }) {
  const [status, setStatus] = useState<TermLinkStatus>("suggested");
  const [type, setType] = useState<TermTargetType | null>(null);
  // Suggestions open grouped by column and term: one decision per column name instead of one per table.
  const [grouping, setGrouping] = useState<"column" | "table">("column");
  const [offset, setOffset] = useState(0);
  // Links of proposed terms are reviewed with their term (ProposedTerms); this list covers the accepted vocabulary.
  const params = useMemo(() => ({ status, target_type: type, term_status: "reviewed", limit: PAGE, offset }), [status, type, offset]);
  const links = useTermLinks(params, running ? 3000 : false);
  const decide = useDecideTermLink();
  const index = domainIndex(domains);
  const items = links.data?.items ?? [];
  const total = links.data?.total ?? 0;
  const groups = useMemo(() => {
    const map = new Map<string, TermLink[]>();
    for (const l of items) {
      const key = l.target_context ?? "Unknown dataset";
      const rows = map.get(key);
      if (rows) rows.push(l);
      else map.set(key, [l]);
    }
    return [...map.entries()];
  }, [items]);
  const confident = items.filter((l) => l.status === "suggested" && l.confidence >= 0.85);
  const acceptAll = () => {
    for (const l of confident) decide.mutate({ id: l.id, body: { decision: "accept" } });
  };

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-3">
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex rounded-lg border border-border/80 bg-card/60 p-0.5" role="tablist" aria-label="Status">
          {STATUSES.map((s) => (
            <button
              key={s.key}
              type="button"
              role="tab"
              aria-selected={status === s.key}
              onClick={() => {
                setStatus(s.key);
                setOffset(0);
              }}
              className={cn(
                "rounded-md px-2.5 py-1 text-xs transition-colors",
                status === s.key ? "bg-primary/15 text-foreground shadow-glow" : "text-muted-foreground hover:text-foreground",
              )}
            >
              {s.label}
            </button>
          ))}
        </div>
        <div className="flex gap-1">
          {TYPES.map((t) => (
            <button
              key={t.label}
              type="button"
              onClick={() => {
                setType(t.key);
                setOffset(0);
              }}
              className={cn(
                "rounded-md border px-2 py-1 text-[11px]",
                type === t.key ? "border-primary/50 bg-primary/10" : "border-border/70 text-muted-foreground hover:text-foreground",
              )}
            >
              {t.label}
            </button>
          ))}
        </div>
        {status === "suggested" ? (
          <div className="flex rounded-lg border border-border/80 bg-card/60 p-0.5" role="radiogroup" aria-label="Group the suggestions">
            {(["column", "table"] as const).map((g) => (
              <button
                key={g}
                type="button"
                role="radio"
                aria-checked={grouping === g}
                onClick={() => setGrouping(g)}
                title={g === "column" ? "One row per column name and term, across every table" : "One section per table"}
                className={cn(
                  "rounded-md px-2.5 py-1 text-xs transition-colors",
                  grouping === g ? "bg-primary/15 text-foreground shadow-glow" : "text-muted-foreground hover:text-foreground",
                )}
              >
                {g === "column" ? "By column" : "By table"}
              </button>
            ))}
          </div>
        ) : null}
        <span className="text-xs text-muted-foreground">
          {formatInt(total)} {status}
          {running ? " · mapping in progress" : ""}
        </span>
        <span className="flex-1" />
        {status === "suggested" && grouping === "table" && confident.length ? (
          <Button size="sm" variant="outline" onClick={acceptAll} disabled={decide.isPending} title="Accept every proposal shown with at least 85 % confidence">
            <CheckCheck className="h-3.5 w-3.5" /> Accept {confident.length} at 85%+
          </Button>
        ) : null}
      </div>

      {status === "suggested" ? <ProposedTerms domains={domains} running={running} /> : null}

      {status === "suggested" && grouping === "column" ? (
        <GroupedReview domains={domains} type={type} running={running} />
      ) : (
        <>
          {links.isLoading && !links.data ? (
            <div className="space-y-2">
              {[0, 1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : null}
          {links.data && items.length === 0 ? (
            <div className="surface p-8 text-center text-sm text-muted-foreground">
              {status === "suggested" ? "Nothing to review. Run the mapping to get proposals for datasets, columns and metrics." : `No ${status} links yet.`}
            </div>
          ) : null}

          <div className="space-y-3">
            {groups.map(([context, rows]) => {
              const first = rows[0];
              return (
                <section key={context} className="surface overflow-hidden">
                  <header className="flex items-center gap-2 border-b border-border/60 bg-muted/30 px-3 py-1.5 text-xs">
                    <span className="truncate font-mono" title={context}>
                      {context}
                    </span>
                    <span className="shrink-0 text-[10px] text-muted-foreground">
                      {rows.length} link{rows.length === 1 ? "" : "s"}
                    </span>
                    <span className="flex-1" />
                    {first?.asset_id ? (
                      <Link to={`/semantic/${first.asset_id}`} className="flex shrink-0 items-center gap-1 text-[11px] text-primary hover:underline">
                        Open dataset <ExternalLink className="h-3 w-3" />
                      </Link>
                    ) : null}
                  </header>
                  <div className="divide-y divide-border/50">
                    {rows.map((l) => {
                      const info = l.domain_key ? index[l.domain_key] : undefined;
                      return (
                        <div
                          key={l.id}
                          className="grid items-center gap-x-3 gap-y-1 px-3 py-2 text-xs md:grid-cols-[minmax(0,1.1fr)_auto_minmax(0,1.4fr)_auto_auto]"
                        >
                          <span className="flex min-w-0 items-center gap-2">
                            <TargetTypeBadge type={l.target_type} />
                            <span className="truncate font-mono" title={l.target_label ?? ""}>
                              {l.target_label ?? "?"}
                            </span>
                          </span>
                          <ArrowRight className="hidden h-3.5 w-3.5 text-muted-foreground md:block" aria-hidden="true" />
                          <span className="flex min-w-0 items-center gap-1.5">
                            <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: `hsl(${info?.color ?? "200 10% 55%"})` }} aria-hidden="true" />
                            <span className="shrink-0 font-medium">{l.term_name}</span>
                            {info ? <span className="shrink-0 text-[10px] text-muted-foreground">· {info.parentName ?? info.name}</span> : null}
                            <span className="hidden truncate text-[10px] text-muted-foreground lg:inline" title={l.rationale}>
                              {l.rationale}
                            </span>
                          </span>
                          <span className="flex items-center gap-2">
                            <ConfidenceMeter value={l.confidence} />
                            <SourceBadge source={l.source} model={l.model} />
                          </span>
                          <span className="flex justify-end gap-1">
                            {l.status === "suggested" ? (
                              <>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="h-7 px-2 text-success"
                                  disabled={decide.isPending}
                                  onClick={() => decide.mutate({ id: l.id, body: { decision: "accept" } })}
                                  title="Accept: the term applies; its synonyms are copied and the dataset gets the domain"
                                >
                                  <CircleCheck className="h-3.5 w-3.5" /> Accept
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="h-7 px-2 text-muted-foreground"
                                  disabled={decide.isPending}
                                  onClick={() => decide.mutate({ id: l.id, body: { decision: "reject" } })}
                                  title="Reject"
                                >
                                  <CircleX className="h-3.5 w-3.5" />
                                </Button>
                              </>
                            ) : (
                              <span className="text-[10px] text-muted-foreground">
                                {l.status}
                                {l.decided_at ? ` · ${formatDateTime(l.decided_at)}` : ""}
                              </span>
                            )}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </section>
              );
            })}
          </div>
          {total > PAGE ? (
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>
                {offset + 1}–{Math.min(offset + PAGE, total)} of {formatInt(total)}
              </span>
              <div className="flex gap-1">
                <Button size="sm" variant="outline" disabled={offset === 0} onClick={() => setOffset(Math.max(0, offset - PAGE))}>
                  Previous
                </Button>
                <Button size="sm" variant="outline" disabled={offset + PAGE >= total} onClick={() => setOffset(offset + PAGE)}>
                  Next
                </Button>
              </div>
            </div>
          ) : null}
        </>
      )}
    </div>
  );
}
