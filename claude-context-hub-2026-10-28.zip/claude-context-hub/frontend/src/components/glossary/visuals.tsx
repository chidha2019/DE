import {
  BookOpen,
  Building2,
  Calculator,
  CalendarRange,
  Coins,
  Database,
  FileSearch,
  Fingerprint,
  Handshake,
  Hash,
  Headset,
  HeartPulse,
  Landmark,
  Layers,
  Receipt,
  Scroll,
  Shield,
  ShieldCheck,
  Sigma,
  Table2,
  Tags,
  Umbrella,
  type LucideIcon,
} from "lucide-react";

import type { GlossaryDomainNode, GlossaryStandard, GlossaryTermKind, TermLinkSource, TermLinkStatus, TermTargetType } from "@/api/types";
import { Badge } from "@/components/ui/badge";
import { formatPercent } from "@/lib/format";
import { cn } from "@/lib/utils";

/** Where a term or domain comes from: the ACORD insurance models, FIBO, or this hub. */
export const STANDARD_COLOR: Record<GlossaryStandard, string> = { acord: "205 80% 55%", fibo: "262 70% 62%", hub: "172 66% 45%" };
export const STANDARD_LABEL: Record<GlossaryStandard, string> = { acord: "ACORD", fibo: "FIBO", hub: "Hub" };
export const STANDARD_HINT: Record<GlossaryStandard, string> = {
  acord: "Aligned to the ACORD insurance capability and information models",
  fibo: "A party, contract or money concept from the Financial Industry Business Ontology",
  hub: "Defined in this hub for insurance data the standards leave open",
};

export const TERM_KINDS: GlossaryTermKind[] = ["entity", "attribute", "measure", "event", "code"];
export const TERM_KIND_COLOR: Record<GlossaryTermKind, string> = {
  entity: "217 85% 60%",
  attribute: "188 80% 46%",
  measure: "160 70% 45%",
  event: "38 92% 52%",
  code: "262 70% 62%",
};
export const TERM_KIND_ICON: Record<GlossaryTermKind, LucideIcon> = { entity: Landmark, attribute: Tags, measure: Sigma, event: CalendarRange, code: Hash };
export const TERM_KIND_LABEL: Record<GlossaryTermKind, string> = { entity: "Entity", attribute: "Attribute", measure: "Measure", event: "Event", code: "Code list" };

export interface DomainStyle {
  color: string;
  icon: LucideIcon;
}
/** One hue and icon per top-level insurance domain; sub-domains inherit their parent's. */
const DOMAIN_STYLE: Record<string, DomainStyle> = {
  party: { color: "262 70% 62%", icon: Handshake },
  product: { color: "199 90% 55%", icon: Umbrella },
  distribution: { color: "28 90% 55%", icon: Building2 },
  underwriting: { color: "188 80% 46%", icon: FileSearch },
  policy: { color: "217 85% 60%", icon: Scroll },
  billing: { color: "45 90% 50%", icon: Receipt },
  claims: { color: "347 77% 58%", icon: HeartPulse },
  reinsurance: { color: "330 75% 60%", icon: Shield },
  actuarial: { color: "160 70% 45%", icon: Calculator },
  finance: { color: "90 55% 45%", icon: Coins },
  service: { color: "14 88% 56%", icon: Headset },
  risk: { color: "0 70% 55%", icon: Fingerprint },
  data_platform: { color: "200 10% 55%", icon: Database },
};
const FALLBACK: DomainStyle = { color: "200 10% 55%", icon: BookOpen };

export function domainStyle(key: string | null | undefined, parentKey?: string | null): DomainStyle {
  return (key ? DOMAIN_STYLE[key] : undefined) ?? (parentKey ? DOMAIN_STYLE[parentKey] : undefined) ?? FALLBACK;
}

export interface DomainInfo extends DomainStyle {
  name: string;
  parentKey: string | null;
  parentName: string | null;
}
/** key -> style and names for every domain in the tree. */
export function domainIndex(domains: GlossaryDomainNode[] | undefined): Record<string, DomainInfo> {
  const out: Record<string, DomainInfo> = {};
  for (const d of domains ?? []) {
    const style = domainStyle(d.key);
    out[d.key] = { ...style, name: d.name, parentKey: null, parentName: null };
    for (const c of d.children) out[c.key] = { ...style, name: c.name, parentKey: d.key, parentName: d.name };
  }
  return out;
}

export function Tile({ color, icon: Icon, className, iconClass = "h-4 w-4", title }: { color: string; icon: LucideIcon; className?: string; iconClass?: string; title?: string }) {
  return (
    <span
      className={cn("flex shrink-0 items-center justify-center rounded-xl border text-white", className ?? "h-9 w-9")}
      style={{
        background: `linear-gradient(135deg, hsl(${color}), hsl(${color} / 0.6))`,
        borderColor: `hsl(${color} / 0.5)`,
        boxShadow: `0 8px 20px -12px hsl(${color} / 0.9), inset 0 1px 0 0 hsl(0 0% 100% / 0.25)`,
      }}
      title={title}
    >
      <Icon className={iconClass} />
    </span>
  );
}

export function KindTile({ kind, className, iconClass }: { kind: GlossaryTermKind; className?: string; iconClass?: string }) {
  return <Tile color={TERM_KIND_COLOR[kind]} icon={TERM_KIND_ICON[kind]} className={className} iconClass={iconClass} title={TERM_KIND_LABEL[kind]} />;
}

export function StandardBadge({ standard, reference }: { standard: GlossaryStandard; reference?: string }) {
  return (
    <Badge variant="outline" className="gap-1 font-normal" title={reference || STANDARD_HINT[standard]}>
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: `hsl(${STANDARD_COLOR[standard]})` }} aria-hidden="true" />
      {STANDARD_LABEL[standard]}
    </Badge>
  );
}

const confidenceTone = (v: number) => (v >= 0.85 ? "bg-success" : v >= 0.6 ? "bg-primary" : "bg-warning");

/** A short bar with the percentage: green from 85 %, teal from 60 %, amber below. */
export function ConfidenceMeter({ value, className }: { value: number; className?: string }) {
  const v = Math.max(0, Math.min(1, value));
  return (
    <span className={cn("inline-flex items-center gap-1.5", className)} title={`${formatPercent(v)} confidence`}>
      <span className="h-1.5 w-14 overflow-hidden rounded-full bg-muted">
        <span className={cn("block h-full rounded-full", confidenceTone(v))} style={{ width: `${Math.max(4, v * 100)}%` }} />
      </span>
      <span className="font-mono text-[10px] tabular-nums text-muted-foreground">{formatPercent(v)}</span>
    </span>
  );
}

export function SourceBadge({ source, model }: { source: TermLinkSource; model?: string | null }) {
  if (source === "model") {
    return (
      <Badge variant="info" title={model ? `Proposed by ${model}` : "Proposed by Claude"}>
        Claude
      </Badge>
    );
  }
  if (source === "curated") return <Badge variant="success">Curated</Badge>;
  return (
    <Badge variant="muted" title="Matched by name or synonym">
      Name rule
    </Badge>
  );
}

export function StatusBadge({ status }: { status: TermLinkStatus }) {
  const variant = status === "accepted" ? "success" : status === "rejected" ? "muted" : "warning";
  return <Badge variant={variant}>{status}</Badge>;
}

export const TARGET_LABEL: Record<TermTargetType, string> = { asset: "Dataset", field: "Column", metric: "Metric" };
const TARGET_ICON: Record<TermTargetType, LucideIcon> = { asset: Layers, field: Table2, metric: ShieldCheck };

export function TargetTypeBadge({ type }: { type: TermTargetType }) {
  const Icon = TARGET_ICON[type];
  return (
    <Badge variant="outline" className="gap-1 font-normal">
      <Icon className="h-3 w-3" />
      {TARGET_LABEL[type]}
    </Badge>
  );
}
