import { ArrowRight, BookOpen } from "lucide-react";
import { Link } from "react-router-dom";

import { domainIndex } from "@/components/glossary/visuals";
import { useGlossaryDomains, useTermLinks } from "@/hooks/queries";

/** The business terms a dataset carries, shown on its detail: domain, dataset-level terms, column and metric counts, proposals. */
export function AssetTermChips({ assetId }: { assetId: string }) {
  const accepted = useTermLinks({ asset_id: assetId, status: "accepted", limit: 200 });
  const suggested = useTermLinks({ asset_id: assetId, status: "suggested", limit: 1 });
  const domains = useGlossaryDomains();
  const index = domainIndex(domains.data);
  const links = accepted.data?.items ?? [];
  const onAsset = links.filter((l) => l.target_type === "asset");
  const columns = links.filter((l) => l.target_type === "field").length;
  const metrics = links.filter((l) => l.target_type === "metric").length;
  const pending = suggested.data?.total ?? 0;
  const domainKey = onAsset[0]?.domain_key ?? null;
  const domain = domainKey ? index[domainKey] : undefined;
  if (!accepted.data) return null;
  return (
    <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
      <BookOpen className="h-3.5 w-3.5 text-muted-foreground" aria-hidden="true" />
      {domain ? (
        <span className="rounded-md px-1.5 py-px text-white" style={{ background: `hsl(${domain.color})` }} title="business domain">
          {domain.parentName ?? domain.name}
        </span>
      ) : null}
      {onAsset.map((l) => {
        const info = l.domain_key ? index[l.domain_key] : undefined;
        return (
          <Link
            key={l.id}
            to={`/glossary/terms?search=${encodeURIComponent(l.term_name)}`}
            className="rounded-md border px-1.5 py-px transition-colors hover:border-primary/60"
            style={{ borderColor: `hsl(${info?.color ?? "200 10% 55%"} / 0.5)` }}
            title={l.rationale}
          >
            {l.term_name}
          </Link>
        );
      })}
      {onAsset.length === 0 ? <span className="text-muted-foreground">No business terms yet</span> : null}
      {columns || metrics ? (
        <span className="text-muted-foreground">
          · {columns} column{columns === 1 ? "" : "s"}
          {metrics ? `, ${metrics} metric${metrics === 1 ? "" : "s"}` : ""} carry terms
        </span>
      ) : null}
      {pending ? (
        <Link to="/glossary/review" className="flex items-center gap-0.5 text-warning hover:underline">
          {pending} proposal{pending === 1 ? "" : "s"} to review <ArrowRight className="h-3 w-3" />
        </Link>
      ) : (
        <Link to="/glossary" className="flex items-center gap-0.5 text-primary hover:underline">
          Glossary <ArrowRight className="h-3 w-3" />
        </Link>
      )}
    </div>
  );
}
