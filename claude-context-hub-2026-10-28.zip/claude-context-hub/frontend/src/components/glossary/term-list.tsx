import { Plus, Search, Sparkles } from "lucide-react";

import type { GlossaryDomainNode, GlossaryTermKind, GlossaryTermRow, Page } from "@/api/types";
import { KindTile, StandardBadge, TERM_KINDS, TERM_KIND_COLOR, TERM_KIND_LABEL, domainIndex } from "@/components/glossary/visuals";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { formatInt } from "@/lib/format";
import { cn } from "@/lib/utils";

interface TermListProps {
  page: Page<GlossaryTermRow> | undefined;
  loading: boolean;
  domains: GlossaryDomainNode[] | undefined;
  search: string;
  onSearch: (value: string) => void;
  kind: GlossaryTermKind | null;
  onKind: (kind: GlossaryTermKind | null) => void;
  onOpen: (term: GlossaryTermRow) => void;
  onCreate: () => void;
  offset: number;
  onOffset: (offset: number) => void;
  pageSize: number;
}

const GRID = { gridTemplateColumns: "repeat(auto-fill, minmax(17rem, 1fr))" };

function TermCard({ term, domainName, domainColor, onOpen }: { term: GlossaryTermRow; domainName: string | null; domainColor: string; onOpen: () => void }) {
  const shown = term.synonyms.slice(0, 4);
  const more = term.synonyms.length - shown.length;
  const linked = term.linked_assets + term.linked_fields + term.linked_metrics;
  return (
    <button
      type="button"
      onClick={onOpen}
      className="group relative flex flex-col overflow-hidden rounded-xl border border-border/70 bg-background/50 p-3 text-left transition-all hover:-translate-y-0.5 hover:border-primary/50"
    >
      <span className="absolute inset-x-0 top-0 h-[2px]" style={{ background: `linear-gradient(90deg, hsl(${domainColor}), hsl(${domainColor} / 0.1))` }} aria-hidden="true" />
      <span className="flex items-start gap-2.5">
        <KindTile kind={term.kind} className="h-9 w-9" iconClass="h-4 w-4" />
        <span className="min-w-0 flex-1">
          <span className="flex flex-wrap items-center gap-1.5">
            <span className="truncate font-display text-sm font-medium leading-tight">{term.name}</span>
            <StandardBadge standard={term.standard} reference={term.standard_ref} />
            {term.status === "curated" ? <span className="rounded-md bg-primary/15 px-1.5 py-px text-[10px] text-primary">curated</span> : null}
            {term.status === "proposed" ? <span className="rounded-md bg-warning/15 px-1.5 py-px text-[10px] text-warning">proposed</span> : null}
          </span>
          <span className="block truncate text-[10px] text-muted-foreground">
            {domainName ?? "No domain"} · {TERM_KIND_LABEL[term.kind]}
          </span>
        </span>
        {term.suggested ? (
          <span className="shrink-0 rounded-md bg-warning/15 px-1.5 py-0.5 font-mono text-[10px] text-warning" title={`${term.suggested} proposals to review`}>
            <Sparkles className="mr-0.5 inline h-3 w-3" />
            {term.suggested}
          </span>
        ) : null}
      </span>
      <span className="mt-2 line-clamp-2 text-xs text-muted-foreground">{term.definition || "No definition yet."}</span>
      {shown.length ? (
        <span className="mt-2 flex flex-wrap gap-1">
          {shown.map((s) => (
            <span key={s} className="rounded-md border border-border/60 bg-card/60 px-1.5 py-px text-[10px] text-muted-foreground">
              {s}
            </span>
          ))}
          {more > 0 ? <span className="px-1 text-[10px] text-muted-foreground">+{more}</span> : null}
        </span>
      ) : null}
      <span className="mt-auto flex items-center gap-3 pt-2 font-mono text-[10px] tabular-nums text-muted-foreground">
        <span title="datasets carrying this term">{formatInt(term.linked_assets)} datasets</span>
        <span title="columns carrying this term">{formatInt(term.linked_fields)} columns</span>
        <span title="metrics carrying this term">{formatInt(term.linked_metrics)} metrics</span>
        {linked === 0 ? <span className="ml-auto text-muted-foreground/70">not in use yet</span> : null}
      </span>
    </button>
  );
}

/** Term cards with search, kind filter and paging. */
export function TermList({ page, loading, domains, search, onSearch, kind, onKind, onOpen, onCreate, offset, onOffset, pageSize }: TermListProps) {
  const index = domainIndex(domains);
  const total = page?.total ?? 0;
  return (
    <div className="flex min-h-0 flex-1 flex-col gap-3">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative min-w-[14rem] flex-1">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
          <Input value={search} onChange={(e) => onSearch(e.target.value)} placeholder="Search terms, synonyms and definitions" className="h-8 pl-8 text-xs" />
        </div>
        <div className="flex flex-wrap gap-1" role="tablist" aria-label="Kind">
          <button
            type="button"
            onClick={() => onKind(null)}
            className={cn("rounded-md border px-2 py-1 text-[11px]", kind === null ? "border-primary/50 bg-primary/10" : "border-border/70 text-muted-foreground hover:text-foreground")}
          >
            All kinds
          </button>
          {TERM_KINDS.map((k) => (
            <button
              key={k}
              type="button"
              onClick={() => onKind(kind === k ? null : k)}
              className={cn(
                "flex items-center gap-1 rounded-md border px-2 py-1 text-[11px]",
                kind === k ? "border-primary/50 bg-primary/10" : "border-border/70 text-muted-foreground hover:text-foreground",
              )}
            >
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: `hsl(${TERM_KIND_COLOR[k]})` }} aria-hidden="true" />
              {TERM_KIND_LABEL[k]}
            </button>
          ))}
        </div>
        <Button size="sm" variant="outline" onClick={onCreate}>
          <Plus className="h-3.5 w-3.5" /> New term
        </Button>
      </div>
      {loading && !page ? (
        <div className="grid gap-2" style={GRID}>
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <Skeleton key={i} className="h-40 w-full" />
          ))}
        </div>
      ) : null}
      {page && page.items.length === 0 ? <div className="surface p-8 text-center text-sm text-muted-foreground">No terms match. Clear the filters or add a term.</div> : null}
      {page && page.items.length ? (
        <div className="grid gap-2" style={GRID}>
          {page.items.map((t) => {
            const info = t.domain_key ? index[t.domain_key] : undefined;
            return <TermCard key={t.id} term={t} domainName={info?.name ?? t.domain_name} domainColor={info?.color ?? "200 10% 55%"} onOpen={() => onOpen(t)} />;
          })}
        </div>
      ) : null}
      {total > pageSize ? (
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>
            {offset + 1}–{Math.min(offset + pageSize, total)} of {formatInt(total)}
          </span>
          <div className="flex gap-1">
            <Button size="sm" variant="outline" disabled={offset === 0} onClick={() => onOffset(Math.max(0, offset - pageSize))}>
              Previous
            </Button>
            <Button size="sm" variant="outline" disabled={offset + pageSize >= total} onClick={() => onOffset(offset + pageSize)}>
              Next
            </Button>
          </div>
        </div>
      ) : null}
    </div>
  );
}
