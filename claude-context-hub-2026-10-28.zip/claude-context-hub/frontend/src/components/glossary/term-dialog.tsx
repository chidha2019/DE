import { ExternalLink } from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import type { GlossaryDomainNode, GlossaryTermKind, GlossaryTermRow, TermLink } from "@/api/types";
import { ConfidenceMeter, KindTile, SourceBadge, StandardBadge, StatusBadge, TERM_KINDS, TERM_KIND_LABEL, TargetTypeBadge } from "@/components/glossary/visuals";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useCreateTerm, useDecideTermLink, useGlossaryTerm, useUpdateTerm } from "@/hooks/queries";
import { describeError } from "@/lib/api-client";

const NONE = "__none__";

interface TermDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** null creates a new term. */
  term: GlossaryTermRow | null;
  domains: GlossaryDomainNode[] | undefined;
  defaultDomain?: string | null;
}

function LinkRow({ link }: { link: TermLink }) {
  const decide = useDecideTermLink();
  return (
    <div className="flex flex-wrap items-center gap-2 rounded-lg border border-border/60 bg-background/40 px-2.5 py-1.5 text-xs">
      <TargetTypeBadge type={link.target_type} />
      <span className="min-w-0 flex-1 truncate">
        <span className="font-mono">{link.target_label ?? "?"}</span>
        {link.target_type !== "asset" && link.target_context ? <span className="ml-1 text-[10px] text-muted-foreground">in {link.target_context}</span> : null}
      </span>
      <ConfidenceMeter value={link.confidence} />
      <SourceBadge source={link.source} model={link.model} />
      <StatusBadge status={link.status} />
      {link.status === "suggested" ? (
        <span className="flex gap-1">
          <Button size="sm" variant="outline" className="h-6 px-2 text-[11px] text-success" disabled={decide.isPending} onClick={() => decide.mutate({ id: link.id, body: { decision: "accept" } })}>
            Accept
          </Button>
          <Button size="sm" variant="outline" className="h-6 px-2 text-[11px] text-muted-foreground" disabled={decide.isPending} onClick={() => decide.mutate({ id: link.id, body: { decision: "reject" } })}>
            Reject
          </Button>
        </span>
      ) : null}
      {link.asset_id ? (
        <Link to={`/semantic/${link.asset_id}`} className="text-muted-foreground hover:text-foreground" title="Open the dataset">
          <ExternalLink className="h-3.5 w-3.5" />
        </Link>
      ) : null}
    </div>
  );
}

/** Create or edit a term; for an existing term, also where it is used, with review actions. */
export function TermDialog({ open, onOpenChange, term, domains, defaultDomain = null }: TermDialogProps) {
  const detail = useGlossaryTerm(open && term ? term.id : null);
  const create = useCreateTerm();
  const update = useUpdateTerm();
  const [name, setName] = useState("");
  const [definition, setDefinition] = useState("");
  const [synonyms, setSynonyms] = useState("");
  const [kind, setKind] = useState<GlossaryTermKind>("entity");
  const [domain, setDomain] = useState<string>(NONE);

  useEffect(() => {
    if (!open) return;
    setName(term?.name ?? "");
    setDefinition(term?.definition ?? "");
    setSynonyms(term?.synonyms.join(", ") ?? "");
    setKind(term?.kind ?? "entity");
    setDomain(term?.domain_key ?? defaultDomain ?? NONE);
    create.reset();
    update.reset();
    // eslint-disable-next-line react-hooks/exhaustive-deps -- the form resets when the dialog opens for a term
  }, [term, defaultDomain, open]);

  const pending = create.isPending || update.isPending;
  const error = create.error ?? update.error;
  const save = () => {
    const body = {
      name: name.trim(),
      definition: definition.trim(),
      kind,
      domain_key: domain === NONE ? null : domain,
      synonyms: synonyms
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean),
    };
    if (!body.name) return;
    if (term) update.mutate({ id: term.id, body }, { onSuccess: () => onOpenChange(false) });
    else create.mutate(body, { onSuccess: () => onOpenChange(false) });
  };
  const links = detail.data?.links ?? [];
  const suggested = links.filter((l) => l.status === "suggested");
  const accepted = links.filter((l) => l.status === "accepted");
  const rejected = links.filter((l) => l.status === "rejected");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex flex-wrap items-center gap-2">
            <KindTile kind={kind} className="h-8 w-8" iconClass="h-3.5 w-3.5" />
            {term ? term.name : "New business term"}
            {term ? <StandardBadge standard={term.standard} reference={term.standard_ref} /> : null}
          </DialogTitle>
          <DialogDescription>
            {term
              ? `${term.standard_ref || "Defined in this hub"}. Edits mark the term curated; synonyms feed search, Genie and the name rules.`
              : "A canonical name, its meaning and the words people use for it. Synonyms feed search, Genie and the name rules."}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="grid gap-1.5 sm:col-span-2">
            <Label htmlFor="term-name">Name</Label>
            <Input id="term-name" value={name} onChange={(e) => setName(e.target.value)} className="h-8 text-sm" />
          </div>
          <div className="grid gap-1.5">
            <Label>Kind</Label>
            <Select value={kind} onValueChange={(v) => setKind(v as GlossaryTermKind)}>
              <SelectTrigger className="h-8 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {TERM_KINDS.map((k) => (
                  <SelectItem key={k} value={k} className="text-xs">
                    {TERM_KIND_LABEL[k]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-1.5">
            <Label>Domain</Label>
            <Select value={domain} onValueChange={setDomain}>
              <SelectTrigger className="h-8 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={NONE} className="text-xs">
                  No domain
                </SelectItem>
                {(domains ?? []).flatMap((d) => [
                  <SelectItem key={d.key} value={d.key} className="text-xs">
                    {d.name}
                  </SelectItem>,
                  ...d.children.map((c) => (
                    <SelectItem key={c.key} value={c.key} className="pl-6 text-xs">
                      {c.name}
                    </SelectItem>
                  )),
                ])}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-1.5 sm:col-span-2">
            <Label htmlFor="term-def">Definition</Label>
            <Textarea id="term-def" value={definition} onChange={(e) => setDefinition(e.target.value)} rows={3} className="text-sm" />
          </div>
          <div className="grid gap-1.5 sm:col-span-2">
            <Label htmlFor="term-syn">
              Synonyms <span className="font-normal text-muted-foreground">(comma separated)</span>
            </Label>
            <Input id="term-syn" value={synonyms} onChange={(e) => setSynonyms(e.target.value)} className="h-8 text-sm" placeholder="policy owner, contract holder" />
          </div>
        </div>
        {error ? <p className="text-xs text-destructive">{describeError(error)}</p> : null}
        <div className="flex items-center justify-end gap-2">
          <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button size="sm" onClick={save} disabled={pending || !name.trim()}>
            {term ? "Save" : "Create"}
          </Button>
        </div>
        {term ? (
          <div className="space-y-2 border-t border-border/60 pt-3">
            <div className="flex items-center justify-between text-[10px] font-medium uppercase tracking-[0.2em] text-muted-foreground">
              <span>Where it is used</span>
              <span>
                {accepted.length} accepted · {suggested.length} to review
              </span>
            </div>
            {detail.isLoading ? <p className="text-xs text-muted-foreground">Loading…</p> : null}
            {!detail.isLoading && links.length === 0 ? (
              <p className="text-xs text-muted-foreground">Not linked to any dataset, column or metric yet. Run the mapping, or accept a proposal from the review queue.</p>
            ) : null}
            {[...suggested, ...accepted, ...rejected].slice(0, 80).map((l) => (
              <LinkRow key={l.id} link={l} />
            ))}
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}
