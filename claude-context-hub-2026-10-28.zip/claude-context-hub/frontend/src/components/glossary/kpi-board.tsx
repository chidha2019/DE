import { ArrowDownRight, ArrowUpRight, Link2, Target } from "lucide-react";
import { useState } from "react";
import { Link } from "react-router-dom";

import type { GlossaryDomainNode, GlossaryKpi } from "@/api/types";
import { KpiDialog } from "@/components/glossary/kpi-dialog";
import { Tile, domainIndex } from "@/components/glossary/visuals";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

const GRID = { gridTemplateColumns: "repeat(auto-fill, minmax(17rem, 1fr))" };

function formatValue(value: number | null, unit: string): string {
  if (value === null) return "–";
  const n = Number.isInteger(value) ? value.toString() : value.toFixed(2).replace(/\.?0+$/, "");
  if (unit === "percent") return `${n}%`;
  if (unit === "days") return `${n} d`;
  if (unit === "ratio") return `${n}×`;
  return n;
}

function Targets({ kpi }: { kpi: GlossaryKpi }) {
  if (kpi.target_value === null) return <span className="text-[10px] text-muted-foreground">No target set</span>;
  const lower = kpi.direction === "lower";
  return (
    <div className="flex flex-wrap items-center gap-1.5 text-[10px]">
      <span className="rounded-md bg-success/15 px-1.5 py-px font-mono text-success" title="target">
        target {lower ? "≤" : "≥"} {formatValue(kpi.target_value, kpi.unit)}
      </span>
      {kpi.warn_value !== null ? (
        <span className="rounded-md bg-warning/15 px-1.5 py-px font-mono text-warning" title="warning threshold">
          warn {lower ? ">" : "<"} {formatValue(kpi.warn_value, kpi.unit)}
        </span>
      ) : null}
    </div>
  );
}

function KpiCard({ kpi, color, onEdit }: { kpi: GlossaryKpi; color: string; onEdit: () => void }) {
  const Dir = kpi.direction === "higher" ? ArrowUpRight : ArrowDownRight;
  return (
    <div className="group relative flex flex-col overflow-hidden rounded-xl border border-border/70 bg-background/50 p-3 transition-all hover:border-primary/50">
      <span className="absolute inset-x-0 top-0 h-[2px]" style={{ background: `linear-gradient(90deg, hsl(${color}), hsl(${color} / 0.1))` }} aria-hidden="true" />
      <div className="flex items-start gap-2.5">
        <Tile color={color} icon={Target} className="h-9 w-9" iconClass="h-4 w-4" />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="truncate font-display text-sm font-medium leading-tight">{kpi.name}</span>
            <span
              className={cn("flex items-center gap-0.5 rounded-md px-1 py-px text-[10px]", kpi.direction === "higher" ? "bg-success/10 text-success" : "bg-blue-500/10 text-blue-500")}
              title={kpi.direction === "higher" ? "Higher is better" : "Lower is better"}
            >
              <Dir className="h-3 w-3" />
              {kpi.direction}
            </span>
            {kpi.status === "curated" ? <span className="rounded-md bg-primary/15 px-1.5 py-px text-[10px] text-primary">curated</span> : null}
          </div>
          <div className="truncate text-[10px] text-muted-foreground">
            {kpi.domain_name ?? "No domain"}
            {kpi.term_name ? ` · ${kpi.term_name}` : ""}
            {kpi.owner ? ` · ${kpi.owner}` : ""}
          </div>
        </div>
      </div>
      <p className="mt-2 line-clamp-2 text-xs text-muted-foreground">{kpi.definition}</p>
      {kpi.formula ? (
        <code className="mt-1.5 block truncate rounded-md bg-muted/50 px-2 py-1 font-mono text-[10px]" title={kpi.formula}>
          {kpi.formula}
        </code>
      ) : null}
      <div className="mt-2 flex flex-wrap gap-1 text-[10px]">
        <span className="rounded-md border border-border/60 px-1.5 py-px text-muted-foreground" title="grain: what one value is about">
          grain · {kpi.grain || "–"}
        </span>
        <span className="rounded-md border border-border/60 px-1.5 py-px text-muted-foreground" title="period">
          {kpi.period}
        </span>
        <span className="rounded-md border border-border/60 px-1.5 py-px text-muted-foreground" title="unit">
          {kpi.unit}
        </span>
      </div>
      <div className="mt-2">
        <Targets kpi={kpi} />
      </div>
      <div className="mt-auto flex items-center gap-2 pt-2 text-[11px]">
        {kpi.metric_id ? (
          <Link
            to={kpi.metric_asset_id ? `/semantic/${kpi.metric_asset_id}` : "/semantic"}
            className="flex min-w-0 items-center gap-1 text-primary hover:underline"
            title={kpi.metric_asset_fqn ?? ""}
          >
            <Link2 className="h-3 w-3 shrink-0" />
            <span className="truncate">{kpi.metric_name}</span>
          </Link>
        ) : (
          <span className="flex items-center gap-1 text-muted-foreground">
            <Link2 className="h-3 w-3" /> No governed metric bound
          </span>
        )}
        <span className="flex-1" />
        <Button size="sm" variant="outline" className="h-6 px-2 text-[11px]" onClick={onEdit}>
          Edit
        </Button>
      </div>
    </div>
  );
}

/** KPI definitions as cards: grain, period, unit, direction, targets and the metric that computes each one. */
export function KpiBoard({ kpis, loading, domains }: { kpis: GlossaryKpi[] | undefined; loading: boolean; domains: GlossaryDomainNode[] | undefined }) {
  const [editing, setEditing] = useState<GlossaryKpi | null>(null);
  const index = domainIndex(domains);
  const list = kpis ?? [];
  const bound = list.filter((k) => k.metric_id).length;
  const targeted = list.filter((k) => k.target_value !== null).length;
  return (
    <div className="flex min-h-0 flex-1 flex-col gap-3">
      <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
        <span>
          <span className="font-mono text-foreground">{list.length}</span> KPI definitions
        </span>
        <span>
          <span className="font-mono text-foreground">{bound}</span> bound to a governed metric
        </span>
        <span>
          <span className="font-mono text-foreground">{targeted}</span> with a target
        </span>
        <span className="flex-1" />
        <span className="hidden md:inline">Accepting a metric link for a KPI&apos;s term binds the metric automatically.</span>
      </div>
      {loading && !kpis ? (
        <div className="grid gap-2" style={GRID}>
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <Skeleton key={i} className="h-52 w-full" />
          ))}
        </div>
      ) : null}
      {kpis && kpis.length === 0 ? <div className="surface p-8 text-center text-sm text-muted-foreground">No KPIs in this domain.</div> : null}
      {list.length ? (
        <div className="grid gap-2" style={GRID}>
          {list.map((k) => (
            <KpiCard key={k.id} kpi={k} color={(k.domain_key ? index[k.domain_key] : undefined)?.color ?? "200 10% 55%"} onEdit={() => setEditing(k)} />
          ))}
        </div>
      ) : null}
      <KpiDialog kpi={editing} onClose={() => setEditing(null)} />
    </div>
  );
}
