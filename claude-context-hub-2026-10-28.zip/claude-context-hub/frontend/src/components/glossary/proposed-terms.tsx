import { CheckCheck, CircleCheck, CircleX, Sparkles } from "lucide-react";
import { useMemo } from "react";

import type { GlossaryDomainNode, GlossaryTermRow, TermLink } from "@/api/types";
import { ConfidenceMeter, KindTile, TERM_KIND_LABEL, TargetTypeBadge, domainIndex } from "@/components/glossary/visuals";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useDecideTerm, useGlossaryTerms, useTermLinks } from "@/hooks/queries";

type Decide = ReturnType<typeof useDecideTerm>;

function ProposedTermCard({ term, evidence, domainName, color, decide }: { term: GlossaryTermRow; evidence: TermLink[]; domainName: string | null; color: string; decide: Decide }) {
  const pending = decide.isPending;
  const accept = (links: boolean) => decide.mutate({ id: term.id, body: { decision: "accept", accept_links: links } });
  const reject = () => decide.mutate({ id: term.id, body: { decision: "reject" } });
  const shown = evidence.slice(0, 6);
  return (
    <div className="relative flex flex-col overflow-hidden rounded-xl border border-warning/40 bg-background/50 p-3">
      <span className="absolute inset-x-0 top-0 h-[2px]" style={{ background: `linear-gradient(90deg, hsl(${color}), hsl(${color} / 0.1))` }} aria-hidden="true" />
      <div className="flex items-start gap-2.5">
        <KindTile kind={term.kind} className="h-9 w-9" iconClass="h-4 w-4" />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="font-display text-sm font-medium leading-tight">{term.name}</span>
            <Badge variant="warning">proposed</Badge>
            <Badge variant="info" title={term.proposed_by ? `Proposed by ${term.proposed_by}` : "Proposed by Claude"}>
              Claude
            </Badge>
          </div>
          <div className="truncate text-[10px] text-muted-foreground">
            {domainName ?? "No domain"} · {TERM_KIND_LABEL[term.kind]}
          </div>
        </div>
      </div>
      <p className="mt-2 text-xs text-muted-foreground">{term.definition || "No definition proposed."}</p>
      {term.synonyms.length ? (
        <div className="mt-1.5 flex flex-wrap gap-1">
          {term.synonyms.map((s) => (
            <span key={s} className="rounded-md border border-border/60 bg-card/60 px-1.5 py-px text-[10px] text-muted-foreground">
              {s}
            </span>
          ))}
        </div>
      ) : null}
      {term.rationale ? <p className="mt-1.5 text-[10px] italic text-muted-foreground">{term.rationale}</p> : null}
      <div className="mt-2 space-y-1">
        {shown.map((l) => (
          <div key={l.id} className="flex items-center gap-2 text-[11px]">
            <TargetTypeBadge type={l.target_type} />
            <span className="truncate font-mono" title={l.target_label ?? ""}>
              {l.target_label ?? "?"}
            </span>
            <span className="hidden min-w-0 truncate text-[10px] text-muted-foreground md:inline" title={l.target_context ?? ""}>
              {l.target_context}
            </span>
            <span className="ml-auto shrink-0">
              <ConfidenceMeter value={l.confidence} />
            </span>
          </div>
        ))}
        {evidence.length > shown.length ? <div className="text-[10px] text-muted-foreground">+{evidence.length - shown.length} more</div> : null}
        {evidence.length === 0 ? <div className="text-[10px] text-muted-foreground">No pending evidence links.</div> : null}
      </div>
      <div className="mt-auto flex flex-wrap items-center gap-1 pt-2">
        <Button size="sm" className="h-7 px-2" disabled={pending} onClick={() => accept(true)} title="Add the term to the glossary and accept every column and metric listed">
          <CheckCheck className="h-3.5 w-3.5" /> Accept with {evidence.length} link{evidence.length === 1 ? "" : "s"}
        </Button>
        <Button size="sm" variant="outline" className="h-7 px-2" disabled={pending} onClick={() => accept(false)} title="Add the term; its links stay in the queue for review">
          <CircleCheck className="h-3.5 w-3.5" /> Term only
        </Button>
        <Button size="sm" variant="outline" className="h-7 px-2 text-muted-foreground" disabled={pending} onClick={reject} title="Discard the term and its proposed links">
          <CircleX className="h-3.5 w-3.5" /> Reject
        </Button>
      </div>
    </div>
  );
}

/** Candidate terms Claude proposed from unmapped columns and metrics, each with its evidence, ahead of the link queue. */
export function ProposedTerms({ domains, running }: { domains: GlossaryDomainNode[] | undefined; running: boolean }) {
  const terms = useGlossaryTerms({ status: "proposed", limit: 200 }, running ? 3000 : false);
  const links = useTermLinks({ term_status: "proposed", status: "suggested", limit: 500 }, running ? 3000 : false);
  const decide = useDecideTerm();
  const index = domainIndex(domains);
  const byTerm = useMemo(() => {
    const map = new Map<string, TermLink[]>();
    for (const l of links.data?.items ?? []) {
      const rows = map.get(l.term_id);
      if (rows) rows.push(l);
      else map.set(l.term_id, [l]);
    }
    return map;
  }, [links.data]);
  const items = terms.data?.items ?? [];
  if (items.length === 0) return null;
  return (
    <section className="space-y-2">
      <div className="flex flex-wrap items-center gap-2 text-[10px] font-medium uppercase tracking-[0.2em] text-muted-foreground">
        <Sparkles className="h-3.5 w-3.5 text-warning" /> Proposed terms · {items.length}
        <span className="font-normal normal-case tracking-normal">new vocabulary Claude derived from the data; accepting adds it to the glossary</span>
      </div>
      <div className="grid gap-2" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(20rem, 1fr))" }}>
        {items.map((t) => {
          const info = t.domain_key ? index[t.domain_key] : undefined;
          return <ProposedTermCard key={t.id} term={t} evidence={byTerm.get(t.id) ?? []} domainName={info?.name ?? t.domain_name} color={info?.color ?? "38 92% 52%"} decide={decide} />;
        })}
      </div>
    </section>
  );
}
