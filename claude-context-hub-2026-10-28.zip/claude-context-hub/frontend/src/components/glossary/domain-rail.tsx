import { BookOpen, ChevronRight } from "lucide-react";

import type { GlossaryDomain, GlossaryDomainNode } from "@/api/types";
import { STANDARD_COLOR, Tile, domainStyle } from "@/components/glossary/visuals";
import { Skeleton } from "@/components/ui/skeleton";
import { formatInt } from "@/lib/format";
import { cn } from "@/lib/utils";

interface DomainRailProps {
  domains: GlossaryDomainNode[] | undefined;
  loading: boolean;
  selected: string | null;
  onSelect: (key: string | null) => void;
}

function Counts({ d, accent }: { d: GlossaryDomain; accent: string }) {
  return (
    <span className="ml-auto flex shrink-0 items-center gap-1 font-mono text-[10px] tabular-nums text-muted-foreground">
      {d.asset_count ? (
        <span className="rounded-md px-1 py-px text-white" style={{ background: `hsl(${accent})` }} title={`${d.asset_count} datasets placed in this domain`}>
          {formatInt(d.asset_count)}
        </span>
      ) : null}
      <span title={`${d.term_count} terms · ${d.kpi_count} KPIs`}>{formatInt(d.term_count)}</span>
    </span>
  );
}

/** The insurance taxonomy: ACORD capability areas with their sub-domains, each with term, KPI and dataset counts. */
export function DomainRail({ domains, loading, selected, onSelect }: DomainRailProps) {
  const list = domains ?? [];
  const totalTerms = list.reduce((n, d) => n + d.term_count, 0);
  const totalAssets = list.reduce((n, d) => n + d.asset_count, 0);
  return (
    <aside className="hidden w-72 shrink-0 flex-col border-r border-border/70 bg-card/40 lg:flex">
      <div className="px-4 pb-2 pt-4">
        <div className="text-[10px] font-medium uppercase tracking-[0.2em] text-muted-foreground">Insurance domains</div>
        <p className="mt-1 text-[11px] text-muted-foreground">ACORD capability areas; party, contract and money follow FIBO.</p>
      </div>
      <nav className="scrollbar-hidden min-h-0 flex-1 overflow-y-auto px-2 pb-4">
        <button
          type="button"
          onClick={() => onSelect(null)}
          className={cn(
            "flex w-full items-center gap-2.5 rounded-xl border px-2.5 py-2 text-left transition-colors",
            selected === null ? "border-primary/50 bg-primary/10" : "border-transparent hover:bg-muted/50",
          )}
        >
          <Tile color="172 66% 45%" icon={BookOpen} className="h-8 w-8" iconClass="h-3.5 w-3.5" />
          <span className="min-w-0 flex-1">
            <span className="block truncate text-sm font-medium">All domains</span>
            <span className="block text-[10px] text-muted-foreground">
              {formatInt(totalTerms)} terms · {formatInt(totalAssets)} datasets placed
            </span>
          </span>
        </button>
        {loading && !domains ? (
          <div className="mt-2 space-y-2 px-1">
            {[0, 1, 2, 3, 4, 5].map((i) => (
              <Skeleton key={i} className="h-11 w-full" />
            ))}
          </div>
        ) : null}
        <div className="mt-2 space-y-1">
          {list.map((d) => {
            const style = domainStyle(d.key);
            const open = selected === d.key || d.children.some((c) => c.key === selected);
            return (
              <div key={d.key}>
                <button
                  type="button"
                  onClick={() => onSelect(d.key)}
                  className={cn(
                    "flex w-full items-center gap-2.5 rounded-xl border px-2.5 py-2 text-left transition-colors",
                    selected === d.key ? "border-primary/50 bg-primary/10" : "border-transparent hover:bg-muted/50",
                  )}
                  title={d.description}
                >
                  <Tile color={style.color} icon={style.icon} className="h-8 w-8" iconClass="h-3.5 w-3.5" />
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-1.5">
                      <span className="truncate text-sm font-medium">{d.name}</span>
                      <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: `hsl(${STANDARD_COLOR[d.standard]})` }} title={d.standard.toUpperCase()} aria-hidden="true" />
                    </span>
                    <span className="block truncate text-[10px] text-muted-foreground">
                      {d.kpi_count ? `${d.kpi_count} KPIs · ` : ""}
                      {d.children.length ? `${d.children.length} sub-domains` : d.standard_ref || "hub domain"}
                    </span>
                  </span>
                  <Counts d={d} accent={style.color} />
                  {d.children.length ? <ChevronRight className={cn("h-3.5 w-3.5 shrink-0 text-muted-foreground transition-transform", open && "rotate-90")} /> : null}
                </button>
                {open && d.children.length ? (
                  <div className="ml-5 mt-0.5 space-y-0.5 border-l border-border/60 pl-2">
                    {d.children.map((c) => (
                      <button
                        key={c.key}
                        type="button"
                        onClick={() => onSelect(c.key)}
                        className={cn(
                          "flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left text-xs transition-colors",
                          selected === c.key ? "bg-primary/10 text-foreground" : "text-muted-foreground hover:bg-muted/50 hover:text-foreground",
                        )}
                        title={c.description}
                      >
                        <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: `hsl(${style.color})` }} aria-hidden="true" />
                        <span className="truncate">{c.name}</span>
                        <Counts d={c} accent={style.color} />
                      </button>
                    ))}
                  </div>
                ) : null}
              </div>
            );
          })}
        </div>
      </nav>
    </aside>
  );
}
