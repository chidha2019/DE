import { useQueryClient } from "@tanstack/react-query";
import { ExternalLink, FileCode, History, Network, Search, Trash2, Waypoints, type LucideIcon } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";

import type { RepoGraphPayload } from "@/api/repo-graph";
import { useDebounced } from "@/components/personas/persona-shell";
import { ConfirmDialog } from "@/components/pipelines/confirm-dialog";
import { CrawlHistory } from "@/components/repo-graph/crawl-history";
import { CrawlPanel } from "@/components/repo-graph/crawl-panel";
import { FilesTable } from "@/components/repo-graph/files-table";
import { GraphView } from "@/components/repo-graph/graph-view";
import { LAYER_ORDER, kindMeta, layerColor, shortSha } from "@/components/repo-graph/kind-style";
import { InfraStrip, LineageFlow } from "@/components/repo-graph/lineage-flow";
import { NodePanel } from "@/components/repo-graph/node-panel";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { isCrawlBusy, repoGraphKeys, useRemoveRepoGraph, useRepoCrawls, useRepoGraph, useRepoGraphRepos, useRepoSearch } from "@/hooks/repo-graph";
import { describeError } from "@/lib/api-client";
import { formatInt, formatRelative } from "@/lib/format";
import { cn } from "@/lib/utils";

type Tab = "lineage" | "graph" | "files" | "crawls";
const TABS: { key: Tab; label: string; icon: LucideIcon }[] = [
  { key: "lineage", label: "Lineage", icon: Waypoints },
  { key: "graph", label: "Graph", icon: Network },
  { key: "files", label: "Files", icon: FileCode },
  { key: "crawls", label: "Crawls", icon: History },
];

export function RepositoriesSection() {
  const [params, setParams] = useSearchParams();
  const repos = useRepoGraphRepos();
  const crawls = useRepoCrawls(null);
  const remove = useRemoveRepoGraph();
  const qc = useQueryClient();
  const [confirmRemove, setConfirmRemove] = useState(false);
  const [showControl, setShowControl] = useState(false);

  const crawled = useMemo(() => repos.data?.crawled ?? [], [repos.data]);
  const wanted = params.get("repo");
  const current = crawled.find((r) => r.repo.toLowerCase() === (wanted ?? "").toLowerCase()) ?? crawled[0] ?? null;
  const repo = current?.repo ?? null;
  const tabParam = params.get("tab") as Tab | null;
  const tab: Tab = tabParam && TABS.some((t) => t.key === tabParam) ? tabParam : "lineage";
  const selected = params.get("node");
  const lineage = useRepoGraph(tab === "lineage" ? repo : null, "lineage");

  const update = (patch: Record<string, string | null>) =>
    setParams(
      (prev) => {
        const next = new URLSearchParams(prev);
        for (const [k, v] of Object.entries(patch)) {
          if (v === null) next.delete(k);
          else next.set(k, v);
        }
        return next;
      },
      { replace: true },
    );
  const select = (key: string) => update({ node: key });

  // When a crawl finishes, everything the page shows about that repository is stale.
  const busy = useRef(new Set<string>());
  useEffect(() => {
    const now = new Set((crawls.data ?? []).filter(isCrawlBusy).map((c) => c.id));
    const finished = [...busy.current].some((id) => !now.has(id));
    busy.current = now;
    if (finished) void qc.invalidateQueries({ queryKey: repoGraphKeys.all });
  }, [crawls.data, qc]);

  const counts = current?.counts ?? {};

  return (
    <div className="space-y-5 md:space-y-6">
      <CrawlPanel repos={repos.data} crawls={crawls.data} initialRepo={repo ?? repos.data?.configured[0] ?? null} onStarted={(name) => update({ repo: name })} />

      {current ? (
        <>
          <section className="flex flex-wrap items-center gap-x-4 gap-y-2">
            {crawled.length > 1 ? (
              <Select value={current.repo} onValueChange={(value) => update({ repo: value, node: null })}>
                <SelectTrigger className="h-9 w-auto min-w-[16rem] font-mono text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {crawled.map((r) => (
                    <SelectItem key={r.repo} value={r.repo} className="font-mono text-sm">
                      {r.repo}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : (
              <span className="font-mono text-sm font-medium">{current.repo}</span>
            )}
            <span className="text-xs text-muted-foreground">
              {current.ref ?? ""} {current.sha ? `@ ${shortSha(current.sha)}` : ""} · crawled {formatRelative(current.crawled_at)} · {formatInt(current.files)} files
            </span>
            {current.url ? (
              <a href={current.url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
                GitHub <ExternalLink className="h-3 w-3" />
              </a>
            ) : null}
            <div className="flex w-full items-center gap-2 sm:ml-auto sm:w-auto">
              <NodeSearch repo={current.repo} onSelect={select} />
              <Button variant="ghost" size="sm" className="shrink-0 gap-1 text-destructive" onClick={() => setConfirmRemove(true)}>
                <Trash2 className="h-3.5 w-3.5" /> <span className="hidden sm:inline">Remove</span>
              </Button>
            </div>
          </section>

          <nav className="flex flex-wrap gap-1.5" aria-label="Repo graph views">
            {TABS.map((t) => (
              <button
                key={t.key}
                type="button"
                onClick={() => update({ tab: t.key })}
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium transition-colors",
                  tab === t.key ? "border-primary bg-primary text-primary-foreground" : "border-border/70 text-muted-foreground hover:text-foreground",
                )}
              >
                <t.icon className="h-3.5 w-3.5" />
                {t.label}
              </button>
            ))}
          </nav>

          <div className={cn("grid grid-cols-1 gap-4", selected && "xl:grid-cols-[minmax(0,1fr)_26rem]")}>
            <div className="min-w-0">
              {tab === "lineage" ? (
                <div className="space-y-3">
                  <LayerSummary data={lineage.data} counts={counts} />
                  <InfraStrip data={lineage.data} onSelect={select} selected={selected} />
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="text-xs text-muted-foreground">Click a source or table to trace it end to end. Hover to preview its path.</p>
                    <label className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Switch checked={showControl} onCheckedChange={setShowControl} aria-label="Show control tables" />
                      Control tables
                    </label>
                  </div>
                  <div className="surface rounded-xl border p-3">
                    <LineageFlow data={lineage.data} loading={lineage.isLoading} selected={selected} onSelect={select} showControl={showControl} />
                  </div>
                </div>
              ) : null}
              {tab === "graph" ? <GraphView repo={current.repo} selected={selected} onSelect={select} counts={counts} /> : null}
              {tab === "files" ? <FilesTable repo={current.repo} selected={selected} onSelect={select} /> : null}
              {tab === "crawls" ? (
                <div className="surface overflow-hidden rounded-xl border">
                  <CrawlHistory crawls={crawls.data} />
                </div>
              ) : null}
            </div>
            {selected ? (
              <NodePanel
                nodeKeyValue={selected}
                repoRef={current.sha ?? current.ref}
                onSelect={select}
                onClose={() => update({ node: null })}
                className="xl:sticky xl:top-4 xl:max-h-[calc(100vh-7rem)]"
              />
            ) : null}
          </div>

          <ConfirmDialog
            open={confirmRemove}
            title={`Remove ${current.repo} from the graph?`}
            description="This deletes the repository's nodes and edges from Neo4j. The repository on GitHub and the crawl history are not touched; crawl it again to rebuild the graph."
            confirmLabel="Remove from graph"
            pending={remove.isPending}
            error={remove.isError ? describeError(remove.error) : null}
            onConfirm={() =>
              remove.mutate(current.repo, {
                onSuccess: () => {
                  setConfirmRemove(false);
                  update({ repo: null, node: null });
                },
              })
            }
            onClose={() => setConfirmRemove(false)}
          />
        </>
      ) : repos.isLoading ? null : (
        <div className="surface rounded-xl border border-dashed p-8 text-center text-sm text-muted-foreground">
          No repository has been crawled yet. Enter one above and choose Crawl repo; its pipelines, tables, columns and checks appear here.
          {crawled.length === 0 && (crawls.data ?? []).length ? (
            <div className="mx-auto mt-4 max-w-4xl overflow-hidden rounded-xl border text-left">
              <CrawlHistory crawls={crawls.data} />
            </div>
          ) : null}
        </div>
      )}
    </div>
  );
}

function LayerSummary({ data, counts }: { data: RepoGraphPayload | undefined; counts: Record<string, number> }) {
  const layers = useMemo(() => {
    const map = new Map<string, number>();
    for (const n of data?.nodes ?? []) {
      if (n.type !== "table") continue;
      const layer = String(n.properties.layer ?? "other");
      map.set(layer, (map.get(layer) ?? 0) + 1);
    }
    const rank = (l: string) => {
      const i = (LAYER_ORDER as readonly string[]).indexOf(l);
      return i === -1 ? 100 : i;
    };
    return [...map.entries()].sort(([a], [b]) => rank(a) - rank(b));
  }, [data]);
  const items: { label: string; value: number; color: string }[] = [
    { label: kindMeta("source").plural, value: counts.source ?? 0, color: kindMeta("source").color },
    ...layers.map(([layer, n]) => ({ label: layer.charAt(0).toUpperCase() + layer.slice(1), value: n, color: layerColor(layer) })),
    { label: kindMeta("column").plural, value: counts.column ?? 0, color: kindMeta("column").color },
    { label: kindMeta("check").plural, value: counts.check ?? 0, color: kindMeta("check").color },
  ].filter((i) => i.value);
  return (
    <div className="flex flex-wrap gap-2">
      {items.map((i) => (
        <span key={i.label} className="inline-flex items-center gap-1.5 rounded-lg border border-border/60 bg-card px-2.5 py-1 text-xs">
          <span className="h-2 w-2 rounded-full" style={{ backgroundColor: i.color }} />
          <span className="font-semibold tabular-nums">{formatInt(i.value)}</span>
          <span className="text-muted-foreground">{i.label}</span>
        </span>
      ))}
    </div>
  );
}

function NodeSearch({ repo, onSelect }: { repo: string; onSelect: (key: string) => void }) {
  const [text, setText] = useState("");
  const [open, setOpen] = useState(false);
  const q = useDebounced(text, 250);
  const results = useRepoSearch(repo, q);
  return (
    <div className="relative min-w-0 flex-1 sm:w-72 sm:flex-none">
      <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
      <Input
        value={text}
        onChange={(e) => {
          setText(e.target.value);
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        onBlur={() => window.setTimeout(() => setOpen(false), 150)}
        placeholder="Find a table, column, check or file"
        className="h-9 pl-8 text-xs"
        aria-label="Find a node"
      />
      {open && q.length >= 2 && results.data ? (
        <div className="absolute right-0 top-full z-30 mt-1 max-h-80 w-full min-w-[18rem] overflow-y-auto rounded-lg border bg-popover p-1 shadow-lg">
          {results.data.length ? (
            results.data.map((n) => {
              const meta = kindMeta(n.type);
              const Icon = meta.icon;
              return (
                <button
                  key={n.id}
                  type="button"
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={() => {
                    onSelect(n.id);
                    setOpen(false);
                  }}
                  className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-xs hover:bg-muted"
                >
                  <Icon className="h-3.5 w-3.5 shrink-0" style={{ color: meta.color }} />
                  <span className="min-w-0 flex-1 truncate font-mono">{String(n.properties.name ?? n.label)}</span>
                  <span className="shrink-0 text-[10px] text-muted-foreground">{meta.label}</span>
                </button>
              );
            })
          ) : (
            <p className="px-2 py-1.5 text-xs text-muted-foreground">Nothing matches.</p>
          )}
        </div>
      ) : null}
    </div>
  );
}
