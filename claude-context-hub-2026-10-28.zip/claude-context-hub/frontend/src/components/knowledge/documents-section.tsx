import { ExternalLink, FileText, Focus, GitFork, Network, Orbit, Shapes, Sparkles, Tags, Waypoints, X } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import type { GraphNode } from "@/api/types";
import { BrandMark } from "@/components/connectors/brand-mark";
import { ChunkList } from "@/components/explorer/chunk-list";
import { DocumentPicker } from "@/components/explorer/document-picker";
import { ForceGraph } from "@/components/explorer/force-graph";
import { NODE_COLORS } from "@/components/explorer/graph-colors";
import { GraphLegend, TYPE_ICON } from "@/components/explorer/graph-legend";
import { HeroStats } from "@/components/layout/page-hero";
import { ViewSwitcher, type ViewOption } from "@/components/layout/view-switcher";
import { Button } from "@/components/ui/button";
import { useDocument, useDocumentChunks, useDocumentGraph, useEntityNeighborhood, useGraphStats, useKnowledgeMap } from "@/hooks/queries";
import { ApiError, describeError } from "@/lib/api-client";
import { formatInt } from "@/lib/format";
import { documentPath } from "@/lib/knowledge-paths";
import { cn } from "@/lib/utils";

type Mode = "map" | "document" | "entity";

const ENTITY_LABELS = ["Person", "Project", "Technology", "Concept"];

/** Soft colour washes and a dot grid behind the canvas, drawn from theme tokens so both themes read well. */
const CANVAS_BACKDROP = {
  backgroundImage: [
    "radial-gradient(circle at 18% 12%, hsl(var(--primary) / 0.12), transparent 45%)",
    "radial-gradient(circle at 85% 88%, rgba(139, 92, 246, 0.12), transparent 50%)",
    "radial-gradient(hsl(var(--foreground) / 0.07) 1px, transparent 1px)",
  ].join(", "),
  backgroundSize: "auto, auto, 18px 18px",
};

function NodeTile({ type, className }: { type: string; className?: string }) {
  const color = NODE_COLORS[type] ?? NODE_COLORS.default ?? "#94a3b8";
  const Icon = TYPE_ICON[type] ?? Shapes;
  return (
    <span
      className={cn("flex shrink-0 items-center justify-center rounded-xl text-white", className ?? "h-10 w-10")}
      style={{ background: `linear-gradient(140deg, ${color}aa, ${color})`, boxShadow: `0 10px 24px -12px ${color}, inset 0 1px 0 0 rgba(255,255,255,0.3)` }}
    >
      <Icon className="h-5 w-5" />
    </span>
  );
}

export function DocumentsSection() {
  const { documentId = null } = useParams<{ documentId: string }>();
  const navigate = useNavigate();
  const [selectedEntity, setSelectedEntity] = useState<string | null>(null);
  const [mode, setMode] = useState<Mode>(documentId ? "document" : "map");

  const stats = useGraphStats();
  const map = useKnowledgeMap(mode === "map");
  const document = useDocument(documentId);
  const chunks = useDocumentChunks(documentId);
  const docGraph = useDocumentGraph(documentId);
  const neighborhood = useEntityNeighborhood(mode === "entity" ? selectedEntity : null);

  // The neighbourhood view only exists while an entity is selected; fall back to where the user came from.
  useEffect(() => {
    if (mode === "entity" && !selectedEntity) setMode(documentId ? "document" : "map");
    if (mode === "document" && !documentId) setMode("map");
  }, [mode, selectedEntity, documentId]);

  const graph = mode === "map" ? map : mode === "entity" && selectedEntity ? neighborhood : docGraph;
  const nodeCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const n of graph.data?.nodes ?? []) counts[n.type] = (counts[n.type] ?? 0) + 1;
    return counts;
  }, [graph.data]);
  const focusId = selectedEntity ?? (mode === "map" ? documentId : null);
  const selectedNode = useMemo(() => graph.data?.nodes.find((n) => n.id === focusId) ?? null, [graph.data, focusId]);

  const onNodeClick = (node: GraphNode) => {
    if (node.type === "Document") {
      if (node.properties?.stub) return;
      setSelectedEntity(null);
      if (node.id !== documentId) navigate(documentPath(node.id));
      return;
    }
    setSelectedEntity((prev) => (prev === node.id ? null : node.id));
  };

  const graphNotSynced = docGraph.isError && docGraph.error instanceof ApiError && docGraph.error.isNotFound;
  const labels = stats.data?.nodes_by_label ?? {};
  const entityTotal = ENTITY_LABELS.reduce((sum, l) => sum + (labels[l] ?? 0), 0);

  const views: ViewOption<Mode>[] = [
    { key: "map", label: "Knowledge map", icon: Orbit, tone: "#8B5CF6", count: map.data ? map.data.nodes.length : undefined },
    ...(documentId ? [{ key: "document" as const, label: "Document graph", icon: FileText, tone: "#3B82F6" }] : []),
    ...(selectedEntity ? [{ key: "entity" as const, label: "Neighbourhood", icon: Focus, tone: "#10B981" }] : []),
  ];
  const caption =
    mode === "map"
      ? "Every synced document and the entities they share — hubs are mentioned most."
      : mode === "entity"
        ? "Documents and entities one hop from the selected entity."
        : "This document's chunks, entities and references.";

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <p className="max-w-xl text-sm text-muted-foreground">
          What Genie retrieves from. Pick a document to read its chunks; click an entity to filter them and light up its connections across the graph.
        </p>
        <HeroStats
          items={[
            { label: "Documents", value: labels.Document ?? 0, icon: FileText, tone: NODE_COLORS.Document },
            { label: "Entities", value: entityTotal, icon: Sparkles, tone: NODE_COLORS.Project },
            { label: "Mentions", value: stats.data?.edges_by_type?.MENTIONS ?? 0, icon: Tags, tone: NODE_COLORS.Concept },
            { label: "Relationships", value: stats.data?.edges_total ?? 0, icon: Waypoints, tone: NODE_COLORS.Technology },
          ]}
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-5">
        {/* ------------------------------------------------------------- left */}
        <div className="flex min-w-0 flex-col gap-4 lg:col-span-2">
          <DocumentPicker
            selectedId={documentId}
            onSelect={(d) => {
              setSelectedEntity(null);
              navigate(documentPath(d.id));
            }}
            height={documentId ? 220 : 560}
          />

          {documentId ? (
            <div className="space-y-3">
              {document.data ? (
                <div className="relative overflow-hidden rounded-2xl border bg-card p-4 shadow-sm">
                  <span className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full bg-primary/15 blur-3xl" aria-hidden="true" />
                  <div className="relative flex items-start gap-3">
                    <BrandMark icon={document.data.source_system} size="md" />
                    <div className="min-w-0 flex-1">
                      <h2 className="truncate font-display text-base font-medium" title={document.data.title}>
                        {document.data.title}
                      </h2>
                      <div className="mt-1.5 flex flex-wrap items-center gap-1.5 text-[11px] text-muted-foreground">
                        <span className="rounded-full border px-2 py-px capitalize">{document.data.source_system}</span>
                        <span className="rounded-full border px-2 py-px">v{document.data.version}</span>
                        <span className="rounded-full border px-2 py-px">{formatInt(document.data.chunk_count ?? 0)} chunks</span>
                        {document.data.author ? <span className="rounded-full border px-2 py-px">{document.data.author}</span> : null}
                        <span
                          className={cn(
                            "rounded-full px-2 py-px font-medium",
                            document.data.graph_sync_status === "synced"
                              ? "bg-success/10 text-success"
                              : document.data.graph_sync_status === "failed"
                                ? "bg-destructive/10 text-destructive"
                                : "bg-warning/10 text-warning",
                          )}
                        >
                          graph {document.data.graph_sync_status}
                        </span>
                      </div>
                    </div>
                    {document.data.uri ? (
                      <a
                        href={document.data.uri}
                        target="_blank"
                        rel="noreferrer"
                        className="rounded-lg p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground"
                        title="Open in source system"
                      >
                        <ExternalLink className="h-4 w-4" />
                      </a>
                    ) : null}
                  </div>
                  {document.data.graph_sync_error ? <p className="relative mt-2 text-xs text-destructive">{document.data.graph_sync_error}</p> : null}
                </div>
              ) : document.isError ? (
                <div className="rounded-2xl border border-destructive/40 p-3 text-sm text-destructive">{describeError(document.error)}</div>
              ) : null}
              <ChunkList chunks={chunks.data} loading={chunks.isLoading} selectedEntityKey={selectedEntity} onSelectEntity={setSelectedEntity} />
            </div>
          ) : null}
        </div>

        {/* ------------------------------------------------------------ right */}
        <div className="flex min-w-0 flex-col gap-3 lg:sticky lg:top-4 lg:col-span-3 lg:self-start">
          <ViewSwitcher views={views} value={mode} onChange={setMode} label="Graph view" size="md" />

          <div className="relative h-[460px] overflow-hidden rounded-2xl border bg-card shadow-sm lg:h-[640px]" style={CANVAS_BACKDROP}>
            <div className="pointer-events-none absolute inset-x-3 top-3 z-10 flex items-start justify-between gap-3">
              <div className="rounded-xl border border-border/70 bg-card/80 px-3 py-2 shadow-sm backdrop-blur">
                <div className="flex items-center gap-2 text-sm font-medium">
                  {mode === "map" ? (
                    <Network className="h-4 w-4 text-primary" />
                  ) : mode === "entity" ? (
                    <Focus className="h-4 w-4 text-primary" />
                  ) : (
                    <GitFork className="h-4 w-4 text-primary" />
                  )}
                  {views.find((v) => v.key === mode)?.label}
                  {graph.data ? (
                    <span className="text-xs font-normal tabular-nums text-muted-foreground">
                      {formatInt(graph.data.nodes.length)} nodes · {formatInt(graph.data.edges.length)} links
                    </span>
                  ) : null}
                </div>
                <p className="mt-0.5 hidden text-[11px] text-muted-foreground sm:block">{caption}</p>
              </div>
            </div>

            {mode === "document" && graphNotSynced ? (
              <div className="flex h-full items-center justify-center p-8 text-center text-sm text-muted-foreground">
                This document is not in Neo4j yet (graph sync pending/failed). Use “Reconcile graph” on the Pipelines page.
              </div>
            ) : graph.isError ? (
              <div className="flex h-full items-center justify-center p-8 text-sm text-destructive">{describeError(graph.error)}</div>
            ) : (
              <ForceGraph
                data={graph.data}
                loading={graph.isLoading}
                selectedId={focusId}
                onNodeClick={onNodeClick}
                onBackgroundClick={() => setSelectedEntity(null)}
                emptyMessage={mode === "map" ? "The graph is empty — crawl a repository or sync a source to populate it." : "No graph data."}
                rich
                fill
              />
            )}

            <div className="absolute bottom-3 left-3 right-16 z-10">
              <GraphLegend counts={nodeCounts} types={["Document", "Person", "Project", "Technology", "Concept", "Chunk"]} />
            </div>
          </div>

          {selectedNode ? (
            <div className="flex flex-wrap items-center gap-3 rounded-2xl border bg-card px-4 py-3 shadow-sm">
              <NodeTile type={selectedNode.type} />
              <div className="min-w-0 flex-1">
                <div className="truncate font-medium" title={selectedNode.label}>
                  {selectedNode.label}
                </div>
                <div className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                  <span style={{ color: NODE_COLORS[selectedNode.type] }}>{selectedNode.type}</span>
                  <span>·</span>
                  <span className="tabular-nums">{selectedNode.degree ?? 0} links</span>
                  {typeof selectedNode.properties?.documents === "number" ? (
                    <>
                      <span>·</span>
                      <span className="tabular-nums">in {selectedNode.properties.documents} documents</span>
                    </>
                  ) : null}
                </div>
              </div>
              {selectedNode.type !== "Document" && mode !== "entity" ? (
                <Button size="sm" variant="outline" onClick={() => setMode("entity")}>
                  <Focus className="h-3.5 w-3.5" /> Focus neighbourhood
                </Button>
              ) : null}
              {selectedNode.type === "Document" && mode === "map" ? (
                <Button size="sm" variant="outline" onClick={() => setMode("document")}>
                  <FileText className="h-3.5 w-3.5" /> Document graph
                </Button>
              ) : null}
              {selectedEntity ? (
                <Button size="sm" variant="ghost" onClick={() => setSelectedEntity(null)} aria-label="Clear selection">
                  <X className="h-4 w-4" />
                </Button>
              ) : null}
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}
