import {
  ArrowDownToLine,
  ArrowRight,
  BadgeCheck,
  BookCheck,
  CalendarClock,
  CircleAlert,
  CircleCheck,
  CircleX,
  CloudUpload,
  Columns3,
  FolderOpen,
  ListChecks,
  Merge,
  MessageSquareReply,
  Rows3,
  Snowflake,
  Sparkles,
  UserRound,
  type LucideIcon,
} from "lucide-react";
import type { ReactNode } from "react";
import { Link } from "react-router-dom";

import type { IntentReview, ReviewStatus, StructuredIntent } from "@/api/types";
import { cn } from "@/lib/utils";

const KIND_LABEL: Record<StructuredIntent["kind"], string> = {
  ingest_csv_to_iceberg: "CSV files → Snowflake Iceberg",
  model_layer: "Model a layer from the one below",
  gold_fact: "Gold fact table",
  other: "Other request",
};

const VERDICT: Record<IntentReview["verdict"], { label: string; color: string; icon: LucideIcon }> = {
  ready: { label: "Ready to plan", color: "152 65% 40%", icon: BadgeCheck },
  needs_answers: { label: "Needs answers", color: "25 95% 53%", icon: MessageSquareReply },
  thin: { label: "Thin ticket", color: "38 92% 50%", icon: CircleAlert },
};

const CHECK: Record<ReviewStatus, { icon: LucideIcon; color: string; rank: number }> = {
  missing: { icon: CircleX, color: "0 72% 55%", rank: 0 },
  warn: { icon: CircleAlert, color: "38 92% 50%", rank: 1 },
  ok: { icon: CircleCheck, color: "152 65% 40%", rank: 2 },
};

/** The review score as a ring; the colour follows the verdict. */
export function ScoreRing({ score, color, size = 88, stroke = 8 }: { score: number; color: string; size?: number; stroke?: number }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return (
    <span className="relative inline-flex shrink-0 items-center justify-center" style={{ width: size, height: size }}>
      <svg viewBox={`0 0 ${size} ${size}`} className="absolute inset-0 -rotate-90" aria-hidden="true">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={`hsl(${color} / 0.15)`} strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={`hsl(${color})`}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={`${((Math.max(0, Math.min(100, score)) / 100) * c).toFixed(2)} ${c.toFixed(2)}`}
          className="transition-all duration-700"
        />
      </svg>
      <span className={cn("font-display font-medium tabular-nums", size >= 64 ? "text-2xl" : "text-[10px]")}>{score}</span>
    </span>
  );
}

/** The score as a small ring for list rows. */
export function ReviewChip({ review }: { review: IntentReview }) {
  const v = VERDICT[review.verdict];
  return (
    <span className="inline-flex items-center gap-1.5 text-[10px] font-medium" style={{ color: `hsl(${v.color})` }} title={`${v.label}: ${review.headline}`}>
      <ScoreRing score={review.score} color={v.color} size={26} stroke={3} />
      {v.label}
    </span>
  );
}

function EndCard({
  icon: Icon,
  color,
  eyebrow,
  title,
  lines,
  missing,
}: {
  icon: LucideIcon;
  color: string;
  eyebrow: string;
  title: string;
  lines: string[];
  missing: boolean;
}) {
  return (
    <div
      className="relative min-w-0 overflow-hidden rounded-2xl border bg-card/80 p-3.5"
      style={{ borderColor: missing ? "hsl(0 72% 55% / 0.45)" : `hsl(${color} / 0.3)` }}
    >
      <span
        className="pointer-events-none absolute -right-8 -top-10 h-24 w-24 rounded-full opacity-20 blur-2xl"
        style={{ background: `hsl(${color})` }}
        aria-hidden="true"
      />
      <div className="relative flex items-center gap-2.5">
        <span
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-white"
          style={{ background: `linear-gradient(140deg, hsl(${color} / 0.7), hsl(${color}))` }}
        >
          <Icon className="h-[18px] w-[18px]" />
        </span>
        <div className="min-w-0">
          <div className="text-[10px] font-medium uppercase tracking-[0.18em] text-muted-foreground">{eyebrow}</div>
          <div className={cn("break-all font-mono text-sm font-medium", missing && "text-destructive")}>{title}</div>
        </div>
      </div>
      <div className="relative mt-2 space-y-0.5">
        {lines.map((line) => (
          <div key={line} className="truncate text-[11px] text-muted-foreground" title={line}>
            {line}
          </div>
        ))}
      </div>
    </div>
  );
}

function FactTile({ icon: Icon, label, value, color }: { icon: LucideIcon; label: string; value: string; color: string }) {
  return (
    <div className="flex min-w-0 items-start gap-2.5 rounded-xl border border-border/60 bg-background/50 p-2.5">
      <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg" style={{ background: `hsl(${color} / 0.14)`, color: `hsl(${color})` }}>
        <Icon className="h-3.5 w-3.5" />
      </span>
      <div className="min-w-0">
        <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</div>
        <div className={cn("text-xs", !value && "text-muted-foreground")}>{value || "not stated"}</div>
      </div>
    </div>
  );
}

function Block({ icon: Icon, title, children, aside }: { icon: LucideIcon; title: string; children: ReactNode; aside?: ReactNode }) {
  return (
    <div>
      <div className="mb-1.5 flex items-center gap-1.5 text-[10px] font-medium uppercase tracking-[0.18em] text-muted-foreground">
        <Icon className="h-3.5 w-3.5" /> {title} {aside}
      </div>
      {children}
    </div>
  );
}

/** What Claude read from the ticket: where the data comes from and goes, its grain and rhythm, and what "done" means. */
export function ReadView({ intent }: { intent: StructuredIntent }) {
  const s = intent.source;
  const t = intent.target;
  const layered = intent.kind === "model_layer";
  const azure = s.storage_provider === "azure";
  const landing = azure
    ? `azure://${s.azure_account ?? "<account>"}.blob.core.windows.net/${s.azure_container ?? "<container>"}/${s.azure_prefix ?? ""}`
    : s.s3_bucket
      ? `s3://${s.s3_bucket}/${s.s3_prefix ?? ""}`
      : null;
  const location = layered ? [s.database, s.schema].filter(Boolean).join(".") || null : (s.folder ?? landing);
  const table = [t.database, t.schema, layered ? null : t.table].filter(Boolean).join(".") || null;
  const merge = t.load_mode === "merge";
  const load = merge ? `merge${t.merge_keys.length ? ` on ${t.merge_keys.join(", ")}` : ""}` : t.load_mode.replace("_", " ");
  const confidence = Math.round(intent.confidence * 100);
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0 flex-1 basis-[18rem]">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-2 py-0.5 text-[11px] font-medium text-primary">
            <Sparkles className="h-3 w-3" /> {KIND_LABEL[intent.kind]}
          </span>
          <p className="mt-2 text-[15px] leading-relaxed">{intent.summary}</p>
        </div>
        <div className="flex items-center gap-2 rounded-xl border border-border/60 bg-background/50 px-3 py-2" title="How sure Claude is of its reading">
          <ScoreRing score={confidence} color={confidence >= 70 ? "152 65% 40%" : confidence >= 40 ? "38 92% 50%" : "0 72% 55%"} size={40} stroke={4} />
          <div className="text-[11px] leading-tight text-muted-foreground">
            reading
            <br />
            confidence
          </div>
        </div>
      </div>

      <div className="grid items-center gap-2 xl:grid-cols-[minmax(0,1fr)_auto_minmax(0,1fr)]">
        <EndCard
          icon={layered ? Snowflake : s.s3_bucket && !s.folder ? CloudUpload : FolderOpen}
          color="199 89% 48%"
          eyebrow="From"
          title={location ?? "not named"}
          missing={!location}
          lines={
            layered
              ? [
                  "the tables loaded there, as validation finds them",
                  intent.depends_on?.length ? `after ${intent.depends_on.join(", ")}` : "no upstream ticket named",
                ]
              : [
                  `${s.file_pattern} · '${s.delimiter}' delimited · header ${s.header ? "yes" : "no"}`,
                  s.folder && landing
                    ? `lands in ${azure ? "Azure Blob Storage" : "S3"}: ${landing}`
                    : s.storage_integration
                      ? `read through storage integration ${s.storage_integration}`
                      : s.encoding,
                ]
          }
        />
        <div className="flex flex-col items-center gap-1 px-1 text-[10px] font-medium text-muted-foreground">
          <span className="inline-flex items-center gap-1 rounded-full border border-border/70 bg-background/70 px-2 py-0.5">
            {merge ? <Merge className="h-3 w-3" /> : <ArrowDownToLine className="h-3 w-3" />} {load}
          </span>
          <ArrowRight className="h-4 w-4 rotate-90 xl:rotate-0" aria-hidden="true" />
        </div>
        <EndCard
          icon={Snowflake}
          color="190 85% 42%"
          eyebrow="Into"
          title={table ?? "not named"}
          missing={!table}
          lines={[
            `${t.platform} · ${t.table_format}${intent.layer ? ` · ${intent.layer} layer` : ""}`,
            layered
              ? "tables proposed by the data modeler"
              : t.table_format === "iceberg"
                ? t.external_volume
                  ? `external volume ${t.external_volume}`
                  : "no external volume named"
                : "native table",
          ]}
        />
      </div>

      <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
        <FactTile icon={Rows3} label="Grain" value={intent.grain} color="262 70% 60%" />
        <FactTile icon={CalendarClock} label="Freshness" value={intent.freshness} color="38 92% 50%" />
        <FactTile icon={UserRound} label="Owner" value={intent.owner} color="199 89% 48%" />
        <FactTile icon={merge ? Merge : ArrowDownToLine} label="Load" value={load} color="172 66% 42%" />
      </div>

      <Block icon={ListChecks} title="Acceptance criteria" aside={<span className="tabular-nums">· {intent.acceptance_criteria.length}</span>}>
        {intent.acceptance_criteria.length ? (
          <ul className="grid gap-1.5 sm:grid-cols-2">
            {intent.acceptance_criteria.map((c) => (
              <li key={c} className="flex items-start gap-2 rounded-lg border border-emerald-500/25 bg-emerald-500/5 px-2.5 py-1.5 text-xs">
                <CircleCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600 dark:text-emerald-400" /> {c}
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-xs text-muted-foreground">The ticket states none; the planner proposes tests from the data and the exemplar table.</p>
        )}
      </Block>

      <div className="grid gap-4 md:grid-cols-2">
        <Block icon={BookCheck} title="Business terms">
          {intent.business_terms.length ? (
            <div className="flex flex-wrap gap-1">
              {intent.business_terms.map((term) => (
                <Link
                  key={term}
                  to={`/glossary/terms?search=${encodeURIComponent(term)}`}
                  className="rounded-full border border-fuchsia-500/30 bg-fuchsia-500/5 px-2 py-0.5 text-[11px] text-fuchsia-700 hover:border-fuchsia-500/60 dark:text-fuchsia-300"
                >
                  {term}
                </Link>
              ))}
            </div>
          ) : (
            <p className="text-xs text-muted-foreground">None recognised.</p>
          )}
        </Block>
        <Block icon={Columns3} title="Columns the ticket names">
          {intent.columns_hint.length ? (
            <div className="flex flex-wrap gap-1">
              {intent.columns_hint.map((c) => (
                <span key={c} className="rounded-md border border-border/60 bg-background/60 px-1.5 py-px font-mono text-[11px]">
                  {c}
                </span>
              ))}
            </div>
          ) : (
            <p className="text-xs text-muted-foreground">None; the columns come from the files.</p>
          )}
        </Block>
      </div>
    </div>
  );
}

/** The review: a score and verdict, then every check, the blocking ones first. */
export function ReviewView({ review, children }: { review: IntentReview; children?: ReactNode }) {
  const v = VERDICT[review.verdict];
  const tally = (status: ReviewStatus) => review.checks.filter((c) => c.status === status).length;
  const checks = [...review.checks].sort((a, b) => CHECK[a.status].rank - CHECK[b.status].rank);
  return (
    <div className="space-y-4">
      <div
        className="relative flex flex-wrap items-center gap-4 overflow-hidden rounded-2xl border p-4"
        style={{ borderColor: `hsl(${v.color} / 0.35)`, background: `linear-gradient(110deg, hsl(${v.color} / 0.1), transparent 65%)` }}
      >
        <ScoreRing score={review.score} color={v.color} />
        <div className="min-w-0 flex-1 basis-64">
          <span
            className="inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[11px] font-medium"
            style={{ background: `hsl(${v.color} / 0.14)`, color: `hsl(${v.color})` }}
          >
            <v.icon className="h-3.5 w-3.5" /> {v.label}
          </span>
          <p className="mt-1.5 text-sm">{review.headline}</p>
          <div className="mt-2 flex flex-wrap gap-1.5 text-[11px]">
            {(["ok", "warn", "missing"] as const).map((status) => {
              const meta = CHECK[status];
              const n = tally(status);
              return (
                <span
                  key={status}
                  className="inline-flex items-center gap-1 rounded-full border px-2 py-0.5"
                  style={{ borderColor: `hsl(${meta.color} / 0.3)`, color: `hsl(${meta.color})` }}
                >
                  <meta.icon className="h-3 w-3" /> {n} {status === "ok" ? "in place" : status === "warn" ? "left to defaults" : "missing"}
                </span>
              );
            })}
          </div>
        </div>
      </div>
      {children}
      <ul className="grid gap-2 sm:grid-cols-2">
        {checks.map((c) => {
          const meta = CHECK[c.status];
          return (
            <li
              key={c.key}
              className="flex min-w-0 items-start gap-2.5 rounded-xl border bg-card/70 p-2.5"
              style={{ borderColor: `hsl(${meta.color} / ${c.status === "ok" ? 0.2 : 0.4})` }}
            >
              <meta.icon className="mt-0.5 h-4 w-4 shrink-0" style={{ color: `hsl(${meta.color})` }} />
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-1.5 text-xs font-medium">
                  {c.label}
                  {c.blocking && c.status === "missing" ? (
                    <span className="rounded-full bg-destructive/10 px-1.5 text-[10px] font-medium text-destructive">blocks the plan</span>
                  ) : null}
                </div>
                <div className="break-words text-[11px] text-muted-foreground">{c.detail}</div>
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
