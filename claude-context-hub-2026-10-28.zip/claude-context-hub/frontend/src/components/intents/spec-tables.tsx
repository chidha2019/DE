import {
  ArrowRight,
  CircleAlert,
  CircleCheck,
  CircleDashed,
  Columns3,
  FileSpreadsheet,
  GitCompareArrows,
  KeyRound,
  Link2,
  Network,
  ShieldCheck,
  Table2,
} from "lucide-react";
import { useMemo, useState } from "react";
import { Link } from "react-router-dom";

import type { ModelTable, SpecTable } from "@/api/types";
import { ErDiagramView } from "@/components/er/er-diagram";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useIntentDiagram } from "@/hooks/queries";
import { describeError } from "@/lib/api-client";
import { formatInt } from "@/lib/format";
import { cn } from "@/lib/utils";

function Stat({ label, value, tone }: { label: string; value: number | string; tone?: "warning" }) {
  return (
    <div className={cn("rounded-xl border px-3 py-2", tone === "warning" ? "border-amber-500/35 bg-amber-500/5" : "border-border/60 bg-card/60")}>
      <div className={cn("font-display text-lg font-medium tabular-nums", tone === "warning" && "text-amber-700 dark:text-amber-300")}>{value}</div>
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</div>
    </div>
  );
}

function KeyChips({ keys }: { keys: string[] }) {
  if (!keys.length) return <span className="text-[11px] text-amber-700 dark:text-amber-300">no key</span>;
  return (
    <span className="inline-flex min-w-0 flex-wrap items-center gap-1">
      <KeyRound className="h-3 w-3 shrink-0 text-primary" />
      {keys.map((k) => (
        <span key={k} className="rounded border border-border/60 bg-background/70 px-1 font-mono text-[10.5px]">
          {k}
        </span>
      ))}
    </span>
  );
}

// --------------------------------------------------------------------------- a table set
function TableDetail({ table }: { table: SpecTable }) {
  return (
    <div className="grid gap-4 rounded-2xl border border-border/60 bg-card/70 p-3.5 lg:grid-cols-[minmax(0,3fr)_minmax(0,2fr)]">
      <div className="min-w-0">
        <div className="mb-1.5 flex items-center gap-1.5 text-[10px] font-medium uppercase tracking-[0.18em] text-muted-foreground">
          <Columns3 className="h-3.5 w-3.5" /> {table.name} · columns
        </div>
        <div className="overflow-x-auto rounded-xl border border-border/60">
          <table className="w-full text-xs">
            <thead className="bg-muted/40 text-[10px] uppercase tracking-wide text-muted-foreground">
              <tr>
                <th className="px-2 py-1 text-left">Column</th>
                <th className="px-2 py-1 text-left">Type</th>
                <th className="px-2 py-1 text-left">Null</th>
                <th className="px-2 py-1 text-left">Term</th>
                <th className="px-2 py-1 text-left">Header</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/50">
              {table.columns.map((c) => (
                <tr key={c.name}>
                  <td className="px-2 py-1 font-mono">
                    {c.name}
                    {table.keys.includes(c.name) ? <KeyRound className="ml-1 inline h-3 w-3 text-primary" /> : null}
                  </td>
                  <td className="px-2 py-1 font-mono text-muted-foreground">{c.type}</td>
                  <td className="px-2 py-1">{c.nullable ? "yes" : <span className="text-warning">no</span>}</td>
                  <td className="px-2 py-1">
                    {c.term_name ? (
                      <Link to={`/glossary/terms?search=${encodeURIComponent(c.term_name)}`} className="text-primary hover:underline">
                        {c.term_name}
                      </Link>
                    ) : (
                      <span className="text-muted-foreground">–</span>
                    )}
                  </td>
                  <td className="px-2 py-1 text-muted-foreground">{c.source_header}</td>
                </tr>
              ))}
              {table.missing_columns.map((c) => (
                <tr key={`missing-${c}`} className="bg-amber-500/5">
                  <td className="px-2 py-1 font-mono text-amber-700 dark:text-amber-300">{c}</td>
                  <td className="px-2 py-1 text-[11px] text-amber-700 dark:text-amber-300" colSpan={4}>
                    in the contract, not in the file
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <div className="min-w-0">
        <div className="mb-1.5 flex items-center gap-1.5 text-[10px] font-medium uppercase tracking-[0.18em] text-muted-foreground">
          <ShieldCheck className="h-3.5 w-3.5" /> checks · {table.tests.length}
        </div>
        <div className="mb-1.5 flex flex-wrap gap-x-3 text-[10.5px] text-muted-foreground">
          <span className="inline-flex items-center gap-1">
            <CircleCheck className="h-3 w-3 text-emerald-600" /> passes on the file
          </span>
          <span className="inline-flex items-center gap-1">
            <CircleAlert className="h-3 w-3 text-amber-600" /> fails on the file
          </span>
          <span className="inline-flex items-center gap-1">
            <CircleDashed className="h-3 w-3" /> runs after the load
          </span>
        </div>
        <ul className="space-y-1">
          {table.tests.map((t) => (
            <li key={t.name} className="flex items-start gap-2 text-xs" title={t.condition ?? t.detail}>
              {t.sample_failures ? (
                <CircleAlert className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-600" aria-label="fails on the file" />
              ) : t.sample_failures === 0 ? (
                <CircleCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600" aria-label="passes on the file" />
              ) : (
                <CircleDashed className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" aria-label="runs after the load" />
              )}
              <span className="min-w-0">
                <span className="font-mono">{t.name}</span>{" "}
                <span className="text-[10.5px] text-muted-foreground">
                  {t.kind === "query" ? "across tables" : t.kind.replace(/_/g, " ")}
                  {t.origin ? ` · from ${t.origin}` : ""}
                </span>
                {t.sample_failures ? (
                  <span className="block text-[10.5px] text-amber-700 dark:text-amber-300">
                    fails on {t.sample_failures} row{t.sample_failures === 1 ? "" : "s"} of the file
                    {t.sample_examples.length ? `: ${t.sample_examples.join("; ")}` : ""}
                  </span>
                ) : null}
              </span>
            </li>
          ))}
        </ul>
        {table.exemplar_checks.some((c) => c.outcome === "skipped") ? (
          <div className="mt-3">
            <div className="text-[10px] font-medium uppercase tracking-[0.18em] text-muted-foreground">contract checks left out</div>
            <ul className="mt-1 space-y-0.5 text-[11px] text-muted-foreground">
              {table.exemplar_checks
                .filter((c) => c.outcome === "skipped")
                .map((c) => (
                  <li key={c.name}>
                    <span className="font-mono text-foreground/80">{c.name}</span>: {c.detail}
                  </li>
                ))}
            </ul>
          </div>
        ) : null}
      </div>
    </div>
  );
}

/** One table per file: each shaped by its repository contract, grouped by source system. */
export function TableSetView({ tables }: { tables: SpecTable[] }) {
  const [open, setOpen] = useState<string | null>(null);
  const groups = useMemo(() => {
    const by = new Map<string, SpecTable[]>();
    for (const t of tables) by.set(t.source_system || "files", [...(by.get(t.source_system || "files") ?? []), t]);
    return [...by.entries()];
  }, [tables]);
  const checks = tables.reduce((n, t) => n + t.tests.length, 0);
  const across = tables.reduce((n, t) => n + t.tests.filter((x) => x.kind === "query").length, 0);
  const failing = tables.reduce((n, t) => n + t.tests.filter((x) => x.sample_failures).length, 0);
  const lacking = tables.filter((t) => t.missing_columns.length).length;
  const selected = tables.find((t) => t.name === open) ?? null;
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 xl:grid-cols-6">
        <Stat label="tables" value={tables.length} />
        <Stat label="rows in the files" value={tables.reduce((n, t) => n + t.rows, 0).toLocaleString()} />
        <Stat label="columns" value={tables.reduce((n, t) => n + t.columns.length, 0)} />
        <Stat label={`checks · ${across} across tables`} value={checks} />
        <Stat label="checks failing on the files" value={failing} tone={failing ? "warning" : undefined} />
        <Stat label="lack contract columns" value={lacking} tone={lacking ? "warning" : undefined} />
      </div>
      {groups.map(([system, items]) => (
        <div key={system}>
          <div className="mb-1.5 flex items-center gap-2 text-[10px] font-medium uppercase tracking-[0.18em] text-muted-foreground">
            <FileSpreadsheet className="h-3.5 w-3.5" /> {system} · {items.length}
          </div>
          <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
            {items.map((t) => {
              const fails = t.tests.filter((x) => x.sample_failures).length;
              const on = open === t.name;
              return (
                <button
                  key={t.name}
                  type="button"
                  onClick={() => setOpen(on ? null : t.name)}
                  className={cn(
                    "min-w-0 rounded-xl border p-2.5 text-left transition-all hover:-translate-y-px hover:shadow-sm",
                    on ? "border-primary/60 bg-primary/5 shadow-sm" : "border-border/60 bg-card/60",
                  )}
                  aria-expanded={on}
                >
                  <div className="flex items-center gap-1.5">
                    <Table2 className="h-3.5 w-3.5 shrink-0 text-primary" />
                    <span className="truncate font-mono text-xs font-medium">{t.name}</span>
                    {t.exists ? (
                      <Badge variant="muted" className="ml-auto">
                        exists
                      </Badge>
                    ) : null}
                  </div>
                  <div className="mt-0.5 truncate font-mono text-[10.5px] text-muted-foreground">{t.source_file}</div>
                  <div className="mt-1.5 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-[11px] text-muted-foreground">
                    <span className="tabular-nums">{t.rows} rows</span>
                    <span className="tabular-nums">{t.columns.length} cols</span>
                    <span className="tabular-nums">{t.tests.length} checks</span>
                    <KeyChips keys={t.keys} />
                  </div>
                  {fails || t.missing_columns.length ? (
                    <div className="mt-1.5 flex flex-wrap gap-1">
                      {fails ? <Badge variant="warning">{fails} failing on the file</Badge> : null}
                      {t.missing_columns.length ? <Badge variant="warning">lacks {t.missing_columns.join(", ")}</Badge> : null}
                    </div>
                  ) : null}
                </button>
              );
            })}
          </div>
          {selected && items.includes(selected) ? (
            <div className="mt-2">
              <TableDetail table={selected} />
            </div>
          ) : null}
        </div>
      ))}
    </div>
  );
}

// --------------------------------------------------------------------------- a modelled layer
const MODEL_KIND: Record<ModelTable["kind"], string> = {
  dimension: "172 66% 40%",
  fact: "262 70% 58%",
  bridge: "38 92% 50%",
  reference: "200 15% 50%",
  aggregate: "345 75% 55%",
};

const isGood = (f: string) => f.startsWith("compiles") || f.startsWith("every ");
const isWaiting = (f: string) => f.startsWith("left out:") || f.startsWith("none of its sources");
const isProblem = (f: string) => !isGood(f) && !isWaiting(f);

function rejectedOf(model: ModelTable): number {
  const nulls = Object.values(model.nulls ?? {}).reduce((a, b) => a + b, 0);
  return Math.min(model.rows ?? 0, (model.duplicates ?? 0) + nulls);
}

/** What the read-only dry run of the compiled SELECT found: rows that merge, rows the load will reject and why. */
function DryRun({ model }: { model: ModelTable }) {
  if (model.rows === null || model.rows === undefined) return null;
  const rejected = rejectedOf(model);
  const kept = model.rows - rejected;
  const share = model.rows ? (kept / model.rows) * 100 : 0;
  return (
    <div className="mt-2.5 rounded-xl border border-border/60 bg-background/60 p-2.5">
      <div className="flex items-center justify-between text-[10.5px] text-muted-foreground">
        <span>Dry run in Snowflake (read-only)</span>
        <span className="tabular-nums">{formatInt(model.rows)} rows</span>
      </div>
      <div className="mt-1.5 flex h-2 gap-0.5 overflow-hidden rounded-full" role="img" aria-label={`${formatInt(kept)} rows merge, ${formatInt(rejected)} rejected`}>
        {kept ? <span className="h-full rounded-full bg-emerald-500" style={{ width: `${share}%` }} /> : null}
        {rejected ? <span className="h-full flex-1 rounded-full bg-amber-500" /> : null}
        {!model.rows ? <span className="h-full flex-1 rounded-full bg-muted" /> : null}
      </div>
      <div className="mt-1 flex flex-wrap gap-x-3 gap-y-0.5 text-[10.5px] tabular-nums">
        <span className="text-emerald-700 dark:text-emerald-300">{formatInt(kept)} merge</span>
        {model.duplicates ? <span className="text-amber-700 dark:text-amber-300">{formatInt(model.duplicates)} repeat a key</span> : null}
        {Object.entries(model.nulls ?? {}).map(([column, n]) => (
          <span key={column} className="text-amber-700 dark:text-amber-300">
            {formatInt(n)} without {column}
          </span>
        ))}
        {rejected ? <span className="text-muted-foreground">rejected rows go to LOAD_REJECTS with the reason</span> : null}
      </div>
    </div>
  );
}

function ModelCard({ model }: { model: ModelTable }) {
  const color = MODEL_KIND[model.kind];
  const designed = Boolean(model.ddl);
  const problems = model.findings.filter(isProblem);
  const good = model.findings.filter(isGood);
  const waiting = model.waiting_on ?? [];
  return (
    <div className="min-w-0 rounded-2xl border bg-card/70 p-3.5" style={{ borderColor: `hsl(${color} / 0.4)` }}>
      <div className="flex flex-wrap items-center gap-2">
        <span className="rounded-md px-1.5 py-px text-[10px] font-medium uppercase tracking-wide text-white" style={{ background: `hsl(${color})` }}>
          {model.kind}
        </span>
        <span className="font-mono text-sm font-medium">{model.name}</span>
        {model.exists ? <Badge variant="muted">exists</Badge> : null}
        {designed && !model.sql ? <Badge variant="warning">waits</Badge> : null}
        <span className="ml-auto text-[10.5px] text-muted-foreground">{model.load_mode.replace("_", " ")}</span>
      </div>
      <p className="mt-1 text-xs">{model.grain}</p>
      {model.description ? <p className="text-[11px] text-muted-foreground">{model.description}</p> : null}
      <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
        <KeyChips keys={model.keys} />
        <span className="inline-flex min-w-0 flex-wrap items-center gap-1">
          reads
          {model.sources.map((s) => (
            <span key={s} className="rounded border border-border/60 bg-background/70 px-1 font-mono text-[10.5px] text-foreground/80">
              {s.split(".").pop()}
            </span>
          ))}
          {!model.sources.length ? <span className="italic">nothing loaded yet</span> : null}
        </span>
      </div>
      {waiting.length ? (
        <div className="mt-2 flex min-w-0 flex-wrap items-center gap-1 text-[11px] text-muted-foreground">
          <CircleDashed className="h-3.5 w-3.5 shrink-0" /> waits for
          {waiting.map((w) => (
            <span key={w} className="rounded border border-dashed border-border px-1 font-mono text-[10.5px]">
              {w}
            </span>
          ))}
        </div>
      ) : null}
      <DryRun model={model} />
      {designed ? (
        <div className="mt-2 flex items-start gap-1.5 text-[11px] text-muted-foreground">
          <ShieldCheck className="mt-px h-3.5 w-3.5 shrink-0 text-primary" />
          <span>
            created as the design DDL writes it; merged on {model.keys.join(", ") || "its key"}
            {model.hash_column ? `, updated only when ${model.hash_column} changes` : ""}
            {model.updated_column ? `, ${model.updated_column} stamped by the load` : ""}
          </span>
        </div>
      ) : model.exemplar ? (
        <div className="mt-2 flex items-start gap-1.5 text-[11px]">
          <GitCompareArrows className="mt-px h-3.5 w-3.5 shrink-0 text-primary" />
          <span>
            follows <span className="font-mono">{model.exemplar}</span>
            {model.deviations.length ? (
              <ul className="mt-0.5 list-disc pl-4 text-muted-foreground">
                {model.deviations.map((d) => (
                  <li key={d}>{d}</li>
                ))}
              </ul>
            ) : (
              <span className="text-muted-foreground"> as the repository defines it</span>
            )}
          </span>
        </div>
      ) : (
        <div className="mt-2 text-[11px] text-muted-foreground">new: the repository has no model for it</div>
      )}
      {good.length || problems.length ? (
        <ul className="mt-2 space-y-0.5 text-[11px]">
          {good.map((f) => (
            <li key={f} className="flex items-start gap-1.5 text-emerald-700 dark:text-emerald-300">
              <CircleCheck className="mt-px h-3.5 w-3.5 shrink-0" /> {f}
            </li>
          ))}
          {problems.map((f) => (
            <li key={f} className="flex items-start gap-1.5 text-amber-700 dark:text-amber-300">
              <CircleAlert className="mt-px h-3.5 w-3.5 shrink-0" /> {f}
            </li>
          ))}
        </ul>
      ) : null}
      <details className="group mt-2.5">
        <summary className="cursor-pointer select-none text-[11px] font-medium text-primary">
          {model.columns.length} columns{model.relationships.length ? ` · ${model.relationships.length} relationships` : ""}
          {model.sql ? " · SQL" : ""}
          {designed ? " · DDL" : ""}
        </summary>
        <div className="mt-2 overflow-x-auto rounded-xl border border-border/60">
          <table className="w-full text-xs">
            <thead className="bg-muted/40 text-[10px] uppercase tracking-wide text-muted-foreground">
              <tr>
                <th className="px-2 py-1 text-left">Column</th>
                <th className="px-2 py-1 text-left">Type</th>
                <th className="px-2 py-1 text-left">From</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/50">
              {model.columns.map((c) => (
                <tr key={c.name} title={c.description || undefined}>
                  <td className="px-2 py-1 font-mono">{c.name}</td>
                  <td className="px-2 py-1 font-mono text-muted-foreground">{c.type}</td>
                  <td className="max-w-[18rem] truncate px-2 py-1 font-mono text-muted-foreground" title={c.expression}>
                    {c.expression}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {model.relationships.length ? (
          <ul className="mt-2 space-y-0.5 text-[11px]">
            {model.relationships.map((r) => (
              <li key={`${r.columns.join(",")}-${r.to_table}`} className="flex flex-wrap items-center gap-1">
                <Link2 className="h-3 w-3 text-muted-foreground" />
                <span className="font-mono">{r.columns.join(", ")}</span>
                <ArrowRight className="h-3 w-3 text-muted-foreground" />
                <span className="font-mono">
                  {r.to_table}({(r.to_columns.length ? r.to_columns : r.columns).join(", ")})
                </span>
              </li>
            ))}
          </ul>
        ) : null}
        {model.sql ? (
          <pre className="mt-2 max-h-72 overflow-auto rounded-xl border border-border/60 bg-muted/40 p-2.5 font-mono text-[11px] leading-relaxed">
            {model.sql}
          </pre>
        ) : null}
        {designed ? (
          <pre className="mt-2 max-h-56 overflow-auto rounded-xl border border-border/60 bg-muted/40 p-2.5 font-mono text-[11px] leading-relaxed">
            {model.ddl}
          </pre>
        ) : null}
      </details>
    </div>
  );
}

/** The proposed layer: one card per table, with what the deterministic checks (or the dry run of the design) found. */
export function ModelView({ models, intentId }: { models: ModelTable[]; intentId?: string }) {
  const [view, setView] = useState<"tables" | "er">("tables");
  const diagram = useIntentDiagram(intentId ?? null, view === "er");
  const kinds = models.reduce<Record<string, number>>((acc, m) => ({ ...acc, [m.kind]: (acc[m.kind] ?? 0) + 1 }), {});
  const problems = models.reduce((n, m) => n + m.findings.filter(isProblem).length, 0);
  const designed = models.some((m) => m.ddl);
  const rows = models.reduce((n, m) => n + (m.rows ?? 0), 0);
  const rejected = models.reduce((n, m) => n + rejectedOf(m), 0);
  const waiting = models.filter((m) => !m.sql).length;
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 xl:grid-cols-6">
        <Stat label="tables" value={models.length} />
        {Object.entries(kinds).map(([k, n]) => (
          <Stat key={k} label={`${k}${n === 1 ? "" : "s"}`} value={n} />
        ))}
        {designed ? (
          <>
            <Stat label="rows in the dry run" value={formatInt(rows)} />
            <Stat label="to reject" value={formatInt(rejected)} tone={rejected ? "warning" : undefined} />
            {waiting ? <Stat label="wait for sources" value={waiting} tone="warning" /> : null}
          </>
        ) : (
          <Stat label="follow the repository" value={models.filter((m) => m.exemplar).length} />
        )}
        <Stat label="findings" value={problems} tone={problems ? "warning" : undefined} />
      </div>
      {intentId ? (
        <div className="inline-flex rounded-lg border border-border/70 bg-card p-0.5" role="group" aria-label="How to show the model">
          {(
            [
              ["tables", "Tables", Table2],
              ["er", "ER diagram", Network],
            ] as const
          ).map(([key, label, Icon]) => (
            <button
              key={key}
              type="button"
              aria-pressed={view === key}
              onClick={() => setView(key)}
              className={cn("inline-flex items-center gap-1 rounded-md px-2.5 py-1 text-xs", view === key ? "bg-primary/15 font-medium text-primary" : "text-muted-foreground hover:text-foreground")}
            >
              <Icon className="h-3.5 w-3.5" /> {label}
            </button>
          ))}
        </div>
      ) : null}
      {view === "er" ? (
        diagram.isLoading ? (
          <Skeleton className="h-80 w-full rounded-xl" />
        ) : diagram.data ? (
          <ErDiagramView diagram={diagram.data} />
        ) : (
          <p className="rounded-xl border border-dashed p-4 text-sm text-muted-foreground">The diagram could not be drawn: {describeError(diagram.error)}</p>
        )
      ) : (
        <div className="grid gap-3 xl:grid-cols-2">
          {models.map((m) => (
            <ModelCard key={m.name} model={m} />
          ))}
        </div>
      )}
    </div>
  );
}
