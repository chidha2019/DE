import {
  BadgeCheck,
  BrainCircuit,
  CircleAlert,
  CodeXml,
  DatabaseZap,
  ExternalLink,
  FileText,
  FolderOpen,
  Info,
  KeyRound,
  MessageSquareReply,
  PenLine,
  PlayCircle,
  Rocket,
  ScanSearch,
  Sparkles,
  TicketCheck,
  Waypoints,
  Workflow,
  X,
} from "lucide-react";
import { useState } from "react";
import { Link } from "react-router-dom";

import type { IntentRecord, PipelineSpec, SpecCatalogMatch, SpecJoin } from "@/api/types";
import { INTENT_STATUS, IntentStatusBadge, JourneyBar } from "@/components/intents/intent-status";
import { ReadView, ReviewChip, ReviewView } from "@/components/intents/intent-review";
import { RouteView } from "@/components/intents/route-view";
import { RunView } from "@/components/intents/run-view";
import { DownstreamModels, ExemplarChecks, SpecTests } from "@/components/intents/spec-exemplar";
import { ModelView, TableSetView } from "@/components/intents/spec-tables";
import { WorkflowView } from "@/components/intents/workflow-view";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { useAnswerIntent, useDecideIntent, useIntentFiles, useIntentsConfig, useReplanIntent, useRunIntent } from "@/hooks/queries";
import { describeError } from "@/lib/api-client";
import { formatDateTime } from "@/lib/format";
import { cn } from "@/lib/utils";

function Fact({ label, value, mono }: { label: string; value: string | null | undefined; mono?: boolean }) {
  return (
    <div className="min-w-0">
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className={cn("truncate text-xs", mono && "font-mono")} title={value ?? ""}>
        {value || <span className="text-muted-foreground">not set</span>}
      </div>
    </div>
  );
}

function Section({ title, items, tone }: { title: string; items: string[]; tone?: "warning" }) {
  if (!items.length) return null;
  return (
    <div>
      <div className={cn("text-[10px] font-medium uppercase tracking-[0.2em]", tone === "warning" ? "text-warning" : "text-muted-foreground")}>{title}</div>
      <ul className="mt-1 space-y-1 text-xs">
        {items.map((item) => (
          <li key={item} className="flex gap-2">
            <span className={cn("mt-1.5 h-1 w-1 shrink-0 rounded-full", tone === "warning" ? "bg-warning" : "bg-muted-foreground")} aria-hidden="true" />
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

const JOIN_KIND: Record<string, string> = {
  shared_key: "shared identifier",
  foreign_key: "foreign key",
  join_declared: "declared join",
  join_inferred: "inferred join",
};

/** The catalog table the feed resembles: how much it shares, its key, the types it lent, and the joins it brings. */
function CatalogMatchCard({ match, joins }: { match: SpecCatalogMatch | null; joins: SpecJoin[] }) {
  if (!match && !joins.length) return null;
  const tone = match?.duplicate ? "38 92% 50%" : "225 65% 50%";
  return (
    <div className="relative overflow-hidden rounded-2xl border bg-card/80 p-3.5" style={{ borderColor: `hsl(${tone} / 0.4)` }}>
      <span
        className="pointer-events-none absolute -right-10 -top-12 h-28 w-28 rounded-full opacity-15 blur-2xl"
        style={{ background: `hsl(${tone})` }}
        aria-hidden="true"
      />
      {match ? (
        <div className="relative flex flex-wrap items-start gap-3">
          <span
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-white"
            style={{ background: `linear-gradient(140deg, hsl(${tone} / 0.7), hsl(${tone}))` }}
          >
            <Waypoints className="h-[18px] w-[18px]" />
          </span>
          <div className="min-w-0 flex-1 basis-64">
            <div className="text-[10px] font-medium uppercase tracking-[0.18em] text-muted-foreground">Catalog match</div>
            {match.link ? (
              <Link to={match.link} className="break-all font-mono text-sm font-medium text-primary hover:underline">
                {match.fqn}
              </Link>
            ) : (
              <span className="break-all font-mono text-sm font-medium">{match.fqn}</span>
            )}
            <div className="mt-1 text-[11px] text-muted-foreground">
              {match.matched_columns.length} of the feed&apos;s {match.feed_columns} columns are in it ({match.table_columns} columns there)
              {match.types_adopted ? ` · ${match.types_adopted} column type${match.types_adopted === 1 ? "" : "s"} taken from it` : ""}
              {match.type_conflicts ? ` · ${match.type_conflicts} type conflict${match.type_conflicts === 1 ? "" : "s"}` : ""}
            </div>
            <div className="mt-1.5 h-1.5 w-full max-w-xs overflow-hidden rounded-full bg-muted" aria-hidden="true">
              <span className="block h-full rounded-full" style={{ width: `${Math.round(match.coverage * 100)}%`, background: `hsl(${tone})` }} />
            </div>
            <div className="mt-2 flex flex-wrap gap-1">
              {match.matched_columns.map((c) => (
                <span key={c} className="rounded-md border border-border/60 bg-background/60 px-1.5 py-px font-mono text-[10.5px]">
                  {c}
                </span>
              ))}
            </div>
          </div>
          {match.key.length ? (
            <div
              className="flex items-center gap-1.5 rounded-lg border border-border/60 bg-background/60 px-2 py-1 text-[11px]"
              title="The table's declared primary key"
            >
              <KeyRound className="h-3.5 w-3.5 text-primary" />
              <span className="font-mono">{match.key.join(", ")}</span>
              <span className={match.key_in_feed ? "text-emerald-700 dark:text-emerald-300" : "text-amber-700 dark:text-amber-300"}>
                {match.key_in_feed ? "used as the key" : "not in the files"}
              </span>
            </div>
          ) : null}
        </div>
      ) : null}
      {match?.duplicate ? (
        <div className="relative mt-2.5 flex items-start gap-1.5 rounded-lg border border-amber-500/30 bg-amber-500/10 px-2.5 py-1.5 text-[11px] text-amber-800 dark:text-amber-200">
          <CircleAlert className="mt-px h-3.5 w-3.5 shrink-0" /> Possible duplicate: {match.duplicate_reason}. Load into it, or say why a second copy is needed.
        </div>
      ) : null}
      {joins.length ? (
        <div className="relative mt-3">
          <div className="mb-1 text-[10px] font-medium uppercase tracking-[0.18em] text-muted-foreground">Joins · {joins.length}</div>
          <ul className="space-y-1">
            {joins.map((j) => (
              <li key={`${j.columns.join(",")}-${j.to_table}`} className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs">
                <span className="font-mono">{j.columns.join(", ")}</span>
                <span className="text-muted-foreground">→</span>
                {j.link ? (
                  <Link to={j.link} className="break-all font-mono text-primary hover:underline">
                    {j.to_table}
                  </Link>
                ) : (
                  <span className="break-all font-mono">{j.to_table}</span>
                )}
                <span className="font-mono text-muted-foreground">({j.to_columns.join(", ")})</span>
                <Badge variant="outline" className="font-normal">
                  {JOIN_KIND[j.kind] ?? j.kind.replace(/_/g, " ")}
                  {j.confidence < 1 ? ` · ${Math.round(j.confidence * 100)}%` : ""}
                </Badge>
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </div>
  );
}

function SpecView({ spec, intentId }: { spec: PipelineSpec; intentId: string }) {
  const t = spec.target;
  const tables = spec.tables ?? [];
  const models = spec.models ?? [];
  const many = tables.length || models.length;
  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Fact label="Pipeline" value={spec.name} mono />
        <Fact
          label="Target"
          value={many ? `${t.database ?? "?"}.${t.schema ?? "?"} · ${many} tables` : `${t.database ?? "?"}.${t.schema ?? "?"}.${t.table ?? "?"}`}
          mono
        />
        {models.length ? (
          <Fact label="Built from" value={`${spec.source.database ?? t.database ?? "?"}.${spec.source.schema ?? "?"}`} mono />
        ) : (
          <Fact label="Stage · format" value={`${spec.stage_name} · ${spec.file_format_name}`} mono />
        )}
        <Fact label="Schedule" value={spec.schedule === "manual" ? "on demand" : `cron ${spec.schedule} UTC`} mono />
      </div>
      {tables.length ? <TableSetView tables={tables} /> : null}
      {models.length ? <ModelView models={models} intentId={intentId} /> : null}
      <CatalogMatchCard match={spec.catalog_match ?? null} joins={spec.joins ?? []} />
      {spec.columns.length ? (
        <div className="overflow-x-auto rounded-xl border border-border/60">
          <table className="w-full text-xs">
            <thead className="bg-muted/40 text-[10px] uppercase tracking-wide text-muted-foreground">
              <tr>
                <th className="px-2 py-1.5 text-left">Column</th>
                <th className="px-2 py-1.5 text-left">Type</th>
                <th className="px-2 py-1.5 text-left">Catalog</th>
                <th className="px-2 py-1.5 text-left">Null</th>
                <th className="px-2 py-1.5 text-left">Business term</th>
                <th className="px-2 py-1.5 text-left">Source header</th>
                <th className="px-2 py-1.5 text-left">Sample</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/50">
              {spec.columns.map((c) => (
                <tr key={c.name}>
                  <td className="px-2 py-1 font-mono">{c.name}</td>
                  <td className="px-2 py-1 font-mono text-muted-foreground">{c.type}</td>
                  <td
                    className="px-2 py-1 font-mono text-muted-foreground"
                    title={c.catalog_type ? "The type the matching catalog table gives this column" : undefined}
                  >
                    {c.catalog_type ?? <span>–</span>}
                  </td>
                  <td className="px-2 py-1">{c.nullable ? "yes" : <span className="text-warning">no</span>}</td>
                  <td className="px-2 py-1">
                    {c.term_name ? (
                      <Link to={`/glossary/terms?search=${encodeURIComponent(c.term_name)}`} className="text-primary hover:underline">
                        {c.term_name}
                      </Link>
                    ) : (
                      <span className="text-muted-foreground">–</span>
                    )}
                  </td>
                  <td className="px-2 py-1 text-muted-foreground">{c.source_header}</td>
                  <td className="max-w-[12rem] truncate px-2 py-1 font-mono text-muted-foreground" title={c.sample ?? ""}>
                    {c.sample}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}
      <div className="grid gap-4 md:grid-cols-2">
        <Section title="Assumptions" items={spec.assumptions} />
        <Section title="Risks" items={spec.risks} tone="warning" />
      </div>
      <SpecTests tests={spec.tests} />
      <ExemplarChecks checks={spec.exemplar_checks} exemplar={spec.matches.find((m) => m.kind === "exemplar")} />
      <DownstreamModels models={spec.downstream} table={tables.length ? `${t.schema ?? "BRONZE"} tables` : `${t.schema ?? "BRONZE"}.${t.table ?? "?"}`} />
      {spec.matches.length ? (
        <div>
          <div className="text-[10px] font-medium uppercase tracking-[0.2em] text-muted-foreground">Related in the hub</div>
          <ul className="mt-1 space-y-1 text-xs">
            {spec.matches.map((m) => (
              <li key={`${m.kind}-${m.name}`} className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
                <Badge variant="outline" className="font-normal">
                  {m.kind}
                </Badge>
                {m.link ? (
                  <Link to={m.link} className="min-w-0 break-all font-mono text-primary hover:underline">
                    {m.name}
                  </Link>
                ) : (
                  <span className="min-w-0 break-all font-mono">{m.name}</span>
                )}
                <span className="min-w-0 text-[10px] text-muted-foreground">{m.detail}</span>
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </div>
  );
}

function FilesView({ intent }: { intent: IntentRecord }) {
  const files = useIntentFiles(intent.id, intent.coder !== null);
  const [selected, setSelected] = useState<string | null>(null);
  const coder = intent.coder;
  if (!coder) return <p className="text-xs text-muted-foreground">Nothing generated yet: approve the plan and the generator writes the pipeline here.</p>;
  const activePath = selected ?? files.data?.[0]?.path ?? null;
  const current = files.data?.find((f) => f.path === activePath);
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2 text-xs">
        <Badge variant={coder.tests_passed === true ? "success" : coder.tests_passed === false ? "destructive" : "muted"}>
          {coder.tests_passed === true ? "tests passed" : coder.tests_passed === false ? "tests failed" : "tests not run"}
        </Badge>
        {coder.branch ? <span className="font-mono text-muted-foreground">{coder.branch}</span> : null}
        {coder.pr_url ? (
          <a href={coder.pr_url} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-primary hover:underline">
            pull request <ExternalLink className="h-3 w-3" />
          </a>
        ) : (
          <span className="text-muted-foreground">no remote configured: the files are in the workspace</span>
        )}
        <span className="flex items-center gap-1 font-mono text-[10px] text-muted-foreground">
          <FolderOpen className="h-3 w-3" /> {coder.workspace}
        </span>
      </div>
      <p className="text-xs text-muted-foreground">{coder.summary}</p>
      <div className="grid gap-3 md:grid-cols-[14rem_minmax(0,1fr)]">
        <div className="space-y-0.5">
          {coder.files.map((f) => (
            <button
              key={f.path}
              type="button"
              onClick={() => setSelected(f.path)}
              className={cn(
                "flex w-full items-center gap-2 rounded-md px-2 py-1 text-left font-mono text-[11px]",
                activePath === f.path ? "bg-primary/10 text-foreground" : "text-muted-foreground hover:bg-muted/50",
              )}
            >
              <FileText className="h-3 w-3 shrink-0" />
              <span className="truncate">{f.path}</span>
              <span className="ml-auto text-[10px]">{f.bytes} B</span>
            </button>
          ))}
        </div>
        <pre className="max-h-[28rem] overflow-auto rounded-xl border border-border/60 bg-background/60 p-3 font-mono text-[11px] leading-relaxed">
          {files.isLoading ? "Loading…" : (current?.content ?? "Select a file.")}
        </pre>
      </div>
      {coder.tests_passed === false && coder.test_output ? (
        <pre className="max-h-48 overflow-auto rounded-xl border border-destructive/40 bg-destructive/5 p-3 font-mono text-[11px] text-destructive">
          {coder.test_output}
        </pre>
      ) : null}
    </div>
  );
}

/** The ticket as it came in, then what the hub posted back on it. */
function TicketView({ intent }: { intent: IntentRecord }) {
  return (
    <div className="space-y-4">
      <div className="overflow-hidden rounded-2xl border border-border/60 bg-card/80">
        <div className="flex flex-wrap items-center gap-2 border-b border-border/60 bg-muted/30 px-3.5 py-2 text-[11px] text-muted-foreground">
          <TicketCheck className="h-3.5 w-3.5 text-primary" />
          <span className="font-mono font-medium text-foreground">{intent.jira_key ?? "manual ticket"}</span>
          {intent.reporter ? <span>reported by {intent.reporter}</span> : null}
          <span className="ml-auto">{formatDateTime(intent.created_at)}</span>
        </div>
        <div className="p-3.5">
          <div className="text-sm font-medium">{intent.title}</div>
          <p className="mt-1.5 whitespace-pre-wrap text-xs leading-relaxed text-muted-foreground">{intent.text || "No description."}</p>
        </div>
      </div>
      {intent.answers.length ? (
        <div>
          <div className="mb-1.5 text-[10px] font-medium uppercase tracking-[0.18em] text-muted-foreground">Answers given</div>
          <ul className="space-y-1.5">
            {intent.answers.map((a, i) => (
              <li key={i} className="flex items-start gap-2 rounded-lg border border-border/60 bg-background/50 px-2.5 py-1.5 text-xs">
                <MessageSquareReply className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" /> {a}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
      <div>
        <div className="mb-1.5 text-[10px] font-medium uppercase tracking-[0.18em] text-muted-foreground">
          The plan as posted {intent.source === "jira" ? "on the issue" : "for review"}
        </div>
        <pre className="whitespace-pre-wrap rounded-xl border border-border/60 bg-background/60 p-3 font-mono text-[11px] leading-relaxed">
          {intent.spec_markdown || "Written here once the planner has run."}
        </pre>
        {intent.posted.length ? (
          <div className="mt-2 flex flex-wrap gap-2 text-[11px] text-muted-foreground">
            <span>Jira activity:</span>
            {intent.posted.map((p, i) => (
              <span key={i}>
                {String(p.kind)}
                {p.at ? ` (${formatDateTime(String(p.at))})` : ""}
              </span>
            ))}
          </div>
        ) : null}
      </div>
    </div>
  );
}

/** One intent: how far it has come, what was read and reviewed, the plan as a workflow, and what was generated. */
export function IntentDetail({ intent, loading }: { intent: IntentRecord | undefined; loading: boolean }) {
  const answer = useAnswerIntent();
  const decide = useDecideIntent();
  const replan = useReplanIntent();
  const runIt = useRunIntent();
  const config = useIntentsConfig().data;
  const [answers, setAnswers] = useState("");
  const [note, setNote] = useState("");
  if (loading && !intent) {
    return (
      <div className="surface space-y-3 p-4">
        <Skeleton className="h-6 w-2/3" />
        <Skeleton className="h-4 w-1/2" />
        <Skeleton className="h-40 w-full" />
      </div>
    );
  }
  if (!intent) {
    return (
      <div className="surface relative flex h-full min-h-[18rem] flex-col items-center justify-center overflow-hidden p-8 text-center">
        <div className="hero-grid pointer-events-none absolute inset-0 opacity-60" aria-hidden="true" />
        <div className="relative flex items-center gap-2">
          {[BrainCircuit, ScanSearch, Workflow, BadgeCheck].map((Icon, i) => (
            <span
              key={i}
              className="flex h-10 w-10 items-center justify-center rounded-2xl border border-border/60 bg-card/80 text-primary shadow-sm"
              style={{ transform: `translateY(${i % 2 ? 6 : -2}px)` }}
            >
              <Icon className="h-5 w-5" />
            </span>
          ))}
        </div>
        <h3 className="relative mt-4 font-display text-lg font-medium">Pick an intent, or hand the hub a ticket</h3>
        <p className="relative mt-1 max-w-md text-sm text-muted-foreground">
          What Claude read from it, the review with its score, the plan as a workflow and the generated pipeline appear here.
        </p>
      </div>
    );
  }
  const busy = answer.isPending || decide.isPending || replan.isPending || runIt.isPending;
  const error = answer.error ?? decide.error ?? replan.error ?? runIt.error;
  const color = INTENT_STATUS[intent.status].color;
  const attention = intent.workflow.filter((s) => s.status === "attention").length;
  const canReplan = ["spec_proposed", "failed", "clarifying", "rejected", "waiting"].includes(intent.status);
  const runEnabled = Boolean(config?.run_enabled);
  // The hub runs file loads and modelled layers; anything else goes to a person.
  const runs = runEnabled && (intent.spec?.kind === "ingest_csv_to_iceberg" || (intent.spec?.kind === "model_layer" && Boolean(intent.spec.models?.length)));
  const autoruns = runs && Boolean(config?.autorun);
  const canRun = runs && Boolean(intent.coder) && ["pr_open", "loaded", "failed"].includes(intent.status);
  const missing = intent.run_missing ?? [];
  const defaultTab =
    intent.status === "clarifying"
      ? "review"
      : intent.status === "waiting" || intent.status === "modeling"
        ? "validate"
        : intent.run || intent.status === "running"
          ? "run"
          : intent.coder
            ? "generated"
            : intent.spec
              ? "plan"
              : intent.intent
                ? "read"
                : "ticket";
  const SourceIcon = intent.source === "jira" ? TicketCheck : PenLine;
  return (
    <div className="surface flex min-h-0 flex-1 flex-col overflow-hidden">
      <div className="relative border-b border-border/60 p-4" style={{ background: `linear-gradient(110deg, hsl(${color} / 0.1), transparent 60%)` }}>
        <div className="flex items-start gap-3">
          <span
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl text-white"
            style={{ background: `linear-gradient(140deg, hsl(${color} / 0.7), hsl(${color}))`, boxShadow: `0 12px 24px -14px hsl(${color})` }}
          >
            <SourceIcon className="h-5 w-5" />
          </span>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="font-display text-xl font-medium tracking-tight">{intent.title}</h2>
              <IntentStatusBadge status={intent.status} />
              {intent.jira_key ? (
                intent.jira_url ? (
                  <a
                    href={intent.jira_url}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 rounded-md border border-border/70 bg-background/70 px-1.5 py-px font-mono text-xs text-primary hover:underline"
                  >
                    {intent.jira_key} <ExternalLink className="h-3 w-3" />
                  </a>
                ) : (
                  <span className="rounded-md border border-border/70 bg-background/70 px-1.5 py-px font-mono text-xs">{intent.jira_key}</span>
                )
              ) : null}
            </div>
            <div className="mt-0.5 text-[11px] text-muted-foreground">
              {intent.reporter ? `${intent.reporter} · ` : ""}created {formatDateTime(intent.created_at)} · updated {formatDateTime(intent.updated_at)}
            </div>
          </div>
          {intent.review ? (
            <div className="hidden shrink-0 sm:block">
              <ReviewChip review={intent.review} />
            </div>
          ) : null}
        </div>
        <div className="mt-3">
          <JourneyBar status={intent.status} route={intent.route} />
          {intent.route ? (
            <p className="mt-1.5 truncate text-[11px] text-muted-foreground" title={intent.route.reason}>
              <span className="font-medium text-foreground/80">{intent.route.title}</span> · {intent.route.reason}
            </p>
          ) : null}
        </div>
        {intent.error ? (
          <div className="mt-3 flex items-start gap-2 rounded-lg border border-destructive/40 bg-destructive/5 p-2 text-xs text-destructive">
            <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {intent.error}
          </div>
        ) : null}
        {intent.status === "spec_proposed" && intent.spec?.blockers?.length ? (
          <div className="mt-3 rounded-lg border border-rose-500/40 bg-rose-500/5 p-2.5 text-xs">
            <div className="flex items-center gap-1.5 font-medium text-rose-700 dark:text-rose-300">
              <CircleAlert className="h-3.5 w-3.5" /> Blocked: this plan reads tables that hold no rows
            </div>
            <ul className="mt-1 list-disc space-y-0.5 pl-5 text-muted-foreground">
              {intent.spec.blockers.map((b) => (
                <li key={b} className="font-mono text-[11px]">
                  {b}
                </li>
              ))}
            </ul>
            <p className="mt-1 text-muted-foreground">A pipeline built on them would pass review and return nothing. Load them, then re-plan.</p>
          </div>
        ) : null}
        {intent.status === "spec_proposed" || intent.status === "pr_open" || intent.status === "loaded" || canReplan || canRun ? (
          <div className="mt-3 flex flex-wrap items-center gap-2">
            {intent.status === "spec_proposed" ? (
              <>
                <Button
                  size="sm"
                  disabled={busy || Boolean(intent.spec?.blockers?.length)}
                  onClick={() => decide.mutate({ id: intent.id, body: { decision: "approve", note } })}
                  title={
                    autoruns
                      ? "Generate the pipeline from this plan, then run it: upload the files, create the tables, load and check"
                      : "Generate the pipeline from this plan"
                  }
                >
                  <BadgeCheck className="h-3.5 w-3.5" /> {autoruns ? "Approve and run" : "Approve and generate"}
                </Button>
                {autoruns && missing.length ? (
                  <span className="inline-flex items-center gap-1 text-[11px] text-amber-700 dark:text-amber-300" title={missing.join(", ")}>
                    <CircleAlert className="h-3.5 w-3.5" /> the run needs {missing.length} setting{missing.length === 1 ? "" : "s"} in .env (see Run)
                  </span>
                ) : null}
                <Input value={note} onChange={(e) => setNote(e.target.value)} placeholder="note (optional)" className="h-8 w-56 text-xs" />
                <Button size="sm" variant="outline" disabled={busy} onClick={() => decide.mutate({ id: intent.id, body: { decision: "reject", note } })}>
                  <X className="h-3.5 w-3.5" /> Reject
                </Button>
                {attention ? (
                  <span className="inline-flex items-center gap-1 text-[11px] text-amber-700 dark:text-amber-300">
                    <CircleAlert className="h-3.5 w-3.5" /> {attention} step{attention === 1 ? "" : "s"} need{attention === 1 ? "s" : ""} attention
                  </span>
                ) : null}
              </>
            ) : null}
            {canRun ? (
              <Button
                size="sm"
                variant={intent.status === "loaded" ? "outline" : "default"}
                disabled={busy}
                onClick={() => runIt.mutate(intent.id)}
                title="Upload the files, create the stage and tables, load and check, then refresh the catalog"
              >
                <PlayCircle className="h-3.5 w-3.5" /> {intent.run ? "Run again" : "Run pipeline"}
              </Button>
            ) : null}
            {intent.status === "pr_open" || intent.status === "loaded" ? (
              <Button
                size="sm"
                variant={intent.status === "loaded" ? "default" : "outline"}
                disabled={busy}
                onClick={() => decide.mutate({ id: intent.id, body: { decision: "done", note } })}
                title="The change landed and the numbers look right"
              >
                <Rocket className="h-3.5 w-3.5" /> Mark done
              </Button>
            ) : null}
            {canReplan ? (
              <Button
                size="sm"
                variant="outline"
                disabled={busy}
                onClick={() => replan.mutate(intent.id)}
                title="Read, review and plan again from the ticket and its answers"
              >
                <Sparkles className="h-3.5 w-3.5" /> Re-plan
              </Button>
            ) : null}
            {error ? <span className="text-xs text-destructive">{describeError(error)}</span> : null}
          </div>
        ) : null}
      </div>

      <Tabs key={`${intent.id}-${intent.status}`} defaultValue={defaultTab} className="flex min-h-0 flex-1 flex-col p-4">
        <TabsList className="h-auto max-w-full flex-wrap justify-start">
          <TabsTrigger value="read" disabled={!intent.intent} className="gap-1.5">
            <BrainCircuit className="h-3.5 w-3.5" /> Read
          </TabsTrigger>
          <TabsTrigger value="review" disabled={!intent.review} className="gap-1.5">
            <ScanSearch className="h-3.5 w-3.5" /> Review{intent.review ? ` · ${intent.review.score}` : ""}
          </TabsTrigger>
          <TabsTrigger value="validate" disabled={!intent.validation && !intent.route} className="gap-1.5">
            <DatabaseZap className="h-3.5 w-3.5" /> Validate
          </TabsTrigger>
          <TabsTrigger value="plan" disabled={!intent.spec} className="gap-1.5">
            <Workflow className="h-3.5 w-3.5" /> Plan{intent.workflow.length ? ` · ${intent.workflow.length} steps` : ""}
          </TabsTrigger>
          <TabsTrigger value="generated" disabled={!intent.coder} className="gap-1.5">
            <CodeXml className="h-3.5 w-3.5" /> Generated{intent.coder ? ` · ${intent.coder.files.length}` : ""}
          </TabsTrigger>
          <TabsTrigger value="run" disabled={!runs && !intent.run} className="gap-1.5">
            <PlayCircle className="h-3.5 w-3.5" /> Run
            {intent.run ? ` · ${intent.run.status === "succeeded" ? "loaded" : intent.run.status === "failed" ? "stopped" : "running"}` : ""}
          </TabsTrigger>
          <TabsTrigger value="ticket" className="gap-1.5">
            <TicketCheck className="h-3.5 w-3.5" /> Ticket
          </TabsTrigger>
        </TabsList>
        <TabsContent value="read" className="min-h-0 flex-1 overflow-auto pt-3">
          {intent.intent ? <ReadView intent={intent.intent} /> : <p className="text-xs text-muted-foreground">Not read yet.</p>}
        </TabsContent>
        <TabsContent value="review" className="min-h-0 flex-1 overflow-auto pt-3">
          {intent.review ? (
            <ReviewView review={intent.review}>
              {intent.status === "clarifying" ? (
                <div className="rounded-2xl border border-orange-500/35 bg-orange-500/5 p-3.5">
                  <div className="flex items-center gap-2 text-xs font-medium text-orange-700 dark:text-orange-300">
                    <MessageSquareReply className="h-4 w-4" /> Answer these and the hub plans again
                    {intent.source === "jira" ? " (or reply on the issue with /answer)" : ""}
                  </div>
                  <ol className="mt-2 space-y-1 text-xs">
                    {intent.questions.map((q, i) => (
                      <li key={q} className="flex gap-2">
                        <span className="flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-orange-500/15 text-[10px] font-medium text-orange-700 dark:text-orange-300">
                          {i + 1}
                        </span>
                        {q}
                      </li>
                    ))}
                  </ol>
                  <Textarea
                    value={answers}
                    onChange={(e) => setAnswers(e.target.value)}
                    rows={3}
                    className="mt-2.5 text-sm"
                    placeholder="Answer in one message, e.g. files are in policies_sample; load into INSURANCE.BRONZE.POLICY; external volume ECH_ICEBERG_VOL"
                  />
                  <div className="mt-2 flex items-center justify-end gap-2">
                    {error ? <span className="text-xs text-destructive">{describeError(error)}</span> : null}
                    <Button
                      size="sm"
                      disabled={busy || !answers.trim()}
                      onClick={() => answer.mutate({ id: intent.id, answers: [answers.trim()] }, { onSuccess: () => setAnswers("") })}
                    >
                      <MessageSquareReply className="h-3.5 w-3.5" /> {answer.isPending ? "Planning…" : "Send answers"}
                    </Button>
                  </div>
                </div>
              ) : null}
            </ReviewView>
          ) : (
            <p className="text-xs text-muted-foreground">Not reviewed yet.</p>
          )}
        </TabsContent>
        <TabsContent value="validate" className="min-h-0 flex-1 overflow-auto pt-3">
          <RouteView intent={intent} />
          {intent.status === "modeling" ? (
            <p className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
              <Sparkles className="h-3.5 w-3.5 animate-pulse text-primary" /> The data modeler is profiling the tables and trying its SQL; the proposal appears
              in Plan.
            </p>
          ) : null}
        </TabsContent>
        <TabsContent value="plan" className="min-h-0 flex-1 overflow-auto pt-3">
          <WorkflowView steps={intent.workflow} />
          {intent.spec ? (
            <div className="mt-6 border-t border-border/60 pt-4">
              <div className="mb-3 text-[10px] font-medium uppercase tracking-[0.2em] text-muted-foreground">
                {intent.spec.models?.length ? "The proposed model" : intent.spec.tables?.length ? "Tables, checks and impact" : "Columns, tests and impact"}
              </div>
              <SpecView spec={intent.spec} intentId={intent.id} />
            </div>
          ) : null}
        </TabsContent>
        <TabsContent value="generated" className="min-h-0 flex-1 overflow-auto pt-3">
          <FilesView intent={intent} />
        </TabsContent>
        <TabsContent value="run" className="min-h-0 flex-1 overflow-auto pt-3">
          <RunView intent={intent} runEnabled={runEnabled} autorun={Boolean(config?.autorun)} />
        </TabsContent>
        <TabsContent value="ticket" className="min-h-0 flex-1 overflow-auto pt-3">
          <TicketView intent={intent} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
