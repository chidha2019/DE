import {
  BadgeCheck,
  ChevronRight,
  DatabaseZap,
  GitPullRequestArrow,
  Hourglass,
  Library,
  Play,
  Rocket,
  ScanSearch,
  Shapes,
  TicketCheck,
  UserRound,
  WandSparkles,
  Workflow,
  type LucideIcon,
} from "lucide-react";

import type { IntentRoute, IntentStatus } from "@/api/types";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

/** One entry per state of the intent machine: label, colour and the badge tone. */
export const INTENT_STATUS: Record<
  IntentStatus,
  { label: string; color: string; variant: "muted" | "warning" | "info" | "default" | "success" | "destructive" }
> = {
  received: { label: "reading", color: "38 92% 52%", variant: "muted" },
  clarifying: { label: "needs answers", color: "25 95% 53%", variant: "warning" },
  planning: { label: "planning", color: "199 89% 48%", variant: "info" },
  waiting: { label: "waiting upstream", color: "38 92% 50%", variant: "warning" },
  modeling: { label: "modelling", color: "282 70% 58%", variant: "info" },
  spec_proposed: { label: "plan to approve", color: "172 66% 42%", variant: "default" },
  approved: { label: "approved", color: "262 70% 60%", variant: "success" },
  coding: { label: "generating", color: "292 70% 55%", variant: "info" },
  pr_open: { label: "pipeline ready", color: "152 65% 40%", variant: "success" },
  running: { label: "running", color: "152 65% 40%", variant: "info" },
  loaded: { label: "loaded", color: "225 65% 55%", variant: "success" },
  done: { label: "done", color: "160 40% 40%", variant: "muted" },
  rejected: { label: "rejected", color: "200 10% 45%", variant: "muted" },
  failed: { label: "failed", color: "0 72% 55%", variant: "destructive" },
};

export function IntentStatusBadge({ status }: { status: IntentStatus }) {
  const meta = INTENT_STATUS[status];
  return <Badge variant={meta.variant}>{meta.label}</Badge>;
}

export interface FlowStage {
  key: string;
  label: string;
  hint: string;
  icon: LucideIcon;
  statuses: IntentStatus[];
  color: string;
}

/** The chain every ticket walks: read, review, plan, approve, generate, ship. */
export const FLOW: FlowStage[] = [
  {
    key: "ticket",
    label: "Read",
    hint: "Claude reads the ticket into source, target, grain and acceptance criteria",
    icon: TicketCheck,
    statuses: ["received"],
    color: "38 92% 52%",
  },
  {
    key: "review",
    label: "Review",
    hint: "a checklist scores the ticket; what is missing goes back as questions",
    icon: ScanSearch,
    statuses: ["clarifying"],
    color: "25 95% 53%",
  },
  {
    key: "plan",
    label: "Plan",
    hint: "validated in Snowflake (read-only), then planned from the files, modelled by the data modeler, or parked until its upstream tables land",
    icon: Workflow,
    statuses: ["planning", "modeling", "waiting"],
    color: "199 89% 48%",
  },
  {
    key: "gate",
    label: "Approve",
    hint: "a person approves or rejects the plan",
    icon: BadgeCheck,
    statuses: ["spec_proposed", "approved"],
    color: "172 66% 42%",
  },
  {
    key: "code",
    label: "Generate",
    hint: "the generator writes the pipeline and runs its offline tests",
    icon: WandSparkles,
    statuses: ["coding"],
    color: "292 70% 55%",
  },
  {
    key: "pr",
    label: "Ship",
    hint: "files on their own branch in the workspace, ready to merge",
    icon: GitPullRequestArrow,
    statuses: ["pr_open"],
    color: "152 65% 40%",
  },
  {
    key: "run",
    label: "Run",
    hint: "the hub runs the approved pipeline: upload, create, load, check, refresh the catalog",
    icon: Play,
    statuses: ["running", "loaded"],
    color: "225 65% 55%",
  },
  { key: "done", label: "Done", hint: "the change landed", icon: Rocket, statuses: ["done"], color: "160 40% 40%" },
];

export function stageOf(status: IntentStatus): number {
  return FLOW.findIndex((s) => s.statuses.includes(status));
}

/** The whole chain with a count per stage; the selected intent's stage glows. */
export function Lifecycle({ count, active }: { count: (stage: FlowStage) => number; active: IntentStatus | null }) {
  return (
    <ol className="grid gap-2" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(8.5rem, 1fr))" }}>
      {FLOW.map((stage, i) => {
        const Icon = stage.icon;
        const on = active ? stage.statuses.includes(active) : false;
        const n = count(stage);
        return (
          <li
            key={stage.key}
            title={stage.hint}
            className={cn(
              "relative flex min-w-0 items-center gap-2.5 rounded-2xl border bg-card/70 px-3 py-2.5 transition-shadow",
              on ? "shadow-md" : "border-border/60",
            )}
            style={on ? { borderColor: `hsl(${stage.color} / 0.6)`, boxShadow: `0 0 0 3px hsl(${stage.color} / 0.14)` } : undefined}
          >
            <span
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-white"
              style={{
                background: `linear-gradient(140deg, hsl(${stage.color} / 0.7), hsl(${stage.color}))`,
                boxShadow: `0 10px 20px -12px hsl(${stage.color})`,
              }}
            >
              <Icon className="h-[18px] w-[18px]" />
            </span>
            <span className="min-w-0">
              <span className="flex items-center gap-1.5 text-xs font-medium">
                <span className="text-[10px] tabular-nums text-muted-foreground">{i + 1}</span> {stage.label}
              </span>
              <span className="block text-[11px] text-muted-foreground">
                <span className="font-display text-sm font-medium tabular-nums text-foreground">{n}</span> {n === 1 ? "intent" : "intents"}
              </span>
            </span>
            {i < FLOW.length - 1 ? (
              <ChevronRight className="absolute -right-2.5 top-1/2 z-10 hidden h-4 w-4 -translate-y-1/2 text-muted-foreground/60 md:block" aria-hidden="true" />
            ) : null}
          </li>
        );
      })}
    </ol>
  );
}

/** Icon, colour and hint of each stage a route can have. */
const ROUTE_STAGE: Record<string, { icon: LucideIcon; color: string; hint: string }> = {
  read: { icon: TicketCheck, color: "38 92% 52%", hint: "Claude reads the ticket" },
  review: { icon: ScanSearch, color: "25 95% 53%", hint: "the ticket is scored; what is missing goes back as questions" },
  validate: { icon: DatabaseZap, color: "205 85% 50%", hint: "a read-only look in Snowflake: what exists, what is missing" },
  plan: { icon: Workflow, color: "199 89% 48%", hint: "the planner lays out tables, load and checks" },
  model: { icon: Shapes, color: "282 70% 58%", hint: "the data modeler proposes the layer's tables and tries its SQL" },
  wait: { icon: Hourglass, color: "38 92% 50%", hint: "parked until the tables it builds from are loaded" },
  approve: { icon: BadgeCheck, color: "172 66% 42%", hint: "a person approves or rejects the proposal" },
  generate: { icon: WandSparkles, color: "292 70% 55%", hint: "the generator writes the pipeline and runs its offline tests" },
  run: { icon: Play, color: "152 65% 40%", hint: "the hub runs the approved pipeline: upload, create, load, check" },
  catalog: { icon: Library, color: "225 65% 55%", hint: "sync the new tables into the semantic layer" },
};

/** The route's own stages: done filled, current ringed, blocked dashed amber, skipped faded. */
function RouteJourney({ route, status }: { route: IntentRoute; status: IntentStatus }) {
  return (
    <div className="flex items-center gap-1" aria-label={`Route: ${route.title}`}>
      {route.stages.map((stage, i) => {
        const meta = ROUTE_STAGE[stage.key] ?? { icon: UserRound, color: "200 10% 45%", hint: "" };
        const Icon = meta.icon;
        const done = stage.status === "done";
        const current = stage.status === "current";
        const blocked = stage.status === "blocked";
        const color = blocked ? "38 92% 50%" : meta.color;
        return (
          <div key={stage.key} className="flex min-w-0 flex-1 items-center gap-1">
            <span
              title={`${stage.label}: ${stage.detail || meta.hint}`}
              className={cn(
                "flex h-7 w-7 shrink-0 items-center justify-center rounded-full border transition-all",
                current && "animate-pulse-dot",
                blocked && "border-dashed",
                stage.status === "skipped" && "opacity-40",
              )}
              style={
                done || current || blocked
                  ? { background: `hsl(${color} / ${done ? 1 : 0.15})`, borderColor: `hsl(${color})`, color: done ? "white" : `hsl(${color})` }
                  : { borderColor: "hsl(var(--border))", color: "hsl(var(--muted-foreground) / 0.6)" }
              }
            >
              <Icon className="h-3.5 w-3.5" />
            </span>
            {i < route.stages.length - 1 ? (
              <span className="h-0.5 min-w-2 flex-1 rounded-full" style={{ background: done ? `hsl(${color})` : "hsl(var(--border))" }} aria-hidden="true" />
            ) : null}
          </div>
        );
      })}
      {status === "failed" ? <Badge variant="destructive">{INTENT_STATUS[status].label}</Badge> : null}
    </div>
  );
}

/** One intent's way through the chain: its route's stages when it has one, else the general flow. */
export function JourneyBar({ status, route }: { status: IntentStatus; route?: IntentRoute | null }) {
  if (route?.stages.length) return <RouteJourney route={route} status={status} />;
  const at = stageOf(status);
  const stopped = status === "failed" || status === "rejected";
  return (
    <div className="flex items-center gap-1" aria-label={`Stage: ${INTENT_STATUS[status].label}`}>
      {FLOW.map((stage, i) => {
        const Icon = stage.icon;
        const done = at > i || status === "done";
        const current = at === i && status !== "done";
        return (
          <div key={stage.key} className="flex min-w-0 flex-1 items-center gap-1">
            <span
              title={`${stage.label}: ${stage.hint}`}
              className={cn("flex h-7 w-7 shrink-0 items-center justify-center rounded-full border transition-all", current && "animate-pulse-dot")}
              style={
                done || current
                  ? {
                      background: `hsl(${stage.color} / ${done ? 1 : 0.15})`,
                      borderColor: `hsl(${stage.color})`,
                      color: done ? "white" : `hsl(${stage.color})`,
                    }
                  : { borderColor: "hsl(var(--border))", color: "hsl(var(--muted-foreground) / 0.6)" }
              }
            >
              <Icon className="h-3.5 w-3.5" />
            </span>
            {i < FLOW.length - 1 ? (
              <span
                className="h-0.5 min-w-2 flex-1 rounded-full"
                style={{ background: done ? `hsl(${stage.color})` : "hsl(var(--border))" }}
                aria-hidden="true"
              />
            ) : null}
          </div>
        );
      })}
      {stopped ? <Badge variant={status === "failed" ? "destructive" : "muted"}>{INTENT_STATUS[status].label}</Badge> : null}
    </div>
  );
}
