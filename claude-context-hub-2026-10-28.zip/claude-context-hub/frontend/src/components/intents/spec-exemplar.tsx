import { ExternalLink } from "lucide-react";
import type { ReactNode } from "react";
import { Link } from "react-router-dom";

import type { DownstreamColumnStatus, SpecDownstream, SpecDownstreamColumn, SpecExemplarCheck, SpecMatch, SpecTest } from "@/api/types";
import { Badge } from "@/components/ui/badge";

type Tone = "success" | "warning" | "destructive" | "info" | "muted";

function Heading({ children }: { children: ReactNode }) {
  return <div className="text-[10px] font-medium uppercase tracking-[0.2em] text-muted-foreground">{children}</div>;
}

function plural(n: number, word: string) {
  return `${n} ${word}${n === 1 ? "" : "s"}`;
}

function SampleBadge({ test }: { test: SpecTest }) {
  if (test.sample_failures === null) return null;
  if (test.sample_failures === 0) {
    return (
      <Badge variant="success" className="font-normal">
        sample passes
      </Badge>
    );
  }
  return (
    <Badge variant="warning" className="font-normal">
      fails on {plural(test.sample_failures, "sampled row")}
    </Badge>
  );
}

export function SpecTests({ tests }: { tests: SpecTest[] }) {
  if (!tests.length) return null;
  return (
    <div>
      <Heading>Tests</Heading>
      <ul className="mt-1 divide-y divide-border/50 rounded-xl border border-border/60 text-xs">
        {tests.map((t) => {
          const note = [t.detail, t.origin && !t.detail.includes(t.origin) ? `copied from ${t.origin}` : ""].filter(Boolean).join(" · ");
          return (
            <li key={t.name} className="space-y-1 px-3 py-2">
              <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                <span className="font-mono">{t.name}</span>
                <Badge variant="outline" className="font-normal">
                  {t.kind.replace(/_/g, " ")}
                </Badge>
                {t.columns.length ? <span className="min-w-0 break-words text-muted-foreground">on {t.columns.join(", ")}</span> : null}
                <SampleBadge test={t} />
              </div>
              {t.condition ? <code className="block break-words rounded-md bg-muted/50 px-2 py-1 font-mono text-[11px]">{t.condition}</code> : null}
              {note ? <div className="text-[11px] text-muted-foreground">{note}</div> : null}
              {t.sample_failures && t.sample_examples.length ? (
                <div className="text-[11px] text-warning">In the sample: {t.sample_examples.join("; ")}</div>
              ) : null}
            </li>
          );
        })}
      </ul>
    </div>
  );
}

const OUTCOME: Record<SpecExemplarCheck["outcome"], { label: string; tone: Tone }> = {
  copied: { label: "copied", tone: "success" },
  covered: { label: "covered by load", tone: "info" },
  skipped: { label: "skipped", tone: "muted" },
};

export function ExemplarChecks({ checks, exemplar }: { checks: SpecExemplarCheck[]; exemplar: SpecMatch | undefined }) {
  if (!checks.length) return null;
  const count = (outcome: SpecExemplarCheck["outcome"]) => checks.filter((c) => c.outcome === outcome).length;
  return (
    <div>
      <Heading>Checks from the exemplar</Heading>
      <p className="mt-1 text-xs text-muted-foreground">
        {exemplar?.link ? (
          <>
            The quality checks of{" "}
            <Link to={exemplar.link} className="font-mono text-primary hover:underline">
              {exemplar.name}
            </Link>
          </>
        ) : (
          "The exemplar's quality checks"
        )}
        : {count("copied")} copied into the tests, {count("covered")} already enforced by the typed load, {count("skipped")} skipped.
      </p>
      <details className="mt-2 rounded-xl border border-border/60">
        <summary className="cursor-pointer select-none px-3 py-2 text-xs text-muted-foreground hover:text-foreground">Show all {checks.length} checks</summary>
        <ul className="divide-y divide-border/50 border-t border-border/60 text-xs">
          {checks.map((c) => (
            <li key={c.name} className="grid gap-1 px-3 py-1.5 sm:grid-cols-[minmax(0,15rem)_7.5rem_minmax(0,1fr)] sm:items-baseline sm:gap-3">
              <span className="truncate font-mono" title={c.name}>
                {c.name}
              </span>
              <Badge variant={OUTCOME[c.outcome].tone} className="w-fit font-normal">
                {OUTCOME[c.outcome].label}
              </Badge>
              <span className="min-w-0 break-words text-[11px] text-muted-foreground">
                {c.test ? <span className="font-mono text-foreground">{c.test}</span> : null}
                {c.test ? " · " : null}
                {c.detail}
              </span>
            </li>
          ))}
        </ul>
      </details>
    </div>
  );
}

const STATUS: Record<DownstreamColumnStatus, { label: string; tone: Tone }> = {
  mapped: { label: "from this feed", tone: "success" },
  needs: { label: "needs another feed", tone: "warning" },
  missing: { label: "column missing", tone: "destructive" },
  constant: { label: "constant", tone: "info" },
  untraced: { label: "untraced", tone: "muted" },
};

function describe(c: SpecDownstreamColumn): string {
  if (c.status === "mapped") return `← ${c.provided_by.join(", ")}`;
  if (c.status === "constant") return "set in the model itself; give the new rows their own value";
  if (c.status === "untraced") return "lineage not traced";
  const today = `today: ${c.sources.join(", ")}`;
  if (c.status === "missing") return `this feed lacks the exemplar column it reads · ${today}`;
  return c.provided_by.length ? `${today} · this feed supplies ${c.provided_by.join(", ")}` : today;
}

function DownstreamCard({ model }: { model: SpecDownstream }) {
  const total = model.columns.length;
  const mapped = model.columns.filter((c) => c.status === "mapped").length;
  const file = model.files[0];
  return (
    <div className="rounded-xl border border-border/60">
      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 px-3 py-2 text-xs">
        {model.link ? (
          <Link to={model.link} className="font-mono font-medium text-primary hover:underline">
            {model.table}
          </Link>
        ) : (
          <span className="font-mono font-medium">{model.table}</span>
        )}
        {model.layer ? (
          <Badge variant="outline" className="font-normal">
            {model.layer}
          </Badge>
        ) : null}
        {file && model.file_url ? (
          <a
            href={model.file_url}
            target="_blank"
            rel="noreferrer"
            className="inline-flex min-w-0 items-center gap-1 break-all font-mono text-[11px] text-muted-foreground hover:text-foreground"
          >
            {file}
            <ExternalLink className="h-3 w-3 shrink-0" aria-hidden="true" />
          </a>
        ) : file ? (
          <span className="break-all font-mono text-[11px] text-muted-foreground">{file}</span>
        ) : null}
        {total ? (
          <span className="text-[11px] text-muted-foreground sm:ml-auto">
            {mapped} of {plural(total, "column")} from this feed
          </span>
        ) : null}
      </div>
      {total ? (
        <div className="mx-3 h-1.5 overflow-hidden rounded-full bg-muted" role="img" aria-label={`${mapped} of ${total} columns from this feed`}>
          <div className="h-full rounded-full bg-success" style={{ width: `${(mapped / total) * 100}%` }} />
        </div>
      ) : null}
      <div className="space-y-0.5 px-3 pt-2 text-[11px] text-muted-foreground">
        <div>Reads {model.reads.join(", ")}</div>
        {model.affects.length ? <div>Feeds {model.affects.join(", ")}</div> : null}
      </div>
      {total ? (
        <ul className="mt-2 divide-y divide-border/50 border-t border-border/60 text-xs">
          {model.columns.map((c) => (
            <li key={c.column} className="grid gap-1 px-3 py-1.5 sm:grid-cols-[minmax(0,12rem)_9rem_minmax(0,1fr)] sm:items-baseline sm:gap-3">
              <span className="truncate font-mono" title={c.column}>
                {c.column}
              </span>
              <Badge variant={STATUS[c.status].tone} className="w-fit font-normal">
                {STATUS[c.status].label}
              </Badge>
              <span className="min-w-0 break-words font-mono text-[11px] text-muted-foreground">{describe(c)}</span>
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}

export function DownstreamModels({ models, table }: { models: SpecDownstream[]; table: string }) {
  if (!models.length) return null;
  return (
    <div>
      <Heading>Downstream models to update</Heading>
      <p className="mt-1 text-xs text-muted-foreground">
        These models read the exemplar but not <span className="font-mono">{table}</span>. Until each one reads the new table too, its rows stop at this layer.
      </p>
      <div className="mt-2 space-y-3">
        {models.map((m) => (
          <DownstreamCard key={`${m.repo}-${m.table}`} model={m} />
        ))}
      </div>
    </div>
  );
}
