import {
  ArrowRight,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  CircleAlert,
  CircleDashed,
  CircleSlash,
  CloudUpload,
  DatabaseZap,
  FileSpreadsheet,
  FileType2,
  FolderInput,
  Layers,
  Library,
  ListChecks,
  Loader2,
  PlayCircle,
  ShieldAlert,
  ShieldCheck,
  Table2,
  TriangleAlert,
  type LucideIcon,
} from "lucide-react";
import { useMemo, useState } from "react";
import { Link } from "react-router-dom";

import type { IntentRecord, PipelineRun, PipelineSpec, RunCheck, RunModel, RunReconciliation, RunStep } from "@/api/types";
import { BrandMark } from "@/components/connectors/brand-mark";
import { Badge } from "@/components/ui/badge";
import { formatDateTime, formatInt } from "@/lib/format";
import { cn } from "@/lib/utils";

type State = RunStep["status"];
type StageKey = "preflight" | "upload" | "apply" | "load" | "checks" | "catalog";

interface Stage {
  key: StageKey;
  label: string;
  icon: LucideIcon;
  color: string;
  status: State;
  seconds: number | null;
  headline: string;
  sub: string;
  step: RunStep | undefined;
}

const COLORS: Record<StageKey, string> = {
  preflight: "205 85% 50%",
  upload: "199 89% 48%",
  apply: "262 70% 60%",
  load: "172 66% 42%",
  checks: "152 65% 40%",
  catalog: "225 65% 55%",
};

const STATE: Record<State, { icon: LucideIcon; label: string; tone: string }> = {
  pending: { icon: CircleDashed, label: "waiting", tone: "text-muted-foreground" },
  running: { icon: Loader2, label: "running", tone: "text-primary" },
  ok: { icon: CheckCircle2, label: "done", tone: "text-success" },
  failed: { icon: CircleAlert, label: "failed", tone: "text-destructive" },
  skipped: { icon: CircleSlash, label: "skipped", tone: "text-muted-foreground" },
};

function seconds(step: RunStep | undefined): number | null {
  if (!step?.started_at || !step.finished_at) return null;
  return (Date.parse(step.finished_at) - Date.parse(step.started_at)) / 1000;
}

function took(s: number | null): string {
  if (s === null) return "";
  return s < 1 ? "<1 s" : s < 90 ? `${Math.round(s)} s` : `${Math.round(s / 60)} min`;
}

function landingUrl(spec: PipelineSpec | null): string {
  const s = spec?.source;
  if (!s) return "";
  if (s.storage_provider === "azure") return `azure://${s.azure_account ?? "…"}.blob.core.windows.net/${s.azure_container ?? "…"}/${s.azure_prefix ?? ""}`;
  return `s3://${s.s3_bucket ?? "…"}/${s.s3_prefix ?? ""}`;
}

/** The run as the six stages a person would describe: check, upload, create, load, check the data, refresh the catalog. */
function isModelled(spec: PipelineSpec | null): boolean {
  return spec?.kind === "model_layer";
}

/** A failing check that only warns (a foreign key without its parent) is reported, not failed. */
function failing(checks: RunCheck[]): RunCheck[] {
  return checks.filter((c) => !c.passed && c.severity !== "warn");
}

function warning(checks: RunCheck[]): RunCheck[] {
  return checks.filter((c) => !c.passed && c.severity === "warn");
}

function sourcesOf(spec: PipelineSpec | null): string[] {
  return [...new Set((spec?.models ?? []).flatMap((m) => m.sources))].sort();
}

function stagesOf(run: PipelineRun, spec: PipelineSpec | null): Stage[] {
  const step = (key: string) => run.steps.find((s) => s.key === key);
  const modelled = isModelled(spec);
  const tables = modelled ? (run.models?.length ?? 0) || spec?.models?.length || 1 : spec?.tables?.length || 1;
  const load = step("load");
  const failedChecks = failing(run.checks).length;
  const warned = warning(run.checks).length;
  const recon = run.reconciliation ?? [];
  const gaps = recon.filter((r) => r.status === "gap").length;
  const preflight = step("preflight")?.status;
  const checkStatus: State = run.checks.length || recon.length
    ? failedChecks || gaps
      ? "failed"
      : "ok"
    : load?.status === "running"
      ? "running"
      : load?.status === "failed"
        ? "failed"
        : load?.status === "skipped"
          ? "skipped"
          : "pending";
  const created = (step("apply")?.log ?? "").split("\n").filter((l) => l.startsWith("ok  CREATE")).length;
  return [
    {
      key: "preflight",
      label: "Preflight",
      icon: ShieldCheck,
      color: COLORS.preflight,
      status: step("preflight")?.status ?? "pending",
      seconds: seconds(step("preflight")),
      headline: step("preflight")?.status === "failed" ? "blocked" : step("preflight")?.status === "ok" ? "ready" : "–",
      sub: run.role ? `signed in as ${run.role}` : "settings and Snowflake sign-in",
      step: step("preflight"),
    },
    modelled
      ? {
          key: "upload",
          label: "Source",
          icon: Layers,
          color: COLORS.upload,
          // Nothing is uploaded: the layer below is already in Snowflake, read in place once preflight has passed.
          status: preflight === "ok" ? "ok" : preflight === "failed" ? "skipped" : "pending",
          seconds: null,
          headline: `${sourcesOf(spec).length} tables`,
          sub: `${spec?.source.database ?? ""}.${spec?.source.schema ?? ""} in Snowflake`,
          step: step("upload"),
        }
      : {
          key: "upload",
          label: "Upload",
          icon: CloudUpload,
          color: COLORS.upload,
          status: step("upload")?.status ?? "pending",
          seconds: seconds(step("upload")),
          headline: `${run.files_uploaded} files`,
          sub: spec?.source.storage_provider === "azure" ? "to Azure Blob Storage" : "to S3",
          step: step("upload"),
        },
    {
      key: "apply",
      label: "Create",
      icon: Table2,
      color: COLORS.apply,
      status: step("apply")?.status ?? "pending",
      seconds: seconds(step("apply")),
      headline: `${created || "–"} objects`,
      sub: modelled ? "schema, tables as the DDL writes them, rejects" : "stage, file format, tables",
      step: step("apply"),
    },
    {
      key: "load",
      label: "Load",
      icon: DatabaseZap,
      color: COLORS.load,
      status: load?.status === "failed" && (run.checks.length || recon.length) ? "ok" : (load?.status ?? "pending"),
      seconds: seconds(load),
      headline: `${tables} tables`,
      sub: modelled ? "stage, reject, merge each table" : "COPY INTO each table",
      step: load,
    },
    {
      key: "checks",
      label: "Checks",
      icon: ListChecks,
      color: COLORS.checks,
      status: checkStatus,
      seconds: null,
      headline: run.checks.length ? `${run.checks.length - failedChecks - warned}/${run.checks.length}` : "–",
      sub: failedChecks
        ? `${failedChecks} failing`
        : gaps
          ? `${gaps} reconciliation gap(s)`
          : warned
            ? `${warned} warning(s)`
            : recon.length
              ? "passed; source and target reconcile"
              : "passed after the load",
      step: load,
    },
    {
      key: "catalog",
      label: "Catalog",
      icon: Library,
      color: COLORS.catalog,
      status: step("catalog")?.status ?? "pending",
      seconds: seconds(step("catalog")),
      headline: run.catalog_run_id ? "synced" : "–",
      sub: "Snowflake sync of the schema",
      step: step("catalog"),
    },
  ];
}

function StageNode({ stage, index, selected, onSelect, last }: { stage: Stage; index: number; selected: boolean; onSelect: () => void; last: boolean }) {
  const state = STATE[stage.status];
  const StateIcon = state.icon;
  const Icon = stage.icon;
  const lit = stage.status === "ok" || stage.status === "running" || stage.status === "failed";
  const tone = stage.status === "failed" ? "0 72% 55%" : stage.color;
  return (
    <li className="relative min-w-0">
      <button
        type="button"
        onClick={onSelect}
        aria-pressed={selected}
        title={stage.sub}
        className={cn(
          "group relative flex w-full min-w-0 flex-col items-center rounded-2xl border bg-card/80 px-1.5 pb-2 pt-3 text-center transition-all hover:-translate-y-0.5 hover:shadow-md",
          selected ? "shadow-md" : "border-border/60",
          !lit && "opacity-60",
        )}
        style={selected ? { borderColor: `hsl(${tone} / 0.7)`, boxShadow: `0 0 0 3px hsl(${tone} / 0.14)` } : undefined}
      >
        <span
          className="relative flex h-10 w-10 items-center justify-center rounded-xl"
          style={{
            background: lit ? `linear-gradient(140deg, hsl(${tone} / 0.7), hsl(${tone}))` : "hsl(var(--muted))",
            color: lit ? "white" : "hsl(var(--muted-foreground))",
            boxShadow: lit ? `0 10px 22px -12px hsl(${tone})` : undefined,
          }}
        >
          <Icon className="h-5 w-5" />
          {stage.status === "running" ? (
            <span className="absolute inset-0 animate-ping rounded-xl" style={{ background: `hsl(${tone} / 0.35)` }} aria-hidden="true" />
          ) : null}
          <span className="absolute -bottom-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-card">
            <StateIcon className={cn("h-3.5 w-3.5", state.tone, stage.status === "running" && "animate-spin")} aria-label={state.label} />
          </span>
        </span>
        <span className="mt-2 text-[10px] uppercase tracking-wide text-muted-foreground">
          <span className="tabular-nums">{index + 1}</span> {stage.label}
        </span>
        <span className="w-full truncate font-display text-sm font-medium leading-tight tabular-nums">{stage.headline}</span>
        <span className={cn("mt-0.5 text-[10px] tabular-nums", state.tone)}>{stage.seconds !== null ? took(stage.seconds) : state.label}</span>
      </button>
      {!last ? (
        <span className="pointer-events-none absolute -right-[0.55rem] top-8 z-10 hidden md:block" aria-hidden="true">
          <ChevronRight
            className={cn(
              "h-3.5 w-3.5",
              stage.status === "ok" ? "text-success" : stage.status === "running" ? "animate-pulse text-primary" : "text-muted-foreground/50",
            )}
          />
        </span>
      ) : null}
    </li>
  );
}

function Panel({ title, icon: Icon, children, aside }: { title: string; icon: LucideIcon; children: React.ReactNode; aside?: React.ReactNode }) {
  return (
    <div className="rounded-2xl border bg-card/70 p-4">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-sm font-medium">
          <Icon className="h-4 w-4 text-primary" /> {title}
        </div>
        {aside}
      </div>
      {children}
    </div>
  );
}

function Output({ step }: { step: RunStep | undefined }) {
  const [open, setOpen] = useState(false);
  if (!step?.log) return null;
  return (
    <div className="mt-3 border-t pt-2">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="inline-flex items-center gap-1 text-[11px] text-muted-foreground hover:text-foreground"
      >
        <ChevronDown className={cn("h-3.5 w-3.5 transition-transform", open && "rotate-180")} /> {open ? "Hide output" : "Show output"}
      </button>
      {open ? <pre className="mt-1.5 max-h-64 overflow-auto rounded-lg bg-muted/60 p-2 font-mono text-[10.5px] leading-relaxed">{step.log}</pre> : null}
    </div>
  );
}

/** Check names read TABLE.kind; the kinds become the columns of the checks table. */
function checkKind(name: string, table: string): string {
  let kind = name.startsWith(`${table}.`) ? name.slice(table.length + 1) : name;
  const own = `${table.toLowerCase()}_`;
  if (kind.startsWith(own)) kind = kind.slice(own.length);
  if (/_in_/.test(kind)) return "references";
  if (kind === "key_unique") return "key unique";
  if (kind === "key_not_null") return "key not null";
  if (kind === "files_landed") return "file landed";
  if (kind === "rows_loaded") return "rows loaded";
  if (kind === "required_columns_not_null") return "not null";
  if (kind.endsWith("_unique")) return "id unique";
  if (kind === "freshness") return "fresh";
  return kind.replace(/_/g, " ");
}

function ChecksTable({ checks, tables }: { checks: RunCheck[]; tables: string[] }) {
  const { kinds, grid } = useMemo(() => {
    const names = tables.length ? tables : [...new Set(checks.map((c) => c.name.split(".")[0] ?? c.name))];
    const kinds: string[] = [];
    const grid = new Map<string, Map<string, RunCheck[]>>();
    for (const table of names) grid.set(table, new Map());
    for (const check of checks) {
      const table = names.find((t) => check.name.startsWith(`${t}.`)) ?? check.name.split(".")[0] ?? "other";
      const kind = checkKind(check.name, table);
      if (!kinds.includes(kind)) kinds.push(kind);
      if (!grid.has(table)) grid.set(table, new Map());
      const cell = grid.get(table);
      cell?.set(kind, [...(cell.get(kind) ?? []), check]);
    }
    return { kinds, grid };
  }, [checks, tables]);
  const open = (byKind: Map<string, RunCheck[]>) => [...byKind.values()].flat().filter((c) => !c.passed).length;
  const rows = [...grid.entries()].sort(([, a], [, b]) => open(b) - open(a));
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-xs">
        <thead>
          <tr className="text-[10px] uppercase tracking-wide text-muted-foreground">
            <th className="py-1.5 pr-3 text-left font-medium">Table</th>
            {kinds.map((k) => (
              <th key={k} className="px-2 py-1.5 text-center font-medium">
                {k}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-border/60">
          {rows.map(([table, byKind]) => (
            <tr key={table}>
              <td className="py-1.5 pr-3 font-mono text-[11px]">{table}</td>
              {kinds.map((k) => {
                const cell = byKind.get(k) ?? [];
                const bad = failing(cell);
                const warn = warning(cell);
                const shown = bad.length ? bad : warn;
                const rowsOff = shown.reduce((n, c) => n + c.failures, 0);
                const title = shown.map((c) => `${c.name}: ${formatInt(c.failures)} row(s)`).join("\n");
                return (
                  <td key={k} className="px-2 py-1.5 text-center">
                    {!cell.length ? (
                      <span className="text-muted-foreground/50">–</span>
                    ) : !shown.length ? (
                      <CheckCircle2 className="mx-auto h-4 w-4 text-success" aria-label={`${cell.map((c) => c.name).join(", ")} passed`} />
                    ) : (
                      <span className={cn("inline-flex items-center gap-0.5", bad.length ? "text-destructive" : "text-warning")} title={title}>
                        {bad.length ? <CircleAlert className="h-4 w-4" /> : <TriangleAlert className="h-4 w-4" />}
                        <span className="tabular-nums">{formatInt(rowsOff)}</span>
                      </span>
                    )}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

const RECON: Record<RunReconciliation["status"], { label: string; tone: string; icon: LucideIcon; order: number }> = {
  gap: { label: "gap", tone: "text-destructive", icon: CircleAlert, order: 0 },
  warn: { label: "total differs", tone: "text-warning", icon: TriangleAlert, order: 1 },
  explained: { label: "rejected rows explain it", tone: "text-success", icon: CheckCircle2, order: 2 },
  match: { label: "match", tone: "text-success", icon: CheckCircle2, order: 3 },
};

function measureLabel(measure: string): string {
  if (measure === "keys") return "distinct keys";
  if (measure.startsWith("sum:")) return `total ${measure.slice(4)}`;
  return measure;
}

function amount(n: number): string {
  return Number.isInteger(n) ? formatInt(n) : n.toLocaleString(undefined, { maximumFractionDigits: 6 });
}

/** Each table's source against its target: rows and distinct keys must match once rejected rows are counted; a total only warns. */
function Reconciliation({ rows }: { rows: RunReconciliation[] }) {
  const sorted = [...rows].sort((a, b) => RECON[a.status].order - RECON[b.status].order || a.table.localeCompare(b.table));
  const tables = new Set(rows.map((r) => r.table));
  const off = new Set(rows.filter((r) => r.status === "gap" || r.status === "warn").map((r) => r.table));
  return (
    <div className="mt-4 border-t pt-3">
      <div className="mb-2 flex flex-wrap items-center gap-2">
        <span className="text-xs font-medium">Source against target</span>
        <Badge variant={rows.some((r) => r.status === "gap") ? "destructive" : off.size ? "warning" : "success"}>
          {tables.size - off.size} of {tables.size} tables reconcile
        </Badge>
        <span className="text-[11px] text-muted-foreground">
          Rows and keys must match once rejected rows are counted; a gap fails the load. A total that differs only warns.
        </span>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead>
            <tr className="text-[10px] uppercase tracking-wide text-muted-foreground">
              <th className="py-1.5 pr-3 text-left font-medium">Table</th>
              <th className="px-2 py-1.5 text-left font-medium">Measure</th>
              <th className="px-2 py-1.5 text-right font-medium">Source</th>
              <th className="px-2 py-1.5 text-right font-medium">Target</th>
              <th className="px-2 py-1.5 text-right font-medium">Rejected</th>
              <th className="px-2 py-1.5 text-right font-medium">Gap</th>
              <th className="px-2 py-1.5 text-left font-medium">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/60">
            {sorted.map((r) => {
              const s = RECON[r.status];
              const Icon = s.icon;
              return (
                <tr key={`${r.table}:${r.measure}`}>
                  <td className="py-1.5 pr-3 font-mono text-[11px]">{r.table}</td>
                  <td className="px-2 py-1.5">{measureLabel(r.measure)}</td>
                  <td className="px-2 py-1.5 text-right tabular-nums">{amount(r.source)}</td>
                  <td className="px-2 py-1.5 text-right tabular-nums">{amount(r.target)}</td>
                  <td className="px-2 py-1.5 text-right tabular-nums text-muted-foreground">{r.explained ? amount(r.explained) : "–"}</td>
                  <td className={cn("px-2 py-1.5 text-right tabular-nums", r.gap ? s.tone : "text-muted-foreground")}>{r.gap ? amount(r.gap) : "0"}</td>
                  <td className="px-2 py-1.5">
                    <span className={cn("inline-flex items-center gap-1", s.tone)}>
                      <Icon className="h-3.5 w-3.5" aria-hidden="true" /> {s.label}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/** Per table: rows staged from the layer below, split into what merged (inserted, updated, unchanged) and what was rejected. */
function MergeRows({ models, spec }: { models: RunModel[]; spec: PipelineSpec | null }) {
  const byName = new Map(models.map((m) => [m.name, m]));
  const planned = spec?.models ?? [];
  const max = Math.max(1, ...models.map((m) => m.staged));
  return (
    <ul className="mt-2 divide-y divide-border/50">
      {planned.map((p) => {
        const m = byName.get(p.name);
        if (!m) {
          return (
            <li key={p.name} className="flex min-w-0 items-center gap-2 py-1.5 text-[11px] text-muted-foreground">
              <CircleDashed className="h-3.5 w-3.5 shrink-0" />
              <span className="w-44 shrink-0 truncate font-mono">{p.name}</span>
              <span className="truncate">{p.sql ? "not reported" : `created empty; waits for ${(p.waiting_on ?? []).join(", ") || "its sources"}`}</span>
            </li>
          );
        }
        const unchanged = Math.max(0, m.staged - m.rejected - m.inserted - m.updated);
        const part = (n: number) => `${(n / max) * 100}%`;
        return (
          <li
            key={p.name}
            className="flex min-w-0 items-center gap-2 py-1.5 text-[11px]"
            title={`${p.name}: ${formatInt(m.staged)} staged, ${formatInt(m.inserted)} inserted, ${formatInt(m.updated)} updated, ${formatInt(unchanged)} unchanged, ${formatInt(m.rejected)} rejected; ${formatInt(m.rows)} rows now`}
          >
            <Table2 className="h-3.5 w-3.5 shrink-0 text-primary" />
            <span className="w-44 shrink-0 truncate font-mono font-medium">{p.name}</span>
            <span className="flex h-2 min-w-8 flex-1 gap-0.5 overflow-hidden rounded-full bg-muted/60">
              {m.inserted ? <span className="h-full rounded-full bg-emerald-500" style={{ width: part(m.inserted) }} /> : null}
              {m.updated ? <span className="h-full rounded-full bg-sky-500" style={{ width: part(m.updated) }} /> : null}
              {unchanged ? <span className="h-full rounded-full bg-slate-400/70" style={{ width: part(unchanged) }} /> : null}
              {m.rejected ? <span className="h-full rounded-full bg-amber-500" style={{ width: part(m.rejected) }} /> : null}
            </span>
            <span className="w-56 shrink-0 text-right tabular-nums text-muted-foreground">
              <span className="text-emerald-700 dark:text-emerald-300">+{formatInt(m.inserted)}</span>
              {m.updated ? <span className="text-sky-700 dark:text-sky-300"> ~{formatInt(m.updated)}</span> : null}
              {m.rejected ? <span className="text-amber-700 dark:text-amber-300"> ✕{formatInt(m.rejected)}</span> : null}
              <span> · {formatInt(m.rows)} rows</span>
            </span>
          </li>
        );
      })}
      <li className="flex flex-wrap gap-x-3 pt-2 text-[10.5px] text-muted-foreground">
        <span className="inline-flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-emerald-500" /> inserted</span>
        <span className="inline-flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-sky-500" /> updated (hash changed)</span>
        <span className="inline-flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-slate-400/70" /> unchanged</span>
        <span className="inline-flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-amber-500" /> rejected with a reason</span>
      </li>
    </ul>
  );
}

function StageDetail({ stage, run, spec }: { stage: Stage; run: PipelineRun; spec: PipelineSpec | null }) {
  const step = stage.step;
  const detail =
    stage.key === "checks" ? null : step?.detail ? (
      <p className={cn("text-xs", step.status === "failed" ? "text-destructive" : "text-muted-foreground")}>{step.detail}</p>
    ) : null;
  if (stage.key === "upload" && isModelled(spec)) {
    const sources = sourcesOf(spec);
    return (
      <Panel
        title="Read in place from the layer below"
        icon={Layers}
        aside={<span className="text-[11px] text-muted-foreground">nothing to upload</span>}
      >
        <p className="text-xs text-muted-foreground">
          The tables were bound by name and by the columns each mapping branch reads, then dry-run read-only before approval.
        </p>
        <div className="mt-2 grid grid-cols-2 gap-1.5 sm:grid-cols-3 lg:grid-cols-5">
          {sources.map((f) => (
            <span key={f} className="inline-flex min-w-0 items-center gap-1.5 rounded-lg border border-border/70 bg-background/60 px-2 py-1 text-[11px]" title={f}>
              <BrandMark icon="snowflake" size="xs" /> <span className="truncate font-mono">{f.split(".").pop()}</span>
            </span>
          ))}
        </div>
      </Panel>
    );
  }
  if (stage.key === "upload") {
    const files = (step?.log ?? "")
      .split("\n")
      .filter((l) => l.startsWith("uploaded "))
      .map((l) => l.slice("uploaded ".length).split(" -> ")[0] ?? l);
    return (
      <Panel title="Files landed" icon={FolderInput} aside={<code className="truncate font-mono text-[10.5px] text-muted-foreground">{landingUrl(spec)}</code>}>
        {detail}
        <div className="mt-2 grid grid-cols-2 gap-1.5 sm:grid-cols-3 lg:grid-cols-5">
          {files.map((f) => (
            <span key={f} className="inline-flex min-w-0 items-center gap-1.5 rounded-lg border border-border/70 bg-background/60 px-2 py-1 text-[11px]">
              <FileSpreadsheet className="h-3.5 w-3.5 shrink-0 text-success" /> <span className="truncate font-mono">{f}</span>
            </span>
          ))}
        </div>
        <Output step={step} />
      </Panel>
    );
  }
  if (stage.key === "apply") {
    const made = (step?.log ?? "")
      .split("\n")
      .filter((l) => l.startsWith("ok  CREATE"))
      .map((l) => {
        const m = /CREATE\s+(?:OR\s+REPLACE\s+)?(FILE FORMAT|STAGE|ICEBERG TABLE|TABLE|SCHEMA|DATABASE)\s+(?:IF NOT EXISTS\s+)?([\w.$"]+)/i.exec(l);
        return { kind: (m?.[1] ?? "object").toLowerCase(), name: (m?.[2] ?? l).split(".").pop() ?? l };
      });
    const icon = (kind: string) => (kind === "stage" ? FolderInput : kind === "file format" ? FileType2 : Table2);
    return (
      <Panel
        title="Objects in Snowflake"
        icon={Table2}
        aside={<span className="text-[11px] text-muted-foreground">{spec ? `${spec.target.database}.${spec.target.schema}` : ""}</span>}
      >
        {detail}
        <div className="mt-2 flex flex-wrap gap-1.5">
          {made.map((o) => {
            const Icon = icon(o.kind);
            return (
              <span
                key={`${o.kind}-${o.name}`}
                className="inline-flex items-center gap-1.5 rounded-lg border border-border/70 bg-background/60 px-2 py-1 text-[11px]"
                title={o.kind}
              >
                <Icon className="h-3.5 w-3.5 text-primary" /> <span className="font-mono">{o.name}</span>
              </span>
            );
          })}
        </div>
        <Output step={step} />
      </Panel>
    );
  }
  if (stage.key === "load" && isModelled(spec)) {
    return (
      <Panel
        title="What each table took"
        icon={DatabaseZap}
        aside={<span className="text-[11px] text-muted-foreground">rejected rows are kept in LOAD_REJECTS with the reason</span>}
      >
        {detail}
        <MergeRows models={run.models ?? []} spec={spec} />
        <Output step={step} />
      </Panel>
    );
  }
  if (stage.key === "load") {
    const tables = spec?.tables ?? [];
    const max = Math.max(1, ...tables.map((t) => t.rows));
    return (
      <Panel
        title="Where each file went"
        icon={DatabaseZap}
        aside={<span className="text-[11px] text-muted-foreground">ON_ERROR = ABORT_STATEMENT: every row of a file, or none</span>}
      >
        {detail}
        <ul className="mt-2 divide-y divide-border/50">
          {tables.map((t) => (
            <li
              key={t.name}
              className="flex min-w-0 items-center gap-2 py-1.5 text-[11px]"
              title={`${t.source_file} → ${spec?.target.database}.${spec?.target.schema}.${t.name}: ${formatInt(t.rows)} rows`}
            >
              <FileSpreadsheet className="h-3.5 w-3.5 shrink-0 text-success" />
              <span className="w-28 shrink-0 truncate font-mono text-muted-foreground">{t.source_file}</span>
              <ArrowRight className="h-3 w-3 shrink-0 text-muted-foreground/70" aria-hidden="true" />
              <Table2 className="h-3.5 w-3.5 shrink-0 text-primary" />
              <span className="w-48 shrink-0 truncate font-mono font-medium">{t.name}</span>
              <span className="h-1.5 min-w-8 flex-1 overflow-hidden rounded-full bg-muted">
                <span
                  className="block h-full rounded-full bg-gradient-to-r from-teal-500 to-sky-500"
                  style={{ width: `${Math.max(3, (t.rows / max) * 100)}%` }}
                />
              </span>
              <span className="w-20 shrink-0 text-right tabular-nums text-muted-foreground">{formatInt(t.rows)} rows</span>
            </li>
          ))}
        </ul>
        <Output step={step} />
      </Panel>
    );
  }
  if (stage.key === "checks") {
    const failed = failing(run.checks).length;
    const warned = warning(run.checks).length;
    const names = spec?.tables?.length ? spec.tables.map((t) => t.name) : (spec?.models ?? []).map((m) => m.name);
    return (
      <Panel
        title="Checks after the load"
        icon={ListChecks}
        aside={
          <span className="flex flex-wrap gap-1.5">
            <Badge variant={failed ? "destructive" : "success"}>
              {run.checks.length - failed - warned} of {run.checks.length} passed
            </Badge>
            {warned ? <Badge variant="warning">{warned} warning(s)</Badge> : null}
          </span>
        }
      >
        {warned ? (
          <p className="mb-2 text-[11px] text-muted-foreground">
            Warnings are foreign keys whose value has no parent row: Snowflake does not enforce them, so they are reported, not failed.
          </p>
        ) : null}
        {run.checks.length ? (
          <ChecksTable checks={run.checks} tables={names} />
        ) : (
          <p className="text-xs text-muted-foreground">The checks run once the load has finished.</p>
        )}
        {run.reconciliation?.length ? (
          <Reconciliation rows={run.reconciliation} />
        ) : run.checks.length && run.status !== "running" ? (
          <p className="mt-3 border-t pt-2 text-[11px] text-muted-foreground">
            No reconciliation for this run: its pipeline was generated before source-to-target reconciliation was added. A pipeline generated now
            reports it after every load.
          </p>
        ) : null}
      </Panel>
    );
  }
  if (stage.key === "catalog") {
    return (
      <Panel title="Catalog refresh" icon={Library}>
        {detail}
        {run.catalog_run_id ? (
          <p className="mt-1 text-xs text-muted-foreground">
            The new tables reach the Semantic Hub and the Knowledge Hub through a Snowflake sync:{" "}
            <Link to="/pipelines?tab=history" className="font-medium text-primary hover:underline">
              see it in Run history
            </Link>
            .
          </p>
        ) : null}
      </Panel>
    );
  }
  return (
    <Panel title="Preflight" icon={ShieldCheck}>
      {detail ?? (
        <p className="text-xs text-muted-foreground">
          Checks the runtime settings and opens a Snowflake session as the pipeline&apos;s role before anything is uploaded.
        </p>
      )}
    </Panel>
  );
}

/** The hub's run of the approved pipeline as a workflow: each stage with what it did, and one stage opened in detail. */
export function RunView({ intent, runEnabled, autorun }: { intent: IntentRecord; runEnabled: boolean; autorun: boolean }) {
  const run = intent.run;
  const missing = intent.run_missing ?? [];
  const stages = useMemo(() => (run ? stagesOf(run, intent.spec) : []), [run, intent.spec]);
  const focusDefault = stages.find((s) => s.status === "failed") ?? stages.find((s) => s.status === "running") ?? stages.find((s) => s.key === "checks");
  const [picked, setPicked] = useState<StageKey | null>(null);
  const focus = stages.find((s) => s.key === picked) ?? focusDefault;

  if (!run) {
    return (
      <div className="rounded-2xl border border-dashed p-5 text-sm">
        <div className="flex items-center gap-2 font-medium">
          <PlayCircle className="h-4 w-4 text-primary" />{" "}
          {runEnabled ? (autorun ? "Approving runs this pipeline" : "Run it once it is generated") : "Runs are off in this hub"}
        </div>
        <p className="mt-1 text-xs text-muted-foreground">
          {runEnabled
            ? isModelled(intent.spec)
              ? "The hub creates the tables as the design DDL writes them, merges each from the layer below (rejecting what breaks the DDL, with the reason), checks them, then refreshes the catalog. Nothing is written before a person approves the plan."
              : "The hub uploads the files, creates the stage and tables, loads and checks them, then refreshes the catalog. Nothing is written before a person approves the plan."
            : "Set ECH_INTENT_RUN_ENABLED=true and the ECH_RUN_* settings to let the hub run approved pipelines; until then run pipeline.py yourself."}
        </p>
        {runEnabled && missing.length ? (
          <div className="mt-3 flex items-start gap-2 rounded-xl border border-warning/40 bg-warning/5 p-2.5 text-xs">
            <ShieldAlert className="mt-0.5 h-3.5 w-3.5 shrink-0 text-warning" />
            <span>
              The run still needs{" "}
              {missing.map((m, i) => (
                <span key={m}>
                  {i ? ", " : ""}
                  <code className="font-mono">{m.replace(/^ECH_RUN_/, "")}</code>
                </span>
              ))}{" "}
              in <code className="font-mono">.env</code> (read as <code className="font-mono">ECH_RUN_*</code>); restart the query service after setting it.
            </span>
          </div>
        ) : null}
      </div>
    );
  }

  const total = run.finished_at ? (Date.parse(run.finished_at) - Date.parse(run.started_at)) / 1000 : null;
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2 text-xs">
        <Badge variant={run.status === "succeeded" ? "success" : run.status === "failed" ? "destructive" : "info"}>
          {run.status === "running" ? "running" : run.status === "succeeded" ? "loaded" : "stopped"}
        </Badge>
        {isModelled(intent.spec) ? null : <BrandMark icon={intent.spec?.source.storage_provider === "azure" ? "azure" : "s3"} size="xs" />}
        <BrandMark icon="snowflake" size="xs" />
        <span className="text-muted-foreground">
          {run.triggered_by === "approval" ? "started by the approval" : "started from this page"} · {formatDateTime(run.started_at)}
          {total !== null ? ` · ${took(total)} in all` : ""}
          {run.role ? ` · as ${run.role}` : ""}
        </span>
      </div>
      {run.warnings.map((w) => (
        <div key={w} className="flex items-start gap-2 rounded-xl border border-warning/40 bg-warning/5 p-2.5 text-xs">
          <ShieldAlert className="mt-0.5 h-3.5 w-3.5 shrink-0 text-warning" /> {w}
        </div>
      ))}
      {run.error ? (
        <div className="flex items-start gap-2 rounded-xl border border-destructive/40 bg-destructive/5 p-2.5 text-xs text-destructive">
          <CircleAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {run.error}
        </div>
      ) : null}
      <ol className="grid grid-cols-3 gap-2.5 md:grid-cols-6" aria-label="Pipeline stages">
        {stages.map((stage, i) => (
          <StageNode
            key={stage.key}
            stage={stage}
            index={i}
            selected={focus?.key === stage.key}
            onSelect={() => setPicked(stage.key)}
            last={i === stages.length - 1}
          />
        ))}
      </ol>
      {focus ? <StageDetail stage={focus} run={run} spec={intent.spec} /> : null}
    </div>
  );
}
