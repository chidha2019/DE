import {
  ArrowDownToLine,
  BookCheck,
  CalendarClock,
  ChevronRight,
  CircleAlert,
  CircleCheck,
  CloudUpload,
  FolderInput,
  Merge,
  Network,
  PackagePlus,
  Shapes,
  ShieldCheck,
  Table2,
  Warehouse,
  Waypoints,
  type LucideIcon,
} from "lucide-react";
import { useState } from "react";

import type { WorkflowKind, WorkflowStep } from "@/api/types";

const KIND: Record<WorkflowKind, { icon: LucideIcon; color: string; short: string }> = {
  prepare: { icon: PackagePlus, color: "205 85% 50%", short: "Prepare" },
  model: { icon: Shapes, color: "282 70% 58%", short: "Model" },
  source: { icon: FolderInput, color: "199 89% 48%", short: "Read" },
  land: { icon: CloudUpload, color: "217 91% 60%", short: "Land" },
  stage: { icon: Warehouse, color: "262 70% 60%", short: "Stage" },
  table: { icon: Table2, color: "190 85% 42%", short: "Table" },
  load: { icon: ArrowDownToLine, color: "172 66% 42%", short: "Load" },
  validate: { icon: ShieldCheck, color: "152 65% 40%", short: "Validate" },
  schedule: { icon: CalendarClock, color: "38 92% 50%", short: "Schedule" },
  govern: { icon: BookCheck, color: "292 70% 55%", short: "Govern" },
  relate: { icon: Waypoints, color: "225 65% 50%", short: "Relate" },
  downstream: { icon: Network, color: "345 75% 55%", short: "Downstream" },
};

function iconOf(step: WorkflowStep): LucideIcon {
  return step.kind === "load" && step.title.startsWith("Merge") ? Merge : KIND[step.kind].icon;
}

function StepCard({ step, index, last }: { step: WorkflowStep; index: number; last: boolean }) {
  const meta = KIND[step.kind];
  const Icon = iconOf(step);
  const [open, setOpen] = useState(false);
  const attention = step.status === "attention";
  const items = open ? step.items : step.items.slice(0, 4);
  return (
    <li className="relative pl-14">
      {!last ? (
        <span
          className="absolute bottom-[-0.75rem] left-[1.35rem] top-12 w-0.5 rounded-full"
          style={{ background: `linear-gradient(hsl(${meta.color} / 0.6), hsl(var(--border)))` }}
          aria-hidden="true"
        />
      ) : null}
      <span
        className="absolute left-0 top-0 flex h-11 w-11 items-center justify-center rounded-2xl text-white"
        style={{ background: `linear-gradient(140deg, hsl(${meta.color} / 0.7), hsl(${meta.color}))`, boxShadow: `0 12px 24px -14px hsl(${meta.color})` }}
      >
        <Icon className="h-5 w-5" />
        <span className="absolute -right-1.5 -top-1.5 flex h-5 w-5 items-center justify-center rounded-full border bg-card text-[10px] font-medium tabular-nums text-foreground">
          {index + 1}
        </span>
      </span>
      <div
        className="relative overflow-hidden rounded-2xl border bg-card/80 p-3.5"
        style={{ borderColor: attention ? "hsl(38 92% 50% / 0.45)" : `hsl(${meta.color} / 0.25)` }}
      >
        <span
          className="pointer-events-none absolute -right-10 -top-12 h-28 w-28 rounded-full opacity-15 blur-2xl"
          style={{ background: `hsl(${meta.color})` }}
          aria-hidden="true"
        />
        <div className="relative flex flex-wrap items-center gap-2">
          <span className="text-sm font-medium">{step.title}</span>
          {attention ? (
            <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/12 px-2 py-0.5 text-[10px] font-medium text-amber-700 dark:text-amber-300">
              <CircleAlert className="h-3 w-3" /> needs attention
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] font-medium text-emerald-700 dark:text-emerald-300">
              <CircleCheck className="h-3 w-3" /> ready
            </span>
          )}
        </div>
        <p className="relative mt-0.5 break-words text-xs text-muted-foreground">{step.summary}</p>
        {step.metrics.length ? (
          <div className="relative mt-2 flex flex-wrap gap-1.5">
            {step.metrics.map((m) => (
              <span
                key={m.label}
                className="inline-flex items-baseline gap-1 rounded-lg border px-2 py-0.5 text-[11px]"
                style={{ borderColor: `hsl(${meta.color} / 0.25)`, background: `hsl(${meta.color} / 0.06)` }}
              >
                <span className="font-mono font-medium" style={{ color: `hsl(${meta.color})` }}>
                  {m.value}
                </span>
                <span className="text-muted-foreground">{m.label}</span>
              </span>
            ))}
          </div>
        ) : null}
        {items.length ? (
          <div className="relative mt-2 flex flex-wrap gap-1">
            {items.map((item) => (
              <span
                key={item}
                className="max-w-full truncate rounded-md border border-border/60 bg-background/60 px-1.5 py-px font-mono text-[10.5px] text-foreground/80"
                title={item}
              >
                {item}
              </span>
            ))}
            {step.items.length > 4 ? (
              <button type="button" onClick={() => setOpen((v) => !v)} className="rounded-md px-1.5 py-px text-[11px] text-primary hover:underline">
                {open ? "show less" : `show all ${step.items.length}`}
              </button>
            ) : null}
          </div>
        ) : null}
        {attention && step.note ? (
          <div className="relative mt-2 flex items-start gap-1.5 rounded-lg border border-amber-500/30 bg-amber-500/10 px-2.5 py-1.5 text-[11px] text-amber-800 dark:text-amber-200">
            <CircleAlert className="mt-px h-3.5 w-3.5 shrink-0" /> {step.note}
          </div>
        ) : null}
      </div>
    </li>
  );
}

/** The plan as the pipeline will run it: a strip to see the whole route at a glance, then each step in full. */
export function WorkflowView({ steps }: { steps: WorkflowStep[] }) {
  const attention = steps.filter((s) => s.status === "attention").length;
  if (!steps.length) return <p className="text-xs text-muted-foreground">The workflow appears once the planner has written the plan.</p>;
  return (
    <div className="space-y-4">
      <div className="overflow-x-auto rounded-2xl border border-border/60 bg-background/40 p-3">
        <ol className="flex min-w-max items-center gap-1.5">
          {steps.map((s, i) => {
            const meta = KIND[s.kind];
            const Icon = iconOf(s);
            return (
              <li key={s.key} className="flex items-center gap-1.5">
                <span className="flex flex-col items-center gap-1" title={`${s.title}: ${s.summary}`}>
                  <span
                    className="relative flex h-9 w-9 items-center justify-center rounded-xl text-white"
                    style={{ background: `linear-gradient(140deg, hsl(${meta.color} / 0.7), hsl(${meta.color}))` }}
                  >
                    <Icon className="h-4 w-4" />
                    {s.status === "attention" ? (
                      <span className="absolute -right-1 -top-1 h-2.5 w-2.5 rounded-full border-2 border-card bg-amber-500" aria-label="needs attention" />
                    ) : null}
                  </span>
                  <span className="text-[10px] font-medium text-muted-foreground">{meta.short}</span>
                </span>
                {i < steps.length - 1 ? <ChevronRight className="mb-4 h-4 w-4 text-muted-foreground/50" aria-hidden="true" /> : null}
              </li>
            );
          })}
        </ol>
      </div>
      <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
        <span className="font-medium text-foreground">{steps.length} steps</span>
        <span>·</span>
        {attention ? (
          <span className="inline-flex items-center gap-1 text-amber-700 dark:text-amber-300">
            <CircleAlert className="h-3.5 w-3.5" /> {attention} need{attention === 1 ? "s" : ""} attention before approval
          </span>
        ) : (
          <span className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-300">
            <CircleCheck className="h-3.5 w-3.5" /> every step is ready
          </span>
        )}
      </div>
      <ol className="space-y-3">
        {steps.map((s, i) => (
          <StepCard key={s.key} step={s} index={i} last={i === steps.length - 1} />
        ))}
      </ol>
    </div>
  );
}
