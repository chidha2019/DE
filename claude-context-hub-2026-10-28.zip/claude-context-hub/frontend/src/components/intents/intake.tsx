import {
  BrainCircuit,
  Check,
  ChevronRight,
  CircleAlert,
  CircleCheck,
  CornerDownLeft,
  DatabaseZap,
  LoaderCircle,
  MessageSquareReply,
  ScanSearch,
  ShieldCheck,
  Sparkles,
  TicketCheck,
  Workflow,
  type LucideIcon,
} from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import type { IntentRecord } from "@/api/types";
import { BrandMark } from "@/components/connectors/brand-mark";
import { Button } from "@/components/ui/button";
import { useImportJira } from "@/hooks/queries";
import { describeError } from "@/lib/api-client";
import { cn } from "@/lib/utils";

// What the hub does while the request is open; the lifecycle strip below the intake shows the whole flow.
const PHASES: { icon: LucideIcon; label: string }[] = [
  { icon: BrainCircuit, label: "Reading the ticket" },
  { icon: ScanSearch, label: "Reviewing what is missing" },
  { icon: Workflow, label: "Checking Snowflake and planning" },
];

const PROMISES: { icon: LucideIcon; text: string }[] = [
  { icon: MessageSquareReply, text: "Questions and the plan go back on the issue" },
  { icon: DatabaseZap, text: "Snowflake is checked read-only first" },
  { icon: ShieldCheck, text: "Nothing runs until you approve" },
];

const ISSUE_KEY = /\b([A-Z][A-Z0-9_]+-\d+)\b/g;

/** DATA-123 from a key or a browse link, as the hub reads it (the last one wins). */
function issueKey(text: string): string | null {
  const found = text.toUpperCase().match(ISSUE_KEY);
  return found?.[found.length - 1] ?? null;
}

/** Where a ticket comes in: a Jira issue key or link, read from the connected Jira site. */
export function Intake({ jiraConfigured, onCreated }: { jiraConfigured: boolean; onCreated: (record: IntentRecord) => void }) {
  const [issue, setIssue] = useState("");
  const importJira = useImportJira();
  const busy = importJira.isPending;
  const key = issueKey(issue);

  // While the hub works, walk the first steps so the wait shows what is happening.
  const [step, setStep] = useState(0);
  useEffect(() => {
    if (!busy) {
      setStep(0);
      return;
    }
    const timer = window.setInterval(() => setStep((s) => Math.min(s + 1, PHASES.length - 1)), 1800);
    return () => window.clearInterval(timer);
  }, [busy]);

  const submit = () =>
    importJira.mutate(issue.trim(), {
      onSuccess: (record) => {
        setIssue("");
        onCreated(record);
      },
    });
  const ready = jiraConfigured && Boolean(key);

  return (
    <section className="surface relative overflow-hidden">
      <div className="hero-grid pointer-events-none absolute inset-0 opacity-40" aria-hidden="true" />
      <div className="pointer-events-none absolute -left-20 -top-28 h-64 w-64 rounded-full bg-sky-500/15 blur-3xl" aria-hidden="true" />
      <div className="pointer-events-none absolute -right-16 -top-20 h-56 w-56 rounded-full bg-amber-400/15 blur-3xl" aria-hidden="true" />
      <div className="pointer-events-none absolute -bottom-28 left-1/3 h-64 w-64 rounded-full bg-primary/15 blur-3xl" aria-hidden="true" />

      <div className="relative space-y-5 p-5 sm:p-6">
        <div className="flex flex-wrap items-start gap-4">
          <BrandMark icon="jira" size="lg" />
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 text-[10px] font-medium uppercase tracking-[0.2em] text-primary">
              <TicketCheck className="h-3.5 w-3.5" /> New intent
            </div>
            <h2 className="mt-1 font-display text-2xl font-medium tracking-tight">Hand the hub a Jira ticket</h2>
            <p className="mt-0.5 text-sm text-muted-foreground">
              It reads the ticket, reviews what is missing and plans the pipeline as a workflow you approve.
            </p>
          </div>
          {jiraConfigured ? (
            <span className="inline-flex items-center gap-1.5 rounded-full border border-success/40 bg-success/10 px-2.5 py-1 text-[11px] font-medium text-success">
              <CircleCheck className="h-3.5 w-3.5" /> Jira connected
            </span>
          ) : (
            <Link
              to="/connectors?connect=jira"
              className="inline-flex items-center gap-1.5 rounded-full border border-warning/40 bg-warning/10 px-2.5 py-1 text-[11px] font-medium text-warning hover:underline"
            >
              <CircleAlert className="h-3.5 w-3.5" /> Connect Jira
            </Link>
          )}
        </div>

        <div>
          <div
            className={cn(
              "flex flex-col gap-2 rounded-2xl border bg-background/80 p-1.5 shadow-sm backdrop-blur transition-shadow sm:flex-row sm:items-center",
              "focus-within:border-primary/50 focus-within:shadow-[0_0_0_4px_hsl(var(--primary)/0.12)]",
              !jiraConfigured && "opacity-70",
            )}
          >
            <div className="flex min-w-0 flex-1 items-center gap-2 pl-3">
              <TicketCheck className="h-5 w-5 shrink-0 text-muted-foreground" aria-hidden="true" />
              <input
                value={issue}
                onChange={(e) => setIssue(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && ready && !busy && submit()}
                placeholder="KAN-3, or https://your-site.atlassian.net/browse/KAN-3"
                aria-label="Jira issue key or link"
                disabled={!jiraConfigured || busy}
                className="h-11 min-w-0 flex-1 bg-transparent font-mono text-sm outline-none placeholder:text-muted-foreground/70"
              />
              {key ? (
                <span className="inline-flex shrink-0 items-center gap-1 rounded-lg border border-primary/30 bg-primary/10 px-2 py-0.5 font-mono text-xs font-medium text-primary">
                  <BrandMark icon="jira" size="xs" /> {key}
                </span>
              ) : null}
              <kbd className="hidden shrink-0 items-center gap-1 rounded-md border bg-muted/60 px-1.5 py-0.5 text-[10px] text-muted-foreground sm:inline-flex">
                <CornerDownLeft className="h-3 w-3" /> Enter
              </kbd>
            </div>
            <Button
              className="h-11 rounded-xl bg-gradient-to-r from-primary to-sky-600 px-5 text-primary-foreground shadow-md hover:opacity-95"
              disabled={!ready || busy}
              onClick={submit}
            >
              {busy ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
              {busy ? "Reading the ticket…" : "Read, review and plan"}
            </Button>
          </div>
          {importJira.error ? (
            <p className="mt-2 flex items-center gap-1.5 text-xs text-destructive">
              <CircleAlert className="h-3.5 w-3.5" /> {describeError(importJira.error)}
            </p>
          ) : !jiraConfigured ? (
            <p className="mt-2 text-xs text-muted-foreground">
              <Link to="/connectors?connect=jira" className="font-medium text-primary underline-offset-2 hover:underline">
                Connect Jira
              </Link>{" "}
              with your site URL, email and API token to bring a ticket in.
            </p>
          ) : null}
          {busy ? (
            <ol className="mt-2.5 flex flex-wrap items-center gap-1.5 text-[11px]" aria-label="Progress" aria-live="polite">
              {PHASES.map((p, i) => {
                const Icon = i < step ? Check : i === step ? LoaderCircle : p.icon;
                return (
                  <li key={p.label} className="flex items-center gap-1.5">
                    <span
                      className={cn(
                        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 transition-colors",
                        i < step && "border-success/40 bg-success/10 text-success",
                        i === step && "border-primary/40 bg-primary/10 text-primary",
                        i > step && "border-border/60 text-muted-foreground",
                      )}
                    >
                      <Icon className={cn("h-3.5 w-3.5", i === step && "animate-spin")} /> {p.label}
                    </span>
                    {i < PHASES.length - 1 ? <ChevronRight className="h-3.5 w-3.5 text-muted-foreground/60" aria-hidden="true" /> : null}
                  </li>
                );
              })}
            </ol>
          ) : null}
          <div className="mt-3 flex flex-wrap gap-2">
            {PROMISES.map((p) => (
              <span
                key={p.text}
                className="inline-flex items-center gap-1.5 rounded-full border border-border/70 bg-card/70 px-2.5 py-1 text-[11px] text-muted-foreground"
              >
                <p.icon className="h-3.5 w-3.5 text-primary" /> {p.text}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
