import {
  ArrowDownToLine,
  CircleCheck,
  CircleDashed,
  DatabaseZap,
  FolderInput,
  Hourglass,
  PencilRuler,
  RefreshCw,
  Shapes,
  ShieldCheck,
  UserRound,
  type LucideIcon,
} from "lucide-react";

import type { IntentRecord, RouteKey, ValidatedObject } from "@/api/types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useRevalidateIntent } from "@/hooks/queries";
import { describeError } from "@/lib/api-client";
import { formatRelative } from "@/lib/format";
import { cn } from "@/lib/utils";

const ROUTE: Record<RouteKey, { icon: LucideIcon; color: string; label: string }> = {
  ingest_new: { icon: FolderInput, color: "199 89% 48%", label: "Load files into new tables" },
  ingest_existing: { icon: ArrowDownToLine, color: "172 66% 42%", label: "Load into existing tables" },
  model_new: { icon: Shapes, color: "282 70% 58%", label: "Model a new layer" },
  model_existing: { icon: PencilRuler, color: "262 70% 60%", label: "Change an existing layer" },
  wait_upstream: { icon: Hourglass, color: "38 92% 50%", label: "Wait for upstream tables" },
  manual: { icon: UserRound, color: "200 10% 45%", label: "Hand to a person" },
};

const OBJECT_LABEL: Record<ValidatedObject["kind"], string> = {
  database: "database",
  schema: "schema",
  table: "table",
  external_volume: "external volume",
  stage: "stage",
  integration: "storage integration",
};

function ObjectChip({ obj }: { obj: ValidatedObject }) {
  const short = obj.kind === "table" ? obj.name.split(".").pop() : obj.name;
  const detail = [
    OBJECT_LABEL[obj.kind],
    obj.exists ? "exists" : "missing",
    obj.rows != null ? `${obj.rows.toLocaleString()} rows` : "",
    obj.columns.length ? `${obj.columns.length} columns` : "",
    obj.detail,
    obj.properties?.STORAGE_PROVIDER ? `reads ${obj.properties.STORAGE_PROVIDER}` : "",
    obj.properties?.STORAGE_BASE_URL ?? "",
    obj.properties?.STORAGE_ALLOWED_LOCATIONS ? `allowed: ${obj.properties.STORAGE_ALLOWED_LOCATIONS}` : "",
  ]
    .filter(Boolean)
    .join(" · ");
  return (
    <span
      title={`${obj.name}: ${detail}`}
      className={cn(
        "inline-flex max-w-full items-center gap-1 rounded-lg border px-1.5 py-0.5 font-mono text-[11px]",
        obj.exists
          ? "border-emerald-500/35 bg-emerald-500/10 text-emerald-800 dark:text-emerald-200"
          : "border-dashed border-border bg-background/60 text-muted-foreground",
      )}
    >
      {obj.exists ? <CircleCheck className="h-3 w-3 shrink-0" /> : <CircleDashed className="h-3 w-3 shrink-0" />}
      <span className="truncate">{short}</span>
      {obj.properties?.STORAGE_PROVIDER ? <span className="font-sans text-[10px] uppercase opacity-70">{obj.properties.STORAGE_PROVIDER}</span> : null}
      {obj.rows != null ? <span className="font-sans text-[10px] opacity-70">{obj.rows.toLocaleString()}</span> : null}
    </span>
  );
}

function ObjectGroup({ title, objects }: { title: string; objects: ValidatedObject[] }) {
  if (!objects.length) return null;
  const present = objects.filter((o) => o.exists).length;
  return (
    <div>
      <div className="mb-1.5 flex items-baseline gap-2">
        <span className="text-[10px] font-medium uppercase tracking-[0.18em] text-muted-foreground">{title}</span>
        <span className="text-[11px] tabular-nums text-muted-foreground">
          {present} of {objects.length} exist
        </span>
      </div>
      <div className="flex flex-wrap gap-1">
        {objects.map((o) => (
          <ObjectChip key={`${o.kind}-${o.name}`} obj={o} />
        ))}
      </div>
    </div>
  );
}

/** The route the intent took and the read-only Snowflake look that chose it. */
export function RouteView({ intent }: { intent: IntentRecord }) {
  const revalidate = useRevalidateIntent();
  const route = intent.route;
  const validation = intent.validation;
  if (!route && !validation) return <p className="text-xs text-muted-foreground">Not validated yet: the hub looks in Snowflake once the ticket is read.</p>;
  const meta = route ? ROUTE[route.key] : null;
  const Icon = meta?.icon ?? DatabaseZap;
  const color = meta?.color ?? "205 85% 50%";
  const objects = validation?.objects ?? [];
  const containers = objects.filter(
    (o) => o.kind === "database" || o.kind === "schema" || o.kind === "external_volume" || o.kind === "integration" || o.kind === "stage",
  );
  const sources = objects.filter((o) => o.kind === "table" && o.role === "source");
  const targets = objects.filter((o) => o.kind === "table" && o.role === "target");
  return (
    <div className="space-y-4">
      {route ? (
        <div className="relative overflow-hidden rounded-2xl border bg-card/80 p-4" style={{ borderColor: `hsl(${color} / 0.45)` }}>
          <span
            className="pointer-events-none absolute -right-12 -top-14 h-36 w-36 rounded-full opacity-15 blur-2xl"
            style={{ background: `hsl(${color})` }}
            aria-hidden="true"
          />
          <div className="relative flex items-start gap-3">
            <span
              className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl text-white"
              style={{ background: `linear-gradient(140deg, hsl(${color} / 0.7), hsl(${color}))`, boxShadow: `0 12px 24px -14px hsl(${color})` }}
            >
              <Icon className="h-5 w-5" />
            </span>
            <div className="min-w-0 flex-1">
              <div className="text-[10px] font-medium uppercase tracking-[0.18em] text-muted-foreground">Route · {meta?.label}</div>
              <div className="font-display text-base font-medium">{route.title}</div>
              <p className="mt-0.5 text-xs text-muted-foreground">{route.reason}</p>
              {route.waits_on.length ? (
                <div className="mt-2 flex flex-wrap items-center gap-1.5 text-[11px]">
                  <span className="text-muted-foreground">waits on</span>
                  {route.waits_on.map((w) => (
                    <Badge key={w} variant="warning" className="font-mono">
                      {w}
                    </Badge>
                  ))}
                </div>
              ) : null}
            </div>
          </div>
        </div>
      ) : null}

      {validation ? (
        <div className="rounded-2xl border border-border/60 bg-card/60 p-4">
          <div className="flex flex-wrap items-start gap-3">
            <span
              className={cn(
                "flex h-9 w-9 shrink-0 items-center justify-center rounded-xl",
                validation.reachable ? "bg-sky-500/15 text-sky-700 dark:text-sky-300" : "bg-muted text-muted-foreground",
              )}
            >
              <DatabaseZap className="h-[18px] w-[18px]" />
            </span>
            <div className="min-w-0 flex-1 basis-60">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-sm font-medium">Snowflake</span>
                <Badge variant={validation.reachable ? "info" : "muted"}>{validation.reachable ? "checked" : "not checked"}</Badge>
                <span className="text-[11px] text-muted-foreground">{formatRelative(validation.checked_at)}</span>
              </div>
              <p className="mt-0.5 text-xs">{validation.summary}</p>
              {validation.error ? <p className="mt-0.5 text-[11px] text-muted-foreground">{validation.error}</p> : null}
              <p className="mt-1 inline-flex items-center gap-1 text-[10.5px] text-muted-foreground">
                <ShieldCheck className="h-3 w-3" /> read-only: SELECT, SHOW and EXPLAIN only; nothing is created or loaded before approval
              </p>
            </div>
            <Button size="sm" variant="outline" disabled={revalidate.isPending} onClick={() => revalidate.mutate(intent.id)}>
              <RefreshCw className={cn("h-3.5 w-3.5", revalidate.isPending && "animate-spin")} /> Check again
            </Button>
          </div>
          {revalidate.error ? <p className="mt-2 text-xs text-destructive">{describeError(revalidate.error)}</p> : null}
          {objects.length ? (
            <div className="mt-4 space-y-3 border-t border-border/50 pt-3">
              <ObjectGroup title="Where it lands" objects={containers} />
              <ObjectGroup title="Source tables" objects={sources} />
              <ObjectGroup title="Target tables" objects={targets} />
            </div>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
