import type { LucideIcon } from "lucide-react";
import { useRef, type CSSProperties, type KeyboardEvent, type ReactNode } from "react";
import { Link } from "react-router-dom";

import { rgba, toneAt } from "@/lib/tones";
import { cn } from "@/lib/utils";

export interface ViewOption<K extends string = string> {
  key: K;
  label: string;
  icon: LucideIcon;
  description?: string;
  count?: ReactNode;
  /** Accent colour as hex; a palette colour is used when left out. */
  tone?: string;
  /** Link mode: the view is a route. */
  to?: string;
}

/** The page's main views as large, unmistakable tabs (lg) or icon pills (md). */
export function ViewSwitcher<K extends string>({
  views,
  value,
  onChange,
  label,
  size = "lg",
  className,
}: {
  views: ViewOption<K>[];
  value: K;
  onChange?: (key: K) => void;
  label: string;
  size?: "lg" | "md";
  className?: string;
}) {
  const refs = useRef<(HTMLElement | null)[]>([]);
  const onKeyDown = (event: KeyboardEvent, index: number) => {
    const last = views.length - 1;
    const next = event.key === "ArrowRight" ? (index === last ? 0 : index + 1) : event.key === "ArrowLeft" ? (index === 0 ? last : index - 1) : event.key === "Home" ? 0 : event.key === "End" ? last : -1;
    if (next < 0) return;
    event.preventDefault();
    refs.current[next]?.focus();
    const view = views[next];
    if (view && !view.to) onChange?.(view.key);
  };

  return (
    <div
      role="tablist"
      aria-label={label}
      className={cn(size === "lg" ? "grid auto-cols-[minmax(13.5rem,1fr)] grid-flow-col gap-2.5 overflow-x-auto pb-1" : "flex flex-wrap gap-2", className)}
    >
      {views.map((view, index) => {
        const active = view.key === value;
        const tone = view.tone ?? toneAt(index);
        const Icon = view.icon;
        const style: CSSProperties = active
          ? { boxShadow: `0 0 0 1.5px ${rgba(tone, 0.85)}, 0 14px 30px -16px ${rgba(tone, 0.9)}` }
          : {};
        const body =
          size === "lg" ? (
            <>
              {active ? (
                <span className="pointer-events-none absolute inset-0" style={{ background: `linear-gradient(135deg, ${rgba(tone, 0.16)}, transparent 65%)` }} aria-hidden="true" />
              ) : null}
              <span
                className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-xl transition-all duration-200"
                style={
                  active
                    ? { background: `linear-gradient(145deg, ${rgba(tone, 0.75)}, ${tone})`, color: "#fff", boxShadow: `0 8px 18px -10px ${tone}` }
                    : { background: rgba(tone, 0.12), color: tone }
                }
                aria-hidden="true"
              >
                <Icon className="h-5 w-5" strokeWidth={2} />
              </span>
              <span className="relative min-w-0 flex-1">
                <span className={cn("block truncate text-sm font-medium", active ? "text-foreground" : "text-foreground/80")}>{view.label}</span>
                <span className="mt-0.5 flex min-w-0 items-center gap-1.5 text-xs text-muted-foreground">
                  {view.count !== undefined && view.count !== null ? (
                    <span
                      className={cn("shrink-0 rounded-full px-1.5 py-px text-[11px] tabular-nums", !active && "bg-muted")}
                      style={active ? { background: rgba(tone, 0.16), color: tone } : undefined}
                    >
                      {view.count}
                    </span>
                  ) : null}
                  {view.description ? <span className="truncate">{view.description}</span> : null}
                </span>
              </span>
              {active ? <span className="absolute inset-x-4 bottom-0 h-[3px] rounded-t-full" style={{ background: tone }} aria-hidden="true" /> : null}
            </>
          ) : (
            <>
              <Icon className="h-4 w-4 shrink-0" style={{ color: active ? tone : undefined }} aria-hidden="true" />
              <span className={cn(active ? "font-medium text-foreground" : "text-muted-foreground group-hover:text-foreground")}>{view.label}</span>
              {view.count !== undefined && view.count !== null ? <span className="text-[11px] tabular-nums text-muted-foreground">{view.count}</span> : null}
            </>
          );
        const classes =
          size === "lg"
            ? cn(
                "group relative flex items-center gap-3 overflow-hidden rounded-2xl border p-3 text-left outline-none transition-all duration-200 focus-visible:ring-2 focus-visible:ring-ring",
                active ? "border-transparent bg-card" : "border-border/70 bg-card/50 hover:-translate-y-0.5 hover:border-border hover:bg-card hover:shadow-md",
              )
            : cn(
                "group inline-flex items-center gap-2 rounded-xl border px-3.5 py-2 text-sm outline-none transition-all duration-200 focus-visible:ring-2 focus-visible:ring-ring",
                active ? "border-transparent bg-card" : "border-border/70 bg-card/50 hover:border-border hover:bg-card",
              );
        const shared = {
          role: "tab" as const,
          "aria-selected": active,
          tabIndex: active ? 0 : -1,
          className: classes,
          style: size === "md" && active ? { ...style, background: `linear-gradient(135deg, ${rgba(tone, 0.14)}, transparent 80%)` } : style,
          onKeyDown: (event: KeyboardEvent) => onKeyDown(event, index),
          title: view.description,
        };
        return view.to ? (
          <Link key={view.key} to={view.to} ref={(el) => {
              refs.current[index] = el;
            }} {...shared}>
            {body}
          </Link>
        ) : (
          <button key={view.key} type="button" ref={(el) => {
              refs.current[index] = el;
            }} onClick={() => onChange?.(view.key)} {...shared}>
            {body}
          </button>
        );
      })}
    </div>
  );
}
