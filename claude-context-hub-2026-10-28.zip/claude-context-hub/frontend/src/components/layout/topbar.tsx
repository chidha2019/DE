import type { ReactNode } from "react";

interface TopbarProps {
  title: string;
  description?: string;
  actions?: ReactNode;
}

/** Page header used by every route; keeps titles/actions visually consistent. */
export function Topbar({ title, description, actions }: TopbarProps) {
  return (
    <header className="relative flex flex-wrap items-start justify-between gap-4 border-b border-border/80 bg-background/70 px-6 py-5 backdrop-blur">
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-primary/50 via-primary/10 to-transparent" aria-hidden="true" />
      <div className="min-w-0">
        <h1 className="font-display text-2xl font-medium tracking-tight">
          {title}
          <span className="text-primary">.</span>
        </h1>
        {description ? <p className="mt-1 max-w-3xl text-sm text-muted-foreground">{description}</p> : null}
      </div>
      {actions ? <div className="flex items-center gap-2">{actions}</div> : null}
    </header>
  );
}
