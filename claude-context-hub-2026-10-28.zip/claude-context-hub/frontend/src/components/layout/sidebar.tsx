import {
  BookOpen,
  Cable,
  ClipboardCheck,
  ChevronsLeft,
  ChevronsRight,
  Home,
  Layers,
  Library,
  LogOut,
  Moon,
  Sparkles,
  Sun,
  Users,
  Workflow,
  X,
  type LucideIcon,
} from "lucide-react";
import { useEffect, useState, type CSSProperties } from "react";
import { NavLink, useLocation, useNavigate } from "react-router-dom";

import { BrandLogo } from "@/components/layout/brand";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { useGenieStatus, useServiceHealth } from "@/hooks/queries";
import { PERSONA_LIST } from "@/lib/personas";
import { cn } from "@/lib/utils";
import { useTheme } from "@/providers/theme-provider";

interface NavEntry {
  to: string;
  label: string;
  icon: LucideIcon;
  hint?: string;
  /** Other route prefixes that count as this entry being active. */
  also?: string[];
}

interface NavGroup {
  label: string;
  /** HSL triplet ("h s% l%") that tints the group's icon tiles and separator in both themes. */
  accent: string;
  items: NavEntry[];
}

const GROUPS: NavGroup[] = [
  { label: "Start", accent: "172 66% 45%", items: [{ to: "/home", label: "Home", icon: Home, hint: "What the hub is, with live numbers and events" }] },
  {
    label: "Personas",
    accent: "262 70% 62%",
    items: [
      {
        to: "/personas",
        label: "Personas",
        icon: Users,
        hint: `Choose your perspective: ${PERSONA_LIST.length} workspaces, each with a companion`,
        also: PERSONA_LIST.map((p) => p.path),
      },
    ],
  },
  {
    label: "Data & semantics",
    accent: "205 80% 55%",
    items: [
      { to: "/semantic", label: "Semantic Hub", icon: Layers, hint: "Semantic catalog, business model and data catalog" },
      { to: "/glossary", label: "Glossary", icon: BookOpen, hint: "Insurance terms, domains and KPIs" },
    ],
  },
  {
    label: "Ingestion",
    accent: "28 90% 55%",
    items: [
      { to: "/connectors", label: "Connectors", icon: Cable, hint: "The catalogue: connected, available and planned sources" },
      { to: "/intents", label: "Intents", icon: ClipboardCheck, hint: "Jira or form requests → spec → approval → generated pipeline" },
      { to: "/pipelines", label: "Pipelines", icon: Workflow, hint: "Saved ingestion jobs, schedules and runs" },
    ],
  },
  {
    label: "Knowledge",
    accent: "330 75% 60%",
    items: [
      { to: "/genie", label: "Genie", icon: Sparkles, hint: "Ask the hub in plain language" },
      { to: "/knowledge", label: "Knowledge Hub", icon: Library, hint: "Crawled GitHub repos, and the documents and entities Genie retrieves from" },
    ],
  },
];

const COLLAPSED_KEY = "ech-sidebar-collapsed";

function hasStoredChoice(): boolean {
  try {
    const stored = localStorage.getItem(COLLAPSED_KEY);
    return stored === "1" || stored === "0";
  } catch {
    return false;
  }
}

/** The stored choice wins; without one, narrow desktops (scaled laptops) start collapsed. */
function readCollapsed(): boolean {
  try {
    const stored = localStorage.getItem(COLLAPSED_KEY);
    if (stored === "1") return true;
    if (stored === "0") return false;
  } catch {
    /* storage unavailable */
  }
  return typeof window !== "undefined" && window.innerWidth < 1280;
}

const NARROW = "(max-width: 1023px)";

/** Tablets and small laptops: the rail stays collapsed whatever was stored for wide screens. */
function useNarrow(): boolean {
  const [narrow, setNarrow] = useState(() => typeof window !== "undefined" && window.matchMedia(NARROW).matches);
  useEffect(() => {
    const query = window.matchMedia(NARROW);
    const onChange = () => setNarrow(query.matches);
    query.addEventListener("change", onChange);
    return () => query.removeEventListener("change", onChange);
  }, []);
  return narrow;
}

/** The icon tile: tinted with the group's accent, filled with it when the entry is active. */
function tileStyle(accent: string, active: boolean): CSSProperties {
  return active
    ? {
        background: `linear-gradient(135deg, hsl(${accent}), hsl(${accent} / 0.7))`,
        borderColor: `hsl(${accent} / 0.6)`,
        color: "white",
        boxShadow: `0 0 0 1px hsl(${accent} / 0.35), 0 10px 22px -12px hsl(${accent} / 0.9)`,
      }
    : { background: `hsl(${accent} / 0.12)`, borderColor: `hsl(${accent} / 0.32)`, color: `hsl(${accent})` };
}

function NavItem({ entry, accent, collapsed }: { entry: NavEntry; accent: string; collapsed: boolean }) {
  const { pathname } = useLocation();
  // Active state is computed here, not via NavLink's className callback: the tooltip trigger's Slot
  // stringifies a function className, which left the collapsed rail without its centring classes.
  const on = pathname === entry.to || pathname.startsWith(`${entry.to}/`) || (entry.also?.some((prefix) => pathname.startsWith(prefix)) ?? false);
  const link = (
    <NavLink
      to={entry.to}
      title={collapsed ? undefined : entry.hint}
      className={cn(
        "group relative flex items-center gap-3 rounded-xl py-1.5 text-sm text-muted-foreground transition-colors hover:bg-accent/50 hover:text-foreground",
        collapsed ? "justify-center px-0" : "pl-2 pr-2",
        on && "bg-accent/60 text-foreground",
      )}
    >
      {on && !collapsed ? (
        <span className="absolute -left-3 top-1/2 h-5 w-1 -translate-y-1/2 rounded-r-full" style={{ background: `hsl(${accent})` }} aria-hidden="true" />
      ) : null}
      <span
        className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border transition-transform group-hover:scale-105"
        style={tileStyle(accent, on)}
      >
        <entry.icon className="h-[18px] w-[18px]" />
      </span>
      {!collapsed ? <span className={cn("truncate", on ? "font-medium" : "font-normal")}>{entry.label}</span> : null}
    </NavLink>
  );
  if (!collapsed) return link;
  return (
    <Tooltip>
      <TooltipTrigger asChild>{link}</TooltipTrigger>
      <TooltipContent side="right">
        <div className="font-medium">{entry.label}</div>
        {entry.hint ? <div className="text-xs text-muted-foreground">{entry.hint}</div> : null}
      </TooltipContent>
    </Tooltip>
  );
}

function GroupHeader({ group, collapsed, first }: { group: NavGroup; collapsed: boolean; first: boolean }) {
  if (collapsed) {
    if (first) return null;
    return (
      <div className="relative mx-1 mb-2 mt-1 h-px bg-border/80" aria-hidden="true">
        <span
          className="absolute left-1/2 top-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full ring-2 ring-card"
          style={{ background: `hsl(${group.accent})` }}
        />
      </div>
    );
  }
  return (
    <div className="mb-1.5 flex items-center gap-3 pl-2 pr-2">
      <span className="flex w-9 shrink-0 justify-center" aria-hidden="true">
        <span className="h-1.5 w-1.5 rounded-full" style={{ background: `hsl(${group.accent})` }} />
      </span>
      <span className="text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">{group.label}</span>
      <span className="h-px flex-1 bg-border/80" aria-hidden="true" />
    </div>
  );
}

type Health = ReturnType<typeof useServiceHealth>;

function healthTone(q: Health): string {
  if (q.isLoading) return "bg-muted-foreground/50";
  if (q.isError) return "bg-destructive";
  return q.data?.status === "ok" ? "animate-pulse-dot bg-success" : "bg-warning";
}

/** Both services and the Genie model in one small card; the tooltip lists every readiness check. */
function SystemWidget({ collapsed }: { collapsed: boolean }) {
  const ingestion = useServiceHealth("ingestion");
  const query = useServiceHealth("query");
  const genie = useGenieStatus();
  const services = [
    { key: "ingestion", label: "Ingestion", q: ingestion },
    { key: "query", label: "Query", q: query },
  ];
  const allOk = services.every((s) => s.q.data?.status === "ok");
  const anyDown = services.some((s) => s.q.isError);

  const body = collapsed ? (
    <div className="flex h-9 w-9 items-center justify-center rounded-xl border border-border/70 bg-card/80" aria-label="Service health">
      <span className="flex flex-col gap-1">
        {services.map((s) => (
          <span key={s.key} className={cn("h-1.5 w-1.5 rounded-full", healthTone(s.q))} />
        ))}
      </span>
    </div>
  ) : (
    <div className="rounded-2xl border border-border/70 bg-background/40 p-2">
      <div className="flex items-center justify-between text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
        <span>System</span>
        <span
          className={cn(
            "rounded-full px-1.5 py-px text-[9px] normal-case tracking-normal",
            anyDown ? "bg-destructive/10 text-destructive" : allOk ? "bg-success/10 text-success" : "bg-warning/10 text-warning",
          )}
        >
          {anyDown ? "degraded" : allOk ? "online" : "checking"}
        </span>
      </div>
      <div className="mt-1 space-y-0.5">
        {services.map((s) => (
          <div key={s.key} className="flex items-center gap-2 rounded-md py-0.5 text-xs text-muted-foreground">
            <span className={cn("h-1.5 w-1.5 shrink-0 rounded-full", healthTone(s.q))} />
            <span className="truncate">{s.label}</span>
            {s.q.data?.version ? <span className="ml-auto font-mono text-[10px] opacity-70">v{s.q.data.version}</span> : null}
          </div>
        ))}
        <div className="flex items-center gap-2 rounded-md py-0.5 text-xs text-muted-foreground">
          <Sparkles className="h-3 w-3 shrink-0 text-primary" />
          <span className="truncate font-mono text-[10px]">{genie.data ? (genie.data.configured ? genie.data.model : "no model configured") : "…"}</span>
        </div>
      </div>
    </div>
  );

  return (
    <Tooltip>
      <TooltipTrigger asChild>{body}</TooltipTrigger>
      <TooltipContent side="right">
        <div className="space-y-1.5 text-xs">
          {services.map((s) => (
            <div key={s.key}>
              <div className="font-medium">
                {s.label}: {s.q.isLoading ? "checking" : s.q.isError ? "unreachable" : (s.q.data?.status ?? "down")}
                {s.q.data?.version ? <span className="ml-1 font-mono text-muted-foreground">v{s.q.data.version}</span> : null}
              </div>
              {Object.entries(s.q.data?.checks ?? {}).map(([name, ok]) => (
                <div key={name} className="flex items-center gap-2 text-muted-foreground">
                  <span className={cn("h-1.5 w-1.5 rounded-full", ok ? "bg-success" : "bg-destructive")} />
                  {name}
                </div>
              ))}
            </div>
          ))}
          <div className="text-muted-foreground">
            Genie · {genie.data?.configured ? `${genie.data.model} via ${genie.data.provider}` : "no model configured"}
          </div>
        </div>
      </TooltipContent>
    </Tooltip>
  );
}

interface SidebarProps {
  /** Phones: the sidebar is a drawer over the page, opened from the top bar. */
  mobileOpen?: boolean;
  onMobileClose?: () => void;
}

export function Sidebar({ mobileOpen = false, onMobileClose }: SidebarProps) {
  const { resolved, toggle } = useTheme();
  const navigate = useNavigate();
  const [stored, setCollapsed] = useState(readCollapsed);
  const narrow = useNarrow();
  const [narrowOpen, setNarrowOpen] = useState(false);
  // The phone drawer always shows labels; below 1024px the rail is collapsed unless opened for now;
  // wider screens follow the stored or automatic choice.
  const collapsed = mobileOpen ? false : narrow ? !narrowOpen : stored;

  // Until the user picks a width, follow the window: dragging onto a scaled laptop screen
  // collapses the rail, moving back to a wide monitor expands it.
  useEffect(() => {
    // Checked per event, not once at mount: a choice made after mount must stop the window from overriding it.
    const onResize = () => {
      if (hasStoredChoice()) return;
      setCollapsed(window.innerWidth < 1280);
    };
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  const toggleCollapsed = () => {
    if (narrow) {
      setNarrowOpen((open) => !open);
      return;
    }
    const next = !stored;
    setCollapsed(next);
    try {
      localStorage.setItem(COLLAPSED_KEY, next ? "1" : "0");
    } catch {
      /* storage unavailable */
    }
  };

  const themeLabel = resolved === "dark" ? "Switch to light mode" : "Switch to dark mode";

  return (
    <aside
      className={cn(
        "relative h-full shrink-0 flex-col border-r border-border/80 bg-card/60 backdrop-blur transition-[width] duration-200",
        mobileOpen ? "fixed inset-y-0 left-0 z-50 flex w-[16.75rem] bg-card shadow-2xl" : "hidden md:flex",
        !mobileOpen && (collapsed ? "w-[4.75rem]" : "w-[16.75rem]"),
      )}
    >
      <div className="pointer-events-none absolute inset-x-0 top-0 h-40 bg-gradient-to-b from-primary/10 to-transparent" aria-hidden="true" />
      <div className={cn("relative flex items-center gap-2 pb-3 pt-5", collapsed ? "flex-col px-3" : "justify-between px-5")}>
        <BrandLogo collapsed={collapsed} />
        <Button
          variant="outline"
          size="icon-sm"
          className="h-8 w-8 border-primary/30 bg-primary/5 text-primary hover:bg-primary/15 hover:text-primary"
          onClick={mobileOpen ? onMobileClose : toggleCollapsed}
          aria-label={mobileOpen ? "Close navigation" : collapsed ? "Expand navigation" : "Collapse navigation"}
        >
          {mobileOpen ? <X className="h-4 w-4" /> : collapsed ? <ChevronsRight className="h-4 w-4" /> : <ChevronsLeft className="h-4 w-4" />}
        </Button>
      </div>

      <nav className={cn("scrollbar-hidden relative flex-1 space-y-4 overflow-y-auto px-3 py-2", collapsed && "px-2.5")}>
        {GROUPS.map((group, index) => (
          <div key={group.label}>
            <GroupHeader group={group} collapsed={collapsed} first={index === 0} />
            <div className="space-y-1">
              {group.items.map((entry) => (
                <NavItem key={entry.to} entry={entry} accent={group.accent} collapsed={collapsed} />
              ))}
            </div>
          </div>
        ))}
      </nav>

      <div className={cn("space-y-2 border-t border-border/80 p-3", collapsed && "flex flex-col items-center p-2")}>
        <SystemWidget collapsed={collapsed} />
        <div className={cn("grid gap-1 rounded-2xl border border-border/70 bg-background/40 p-1", collapsed ? "grid-cols-1" : "grid-cols-2")}>
          {collapsed ? (
            <>
              <Button
                variant="ghost"
                size="icon-sm"
                className="h-8 w-8 text-muted-foreground hover:text-foreground"
                onClick={toggle}
                title={themeLabel}
                aria-label={themeLabel}
              >
                {resolved === "dark" ? <Sun className="h-3.5 w-3.5" /> : <Moon className="h-3.5 w-3.5" />}
              </Button>
              <Button
                variant="ghost"
                size="icon-sm"
                className="h-8 w-8 text-muted-foreground hover:text-foreground"
                onClick={() => navigate("/")}
                title="Sign out"
                aria-label="Sign out"
              >
                <LogOut className="h-3.5 w-3.5" />
              </Button>
            </>
          ) : (
            <>
              <Button
                variant="ghost"
                size="sm"
                className="justify-start gap-2 px-1 text-xs text-muted-foreground hover:text-foreground"
                onClick={toggle}
                title={themeLabel}
              >
                {resolved === "dark" ? <Sun className="h-3.5 w-3.5" /> : <Moon className="h-3.5 w-3.5" />}
                {resolved === "dark" ? "Light" : "Dark"}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="justify-start gap-2 px-1 text-xs text-muted-foreground hover:text-foreground"
                onClick={() => navigate("/")}
                title="Sign out"
              >
                <LogOut className="h-3.5 w-3.5" />
                Sign out
              </Button>
            </>
          )}
        </div>
      </div>
    </aside>
  );
}
