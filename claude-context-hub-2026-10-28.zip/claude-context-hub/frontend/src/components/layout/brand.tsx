import { cn } from "@/lib/utils";

interface BrandLogoProps {
  /** Mark only (collapsed navigation). */
  collapsed?: boolean;
  /** The wordmark is grey in the source file; on dark surfaces it is brightened a little. */
  variant?: "dark" | "light";
  className?: string;
}

/** The Data Economy logo as shipped on dataeconomy.ai (public/brand), mark-only when collapsed. */
export function BrandLogo({ collapsed, variant = "dark", className }: BrandLogoProps) {
  if (collapsed) {
    return <img src="/brand/DE_Mark.svg" alt="Data Economy" className={cn("h-9 w-auto", className)} draggable={false} />;
  }
  return (
    <img
      src="/brand/DE_Logo.svg"
      alt="Data Economy"
      className={cn("h-11 w-auto", variant === "dark" && "brightness-[1.18] contrast-[1.05]", className)}
      draggable={false}
    />
  );
}
