import type { LucideIcon } from "lucide-react";
import type { ReactNode } from "react";

import { formatCompact } from "@/lib/format";
import { rgba, toneAt } from "@/lib/tones";
import { cn } from "@/lib/utils";

interface PageHeroProps {
  eyebrow: string;
  icon: LucideIcon;
  title: string;
  lead: string;
  sub?: ReactNode;
  actions?: ReactNode;
  aside?: ReactNode;
  compact?: boolean;
  /** One-row banner for pages whose content needs the height (rails, graphs, chat). */
  slim?: boolean;
  className?: string;
}

/** The banner at the top of a workspace: eyebrow chip, display title, copy, calls to action and an illustration panel. */
export function PageHero({ eyebrow, icon: Icon, title, lead, sub, actions, aside, compact, slim, className }: PageHeroProps) {
  if (slim) {
    return (
      <section
        className={cn(
          "relative overflow-clip rounded-2xl border border-primary/15 bg-gradient-to-r from-card via-card to-accent/60 px-6 py-5 shadow-[inset_0_1px_0_0_hsl(var(--primary)/0.14)]",
          className,
        )}
      >
        <div className="hero-grid pointer-events-none absolute inset-0 opacity-30" aria-hidden="true" />
        <div className="pointer-events-none absolute -right-16 -top-24 h-56 w-56 rounded-full bg-primary/15 blur-3xl" aria-hidden="true" />
        <div className="relative flex flex-wrap items-center justify-between gap-x-8 gap-y-4">
          <div className="min-w-0 flex-1 basis-[26rem]">
            <div className="flex items-center gap-2 text-[10px] font-medium uppercase tracking-[0.16em] text-primary">
              <span className="icon-tile h-7 w-7">
                <Icon className="h-3.5 w-3.5" />
              </span>
              {eyebrow}
            </div>
            <h1 className="mt-2 font-display text-2xl font-medium tracking-tight md:text-3xl">
              {title}
              <span className="text-primary">.</span>
            </h1>
            <p className="mt-1 max-w-3xl text-sm text-muted-foreground">{lead}</p>
            {sub ? <div className="mt-1 max-w-3xl text-sm text-muted-foreground">{sub}</div> : null}
          </div>
          {aside || actions ? (
            <div className="flex flex-wrap items-center gap-4">
              {aside}
              {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
            </div>
          ) : null}
        </div>
      </section>
    );
  }
  return (
    <section
      className={cn(
        "relative overflow-clip rounded-2xl border border-primary/15 bg-gradient-to-br from-card via-card to-accent/60 shadow-[inset_0_1px_0_0_hsl(var(--primary)/0.14)]",
        compact ? "px-6 py-6" : "px-8 py-9",
        className,
      )}
    >
      <div className="hero-grid pointer-events-none absolute inset-0 opacity-40" aria-hidden="true" />
      <div className="pointer-events-none absolute -right-20 -top-24 h-72 w-72 rounded-full bg-primary/15 blur-3xl" aria-hidden="true" />
      <div className="pointer-events-none absolute -bottom-32 left-1/3 h-64 w-64 rounded-full bg-primary/10 blur-3xl" aria-hidden="true" />
      <div className={cn("relative grid gap-8", aside && "lg:grid-cols-[minmax(0,1fr)_auto] lg:items-center")}>
        <div className="min-w-0">
          <div className="flex items-center gap-2.5 text-[10px] font-medium uppercase tracking-[0.16em] text-primary">
            <span className="icon-tile h-8 w-8">
              <Icon className="h-4 w-4" />
            </span>
            {eyebrow}
          </div>
          <h1 className={cn("mt-4 font-display font-medium tracking-tight text-foreground", compact ? "text-3xl md:text-4xl" : "text-4xl md:text-5xl")}>
            {title}
            <span className="text-primary">.</span>
          </h1>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted-foreground md:text-[15px]">{lead}</p>
          {sub ? <div className="mt-1 max-w-2xl text-sm text-muted-foreground">{sub}</div> : null}
          {actions ? <div className="mt-6 flex flex-wrap items-center gap-2">{actions}</div> : null}
        </div>
        {aside ? <div className="hidden lg:block">{aside}</div> : null}
      </div>
    </section>
  );
}

interface HeroFlowProps {
  title: string;
  icon: LucideIcon;
  source: { label: string; caption: string };
  targets: { label: string; caption: string; icon: LucideIcon }[];
  footer?: string;
  /** `column` stacks the targets (tall, for the dashboard); `row` lines everything up (short, for persona banners). */
  layout?: "column" | "row";
}

/** The framed "one source, many outcomes" diagram used on the right of a hero. */
export function HeroFlow({ title, icon: Icon, source, targets, footer, layout = "column" }: HeroFlowProps) {
  if (layout === "row") {
    return (
      <div className="max-w-full rounded-2xl border border-primary/15 bg-background/40 px-4 py-3 backdrop-blur">
        <div className="flex items-center justify-between gap-4 text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
          <span className="truncate">{title}</span>
          <Icon className="h-3.5 w-3.5 shrink-0 text-primary" />
        </div>
        <div className="mt-2 flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-2.5 rounded-xl border border-primary/25 bg-primary/5 px-3 py-1.5">
            <span className="icon-tile h-9 w-9">
              <Icon className="h-4 w-4" />
            </span>
            <div className="min-w-0">
              <div className="text-xs font-medium">{source.label}</div>
              <div className="truncate text-[10px] text-muted-foreground">{source.caption}</div>
            </div>
          </div>
          <svg viewBox="0 0 36 24" className="h-6 w-9 shrink-0 text-primary/60" aria-hidden="true">
            <path d="M0 12 H14 M14 12 L8 6 M14 12 L8 18 M18 12 H36" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
            <circle cx="16" cy="12" r="2.5" fill="currentColor" />
          </svg>
          {targets.map((t, i) => (
            <div key={t.label} className="flex items-center gap-2 rounded-lg border border-primary/15 bg-card/80 px-2.5 py-1.5">
              <TargetIcon icon={t.icon} tone={toneAt(i)} />
              <div className="min-w-0">
                <div className="truncate text-xs font-medium">{t.label}</div>
                <div className="truncate text-[10px] text-muted-foreground">{t.caption}</div>
              </div>
            </div>
          ))}
        </div>
        {footer ? <p className="mt-2 text-[10px] text-muted-foreground">{footer}</p> : null}
      </div>
    );
  }
  return (
    <div className="w-[22rem] max-w-full rounded-2xl border border-primary/15 bg-background/40 p-4 backdrop-blur xl:w-[26rem] xl:p-5">
      <div className="flex items-center justify-between text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
        {title}
        <Icon className="h-3.5 w-3.5 text-primary" />
      </div>
      <div className="mt-4 grid grid-cols-[auto_28px_1fr] items-center gap-2">
        <div className="flex w-28 flex-col items-center text-center">
          <span className="icon-tile h-14 w-14 rounded-2xl">
            <Icon className="h-6 w-6" />
          </span>
          <span className="mt-2 text-xs font-medium">{source.label}</span>
          <span className="text-[10px] text-muted-foreground">{source.caption}</span>
        </div>
        <svg viewBox="0 0 28 120" className="h-[120px] w-7 text-primary/50" aria-hidden="true">
          <path d="M0 60 H10 M10 60 V14 H28 M10 60 H28 M10 60 V106 H28" fill="none" stroke="currentColor" strokeWidth="1.5" />
          <circle cx="10" cy="60" r="2.5" fill="currentColor" />
        </svg>
        <div className="space-y-2">
          {targets.map((t, i) => (
            <div key={t.label} className="flex items-center gap-2.5 rounded-lg border border-primary/15 bg-card/80 px-3 py-2">
              <TargetIcon icon={t.icon} tone={toneAt(i)} />
              <div className="min-w-0">
                <div className="truncate text-xs font-medium">{t.label}</div>
                <div className="truncate text-[10px] text-muted-foreground">{t.caption}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
      {footer ? <p className="mt-4 text-center text-[10px] text-muted-foreground">{footer}</p> : null}
    </div>
  );
}

function TargetIcon({ icon: Icon, tone }: { icon: LucideIcon; tone: string }) {
  return (
    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md" style={{ background: rgba(tone, 0.14), color: tone }} aria-hidden="true">
      <Icon className="h-3.5 w-3.5" />
    </span>
  );
}

interface HeroStatItem {
  label: string;
  value: number | string | null | undefined;
  icon: LucideIcon;
  hint?: string;
  /** Accent colour as hex; a palette colour by position when left out. */
  tone?: string;
}

/** A row of small tinted icon tiles with a number or a word under a label; the aside of a slim hero. */
export function HeroStats({ items }: { items: HeroStatItem[] }) {
  return (
    <div className="flex flex-wrap gap-2">
      {items.map((item, index) => {
        const tone = item.tone ?? toneAt(index);
        return (
          <div
            key={item.label}
            className="relative flex items-center gap-3 overflow-hidden rounded-xl border bg-background/50 px-3 py-2 backdrop-blur transition-shadow hover:shadow-md"
            style={{ borderColor: rgba(tone, 0.28) }}
            title={item.hint}
          >
            <span className="pointer-events-none absolute -left-6 -top-6 h-16 w-16 rounded-full opacity-60 blur-2xl" style={{ background: rgba(tone, 0.35) }} aria-hidden="true" />
            <span
              className="relative flex h-9 w-9 shrink-0 items-center justify-center rounded-xl"
              style={{ background: `linear-gradient(145deg, ${rgba(tone, 0.22)}, ${rgba(tone, 0.08)})`, color: tone, boxShadow: `inset 0 0 0 1px ${rgba(tone, 0.35)}` }}
              aria-hidden="true"
            >
              <item.icon className="h-4 w-4" />
            </span>
            <div className="relative min-w-0">
              <div className="font-display text-lg font-medium leading-tight tabular-nums">
                {typeof item.value === "number" ? formatCompact(item.value) : (item.value ?? "–")}
              </div>
              <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{item.label}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

