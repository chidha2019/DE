import { Menu } from "lucide-react";
import { Component, useEffect, useState, type ErrorInfo, type ReactNode } from "react";
import { Outlet, useLocation } from "react-router-dom";

import { BrandLogo } from "@/components/layout/brand";
import { Sidebar } from "@/components/layout/sidebar";
import { Button } from "@/components/ui/button";
import { rememberPath } from "@/pages/landing-page";

interface BoundaryState {
  error: Error | null;
}

/** Last-resort error boundary so one broken page never blanks the whole console. */
class PageErrorBoundary extends Component<{ children: ReactNode }, BoundaryState> {
  state: BoundaryState = { error: null };

  static getDerivedStateFromError(error: Error): BoundaryState {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo): void {
    console.error("page crashed", error, info.componentStack);
  }

  render() {
    if (this.state.error) {
      return (
        <div className="m-6 rounded-lg border border-destructive/40 bg-destructive/5 p-6">
          <h2 className="font-medium text-destructive">Something went wrong rendering this page</h2>
          <pre className="mt-2 max-h-48 overflow-auto whitespace-pre-wrap text-xs text-muted-foreground">{this.state.error.message}</pre>
          <Button className="mt-4" variant="outline" size="sm" onClick={() => this.setState({ error: null })}>
            Try again
          </Button>
        </div>
      );
    }
    return this.props.children;
  }
}

export function AppShell() {
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  // The landing page's "Open Context Hub" returns here.
  useEffect(() => rememberPath(location.pathname + location.search), [location.pathname, location.search]);
  // The phone drawer closes on navigation, on Escape and when the window grows past the phone layout.
  useEffect(() => setMenuOpen(false), [location.pathname]);
  useEffect(() => {
    const wide = window.matchMedia("(min-width: 768px)");
    const onWide = () => wide.matches && setMenuOpen(false);
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setMenuOpen(false);
    wide.addEventListener("change", onWide);
    window.addEventListener("keydown", onKey);
    return () => {
      wide.removeEventListener("change", onWide);
      window.removeEventListener("keydown", onKey);
    };
  }, []);
  return (
    <div className="flex h-full min-h-screen">
      <Sidebar mobileOpen={menuOpen} onMobileClose={() => setMenuOpen(false)} />
      {menuOpen ? <div className="fixed inset-0 z-40 bg-background/70 backdrop-blur-sm md:hidden" onClick={() => setMenuOpen(false)} aria-hidden="true" /> : null}
      <main className="flex min-w-0 flex-1 flex-col overflow-hidden">
        <div className="flex h-14 shrink-0 items-center gap-3 border-b border-border/80 bg-card/70 px-4 backdrop-blur md:hidden">
          <Button variant="outline" size="icon-sm" className="h-9 w-9 border-primary/30 bg-primary/5 text-primary" onClick={() => setMenuOpen(true)} aria-label="Open navigation" aria-expanded={menuOpen}>
            <Menu className="h-4 w-4" />
          </Button>
          <BrandLogo className="h-7 w-auto" />
        </div>
        <PageErrorBoundary>
          <Outlet />
        </PageErrorBoundary>
      </main>
    </div>
  );
}
