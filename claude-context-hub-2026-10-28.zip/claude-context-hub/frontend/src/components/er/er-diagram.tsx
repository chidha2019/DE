import { Check, Copy, Download, KeyRound, Link2, List, Maximize2, Minus, Network, Plus, X } from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import type { ErColumn, ErDiagram, ErEntity, ErEntityKind, ErRelationship } from "@/api/types";
import { Button } from "@/components/ui/button";
import { formatInt } from "@/lib/format";
import { cn } from "@/lib/utils";

const BOX_W = 264;
const HEAD_H = 46;
const ROW_H = 22;
const PAD_B = 8;
const COL_GAP = 150;
const ROW_GAP = 28;
const MARGIN = 28;
const PER_COLUMN = 8; // a level with more tables than this wraps into another column

const KIND: Record<ErEntityKind, { label: string; head: string; stroke: string; text: string; order: number }> = {
  dimension: { label: "dimension", head: "fill-sky-500/15", stroke: "stroke-sky-500/60", text: "text-sky-700 dark:text-sky-300", order: 1 },
  reference: { label: "reference", head: "fill-slate-500/15", stroke: "stroke-slate-500/60", text: "text-slate-600 dark:text-slate-300", order: 2 },
  bridge: { label: "bridge", head: "fill-amber-500/15", stroke: "stroke-amber-500/60", text: "text-amber-700 dark:text-amber-300", order: 3 },
  fact: { label: "fact", head: "fill-violet-500/15", stroke: "stroke-violet-500/60", text: "text-violet-700 dark:text-violet-300", order: 4 },
  aggregate: { label: "aggregate", head: "fill-emerald-500/15", stroke: "stroke-emerald-500/60", text: "text-emerald-700 dark:text-emerald-300", order: 5 },
  table: { label: "table", head: "fill-primary/15", stroke: "stroke-primary/60", text: "text-primary", order: 6 },
  external: { label: "not in this model", head: "fill-muted", stroke: "stroke-muted-foreground/50", text: "text-muted-foreground", order: 0 },
};

type Mode = "keys" | "all";
type Row = { kind: "column"; col: ErColumn } | { kind: "more"; count: number };
interface Box {
  e: ErEntity;
  x: number;
  y: number;
  h: number;
  rows: Row[];
}

function rowsOf(e: ErEntity, mode: Mode): Row[] {
  if (mode === "all" || e.kind === "external") return e.columns.map((col) => ({ kind: "column", col }));
  const keys = e.columns.filter((c) => c.pk || c.fk);
  const rest = e.columns.length - keys.length;
  return [...keys.map((col) => ({ kind: "column" as const, col })), ...(rest > 0 ? [{ kind: "more" as const, count: rest }] : [])];
}

/** Referenced tables to the left, the tables that reference them to the right, ordered to keep lines short. */
function layout(d: ErDiagram, mode: Mode): { boxes: Map<string, Box>; width: number; height: number } {
  const names = new Set(d.entities.map((e) => e.name));
  const parents = new Map<string, Set<string>>();
  const children = new Map<string, Set<string>>();
  for (const r of d.relationships) {
    if (r.from_table === r.to_table || !names.has(r.from_table) || !names.has(r.to_table)) continue;
    if (!parents.has(r.from_table)) parents.set(r.from_table, new Set());
    if (!children.has(r.to_table)) children.set(r.to_table, new Set());
    parents.get(r.from_table)?.add(r.to_table);
    children.get(r.to_table)?.add(r.from_table);
  }
  const level = new Map<string, number>();
  const depth = (n: string, path: Set<string>): number => {
    const known = level.get(n);
    if (known !== undefined) return known;
    if (path.has(n)) return 0; // a cycle: break it here
    path.add(n);
    const ps = [...(parents.get(n) ?? [])];
    const l = ps.length ? 1 + Math.max(...ps.map((p) => depth(p, path))) : 0;
    path.delete(n);
    level.set(n, l);
    return l;
  };
  d.entities.forEach((e) => depth(e.name, new Set()));

  const levels: ErEntity[][] = [];
  for (const e of [...d.entities].sort((a, b) => KIND[a.kind].order - KIND[b.kind].order || a.name.localeCompare(b.name))) {
    const l = level.get(e.name) ?? 0;
    (levels[l] ??= []).push(e);
  }
  // Order each column by where the tables it is joined to sit (a few down-and-up sweeps), so lines cross less.
  const at = new Map<string, number>();
  const place = () => levels.forEach((col) => col?.forEach((e, i) => at.set(e.name, (i + 0.5) / col.length)));
  const mean = (xs: string[]) => (xs.length ? xs.reduce((s, x) => s + (at.get(x) ?? 0.5), 0) / xs.length : 2);
  place();
  for (let pass = 0; pass < 3; pass++) {
    for (let l = 1; l < levels.length; l++) {
      const col = levels[l];
      if (!col) continue;
      const key = new Map(col.map((e) => [e.name, mean([...(parents.get(e.name) ?? [])])]));
      col.sort((a, b) => (key.get(a.name) ?? 2) - (key.get(b.name) ?? 2));
      place();
    }
    for (let l = levels.length - 2; l >= 0; l--) {
      const col = levels[l];
      if (!col) continue;
      const key = new Map(col.map((e) => [e.name, mean([...(children.get(e.name) ?? [])])]));
      col.sort((a, b) => (key.get(a.name) ?? 2) - (key.get(b.name) ?? 2));
      place();
    }
  }

  const columns: ErEntity[][] = levels.flatMap((col) => {
    if (!col?.length) return [];
    const out: ErEntity[][] = [];
    for (let i = 0; i < col.length; i += PER_COLUMN) out.push(col.slice(i, i + PER_COLUMN));
    return out;
  });
  const boxes = new Map<string, Box>();
  const heightOf = (e: ErEntity) => HEAD_H + rowsOf(e, mode).length * ROW_H + PAD_B;
  const tallest = Math.max(0, ...columns.map((col) => col.reduce((s, e) => s + heightOf(e), 0) + ROW_GAP * (col.length - 1)));
  columns.forEach((col, c) => {
    const total = col.reduce((s, e) => s + heightOf(e), 0) + ROW_GAP * (col.length - 1);
    let y = MARGIN + (tallest - total) / 2;
    for (const e of col) {
      const h = heightOf(e);
      boxes.set(e.name, { e, x: MARGIN + c * (BOX_W + COL_GAP), y, h, rows: rowsOf(e, mode) });
      y += h + ROW_GAP;
    }
  });
  return { boxes, width: MARGIN * 2 + columns.length * BOX_W + Math.max(0, columns.length - 1) * COL_GAP + 40, height: MARGIN * 2 + tallest };
}

function rowY(b: Box, column: string | undefined): number {
  const i = column ? b.rows.findIndex((r) => r.kind === "column" && r.col.name === column) : -1;
  return i < 0 ? b.y + HEAD_H / 2 : b.y + HEAD_H + i * ROW_H + ROW_H / 2;
}

interface Edge {
  r: ErRelationship;
  d: string;
  child: { x: number; y: number; dir: 1 | -1 };
  parent: { x: number; y: number; dir: 1 | -1 };
}

function edges(rels: ErRelationship[], boxes: Map<string, Box>): Edge[] {
  const out: Edge[] = [];
  for (const r of rels) {
    const c = boxes.get(r.from_table);
    const p = boxes.get(r.to_table);
    if (!c || !p) continue;
    const y1 = rowY(c, r.from_columns[0]);
    const y2 = rowY(p, r.to_columns[0] ?? p.e.columns.find((col) => col.pk)?.name);
    if (c === p || c.x === p.x) {
      // A table that references itself, or one in the same column: loop out of the right edge.
      const x = c.x + BOX_W;
      const bulge = c === p ? 46 : 70;
      out.push({ r, d: `M ${x} ${y1} C ${x + bulge} ${y1}, ${x + bulge} ${y2}, ${x} ${y2}`, child: { x, y: y1, dir: 1 }, parent: { x, y: y2, dir: 1 } });
    } else if (c.x > p.x) {
      const x1 = c.x;
      const x2 = p.x + BOX_W;
      const k = Math.max(40, (x1 - x2) / 2);
      out.push({ r, d: `M ${x1} ${y1} C ${x1 - k} ${y1}, ${x2 + k} ${y2}, ${x2} ${y2}`, child: { x: x1, y: y1, dir: -1 }, parent: { x: x2, y: y2, dir: 1 } });
    } else {
      const x1 = c.x + BOX_W;
      const x2 = p.x;
      const k = Math.max(40, (x2 - x1) / 2);
      out.push({ r, d: `M ${x1} ${y1} C ${x1 + k} ${y1}, ${x2 - k} ${y2}, ${x2} ${y2}`, child: { x: x1, y: y1, dir: 1 }, parent: { x: x2, y: y2, dir: -1 } });
    }
  }
  return out;
}

/** Crow's-foot ends: the referencing side is zero-or-many (zero-or-one for one-to-one), the referenced side one. */
function End({ x, y, dir, kind }: { x: number; y: number; dir: 1 | -1; kind: "many" | "zero-one" | "only-one" }) {
  const at = (n: number) => x + dir * n;
  if (kind === "many") {
    return (
      <g>
        <path d={`M ${at(13)} ${y} L ${x} ${y - 6} M ${at(13)} ${y} L ${x} ${y} M ${at(13)} ${y} L ${x} ${y + 6}`} />
        <circle cx={at(19)} cy={y} r={3.5} className="fill-card" />
      </g>
    );
  }
  if (kind === "zero-one") {
    return (
      <g>
        <path d={`M ${at(8)} ${y - 6} L ${at(8)} ${y + 6}`} />
        <circle cx={at(16)} cy={y} r={3.5} className="fill-card" />
      </g>
    );
  }
  return <path d={`M ${at(7)} ${y - 6} L ${at(7)} ${y + 6} M ${at(12)} ${y - 6} L ${at(12)} ${y + 6}`} />;
}

function clip(text: string, max: number): string {
  return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}

function describe(r: ErRelationship): string {
  const how = r.cardinality === "one_to_one" ? "one to one" : "many to one";
  return `${r.from_table}.${r.from_columns.join(", ")} → ${r.to_table}.${r.to_columns.join(", ") || "key"} · ${how}, ${r.required ? "required" : "optional"}`;
}

/** An ER diagram of a modelled layer, drawn from the design documents or a model plan. */
export function ErDiagramView({ diagram }: { diagram: ErDiagram }) {
  const [mode, setMode] = useState<Mode>("keys");
  const [view, setView] = useState<"diagram" | "list">("diagram");
  const [selected, setSelected] = useState<string | null>(null);
  const [hover, setHover] = useState<string | null>(null);
  const [scale, setScale] = useState(1);
  const [copied, setCopied] = useState(false);
  const frame = useRef<HTMLDivElement>(null);
  const { boxes, width, height } = useMemo(() => layout(diagram, mode), [diagram, mode]);
  const lines = useMemo(() => edges(diagram.relationships, boxes), [diagram.relationships, boxes]);
  const focus = hover ?? selected;
  const chosen = selected ? (diagram.entities.find((e) => e.name === selected) ?? null) : null;

  const fit = useCallback(() => {
    const room = frame.current?.clientWidth ?? width;
    setScale(Math.max(0.35, Math.min(1, (room - 8) / width)));
  }, [width]);
  useEffect(() => {
    fit();
  }, [fit, diagram.key]);
  useEffect(() => {
    setSelected(null);
  }, [diagram.key]);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(diagram.mermaid);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setCopied(false);
    }
  };
  const download = () => {
    const url = URL.createObjectURL(new Blob([diagram.mermaid], { type: "text/plain" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `${diagram.origin.replace(/[^A-Za-z0-9_-]+/g, "_") || "model"}.mmd`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const modelled = diagram.entities.filter((e) => e.kind !== "external");
  const external = diagram.entities.length - modelled.length;
  const linked = (a: string, b: string) => lines.some((l) => (l.r.from_table === a && l.r.to_table === b) || (l.r.to_table === a && l.r.from_table === b));
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <p className="mr-auto text-xs text-muted-foreground">
          {formatInt(modelled.length)} tables · {formatInt(diagram.relationships.length)} relationships
          {external ? ` · ${external} referenced but not in this model` : ""}
        </p>
        <Segmented value={view} onChange={setView} options={[["diagram", "Diagram", Network], ["list", "Relationships", List]]} />
        {view === "diagram" ? <Segmented value={mode} onChange={setMode} options={[["keys", "Keys only", KeyRound], ["all", "All columns", List]]} /> : null}
        {view === "diagram" ? (
          <div className="inline-flex items-center rounded-lg border border-border/70 bg-card">
            <button type="button" className="p-1.5 hover:bg-muted/60" onClick={() => setScale((s) => Math.max(0.35, s - 0.1))} aria-label="Zoom out">
              <Minus className="h-3.5 w-3.5" />
            </button>
            <span className="w-11 text-center text-[11px] tabular-nums text-muted-foreground">{Math.round(scale * 100)}%</span>
            <button type="button" className="p-1.5 hover:bg-muted/60" onClick={() => setScale((s) => Math.min(1.6, s + 0.1))} aria-label="Zoom in">
              <Plus className="h-3.5 w-3.5" />
            </button>
            <button type="button" className="border-l border-border/70 p-1.5 hover:bg-muted/60" onClick={fit} aria-label="Fit to width">
              <Maximize2 className="h-3.5 w-3.5" />
            </button>
          </div>
        ) : null}
        <Button size="sm" variant="outline" className="h-8" onClick={copy}>
          {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />} {copied ? "Copied" : "Copy Mermaid"}
        </Button>
        <Button size="sm" variant="ghost" className="h-8" onClick={download}>
          <Download className="h-3.5 w-3.5" /> .mmd
        </Button>
      </div>

      {diagram.problems.length ? (
        <ul className="rounded-lg border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-xs text-amber-800 dark:text-amber-200">
          {diagram.problems.map((p) => (
            <li key={p}>{p}</li>
          ))}
        </ul>
      ) : null}

      {view === "list" ? (
        <RelationshipList diagram={diagram} />
      ) : (
        <div className={cn("grid gap-3", chosen && "lg:grid-cols-[minmax(0,1fr)_20rem]")}>
          <div ref={frame} className="min-w-0 overflow-auto rounded-xl border border-border/70 bg-muted/20" style={{ maxHeight: "72vh" }}>
            <svg
              width={width * scale}
              height={height * scale}
              viewBox={`0 0 ${width} ${height}`}
              role="img"
              aria-label={`ER diagram: ${modelled.length} tables and ${diagram.relationships.length} relationships`}
              className="block"
              onClick={() => setSelected(null)}
            >
              <g fill="none">
                {lines.map((l, i) => {
                  const lit = focus !== null && (l.r.from_table === focus || l.r.to_table === focus);
                  return (
                    <g
                      key={i}
                      className={cn("transition-opacity", lit ? "stroke-primary" : "stroke-muted-foreground/60", focus !== null && !lit && "opacity-20")}
                      strokeWidth={lit ? 2.25 : 1.5}
                    >
                      <title>{describe(l.r)}</title>
                      <path d={l.d} strokeDasharray={l.r.required ? undefined : "5 4"} />
                      <End {...l.child} kind={l.r.cardinality === "one_to_one" ? "zero-one" : "many"} />
                      <End {...l.parent} kind={l.r.required ? "only-one" : "zero-one"} />
                    </g>
                  );
                })}
              </g>
              {[...boxes.values()].map((b) => (
                <EntityBox
                  key={b.e.name}
                  box={b}
                  active={focus === b.e.name}
                  faded={focus !== null && focus !== b.e.name && !linked(focus, b.e.name)}
                  onHover={setHover}
                  onSelect={(name) => setSelected((s) => (s === name ? null : name))}
                />
              ))}
            </svg>
          </div>
          {chosen ? <EntityPanel entity={chosen} diagram={diagram} onClose={() => setSelected(null)} /> : null}
        </div>
      )}
      <Legend />
    </div>
  );
}

function EntityBox({ box: b, active, faded, onHover, onSelect }: { box: Box; active: boolean; faded: boolean; onHover: (n: string | null) => void; onSelect: (n: string) => void }) {
  const k = KIND[b.e.kind];
  const sub = [k.label, b.e.concept, b.e.rows !== null ? `${formatInt(b.e.rows)} rows` : ""].filter(Boolean).join(" · ");
  return (
    <g
      transform={`translate(${b.x} ${b.y})`}
      className={cn("cursor-pointer outline-none transition-opacity", faded && "opacity-35")}
      tabIndex={0}
      role="button"
      aria-label={`${b.e.name}, ${k.label}, ${b.e.columns.length} columns`}
      aria-pressed={active}
      onMouseEnter={() => onHover(b.e.name)}
      onMouseLeave={() => onHover(null)}
      onFocus={() => onHover(b.e.name)}
      onBlur={() => onHover(null)}
      onClick={(ev) => {
        ev.stopPropagation();
        onSelect(b.e.name);
      }}
      onKeyDown={(ev) => {
        if (ev.key === "Enter" || ev.key === " ") {
          ev.preventDefault();
          onSelect(b.e.name);
        }
      }}
    >
      <title>{b.e.description || b.e.name}</title>
      <rect
        width={BOX_W}
        height={b.h}
        rx={10}
        className={cn("fill-card", active ? "stroke-primary" : k.stroke)}
        strokeWidth={active ? 2.5 : 1.25}
        strokeDasharray={b.e.kind === "external" ? "5 4" : undefined}
      />
      <path d={`M 0 10 Q 0 0 10 0 L ${BOX_W - 10} 0 Q ${BOX_W} 0 ${BOX_W} 10 L ${BOX_W} ${HEAD_H} L 0 ${HEAD_H} Z`} className={k.head} />
      <line x1={0} y1={HEAD_H} x2={BOX_W} y2={HEAD_H} className={k.stroke} strokeWidth={1} />
      <text x={12} y={20} className="fill-foreground text-[12.5px] font-semibold">
        {clip(b.e.name, 30)}
      </text>
      <text x={12} y={36} className={cn("fill-current text-[10.5px]", k.text)}>
        {clip(sub, 40)}
      </text>
      {b.rows.map((r, i) => {
        const y = HEAD_H + i * ROW_H + ROW_H / 2 + 4;
        if (r.kind === "more") {
          return (
            <text key="more" x={12} y={y} className="fill-muted-foreground text-[10.5px] italic">
              + {r.count} more column{r.count === 1 ? "" : "s"}
            </text>
          );
        }
        const c = r.col;
        return (
          <g key={c.name}>
            <title>{[c.description, c.fk ? `references ${c.fk}` : "", c.nullable ? "nullable" : "NOT NULL"].filter(Boolean).join(" · ")}</title>
            {c.pk || c.fk ? (
              <text x={12} y={y} className={cn("text-[9px] font-bold", c.pk ? "fill-amber-600 dark:fill-amber-300" : "fill-sky-600 dark:fill-sky-300")}>
                {c.pk && c.fk ? "PK FK" : c.pk ? "PK" : "FK"}
              </text>
            ) : null}
            <text x={c.pk && c.fk ? 46 : 34} y={y} className={cn("fill-foreground text-[11px]", c.pk && "font-semibold", !c.nullable && !c.pk && "font-medium")}>
              {clip(c.name, c.type ? 22 : 32)}
            </text>
            {c.type ? (
              <text x={BOX_W - 12} y={y} textAnchor="end" className="fill-muted-foreground font-mono text-[9.5px]">
                {clip(c.type.toLowerCase(), 14)}
              </text>
            ) : null}
          </g>
        );
      })}
    </g>
  );
}

function EntityPanel({ entity: e, diagram, onClose }: { entity: ErEntity; diagram: ErDiagram; onClose: () => void }) {
  const out = diagram.relationships.filter((r) => r.from_table === e.name);
  const into = diagram.relationships.filter((r) => r.to_table === e.name);
  return (
    <aside className="min-w-0 space-y-3 rounded-xl border border-border/70 bg-card p-3 text-[12px]" aria-label={`${e.name} details`}>
      <div className="flex items-start gap-2">
        <div className="min-w-0 flex-1">
          <h4 className="break-all font-mono text-[13px] font-semibold">{e.schema_name ? `${e.schema_name}.${e.name}` : e.name}</h4>
          <p className={cn("text-[11px]", KIND[e.kind].text)}>{[KIND[e.kind].label, e.concept].filter(Boolean).join(" · ")}</p>
        </div>
        <button type="button" onClick={onClose} className="rounded-md p-1 text-muted-foreground hover:bg-muted/60" aria-label="Close details">
          <X className="h-3.5 w-3.5" />
        </button>
      </div>
      {e.description ? <p className="text-muted-foreground">{e.description}</p> : null}
      {e.grain ? (
        <p>
          <span className="font-medium">Grain:</span> {e.grain}
        </p>
      ) : null}
      {e.rows !== null ? (
        <p>
          <span className="font-medium">Dry run:</span> {formatInt(e.rows)} rows
        </p>
      ) : null}
      {e.findings.length ? (
        <ul className="space-y-0.5 rounded-lg bg-amber-500/10 px-2 py-1.5 text-[11px] text-amber-800 dark:text-amber-200">
          {e.findings.map((f) => (
            <li key={f}>{f}</li>
          ))}
        </ul>
      ) : null}
      {out.length || into.length ? (
        <div className="space-y-1">
          <div className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">Relationships</div>
          {out.map((r, i) => (
            <p key={`o${i}`} className="flex items-start gap-1.5">
              <Link2 className="mt-0.5 h-3 w-3 shrink-0 text-sky-500" aria-hidden="true" />
              <span>
                <span className="font-mono">{r.from_columns.join(", ")}</span> references <span className="font-mono">{r.to_table}</span>
                <span className="text-muted-foreground"> · {r.required ? "required" : "optional"}</span>
              </span>
            </p>
          ))}
          {into.map((r, i) => (
            <p key={`i${i}`} className="flex items-start gap-1.5">
              <Link2 className="mt-0.5 h-3 w-3 shrink-0 text-violet-500" aria-hidden="true" />
              <span>
                <span className="font-mono">{r.from_table}</span> refers to it by <span className="font-mono">{r.from_columns.join(", ")}</span>
              </span>
            </p>
          ))}
        </div>
      ) : null}
      <div>
        <div className="mb-1 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">Columns · {e.columns.length}</div>
        <ul className="max-h-80 space-y-1 overflow-y-auto pr-1">
          {e.columns.map((c) => (
            <li key={c.name} className="rounded-md px-1.5 py-1 hover:bg-muted/50">
              <div className="flex items-baseline gap-1.5">
                {c.pk ? <span className="text-[9px] font-bold text-amber-600 dark:text-amber-300">PK</span> : null}
                {c.fk ? <span className="text-[9px] font-bold text-sky-600 dark:text-sky-300">FK</span> : null}
                <span className="min-w-0 break-all font-mono text-[11px]">{c.name}</span>
                <span className="ml-auto shrink-0 font-mono text-[10px] text-muted-foreground">{c.type.toLowerCase()}</span>
              </div>
              {c.description || c.fk || !c.nullable ? (
                <p className="text-[11px] text-muted-foreground">{[c.description, c.fk ? `→ ${c.fk}` : "", !c.nullable ? "NOT NULL" : ""].filter(Boolean).join(" · ")}</p>
              ) : null}
            </li>
          ))}
        </ul>
      </div>
    </aside>
  );
}

function RelationshipList({ diagram }: { diagram: ErDiagram }) {
  if (!diagram.relationships.length) return <p className="rounded-xl border border-dashed p-4 text-sm text-muted-foreground">No foreign keys are declared between these tables.</p>;
  return (
    <div className="overflow-x-auto rounded-xl border border-border/70">
      <table className="w-full text-left text-[12px]">
        <thead className="bg-muted/40 text-[10px] uppercase tracking-wide text-muted-foreground">
          <tr>
            <th className="px-3 py-2 font-medium">Table</th>
            <th className="px-3 py-2 font-medium">Column</th>
            <th className="px-3 py-2 font-medium">References</th>
            <th className="px-3 py-2 font-medium">Cardinality</th>
            <th className="px-3 py-2 font-medium">Required</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border/60">
          {diagram.relationships.map((r, i) => (
            <tr key={i}>
              <td className="px-3 py-1.5 font-mono">{r.from_table}</td>
              <td className="px-3 py-1.5 font-mono">{r.from_columns.join(", ")}</td>
              <td className="px-3 py-1.5 font-mono">
                {r.to_table}.{r.to_columns.join(", ")}
              </td>
              <td className="px-3 py-1.5">{r.cardinality === "one_to_one" ? "one to one" : "many to one"}</td>
              <td className="px-3 py-1.5">{r.required ? "yes" : "no, nullable"}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Legend() {
  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-muted-foreground">
      {(["dimension", "fact", "bridge", "reference", "external"] as ErEntityKind[]).map((k) => (
        <span key={k} className="inline-flex items-center gap-1.5">
          <svg width="14" height="10" aria-hidden="true">
            <rect x="0.5" y="0.5" width="13" height="9" rx="2" className={cn(KIND[k].head, KIND[k].stroke)} strokeDasharray={k === "external" ? "2 2" : undefined} />
          </svg>
          {KIND[k].label}
        </span>
      ))}
      <span className="inline-flex items-center gap-1.5">
        <svg width="34" height="12" className="stroke-muted-foreground" fill="none" strokeWidth="1.5" aria-hidden="true">
          <path d="M 2 6 L 32 6 M 12 6 L 2 1 M 12 6 L 2 11 M 26 1 L 26 11 M 30 1 L 30 11" />
        </svg>
        many to one, required
      </span>
      <span className="inline-flex items-center gap-1.5">
        <svg width="34" height="12" className="stroke-muted-foreground" fill="none" strokeWidth="1.5" aria-hidden="true">
          <path d="M 2 6 L 32 6" strokeDasharray="4 3" />
        </svg>
        optional (nullable key)
      </span>
      <span>Click a table for its columns and descriptions.</span>
    </div>
  );
}

function Segmented<T extends string>({ value, onChange, options }: { value: T; onChange: (v: T) => void; options: [T, string, typeof Network][] }) {
  return (
    <div className="inline-flex rounded-lg border border-border/70 bg-card p-0.5" role="group">
      {options.map(([key, label, Icon]) => (
        <button
          key={key}
          type="button"
          aria-pressed={value === key}
          onClick={() => onChange(key)}
          className={cn("inline-flex items-center gap-1 rounded-md px-2 py-1 text-[11.5px]", value === key ? "bg-primary/15 font-medium text-primary" : "text-muted-foreground hover:text-foreground")}
        >
          <Icon className="h-3.5 w-3.5" /> {label}
        </button>
      ))}
    </div>
  );
}
