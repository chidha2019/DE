import { FolderGit2, Loader2, RefreshCw } from "lucide-react";
import { useEffect, useMemo, useState, type FormEvent } from "react";

import type { RepoCrawl, RepoGraphRepos } from "@/api/repo-graph";
import { shortSha } from "@/components/repo-graph/kind-style";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { isCrawlBusy, useStartCrawl } from "@/hooks/repo-graph";
import { describeError } from "@/lib/api-client";
import { formatDuration, formatInt, formatRelative } from "@/lib/format";
import { cn } from "@/lib/utils";

function normalizeRepo(text: string): string {
  const trimmed = text.trim().replace(/^https:\/\/github\.com\//, "").replace(/\.git$/, "").replace(/\/+$/, "");
  return trimmed.split("@")[0] ?? trimmed;
}

export function CrawlPanel({
  repos,
  crawls,
  initialRepo,
  onStarted,
}: {
  repos: RepoGraphRepos | undefined;
  crawls: RepoCrawl[] | undefined;
  initialRepo: string | null;
  onStarted: (repo: string) => void;
}) {
  const [repo, setRepo] = useState(initialRepo ?? "");
  const [ref, setRef] = useState("");
  const [indexText, setIndexText] = useState(false);
  const start = useStartCrawl();

  useEffect(() => {
    if (!repo && initialRepo) setRepo(initialRepo);
  }, [initialRepo, repo]);

  const target = normalizeRepo(repo);
  const configured = useMemo(() => new Set((repos?.configured ?? []).map((r) => r.toLowerCase())), [repos]);
  const canIndex = configured.has(target.toLowerCase());
  const suggestions = useMemo(() => {
    const names = new Set<string>([...(repos?.configured ?? []), ...(repos?.crawled ?? []).map((r) => r.repo)]);
    return [...names].sort();
  }, [repos]);
  const latest = useMemo(() => crawls?.find((c) => c.repo.toLowerCase() === target.toLowerCase()) ?? null, [crawls, target]);
  const busy = isCrawlBusy(latest);

  useEffect(() => {
    if (!canIndex && indexText) setIndexText(false);
  }, [canIndex, indexText]);

  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!target.includes("/")) return;
    start.mutate({ repo: target, ref: ref.trim() || null, index_text: indexText && canIndex }, { onSuccess: (crawl) => onStarted(crawl.repo) });
  };

  return (
    <section className="surface rounded-xl border p-4">
      <form onSubmit={submit} className="flex flex-col gap-3 lg:flex-row lg:items-end">
        <div className="min-w-0 flex-1 space-y-1">
          <Label htmlFor="repo-input" className="text-xs">
            GitHub repository
          </Label>
          <div className="relative">
            <FolderGit2 className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              id="repo-input"
              value={repo}
              onChange={(e) => setRepo(e.target.value)}
              placeholder="owner/name or https://github.com/owner/name"
              className="pl-8 font-mono text-sm"
              autoComplete="off"
              spellCheck={false}
            />
          </div>
        </div>
        <div className="space-y-1 lg:w-40">
          <Label htmlFor="ref-input" className="text-xs">
            Branch or tag
          </Label>
          <Input id="ref-input" value={ref} onChange={(e) => setRef(e.target.value)} placeholder="default branch" className="font-mono text-sm" />
        </div>
        <Button type="submit" disabled={!target.includes("/") || start.isPending || busy} className="gap-2 lg:w-36">
          {start.isPending || busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
          {busy ? "Crawling" : "Crawl repo"}
        </Button>
      </form>
      <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2">
        <label className={cn("flex items-center gap-2 text-xs", !canIndex && "opacity-60")} title={canIndex ? undefined : "Only repositories listed in ECH_GITHUB_REPOS can be indexed as text"}>
          <Switch checked={indexText} onCheckedChange={setIndexText} disabled={!canIndex} aria-label="Also index file text" />
          Also index file text for search and Genie
        </label>
        {suggestions.length ? (
          <div className="flex min-w-0 flex-wrap items-center gap-1.5">
            <span className="text-[11px] text-muted-foreground">Repos:</span>
            {suggestions.map((name) => (
              <button
                key={name}
                type="button"
                onClick={() => setRepo(name)}
                className={cn(
                  "max-w-full truncate rounded-full border px-2 py-0.5 font-mono text-[11px] transition-colors",
                  name.toLowerCase() === target.toLowerCase() ? "border-primary bg-primary/10 text-primary" : "border-border/70 hover:border-primary/50",
                )}
              >
                {name}
              </button>
            ))}
          </div>
        ) : null}
      </div>
      {start.isError ? <p className="mt-3 text-xs text-destructive">{describeError(start.error)}</p> : null}
      {latest ? <CrawlStatusLine crawl={latest} /> : null}
    </section>
  );
}

const PHASES = ["reading repository", "reading files", "extracting", "writing graph", "indexing text"];

function seconds(crawl: RepoCrawl): number | null {
  if (!crawl.started_at) return null;
  const end = crawl.finished_at ? Date.parse(crawl.finished_at) : Date.now();
  return Math.max(0, (end - Date.parse(crawl.started_at)) / 1000);
}

export function CrawlStatusLine({ crawl }: { crawl: RepoCrawl }) {
  const busy = isCrawlBusy(crawl);
  const stats = crawl.stats;
  if (busy) {
    const step = Math.max(0, PHASES.indexOf(crawl.phase));
    const pct = crawl.files_total ? Math.round((crawl.files_read / crawl.files_total) * 100) : 0;
    return (
      <div className="mt-4 space-y-1.5 rounded-lg border border-primary/30 bg-primary/5 p-3">
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
          <span className="font-medium">
            Step {step + 1} of {crawl.index_text ? 5 : 4}: {crawl.phase}
          </span>
          <span className="text-muted-foreground">
            {crawl.files_total ? `${formatInt(crawl.files_read)} of ${formatInt(crawl.files_total)} files` : "listing files"}
          </span>
        </div>
        <Progress value={crawl.phase === "reading files" ? pct : Math.min(100, ((step + 1) / 4) * 100)} className="h-1.5" />
      </div>
    );
  }
  if (crawl.status === "failed") {
    return (
      <p className="mt-4 rounded-lg border border-destructive/40 bg-destructive/5 p-3 text-xs text-destructive">
        Last crawl failed {formatRelative(crawl.finished_at ?? crawl.created_at)}: {crawl.error ?? "unknown error"}
      </p>
    );
  }
  const lineage = stats.lineage;
  return (
    <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1 rounded-lg border border-success/30 bg-success/5 p-3 text-xs">
      <span className="font-medium text-success">Crawled {formatRelative(crawl.finished_at)}</span>
      <span>
        {formatInt(crawl.files_read)} files · {formatInt(stats.nodes)} nodes · {formatInt(stats.edges)} edges
      </span>
      {lineage && lineage.model_columns ? (
        <span>
          {formatInt(lineage.traced)} of {formatInt(lineage.model_columns)} model columns traced
          {lineage.constant ? `, ${formatInt(lineage.constant)} constants` : ""}
        </span>
      ) : null}
      {crawl.sha ? <span className="font-mono text-muted-foreground">{crawl.ref ?? ""} @ {shortSha(crawl.sha)}</span> : null}
      <span className="text-muted-foreground">{formatDuration(seconds(crawl))}</span>
      {crawl.warnings.length ? <span className="text-warning">{crawl.warnings.length} warnings</span> : null}
      {crawl.index_run_id ? <span className="text-muted-foreground">text indexing started</span> : null}
    </div>
  );
}
