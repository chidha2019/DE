import { useState } from "react";

import type { RepoNodeKind } from "@/api/repo-graph";
import { KIND_META } from "@/components/repo-graph/kind-style";
import { RepoNetwork } from "@/components/repo-graph/repo-network";
import { useRepoGraph } from "@/hooks/repo-graph";
import { cn } from "@/lib/utils";

const DEFAULT_KINDS: RepoNodeKind[] = [
  "pipeline", "source_system", "source", "table", "stage", "file_format", "storage_integration", "external_volume", "s3_location", "alert", "ci_stage",
];
const OPTIONAL_KINDS: RepoNodeKind[] = ["file", "symbol", "check", "column"];

export function GraphView({ repo, selected, onSelect, counts }: { repo: string; selected: string | null; onSelect: (key: string) => void; counts: Record<string, number> }) {
  const [kinds, setKinds] = useState<RepoNodeKind[]>(DEFAULT_KINDS);
  const graph = useRepoGraph(repo, "all", kinds);
  const toggle = (kind: RepoNodeKind) => setKinds((prev) => (prev.includes(kind) ? prev.filter((k) => k !== kind) : [...prev, kind]));

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-1.5">
        {[...DEFAULT_KINDS, ...OPTIONAL_KINDS].map((kind) => {
          const meta = KIND_META[kind];
          const Icon = meta.icon;
          const on = kinds.includes(kind);
          const n = counts[kind] ?? 0;
          if (!n) return null;
          return (
            <button
              key={kind}
              type="button"
              onClick={() => toggle(kind)}
              className={cn(
                "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] transition-colors",
                on ? "border-primary/50 bg-primary/10" : "border-border/70 text-muted-foreground hover:border-primary/40",
              )}
            >
              <Icon className="h-3 w-3" style={{ color: on ? meta.color : undefined }} />
              {meta.plural}
              <span className="font-mono text-muted-foreground">{n}</span>
            </button>
          );
        })}
      </div>
      <RepoNetwork data={graph.data} loading={graph.isLoading} selectedId={selected} onSelect={onSelect} />
      {graph.data?.truncated ? <p className="text-xs text-warning">Only the first 2,500 nodes are drawn; turn some kinds off.</p> : null}
    </div>
  );
}
