import { ExternalLink, X } from "lucide-react";
import { useEffect, useMemo, useRef, type ReactNode } from "react";

import { nodeKey, type RepoColumn, type RepoNodeDetail, type RepoNodeLink } from "@/api/repo-graph";
import { kindMeta, methodLabel, nodeTint } from "@/components/repo-graph/kind-style";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useRepoNode } from "@/hooks/repo-graph";
import { cn } from "@/lib/utils";

const OUT_LABEL: Record<string, string> = {
  LOADED_FROM: "Loaded from", DERIVED_FROM: "Derived from", DEFINED_IN: "Defined in", STORED_ON: "Stored on", USES: "Uses",
  READS_FROM: "Reads from", ALLOWS: "Allows", WRITES_TO: "Writes to", LANDS_IN: "Lands in", FROM_SYSTEM: "From system",
  CHECKS: "Checks", IMPORTS: "Imports", READS: "Reads", TESTS: "Tests", DECLARES: "Declares", NEXT: "Next stage",
  MONITORS: "Monitors", DOCUMENTS: "Documents", INGESTS: "Ingests", BUILDS: "Builds", CONTAINS: "Contains", DEFINES: "Defines",
};
const IN_LABEL: Record<string, string> = {
  LOADED_FROM: "Loads", DERIVED_FROM: "Feeds", DEFINED_IN: "Defines", STORED_ON: "Stores", USES: "Used by", READS_FROM: "Read by",
  ALLOWS: "Allowed by", WRITES_TO: "Written by", LANDS_IN: "Landing for", FROM_SYSTEM: "Provides", CHECKS: "Checked by",
  IMPORTS: "Imported by", READS: "Read by", TESTS: "Tested by", DECLARES: "Declared in", NEXT: "After", MONITORS: "Monitored by",
  DOCUMENTS: "Documented in", INGESTS: "Ingested by", BUILDS: "Built by", CONTAINS: "In repository", DEFINES: "Defined by",
};
const HIDDEN_PROPS = new Set(["kind", "name", "display", "node_key", "repo", "url", "headers", "crawl_id"]);
const PROP_ORDER = [
  "layer", "table_type", "catalog", "managed", "external_volume", "key", "grain", "owner", "load_mode", "column_count", "checks",
  "source_path", "source_system", "format", "mode", "schedule", "layers", "url", "stage_type", "provider", "base_url",
  "allowed_locations", "role_arn", "encryption", "format_type", "skip_header", "path", "role", "language", "lines", "title",
  "summary", "rule", "column", "subject", "expr", "severity", "runbook", "symbol_kind", "file", "line", "type", "source_header",
  "derivation", "definition", "contract",
];
const GROUP_LIMIT = 24;

function formatValue(value: unknown): string {
  if (Array.isArray(value)) return value.join(", ");
  if (typeof value === "boolean") return value ? "yes" : "no";
  return String(value);
}

function propEntries(node: Record<string, unknown>): [string, unknown][] {
  const entries = Object.entries(node).filter(([k, v]) => !HIDDEN_PROPS.has(k) && v !== null && v !== "" && !(Array.isArray(v) && !v.length));
  const rank = (k: string) => {
    const i = PROP_ORDER.indexOf(k);
    return i === -1 ? 999 : i;
  };
  return entries.sort(([a], [b]) => rank(a) - rank(b) || a.localeCompare(b));
}

function githubUrl(repo: string, ref: string | null | undefined, path: string): string {
  return `https://github.com/${repo}/blob/${ref || "HEAD"}/${path}`;
}

function short(name: string): string {
  const parts = name.split(".");
  return parts.length > 2 ? parts.slice(-2).join(".") : name;
}

export function NodePanel({
  nodeKeyValue,
  repoRef,
  onSelect,
  onClose,
  className,
}: {
  nodeKeyValue: string | null;
  repoRef: string | null | undefined;
  onSelect: (key: string) => void;
  onClose: () => void;
  className?: string;
}) {
  const query = useRepoNode(nodeKeyValue);
  const ref = useRef<HTMLElement | null>(null);
  // Below the two-column layout the panel sits under the tab content: bring it into view on selection.
  useEffect(() => {
    if (!nodeKeyValue || !ref.current || !window.matchMedia("(max-width: 1279px)").matches) return;
    ref.current.scrollIntoView({ behavior: "smooth", block: "start" });
  }, [nodeKeyValue]);
  if (!nodeKeyValue) return null;
  return (
    <aside ref={ref} className={cn("surface flex min-h-0 scroll-mt-4 flex-col overflow-hidden rounded-xl border", className)}>
      {query.isLoading ? (
        <div className="space-y-3 p-4">
          <Skeleton className="h-6 w-2/3" />
          <Skeleton className="h-24 w-full" />
          <Skeleton className="h-40 w-full" />
        </div>
      ) : query.data ? (
        <Detail detail={query.data} repoRef={repoRef} onSelect={onSelect} onClose={onClose} />
      ) : (
        <div className="flex items-start justify-between gap-2 p-4 text-sm text-muted-foreground">
          This node is not in the graph any more; crawl the repository again.
          <Button size="icon-sm" variant="ghost" onClick={onClose} aria-label="Close">
            <X className="h-4 w-4" />
          </Button>
        </div>
      )}
    </aside>
  );
}

function Detail({ detail, repoRef, onSelect, onClose }: { detail: RepoNodeDetail; repoRef: string | null | undefined; onSelect: (key: string) => void; onClose: () => void }) {
  const node = detail.node;
  const repo = node.repo;
  const meta = kindMeta(node.kind);
  const Icon = meta.icon;
  const tint = nodeTint(node.kind, node.layer);
  const files = detail.links.filter((l) => l.type === "DEFINED_IN" && l.outgoing && l.kind === "file");
  const selfUrl = node.kind === "file" ? String(node.url ?? "") : null;
  const groups = useMemo(() => {
    const map = new Map<string, RepoNodeLink[]>();
    for (const link of detail.links) {
      if (link.type === "HAS_COLUMN") continue;
      if (link.type === "DEFINED_IN" && link.outgoing) continue;
      const label = (link.outgoing ? OUT_LABEL : IN_LABEL)[link.type] ?? link.type;
      map.set(label, [...(map.get(label) ?? []), link]);
    }
    return [...map.entries()].sort((a, b) => a[1].length - b[1].length);
  }, [detail.links]);

  return (
    <>
      <div className="flex items-start gap-3 border-b border-border/60 p-4">
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg" style={{ backgroundColor: `${tint}22`, color: tint }}>
          <Icon className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">{meta.label}</div>
          <div className="break-all font-mono text-sm font-medium">{node.display ?? node.name}</div>
          {node.display && node.display !== node.name ? <div className="break-all font-mono text-[11px] text-muted-foreground">{node.name}</div> : null}
          <div className="mt-2 flex flex-wrap gap-1.5">
            {selfUrl ? (
              <Button size="sm" variant="outline" className="h-7 gap-1 px-2 text-xs" asChild>
                <a href={selfUrl} target="_blank" rel="noreferrer">
                  GitHub <ExternalLink className="h-3 w-3" />
                </a>
              </Button>
            ) : null}
            {files.slice(0, 3).map((f) => (
              <Button key={f.key} size="sm" variant="outline" className="h-7 max-w-full gap-1 px-2 font-mono text-[11px]" asChild>
                <a href={githubUrl(repo, repoRef, String(f.name))} target="_blank" rel="noreferrer" title={`Defined in ${f.name}${f.role ? ` (${f.role})` : ""}`}>
                  <span className="truncate">{f.name}</span> <ExternalLink className="h-3 w-3 shrink-0" />
                </a>
              </Button>
            ))}
          </div>
        </div>
        <Button size="icon-sm" variant="ghost" onClick={onClose} aria-label="Close details">
          <X className="h-4 w-4" />
        </Button>
      </div>
      <div className="min-h-0 flex-1 space-y-5 overflow-y-auto p-4">
        <dl className="grid grid-cols-[minmax(0,8rem)_minmax(0,1fr)] gap-x-3 gap-y-1.5 text-xs">
          {propEntries(node).map(([k, v]) => (
            <div key={k} className="contents">
              <dt className="truncate text-muted-foreground">{k.replace(/_/g, " ")}</dt>
              <dd className="break-words font-mono text-[11px]">{formatValue(v)}</dd>
            </div>
          ))}
        </dl>
        {detail.upstream.length || detail.downstream.length ? (
          <div className="grid gap-3 sm:grid-cols-2">
            <TableChips title="All upstream" names={detail.upstream} repo={repo} onSelect={onSelect} />
            <TableChips title="All downstream" names={detail.downstream} repo={repo} onSelect={onSelect} />
          </div>
        ) : null}
        {node.kind === "table" && detail.columns.length ? <ColumnList columns={detail.columns} repo={repo} onSelect={onSelect} /> : null}
        {detail.trace.length ? (
          <Section title="Traced to">
            <ul className="space-y-1.5">
              {detail.trace.map((t, i) => (
                <li key={i} className="font-mono text-[11px] leading-relaxed">
                  {t.path.map(short).join("  ·  ")}
                  {t.header ? <span className="text-muted-foreground"> · CSV header {t.header}</span> : null}
                </li>
              ))}
            </ul>
          </Section>
        ) : null}
        {groups.map(([label, links]) => (
          <Section key={label} title={`${label} (${links.length})`}>
            <div className="flex flex-wrap gap-1.5">
              {links.slice(0, GROUP_LIMIT).map((l) => (
                <LinkChip key={`${l.type}-${l.key}-${l.outgoing}`} link={l} onSelect={onSelect} />
              ))}
              {links.length > GROUP_LIMIT ? <span className="self-center text-[11px] text-muted-foreground">+{links.length - GROUP_LIMIT} more</span> : null}
            </div>
          </Section>
        ))}
      </div>
    </>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section>
      <h3 className="mb-1.5 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">{title}</h3>
      {children}
    </section>
  );
}

function TableChips({ title, names, repo, onSelect }: { title: string; names: string[]; repo: string; onSelect: (key: string) => void }) {
  return (
    <Section title={`${title} (${names.length})`}>
      {names.length ? (
        <div className="flex flex-wrap gap-1">
          {names.slice(0, 40).map((name) => (
            <button
              key={name}
              type="button"
              onClick={() => onSelect(nodeKey(repo, "table", name))}
              className="rounded border border-border/70 bg-background/50 px-1.5 py-0.5 font-mono text-[10px] hover:border-primary/60"
            >
              {name}
            </button>
          ))}
        </div>
      ) : (
        <p className="text-[11px] text-muted-foreground">none</p>
      )}
    </Section>
  );
}

function LinkChip({ link, onSelect }: { link: RepoNodeLink; onSelect: (key: string) => void }) {
  const meta = kindMeta(link.kind);
  const Icon = meta.icon;
  const how = methodLabel(link.methods);
  return (
    <button
      type="button"
      onClick={() => onSelect(link.key)}
      title={`${meta.label}${how ? ` · ${how}` : ""}${link.evidence.length ? ` · evidence: ${link.evidence.join(", ")}` : ""}`}
      className="inline-flex max-w-full items-center gap-1 rounded-md border border-border/70 bg-background/50 px-1.5 py-0.5 text-[11px] hover:border-primary/60"
    >
      <Icon className="h-3 w-3 shrink-0" style={{ color: meta.color }} />
      <span className="truncate font-mono">{link.display ?? link.name}</span>
      {link.methods.includes("inferred") && !link.methods.includes("parsed") && !link.methods.includes("declared") ? (
        <Badge variant="muted" className="h-4 px-1 text-[9px]">
          inferred
        </Badge>
      ) : null}
    </button>
  );
}

function ColumnList({ columns, repo, onSelect }: { columns: RepoColumn[]; repo: string; onSelect: (key: string) => void }) {
  return (
    <Section title={`Columns (${columns.length})`}>
      <div className="divide-y divide-border/50 rounded-lg border border-border/60">
        {columns.map((c) => {
          const origins = c.origins.filter((o) => o.name !== c.name);
          return (
            <div key={c.name} className="px-2.5 py-1.5 text-[11px]">
              <div className="flex items-center gap-2">
                <button type="button" onClick={() => onSelect(nodeKey(repo, "column", c.name))} className="truncate font-mono font-medium hover:underline">
                  {c.column}
                </button>
                {c.is_key ? (
                  <Badge variant="info" className="h-4 px-1 text-[9px]">
                    key
                  </Badge>
                ) : null}
                <span className="ml-auto shrink-0 font-mono text-[10px] text-muted-foreground">{c.type ?? ""}</span>
              </div>
              <div className="mt-0.5 text-[10px] text-muted-foreground">
                {c.derivation === "constant" ? (
                  "constant value"
                ) : origins.length ? (
                  <>
                    from{" "}
                    {origins.slice(0, 4).map((o, i) => (
                      <span key={o.name}>
                        {i > 0 ? ", " : ""}
                        <span className="font-mono">{short(o.name)}</span>
                        {o.header ? ` (CSV ${o.header})` : ""}
                      </span>
                    ))}
                    {origins.length > 4 ? ` and ${origins.length - 4} more` : ""}
                  </>
                ) : c.source_header ? (
                  <>
                    CSV header <span className="font-mono">{c.source_header}</span>
                    {c.required ? " · required" : ""}
                  </>
                ) : c.inferred ? (
                  "read by downstream SQL; not in the contract (added by the deploy code)"
                ) : (
                  c.description || "no lineage recorded"
                )}
                {c.used_by.length ? ` · used by ${c.used_by.length}` : ""}
              </div>
            </div>
          );
        })}
      </div>
    </Section>
  );
}
