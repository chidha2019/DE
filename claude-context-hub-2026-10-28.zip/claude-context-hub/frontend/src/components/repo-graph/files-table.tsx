import { ExternalLink, Search } from "lucide-react";
import { useMemo, useState } from "react";

import { EmptyRow } from "@/components/personas/persona-shell";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useRepoGraph } from "@/hooks/repo-graph";
import { formatInt } from "@/lib/format";
import { cn } from "@/lib/utils";

export function FilesTable({ repo, selected, onSelect }: { repo: string; selected: string | null; onSelect: (key: string) => void }) {
  const graph = useRepoGraph(repo, "all", ["file"]);
  const [filter, setFilter] = useState("");
  const [role, setRole] = useState<string | null>(null);
  const files = useMemo(() => (graph.data?.nodes ?? []).slice().sort((a, b) => String(a.properties.path).localeCompare(String(b.properties.path))), [graph.data]);
  const roles = useMemo(() => {
    const counts = new Map<string, number>();
    for (const f of files) counts.set(String(f.properties.role), (counts.get(String(f.properties.role)) ?? 0) + 1);
    return [...counts.entries()].sort((a, b) => b[1] - a[1]);
  }, [files]);
  const shown = files.filter(
    (f) => (!role || f.properties.role === role) && (!filter.trim() || String(f.properties.path).toLowerCase().includes(filter.trim().toLowerCase())),
  );
  if (graph.isLoading) return <Skeleton className="h-64 w-full" />;
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative w-full sm:w-72">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
          <Input value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="Filter by path" className="h-8 pl-8 text-xs" />
        </div>
        {roles.map(([name, n]) => (
          <button
            key={name}
            type="button"
            onClick={() => setRole(role === name ? null : name)}
            className={cn("rounded-full border px-2 py-0.5 text-[11px]", role === name ? "border-primary bg-primary/10 text-primary" : "border-border/70 text-muted-foreground")}
          >
            {name} <span className="font-mono">{n}</span>
          </button>
        ))}
      </div>
      <div className="surface overflow-hidden rounded-xl border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Path</TableHead>
              <TableHead>Role</TableHead>
              <TableHead className="text-right">Lines</TableHead>
              <TableHead>What it holds</TableHead>
              <TableHead />
            </TableRow>
          </TableHeader>
          <TableBody>
            {shown.map((f) => (
              <TableRow key={f.id} className={cn("cursor-pointer", selected === f.id && "bg-primary/5")} onClick={() => onSelect(f.id)}>
                <TableCell className="font-mono text-xs">{String(f.properties.path)}</TableCell>
                <TableCell>
                  <Badge variant="muted" className="text-[10px]">
                    {String(f.properties.role)}
                  </Badge>
                </TableCell>
                <TableCell className="text-right font-mono text-xs">{formatInt(Number(f.properties.lines ?? 0))}</TableCell>
                <TableCell className="max-w-[26rem] truncate text-xs text-muted-foreground">
                  {String(f.properties.title ?? f.properties.summary ?? (f.properties.checks ? `${f.properties.checks} quality checks` : ""))}
                </TableCell>
                <TableCell className="text-right">
                  <a
                    href={String(f.properties.url)}
                    target="_blank"
                    rel="noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="inline-flex text-muted-foreground hover:text-foreground"
                    aria-label={`Open ${String(f.properties.path)} on GitHub`}
                  >
                    <ExternalLink className="h-3.5 w-3.5" />
                  </a>
                </TableCell>
              </TableRow>
            ))}
            {shown.length === 0 ? <EmptyRow colSpan={5}>No files match.</EmptyRow> : null}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
