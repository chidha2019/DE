/**
 * A crawled repository drawn as constellations in data-flow order: source systems and CSV sources on the
 * left, the landing stage, then Bronze, Silver, Gold and Serving tables, with orchestration (pipeline,
 * alerts, CI) above and Iceberg storage below. Lineage edges carry particles in the direction data moves;
 * structural edges (the pipeline builds a table, a table is stored on a volume) stay faint until a node
 * is focused by hovering or selecting it.
 */

import { Activity, CircleDashed, Maximize2, Minus, Plus, type LucideIcon } from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import ForceGraph2D, { type ForceGraphMethods, type LinkObject, type NodeObject } from "react-force-graph-2d";

import type { GraphNode, GraphPayload } from "@/api/types";
import { KIND_META, LAYER_COLOR, kindMeta, tableTypeLabel } from "@/components/repo-graph/kind-style";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { useTheme } from "@/providers/theme-provider";

type Shape = "circle" | "table" | "diamond" | "hexagon" | "triangle" | "square";

interface NodeData {
  id: string;
  label: string;
  kind: string;
  layer: string | null;
  color: string;
  r: number;
  shape: Shape;
  group: string;
  priority: number;
  degree: number;
  ax: number;
  ay: number;
  original: GraphNode;
}

interface LinkData {
  type: string;
  flow: boolean;
  color: string;
}

type RNode = NodeObject<NodeData>;
type RLink = LinkObject<NodeData, LinkData>;

interface Group {
  label: string;
  color: string;
  anchor: [number, number];
}

const tint = (layer: string) => LAYER_COLOR[layer] ?? "#94a3b8";
const OTHER: Group = {
  label: "Other tables",
  color: "#94a3b8",
  anchor: [3.4, -1.5],
};

const GROUPS: Record<string, Group> = {
  systems: {
    label: "Source systems",
    color: KIND_META.source_system.color,
    anchor: [-3.75, 0],
  },
  sources: {
    label: "CSV sources",
    color: KIND_META.source.color,
    anchor: [-2.6, 0],
  },
  landing: {
    label: "Landing",
    color: KIND_META.stage.color,
    anchor: [-1.4, 0],
  },
  bronze: { label: "Bronze", color: tint("bronze"), anchor: [-0.15, 0] },
  silver: { label: "Silver", color: tint("silver"), anchor: [1.1, 0] },
  gold: { label: "Gold", color: tint("gold"), anchor: [2.25, 0] },
  serving: { label: "Serving", color: tint("serving"), anchor: [3.4, 0] },
  control: { label: "Control", color: tint("control"), anchor: [2.3, 1.6] },
  other: OTHER,
  orchestration: {
    label: "Orchestration",
    color: KIND_META.pipeline.color,
    anchor: [0.55, -1.8],
  },
  storage: {
    label: "Iceberg storage",
    color: KIND_META.external_volume.color,
    anchor: [0.55, 1.75],
  },
  code: { label: "Code", color: KIND_META.file.color, anchor: [-2.5, 1.95] },
};

const LAYER_GROUP: Record<string, string> = {
  raw: "bronze",
  landing: "bronze",
  bronze: "bronze",
  staging: "silver",
  silver: "silver",
  intermediate: "silver",
  gold: "gold",
  mart: "gold",
  marts: "gold",
  serving: "serving",
  control: "control",
  ingestion: "control",
};

const KIND_GROUP: Record<string, string> = {
  source_system: "systems",
  source: "sources",
  stage: "landing",
  file_format: "landing",
  storage_integration: "landing",
  external_volume: "storage",
  pipeline: "orchestration",
  alert: "orchestration",
  ci_stage: "orchestration",
  file: "code",
  symbol: "code",
  repository: "code",
};

const SHAPE: Record<string, Shape> = {
  table: "table",
  stage: "diamond",
  file_format: "diamond",
  storage_integration: "diamond",
  s3_location: "diamond",
  symbol: "diamond",
  external_volume: "hexagon",
  pipeline: "hexagon",
  repository: "hexagon",
  alert: "triangle",
  ci_stage: "square",
  file: "square",
};

const BASE_RADIUS: Record<string, number> = {
  pipeline: 13,
  source_system: 10,
  external_volume: 10,
  repository: 9,
  stage: 9,
  storage_integration: 7,
  s3_location: 7,
  file_format: 6,
  table: 5.5,
  ci_stage: 5.5,
  alert: 5,
  source: 4.5,
  file: 4,
  symbol: 3,
  check: 3,
  column: 2.6,
};

const HUBS = new Set(["pipeline", "source_system", "external_volume", "stage", "storage_integration", "s3_location", "file_format", "repository"]);

// Lineage edges, drawn in the direction data moves. These four are stored downstream -> upstream.
const FLOW = new Set(["DERIVED_FROM", "LOADED_FROM", "FROM_SYSTEM", "LANDS_IN", "READS_FROM", "WRITES_TO", "NEXT"]);
const STORED_UPSTREAM_FIRST = new Set(["DERIVED_FROM", "LOADED_FROM", "FROM_SYSTEM", "READS_FROM"]);
const ATTACHED = new Set(["HAS_COLUMN", "CHECKS"]);
const EMPTY = { nodes: [] as RNode[], links: [] as RLink[] };

function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace("#", "");
  const full =
    h.length === 3
      ? h
          .split("")
          .map((c) => c + c)
          .join("")
      : h;
  const n = Number.parseInt(full, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function alpha(hex: string, a: number): string {
  const [r, g, b] = hexToRgb(hex);
  return `rgba(${r},${g},${b},${a})`;
}

function lighten(hex: string, amount: number): string {
  const [r, g, b] = hexToRgb(hex);
  const mix = (c: number) => Math.round(c + (255 - c) * amount);
  return `rgb(${mix(r)},${mix(g)},${mix(b)})`;
}

/** A stable pseudo-random offset per id, so the same graph always settles the same way. */
function jitter(id: string, salt: number): number {
  let h = 2166136261 ^ salt;
  for (let i = 0; i < id.length; i++) h = Math.imul(h ^ id.charCodeAt(i), 16777619);
  return ((h >>> 0) % 1000) / 1000 - 0.5;
}

function endId(end: string | number | RNode | undefined): string {
  return typeof end === "object" && end !== null ? String(end.id) : String(end ?? "");
}

function escapeHtml(text: string): string {
  return text.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] ?? c);
}

function truncate(text: string, max: number): string {
  return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}

function tracePath(ctx: CanvasRenderingContext2D, shape: Shape, x: number, y: number, r: number) {
  ctx.beginPath();
  if (shape === "diamond") {
    const d = r * 1.2;
    ctx.moveTo(x, y - d);
    ctx.lineTo(x + d, y);
    ctx.lineTo(x, y + d);
    ctx.lineTo(x - d, y);
    ctx.closePath();
  } else if (shape === "hexagon") {
    for (let i = 0; i < 6; i++) {
      const a = (Math.PI / 3) * i + Math.PI / 6;
      const px = x + r * 1.12 * Math.cos(a);
      const py = y + r * 1.12 * Math.sin(a);
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
  } else if (shape === "triangle") {
    ctx.moveTo(x, y - r * 1.25);
    ctx.lineTo(x + r * 1.15, y + r * 0.85);
    ctx.lineTo(x - r * 1.15, y + r * 0.85);
    ctx.closePath();
  } else if (shape === "square") {
    ctx.roundRect(x - r, y - r, r * 2, r * 2, r * 0.4);
  } else {
    ctx.arc(x, y, r, 0, 2 * Math.PI);
  }
}

function clusterForce(strength: number) {
  let nodes: RNode[] = [];
  const force = (a: number) => {
    for (const n of nodes) {
      n.vx = (n.vx ?? 0) + (n.ax - (n.x ?? 0)) * strength * a;
      n.vy = (n.vy ?? 0) + (n.ay - (n.y ?? 0)) * strength * a;
    }
  };
  force.initialize = (all: RNode[]) => {
    nodes = all;
  };
  return force;
}

function collideForce(padding: number) {
  let nodes: RNode[] = [];
  const force = () => {
    for (let i = 0; i < nodes.length; i++) {
      const a = nodes[i];
      if (!a) continue;
      for (let j = i + 1; j < nodes.length; j++) {
        const b = nodes[j];
        if (!b) continue;
        const dx = (b.x ?? 0) - (a.x ?? 0) || 0.01;
        const dy = (b.y ?? 0) - (a.y ?? 0) || 0.01;
        const min = a.r + b.r + padding;
        const d2 = dx * dx + dy * dy;
        if (d2 >= min * min) continue;
        const d = Math.sqrt(d2);
        const push = ((min - d) / d) * 0.5;
        a.x = (a.x ?? 0) - dx * push;
        a.y = (a.y ?? 0) - dy * push;
        b.x = (b.x ?? 0) + dx * push;
        b.y = (b.y ?? 0) + dy * push;
      }
    }
  };
  force.initialize = (all: RNode[]) => {
    nodes = all.length <= 900 ? all : [];
  };
  return force;
}

function buildGraph(data: GraphPayload) {
  const kindOf = new Map(data.nodes.map((n) => [n.id, n.type]));
  const edges = data.edges.filter((e) => kindOf.has(e.source) && kindOf.has(e.target));
  // Columns and checks join the cluster of the table they belong to; S3 locations the cluster of what uses them.
  const tableOf = new Map<string, string>();
  const nearVolume = new Set<string>();
  for (const e of edges) {
    if (ATTACHED.has(e.type) && kindOf.get(e.target) === "table" && !tableOf.has(e.source)) tableOf.set(e.source, e.target);
    if (e.type === "HAS_COLUMN" && kindOf.get(e.source) === "table") tableOf.set(e.target, e.source);
    if (e.type === "WRITES_TO") nearVolume.add(e.target);
  }
  const byId = new Map(data.nodes.map((n) => [n.id, n]));
  const groupOfTable = (node: GraphNode | undefined) => LAYER_GROUP[String(node?.properties.layer ?? "")] ?? "other";
  const groupOf = (n: GraphNode): string => {
    if (n.type === "table") return groupOfTable(n);
    if (n.type === "column" || n.type === "check") return groupOfTable(byId.get(tableOf.get(n.id) ?? ""));
    if (n.type === "s3_location") return nearVolume.has(n.id) ? "storage" : "landing";
    return KIND_GROUP[n.type] ?? "other";
  };

  const assigned = data.nodes.map((n) => ({ n, group: groupOf(n) }));
  const sizes = new Map<string, number>();
  for (const { group } of assigned) sizes.set(group, (sizes.get(group) ?? 0) + 1);
  const unit = 150 + 10 * Math.sqrt(Math.max(1, ...sizes.values()));

  const nodes: RNode[] = assigned.map(({ n, group }) => {
    const layer = n.type === "table" ? String(n.properties.layer ?? "") || null : null;
    const color = n.type === "table" ? tint(layer ?? "") : kindMeta(n.type).color;
    const degree = n.degree ?? 0;
    const grow = n.type === "table" || n.type === "source" ? Math.min(5, Math.sqrt(degree) * 0.9) : 0;
    const [gx, gy] = (GROUPS[group] ?? OTHER).anchor;
    const ax = gx * unit;
    const ay = gy * unit;
    const priority = HUBS.has(n.type)
      ? 70
      : layer === "gold" || layer === "serving"
        ? 55
        : n.type === "table" || n.type === "alert" || n.type === "ci_stage"
          ? 40
          : n.type === "source"
            ? 30
            : 10;
    return {
      id: n.id,
      label: n.label,
      kind: n.type,
      layer,
      color,
      r: (BASE_RADIUS[n.type] ?? 4) + grow,
      shape: SHAPE[n.type] ?? "circle",
      group,
      priority,
      degree,
      ax,
      ay,
      original: n,
      x: ax + jitter(n.id, 1) * unit * 0.6,
      y: ay + jitter(n.id, 2) * unit * 0.6,
    };
  });
  const colorOf = new Map(nodes.map((n) => [n.id, n.color]));
  const links: RLink[] = edges.map((e) => {
    const reverse = STORED_UPSTREAM_FIRST.has(e.type);
    const source = reverse ? e.target : e.source;
    const target = reverse ? e.source : e.target;
    return {
      source,
      target,
      type: e.type,
      flow: FLOW.has(e.type),
      color: colorOf.get(source) ?? "#94a3b8",
    };
  });
  const neighbours = new Map<string, Set<string>>();
  for (const e of edges) {
    if (!neighbours.has(e.source)) neighbours.set(e.source, new Set());
    if (!neighbours.has(e.target)) neighbours.set(e.target, new Set());
    neighbours.get(e.source)?.add(e.target);
    neighbours.get(e.target)?.add(e.source);
  }
  const labelOrder = [...nodes].sort((a, b) => b.priority - a.priority || b.degree - a.degree);
  return { nodes, links, neighbours, labelOrder };
}

function tooltip(n: RNode): string {
  const meta = kindMeta(n.kind);
  const p = n.original.properties;
  const facts = [
    n.layer ? `${n.layer} layer` : null,
    n.kind === "table" && p.table_type ? tableTypeLabel(p.table_type) : null,
    p.source_path ? String(p.source_path) : null,
    p.schedule ? `schedule ${String(p.schedule)}` : null,
    `${n.degree} connection${n.degree === 1 ? "" : "s"}`,
  ].filter(Boolean) as string[];
  return (
    `<div class="rn-tip"><div class="rn-tip-kind"><span class="rn-tip-dot" style="background:${n.color}"></span>${escapeHtml(meta.label)}</div>` +
    `<div class="rn-tip-name">${escapeHtml(n.label)}</div><div class="rn-tip-facts">${escapeHtml(facts.join(" · "))}</div>` +
    `<div class="rn-tip-hint">Click for details</div></div>`
  );
}

function ControlButton({ icon: Icon, label, onClick, pressed }: { icon: LucideIcon; label: string; onClick: () => void; pressed?: boolean }) {
  return (
    <button
      type="button"
      title={label}
      aria-label={label}
      aria-pressed={pressed}
      onClick={onClick}
      className={cn(
        "inline-flex h-8 w-8 items-center justify-center rounded-lg transition-colors",
        pressed === false ? "text-muted-foreground hover:bg-muted" : "text-foreground hover:bg-primary/10",
        pressed && "bg-primary/10 text-primary",
      )}
    >
      <Icon className="h-4 w-4" aria-hidden="true" />
    </button>
  );
}

export function RepoNetwork({
  data,
  loading,
  selectedId = null,
  onSelect,
}: {
  data: GraphPayload | undefined;
  loading?: boolean;
  selectedId?: string | null;
  onSelect?: (key: string) => void;
}) {
  const fgRef = useRef<ForceGraphMethods<RNode, RLink> | undefined>(undefined);
  const observerRef = useRef<ResizeObserver | null>(null);
  // Ticks left during which the view keeps fitting the settling layout (after new data or a resize).
  const fitTicks = useRef(0);
  const [size, setSize] = useState({ width: 0, height: 0 });
  const [hoverId, setHoverId] = useState<string | null>(null);
  const [animate, setAnimate] = useState(true);
  const [clusters, setClusters] = useState(true);
  const [forcesReady, setForcesReady] = useState(false);
  const { resolved } = useTheme();
  const palette = useMemo(
    () =>
      resolved === "dark"
        ? {
            text: "#e2e8f0",
            halo: "rgba(2,6,23,0.9)",
            structure: "#94a3b8",
            outline: "#0b1220",
          }
        : {
            text: "#0f172a",
            halo: "rgba(255,255,255,0.92)",
            structure: "#64748b",
            outline: "#ffffff",
          },
    [resolved],
  );

  const containerRef = useCallback((el: HTMLDivElement | null) => {
    observerRef.current?.disconnect();
    observerRef.current = null;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    setSize({ width: Math.floor(rect.width), height: Math.floor(rect.height) });
    const observer = new ResizeObserver((entries) => {
      const r = entries[0]?.contentRect;
      if (r) setSize({ width: Math.floor(r.width), height: Math.floor(r.height) });
    });
    observer.observe(el);
    observerRef.current = observer;
  }, []);

  const graph = useMemo(() => (data ? buildGraph(data) : null), [data]);
  const ready = size.width > 0 && size.height > 0;
  const focusId = hoverId ?? selectedId;
  const focus = useMemo(() => {
    if (!focusId || !graph) return null;
    return new Set([focusId, ...(graph.neighbours.get(focusId) ?? [])]);
  }, [focusId, graph]);

  // Layout forces: clusters in flow order, lineage links as soft springs, structural links drawn only.
  // They are set while the graph is still empty, so the warm-up ticks of the real data already use them
  // and the first frame shows the settled layout.
  useEffect(() => {
    const fg = fgRef.current;
    if (!fg || !ready || forcesReady) return;
    const link = fg.d3Force("link") as unknown as
      | {
          strength: (fn: (l: RLink) => number) => unknown;
          distance: (fn: (l: RLink) => number) => unknown;
        }
      | undefined;
    link?.strength((l) => (ATTACHED.has(l.type) ? 0.6 : l.flow ? 0.04 : 0));
    link?.distance((l) => (ATTACHED.has(l.type) ? 14 : 60));
    const charge = fg.d3Force("charge") as unknown as
      | {
          strength: (fn: (n: RNode) => number) => unknown;
          distanceMax: (d: number) => unknown;
        }
      | undefined;
    charge?.strength((n) => -14 - n.r * 3);
    charge?.distanceMax(180);
    fg.d3Force("cluster", clusterForce(0.14) as never);
    fg.d3Force("collide", collideForce(5) as never);
    setForcesReady(true);
  }, [ready, forcesReady]);

  useEffect(() => {
    if (!ready || !forcesReady) return;
    fitTicks.current = 30;
    fgRef.current?.zoomToFit(0, 56);
  }, [ready, forcesReady, graph, size.width, size.height]);

  useEffect(() => {
    if (!selectedId || !graph) return;
    const node = graph.nodes.find((n) => n.id === selectedId);
    if (node?.x !== undefined && node.y !== undefined) fgRef.current?.centerAt(node.x, node.y, 600);
  }, [selectedId, graph]);

  const paintClusters = useCallback(
    (ctx: CanvasRenderingContext2D, scale: number) => {
      if (!clusters || !graph) return;
      const members = new Map<string, RNode[]>();
      for (const n of graph.nodes) {
        if (!members.has(n.group)) members.set(n.group, []);
        members.get(n.group)?.push(n);
      }
      for (const [key, nodes] of members) {
        const group = GROUPS[key] ?? OTHER;
        const cx = nodes.reduce((s, n) => s + (n.x ?? 0), 0) / nodes.length;
        const cy = nodes.reduce((s, n) => s + (n.y ?? 0), 0) / nodes.length;
        const radius = Math.max(26, ...nodes.map((n) => Math.hypot((n.x ?? 0) - cx, (n.y ?? 0) - cy) + n.r)) + 14;
        const faded = focus !== null && !nodes.some((n) => focus.has(n.id));
        ctx.globalAlpha = faded ? 0.35 : 1;
        const fill = ctx.createRadialGradient(cx, cy, radius * 0.15, cx, cy, radius);
        fill.addColorStop(0, alpha(group.color, 0.14));
        fill.addColorStop(1, alpha(group.color, 0.03));
        ctx.beginPath();
        ctx.arc(cx, cy, radius, 0, 2 * Math.PI);
        ctx.fillStyle = fill;
        ctx.fill();
        ctx.setLineDash([4 / scale, 5 / scale]);
        ctx.lineWidth = 1 / scale;
        ctx.strokeStyle = alpha(group.color, 0.45);
        ctx.stroke();
        ctx.setLineDash([]);
        const fontPx = 10.5 / scale;
        ctx.font = `700 ${fontPx}px Inter, system-ui, sans-serif`;
        ctx.textAlign = "center";
        ctx.textBaseline = "bottom";
        const title = `${group.label.toUpperCase()}  ${nodes.length}`;
        ctx.lineJoin = "round";
        ctx.lineWidth = 3 / scale;
        ctx.strokeStyle = palette.halo;
        ctx.strokeText(title, cx, cy - radius - 4 / scale);
        ctx.fillStyle = alpha(group.color, 0.95);
        ctx.fillText(title, cx, cy - radius - 4 / scale);
        ctx.globalAlpha = 1;
      }
    },
    [clusters, graph, focus, palette],
  );

  const paintNode = useCallback(
    (node: RNode, ctx: CanvasRenderingContext2D, scale: number) => {
      const x = node.x ?? 0;
      const y = node.y ?? 0;
      const focused = node.id === focusId;
      const dim = focus !== null && !focus.has(node.id);
      ctx.globalAlpha = dim ? 0.16 : 1;
      if (focused || (HUBS.has(node.kind) && !dim)) {
        ctx.shadowColor = alpha(node.color, focused ? 0.9 : 0.55);
        ctx.shadowBlur = focused ? 22 : 12;
      }
      const fill = ctx.createRadialGradient(x - node.r * 0.4, y - node.r * 0.45, node.r * 0.1, x, y, node.r * 1.25);
      fill.addColorStop(0, lighten(node.color, 0.55));
      fill.addColorStop(1, node.color);
      tracePath(ctx, node.shape, x, y, node.r);
      ctx.fillStyle = fill;
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.shadowColor = "transparent";
      ctx.lineWidth = 1.4 / scale;
      ctx.strokeStyle = palette.outline;
      ctx.stroke();
      if (node.shape === "table") {
        ctx.beginPath();
        ctx.arc(x, y, node.r * 0.45, 0, 2 * Math.PI);
        ctx.fillStyle = "rgba(255,255,255,0.75)";
        ctx.fill();
      }
      if (focused || node.id === selectedId) {
        tracePath(ctx, node.shape, x, y, node.r + 3.5 / scale);
        ctx.lineWidth = 2 / scale;
        ctx.strokeStyle = node.color;
        ctx.stroke();
      }
      ctx.globalAlpha = 1;
    },
    [focus, focusId, selectedId, palette],
  );

  const paintLabels = useCallback(
    (ctx: CanvasRenderingContext2D, scale: number) => {
      if (!graph) return;
      const threshold = scale < 0.7 ? 70 : scale < 1.1 ? 50 : scale < 1.8 ? 30 : 0;
      const placed: [number, number, number, number][] = [];
      const order = focus
        ? graph.labelOrder.filter((n) => focus.has(n.id)).sort((a, b) => Number(b.id === focusId) - Number(a.id === focusId))
        : graph.labelOrder.filter((n) => n.priority >= threshold || n.id === selectedId);
      ctx.textAlign = "center";
      ctx.textBaseline = "top";
      ctx.lineJoin = "round";
      for (const n of order) {
        const strong = n.priority >= 55 || n.id === focusId;
        const fontPx = (strong ? 11.5 : 10.5) / scale;
        ctx.font = `${strong ? 600 : 500} ${fontPx}px Inter, system-ui, sans-serif`;
        const text = truncate(n.label, 30);
        const w = ctx.measureText(text).width;
        const x = n.x ?? 0;
        const y = (n.y ?? 0) + n.r * 1.25 + 3 / scale;
        const box: [number, number, number, number] = [x - w / 2 - 2 / scale, y - 1 / scale, x + w / 2 + 2 / scale, y + fontPx + 1 / scale];
        if (placed.some((p) => box[0] < p[2] && box[2] > p[0] && box[1] < p[3] && box[3] > p[1])) continue;
        placed.push(box);
        ctx.lineWidth = 3.2 / scale;
        ctx.strokeStyle = palette.halo;
        ctx.strokeText(text, x, y);
        ctx.fillStyle = palette.text;
        ctx.fillText(text, x, y);
      }
    },
    [graph, focus, focusId, selectedId, palette],
  );

  const touches = useCallback((l: RLink) => focusId !== null && (endId(l.source) === focusId || endId(l.target) === focusId), [focusId]);

  if (loading) return <Skeleton className="h-[68vh] min-h-[460px] w-full rounded-xl" />;
  if (!graph || graph.nodes.length === 0) {
    return (
      <div className="flex h-[40vh] min-h-[280px] items-center justify-center rounded-xl border text-sm text-muted-foreground">
        Nothing to draw for the chosen kinds.
      </div>
    );
  }

  const flowCount = graph.links.filter((l) => l.flow).length;
  const zoomBy = (factor: number) => {
    const fg = fgRef.current;
    if (fg) fg.zoom(fg.zoom() * factor, 300);
  };

  return (
    <div className="space-y-2">
      <div
        className="repo-network relative h-[68vh] min-h-[460px] overflow-hidden rounded-xl border bg-card"
        style={{
          backgroundImage: "radial-gradient(hsl(var(--border)) 1px, transparent 1px)",
          backgroundSize: "22px 22px",
        }}
      >
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-primary/[0.05] via-transparent to-background/40" aria-hidden="true" />
        <div ref={containerRef} className="absolute inset-0">
          {ready ? (
            <ForceGraph2D<NodeData, LinkData>
              ref={fgRef}
              width={size.width}
              height={size.height}
              graphData={forcesReady ? graph : EMPTY}
              backgroundColor="rgba(0,0,0,0)"
              nodeId="id"
              nodeLabel={tooltip}
              nodeCanvasObject={paintNode}
              nodeCanvasObjectMode={() => "replace"}
              nodePointerAreaPaint={(node, color, ctx) => {
                ctx.fillStyle = color;
                tracePath(ctx, node.shape, node.x ?? 0, node.y ?? 0, node.r + 3);
                ctx.fill();
              }}
              onRenderFramePre={paintClusters}
              onRenderFramePost={paintLabels}
              linkVisibility={(l) => l.flow || ATTACHED.has(l.type) || touches(l)}
              linkColor={(l) => {
                if (focusId !== null && !touches(l)) return alpha(palette.structure, 0.05);
                if (l.flow) return alpha(l.color, touches(l) ? 0.95 : 0.5);
                return alpha(palette.structure, touches(l) ? 0.75 : 0.14);
              }}
              linkWidth={(l) => (l.flow ? (touches(l) ? 2.6 : 1.4) : touches(l) ? 1.4 : 0.6)}
              linkLineDash={(l) => (l.flow ? null : [3, 3])}
              linkCurvature={(l) => (l.type === "NEXT" ? 0 : l.flow ? 0.16 : 0.28)}
              linkDirectionalArrowLength={(l) => (l.flow && !animate ? 4 : 0)}
              linkDirectionalArrowRelPos={0.92}
              linkDirectionalParticles={(l) => (animate && l.flow && (focusId === null || touches(l)) ? 2 : 0)}
              linkDirectionalParticleSpeed={0.0045}
              linkDirectionalParticleWidth={(l) => (touches(l) ? 3.6 : 2.6)}
              linkDirectionalParticleColor={(l) => lighten(l.color, 0.15)}
              linkLabel={(l) => l.type.replace(/_/g, " ").toLowerCase()}
              onNodeHover={(n) => setHoverId(n ? String(n.id) : null)}
              onNodeClick={(n) => onSelect?.(String(n.id))}
              onEngineTick={() => {
                if (fitTicks.current <= 0) return;
                fitTicks.current -= 1;
                fgRef.current?.zoomToFit(0, 56);
              }}
              warmupTicks={160}
              cooldownTicks={120}
              d3AlphaDecay={0.025}
              d3VelocityDecay={0.32}
              minZoom={0.25}
              maxZoom={5}
              enableNodeDrag
            />
          ) : null}
        </div>

        <div className="pointer-events-none absolute left-3 top-3 rounded-lg border bg-background/80 px-2.5 py-1 text-[11px] text-muted-foreground backdrop-blur">
          {graph.nodes.length} nodes · {graph.links.length} edges · {flowCount} lineage
        </div>

        <div className="absolute right-3 top-3 flex flex-col gap-0.5 rounded-xl border bg-background/85 p-1 shadow-sm backdrop-blur">
          <ControlButton icon={Plus} label="Zoom in" onClick={() => zoomBy(1.35)} />
          <ControlButton icon={Minus} label="Zoom out" onClick={() => zoomBy(1 / 1.35)} />
          <ControlButton icon={Maximize2} label="Fit to view" onClick={() => fgRef.current?.zoomToFit(500, 56)} />
          <div className="mx-1.5 my-0.5 h-px bg-border" aria-hidden="true" />
          <ControlButton icon={Activity} label="Animate data flow" pressed={animate} onClick={() => setAnimate((v) => !v)} />
          <ControlButton icon={CircleDashed} label="Show clusters" pressed={clusters} onClick={() => setClusters((v) => !v)} />
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 px-1 text-[11px] text-muted-foreground">
        <span className="inline-flex items-center gap-1.5">
          <span className="h-0.5 w-5 rounded-full bg-gradient-to-r from-sky-400 to-amber-500" aria-hidden="true" />
          lineage, moving with the data
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="w-5 border-t border-dashed border-muted-foreground/70" aria-hidden="true" />
          builds, stores, monitors (on focus)
        </span>
        <span>● tables and sources · ◆ landing and config · ⬢ pipeline and volume · ▲ alerts · ■ CI</span>
        <span className="text-muted-foreground/80">hover to focus · click for details · drag to move · scroll to zoom</span>
      </div>
    </div>
  );
}
