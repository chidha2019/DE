import {
  Bell,
  Braces,
  Cloud,
  Columns3,
  Download,
  FileCode,
  FileCog,
  FileText,
  FolderGit2,
  GitCommitHorizontal,
  HardDrive,
  KeyRound,
  Server,
  ShieldCheck,
  Table2,
  Workflow,
  type LucideIcon,
} from "lucide-react";

import type { RepoNodeKind } from "@/api/repo-graph";

export interface KindMeta {
  label: string;
  plural: string;
  icon: LucideIcon;
  color: string;
}

export const KIND_META: Record<RepoNodeKind, KindMeta> = {
  repository: { label: "Repository", plural: "Repositories", icon: FolderGit2, color: "#94a3b8" },
  file: { label: "File", plural: "Files", icon: FileCode, color: "#64748b" },
  symbol: { label: "Code symbol", plural: "Code symbols", icon: Braces, color: "#a78bfa" },
  pipeline: { label: "Pipeline", plural: "Pipelines", icon: Workflow, color: "#f97316" },
  source_system: { label: "Source system", plural: "Source systems", icon: Server, color: "#0ea5e9" },
  source: { label: "CSV source", plural: "CSV sources", icon: FileText, color: "#38bdf8" },
  table: { label: "Table", plural: "Tables", icon: Table2, color: "#c2773b" },
  column: { label: "Column", plural: "Columns", icon: Columns3, color: "#94a3b8" },
  check: { label: "Quality check", plural: "Quality checks", icon: ShieldCheck, color: "#22c55e" },
  storage_integration: { label: "Storage integration", plural: "Storage integrations", icon: KeyRound, color: "#eab308" },
  external_volume: { label: "External volume", plural: "External volumes", icon: HardDrive, color: "#14b8a6" },
  stage: { label: "Stage", plural: "Stages", icon: Download, color: "#06b6d4" },
  file_format: { label: "File format", plural: "File formats", icon: FileCog, color: "#a3a3a3" },
  s3_location: { label: "S3 location", plural: "S3 locations", icon: Cloud, color: "#f59e0b" },
  ci_stage: { label: "CI stage", plural: "CI stages", icon: GitCommitHorizontal, color: "#8b5cf6" },
  alert: { label: "Alert", plural: "Alerts", icon: Bell, color: "#ef4444" },
};

/** Data layers in flow order; anything else is drawn after these. */
export const LAYER_ORDER = ["raw", "landing", "bronze", "staging", "silver", "intermediate", "gold", "mart", "marts", "serving"] as const;

export const LAYER_COLOR: Record<string, string> = {
  raw: "#a16207",
  landing: "#a16207",
  bronze: "#c2773b",
  staging: "#60a5fa",
  silver: "#94a3b8",
  intermediate: "#818cf8",
  gold: "#eab308",
  mart: "#10b981",
  marts: "#10b981",
  serving: "#22c55e",
  control: "#64748b",
  ingestion: "#64748b",
};

export function kindMeta(kind: string | null | undefined): KindMeta {
  return KIND_META[(kind ?? "file") as RepoNodeKind] ?? KIND_META.file;
}

export function layerColor(layer: unknown): string {
  return LAYER_COLOR[String(layer ?? "")] ?? "#94a3b8";
}

export function nodeTint(kind: string | null | undefined, layer?: unknown): string {
  return kind === "table" ? layerColor(layer) : kindMeta(kind).color;
}

export function tableTypeLabel(value: unknown): string {
  switch (value) {
    case "iceberg":
      return "Iceberg";
    case "secure_view":
      return "Secure view";
    case "view":
      return "View";
    case "table":
      return "Table";
    default:
      return String(value ?? "");
  }
}

export function methodLabel(methods: string[] | null | undefined): string {
  const m = new Set(methods ?? []);
  if (m.has("declared") && m.has("parsed")) return "declared and parsed";
  return [...m].join(", ");
}

export function shortSha(sha: string | null | undefined): string {
  return sha ? sha.slice(0, 7) : "";
}
