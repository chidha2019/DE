import type { RepoCrawl } from "@/api/repo-graph";
import { shortSha } from "@/components/repo-graph/kind-style";
import { EmptyRow } from "@/components/personas/persona-shell";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatDateTime, formatInt, formatRelative } from "@/lib/format";

const STATUS_VARIANT = { queued: "muted", running: "info", completed: "success", failed: "destructive" } as const;

export function CrawlHistory({ crawls }: { crawls: RepoCrawl[] | undefined }) {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Started</TableHead>
          <TableHead>Repository</TableHead>
          <TableHead>Status</TableHead>
          <TableHead className="text-right">Files</TableHead>
          <TableHead className="text-right">Nodes</TableHead>
          <TableHead className="text-right">Edges</TableHead>
          <TableHead>Commit</TableHead>
          <TableHead>Notes</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {crawls?.map((c) => (
          <TableRow key={c.id}>
            <TableCell className="whitespace-nowrap text-xs" title={formatDateTime(c.created_at)}>
              {formatRelative(c.created_at)}
            </TableCell>
            <TableCell className="font-mono text-xs">{c.repo}</TableCell>
            <TableCell>
              <Badge variant={STATUS_VARIANT[c.status]} className="text-[10px]">
                {c.status === "running" ? c.phase : c.status}
              </Badge>
            </TableCell>
            <TableCell className="text-right font-mono text-xs">{formatInt(c.files_read)}</TableCell>
            <TableCell className="text-right font-mono text-xs">{formatInt(c.stats.nodes)}</TableCell>
            <TableCell className="text-right font-mono text-xs">{formatInt(c.stats.edges)}</TableCell>
            <TableCell className="font-mono text-xs text-muted-foreground">
              {c.ref ?? ""} {shortSha(c.sha)}
            </TableCell>
            <TableCell className="max-w-[28rem] text-xs text-muted-foreground">
              {c.error ? (
                <span className="text-destructive">{c.error}</span>
              ) : c.warnings.length ? (
                <details>
                  <summary className="cursor-pointer text-warning">{c.warnings.length} warnings</summary>
                  <ul className="mt-1 list-disc space-y-0.5 pl-4">
                    {c.warnings.slice(0, 30).map((w) => (
                      <li key={w}>{w}</li>
                    ))}
                  </ul>
                </details>
              ) : c.index_text ? (
                "graph and text index"
              ) : (
                "graph only"
              )}
            </TableCell>
          </TableRow>
        ))}
        {crawls && crawls.length === 0 ? <EmptyRow colSpan={8}>No crawls yet. Enter a repository above and crawl it.</EmptyRow> : null}
      </TableBody>
    </Table>
  );
}
