import { ArrowRight, Columns3, ShieldCheck } from "lucide-react";
import { useCallback, useLayoutEffect, useMemo, useRef, useState } from "react";

import type { RepoGraphPayload } from "@/api/repo-graph";
import type { GraphNode } from "@/api/types";
import { LAYER_ORDER, kindMeta, layerColor, nodeTint, tableTypeLabel } from "@/components/repo-graph/kind-style";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

interface FlowColumn {
  key: string;
  label: string;
  color: string;
  groups: { label: string | null; nodes: GraphNode[] }[];
}

interface Path {
  id: string;
  d: string;
  color: string;
  from: string;
  to: string;
}

const HIDDEN_LAYERS = new Set(["control", "ingestion"]);

function prop(node: GraphNode | undefined, key: string): unknown {
  return node?.properties?.[key];
}

/** Upstream -> downstream edges of the data flow (sources into tables, tables into tables). */
function flowEdges(data: RepoGraphPayload | undefined): [string, string][] {
  if (!data) return [];
  const out: [string, string][] = [];
  for (const e of data.edges) {
    if (e.type === "LOADED_FROM") out.push([e.target, e.source]);
    else if (e.type === "DERIVED_FROM") out.push([e.target, e.source]);
  }
  return out;
}

function reach(start: string, adjacency: Map<string, string[]>): Set<string> {
  const seen = new Set<string>();
  const stack = [start];
  while (stack.length) {
    const id = stack.pop() as string;
    for (const next of adjacency.get(id) ?? []) {
      if (!seen.has(next)) {
        seen.add(next);
        stack.push(next);
      }
    }
  }
  return seen;
}

export function LineageFlow({
  data,
  loading,
  selected,
  onSelect,
  showControl,
}: {
  data: RepoGraphPayload | undefined;
  loading: boolean;
  selected: string | null;
  onSelect: (key: string) => void;
  showControl: boolean;
}) {
  const [hovered, setHovered] = useState<string | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const nodeRefs = useRef(new Map<string, HTMLElement>());
  const [paths, setPaths] = useState<Path[]>([]);
  const [size, setSize] = useState({ w: 0, h: 0 });

  const byId = useMemo(() => new Map((data?.nodes ?? []).map((n) => [n.id, n] as const)), [data]);
  const edges = useMemo(() => flowEdges(data), [data]);

  const columns = useMemo<FlowColumn[]>(() => {
    if (!data) return [];
    const sources = data.nodes.filter((n) => n.type === "source");
    const bySystem = new Map<string, GraphNode[]>();
    for (const s of sources) {
      const system = String(prop(s, "source_system") ?? "other");
      bySystem.set(system, [...(bySystem.get(system) ?? []), s]);
    }
    const sourceOrder = new Map<string, number>();
    const sourceGroups = [...bySystem.entries()]
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([label, nodes]) => ({ label, nodes: nodes.sort((a, b) => a.label.localeCompare(b.label)) }));
    sourceGroups.flatMap((g) => g.nodes).forEach((n, i) => sourceOrder.set(n.id, i));
    const loadedFrom = new Map<string, string>();
    for (const e of data.edges) if (e.type === "LOADED_FROM") loadedFrom.set(e.source, e.target);

    const tables = data.nodes.filter((n) => n.type === "table");
    const layers = new Map<string, GraphNode[]>();
    for (const t of tables) {
      const layer = String(prop(t, "layer") ?? "other");
      if (HIDDEN_LAYERS.has(layer) && !showControl) continue;
      layers.set(layer, [...(layers.get(layer) ?? []), t]);
    }
    const rank = (layer: string) => {
      const i = (LAYER_ORDER as readonly string[]).indexOf(layer);
      return i === -1 ? 100 : i;
    };
    const cols: FlowColumn[] = [];
    if (sources.length) cols.push({ key: "sources", label: "CSV sources", color: kindMeta("source").color, groups: sourceGroups });
    for (const [layer, nodes] of [...layers.entries()].sort(([a], [b]) => rank(a) - rank(b) || a.localeCompare(b))) {
      const sorted = nodes.sort((a, b) => {
        const sa = sourceOrder.get(loadedFrom.get(a.id) ?? "") ?? 1e6;
        const sb = sourceOrder.get(loadedFrom.get(b.id) ?? "") ?? 1e6;
        return sa - sb || a.label.localeCompare(b.label);
      });
      cols.push({ key: layer, label: layer.charAt(0).toUpperCase() + layer.slice(1), color: layerColor(layer), groups: [{ label: null, nodes: sorted }] });
    }
    return cols;
  }, [data, showControl]);

  const visible = useMemo(() => new Set(columns.flatMap((c) => c.groups.flatMap((g) => g.nodes.map((n) => n.id)))), [columns]);

  const { down, up } = useMemo(() => {
    const down = new Map<string, string[]>();
    const up = new Map<string, string[]>();
    for (const [a, b] of edges) {
      down.set(a, [...(down.get(a) ?? []), b]);
      up.set(b, [...(up.get(b) ?? []), a]);
    }
    return { down, up };
  }, [edges]);

  const focus = hovered ?? selected;
  const lit = useMemo(() => {
    if (!focus || !visible.has(focus)) return null;
    return new Set([focus, ...reach(focus, down), ...reach(focus, up)]);
  }, [focus, visible, down, up]);

  const measure = useCallback(() => {
    const box = containerRef.current;
    if (!box) return;
    const origin = box.getBoundingClientRect();
    const next: Path[] = [];
    for (const [a, b] of edges) {
      if (!visible.has(a) || !visible.has(b)) continue;
      const ea = nodeRefs.current.get(a);
      const eb = nodeRefs.current.get(b);
      if (!ea || !eb) continue;
      const ra = ea.getBoundingClientRect();
      const rb = eb.getBoundingClientRect();
      const x1 = ra.right - origin.left;
      const y1 = ra.top + ra.height / 2 - origin.top;
      const x2 = rb.left - origin.left;
      const y2 = rb.top + rb.height / 2 - origin.top;
      if (x2 <= x1) continue;
      const dx = Math.max(24, (x2 - x1) / 2);
      const target = byId.get(b);
      next.push({ id: `${a}>${b}`, d: `M ${x1} ${y1} C ${x1 + dx} ${y1}, ${x2 - dx} ${y2}, ${x2} ${y2}`, color: nodeTint(target?.type, prop(target, "layer")), from: a, to: b });
    }
    setPaths(next);
    setSize({ w: box.scrollWidth, h: box.scrollHeight });
  }, [edges, visible, byId]);

  useLayoutEffect(() => {
    measure();
    const box = containerRef.current;
    if (!box) return;
    const observer = new ResizeObserver(() => measure());
    observer.observe(box);
    return () => observer.disconnect();
  }, [measure, columns]);

  const register = useCallback(
    (id: string) => (el: HTMLElement | null) => {
      if (el) nodeRefs.current.set(id, el);
      else nodeRefs.current.delete(id);
    },
    [],
  );

  if (loading && !data) return <Skeleton className="h-96 w-full" />;
  if (!columns.length) {
    return <p className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">No sources or tables were found in this repository.</p>;
  }

  return (
    <div className="overflow-x-auto pb-2">
      <div ref={containerRef} className="relative flex min-w-max gap-14 px-1 py-1">
        <svg className="pointer-events-none absolute left-0 top-0" width={size.w} height={size.h} aria-hidden="true">
          {paths.map((p) => {
            const on = lit ? lit.has(p.from) && lit.has(p.to) : false;
            return (
              <path
                key={p.id}
                d={p.d}
                fill="none"
                stroke={p.color}
                strokeWidth={on ? 2 : 1.25}
                strokeOpacity={lit ? (on ? 0.95 : 0.06) : 0.38}
                className="transition-[stroke-opacity] duration-150"
              />
            );
          })}
        </svg>
        {columns.map((col) => (
          <div key={col.key} className="relative w-52 shrink-0">
            <div className="mb-2 flex items-center gap-2 px-1">
              <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: col.color }} />
              <span className="text-xs font-medium uppercase tracking-wider">{col.label}</span>
              <span className="text-[11px] text-muted-foreground">{col.groups.reduce((n, g) => n + g.nodes.length, 0)}</span>
            </div>
            <div className="space-y-3">
              {col.groups.map((group) => (
                <div key={group.label ?? "all"} className="space-y-1.5">
                  {group.label ? <div className="px-1 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{group.label}</div> : null}
                  {group.nodes.map((n) => (
                    <FlowNode
                      key={n.id}
                      node={n}
                      refCallback={register(n.id)}
                      selected={selected === n.id}
                      dimmed={Boolean(lit && !lit.has(n.id))}
                      onSelect={() => onSelect(n.id)}
                      onHover={(on) => setHovered(on ? n.id : null)}
                    />
                  ))}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function FlowNode({
  node,
  refCallback,
  selected,
  dimmed,
  onSelect,
  onHover,
}: {
  node: GraphNode;
  refCallback: (el: HTMLElement | null) => void;
  selected: boolean;
  dimmed: boolean;
  onSelect: () => void;
  onHover: (on: boolean) => void;
}) {
  const isSource = node.type === "source";
  const tint = nodeTint(node.type, prop(node, "layer"));
  const columns = Number(prop(node, "column_count") ?? 0);
  const checks = Number(prop(node, "checks") ?? 0);
  const type = prop(node, "table_type");
  return (
    <button
      ref={refCallback}
      type="button"
      onClick={onSelect}
      onMouseEnter={() => onHover(true)}
      onMouseLeave={() => onHover(false)}
      onFocus={() => onHover(true)}
      onBlur={() => onHover(false)}
      title={String(prop(node, "name") ?? node.label)}
      className={cn(
        "relative block w-full overflow-hidden rounded-lg border bg-card py-1.5 pl-3 pr-2 text-left transition-all",
        selected ? "border-primary ring-2 ring-primary/30" : "border-border/70 hover:border-primary/50",
        dimmed && "opacity-30",
      )}
    >
      <span className="absolute inset-y-0 left-0 w-1" style={{ backgroundColor: tint }} />
      <div className="truncate font-mono text-[11px] font-medium leading-tight">{node.label}</div>
      <div className="mt-0.5 flex items-center gap-2 text-[10px] text-muted-foreground">
        {isSource ? (
          <span className="truncate">{String(prop(node, "source_path") ?? prop(node, "format") ?? "")}</span>
        ) : (
          <>
            {type ? <span className="truncate">{tableTypeLabel(type)}</span> : null}
            {columns ? (
              <span className="inline-flex items-center gap-0.5">
                <Columns3 className="h-2.5 w-2.5" />
                {columns}
              </span>
            ) : null}
            {checks ? (
              <span className="inline-flex items-center gap-0.5 text-success">
                <ShieldCheck className="h-2.5 w-2.5" />
                {checks}
              </span>
            ) : null}
          </>
        )}
      </div>
    </button>
  );
}

/** The storage path the flow runs on: landing bucket, integration, stage and format; volume and Iceberg bucket. */
export function InfraStrip({ data, onSelect, selected }: { data: RepoGraphPayload | undefined; onSelect: (key: string) => void; selected: string | null }) {
  const chains = useMemo(() => {
    if (!data) return [] as { title: string; nodes: GraphNode[] }[];
    const byId = new Map(data.nodes.map((n) => [n.id, n] as const));
    const out = (id: string, type: string) =>
      data.edges.filter((e) => e.source === id && e.type === type).map((e) => byId.get(e.target)).filter((n): n is GraphNode => Boolean(n));
    const result: { title: string; nodes: GraphNode[] }[] = [];
    for (const stage of data.nodes.filter((n) => n.type === "stage")) {
      const uses = out(stage.id, "USES");
      const nodes = [out(stage.id, "READS_FROM")[0], uses.find((n) => n.type === "storage_integration"), stage, uses.find((n) => n.type === "file_format")];
      result.push({ title: "Landing path", nodes: nodes.filter((n): n is GraphNode => Boolean(n)) });
    }
    for (const volume of data.nodes.filter((n) => n.type === "external_volume")) {
      const nodes = [volume, out(volume.id, "WRITES_TO")[0]];
      result.push({ title: "Iceberg storage", nodes: nodes.filter((n): n is GraphNode => Boolean(n)) });
    }
    return result;
  }, [data]);
  if (!chains.length) return null;
  return (
    <div className="grid gap-2 lg:grid-cols-2">
      {chains.map((chain, i) => (
        <div key={i} className="flex flex-wrap items-center gap-1.5 rounded-lg border border-border/60 bg-background/40 p-2">
          <span className="w-full px-1 text-[10px] font-medium uppercase tracking-wider text-muted-foreground">{chain.title}</span>
          {chain.nodes.map((n, j) => {
            const meta = kindMeta(n.type);
            const Icon = meta.icon;
            return (
              <span key={n.id} className="flex min-w-0 items-center gap-1.5">
                {j > 0 ? <ArrowRight className="h-3 w-3 shrink-0 text-muted-foreground" /> : null}
                <button
                  type="button"
                  onClick={() => onSelect(n.id)}
                  title={meta.label}
                  className={cn(
                    "inline-flex min-w-0 max-w-[16rem] items-center gap-1.5 rounded-md border px-2 py-1 font-mono text-[11px] transition-colors",
                    selected === n.id ? "border-primary bg-primary/10" : "border-border/70 bg-card hover:border-primary/50",
                  )}
                >
                  <Icon className="h-3 w-3 shrink-0" style={{ color: meta.color }} />
                  <span className="truncate">{n.label}</span>
                </button>
              </span>
            );
          })}
        </div>
      ))}
    </div>
  );
}
