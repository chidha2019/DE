import { MessageSquare, MessageSquarePlus, Pencil, Plus, Sparkles, Star, Trash2 } from "lucide-react";
import { useState } from "react";

import type { GenieConversation, GenieSpace } from "@/api/types";
import { SpaceDialog } from "@/components/genie/space-dialog";
import { Companion } from "@/components/personas/companion";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { useDeleteGenieConversation, useDeleteGenieSpace, useGenieConversations } from "@/hooks/queries";
import { formatRelative } from "@/lib/format";
import { PERSONA_GENIE } from "@/lib/persona-genie";
import { cn } from "@/lib/utils";

interface SpaceRailProps {
  spaces: GenieSpace[] | undefined;
  loading: boolean;
  selectedSpaceId: string | null;
  conversationId: string | null;
  onSelectSpace: (spaceId: string) => void;
  onSelectConversation: (conversationId: string) => void;
  onNewChat: () => void;
}

function spaceAccent(space: GenieSpace): string | null {
  if (!space.persona) return null;
  const [h, s, l] = PERSONA_GENIE[space.persona].color;
  return `hsl(${h} ${s}% ${l}%)`;
}

/** A persona space shows its companion; the default space a spark; a custom space a chat glyph. */
function SpaceAvatar({ space }: { space: GenieSpace }) {
  if (space.persona) return <Companion persona={space.persona} size="2.4rem" interactive={false} still className="-my-1 shrink-0" />;
  return (
    <span className={cn("icon-tile h-9 w-9 shrink-0", !space.is_default && "border-border/80 bg-muted/60 text-muted-foreground")}>
      {space.is_default ? <Sparkles className="h-4 w-4" /> : <MessageSquare className="h-4 w-4" />}
    </span>
  );
}

/** Left column: curated spaces, then the saved conversations of the selected one. */
export function SpaceRail({ spaces, loading, selectedSpaceId, conversationId, onSelectSpace, onSelectConversation, onNewChat }: SpaceRailProps) {
  const [dialog, setDialog] = useState<{ open: boolean; space: GenieSpace | null }>({ open: false, space: null });
  const [pendingDelete, setPendingDelete] = useState<GenieSpace | GenieConversation | null>(null);
  const conversations = useGenieConversations(selectedSpaceId);
  const deleteSpace = useDeleteGenieSpace();
  const deleteConversation = useDeleteGenieConversation();
  const selected = spaces?.find((s) => s.id === selectedSpaceId) ?? null;

  const confirmDelete = async () => {
    if (!pendingDelete) return;
    if ("space_id" in pendingDelete) {
      await deleteConversation.mutateAsync(pendingDelete.id);
      if (pendingDelete.id === conversationId) onNewChat();
    } else {
      await deleteSpace.mutateAsync(pendingDelete.id);
      const fallback = spaces?.find((s) => s.is_default) ?? spaces?.find((s) => s.id !== pendingDelete.id);
      if (fallback) onSelectSpace(fallback.id);
    }
    setPendingDelete(null);
  };

  return (
    <aside className="flex w-[19rem] shrink-0 flex-col border-r border-border/80 bg-card/40 backdrop-blur">
      <div className="flex items-center justify-between px-4 pb-2 pt-4">
        <h2 className="text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">Spaces</h2>
        <Button variant="ghost" size="icon-sm" onClick={() => setDialog({ open: true, space: null })} aria-label="New space">
          <Plus className="h-4 w-4" />
        </Button>
      </div>
      <div className="space-y-1 px-2">
        {loading ? (
          <>
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
          </>
        ) : (
          spaces?.map((space) => {
            const active = space.id === selectedSpaceId;
            const accent = spaceAccent(space);
            return (
              <div key={space.id} className="group relative">
                <button
                  type="button"
                  onClick={() => onSelectSpace(space.id)}
                  className={cn(
                    "relative flex w-full items-center gap-3 overflow-hidden rounded-xl border border-transparent px-3 py-2 text-left text-sm transition-all hover:bg-accent/70",
                    active && "border-primary/40 bg-primary/10 shadow-glow",
                  )}
                >
                  {accent ? <span className="absolute inset-y-2 left-0 w-0.5 rounded-full" style={{ background: accent }} aria-hidden="true" /> : null}
                  <SpaceAvatar space={space} />
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-1.5">
                      <span className={cn("truncate", active && "font-medium")}>{space.name}</span>
                      {space.persona ? <span className="truncate text-[11px] text-muted-foreground">· {PERSONA_GENIE[space.persona].petName}</span> : null}
                      {space.is_default ? <Star className="h-3 w-3 shrink-0 text-warning" /> : null}
                    </span>
                    {space.description ? <span className="block truncate text-[11px] font-normal text-muted-foreground">{space.description}</span> : null}
                  </span>
                  <Badge variant={active ? "info" : "muted"} className="h-4 px-1.5 text-[10px]">
                    {space.conversation_count}
                  </Badge>
                </button>
                {active ? (
                  <div className="absolute right-1 top-1 hidden gap-0.5 group-hover:flex">
                    <Button variant="ghost" size="icon-sm" className="h-6 w-6 bg-accent" onClick={() => setDialog({ open: true, space })} aria-label="Edit space">
                      <Pencil className="h-3 w-3" />
                    </Button>
                    {!space.is_default && !space.persona ? (
                      <Button variant="ghost" size="icon-sm" className="h-6 w-6 bg-accent text-destructive" onClick={() => setPendingDelete(space)} aria-label="Delete space">
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    ) : null}
                  </div>
                ) : null}
              </div>
            );
          })
        )}
      </div>

      <div className="mt-5 flex items-center justify-between px-4 pb-2">
        <h2 className="text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">Conversations</h2>
        <Button variant="ghost" size="icon-sm" onClick={onNewChat} aria-label="New chat" disabled={!selected}>
          <MessageSquarePlus className="h-4 w-4" />
        </Button>
      </div>
      <div className="min-h-0 flex-1 space-y-1 overflow-y-auto px-2 pb-3">
        {conversations.isLoading ? (
          <Skeleton className="h-10 w-full" />
        ) : conversations.data?.items.length ? (
          conversations.data.items.map((c) => {
            const active = c.id === conversationId;
            return (
              <div key={c.id} className="group relative">
                <button
                  type="button"
                  onClick={() => onSelectConversation(c.id)}
                  className={cn(
                    "flex w-full items-start gap-2.5 rounded-xl border border-transparent px-3 py-2 text-left text-sm transition-all hover:bg-accent/70",
                    active && "border-primary/30 bg-primary/10",
                  )}
                >
                  <MessageSquare className={cn("mt-0.5 h-3.5 w-3.5 shrink-0", active ? "text-primary" : "text-muted-foreground")} />
                  <span className="min-w-0 flex-1">
                    <span className={cn("block truncate pr-5", active && "font-medium")}>{c.title}</span>
                    <span className="text-[11px] font-normal text-muted-foreground">
                      {c.message_count} messages · {formatRelative(c.last_message_at ?? c.updated_at)}
                    </span>
                  </span>
                </button>
                <Button
                  variant="ghost"
                  size="icon-sm"
                  className="absolute right-1 top-1 hidden h-6 w-6 bg-accent text-destructive group-hover:flex"
                  onClick={() => setPendingDelete(c)}
                  aria-label="Delete conversation"
                >
                  <Trash2 className="h-3 w-3" />
                </Button>
              </div>
            );
          })
        ) : (
          <p className="rounded-xl border border-dashed border-border/80 px-3 py-3 text-xs text-muted-foreground">No conversations yet. Ask something to start one.</p>
        )}
      </div>

      <SpaceDialog open={dialog.open} space={dialog.space} onClose={() => setDialog({ open: false, space: null })} onSaved={(s) => onSelectSpace(s.id)} />

      <Dialog open={pendingDelete !== null} onOpenChange={(o) => !o && setPendingDelete(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{pendingDelete && "space_id" in pendingDelete ? "Delete conversation?" : "Delete space?"}</DialogTitle>
            <DialogDescription>
              {pendingDelete && "space_id" in pendingDelete
                ? "The conversation and its messages are removed permanently."
                : "The space and every conversation in it are removed permanently."}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPendingDelete(null)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={confirmDelete} disabled={deleteSpace.isPending || deleteConversation.isPending}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </aside>
  );
}
