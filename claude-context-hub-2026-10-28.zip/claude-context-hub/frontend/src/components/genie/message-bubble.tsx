import { AlertTriangle, Check, Copy, FileText, Layers, Sparkles, ThumbsDown, ThumbsUp, User } from "lucide-react";
import { useState } from "react";
import { Link } from "react-router-dom";

import type { GenieCitation, GenieMessage } from "@/api/types";
import { Markdown } from "@/components/genie/markdown";
import { fromLive, fromTrace, TraceView } from "@/components/genie/trace-view";
import { Companion } from "@/components/personas/companion";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useGenieFeedback } from "@/hooks/queries";
import type { LiveAnswer } from "@/hooks/use-genie-chat";
import { formatCompact, formatDuration, formatRelative, formatScore } from "@/lib/format";
import { documentPath } from "@/lib/knowledge-paths";
import { PERSONA_GENIE } from "@/lib/persona-genie";
import type { PersonaKey } from "@/lib/personas";
import { cn } from "@/lib/utils";

function accentOf(persona: PersonaKey | null | undefined): string {
  if (!persona) return "hsl(var(--primary))";
  const [h, s, l] = PERSONA_GENIE[persona].color;
  return `hsl(${h} ${s}% ${l}%)`;
}

export function UserBubble({ message }: { message: GenieMessage }) {
  return (
    <div className="flex items-end justify-end gap-2.5">
      <div className="max-w-[80%] whitespace-pre-wrap rounded-2xl rounded-br-md bg-gradient-to-br from-primary to-primary/80 px-4 py-2.5 text-sm text-primary-foreground shadow-[0_14px_32px_-18px_hsl(var(--primary)/0.9)]">
        {message.content}
      </div>
      <span className="mb-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-primary/40 bg-primary/15 text-primary" aria-hidden="true">
        <User className="h-3.5 w-3.5" />
      </span>
    </div>
  );
}

interface AssistantBubbleProps {
  message: GenieMessage;
  onAsk: (question: string) => void;
  /** The persona whose space answered; its companion becomes the avatar. */
  persona?: PersonaKey | null;
}

export function AssistantBubble({ message, onAsk, persona = null }: AssistantBubbleProps) {
  const [copied, setCopied] = useState(false);
  const [highlight, setHighlight] = useState<string | null>(null);
  const feedback = useGenieFeedback();
  const failed = message.status === "error";
  const cancelled = message.status === "cancelled";
  const who = persona ? PERSONA_GENIE[persona].petName : "Genie";
  const accent = accentOf(persona);

  const copy = async () => {
    await navigator.clipboard.writeText(message.content);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1500);
  };

  const rate = (value: 1 | -1) => feedback.mutate({ messageId: message.id, value: message.feedback === value ? null : value });

  return (
    <div className="flex gap-3">
      <Avatar persona={persona} failed={failed} />
      <div className="min-w-0 flex-1 space-y-2">
        <div className={cn("overflow-hidden rounded-2xl rounded-tl-md border border-border/80 bg-card/90 shadow-sm backdrop-blur", failed && "border-destructive/40 bg-destructive/5")}>
          <div className="h-0.5 w-full" style={{ background: `linear-gradient(90deg, ${failed ? "hsl(var(--destructive))" : accent}, transparent 60%)` }} aria-hidden="true" />
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1 border-b border-border/60 px-4 py-1.5 text-[11px] text-muted-foreground">
            <span className="font-medium text-foreground">{who}</span>
            {message.model ? (
              <Badge variant="muted" className="h-4 px-1.5 font-mono text-[10px] font-normal">
                {message.model}
              </Badge>
            ) : null}
            {message.latency_ms !== null ? <span>{formatDuration(message.latency_ms / 1000)}</span> : null}
            {message.citations.length ? (
              <span>
                · {message.citations.length} source{message.citations.length === 1 ? "" : "s"}
              </span>
            ) : null}
            {message.trace.length ? (
              <span>
                · {message.trace.length} step{message.trace.length === 1 ? "" : "s"}
              </span>
            ) : null}
            <span className="flex-1" />
            <span>{formatRelative(message.created_at)}</span>
          </div>
          <div className="px-4 py-3">
            {failed ? (
              <div className="mb-2 flex items-start gap-2 text-sm text-destructive">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                <div>
                  <div className="font-medium">{who} could not finish this answer</div>
                  {message.error ? <div className="mt-0.5 font-mono text-xs opacity-80">{message.error}</div> : null}
                </div>
              </div>
            ) : null}
            {message.content ? <Markdown content={message.content} citations={message.citations} onCitation={(c) => setHighlight(c.marker)} /> : null}
            {cancelled ? <p className="mt-2 text-xs italic text-muted-foreground">Stopped before the answer was complete.</p> : null}
          </div>
        </div>

        {message.citations.length ? <Sources citations={message.citations} highlight={highlight} /> : null}
        <TraceView items={fromTrace(message.trace)} />

        {message.follow_ups.length ? (
          <div className="flex flex-wrap gap-1.5">
            {message.follow_ups.map((q) => (
              <button
                key={q}
                type="button"
                onClick={() => onAsk(q)}
                className="inline-flex items-center gap-1.5 rounded-full border border-primary/25 bg-primary/5 px-3 py-1 text-xs text-foreground transition-colors hover:border-primary/50 hover:bg-primary/10"
              >
                <Sparkles className="h-3 w-3 text-primary" />
                {q}
              </button>
            ))}
          </div>
        ) : null}

        <div className="flex flex-wrap items-center gap-1 text-[11px] text-muted-foreground">
          {message.usage.input_tokens ? (
            <span>
              {formatCompact(message.usage.input_tokens)} tokens in · {formatCompact(message.usage.output_tokens ?? 0)} out
            </span>
          ) : null}
          <span className="flex-1" />
          <Button variant="ghost" size="icon-sm" onClick={copy} aria-label="Copy answer">
            {copied ? <Check className="h-3.5 w-3.5 text-success" /> : <Copy className="h-3.5 w-3.5" />}
          </Button>
          <Button variant="ghost" size="icon-sm" onClick={() => rate(1)} aria-label="Good answer" className={cn(message.feedback === 1 && "text-success")}>
            <ThumbsUp className="h-3.5 w-3.5" />
          </Button>
          <Button variant="ghost" size="icon-sm" onClick={() => rate(-1)} aria-label="Poor answer" className={cn(message.feedback === -1 && "text-destructive")}>
            <ThumbsDown className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>
    </div>
  );
}

export function LiveBubble({ live, persona = null }: { live: LiveAnswer; persona?: PersonaKey | null }) {
  const items = fromLive(live.steps, live.narration);
  const thinking = !live.text && !live.steps.some((s) => !s.done);
  const who = persona ? PERSONA_GENIE[persona].petName : "Genie";
  return (
    <div className="flex gap-3">
      <Avatar persona={persona} pulse />
      <div className="min-w-0 flex-1 space-y-2">
        {items.length ? <TraceView items={items} defaultOpen title={live.text ? undefined : "Working…"} /> : null}
        <div className="overflow-hidden rounded-2xl rounded-tl-md border border-border/80 bg-card/90 shadow-sm backdrop-blur">
          <div className="h-0.5 w-full animate-pulse" style={{ background: `linear-gradient(90deg, ${accentOf(persona)}, transparent 60%)` }} aria-hidden="true" />
          <div className="px-4 py-3">
            {live.text ? (
              <Markdown content={live.text} />
            ) : (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <span className="flex gap-1">
                  <Dot delay="0ms" />
                  <Dot delay="150ms" />
                  <Dot delay="300ms" />
                </span>
                {who} is {thinking ? "thinking" : "reading the results"}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

/** Citations as chips: the marker, the kind, the title, the score; the clicked marker lights up. */
function Sources({ citations, highlight }: { citations: GenieCitation[]; highlight: string | null }) {
  const [open, setOpen] = useState(false);
  const limit = 6;
  const shown = open ? citations : citations.slice(0, limit);
  return (
    <div className="flex flex-wrap items-center gap-1.5">
      <span className="mr-1 text-[11px] font-medium text-muted-foreground">Sources · {citations.length}</span>
      {shown.map((c) => {
        const Icon = c.kind === "asset" ? Layers : FileText;
        return (
          <Link
            key={c.marker}
            id={`source-${c.marker}`}
            to={c.kind === "asset" ? `/semantic/${c.document_id}` : documentPath(c.document_id)}
            title={`${c.title}\n\n${c.snippet}`}
            className={cn(
              "inline-flex max-w-[24rem] items-center gap-1.5 rounded-full border border-border/80 bg-background/70 py-1 pl-1 pr-2.5 text-[11px] transition-colors hover:border-primary/50 hover:bg-primary/5",
              highlight === c.marker && "border-primary/60 bg-primary/10 shadow-glow",
            )}
          >
            <span className="flex h-4 min-w-[1.1rem] items-center justify-center rounded-full bg-primary/15 px-1 font-mono text-[10px] text-primary">{c.marker.replace(/^S/, "")}</span>
            <Icon className="h-3 w-3 shrink-0 text-muted-foreground" />
            <span className="truncate">{c.path ?? c.title}</span>
            {c.kind !== "asset" ? <span className="shrink-0 text-muted-foreground">{formatScore(c.score)}</span> : null}
          </Link>
        );
      })}
      {citations.length > limit ? (
        <button type="button" className="text-[11px] text-muted-foreground hover:text-foreground" onClick={() => setOpen((o) => !o)}>
          {open ? "Show fewer" : `+${citations.length - limit} more`}
        </button>
      ) : null}
    </div>
  );
}

function Avatar({ persona, failed, pulse }: { persona: PersonaKey | null; failed?: boolean; pulse?: boolean }) {
  if (persona) {
    return (
      <div className="mt-0.5 shrink-0">
        <Companion persona={persona} size="2.25rem" interactive={false} still mood={failed ? "sad" : pulse ? "thinking" : "idle"} />
      </div>
    );
  }
  return (
    <div className={cn("mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-xl border", failed ? "border-destructive/40 bg-destructive/15 text-destructive" : "icon-tile")}>
      <Sparkles className={cn("h-4 w-4", pulse && "animate-pulse")} />
    </div>
  );
}

function Dot({ delay }: { delay: string }) {
  return <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-muted-foreground/60" style={{ animationDelay: delay }} />;
}
