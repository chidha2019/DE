import { ArrowRight, Sparkles } from "lucide-react";
import { useEffect, useRef } from "react";

import type { GenieMessage, GenieSpace } from "@/api/types";
import { AssistantBubble, LiveBubble, UserBubble } from "@/components/genie/message-bubble";
import { Companion } from "@/components/personas/companion";
import { useOverview, useSemanticOverview } from "@/hooks/queries";
import type { LiveAnswer } from "@/hooks/use-genie-chat";
import { formatCompact } from "@/lib/format";
import type { PersonaKey } from "@/lib/personas";

interface ChatThreadProps {
  messages: GenieMessage[];
  live: LiveAnswer | null;
  error: string | null;
  onAsk: (question: string) => void;
  /** The persona whose space this is, so answers carry its companion. */
  persona?: PersonaKey | null;
}

export function ChatThread({ messages, live, error, onAsk, persona = null }: ChatThreadProps) {
  const bottom = useRef<HTMLDivElement>(null);
  const liveLength = live?.text.length ?? 0;
  const liveSteps = live?.steps.length ?? 0;
  useEffect(() => {
    bottom.current?.scrollIntoView({ block: "end", behavior: "smooth" });
  }, [messages.length, liveLength, liveSteps]);

  return (
    <div className="relative min-h-0 flex-1 overflow-y-auto px-6 py-5">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-40 bg-gradient-to-b from-primary/[0.06] to-transparent" aria-hidden="true" />
      <div className="relative mx-auto max-w-5xl space-y-5">
        {messages.map((m) => (m.role === "user" ? <UserBubble key={m.id} message={m} /> : <AssistantBubble key={m.id} message={m} onAsk={onAsk} persona={persona} />))}
        {live ? <LiveBubble live={live} persona={persona} /> : null}
        {error && !live ? <p className="text-center text-xs text-destructive">{error}</p> : null}
        <div ref={bottom} />
      </div>
    </div>
  );
}

/** First screen of a non-persona space: Genie's companion, what the space covers, live context, questions to try. */
export function EmptyState({ space, onAsk, disabled }: { space: GenieSpace | null; onAsk: (question: string) => void; disabled?: boolean }) {
  const overview = useOverview();
  const semantic = useSemanticOverview();
  const o = overview.data;
  const s = semantic.data;
  const stats: Array<{ label: string; value: number | undefined }> = [
    { label: "documents", value: o?.documents_total },
    { label: "catalog assets", value: s?.assets },
    { label: "governed metrics", value: s?.declared_metrics },
    { label: "graph nodes", value: o?.graph_nodes_total },
  ];
  return (
    <div className="min-h-0 flex-1 overflow-y-auto px-6 py-6">
      <div className="mx-auto max-w-5xl space-y-6">
        <section className="surface relative overflow-hidden p-6 md:p-8">
          <div className="hero-grid pointer-events-none absolute inset-0 opacity-60" aria-hidden="true" />
          <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-primary/20 blur-3xl" aria-hidden="true" />
          <div className="relative grid gap-6 md:grid-cols-[13rem_1fr] md:items-center">
            <div className="flex justify-center pt-10 md:justify-start">
              <Companion mood={disabled ? "sleeping" : "idle"} size="9rem" say={disabled ? "Zzz… no model configured." : "Ask me anything the hub has indexed."} bubble="top-left" />
            </div>
            <div className="min-w-0">
              <p className="text-[10px] font-medium uppercase tracking-[0.16em] text-primary">Genie · {space ? space.name : "the hub"}</p>
              <h2 className="mt-1 font-display text-2xl font-medium tracking-tight md:text-3xl">
                {space ? space.name : "Genie"}
                <span className="text-primary">.</span>
              </h2>
              <p className="mt-2 max-w-3xl text-sm text-muted-foreground">
                {space?.description || "Ask the hub a question in plain language. Genie searches the indexed sources, queries the knowledge graph read-only and cites what it used."}
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                {stats.map((st) => (
                  <span key={st.label} className="inline-flex items-baseline gap-1 rounded-full border border-border/80 bg-background/60 px-2.5 py-1 text-xs">
                    <span className="font-semibold tabular-nums">{st.value === undefined ? "…" : formatCompact(st.value)}</span>
                    <span className="text-muted-foreground">{st.label}</span>
                  </span>
                ))}
              </div>
            </div>
          </div>
        </section>

        {space?.sample_questions.length ? (
          <section>
            <div className="mb-3 flex flex-wrap items-center gap-2">
              <Sparkles className="h-4 w-4 text-primary" />
              <h3 className="text-sm font-medium">Try asking</h3>
              <span className="text-xs text-muted-foreground">Click one to send it.</span>
            </div>
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
              {space.sample_questions.map((q, i) => (
                <button
                  key={q}
                  type="button"
                  disabled={disabled}
                  onClick={() => onAsk(q)}
                  className="surface group flex items-start gap-3 p-4 text-left text-sm transition-all hover:-translate-y-0.5 hover:shadow-glow disabled:opacity-50 disabled:hover:translate-y-0 disabled:hover:shadow-none"
                >
                  <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-primary/50 text-[11px] font-semibold text-primary tabular-nums">{i + 1}</span>
                  <span className="min-w-0 flex-1 leading-snug">{q}</span>
                  <ArrowRight className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground opacity-0 transition-all group-hover:translate-x-0.5 group-hover:opacity-100" />
                </button>
              ))}
            </div>
          </section>
        ) : null}
      </div>
    </div>
  );
}
