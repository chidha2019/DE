import { useMemo } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

import type { GenieCitation } from "@/api/types";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

interface MarkdownProps {
  content: string;
  citations?: GenieCitation[];
  onCitation?: (citation: GenieCitation) => void;
  className?: string;
}

const MARKER = /\[(S\d+)\]/g;

/** Genie's answers: GitHub-flavoured markdown with `[S#]` markers rendered as citation chips. */
export function Markdown({ content, citations = [], onCitation, className }: MarkdownProps) {
  const prepared = useMemo(() => content.replace(MARKER, (_m, marker: string) => `[${marker}](#cite-${marker})`), [content]);
  const byMarker = useMemo(() => new Map(citations.map((c) => [c.marker, c])), [citations]);

  return (
    <div className={cn("text-sm [&>*:first-child]:mt-0 [&>*:last-child]:mb-0", className)}>
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          a: ({ href, children, node: _node, ...props }) => {
            if (href?.startsWith("#cite-")) {
              const marker = href.slice("#cite-".length);
              return <CitationChip marker={marker} citation={byMarker.get(marker)} onClick={onCitation} />;
            }
            return (
              <a href={href} target="_blank" rel="noreferrer" className="text-primary underline underline-offset-2" {...props}>
                {children}
              </a>
            );
          },
          p: ({ children, node: _node, ...props }) => (
            <p className="my-2 leading-relaxed" {...props}>
              {children}
            </p>
          ),
          ul: ({ children, node: _node, ...props }) => (
            <ul className="my-2 list-disc space-y-1 pl-5" {...props}>
              {children}
            </ul>
          ),
          ol: ({ children, node: _node, ...props }) => (
            <ol className="my-2 list-decimal space-y-1 pl-5" {...props}>
              {children}
            </ol>
          ),
          h1: ({ children, node: _node, ...props }) => (
            <h3 className="mb-1 mt-3 text-base font-medium" {...props}>
              {children}
            </h3>
          ),
          h2: ({ children, node: _node, ...props }) => (
            <h3 className="mb-1 mt-3 text-sm font-medium" {...props}>
              {children}
            </h3>
          ),
          h3: ({ children, node: _node, ...props }) => (
            <h4 className="mb-1 mt-2 text-sm font-medium" {...props}>
              {children}
            </h4>
          ),
          code: ({ children, className: codeClass, node: _node, ...props }) => {
            const block = Boolean(codeClass) || String(children).includes("\n");
            return block ? (
              <code className={cn("font-mono text-xs", codeClass)} {...props}>
                {children}
              </code>
            ) : (
              <code className="rounded bg-muted px-1 py-0.5 font-mono text-[0.85em]" {...props}>
                {children}
              </code>
            );
          },
          pre: ({ children, node: _node, ...props }) => (
            <pre className="my-2 overflow-x-auto rounded-md border bg-muted/50 p-3" {...props}>
              {children}
            </pre>
          ),
          table: ({ children, node: _node, ...props }) => (
            <div className="my-2 overflow-x-auto rounded-md border">
              <table className="w-full text-xs [&_td]:border-t [&_td]:px-2.5 [&_td]:py-1.5 [&_th]:bg-muted/60 [&_th]:px-2.5 [&_th]:py-1.5 [&_th]:text-left [&_th]:font-medium" {...props}>
                {children}
              </table>
            </div>
          ),
          blockquote: ({ children, node: _node, ...props }) => (
            <blockquote className="my-2 border-l-2 border-primary/40 pl-3 text-muted-foreground" {...props}>
              {children}
            </blockquote>
          ),
        }}
      >
        {prepared}
      </ReactMarkdown>
    </div>
  );
}

function CitationChip({ marker, citation, onClick }: { marker: string; citation?: GenieCitation; onClick?: (c: GenieCitation) => void }) {
  const number = marker.replace(/^S/, "");
  const chip = (
    <button
      type="button"
      onClick={() => citation && onClick?.(citation)}
      className={cn(
        "mx-0.5 inline-flex h-4 min-w-4 items-center justify-center rounded px-1 align-super text-[10px] font-medium leading-none",
        citation ? "bg-primary/15 text-primary hover:bg-primary/25" : "bg-muted text-muted-foreground",
      )}
      aria-label={citation ? `Source ${number}: ${citation.title}` : `Source ${number}`}
    >
      {number}
    </button>
  );
  if (!citation) return chip;
  return (
    <Tooltip>
      <TooltipTrigger asChild>{chip}</TooltipTrigger>
      <TooltipContent side="top" className="max-w-xs">
        <div className="text-xs font-medium">{citation.title}</div>
        {citation.path ? <div className="font-mono text-[10px] text-muted-foreground">{citation.path}</div> : null}
        <div className="mt-1 line-clamp-3 text-[11px] text-muted-foreground">{citation.snippet}</div>
      </TooltipContent>
    </Tooltip>
  );
}
