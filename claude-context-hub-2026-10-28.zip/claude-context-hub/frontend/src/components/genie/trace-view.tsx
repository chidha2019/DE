import { AlertCircle, ChevronDown, ChevronRight, Database, FileSearch, FileText, GitFork, Layers, Loader2, Network, Search, Share2 } from "lucide-react";
import { useState } from "react";

import type { GenieTraceStep } from "@/api/types";
import type { LiveStep } from "@/hooks/use-genie-chat";
import { cn } from "@/lib/utils";

const TOOL_ICON: Record<string, typeof Search> = {
  search_knowledge: Search,
  query_graph: Share2,
  find_documents: FileSearch,
  read_document: FileText,
  get_lineage: GitFork,
  explore_entity: Network,
  semantic_search: Layers,
  describe_asset: Database,
};

const TOOL_LABEL: Record<string, string> = {
  search_knowledge: "Searched the hub",
  query_graph: "Queried the graph",
  find_documents: "Looked up documents",
  read_document: "Read a document",
  get_lineage: "Followed lineage",
  explore_entity: "Explored an entity",
  semantic_search: "Searched the semantic layer",
  describe_asset: "Described an asset",
};

export interface TraceItem {
  step: number;
  tool: string;
  input: Record<string, unknown>;
  summary?: string;
  detail?: string | null;
  ok?: boolean;
  duration_ms?: number;
  rows?: number | null;
  narration?: string | null;
  running: boolean;
}

export function fromTrace(steps: GenieTraceStep[]): TraceItem[] {
  return steps.map((s) => ({ ...s, running: false }));
}

export function fromLive(steps: LiveStep[], narration: string[]): TraceItem[] {
  return steps.map((s, i) => ({
    step: s.step,
    tool: s.tool,
    input: s.input,
    summary: s.done?.summary,
    detail: s.done?.detail,
    ok: s.done?.ok,
    duration_ms: s.done?.duration_ms,
    rows: s.done?.rows,
    narration: s.done?.narration ?? (i === 0 ? narration[0] : narration[i]) ?? null,
    running: !s.done,
  }));
}

/** The "how Genie got this" panel: every tool call, with the Cypher that ran where there was one. */
export function TraceView({ items, defaultOpen = false, title }: { items: TraceItem[]; defaultOpen?: boolean; title?: string }) {
  const [open, setOpen] = useState(defaultOpen);
  if (items.length === 0) return null;
  const running = items.some((i) => i.running);
  const failed = items.filter((i) => i.ok === false).length;
  return (
    <div className="rounded-md border bg-muted/30 text-xs">
      <button type="button" onClick={() => setOpen((o) => !o)} className="flex w-full items-center gap-2 px-3 py-2 text-left text-muted-foreground hover:text-foreground">
        {open ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
        {running ? <Loader2 className="h-3.5 w-3.5 animate-spin text-primary" /> : null}
        <span className="font-medium">
          {title ?? (running ? "Working…" : "How Genie got this")} · {items.length} {items.length === 1 ? "step" : "steps"}
          {failed ? ` · ${failed} failed` : ""}
        </span>
      </button>
      {open ? (
        <ol className="space-y-2 border-t px-3 py-2">
          {items.map((item) => (
            <TraceStepRow key={item.step} item={item} />
          ))}
        </ol>
      ) : null}
    </div>
  );
}

function TraceStepRow({ item }: { item: TraceItem }) {
  const [expanded, setExpanded] = useState(false);
  const Icon = TOOL_ICON[item.tool] ?? Search;
  const label = item.summary ?? TOOL_LABEL[item.tool] ?? item.tool;
  const meta = [item.rows !== null && item.rows !== undefined ? `${item.rows} rows` : null, item.duration_ms !== undefined ? `${Math.round(item.duration_ms)} ms` : null].filter(Boolean).join(" · ");
  const detail = item.detail ?? (Object.keys(item.input).length ? JSON.stringify(item.input, null, 2) : null);
  return (
    <li>
      {item.narration ? <p className="mb-1 italic text-muted-foreground">{item.narration}</p> : null}
      <div className="flex items-start gap-2">
        <span className={cn("mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded bg-background", item.ok === false ? "text-destructive" : "text-primary")}>
          {item.running ? <Loader2 className="h-3 w-3 animate-spin" /> : item.ok === false ? <AlertCircle className="h-3 w-3" /> : <Icon className="h-3 w-3" />}
        </span>
        <div className="min-w-0 flex-1">
          <button type="button" onClick={() => detail && setExpanded((e) => !e)} className={cn("text-left", detail && "hover:underline")}>
            <span className={cn(item.ok === false && "text-destructive")}>{item.running ? `${TOOL_LABEL[item.tool] ?? item.tool}…` : label}</span>
            {meta ? <span className="ml-2 text-muted-foreground">{meta}</span> : null}
          </button>
          {expanded && detail ? <pre className="mt-1 overflow-x-auto rounded border bg-background p-2 font-mono text-[11px] leading-relaxed">{detail}</pre> : null}
        </div>
      </div>
    </li>
  );
}
