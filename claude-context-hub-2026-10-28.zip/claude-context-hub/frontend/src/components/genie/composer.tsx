import { ArrowUp, Square } from "lucide-react";
import { useEffect, useRef, useState, type KeyboardEvent } from "react";

import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

interface ComposerProps {
  onSend: (question: string) => void;
  onStop: () => void;
  pending: boolean;
  disabled?: boolean;
  disabledReason?: string | null;
  placeholder?: string;
  /** True while the box is focused or holds text; a companion can perk up on it. */
  onActivity?: (active: boolean) => void;
}

/** Enter sends, Shift+Enter adds a line; the box grows with the question. */
export function Composer({ onSend, onStop, pending, disabled, disabledReason, placeholder, onActivity }: ComposerProps) {
  const [value, setValue] = useState("");
  const [focused, setFocused] = useState(false);
  const ref = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    onActivity?.(focused || value.trim().length > 0);
  }, [focused, value, onActivity]);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.style.height = "auto"; // one row when empty; measured only once there is content
    if (value) el.style.height = `${Math.min(el.scrollHeight, 200)}px`;
  }, [value]);

  const submit = () => {
    const question = value.trim();
    if (!question || pending || disabled) return;
    onSend(question);
    setValue("");
  };

  const onKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submit();
    }
  };

  return (
    <div className="border-t bg-background/80 px-6 py-4 backdrop-blur">
      <div className="mx-auto max-w-5xl rounded-2xl bg-gradient-to-r from-primary/35 via-primary/10 to-primary/35 p-px shadow-[0_14px_40px_-26px_hsl(var(--primary)/0.7)] transition-colors focus-within:from-primary/70 focus-within:via-primary/30 focus-within:to-primary/70">
        <div className="flex items-end gap-2 rounded-[15px] bg-card p-2">
        <Textarea
          ref={ref}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          onKeyDown={onKeyDown}
          rows={1}
          disabled={disabled}
          placeholder={disabled ? disabledReason ?? "Genie is unavailable" : placeholder ?? "Ask about anything the hub has indexed…"}
          className="min-h-0 flex-1 resize-none border-0 bg-transparent px-2 py-1.5 shadow-none focus-visible:ring-0"
        />
        {pending ? (
          <Button size="icon-sm" variant="secondary" onClick={onStop} aria-label="Stop">
            <Square className="h-3.5 w-3.5" />
          </Button>
        ) : (
          <Button size="icon-sm" onClick={submit} disabled={disabled || !value.trim()} aria-label="Send">
            <ArrowUp className="h-4 w-4" />
          </Button>
        )}
        </div>
      </div>
      <p className="mx-auto mt-1.5 max-w-5xl text-center text-[11px] text-muted-foreground">Answers are grounded in indexed sources and cite them. Check the trace for the graph queries it ran.</p>
    </div>
  );
}
