import { Loader2 } from "lucide-react";
import { useEffect, useState } from "react";

import type { GenieSpace, GenieSpaceIn, SourceSystem } from "@/api/types";
import { SOURCE_SYSTEMS } from "@/api/types";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { useCreateGenieSpace, useUpdateGenieSpace } from "@/hooks/queries";
import { describeError } from "@/lib/api-client";

interface SpaceDialogProps {
  open: boolean;
  onClose: () => void;
  space?: GenieSpace | null; // editing when set
  onSaved?: (space: GenieSpace) => void;
}

interface Form {
  name: string;
  description: string;
  instructions: string;
  source_systems: SourceSystem[];
  repo: string;
  sample_questions: string;
}

const EMPTY: Form = { name: "", description: "", instructions: "", source_systems: [], repo: "", sample_questions: "" };

function toForm(space: GenieSpace): Form {
  const repo = space.filters.attributes?.repo;
  return {
    name: space.name,
    description: space.description,
    instructions: space.instructions,
    source_systems: space.filters.source_systems ?? [],
    repo: typeof repo === "string" ? repo : "",
    sample_questions: space.sample_questions.join("\n"),
  };
}

function toBody(form: Form): GenieSpaceIn {
  const attributes: Record<string, unknown> = {};
  if (form.repo.trim()) attributes.repo = form.repo.trim();
  return {
    name: form.name.trim(),
    description: form.description.trim(),
    instructions: form.instructions.trim(),
    filters: {
      source_systems: form.source_systems.length ? form.source_systems : null,
      attributes: Object.keys(attributes).length ? attributes : null,
    },
    sample_questions: form.sample_questions
      .split("\n")
      .map((q) => q.trim())
      .filter(Boolean)
      .slice(0, 12),
  };
}

/** Create or edit a Genie space: name, scope (source systems, repository), instructions, sample questions. */
export function SpaceDialog({ open, onClose, space, onSaved }: SpaceDialogProps) {
  const [form, setForm] = useState<Form>(EMPTY);
  const create = useCreateGenieSpace();
  const update = useUpdateGenieSpace();
  const pending = create.isPending || update.isPending;
  const error = create.error ?? update.error;

  useEffect(() => {
    if (open) setForm(space ? toForm(space) : EMPTY);
  }, [open, space]);

  const submit = async () => {
    if (!form.name.trim()) return;
    const body = toBody(form);
    const saved = space ? await update.mutateAsync({ id: space.id, body }) : await create.mutateAsync(body);
    onSaved?.(saved);
    onClose();
  };

  const toggleSource = (s: SourceSystem, on: boolean) =>
    setForm((f) => ({ ...f, source_systems: on ? [...f.source_systems, s] : f.source_systems.filter((x) => x !== s) }));

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{space ? "Edit space" : "New Genie space"}</DialogTitle>
          <DialogDescription>A space scopes what Genie may read and how it should answer, like a curated Genie space in Databricks.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-2">
          <div className="grid gap-1.5">
            <Label htmlFor="space-name">Name</Label>
            <Input id="space-name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. omniclaim lakehouse" />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="space-description">Description</Label>
            <Input id="space-description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="What this space covers; shown on the empty screen" />
          </div>
          <div className="grid gap-2 sm:grid-cols-2">
            <div className="grid gap-1.5">
              <Label>Source systems</Label>
              <div className="grid gap-1.5 rounded-md border p-2">
                {SOURCE_SYSTEMS.map((s) => (
                  <div key={s} className="flex items-center justify-between text-sm">
                    <span className="capitalize">{s}</span>
                    <Switch checked={form.source_systems.includes(s)} onCheckedChange={(on) => toggleSource(s, on)} aria-label={s} />
                  </div>
                ))}
                <p className="text-[11px] text-muted-foreground">None selected means all sources.</p>
              </div>
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="space-repo">Repository (document attribute)</Label>
              <Input id="space-repo" value={form.repo} onChange={(e) => setForm({ ...form, repo: e.target.value })} placeholder="owner/name" />
              <p className="text-[11px] text-muted-foreground">Limits search to documents whose `repo` attribute matches, e.g. a crawled GitHub repository.</p>
            </div>
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="space-instructions">Instructions</Label>
            <Textarea
              id="space-instructions"
              rows={3}
              value={form.instructions}
              onChange={(e) => setForm({ ...form, instructions: e.target.value })}
              placeholder="Standing guidance for answers in this space, e.g. 'Prefer config/assets.yml as the source of truth for table grain.'"
            />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="space-samples">Sample questions (one per line)</Label>
            <Textarea id="space-samples" rows={3} value={form.sample_questions} onChange={(e) => setForm({ ...form, sample_questions: e.target.value })} placeholder={"Which gold tables exist?\nWho maintains the ingestion code?"} />
          </div>
          {error ? <p className="text-sm text-destructive">{describeError(error)}</p> : null}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={submit} disabled={pending || !form.name.trim()}>
            {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
            {space ? "Save" : "Create space"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
