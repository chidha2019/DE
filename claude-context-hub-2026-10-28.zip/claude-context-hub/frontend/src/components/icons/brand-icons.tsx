import type { LucideIcon, LucideProps } from "lucide-react";
import { forwardRef } from "react";

/** Brand glyphs lucide no longer ships (it dropped brand icons in 1.0), shaped like lucide icons so maps of icons accept them. */
function brandIcon(name: string, path: string): LucideIcon {
  const Icon = forwardRef<SVGSVGElement, LucideProps>(({ size = 24, color = "currentColor", strokeWidth, absoluteStrokeWidth, ...rest }, ref) => {
    void strokeWidth;
    void absoluteStrokeWidth;
    return (
      <svg ref={ref} xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" fill={color} aria-hidden="true" {...rest}>
        <path d={path} />
      </svg>
    );
  });
  Icon.displayName = name;
  return Icon as LucideIcon;
}

export const GithubIcon = brandIcon(
  "GithubIcon",
  "M12 .3a12 12 0 0 0-3.8 23.38c.6.12.83-.26.83-.57L9 21.07c-3.34.72-4.04-1.61-4.04-1.61-.55-1.39-1.34-1.76-1.34-1.76-1.08-.74.09-.73.09-.73 1.2.09 1.84 1.24 1.84 1.24 1.07 1.83 2.81 1.3 3.5 1 .1-.78.42-1.31.76-1.61-2.67-.3-5.47-1.33-5.47-5.93 0-1.31.47-2.38 1.24-3.22-.14-.3-.54-1.52.1-3.18 0 0 1-.32 3.3 1.23a11.5 11.5 0 0 1 6 0c2.28-1.55 3.29-1.23 3.29-1.23.64 1.66.24 2.88.12 3.18a4.65 4.65 0 0 1 1.23 3.22c0 4.61-2.8 5.63-5.48 5.92.42.36.81 1.1.81 2.22l-.01 3.29c0 .31.2.69.82.57A12 12 0 0 0 12 .3",
);

export const GitlabIcon = brandIcon("GitlabIcon", "M12 21.6 22.6 13.9 20.2 3.4 16.9 10.2H7.1L3.8 3.4 1.4 13.9Z");
