import { AlertTriangle, Loader2, Plug, RotateCcw, Save, SlidersHorizontal, Target, Zap, type LucideIcon } from "lucide-react";
import { useMemo, useState } from "react";

import type { ConnectionDraft, ConnectionField, ConnectionOut } from "@/api/connections";
import type { ConnectorCatalogEntry } from "@/api/types";
import { BrandMark, brandColor } from "@/components/connectors/brand-mark";
import { FieldRow, type FormValue, type SecretState } from "@/components/connectors/connection-fields";
import { TestResultBanner } from "@/components/connectors/test-result";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { useConnection, useResetConnection, useSaveConnection, useTestConnection } from "@/hooks/connections";
import { describeError } from "@/lib/api-client";
import { formatRelative } from "@/lib/format";
import { cn } from "@/lib/utils";

const GROUP_ICON: Record<string, LucideIcon> = {
  Connection: Plug,
  Scope: Target,
  Options: SlidersHorizontal,
};
const EMPTY_SECRET: SecretState = { value: "", shown: false, clear: false };

function initialValue(field: ConnectionField): FormValue {
  if (field.kind === "bool") return field.value === true;
  return field.value === null || field.value === undefined ? "" : String(field.value);
}

type TestMutation = ReturnType<typeof useTestConnection>;

/** Edit, test and save one connection in a side panel; credentials are write-only. */
export function ConnectionEditor({ entry, onClose }: { entry: ConnectorCatalogEntry | null; onClose: () => void }) {
  const name = entry?.adapter ?? null;
  const connection = useConnection(name);
  const test = useTestConnection(name ?? "");
  const [savedAt, setSavedAt] = useState<string | null>(null);
  const close = () => {
    test.reset();
    setSavedAt(null);
    onClose();
  };
  return (
    <Dialog open={Boolean(entry)} onOpenChange={(open) => !open && close()}>
      <DialogContent className="left-auto right-0 top-0 flex h-full max-h-screen w-full max-w-xl translate-x-0 translate-y-0 flex-col gap-0 overflow-hidden p-0 data-[state=closed]:slide-out-to-right-1/4 data-[state=open]:slide-in-from-right-1/4 sm:rounded-none sm:rounded-l-2xl">
        {entry && name && connection.data ? (
          <EditorBody
            key={connection.dataUpdatedAt}
            entry={entry}
            name={name}
            connection={connection.data}
            test={test}
            savedAt={savedAt}
            onSaved={() => {
              setSavedAt(new Date().toISOString());
              test.mutate(undefined);
            }}
            onReset={() => {
              setSavedAt(null);
              test.reset();
            }}
          />
        ) : (
          <div className="space-y-4 p-6">
            <DialogTitle className="font-display text-xl">{entry ? `${entry.name} connection` : "Connection"}</DialogTitle>
            <DialogDescription>{connection.isError ? describeError(connection.error) : "Loading the connection settings…"}</DialogDescription>
            {connection.isError ? null : <Skeleton className="h-64 w-full" />}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function EditorBody({
  entry,
  name,
  connection,
  test,
  savedAt,
  onSaved,
  onReset,
}: {
  entry: ConnectorCatalogEntry;
  name: string;
  connection: ConnectionOut;
  test: TestMutation;
  savedAt: string | null;
  onSaved: () => void;
  onReset: () => void;
}) {
  const save = useSaveConnection(name);
  const reset = useResetConnection(name);
  const initial = useMemo(
    () => Object.fromEntries(connection.fields.filter((f) => f.kind !== "secret").map((f) => [f.name, initialValue(f)])) as Record<string, FormValue>,
    [connection],
  );
  const [values, setValues] = useState<Record<string, FormValue>>(initial);
  const [secrets, setSecrets] = useState<Record<string, SecretState>>({});
  const [confirmReset, setConfirmReset] = useState(false);

  const draft = useMemo<ConnectionDraft>(() => {
    const out: ConnectionDraft = { values: {}, secrets: {} };
    for (const f of connection.fields) {
      if (f.kind === "secret") {
        const s = secrets[f.name];
        if (s?.clear) out.secrets[f.name] = null;
        else if (s?.value.trim()) out.secrets[f.name] = s.value;
        continue;
      }
      const now = values[f.name];
      if (now !== undefined && now !== initial[f.name]) out.values[f.name] = f.kind === "number" ? Number(now) : now;
    }
    return out;
  }, [connection, values, secrets, initial]);
  const changes = Object.keys(draft.values).length + Object.keys(draft.secrets).length;
  const groups = useMemo(() => {
    const byGroup = new Map<string, ConnectionField[]>();
    for (const f of connection.fields) byGroup.set(f.group, [...(byGroup.get(f.group) ?? []), f]);
    return [...byGroup.entries()];
  }, [connection]);
  const fromHub = connection.fields.some((f) => f.source === "hub");
  const color = brandColor(entry.icon);
  const error = save.error ?? reset.error ?? test.error;

  return (
    <>
      <div
        className="relative shrink-0 border-b border-border/70 px-5 pb-4 pt-5"
        style={{
          background: `linear-gradient(180deg, ${color}30, transparent)`,
        }}
      >
        <div className="flex items-center gap-3 pr-8">
          <BrandMark icon={entry.icon} size="lg" />
          <div className="min-w-0">
            <DialogTitle className="font-display text-xl">{entry.name} connection</DialogTitle>
            <DialogDescription className="text-xs">
              {connection.registered ? "Live" : "Not connected yet"} ·{" "}
              {fromHub ? `saved in the hub${connection.updated_at ? ` ${formatRelative(connection.updated_at)}` : ""}` : "settings from .env"}
            </DialogDescription>
          </div>
        </div>
        {!connection.can_store_secrets ? (
          <p className="mt-3 flex items-start gap-2 rounded-lg border border-warning/40 bg-warning/10 px-3 py-2 text-xs text-warning">
            <AlertTriangle className="mt-px h-3.5 w-3.5 shrink-0" aria-hidden="true" />
            The service has no key to encrypt credentials: set ECH_SECRETS_KEY or make ECH_STATE_DIR writable. Other settings can still be saved.
          </p>
        ) : null}
      </div>

      <div className="flex-1 space-y-6 overflow-y-auto px-5 py-5">
        {groups.map(([group, fields]) => {
          const Icon = GROUP_ICON[group] ?? SlidersHorizontal;
          return (
            <section key={group}>
              <h3 className="mb-3 flex items-center gap-2 text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
                <span className="flex h-5 w-5 items-center justify-center rounded-md bg-muted">
                  <Icon className="h-3 w-3" aria-hidden="true" />
                </span>
                {group}
              </h3>
              <div className="grid gap-4 sm:grid-cols-2">
                {fields.map((f) => (
                  <div key={f.name} className={cn((f.kind === "secret" || f.kind === "list" || f.kind === "url" || f.kind === "bool") && "sm:col-span-2")}>
                    <FieldRow
                      field={f}
                      value={values[f.name] ?? ""}
                      secret={secrets[f.name] ?? EMPTY_SECRET}
                      changed={f.name in draft.values || f.name in draft.secrets}
                      onChange={(v) => setValues((prev) => ({ ...prev, [f.name]: v }))}
                      onSecret={(next) =>
                        setSecrets((prev) => ({
                          ...prev,
                          [f.name]: {
                            ...(prev[f.name] ?? EMPTY_SECRET),
                            ...next,
                          },
                        }))
                      }
                    />
                  </div>
                ))}
              </div>
            </section>
          );
        })}
        <p className="rounded-lg border border-dashed border-border/80 px-3 py-2 text-[11px] text-muted-foreground">
          Settings saved here override .env for this connector and take effect at once. Credentials are encrypted in the hub&apos;s database and never shown
          again; leave a credential blank to keep it.
        </p>
      </div>

      <div className="shrink-0 space-y-3 border-t border-border/70 bg-muted/25 px-5 py-4">
        {test.data ? <TestResultBanner result={test.data} /> : null}
        {error ? <p className="text-xs text-destructive">{describeError(error)}</p> : null}
        {savedAt ? <p className="text-xs text-success">Saved {formatRelative(savedAt)}: the connector was reloaded with these settings.</p> : null}
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="outline" className="gap-1.5" onClick={() => test.mutate(changes ? draft : undefined)} disabled={test.isPending}>
            {test.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Zap className="h-4 w-4" />}
            {changes ? "Test changes" : "Test connection"}
          </Button>
          {fromHub ? (
            <Button
              variant="ghost"
              className="gap-1.5 text-muted-foreground"
              disabled={reset.isPending}
              onClick={() => {
                if (!confirmReset) {
                  setConfirmReset(true);
                  return;
                }
                reset.mutate(undefined, { onSuccess: onReset });
              }}
            >
              <RotateCcw className="h-4 w-4" /> {confirmReset ? "Click again to reset" : "Reset to .env"}
            </Button>
          ) : null}
          <span className="ml-auto text-xs text-muted-foreground">{changes ? `${changes} unsaved change${changes === 1 ? "" : "s"}` : "No changes"}</span>
          <Button
            className="gap-1.5"
            disabled={!changes || save.isPending}
            onClick={() => save.mutate({ ...draft, updated_by: "Connectors page" }, { onSuccess: onSaved })}
          >
            {save.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Save
          </Button>
        </div>
      </div>
    </>
  );
}
