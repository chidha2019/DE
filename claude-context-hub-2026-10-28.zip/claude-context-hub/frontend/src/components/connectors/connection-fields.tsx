import { Eye, EyeOff, KeyRound, RotateCcw } from "lucide-react";

import type { ConnectionField } from "@/api/connections";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";

const SOURCE: Record<ConnectionField["source"], { label: string; cls: string }> = {
  hub: {
    label: "saved in hub",
    cls: "border-primary/40 bg-primary/10 text-primary",
  },
  env: {
    label: "from .env",
    cls: "border-border bg-muted/60 text-muted-foreground",
  },
  default: {
    label: "default",
    cls: "border-dashed border-border text-muted-foreground",
  },
};

export type FormValue = string | boolean;

export interface SecretState {
  value: string;
  shown: boolean;
  clear: boolean;
}

function items(value: string): string[] {
  return value
    .split(/[,\n]/)
    .map((s) => s.trim())
    .filter(Boolean);
}

export function FieldRow({
  field,
  value,
  secret,
  changed,
  onChange,
  onSecret,
}: {
  field: ConnectionField;
  value: FormValue;
  secret: SecretState;
  changed: boolean;
  onChange: (value: FormValue) => void;
  onSecret: (next: Partial<SecretState>) => void;
}) {
  const id = `conn-${field.name}`;
  const source = SOURCE[field.source];
  const label = (
    <div className="flex items-center justify-between gap-2">
      <Label htmlFor={id} className="text-xs font-medium">
        {field.label}
        {field.required ? <span className="ml-0.5 text-destructive">*</span> : null}
        {changed ? <span className="ml-1.5 rounded bg-warning/15 px-1 text-[10px] font-normal text-warning">changed</span> : null}
      </Label>
      <span className={cn("shrink-0 rounded-full border px-1.5 py-px text-[10px]", source.cls)}>{source.label}</span>
    </div>
  );
  const help = field.help ? <p className="text-[11px] text-muted-foreground">{field.help}</p> : null;

  if (field.kind === "bool") {
    return (
      <div className="flex items-center justify-between gap-3 rounded-xl border border-border/70 bg-background/60 px-3 py-2.5">
        <div className="min-w-0">
          <Label htmlFor={id} className="text-xs font-medium">
            {field.label}
          </Label>
          {help}
        </div>
        <Switch id={id} checked={value === true} onCheckedChange={(checked) => onChange(checked)} />
      </div>
    );
  }

  if (field.kind === "secret") {
    const placeholder = secret.clear
      ? "Back to the environment's value on save"
      : field.secret_set
        ? field.source === "hub"
          ? "Saved in the hub · type to replace"
          : "Set in .env · type to override"
        : "Not set";
    return (
      <div className="space-y-1.5">
        {label}
        <div className="relative">
          <KeyRound className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
          <Input
            id={id}
            type={secret.shown ? "text" : "password"}
            autoComplete="new-password"
            spellCheck={false}
            value={secret.value}
            disabled={secret.clear}
            placeholder={placeholder}
            onChange={(e) => onSecret({ value: e.target.value })}
            className="pl-8 pr-9 font-mono text-xs"
          />
          <button
            type="button"
            onClick={() => onSecret({ shown: !secret.shown })}
            className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-muted-foreground hover:text-foreground"
            aria-label={secret.shown ? "Hide what you typed" : "Show what you typed"}
          >
            {secret.shown ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
          </button>
        </div>
        {field.source === "hub" ? (
          <button
            type="button"
            onClick={() => onSecret({ clear: !secret.clear, value: "" })}
            className="inline-flex items-center gap-1 text-[11px] text-primary hover:underline"
          >
            <RotateCcw className="h-3 w-3" /> {secret.clear ? "Keep the value saved in the hub" : "Use the environment's value instead"}
          </button>
        ) : null}
        {help}
      </div>
    );
  }

  if (field.kind === "select") {
    return (
      <div className="space-y-1.5">
        {label}
        <Select value={String(value)} onValueChange={(v) => onChange(v)}>
          <SelectTrigger id={id} className="h-9 font-mono text-xs">
            <SelectValue placeholder={field.placeholder || "Choose"} />
          </SelectTrigger>
          <SelectContent>
            {field.options.map((o) => (
              <SelectItem key={o} value={o} className="font-mono text-xs">
                {o}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {help}
      </div>
    );
  }

  const text = String(value);
  return (
    <div className="space-y-1.5">
      {label}
      <Input
        id={id}
        type={field.kind === "number" ? "number" : field.kind === "url" ? "url" : "text"}
        min={field.kind === "number" ? 1 : undefined}
        spellCheck={false}
        value={text}
        placeholder={field.placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="h-9 font-mono text-xs"
      />
      {field.kind === "list" && items(text).length ? (
        <div className="flex flex-wrap gap-1">
          {items(text).map((item) => (
            <span key={item} className="rounded-md border border-border/70 bg-muted/50 px-1.5 py-px font-mono text-[10px]">
              {item}
            </span>
          ))}
        </div>
      ) : null}
      {help}
    </div>
  );
}
