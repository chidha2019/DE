import { CheckCircle2, XCircle } from "lucide-react";

import type { ConnectionTestResult } from "@/api/connections";
import { formatRelative } from "@/lib/format";
import { cn } from "@/lib/utils";

/** Up to `limit` short facts from a health check (account, role, warehouse, repositories…); errors and nested objects left out. */
export function healthFacts(details: Record<string, unknown>, limit = 4): [string, string][] {
  const out: [string, string][] = [];
  for (const [key, value] of Object.entries(details)) {
    if (out.length >= limit) break;
    if (key === "error" || value === null || value === undefined || value === "") continue;
    const label = key.replace(/_/g, " ").toLowerCase();
    if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
      out.push([label, String(value)]);
    } else if (Array.isArray(value) && value.length) {
      const strings = value.every((v) => typeof v === "string");
      out.push([label, strings && value.length <= 2 ? value.join(", ") : String(value.length)]);
    }
  }
  return out;
}

export function FactChips({ details, limit = 4, className }: { details: Record<string, unknown>; limit?: number; className?: string }) {
  const facts = healthFacts(details, limit);
  if (!facts.length) return null;
  return (
    <div className={cn("flex flex-wrap gap-1.5", className)}>
      {facts.map(([label, value]) => (
        <span key={label} className="inline-flex max-w-full items-center gap-1 rounded-md border border-border/70 bg-background/70 px-1.5 py-0.5 text-[11px]">
          <span className="text-muted-foreground">{label}</span>
          <span className="truncate font-mono">{value}</span>
        </span>
      ))}
    </div>
  );
}

export function TestResultBanner({ result, className }: { result: ConnectionTestResult; className?: string }) {
  const Icon = result.ok ? CheckCircle2 : XCircle;
  return (
    <div
      role="status"
      className={cn(
        "rounded-xl border px-3 py-2 text-xs",
        result.ok ? "border-success/40 bg-success/10" : "border-destructive/40 bg-destructive/10",
        className,
      )}
    >
      <div className={cn("flex items-start gap-2 font-medium", result.ok ? "text-success" : "text-destructive")}>
        <Icon className="mt-px h-4 w-4 shrink-0" aria-hidden="true" />
        <span className="min-w-0 break-words">
          {result.ok ? `Connected in ${result.latency_ms} ms` : `Failed after ${result.latency_ms} ms: ${result.error ?? "unknown error"}`}
          {result.draft ? " · with your unsaved changes" : ""}
        </span>
        <span className="ml-auto shrink-0 font-normal text-muted-foreground">{formatRelative(result.tested_at)}</span>
      </div>
      {result.ok ? <FactChips details={result.details} className="mt-2" /> : null}
    </div>
  );
}
