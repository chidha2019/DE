import { Activity, AlertTriangle, Clock, Compass, FileText, Loader2, Pencil, Play, Zap, type LucideIcon } from "lucide-react";
import { Link } from "react-router-dom";

import type { ConnectorCatalogEntry } from "@/api/types";
import { BrandMark, brandColor } from "@/components/connectors/brand-mark";
import { FactChips, TestResultBanner } from "@/components/connectors/test-result";
import { Button } from "@/components/ui/button";
import { useTestConnection } from "@/hooks/connections";
import { describeError } from "@/lib/api-client";
import { formatInt, formatRelative } from "@/lib/format";
import { cn } from "@/lib/utils";

function Metric({ icon: Icon, label, value, tone }: { icon: LucideIcon; label: string; value: string; tone?: "bad" }) {
  return (
    <div className={cn("min-w-0 rounded-xl border px-2.5 py-1.5", tone === "bad" ? "border-destructive/40 bg-destructive/5" : "border-border/60 bg-background/60")}>
      <div className={cn("truncate text-sm font-semibold tabular-nums", tone === "bad" && "text-destructive")}>{value}</div>
      <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
        <Icon className="h-3 w-3 shrink-0" aria-hidden="true" />
        <span className="truncate">{label}</span>
      </div>
    </div>
  );
}

function Health({ entry }: { entry: ConnectorCatalogEntry }) {
  const bad = entry.healthy === false;
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium",
        bad ? "border-destructive/40 bg-destructive/10 text-destructive" : "border-success/40 bg-success/10 text-success",
      )}
    >
      <span className="relative flex h-2 w-2">
        {!bad ? <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-success opacity-60" /> : null}
        <span className={cn("relative inline-flex h-2 w-2 rounded-full", bad ? "bg-destructive" : "bg-success")} />
      </span>
      {bad ? "Unhealthy" : "Healthy"}
      {entry.health_latency_ms !== null ? <span className="font-normal opacity-80">· {formatInt(entry.health_latency_ms)} ms</span> : null}
    </span>
  );
}

/** A live connection: health, what it has delivered, what its last check saw, and test, edit, run and browse. */
export function ConnectionCard({ entry, onEdit, onRun }: { entry: ConnectorCatalogEntry; onEdit: () => void; onRun: () => void }) {
  const name = entry.adapter ?? entry.key;
  const test = useTestConnection(name);
  const color = brandColor(entry.icon);
  const error = typeof entry.health_details.error === "string" ? entry.health_details.error : null;
  return (
    <article className="group relative flex flex-col overflow-hidden rounded-2xl border border-border/80 bg-card shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg">
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-28"
        style={{
          background: `linear-gradient(180deg, ${color}26, transparent)`,
        }}
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute -right-12 -top-20 h-48 w-48 rounded-full opacity-25 blur-3xl transition-opacity duration-300 group-hover:opacity-45"
        style={{ background: color }}
        aria-hidden="true"
      />
      <div className="relative flex-1 p-4">
        <div className="flex items-start gap-3">
          <BrandMark icon={entry.icon} size="lg" />
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
              <h3 className="font-display text-lg font-medium leading-tight">{entry.name}</h3>
              {entry.settings_source === "hub" ? (
                <span className="rounded-full border border-primary/40 bg-primary/10 px-1.5 py-px text-[10px] font-medium text-primary">edited in hub</span>
              ) : null}
            </div>
            <div className="truncate text-xs text-muted-foreground">{entry.vendor}</div>
          </div>
          <Health entry={entry} />
        </div>

        <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-2 xl:grid-cols-4">
          <Metric icon={FileText} label="documents" value={formatInt(entry.documents)} />
          <Metric icon={Activity} label="runs, 7 days" value={formatInt(entry.runs_7d)} />
          <Metric icon={AlertTriangle} label="failed, 7 days" value={formatInt(entry.failed_7d)} tone={entry.failed_7d ? "bad" : undefined} />
          <Metric icon={Clock} label="last good run" value={entry.last_success_at ? formatRelative(entry.last_success_at) : "never"} />
        </div>

        <FactChips details={entry.health_details} className="mt-3" />
        {error ? <p className="mt-3 line-clamp-2 text-xs text-destructive">{error}</p> : null}
        {test.data ? <TestResultBanner result={test.data} className="mt-3" /> : null}
        {test.isError ? <p className="mt-3 text-xs text-destructive">{describeError(test.error)}</p> : null}
      </div>

      <div className="relative flex flex-wrap items-center gap-1.5 border-t border-border/70 bg-muted/25 px-3 py-2.5">
        {entry.editable ? (
          <Button size="sm" variant="outline" className="h-8 gap-1.5" onClick={() => test.mutate(undefined)} disabled={test.isPending}>
            {test.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Zap className="h-3.5 w-3.5" />}
            {test.isPending ? "Testing…" : "Test"}
          </Button>
        ) : null}
        {entry.editable ? (
          <Button size="sm" variant="outline" className="h-8 gap-1.5" onClick={onEdit}>
            <Pencil className="h-3.5 w-3.5" /> Edit
          </Button>
        ) : null}
        {entry.adapter ? (
          <Button size="sm" variant="outline" className="h-8 gap-1.5" onClick={onRun}>
            <Play className="h-3.5 w-3.5" /> Run
          </Button>
        ) : null}
        <Button size="sm" variant="ghost" className="ml-auto h-8 gap-1.5 text-primary" asChild>
          <Link to={entry.adapter ? `/pipelines/new?connection=${encodeURIComponent(entry.adapter)}` : "/pipelines"}>
            <Compass className="h-3.5 w-3.5" /> {entry.adapter ? "Browse schema" : "Pipelines"}
          </Link>
        </Button>
      </div>
    </article>
  );
}
