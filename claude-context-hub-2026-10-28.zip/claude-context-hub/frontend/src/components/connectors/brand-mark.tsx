import { Archive, Cloud, Database, Fan, Gauge, Plug, Rabbit, Snowflake, Upload, type LucideIcon } from "lucide-react";
import type { ReactNode } from "react";

import { GithubIcon, GitlabIcon } from "@/components/icons/brand-icons";
import { cn } from "@/lib/utils";

/** A brand-coloured tile per connector: the vendor's colours with a recognisable glyph or wordmark. */
interface Brand {
  from: string;
  to: string;
  fg?: string;
  icon?: LucideIcon;
  glyph?: ReactNode;
  mark?: string;
}

const stroke = {
  fill: "none",
  stroke: "currentColor",
  strokeLinecap: "round",
  strokeLinejoin: "round",
} as const;

const BRANDS: Record<string, Brand> = {
  databricks: {
    from: "#FF5A36",
    to: "#E0301E",
    glyph: (
      <>
        <path d="M12 3.6 20.4 8.2 12 12.8 3.6 8.2Z" fill="currentColor" />
        <path d="M3.6 12.1 12 16.7l8.4-4.6" {...stroke} strokeWidth={2.2} />
        <path d="M3.6 15.9 12 20.5l8.4-4.6" {...stroke} strokeWidth={2.2} />
      </>
    ),
  },
  snowflake: { from: "#4FC6F0", to: "#1C8CC8", icon: Snowflake },
  azure: { from: "#3AA0F0", to: "#0063B1", icon: Cloud },
  s3: { from: "#F7A23B", to: "#C7511F", icon: Archive },
  postgres: { from: "#4A7FB5", to: "#2B5679", icon: Database },
  oracle: {
    from: "#E2453B",
    to: "#B5251C",
    glyph: <rect x="2.6" y="7.2" width="18.8" height="9.6" rx="4.8" {...stroke} strokeWidth={2.6} />,
  },
  mssql: { from: "#D93A3A", to: "#9E1F24", mark: "SQL" },
  trino: { from: "#F23DB3", to: "#B4007C", icon: Rabbit },
  github: { from: "#3A4049", to: "#16191D", icon: GithubIcon },
  gitlab: { from: "#FC8A3E", to: "#E2431E", icon: GitlabIcon },
  manual: { from: "#2BB3A3", to: "#137B70", icon: Upload },
  confluence: {
    from: "#3F8CFF",
    to: "#1855C9",
    glyph: (
      <>
        <path d="M4 17.4c2.7-3.9 5.8-5 9.4-3.5l6.6 2.9" {...stroke} strokeWidth={2.6} />
        <path d="M20 6.6c-2.7 3.9-5.8 5-9.4 3.5L4 7.2" {...stroke} strokeWidth={2.6} />
      </>
    ),
  },
  sharepoint: { from: "#13A3A3", to: "#03676B", mark: "S" },
  dbt: { from: "#FF7A57", to: "#E8462A", mark: "dbt" },
  airflow: { from: "#2C9BF5", to: "#0164BF", icon: Fan },
  tableau: {
    from: "#F08A3C",
    to: "#C7561A",
    glyph: (
      <>
        <path d="M12 7.2v9.6M7.2 12h9.6" {...stroke} strokeWidth={2.4} />
        <path d="M12 2.6v3M10.5 4.1h3M12 18.4v3M10.5 19.9h3M2.6 12h3M4.1 10.5v3M18.4 12h3M19.9 10.5v3" {...stroke} strokeWidth={1.5} />
        <path d="M5.4 5.4v2M4.4 6.4h2M18.6 5.4v2M17.6 6.4h2M5.4 16.6v2M4.4 17.6h2M18.6 16.6v2M17.6 17.6h2" {...stroke} strokeWidth={1.2} />
      </>
    ),
  },
  powerbi: {
    from: "#F7D84A",
    to: "#E2A80C",
    fg: "#3A2C00",
    glyph: (
      <>
        <rect x="4.6" y="11.4" width="3.6" height="8.4" rx="1.4" fill="currentColor" opacity="0.65" />
        <rect x="10.2" y="7.4" width="3.6" height="12.4" rx="1.4" fill="currentColor" opacity="0.82" />
        <rect x="15.8" y="3.6" width="3.6" height="16.2" rx="1.4" fill="currentColor" />
      </>
    ),
  },
  grafana: { from: "#FBB03B", to: "#EE5A0E", icon: Gauge },
  jira: {
    from: "#2684FF",
    to: "#0052CC",
    glyph: (
      <>
        <path d="M12 3.4 20.6 12 12 20.6 3.4 12Z" fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinejoin="round" />
        <path d="M12 8.6 15.4 12 12 15.4 8.6 12Z" fill="currentColor" />
      </>
    ),
  },
};

const SIZES = {
  xs: { box: "h-5 w-5 rounded-md", icon: "h-3 w-3", text: "text-[8px]" },
  sm: { box: "h-8 w-8 rounded-[10px]", icon: "h-4 w-4", text: "text-[10px]" },
  md: { box: "h-11 w-11 rounded-[14px]", icon: "h-5 w-5", text: "text-[12px]" },
  lg: { box: "h-14 w-14 rounded-[18px]", icon: "h-7 w-7", text: "text-[15px]" },
} as const;

export function BrandMark({ icon, size = "md", className }: { icon: string; size?: keyof typeof SIZES; className?: string }) {
  const brand = BRANDS[icon] ?? { from: "#64748B", to: "#334155", icon: Plug };
  const s = SIZES[size];
  const Icon = brand.icon;
  return (
    <span
      className={cn("relative isolate flex shrink-0 items-center justify-center overflow-hidden", s.box, className)}
      style={{
        background: `linear-gradient(145deg, ${brand.from}, ${brand.to})`,
        color: brand.fg ?? "#ffffff",
        boxShadow: `0 10px 22px -12px ${brand.to}, inset 0 1px 0 0 rgba(255,255,255,0.35), inset 0 0 0 1px rgba(255,255,255,0.14)`,
      }}
      aria-hidden="true"
    >
      <span className="pointer-events-none absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-white/30 to-transparent" />
      {Icon ? (
        <Icon className={cn("relative drop-shadow-sm", s.icon)} strokeWidth={2.2} />
      ) : brand.glyph ? (
        <svg viewBox="0 0 24 24" className={cn("relative drop-shadow-sm", s.icon)}>
          {brand.glyph}
        </svg>
      ) : (
        <span className={cn("relative font-display font-bold tracking-tight", s.text)}>{brand.mark}</span>
      )}
    </span>
  );
}

/** The brand's main colour, for accents around the mark. */
export function brandColor(icon: string): string {
  return (BRANDS[icon] ?? { to: "#64748B" }).to;
}
