import { BookText, CheckCircle2, Database, ExternalLink, Layers3, Settings2 } from "lucide-react";
import { Link } from "react-router-dom";

import type { ConnectorCatalogEntry } from "@/api/types";
import { BrandMark, brandColor } from "@/components/connectors/brand-mark";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { cn } from "@/lib/utils";

const FEEDS: Record<ConnectorCatalogEntry["feeds"], { label: string; icon: typeof Database }> = {
  semantic: { label: "Semantic hub", icon: Database },
  documents: { label: "Documents", icon: BookText },
  both: { label: "Semantic hub + documents", icon: Layers3 },
};

function Availability({ entry }: { entry: ConnectorCatalogEntry }) {
  const ready = entry.availability === "available";
  return (
    <span
      className={cn(
        "shrink-0 rounded-full border px-1.5 py-px text-[10px] font-medium",
        ready ? "border-primary/40 bg-primary/10 text-primary" : "border-border bg-muted/60 text-muted-foreground",
      )}
    >
      {ready ? "Ready" : "Planned"}
    </span>
  );
}

/** A connector not connected yet: compact, so the whole library fits on a screen. */
export function LibraryTile({ entry, onOpen }: { entry: ConnectorCatalogEntry; onOpen: () => void }) {
  const feeds = FEEDS[entry.feeds];
  return (
    <button
      type="button"
      onClick={onOpen}
      className="group relative flex items-start gap-3 overflow-hidden rounded-xl border border-border/80 bg-card/80 p-3 text-left transition-all duration-200 hover:-translate-y-0.5 hover:border-transparent hover:shadow-lg"
    >
      <span
        className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-200 group-hover:opacity-100"
        style={{
          background: `linear-gradient(135deg, ${brandColor(entry.icon)}1a, transparent 60%)`,
          boxShadow: `inset 0 0 0 1px ${brandColor(entry.icon)}55`,
        }}
        aria-hidden="true"
      />
      <BrandMark icon={entry.icon} size="md" className={cn(entry.availability === "planned" && "saturate-[0.85]")} />
      <span className="relative min-w-0 flex-1">
        <span className="flex items-center justify-between gap-2">
          <span className="truncate font-medium">{entry.name}</span>
          <Availability entry={entry} />
        </span>
        <span className="block truncate text-xs text-muted-foreground">{entry.vendor}</span>
        <span className="mt-1.5 flex items-center gap-1.5 text-[11px] text-muted-foreground">
          <feeds.icon className="h-3 w-3" aria-hidden="true" />
          <span className="truncate">
            {feeds.label} · {entry.capabilities.length} capabilities
          </span>
        </span>
      </span>
    </button>
  );
}

/** What a connector collects and what it needs; a ready adapter can be configured from here. */
export function ConnectorDetail({
  entry,
  onClose,
  onConfigure,
}: {
  entry: ConnectorCatalogEntry | null;
  onClose: () => void;
  onConfigure: (entry: ConnectorCatalogEntry) => void;
}) {
  const external = entry?.docs_url?.startsWith("http") ?? false;
  return (
    <Dialog open={Boolean(entry)} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-lg overflow-hidden p-0">
        {entry ? (
          <>
            <div
              className="relative px-6 pb-4 pt-6"
              style={{
                background: `linear-gradient(180deg, ${brandColor(entry.icon)}24, transparent)`,
              }}
            >
              <DialogHeader>
                <div className="flex items-center gap-3">
                  <BrandMark icon={entry.icon} size="lg" />
                  <div className="min-w-0 text-left">
                    <DialogTitle className="font-display text-xl">{entry.name}</DialogTitle>
                    <DialogDescription>{entry.vendor}</DialogDescription>
                  </div>
                  <span className="ml-auto self-start">
                    <Availability entry={entry} />
                  </span>
                </div>
              </DialogHeader>
              <p className="mt-3 text-sm text-muted-foreground">{entry.description}</p>
            </div>
            <div className="space-y-4 px-6 pb-6">
              <div>
                <div className="text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">What it collects</div>
                <ul className="mt-2 grid gap-1.5 text-sm sm:grid-cols-2">
                  {entry.capabilities.map((c) => (
                    <li key={c} className="flex items-start gap-2">
                      <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" aria-hidden="true" />
                      {c}
                    </li>
                  ))}
                </ul>
              </div>
              {entry.env_vars.length ? (
                <div>
                  <div className="text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
                    {entry.availability === "planned" ? "Settings it will need" : "Settings"}
                  </div>
                  <div className="mt-2 flex flex-wrap gap-1">
                    {entry.env_vars.map((name) => (
                      <code key={name} className="rounded-md border border-border/70 bg-muted/50 px-1.5 py-0.5 font-mono text-[11px]">
                        {name}
                      </code>
                    ))}
                  </div>
                  <p className="mt-2 text-xs text-muted-foreground">
                    {entry.availability === "planned"
                      ? "On the roadmap: the card shows the scope before the adapter lands."
                      : entry.editable
                        ? "Configure it here, or set these in the root .env. Credentials are encrypted and never shown again."
                        : "Set these in the root .env and restart the ingestion service."}
                  </p>
                </div>
              ) : null}
              <div className="flex flex-wrap justify-end gap-2">
                {entry.docs_url ? (
                  <Button size="sm" variant="outline" asChild>
                    {external ? (
                      <a href={entry.docs_url} target="_blank" rel="noreferrer">
                        Vendor documentation <ExternalLink className="h-3 w-3" />
                      </a>
                    ) : (
                      <Link to={entry.docs_url}>Open</Link>
                    )}
                  </Button>
                ) : null}
                {entry.editable && entry.availability !== "planned" ? (
                  <Button size="sm" onClick={() => onConfigure(entry)}>
                    <Settings2 className="h-3.5 w-3.5" /> Configure connection
                  </Button>
                ) : null}
              </div>
            </div>
          </>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}
