import type { LucideIcon } from "lucide-react";
import type { ReactNode } from "react";

import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

interface MetricCardProps {
  title: string;
  value: ReactNode;
  hint?: ReactNode;
  icon: LucideIcon;
  tone?: "default" | "success" | "warning" | "destructive";
  loading?: boolean;
}

const TONES: Record<NonNullable<MetricCardProps["tone"]>, string> = {
  default: "border-primary/30 bg-primary/10 text-primary",
  success: "border-success/30 bg-success/10 text-success",
  warning: "border-warning/30 bg-warning/10 text-warning",
  destructive: "border-destructive/30 bg-destructive/10 text-destructive",
};

/** A stat tile: icon chip on the left, label, big number, one-line hint. */
export function MetricCard({ title, value, hint, icon: Icon, tone = "default", loading }: MetricCardProps) {
  return (
    <Card className="surface">
      <CardContent className="flex items-center gap-4 p-5">
        <div className={cn("flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border shadow-[inset_0_1px_0_0_hsl(var(--primary)/0.2)]", TONES[tone])}>
          <Icon className="h-5 w-5" />
        </div>
        <div className="min-w-0">
          <div className="text-xs font-medium text-muted-foreground">{title}</div>
          {loading ? <Skeleton className="mt-1 h-7 w-20" /> : <div className="tabular mt-0.5 truncate font-display text-2xl font-medium leading-tight">{value}</div>}
          {hint ? <div className="mt-0.5 truncate text-[11px] text-muted-foreground">{hint}</div> : null}
        </div>
      </CardContent>
    </Card>
  );
}
