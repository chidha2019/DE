import { Skeleton } from "@/components/ui/skeleton";
import { formatInt } from "@/lib/format";
import { cn } from "@/lib/utils";

interface BreakdownProps {
  data: Record<string, number> | undefined;
  loading?: boolean;
  colors?: Record<string, string>;
  emptyLabel?: string;
}

const DEFAULT_COLORS: Record<string, string> = {
  confluence: "bg-blue-500",
  sharepoint: "bg-teal-500",
  github: "bg-slate-400",
  manual: "bg-amber-500",
  Document: "bg-entity-document",
  Chunk: "bg-entity-chunk",
  Entity: "bg-primary",
  Person: "bg-entity-person",
  Project: "bg-entity-project",
  Technology: "bg-entity-technology",
  Concept: "bg-entity-concept",
  HAS_CHUNK: "bg-slate-400",
  MENTIONS: "bg-primary",
  REFERENCES: "bg-blue-500",
  DEPENDS_ON: "bg-emerald-500",
  CONTRIBUTED_BY: "bg-amber-500",
};

/** Horizontal bar list for small categorical breakdowns (documents by source, graph by label). */
export function SourceBreakdown({ data, loading, colors = DEFAULT_COLORS, emptyLabel = "No data yet" }: BreakdownProps) {
  if (loading || !data) {
    return (
      <div className="space-y-3">
        {[0, 1, 2].map((i) => (
          <Skeleton key={i} className="h-5 w-full" />
        ))}
      </div>
    );
  }
  const entries = Object.entries(data).sort((a, b) => b[1] - a[1]);
  const max = Math.max(1, ...entries.map(([, v]) => v));
  if (entries.length === 0 || entries.every(([, v]) => v === 0)) {
    return <div className="text-sm text-muted-foreground">{emptyLabel}</div>;
  }
  return (
    <ul className="space-y-2.5">
      {entries.map(([name, value]) => (
        <li key={name} className="text-sm">
          <div className="mb-1 flex items-center justify-between">
            <span className="capitalize">{name}</span>
            <span className="tabular text-muted-foreground">{formatInt(value)}</span>
          </div>
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
            <div className={cn("h-full rounded-full", colors[name] ?? "bg-primary")} style={{ width: `${Math.max(2, (value / max) * 100)}%` }} />
          </div>
        </li>
      ))}
    </ul>
  );
}
