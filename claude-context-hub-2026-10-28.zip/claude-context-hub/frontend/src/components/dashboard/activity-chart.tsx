import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis, type TooltipProps } from "recharts";

import type { RunActivityPoint } from "@/api/types";
import { Skeleton } from "@/components/ui/skeleton";
import { formatInt, formatTime } from "@/lib/format";

interface ActivityChartProps {
  points: RunActivityPoint[] | undefined;
  loading?: boolean;
  height?: number;
  /** Axis label for a bucket start; defaults to the time of day, which suits hourly buckets. */
  label?: (iso: string) => string;
}

export const OUTCOMES = [
  { key: "completed", label: "Completed", color: "#10B981" },
  { key: "failed", label: "Failed", color: "#EF4444" },
  { key: "cancelled", label: "Cancelled", color: "#F59E0B" },
] as const;

function Tip({ active, payload, label }: TooltipProps<number, string>) {
  if (!active || !payload?.length) return null;
  const row = payload[0]?.payload as RunActivityPoint & { t: string };
  return (
    <div className="rounded-xl border border-border/80 bg-popover px-3 py-2 text-xs text-popover-foreground shadow-lg">
      <div className="mb-1 font-medium">{label}</div>
      {OUTCOMES.map((o) => (
        <div key={o.key} className="flex items-center justify-between gap-4">
          <span className="flex items-center gap-1.5 text-muted-foreground">
            <span className="h-2 w-2 rounded-sm" style={{ background: o.color }} /> {o.label}
          </span>
          <span className="font-mono tabular-nums">{formatInt(row[o.key])}</span>
        </div>
      ))}
      <div className="mt-1 border-t border-border/60 pt-1 text-muted-foreground">{formatInt(row.documents)} documents</div>
    </div>
  );
}

/** Run outcomes per bucket as stacked bars with soft gradients; the tooltip adds the documents each bucket landed. */
export function ActivityChart({ points, loading, height = 220, label = formatTime }: ActivityChartProps) {
  if (loading || !points) return <Skeleton style={{ height }} className="w-full" />;
  if (points.length === 0) {
    return (
      <div style={{ height }} className="flex items-center justify-center text-sm text-muted-foreground">
        No ingestion runs in this window.
      </div>
    );
  }
  const data = points.map((p) => ({ t: label(p.bucket_start), ...p }));
  return (
    <div className="w-full">
      <div style={{ height }} className="w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: -20 }} barCategoryGap="28%">
            <defs>
              {OUTCOMES.map((o) => (
                <linearGradient key={o.key} id={`activity-${o.key}`} x1="0" x2="0" y1="0" y2="1">
                  <stop offset="0%" stopColor={o.color} stopOpacity={0.95} />
                  <stop offset="100%" stopColor={o.color} stopOpacity={0.55} />
                </linearGradient>
              ))}
            </defs>
            <CartesianGrid stroke="#64748b" strokeOpacity={0.14} strokeDasharray="3 4" vertical={false} />
            <XAxis dataKey="t" tick={{ fontSize: 11, fill: "#64748b" }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11, fill: "#64748b" }} axisLine={false} tickLine={false} allowDecimals={false} />
            <Tooltip content={<Tip />} cursor={{ fill: "hsl(var(--primary) / 0.06)", radius: 8 }} />
            {OUTCOMES.map((o) => (
              <Bar key={o.key} dataKey={o.key} name={o.label} stackId="runs" fill={`url(#activity-${o.key})`} radius={[6, 6, 2, 2]} maxBarSize={44} />
            ))}
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-1 flex flex-wrap justify-center gap-3 text-[11px] text-muted-foreground">
        {OUTCOMES.map((o) => (
          <span key={o.key} className="inline-flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-sm" style={{ background: o.color }} /> {o.label}
          </span>
        ))}
      </div>
    </div>
  );
}
