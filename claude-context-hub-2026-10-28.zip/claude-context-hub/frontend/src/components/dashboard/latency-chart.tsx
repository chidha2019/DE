import { Area, Bar, CartesianGrid, ComposedChart, Legend, Line, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

import type { LatencySeries } from "@/api/types";
import { Skeleton } from "@/components/ui/skeleton";
import { formatMs, formatTime } from "@/lib/format";

interface LatencyChartProps {
  series: LatencySeries | undefined;
  loading?: boolean;
  height?: number;
}

const TOOLTIP_STYLE = {
  background: "hsl(var(--popover))",
  border: "1px solid hsl(var(--border))",
  borderRadius: 8,
  color: "hsl(var(--popover-foreground))",
  fontSize: 12,
};

export function LatencyChart({ series, loading, height = 260 }: LatencyChartProps) {
  if (loading || !series) return <Skeleton style={{ height }} className="w-full" />;

  const data = series.points.map((p) => ({
    t: formatTime(p.bucket_start),
    p50: p.p50_ms || null,
    p95: p.p95_ms || null,
    p99: p.p99_ms || null,
    count: p.count,
  }));
  const hasData = data.some((d) => d.count > 0);

  return (
    <div style={{ height }} className="relative w-full">
      {!hasData ? (
        <div className="absolute inset-0 z-10 flex items-center justify-center text-sm text-muted-foreground">
          No requests in the last {series.window_minutes} minutes — call the API to populate this chart.
        </div>
      ) : null}
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={data} margin={{ top: 8, right: 12, bottom: 0, left: -8 }}>
          <CartesianGrid stroke="#64748b" strokeOpacity={0.2} vertical={false} />
          <XAxis dataKey="t" tick={{ fontSize: 11 }} stroke="#64748b" minTickGap={28} />
          <YAxis yAxisId="ms" tick={{ fontSize: 11 }} stroke="#64748b" tickFormatter={(v: number) => formatMs(v, 0)} width={64} />
          <YAxis yAxisId="count" orientation="right" tick={{ fontSize: 11 }} stroke="#64748b" allowDecimals={false} width={32} />
          <Tooltip
            contentStyle={TOOLTIP_STYLE}
            formatter={(value, name) => [name === "requests" ? String(value) : formatMs(Number(value)), String(name)]}
          />
          <Legend wrapperStyle={{ fontSize: 12 }} />
          <Bar yAxisId="count" dataKey="count" name="requests" fill="#64748b" fillOpacity={0.25} radius={[2, 2, 0, 0]} />
          <Area yAxisId="ms" type="monotone" dataKey="p95" name="p95" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.12} strokeWidth={2} connectNulls />
          <Line yAxisId="ms" type="monotone" dataKey="p50" name="p50" stroke="#3b82f6" strokeWidth={2} dot={false} connectNulls />
          <Line yAxisId="ms" type="monotone" dataKey="p99" name="p99" stroke="#f43f5e" strokeWidth={1.5} strokeDasharray="4 3" dot={false} connectNulls />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}
