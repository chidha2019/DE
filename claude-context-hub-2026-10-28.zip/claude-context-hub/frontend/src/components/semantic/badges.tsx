import { Clock, KeyRound, Sigma, Tag, Type, type LucideIcon } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const ROLE_CLASS: Record<string, string> = {
  identifier: "border-transparent bg-slate-500/15 text-slate-600 dark:text-slate-300",
  dimension: "border-transparent bg-blue-500/15 text-blue-600 dark:text-blue-300",
  time: "border-transparent bg-violet-500/15 text-violet-600 dark:text-violet-300",
  measure: "border-transparent bg-emerald-500/15 text-emerald-600 dark:text-emerald-300",
  attribute: "border-transparent bg-muted text-muted-foreground",
};

const KIND_CLASS: Record<string, string> = {
  fact: "border-transparent bg-emerald-500/15 text-emerald-600 dark:text-emerald-300",
  dimension: "border-transparent bg-blue-500/15 text-blue-600 dark:text-blue-300",
  bridge: "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-300",
  metric: "border-transparent bg-rose-500/15 text-rose-600 dark:text-rose-300",
  reference: "border-transparent bg-cyan-500/15 text-cyan-600 dark:text-cyan-300",
  unknown: "border-transparent bg-muted text-muted-foreground",
};

const RELATIONSHIP_LABEL: Record<string, string> = {
  foreign_key: "foreign key",
  join_declared: "declared join",
  join_inferred: "inferred join",
  lineage_upstream: "reads from",
  lineage_downstream: "feeds",
  metric_source: "defined over",
};

const ROLE_ICON: Record<string, LucideIcon> = { identifier: KeyRound, dimension: Tag, time: Clock, measure: Sigma, attribute: Type };

interface NameSourceMeta {
  label: string;
  variant: "muted" | "info" | "success" | "warning";
  hint: string;
}

const DERIVED_NAME: NameSourceMeta = { label: "derived name", variant: "muted", hint: "Business name derived from the technical name" };

const NAME_SOURCE: Record<string, NameSourceMeta> = {
  derived: DERIVED_NAME,
  declared: { label: "declared", variant: "info", hint: "Name declared on the platform" },
  model: { label: "named by Claude", variant: "success", hint: "Suggested by Claude and accepted as-is" },
  curated: { label: "curated", variant: "success", hint: "Edited and accepted by a person" },
};

export function NameSourceBadge({ source }: { source: string }) {
  const meta = NAME_SOURCE[source] ?? DERIVED_NAME;
  return (
    <Badge variant={meta.variant} className="h-5 px-1.5 text-[10px]" title={meta.hint}>
      {meta.label}
    </Badge>
  );
}

export function RoleBadge({ role, aggregation }: { role: string; aggregation?: string | null }) {
  const Icon = ROLE_ICON[role] ?? Type;
  return (
    <Badge variant="outline" className={cn("h-5 gap-1 px-1.5 text-[10px] font-medium", ROLE_CLASS[role] ?? ROLE_CLASS.attribute)}>
      <Icon className="h-3 w-3" />
      {role}
      {aggregation ? ` · ${aggregation}` : ""}
    </Badge>
  );
}

export function KindBadge({ kind }: { kind: string }) {
  return (
    <Badge variant="outline" className={cn("h-5 px-1.5 text-[10px] font-medium", KIND_CLASS[kind] ?? KIND_CLASS.unknown)}>
      {kind === "unknown" ? "unclassified" : kind}
    </Badge>
  );
}

export function TypeBadge({ assetType }: { assetType: string }) {
  return (
    <Badge variant="muted" className="h-5 px-1.5 font-mono text-[10px]">
      {assetType.replace(/_/g, " ")}
    </Badge>
  );
}

export function PlatformBadge({ platform }: { platform: string }) {
  return (
    <Badge variant={platform === "databricks" ? "warning" : "info"} className="h-5 px-1.5 text-[10px] capitalize">
      {platform}
    </Badge>
  );
}

export function relationshipLabel(kind: string): string {
  return RELATIONSHIP_LABEL[kind] ?? kind.replace(/_/g, " ");
}

export function MetricSourceBadge({ source }: { source: string }) {
  return (
    <Badge variant={source === "inferred" ? "muted" : "success"} className="h-5 px-1.5 text-[10px]">
      {source}
    </Badge>
  );
}
