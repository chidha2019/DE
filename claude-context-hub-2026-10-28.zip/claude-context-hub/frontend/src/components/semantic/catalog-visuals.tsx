import { GitFork, Landmark, ListTree, Sigma, Tags, Target, type LucideIcon } from "lucide-react";

import type { CatalogCounts, CatalogObjectType, QualityCheck } from "@/api/types";
import { formatInt } from "@/lib/format";
import { cn } from "@/lib/utils";

export interface TypeMeta {
  label: string;
  plural: string;
  icon: LucideIcon;
  color: string;
  countKey: Exclude<keyof CatalogCounts, "total">;
  hint: string;
}

export const OBJECT_TYPES: CatalogObjectType[] = ["entity", "dimension", "measure", "metric", "relationship", "hierarchy"];

/** One hue, icon and explanation per semantic object type. */
export const TYPE_META: Record<CatalogObjectType, TypeMeta> = {
  entity: { label: "Table", plural: "Tables", icon: Landmark, color: "217 85% 60%", countKey: "entities", hint: "One per table or view: what a row of it is about (a policy, a claim, an agent)" },
  dimension: { label: "Dimension", plural: "Dimensions", icon: Tags, color: "199 90% 55%", countKey: "dimensions", hint: "Columns you group and filter by: dates, statuses, codes, names" },
  measure: { label: "Measure", plural: "Measures", icon: Sigma, color: "160 70% 45%", countKey: "measures", hint: "Numeric columns you add up: amounts, premiums, counts" },
  metric: { label: "Metric", plural: "Metrics", icon: Target, color: "347 77% 58%", countKey: "metrics", hint: "Calculations such as Total Face Amount, plus the KPI definitions written in the glossary" },
  relationship: { label: "Link", plural: "Links", icon: GitFork, color: "28 90% 55%", countKey: "relationships", hint: "How tables connect: keys, joins and lineage" },
  hierarchy: { label: "Hierarchy", plural: "Hierarchies", icon: ListTree, color: "262 70% 62%", countKey: "hierarchies", hint: "Drill paths found in column names, such as year → quarter → month" },
};

export const typeColor = (type: CatalogObjectType): string => TYPE_META[type].color;

/** Green from 75, amber from 50, red below. */
export function qualityTone(value: number): string {
  return value >= 75 ? "160 70% 45%" : value >= 50 ? "45 90% 50%" : "0 70% 55%";
}

export function checksTitle(checks: QualityCheck[]): string {
  return checks.map((c) => `${c.ok ? "✓" : "✗"} ${c.name}`).join("\n");
}

export function QualityBar({ value, checks, className, width = "w-16" }: { value: number; checks?: QualityCheck[]; className?: string; width?: string }) {
  const tone = qualityTone(value);
  return (
    <span className={cn("inline-flex items-center gap-2", className)} title={checks?.length ? checksTitle(checks) : `${value} / 100`}>
      <span className={cn("h-1.5 overflow-hidden rounded-full bg-muted", width)}>
        <span className="block h-full rounded-full transition-all" style={{ width: `${Math.max(0, Math.min(100, value))}%`, background: `hsl(${tone})` }} />
      </span>
      <span className="font-mono text-[11px] tabular-nums" style={{ color: `hsl(${tone})` }}>
        {value}
      </span>
    </span>
  );
}

export function TypeChip({ type, className }: { type: CatalogObjectType; className?: string }) {
  const meta = TYPE_META[type];
  return (
    <span className={cn("inline-flex items-center gap-1 whitespace-nowrap rounded-md px-1.5 py-0.5 text-[10px] font-medium", className)} style={{ background: `hsl(${meta.color} / 0.15)`, color: `hsl(${meta.color})` }} title={meta.hint}>
      <meta.icon className="h-3 w-3" /> {meta.label}
    </span>
  );
}

export function TypeTile({ type, className, iconClass = "h-4 w-4" }: { type: CatalogObjectType; className?: string; iconClass?: string }) {
  const meta = TYPE_META[type];
  return (
    <span className={cn("flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border text-white", className)} style={{ background: `linear-gradient(135deg, hsl(${meta.color}), hsl(${meta.color} / 0.65))`, borderColor: `hsl(${meta.color} / 0.5)` }}>
      <meta.icon className={iconClass} />
    </span>
  );
}

/** The six per-type counts of a domain in one row; zero counts are dimmed so the shape still reads. */
export function CountStrip({ counts, className, dim = true }: { counts: CatalogCounts; className?: string; dim?: boolean }) {
  return (
    <span className={cn("flex flex-wrap items-center gap-x-2 gap-y-0.5 font-mono text-[10px] tabular-nums", className)}>
      {OBJECT_TYPES.map((t) => {
        const meta = TYPE_META[t];
        const n = counts[meta.countKey];
        return (
          <span key={t} className={cn("inline-flex items-center gap-0.5", !n && dim && "opacity-35")} title={`${formatInt(n)} ${n === 1 ? meta.label.toLowerCase() : meta.plural.toLowerCase()}`} style={{ color: `hsl(${meta.color})` }}>
            <meta.icon className="h-3 w-3" /> {formatInt(n)}
          </span>
        );
      })}
    </span>
  );
}
