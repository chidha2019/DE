import { Check, Sparkles, X } from "lucide-react";
import { useEffect, useState } from "react";

import type { EnrichmentSuggestion, SemanticAssetDetail } from "@/api/types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useDecideEnrichment, useEnrichAsset } from "@/hooks/queries";
import { describeError } from "@/lib/api-client";
import { formatPercent, formatRelative } from "@/lib/format";

const KINDS = ["fact", "dimension", "bridge", "reference", "metric", "unknown"];

function suggestionOf(asset: SemanticAssetDetail): EnrichmentSuggestion | null {
  const raw = asset.enrichment;
  return raw && typeof raw === "object" && "status" in raw && typeof raw.status === "string" ? (raw as EnrichmentSuggestion) : null;
}

/** Claude's proposal for one asset: review, edit, accept or reject; or ask for one. */
export function EnrichmentPanel({ asset, available }: { asset: SemanticAssetDetail; available: boolean }) {
  const suggest = useEnrichAsset();
  const decide = useDecideEnrichment();
  const suggestion = suggestionOf(asset);
  const stamp = suggestion?.generated_at ?? null;

  const [name, setName] = useState("");
  const [summary, setSummary] = useState("");
  const [kind, setKind] = useState("unknown");
  const [chosen, setChosen] = useState<string[]>([]);

  // Reset the editable copy whenever a new suggestion arrives.
  useEffect(() => {
    const current = suggestionOf(asset);
    if (!current) return;
    setName(current.display_name);
    setSummary(current.summary);
    setKind(current.kind);
    setChosen(current.metrics.map((m) => m.name));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stamp, asset.id]);

  const busy = suggest.isPending || decide.isPending;
  const error = suggest.error ?? decide.error;

  if (!suggestion || suggestion.status !== "suggested") {
    return (
      <div className="flex flex-wrap items-center gap-2 rounded-lg border border-dashed border-primary/30 bg-primary/5 px-3 py-2 text-xs">
        <Sparkles className="h-3.5 w-3.5 shrink-0 text-primary" />
        {suggestion?.status === "accepted" ? (
          <span>
            Named with Claude {formatRelative(suggestion.decided_at)}
            {suggestion.model ? <span className="text-muted-foreground"> · {suggestion.model}</span> : null}
          </span>
        ) : suggestion?.status === "rejected" ? (
          <span className="text-muted-foreground">Claude's suggestion was rejected {formatRelative(suggestion.decided_at)}.</span>
        ) : (
          <span className="text-muted-foreground">Let Claude propose a business name, meaning, kind and metrics from the columns, keys and joins.</span>
        )}
        <span className="flex-1" />
        <Button size="sm" variant="outline" disabled={!available || busy} onClick={() => suggest.mutate(asset.id)} title={available ? undefined : "Configure a Claude model to enable enrichment"}>
          <Sparkles className="h-3.5 w-3.5" /> {busy ? "Asking Claude…" : suggestion ? "Suggest again" : "Suggest with Claude"}
        </Button>
        {error ? <span className="w-full text-destructive">{describeError(error)}</span> : null}
      </div>
    );
  }

  const toggle = (metricName: string) => setChosen((list) => (list.includes(metricName) ? list.filter((n) => n !== metricName) : [...list, metricName]));
  const accept = () =>
    decide.mutate({
      id: asset.id,
      body: { action: "accept", display_name: name.trim() || null, summary: summary.trim() || null, kind, metric_names: chosen },
    });
  const reject = () => decide.mutate({ id: asset.id, body: { action: "reject" } });

  return (
    <div className="rounded-lg border border-primary/30 bg-primary/5 p-3 text-xs">
      <div className="flex flex-wrap items-center gap-2">
        <Sparkles className="h-3.5 w-3.5 text-primary" />
        <span className="font-medium">Claude suggests</span>
        <Badge variant="outline" className="h-5 text-[10px]">
          confidence {formatPercent(suggestion.confidence)}
        </Badge>
        <span className="text-muted-foreground">
          {suggestion.model ? `${suggestion.model} · ` : ""}
          {formatRelative(suggestion.generated_at)}
        </span>
      </div>
      {suggestion.rationale ? <p className="mt-1 italic text-muted-foreground">{suggestion.rationale}</p> : null}
      <div className="mt-3 grid gap-2 md:grid-cols-[1fr_160px]">
        <label className="space-y-1">
          <span className="text-[10px] uppercase tracking-wide text-muted-foreground">Business name</span>
          <Input value={name} onChange={(e) => setName(e.target.value)} className="h-8 text-xs" />
        </label>
        <label className="space-y-1">
          <span className="text-[10px] uppercase tracking-wide text-muted-foreground">Kind</span>
          <Select value={kind} onValueChange={setKind}>
            <SelectTrigger className="h-8 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {KINDS.map((k) => (
                <SelectItem key={k} value={k} className="text-xs capitalize">
                  {k === "unknown" ? "unclassified" : k}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </label>
        <label className="space-y-1 md:col-span-2">
          <span className="text-[10px] uppercase tracking-wide text-muted-foreground">Meaning</span>
          <Textarea value={summary} onChange={(e) => setSummary(e.target.value)} rows={2} className="text-xs" />
        </label>
      </div>
      {suggestion.metrics.length ? (
        <div className="mt-3">
          <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Metrics to add</div>
          <ul className="mt-1 space-y-1">
            {suggestion.metrics.map((m) => (
              <li key={m.name} className="flex items-start gap-2 rounded-md border border-border/60 bg-card/60 px-2 py-1.5">
                <input type="checkbox" className="mt-0.5 accent-[hsl(var(--primary))]" checked={chosen.includes(m.name)} onChange={() => toggle(m.name)} aria-label={`Add ${m.display_name || m.name}`} />
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-medium">{m.display_name || m.name}</span>
                    <code className="rounded bg-muted/60 px-1 font-mono text-[10px] text-muted-foreground">{m.expression}</code>
                  </div>
                  {m.description ? <div className="text-[11px] text-muted-foreground">{m.description}</div> : null}
                  {m.dimensions.length ? <div className="text-[10px] text-muted-foreground">by {m.dimensions.join(", ")}</div> : null}
                </div>
              </li>
            ))}
          </ul>
        </div>
      ) : null}
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <Button size="sm" onClick={accept} disabled={busy || !name.trim()}>
          <Check className="h-3.5 w-3.5" /> Accept
        </Button>
        <Button size="sm" variant="outline" onClick={reject} disabled={busy}>
          <X className="h-3.5 w-3.5" /> Reject
        </Button>
        <span className="text-[11px] text-muted-foreground">Edits are recorded as curated; accepting as-is is attributed to the model.</span>
        {error ? <span className="w-full text-destructive">{describeError(error)}</span> : null}
      </div>
    </div>
  );
}
