import { ChevronDown, ChevronRight, Columns3, FolderTree, Layers, Sigma, Waypoints, type LucideIcon } from "lucide-react";
import { useMemo, useState } from "react";

import type { SemanticOverview } from "@/api/types";
import { BrandMark } from "@/components/connectors/brand-mark";
import { CompositionBar, KIND_LABEL, KIND_ORDER, kindColor, kindSegments, roleSegments } from "@/components/semantic/visuals";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCompact, formatRelative } from "@/lib/format";
import { cn } from "@/lib/utils";

export interface ScopeSelection {
  platform: string | null;
  database: string | null;
  schema: string | null;
  kind: string | null;
}

interface ScopeRailProps {
  overview: SemanticOverview | undefined;
  loading: boolean;
  selection: ScopeSelection;
  onChange: (next: ScopeSelection) => void;
}

interface DatabaseNode {
  assets: number;
  schemas: { name: string; assets: number; metric_views: number; facts: number; dimensions: number }[];
}

function PlatformTile({ platform }: { platform: string }) {
  return <BrandMark icon={platform} size="sm" />;
}

/** A tree row with a proportional bar behind the count, so big schemas read as big. */
function TreeRow({ label, count, hint, share, active, onClick, className, mono = true }: { label: string; count: number; hint?: string; share: number; active: boolean; onClick: () => void; className?: string; mono?: boolean }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn("relative flex w-full items-center justify-between gap-2 overflow-hidden rounded-md px-2 py-1 text-left text-xs transition-colors hover:bg-accent/70", active && "bg-primary/10 font-medium text-foreground", className)}
    >
      {active ? <span className="absolute inset-y-1 left-0 w-0.5 rounded-r-full bg-primary" aria-hidden="true" /> : null}
      <span className={cn("min-w-0 truncate", mono && "font-mono")}>{label}</span>
      <span className="flex shrink-0 items-center gap-1.5">
        <span className="h-1 w-10 overflow-hidden rounded-full bg-muted/70" aria-hidden="true">
          <span className="block h-full rounded-full bg-primary/70" style={{ width: `${Math.max(6, Math.round(share * 100))}%` }} />
        </span>
        <span className="font-mono text-[10px] text-muted-foreground" title={hint}>
          {count}
        </span>
      </span>
    </button>
  );
}

/** Left column: the scope's totals, the platform → database → schema tree, kind filters and column roles. */
export function ScopeRail({ overview, loading, selection, onChange, className }: ScopeRailProps & { className?: string }) {
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
  const tree = useMemo(() => {
    const byPlatform = new Map<string, Map<string, DatabaseNode>>();
    for (const scope of overview?.scopes ?? []) {
      const databases = byPlatform.get(scope.platform) ?? new Map<string, DatabaseNode>();
      const database = databases.get(scope.database_name) ?? { assets: 0, schemas: [] };
      database.assets += scope.assets;
      database.schemas.push({ name: scope.schema_name, assets: scope.assets, metric_views: scope.metric_views, facts: scope.facts, dimensions: scope.dimensions });
      databases.set(scope.database_name, database);
      byPlatform.set(scope.platform, databases);
    }
    return byPlatform;
  }, [overview]);
  const maxAssets = Math.max(1, ...[...tree.values()].flatMap((dbs) => [...dbs.values()].map((d) => d.assets)));
  const pick = (patch: Partial<ScopeSelection>) => onChange({ ...selection, ...patch });

  return (
    <aside className={cn("scrollbar-hidden flex w-72 shrink-0 flex-col gap-4 overflow-y-auto border-r border-border/80 bg-card/30 p-4", className)}>
      <div className="rounded-xl border border-border/70 bg-background/40 p-3">
        <div className="grid grid-cols-2 gap-x-3 gap-y-2">
          <Stat icon={Layers} tone="#0EA5E9" label="Datasets" value={overview?.assets} loading={loading} />
          <Stat icon={Columns3} tone="#8B5CF6" label="Columns" value={overview?.fields} loading={loading} />
          <Stat icon={Sigma} tone="#10B981" label="Metrics" value={overview?.metrics} hint={overview ? `${overview.declared_metrics} declared` : undefined} loading={loading} />
          <Stat icon={Waypoints} tone="#F59E0B" label="Links" value={overview?.relationships} loading={loading} />
        </div>
        {overview ? <CompositionBar segments={kindSegments(overview.by_kind)} legend={false} height="h-1.5" className="mt-3" /> : null}
        {overview?.last_synced_at ? <p className="mt-2 text-[10px] text-muted-foreground">Last sync {formatRelative(overview.last_synced_at)}</p> : null}
      </div>

      <div>
        <h2 className="mb-1.5 flex items-center gap-1.5 text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
          <FolderTree className="h-3.5 w-3.5 text-primary" /> Sources
        </h2>
        {loading ? (
          <Skeleton className="h-24 w-full" />
        ) : tree.size === 0 ? (
          <p className="rounded-md border border-dashed p-3 text-xs text-muted-foreground">No catalog metadata yet. Configure the Databricks or Snowflake connector and run it from Pipelines.</p>
        ) : (
          <div className="space-y-1">
            <button
              type="button"
              onClick={() => pick({ platform: null, database: null, schema: null })}
              className={cn("relative w-full rounded-md px-2 py-1 text-left text-xs transition-colors hover:bg-accent/70", !selection.platform && "bg-primary/10 font-medium")}
            >
              {!selection.platform ? <span className="absolute inset-y-1 left-0 w-0.5 rounded-r-full bg-primary" aria-hidden="true" /> : null}
              All sources
            </button>
            {[...tree.entries()].map(([platform, databases]) => {
              const platformAssets = [...databases.values()].reduce((n, d) => n + d.assets, 0);
              return (
                <div key={platform} className="pt-1">
                  <button
                    type="button"
                    onClick={() => pick({ platform, database: null, schema: null })}
                    className={cn(
                      "relative flex w-full items-center gap-2 rounded-lg px-1.5 py-1.5 text-left text-xs transition-colors hover:bg-accent/70",
                      selection.platform === platform && !selection.database && "bg-primary/10 font-medium",
                    )}
                  >
                    <PlatformTile platform={platform} />
                    <span className="min-w-0 flex-1">
                      <span className="block capitalize">{platform}</span>
                      <span className="block text-[10px] text-muted-foreground">
                        {databases.size} catalog{databases.size === 1 ? "" : "s"} · {platformAssets} datasets
                      </span>
                    </span>
                  </button>
                  {[...databases.entries()].map(([database, info]) => {
                    const key = `${platform}.${database}`;
                    const open = !collapsed[key];
                    const dbMax = Math.max(1, ...info.schemas.map((s) => s.assets));
                    return (
                      <div key={key} className="ml-2 border-l border-border/60 pl-2">
                        <div className="flex items-center">
                          <button type="button" onClick={() => setCollapsed((c) => ({ ...c, [key]: !c[key] }))} className="p-0.5 text-muted-foreground" aria-label="Toggle schemas">
                            {open ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
                          </button>
                          <TreeRow
                            label={database}
                            count={info.assets}
                            share={info.assets / maxAssets}
                            active={selection.database === database && !selection.schema}
                            onClick={() => pick({ platform, database, schema: null })}
                            className="flex-1"
                          />
                        </div>
                        {open
                          ? info.schemas.map((schema) => (
                              <TreeRow
                                key={schema.name}
                                label={schema.name}
                                count={schema.assets}
                                hint={`${schema.facts} facts · ${schema.dimensions} dimensions${schema.metric_views ? ` · ${schema.metric_views} metric views` : ""}`}
                                share={schema.assets / dbMax}
                                active={selection.database === database && selection.schema === schema.name}
                                onClick={() => pick({ platform, database, schema: schema.name })}
                                className="ml-5 w-[calc(100%-1.25rem)]"
                              />
                            ))
                          : null}
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div>
        <h2 className="mb-1.5 text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">Kind</h2>
        <div className="flex flex-wrap gap-1">
          {KIND_ORDER.map((kind) => {
            const count = overview?.by_kind[kind] ?? 0;
            if (!count && selection.kind !== kind) return null;
            const active = selection.kind === kind;
            return (
              <button
                key={kind}
                type="button"
                onClick={() => pick({ kind: active ? null : kind })}
                className={cn("inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[11px] transition-colors hover:bg-accent/70", active ? "border-primary/50 bg-primary/10 text-foreground" : "border-border/70 text-muted-foreground")}
                style={active ? { borderColor: `hsl(${kindColor(kind)} / 0.6)` } : undefined}
              >
                <span className="h-1.5 w-1.5 rounded-full" style={{ background: `hsl(${kindColor(kind)})` }} aria-hidden="true" />
                {KIND_LABEL[kind]} <span className="font-mono">{count}</span>
              </button>
            );
          })}
        </div>
      </div>

      {overview && Object.keys(overview.by_role).length ? (
        <div>
          <h2 className="mb-1.5 text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">Column roles</h2>
          <CompositionBar segments={roleSegments(overview.by_role)} />
        </div>
      ) : null}
    </aside>
  );
}

function Stat({ icon: Icon, tone, label, value, hint, loading }: { icon: LucideIcon; tone: string; label: string; value: number | undefined; hint?: string; loading: boolean }) {
  return (
    <div className="flex items-start gap-2">
      <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg" style={{ background: `${tone}1f`, color: tone }} aria-hidden="true">
        <Icon className="h-3.5 w-3.5" />
      </span>
      <div className="min-w-0">
        {loading ? <Skeleton className="h-5 w-12" /> : <div className="font-display text-lg font-medium leading-tight tabular-nums">{formatCompact(value ?? 0)}</div>}
        <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</div>
        {hint ? <div className="text-[10px] text-muted-foreground">{hint}</div> : null}
      </div>
    </div>
  );
}
