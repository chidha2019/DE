import { GitFork, Search, Sigma, Table2 } from "lucide-react";

import type { Page, SemanticAssetSummary } from "@/api/types";
import { NameSourceBadge, TypeBadge } from "@/components/semantic/badges";
import { KIND_LABEL, KindTile, Pill, PlatformDot, kindColor } from "@/components/semantic/visuals";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCompact, formatRelative } from "@/lib/format";
import { cn } from "@/lib/utils";

interface AssetTableProps {
  page: Page<SemanticAssetSummary> | undefined;
  loading: boolean;
  search: string;
  onSearch: (value: string) => void;
  selectedId: string | null;
  onSelect: (asset: SemanticAssetSummary) => void;
  offset: number;
  onOffset: (next: number) => void;
}

function AssetRow({ asset, selected, onSelect }: { asset: SemanticAssetSummary; selected: boolean; onSelect: () => void }) {
  const c = kindColor(asset.kind);
  return (
    <button
      type="button"
      onClick={onSelect}
      className={cn(
        "group relative flex w-full items-start gap-3 overflow-hidden rounded-xl border px-3 py-2.5 text-left transition-all hover:border-primary/40 hover:bg-primary/5",
        selected ? "border-primary/50 bg-primary/10 shadow-glow" : "border-border/60 bg-card/60",
      )}
    >
      <span className="absolute inset-y-2 left-0 w-0.5 rounded-r-full" style={{ background: `hsl(${c})` }} aria-hidden="true" />
      <KindTile kind={asset.kind} className="mt-0.5 h-9 w-9" />
      <span className="min-w-0 flex-1">
        <span className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
          <span className="truncate text-sm font-medium" title={asset.fqn}>
            {asset.display_name || asset.name}
          </span>
          <TypeBadge assetType={asset.asset_type} />
          <span className="text-[10px] uppercase tracking-wide" style={{ color: `hsl(${c})` }}>
            {KIND_LABEL[asset.kind] ?? asset.kind}
          </span>
        </span>
        <span className="flex items-center gap-1.5 truncate font-mono text-[10px] text-muted-foreground">
          <PlatformDot platform={asset.platform} />
          {asset.schema_name}.{asset.name}
        </span>
        {asset.summary || asset.description ? <span className="mt-0.5 line-clamp-1 text-[11px] text-muted-foreground">{asset.summary || asset.description}</span> : null}
        <span className="mt-1.5 flex flex-wrap items-center gap-1.5">
          <Pill icon={Table2} value={asset.field_count} label="columns" />
          <Pill icon={Sigma} value={asset.metric_count} label="metrics" tone={asset.metric_count ? "160 70% 45%" : undefined} />
          <Pill icon={GitFork} value={asset.relationship_count} label="keys, joins and lineage" tone={asset.relationship_count ? "217 85% 60%" : undefined} />
          {asset.row_count !== null ? <span className="font-mono text-[10px] text-muted-foreground">{formatCompact(asset.row_count)} rows</span> : null}
          <span className="ml-auto flex items-center gap-1.5">
            {asset.name_source !== "derived" ? <NameSourceBadge source={asset.name_source} /> : null}
            <span className="text-[10px] text-muted-foreground">{formatRelative(asset.source_updated_at ?? asset.synced_at)}</span>
          </span>
        </span>
      </span>
    </button>
  );
}

export function AssetTable({ page, loading, search, onSearch, selectedId, onSelect, offset, onOffset }: AssetTableProps) {
  const limit = page?.limit ?? 50;
  const total = page?.total ?? 0;
  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="relative mb-3">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input value={search} onChange={(e) => onSearch(e.target.value)} placeholder="Search tables, views and metric views by name or description…" className="h-10 pl-9" />
      </div>
      <div className="scrollbar-hidden min-h-0 flex-1 space-y-1.5 overflow-auto pr-0.5">
        {loading && !page
          ? Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-20 w-full rounded-xl" />)
          : page?.items.map((asset) => <AssetRow key={asset.id} asset={asset} selected={selectedId === asset.id} onSelect={() => onSelect(asset)} />)}
        {page && page.items.length === 0 ? (
          <div className="rounded-xl border border-dashed border-border/80 px-4 py-10 text-center text-sm text-muted-foreground">No assets match. Run the Databricks or Snowflake connector from Pipelines, or widen the filters.</div>
        ) : null}
      </div>
      <div className="mt-2 flex items-center justify-between text-xs text-muted-foreground">
        <span>{total ? `${offset + 1}–${Math.min(offset + limit, total)} of ${total}` : "0 assets"}</span>
        <div className="flex gap-1">
          <Button variant="outline" size="sm" disabled={offset === 0} onClick={() => onOffset(Math.max(0, offset - limit))}>
            Previous
          </Button>
          <Button variant="outline" size="sm" disabled={offset + limit >= total} onClick={() => onOffset(offset + limit)}>
            Next
          </Button>
        </div>
      </div>
    </div>
  );
}
