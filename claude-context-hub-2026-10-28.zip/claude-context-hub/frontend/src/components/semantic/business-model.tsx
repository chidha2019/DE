import { Clock, Layers, ShieldCheck, Sigma, Tag, type LucideIcon } from "lucide-react";
import type { ReactNode } from "react";

import type { BusinessModel, EnrichRun, FactStar, MetricViewCard, SemanticAssetSummary, SubjectArea } from "@/api/types";
import { KindBadge, NameSourceBadge, PlatformBadge } from "@/components/semantic/badges";
import { ModelOverview, areaId } from "@/components/semantic/model-overview";
import { KindTile, PlatformDot, platformColor } from "@/components/semantic/visuals";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { formatPercent } from "@/lib/format";
import { cn } from "@/lib/utils";

interface BusinessModelViewProps {
  model: BusinessModel | undefined;
  loading: boolean;
  onOpen: (assetId: string) => void;
  onEnrich: () => void;
  enrichPending: boolean;
  enrichRun: EnrichRun | null;
}

/** The semantic layer as a business reader sees it: subject areas, fact stars, governed KPIs. */
export function BusinessModelView({ model, loading, onOpen, onEnrich, enrichPending, enrichRun }: BusinessModelViewProps) {
  if (loading || !model) {
    return (
      <div className="space-y-4 p-4">
        <Skeleton className="h-16 w-full" />
        <Skeleton className="h-72 w-full" />
      </div>
    );
  }
  if (model.subject_areas.length === 0) {
    return <div className="m-4 rounded-lg border border-dashed p-8 text-center text-sm text-muted-foreground">No catalog metadata in this scope yet. Run the Databricks or Snowflake connector from Pipelines.</div>;
  }
  return (
    <div className="scrollbar-hidden min-h-0 flex-1 space-y-6 overflow-auto p-4">
      <ModelOverview
        model={model}
        onJump={(id) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" })}
        onEnrich={onEnrich}
        enrichPending={enrichPending}
        enrichRun={enrichRun}
      />
      {model.subject_areas.map((area) => (
        <SubjectAreaCard key={areaId(area)} area={area} onOpen={onOpen} />
      ))}
    </div>
  );
}

function SubjectAreaCard({ area, onOpen }: { area: SubjectArea; onOpen: (id: string) => void }) {
  const accent = platformColor(area.platform);
  return (
    <section id={areaId(area)} className="surface relative scroll-mt-4 overflow-hidden p-4">
      <span className="absolute inset-x-0 top-0 h-[3px]" style={{ background: `linear-gradient(90deg, hsl(${accent}), hsl(${accent} / 0.1))` }} aria-hidden="true" />
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <PlatformDot platform={area.platform} className="h-2.5 w-2.5" />
            <h2 className="font-display text-lg font-medium">{area.label}</h2>
            <PlatformBadge platform={area.platform} />
            <span className="font-mono text-[11px] text-muted-foreground">
              {area.database_name}.{area.schema_name}
            </span>
          </div>
          <p className="text-xs text-muted-foreground">
            {area.assets} datasets · {area.facts.length} facts · {area.dimensions.length} dimensions · {area.metric_views.length} metric views
          </p>
        </div>
        <div className="flex gap-3">
          <Ring label="Described" value={area.assets ? area.described / area.assets : 0} hint="datasets with a catalog description" />
          <Ring label="Named" value={area.assets ? area.named / area.assets : 0} hint="business names that are declared, curated or accepted from Claude" />
        </div>
      </header>

      {area.metric_views.length ? (
        <div className="mt-4">
          <SectionLabel icon={ShieldCheck}>Governed metrics</SectionLabel>
          <div className="card-grid mt-2">
            {area.metric_views.map((card) => (
              <MetricViewTile key={card.asset.id} card={card} onOpen={onOpen} />
            ))}
          </div>
        </div>
      ) : null}

      {area.facts.length ? (
        <div className="mt-4">
          <SectionLabel icon={Sigma}>Facts and their dimensions</SectionLabel>
          <div className="star-grid mt-2">
            {area.facts.map((star) => (
              <StarCard key={star.asset.id} star={star} onOpen={onOpen} />
            ))}
          </div>
        </div>
      ) : null}

      {area.dimensions.length ? (
        <div className="mt-4">
          <SectionLabel icon={Tag}>Dimensions and reference data</SectionLabel>
          <div className="mt-2 flex flex-wrap gap-2">
            {area.dimensions.map((asset) => (
              <AssetChip key={asset.id} asset={asset} onOpen={onOpen} />
            ))}
          </div>
        </div>
      ) : null}

      {area.other.length ? (
        <div className="mt-4">
          <SectionLabel icon={Layers}>Not yet placed in the model</SectionLabel>
          <p className="text-[11px] text-muted-foreground">Name with Claude, or add keys and descriptions on the platform, and these datasets take their place as facts, dimensions or references.</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {area.other.map((asset) => (
              <AssetChip key={asset.id} asset={asset} onOpen={onOpen} />
            ))}
          </div>
        </div>
      ) : null}
    </section>
  );
}

function SectionLabel({ icon: Icon, children }: { icon: LucideIcon; children: ReactNode }) {
  return (
    <h3 className="flex items-center gap-1.5 text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
      <Icon className="h-3.5 w-3.5 text-primary" /> {children}
    </h3>
  );
}

function Ring({ label, value, hint }: { label: string; value: number; hint?: string }) {
  const circumference = 2 * Math.PI * 15.5;
  return (
    <div className="flex items-center gap-2" title={hint}>
      <svg viewBox="0 0 36 36" className="h-11 w-11" aria-hidden="true">
        <circle cx="18" cy="18" r="15.5" className="fill-none stroke-muted" strokeWidth="3" />
        <circle
          cx="18"
          cy="18"
          r="15.5"
          className={cn("fill-none", value >= 0.9 ? "stroke-success" : value >= 0.6 ? "stroke-primary" : "stroke-warning")}
          strokeWidth="3"
          strokeLinecap="round"
          strokeDasharray={`${Math.max(0, Math.min(1, value)) * circumference} ${circumference}`}
          transform="rotate(-90 18 18)"
        />
        <text x="18" y="21" textAnchor="middle" className="fill-foreground text-[9px] font-medium">
          {formatPercent(value)}
        </text>
      </svg>
      <span className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</span>
    </div>
  );
}

function AssetChip({ asset, onOpen }: { asset: SemanticAssetSummary; onOpen: (id: string) => void }) {
  return (
    <button
      type="button"
      onClick={() => onOpen(asset.id)}
      title={`${asset.fqn}${asset.summary ? ` · ${asset.summary}` : ""}`}
      className="flex items-center gap-1.5 rounded-lg border border-border/80 bg-card/70 px-2.5 py-1.5 text-xs transition-colors hover:border-primary/40 hover:bg-primary/5"
    >
      <span className="font-medium">{asset.display_name || asset.name}</span>
      <KindBadge kind={asset.kind} />
    </button>
  );
}

function truncate(text: string, max: number): string {
  return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}

function initials(text: string): string {
  const words = text.split(/\s+/).filter(Boolean);
  return words
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() ?? "")
    .join("");
}

const CX = 150;
const CY = 118;
const RADIUS = 84;

function StarCard({ star, onOpen }: { star: FactStar; onOpen: (id: string) => void }) {
  const dims = star.dimensions.slice(0, 8);
  const name = star.asset.display_name || star.asset.name;
  return (
    <div className="min-w-0 overflow-hidden rounded-xl border border-border/80 bg-background/40 p-3 transition-colors hover:border-primary/30">
      <div className="flex items-start justify-between gap-2">
        <div className="flex min-w-0 items-start gap-2.5">
          <KindTile kind={star.asset.kind} className="mt-0.5 h-9 w-9" />
          <div className="min-w-0">
          <button type="button" onClick={() => onOpen(star.asset.id)} className="text-left">
            <div className="font-display text-base font-medium hover:underline">{name}</div>
          </button>
          <div className="truncate font-mono text-[10px] text-muted-foreground">{star.asset.fqn}</div>
          <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{star.asset.summary || star.asset.description}</p>
          </div>
        </div>
        <NameSourceBadge source={star.asset.name_source} />
      </div>
      {/* Diagram beside the chips when the card is wide enough for two 13rem columns, stacked otherwise. */}
      <div className="mt-2 grid gap-3" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(13rem, 1fr))" }}>
        <svg viewBox="0 0 300 236" className="mx-auto w-full max-w-[18rem]" role="img" aria-label={`${name} and the dimensions it joins to`}>
          {dims.map((d, index) => {
            const angle = -Math.PI / 2 + (index * 2 * Math.PI) / dims.length;
            const x = CX + Math.cos(angle) * RADIUS;
            const y = CY + Math.sin(angle) * RADIUS;
            const declared = d.relationship !== "join_inferred";
            const strong = declared || d.confidence >= 0.85;
            const mid = d.confidence >= 0.75;
            const below = y > CY + 4;
            return (
              <g key={d.fqn}>
                <line
                  x1={CX}
                  y1={CY}
                  x2={x}
                  y2={y}
                  className={strong ? "stroke-primary" : mid ? "stroke-warning" : "stroke-muted-foreground/60"}
                  strokeWidth={strong ? 2 : 1.5}
                  strokeDasharray={strong ? undefined : "4 3"}
                />
                <g className={d.asset ? "cursor-pointer" : undefined} onClick={() => d.asset && onOpen(d.asset.id)}>
                  <circle
                    cx={x}
                    cy={y}
                    r="15"
                    className={cn(
                      "stroke-[1.5]",
                      d.kind === "dimension" ? "fill-blue-500/15 stroke-blue-400" : d.kind === "reference" ? "fill-cyan-500/15 stroke-cyan-400" : "fill-muted stroke-border",
                    )}
                  />
                  <text x={x} y={y + 3.5} textAnchor="middle" className="fill-foreground text-[8px] font-medium">
                    {initials(d.display_name)}
                  </text>
                  <text x={x} y={below ? y + 27 : y - 20} textAnchor="middle" className="fill-muted-foreground text-[8.5px]">
                    {truncate(d.display_name, 20)}
                  </text>
                </g>
              </g>
            );
          })}
          <circle cx={CX} cy={CY} r="30" className="fill-primary/15 stroke-primary" strokeWidth="2" />
          <text x={CX} y={CY + 4} textAnchor="middle" className="fill-foreground text-[11px] font-medium">
            {initials(name)}
          </text>
          {dims.length === 0 ? (
            <text x={CX} y={CY + 52} textAnchor="middle" className="fill-muted-foreground text-[9px]">
              no keys or joins recorded yet
            </text>
          ) : null}
        </svg>
        <div className="min-w-0 space-y-2 text-xs">
          {star.measures.length ? <ChipRow icon={Sigma} label="Measures" items={star.measures} className="border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300" /> : null}
          {star.time.length ? <ChipRow icon={Clock} label="Time" items={star.time} className="border-violet-500/30 bg-violet-500/10 text-violet-700 dark:text-violet-300" /> : null}
          {star.metrics.length ? (
            <div>
              <div className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">Metrics</div>
              <ul className="mt-1 space-y-1">
                {star.metrics.slice(0, 5).map((m) => (
                  <li key={m.id} className="min-w-0 rounded-md border border-border/60 bg-card/60 px-2 py-1">
                    <div className="flex items-center gap-1.5">
                      <span className="min-w-0 flex-1 truncate font-medium" title={m.display_name || m.name}>
                        {m.display_name || m.name}
                      </span>
                      {m.source !== "inferred" ? (
                        <Badge variant="success" className="h-4 shrink-0 px-1 text-[9px]">
                          {m.source}
                        </Badge>
                      ) : null}
                    </div>
                    <code className="line-clamp-2 break-all font-mono text-[10px] leading-snug text-muted-foreground" title={m.expression}>
                      {m.expression}
                    </code>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}
          {dims.length ? (
            <div className="flex flex-wrap gap-1">
              {dims.map((d) => (
                <span key={d.fqn} className="max-w-full truncate whitespace-nowrap rounded border border-border/60 px-1.5 py-0.5 text-[10px] text-muted-foreground" title={`${d.relationship.replace(/_/g, " ")} on ${d.join_columns.join(", ") || "?"}`}>
                  {d.display_name} · {d.relationship === "join_inferred" ? formatPercent(d.confidence) : "declared"}
                </span>
              ))}
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}

function ChipRow({ icon: Icon, label, items, className }: { icon: LucideIcon; label: string; items: string[]; className: string }) {
  return (
    <div>
      <div className="flex items-center gap-1 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
        <Icon className="h-3 w-3" /> {label}
      </div>
      <div className="mt-1 flex flex-wrap gap-1">
        {items.slice(0, 10).map((item) => (
          <span key={item} className={cn("max-w-full truncate whitespace-nowrap rounded border px-1.5 py-0.5 text-[10px]", className)} title={item}>
            {item}
          </span>
        ))}
        {items.length > 10 ? <span className="text-[10px] text-muted-foreground">+{items.length - 10}</span> : null}
      </div>
    </div>
  );
}

function MetricViewTile({ card, onOpen }: { card: MetricViewCard; onOpen: (id: string) => void }) {
  return (
    <div className="rounded-xl border border-success/30 bg-success/5 p-3">
      <div className="flex items-start justify-between gap-2">
        <button type="button" onClick={() => onOpen(card.asset.id)} className="min-w-0 text-left">
          <div className="truncate font-display text-sm font-medium hover:underline">{card.asset.display_name || card.asset.name}</div>
        </button>
        <Badge variant="success" className="h-5 shrink-0 text-[10px]">
          governed
        </Badge>
      </div>
      {card.source_fqn ? <div className="truncate font-mono text-[10px] text-muted-foreground">over {card.source_fqn}</div> : null}
      <ul className="mt-2 space-y-1">
        {card.metrics.slice(0, 4).map((m) => (
          <li key={m.id} className="rounded-md border border-border/60 bg-card/60 px-2 py-1 text-xs">
            <div className="flex items-center justify-between gap-2">
              <span className="truncate font-medium">{m.display_name || m.name}</span>
              <code className="shrink-0 font-mono text-[10px] text-muted-foreground">{truncate(m.expression, 28)}</code>
            </div>
            {m.description ? <div className="line-clamp-1 text-[11px] text-muted-foreground">{m.description}</div> : null}
          </li>
        ))}
        {card.metrics.length > 4 ? <li className="text-[10px] text-muted-foreground">+{card.metrics.length - 4} more</li> : null}
      </ul>
      {card.dimensions.length ? (
        <div className="mt-2 flex flex-wrap gap-1">
          {card.dimensions.slice(0, 6).map((d) => (
            <span key={d} className="rounded border border-blue-400/30 bg-blue-500/10 px-1.5 py-0.5 text-[10px] text-blue-300">
              {d}
            </span>
          ))}
        </div>
      ) : null}
    </div>
  );
}
