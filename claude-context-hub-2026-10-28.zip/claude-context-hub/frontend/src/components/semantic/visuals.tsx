import { BookOpen, GitMerge, HelpCircle, ShieldCheck, Sigma, Tag, type LucideIcon } from "lucide-react";

import { formatCompact, formatPercent } from "@/lib/format";
import { cn } from "@/lib/utils";

/** One hue per kind (HSL triplets), matching the badge palette so chips, tiles and bars agree. */
export const KIND_COLOR: Record<string, string> = {
  fact: "160 70% 45%",
  dimension: "217 85% 60%",
  reference: "188 80% 46%",
  bridge: "38 92% 52%",
  metric: "347 77% 58%",
  unknown: "200 10% 55%",
};
export const KIND_ICON: Record<string, LucideIcon> = { fact: Sigma, dimension: Tag, reference: BookOpen, bridge: GitMerge, metric: ShieldCheck, unknown: HelpCircle };
export const KIND_LABEL: Record<string, string> = { fact: "Facts", dimension: "Dimensions", reference: "Reference data", bridge: "Bridges", metric: "Metric views", unknown: "Unplaced" };
export const KIND_ORDER = ["fact", "dimension", "reference", "bridge", "metric", "unknown"];

export const PLATFORM_COLOR: Record<string, string> = { databricks: "14 88% 56%", snowflake: "199 90% 55%" };
export const ROLE_COLOR: Record<string, string> = { identifier: "215 20% 55%", dimension: "217 85% 60%", time: "262 70% 62%", measure: "160 70% 45%", attribute: "200 10% 50%" };

export const kindColor = (kind: string): string => KIND_COLOR[kind] ?? "200 10% 55%";
export const kindLabel = (kind: string): string => KIND_LABEL[kind] ?? kind;
export const platformColor = (platform: string): string => PLATFORM_COLOR[platform] ?? "172 66% 45%";

export function KindTile({ kind, className, iconClass = "h-4 w-4" }: { kind: string; className?: string; iconClass?: string }) {
  const Icon = KIND_ICON[kind] ?? HelpCircle;
  const c = kindColor(kind);
  return (
    <span
      className={cn("flex shrink-0 items-center justify-center rounded-xl border text-white", className ?? "h-9 w-9")}
      style={{ background: `linear-gradient(135deg, hsl(${c}), hsl(${c} / 0.6))`, borderColor: `hsl(${c} / 0.5)`, boxShadow: `0 8px 20px -12px hsl(${c} / 0.9), inset 0 1px 0 0 hsl(0 0% 100% / 0.25)` }}
      title={KIND_LABEL[kind] ?? kind}
    >
      <Icon className={iconClass} />
    </span>
  );
}

export function PlatformDot({ platform, className }: { platform: string; className?: string }) {
  return <span className={cn("inline-block h-2 w-2 shrink-0 rounded-full", className)} style={{ background: `hsl(${platformColor(platform)})` }} aria-hidden="true" />;
}

export interface Segment {
  key: string;
  label: string;
  value: number;
  color: string;
}

export function kindSegments(counts: Record<string, number>): Segment[] {
  return KIND_ORDER.map((kind) => ({ key: kind, label: kindLabel(kind), value: counts[kind] ?? 0, color: kindColor(kind) }));
}

export function roleSegments(counts: Record<string, number>): Segment[] {
  return ["identifier", "dimension", "time", "measure", "attribute"].map((role) => ({ key: role, label: role, value: counts[role] ?? 0, color: ROLE_COLOR[role] ?? "200 10% 50%" }));
}

/** A segmented bar; segments with zero value are skipped so the bar never shows empty slivers. */
export function CompositionBar({ segments, className, legend = true, height = "h-2.5" }: { segments: Segment[]; className?: string; legend?: boolean; height?: string }) {
  const shown = segments.filter((s) => s.value > 0);
  const total = shown.reduce((n, s) => n + s.value, 0);
  return (
    <div className={className}>
      <div className={cn("flex w-full overflow-hidden rounded-full bg-muted/60", height)}>
        {shown.map((s) => (
          <div key={s.key} title={`${s.label}: ${formatCompact(s.value)}`} style={{ width: `${(s.value / Math.max(total, 1)) * 100}%`, background: `hsl(${s.color})` }} />
        ))}
      </div>
      {legend ? (
        <div className="mt-1.5 flex flex-wrap gap-x-3 gap-y-1 text-[10px] text-muted-foreground">
          {shown.map((s) => (
            <span key={s.key} className="inline-flex items-center gap-1 capitalize">
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: `hsl(${s.color})` }} aria-hidden="true" />
              {s.label} <span className="font-mono text-foreground">{formatCompact(s.value)}</span>
            </span>
          ))}
        </div>
      ) : null}
    </div>
  );
}

const ringTone = (v: number) => (v >= 0.9 ? "stroke-success" : v >= 0.6 ? "stroke-primary" : "stroke-warning");

/** A ring gauge: green from 90 %, teal from 60 %, amber below. */
export function Gauge({ value, label, sub, hint, size = 56 }: { value: number; label: string; sub?: string; hint?: string; size?: number }) {
  const r = 15.5;
  const circumference = 2 * Math.PI * r;
  const v = Math.max(0, Math.min(1, value));
  return (
    <div className="flex flex-col items-center gap-1" title={hint}>
      <svg viewBox="0 0 36 36" style={{ width: size, height: size }} aria-hidden="true">
        <circle cx="18" cy="18" r={r} className="fill-none stroke-muted" strokeWidth="3.2" />
        <circle
          cx="18"
          cy="18"
          r={r}
          className={cn("fill-none transition-[stroke-dasharray] duration-700", ringTone(v))}
          strokeWidth="3.2"
          strokeLinecap="round"
          strokeDasharray={`${v * circumference} ${circumference}`}
          transform="rotate(-90 18 18)"
        />
        <text x="18" y="21.2" textAnchor="middle" className="fill-foreground text-[9.5px] font-medium">
          {formatPercent(v)}
        </text>
      </svg>
      <span className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</span>
      {sub ? <span className="-mt-1 text-[10px] text-muted-foreground/80">{sub}</span> : null}
    </div>
  );
}

/** A label-less ring for tight spots such as tiles. */
export function MiniRing({ value, size = 30, title }: { value: number; size?: number; title?: string }) {
  const r = 15.5;
  const circumference = 2 * Math.PI * r;
  const v = Math.max(0, Math.min(1, value));
  return (
    <svg viewBox="0 0 36 36" style={{ width: size, height: size }} role="img" aria-label={title}>
      {title ? <title>{title}</title> : null}
      <circle cx="18" cy="18" r={r} className="fill-none stroke-muted" strokeWidth="4" />
      <circle cx="18" cy="18" r={r} className={cn("fill-none", ringTone(v))} strokeWidth="4" strokeLinecap="round" strokeDasharray={`${v * circumference} ${circumference}`} transform="rotate(-90 18 18)" />
      <text x="18" y="21.5" textAnchor="middle" className="fill-foreground text-[10px] font-medium">
        {Math.round(v * 100)}
      </text>
    </svg>
  );
}

/** A small count with an icon, used in rows and headers. */
export function Pill({ icon: Icon, value, label, tone }: { icon: LucideIcon; value: number | string; label: string; tone?: string }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-md border border-border/60 bg-background/50 px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground" title={label}>
      <Icon className="h-3 w-3" style={tone ? { color: `hsl(${tone})` } : undefined} />
      {value}
    </span>
  );
}
