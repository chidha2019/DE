import { ArrowDown, ArrowUp, ArrowUpDown, ChevronRight, Columns3, Home, LayoutGrid, List, Search } from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { formatInt } from "@/lib/format";
import { cn } from "@/lib/utils";

import type { Crumb } from "./tree-model";
import type { Selection } from "./state";

export type ViewMode = "list" | "grid";

export function Breadcrumbs({ crumbs, onSelect }: { crumbs: Crumb[]; onSelect: (sel: Selection) => void }) {
  return (
    <nav aria-label="Breadcrumb" className="min-w-0 flex-1">
      <ol className="flex min-w-0 items-center gap-1 overflow-x-auto whitespace-nowrap text-sm">
        <li className="flex items-center text-muted-foreground">
          <Home className="h-3.5 w-3.5" aria-hidden="true" />
        </li>
        {crumbs.map((c, i) => {
          const last = i === crumbs.length - 1;
          return (
            <li key={`${i}-${c.label}`} className="flex min-w-0 items-center gap-1">
              <ChevronRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground/60" aria-hidden="true" />
              {last ? (
                <span aria-current="page" className="truncate font-medium text-foreground">
                  {c.label}
                </span>
              ) : (
                <button type="button" onClick={() => onSelect(c.sel)} className="truncate text-muted-foreground transition-colors hover:text-foreground">
                  {c.label}
                </button>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}

/** A search box that writes to the URL a moment after typing stops. */
export function SearchBox({ value, onChange, placeholder }: { value: string; onChange: (next: string) => void; placeholder: string }) {
  const [draft, setDraft] = useState(value);
  useEffect(() => setDraft(value), [value]);
  useEffect(() => {
    if (draft === value) return;
    const timer = window.setTimeout(() => onChange(draft), 250);
    return () => window.clearTimeout(timer);
  }, [draft, value, onChange]);
  return (
    <div className="relative min-w-[14rem] flex-1">
      <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
      <Input value={draft} onChange={(e) => setDraft(e.target.value)} placeholder={placeholder} className="h-9 pl-9" aria-label={placeholder} />
    </div>
  );
}

export interface ColumnDef<K extends string> {
  key: K;
  label: string;
}

export function ColumnsMenu<K extends string>({ columns, visible, onChange }: { columns: ColumnDef<K>[]; visible: K[]; onChange: (next: K[]) => void }) {
  const shown = new Set(visible);
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="h-9 gap-1.5">
          <Columns3 className="h-4 w-4" /> Columns
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-56 p-2">
        <div className="px-2 pb-1.5 pt-1 text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">Show columns</div>
        {columns.map((c) => (
          <label key={c.key} className="flex cursor-pointer items-center gap-2.5 rounded-lg px-2 py-1.5 text-sm hover:bg-muted/60">
            <input
              type="checkbox"
              className="h-4 w-4 accent-[hsl(var(--primary))]"
              checked={shown.has(c.key)}
              onChange={() => onChange(columns.map((x) => x.key).filter((k) => (k === c.key ? !shown.has(k) : shown.has(k))))}
            />
            {c.label}
          </label>
        ))}
        <button type="button" onClick={() => onChange(columns.map((c) => c.key))} className="mt-1 w-full rounded-lg px-2 py-1.5 text-left text-xs text-primary hover:bg-muted/60">
          Show all
        </button>
      </PopoverContent>
    </Popover>
  );
}

export function ModeToggle({ mode, onMode }: { mode: ViewMode; onMode: (next: ViewMode) => void }) {
  const items: { key: ViewMode; icon: typeof List; label: string }[] = [
    { key: "list", icon: List, label: "List" },
    { key: "grid", icon: LayoutGrid, label: "Grid" },
  ];
  return (
    <div className="flex rounded-xl border border-border/70 bg-muted/40 p-0.5" role="radiogroup" aria-label="Layout">
      {items.map((i) => (
        <button
          key={i.key}
          type="button"
          role="radio"
          aria-checked={mode === i.key}
          aria-label={i.label}
          title={i.label}
          onClick={() => onMode(i.key)}
          className={cn("flex h-8 w-9 items-center justify-center rounded-lg transition-colors", mode === i.key ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-foreground")}
        >
          <i.icon className="h-4 w-4" />
        </button>
      ))}
    </div>
  );
}

/** A column heading that sorts: click once ascending, again descending. */
export function SortHeader({ label, active, order, onSort }: { label: string; active: boolean; order: "asc" | "desc"; onSort: () => void }) {
  const Icon = !active ? ArrowUpDown : order === "asc" ? ArrowUp : ArrowDown;
  return (
    <button type="button" onClick={onSort} aria-sort={active ? (order === "asc" ? "ascending" : "descending") : undefined} className={cn("inline-flex items-center gap-1 transition-colors hover:text-foreground", active && "text-foreground")}>
      {label}
      <Icon className={cn("h-3.5 w-3.5", !active && "opacity-40")} />
    </button>
  );
}

export function Pager({ total, offset, limit, noun, onOffset }: { total: number; offset: number; limit: number; noun: string; onOffset: (next: number) => void }) {
  return (
    <div className="flex items-center justify-between text-xs text-muted-foreground">
      <span>{total ? `${formatInt(offset + 1)}–${formatInt(Math.min(offset + limit, total))} of ${formatInt(total)} ${noun}` : `0 ${noun}`}</span>
      <div className="flex gap-1">
        <Button variant="outline" size="sm" disabled={offset === 0} onClick={() => onOffset(Math.max(0, offset - limit))}>
          Previous
        </Button>
        <Button variant="outline" size="sm" disabled={offset + limit >= total} onClick={() => onOffset(offset + limit)}>
          Next
        </Button>
      </div>
    </div>
  );
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="space-y-1">
      <div className="text-[11px] font-medium text-muted-foreground">{label}</div>
      {children}
    </div>
  );
}
