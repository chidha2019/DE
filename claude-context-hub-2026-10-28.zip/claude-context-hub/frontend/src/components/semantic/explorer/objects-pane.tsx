import { BookOpen, Filter } from "lucide-react";
import type { ReactNode } from "react";

import type { CatalogLine, CatalogObject, CatalogObjectType, CatalogSort, Page } from "@/api/types";
import { QualityBar, TYPE_META, TypeChip, TypeTile } from "@/components/semantic/catalog-visuals";
import { PlatformDot } from "@/components/semantic/visuals";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatRelative } from "@/lib/format";
import { cn } from "@/lib/utils";

import { lineStyle } from "./line-style";
import { PAGE_SIZE, useStoredState, type Selection, type TableState } from "./state";
import { ColumnsMenu, Field, ModeToggle, Pager, SearchBox, SortHeader, type ColumnDef, type ViewMode } from "./toolbar";

type ObjectColumn = "type" | "domain" | "lob" | "model" | "owner" | "quality" | "term" | "updated";
const COLUMNS: (ColumnDef<ObjectColumn> & { sort?: CatalogSort })[] = [
  { key: "type", label: "Type", sort: "type" },
  { key: "domain", label: "Domain", sort: "domain" },
  { key: "lob", label: "Line of business" },
  { key: "model", label: "Model", sort: "model" },
  { key: "owner", label: "Owner", sort: "owner" },
  { key: "quality", label: "Quality score", sort: "quality" },
  { key: "term", label: "Glossary term" },
  { key: "updated", label: "Last updated", sort: "updated" },
];
const ALL = "__all__";
const QUALITY_STEPS = [0, 50, 75, 100];
const SOURCE_LABEL: Record<CatalogObject["domain_source"], string> = {
  dataset: "via its dataset",
  term: "via its glossary term",
  columns: "via its columns' terms",
  kpi: "KPI definition",
  none: "",
};

function DomainCell({ o, colorOf }: { o: CatalogObject; colorOf: (key: string | null) => string }) {
  if (!o.domain_key) return <span className="text-xs text-muted-foreground">Unassigned</span>;
  return (
    <>
      <span className="flex items-center gap-1.5 text-xs">
        <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: `hsl(${colorOf(o.domain_key)})` }} aria-hidden="true" />
        <span className="truncate">{o.domain_name}</span>
      </span>
      <div className="text-[10px] text-muted-foreground">{SOURCE_LABEL[o.domain_source]}</div>
    </>
  );
}

/** The lines a dataset holds, or "Shared" when no tag, default, column or join ties it to one; the note says how the sync knows. */
/** KPI definitions come from the glossary itself, not from a table: say so where they are listed. */
function GlossaryKpi() {
  return (
    <span className="inline-flex shrink-0 items-center gap-1 rounded-md bg-violet-500/10 px-1.5 py-0.5 text-[10px] font-medium text-violet-600 dark:text-violet-300" title="Written in the glossary with its business area, not read from a table">
      <BookOpen className="h-3 w-3" /> KPI from the glossary
    </span>
  );
}

function LineChips({ o, names }: { o: CatalogObject; names: Map<string, string> }) {
  if (!o.lines.length) {
    return (
      <span className="text-[11px] text-muted-foreground" title="Shared across lines: no tag, pipeline default, column or join ties this dataset to one line">
        Shared
      </span>
    );
  }
  return (
    <span className="flex flex-wrap gap-1" title={o.lines_note || undefined}>
      {o.lines.map((key) => {
        const style = lineStyle(key);
        return (
          <span key={key} className="inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[10px] font-medium" style={{ background: `hsl(${style.color} / 0.14)`, color: `hsl(${style.color})` }}>
            <style.icon className="h-3 w-3" /> {names.get(key) ?? key}
          </span>
        );
      })}
    </span>
  );
}

function Cell({ column, o, colorOf, names }: { column: ObjectColumn; o: CatalogObject; colorOf: (key: string | null) => string; names: Map<string, string> }) {
  switch (column) {
    case "lob":
      return (
        <TableCell className="py-2">
          <LineChips o={o} names={names} />
          {o.lines.length ? <div className="mt-0.5 max-w-[11rem] truncate text-[10px] text-muted-foreground" title={o.lines_note}>{o.lines_note}</div> : null}
        </TableCell>
      );
    case "type":
      return (
        <TableCell className="py-2">
          <TypeChip type={o.type} />
          <div className="mt-0.5 max-w-[10rem] truncate text-[10px] text-muted-foreground" title={o.detail}>
            {o.subtype}
            {o.detail ? ` · ${o.detail}` : ""}
          </div>
        </TableCell>
      );
    case "domain":
      return (
        <TableCell className="max-w-[12rem] py-2">
          <DomainCell o={o} colorOf={colorOf} />
        </TableCell>
      );
    case "model":
      return (
        <TableCell className="max-w-[12rem] py-2">
          <span className="flex items-center gap-1.5 text-xs">
            <PlatformDot platform={o.platform} />
            <span className="truncate">{o.model_label}</span>
          </span>
          <div className="truncate font-mono text-[10px] text-muted-foreground" title={o.model}>
            {o.model}
          </div>
        </TableCell>
      );
    case "owner":
      return (
        <TableCell className="max-w-[9rem] truncate py-2 text-xs" title={o.owner ?? undefined}>
          {o.owner ?? <span className="text-muted-foreground">–</span>}
        </TableCell>
      );
    case "quality":
      return (
        <TableCell className="py-2">
          <QualityBar value={o.quality} checks={o.checks} />
        </TableCell>
      );
    case "term":
      return (
        <TableCell className="max-w-[10rem] py-2">
          {o.term ? <span className="inline-block max-w-full truncate rounded-md bg-primary/10 px-1.5 py-0.5 text-[11px] text-primary">{o.term}</span> : <span className="text-xs text-muted-foreground">–</span>}
        </TableCell>
      );
    case "updated":
      return (
        <TableCell className="whitespace-nowrap py-2 text-xs text-muted-foreground" title={o.updated_at ?? undefined}>
          {formatRelative(o.updated_at)}
        </TableCell>
      );
  }
}

function Card({ o, colorOf, names, onOpen }: { o: CatalogObject; colorOf: (key: string | null) => string; names: Map<string, string>; onOpen: () => void }) {
  return (
    <button
      type="button"
      onClick={onOpen}
      className="group flex min-w-0 flex-col gap-2 rounded-2xl border border-border/70 bg-card p-3 text-left shadow-sm transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-md"
    >
      <div className="flex min-w-0 items-start gap-2.5">
        <TypeTile type={o.type} className="h-8 w-8 rounded-lg" />
        <div className="min-w-0">
          <div className="truncate text-sm font-medium">{o.name}</div>
          <div className="truncate font-mono text-[10px] text-muted-foreground" title={o.technical_name}>
            {o.technical_name}
          </div>
        </div>
      </div>
      {o.subtype === "kpi" ? <GlossaryKpi /> : null}
      {o.description ? <p className="line-clamp-2 text-xs text-muted-foreground">{o.description}</p> : null}
      <div className="flex flex-wrap gap-1 text-[10px]">
        <span className="inline-flex items-center gap-1 rounded-md border border-border/70 px-1.5 py-0.5">
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: `hsl(${colorOf(o.domain_key)})` }} aria-hidden="true" />
          {o.domain_name ?? "Unassigned"}
        </span>
        <span className="inline-flex max-w-full items-center gap-1 truncate rounded-md border border-border/70 px-1.5 py-0.5" title={o.model}>
          <PlatformDot platform={o.platform} className="h-1.5 w-1.5" />
          {o.model_label}
        </span>
        {o.term ? <span className="rounded-md bg-primary/10 px-1.5 py-0.5 text-primary">{o.term}</span> : null}
      </div>
      <LineChips o={o} names={names} />
      <div className="mt-auto flex items-center justify-between gap-2 pt-1">
        <QualityBar value={o.quality} checks={o.checks} />
        <span className="text-[10px] text-muted-foreground">{formatRelative(o.updated_at)}</span>
      </div>
    </button>
  );
}

type SelectFn = (sel: Selection, table?: Partial<TableState>) => void;

interface FiltersMenuProps {
  selection: Selection;
  table: TableState;
  owners: string[];
  lines: CatalogLine[];
  onSelection: SelectFn;
  onTable: (patch: Partial<TableState>) => void;
}

function FiltersMenu({ selection, table, owners, lines, onSelection, onTable }: FiltersMenuProps) {
  // Grouped by line, the tree picks the line; otherwise it is a filter like the others.
  const lineFilter = selection.by !== "lob";
  const active = (table.owner ? 1 : 0) + (table.minQuality ? 1 : 0) + (lineFilter && selection.lob ? 1 : 0);
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="h-9 gap-1.5">
          <Filter className="h-4 w-4" /> Filters
          {active ? <span className="rounded-full bg-primary px-1.5 text-[10px] font-medium text-primary-foreground">{active}</span> : null}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-72 space-y-3">
        {lineFilter ? (
          <Field label="Line of business">
            <Select value={selection.lob ?? ALL} onValueChange={(v) => onSelection({ ...selection, lob: v === ALL ? null : v })}>
              <SelectTrigger className="h-8 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL} className="text-xs">
                  All lines
                </SelectItem>
                {lines.map((l) => (
                  <SelectItem key={l.key} value={l.key} className="text-xs">
                    {l.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
        ) : null}
        <Field label="Owner">
          <Select value={table.owner ?? ALL} onValueChange={(v) => onTable({ owner: v === ALL ? null : v })}>
            <SelectTrigger className="h-8 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL} className="text-xs">
                All owners
              </SelectItem>
              {owners.map((o) => (
                <SelectItem key={o} value={o} className="text-xs">
                  {o}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
        <Field label="Minimum quality score">
          <Select value={String(table.minQuality)} onValueChange={(v) => onTable({ minQuality: Number(v) })}>
            <SelectTrigger className="h-8 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {QUALITY_STEPS.map((q) => (
                <SelectItem key={q} value={String(q)} className="text-xs">
                  {q === 0 ? "Any quality" : q === 100 ? "100 only" : `${q} or more`}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
        {active ? (
          <Button
            variant="ghost"
            size="sm"
            className="w-full"
            onClick={() => onSelection({ ...selection, lob: lineFilter ? null : selection.lob }, { owner: null, minQuality: 0 })}
          >
            Clear filters
          </Button>
        ) : null}
      </PopoverContent>
    </Popover>
  );
}

export function objectNoun(type: CatalogObjectType | null, total: number): string {
  if (!type) return total === 1 ? "object" : "objects";
  return total === 1 ? TYPE_META[type].label.toLowerCase() : TYPE_META[type].plural.toLowerCase();
}

interface ObjectsPaneProps {
  page: Page<CatalogObject> | undefined;
  loading: boolean;
  selection: Selection;
  table: TableState;
  owners: string[];
  lines: CatalogLine[];
  colorOf: (key: string | null) => string;
  onSelection: SelectFn;
  onTable: (patch: Partial<TableState>) => void;
  onOpen: (o: CatalogObject) => void;
  /** What to say when nothing matches, when the explorer knows better than "nothing matches". */
  emptyNote?: ReactNode;
}

/** The semantic objects at the selected node: searchable, filterable, sortable, as a table or as cards. */
export function ObjectsPane({ page, loading, selection, table, owners, lines, colorOf, onSelection, onTable, onOpen, emptyNote }: ObjectsPaneProps) {
  const [mode, setMode] = useStoredState<ViewMode>("ech-catalog-mode", "list");
  // Hidden columns are remembered, so a column added later shows up for everyone.
  const [hidden, setHidden] = useStoredState<ObjectColumn[]>("ech-catalog-hidden-columns", []);
  const columns = COLUMNS.filter((c) => !hidden.includes(c.key));
  const visible = columns.map((c) => c.key);
  const setVisible = (next: ObjectColumn[]) => setHidden(COLUMNS.map((c) => c.key).filter((k) => !next.includes(k)));
  const names = new Map(lines.map((l) => [l.key, l.name]));
  const sortBy = (sort: CatalogSort) => onTable(table.sort === sort ? { sort, order: table.order === "asc" ? "desc" : "asc" } : { sort, order: "asc" });
  const items = page?.items ?? [];
  const empty = page !== undefined && items.length === 0;
  const span = columns.length + 1;
  return (
    <>
      <div className="flex flex-wrap items-center gap-2">
        <SearchBox value={table.q} onChange={(q) => onTable({ q })} placeholder="Search semantic objects…" />
        <FiltersMenu selection={selection} table={table} owners={owners} lines={lines} onSelection={onSelection} onTable={onTable} />
        {mode === "list" ? <ColumnsMenu columns={COLUMNS} visible={visible} onChange={setVisible} /> : null}
        <ModeToggle mode={mode} onMode={setMode} />
      </div>
      {mode === "list" ? (
        <div className="scrollbar-hidden min-h-[16rem] flex-1 overflow-auto rounded-xl border border-border/60 bg-card [&_td]:px-3 [&_th]:px-3">
          <Table>
            <TableHeader className="sticky top-0 z-10 bg-card">
              <TableRow>
                <TableHead className="whitespace-nowrap">
                  <SortHeader label="Name" active={table.sort === "name"} order={table.order} onSort={() => sortBy("name")} />
                </TableHead>
                {columns.map((c) => (
                  <TableHead key={c.key} className="whitespace-nowrap">
                    {c.sort ? <SortHeader label={c.label} active={table.sort === c.sort} order={table.order} onSort={() => sortBy(c.sort as CatalogSort)} /> : <span className="normal-case">{c.label}</span>}
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading && !page
                ? Array.from({ length: 10 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell colSpan={span} className="py-2">
                        <Skeleton className="h-8 w-full" />
                      </TableCell>
                    </TableRow>
                  ))
                : items.map((o) => (
                    <TableRow key={o.id} className="cursor-pointer" onClick={() => onOpen(o)} title={o.description || undefined}>
                      <TableCell className="max-w-[20rem] py-2">
                        <div className="flex items-start gap-2">
                          <span className="mt-1 h-6 w-0.5 shrink-0 rounded-full" style={{ background: `hsl(${TYPE_META[o.type].color})` }} aria-hidden="true" />
                          <div className="min-w-0">
                            <div className="flex min-w-0 items-center gap-1.5">
                              <span className="truncate text-sm font-medium">{o.name}</span>
                              {o.subtype === "kpi" ? <GlossaryKpi /> : null}
                            </div>
                            <div className="truncate font-mono text-[10px] text-muted-foreground" title={o.technical_name}>
                              {o.technical_name}
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      {columns.map((c) => (
                        <Cell key={c.key} column={c.key} o={o} colorOf={colorOf} names={names} />
                      ))}
                    </TableRow>
                  ))}
              {empty ? (
                <TableRow>
                  <TableCell colSpan={span} className="px-4 py-10 text-center text-sm text-muted-foreground">
                    {emptyNote ?? "Nothing here matches. Widen the filters, or approve glossary proposals to place more objects in domains."}
                  </TableCell>
                </TableRow>
              ) : null}
            </TableBody>
          </Table>
        </div>
      ) : (
        <div className={cn("grid min-h-[16rem] content-start gap-3 [grid-template-columns:repeat(auto-fill,minmax(15rem,1fr))]")}>
          {loading && !page ? Array.from({ length: 9 }).map((_, i) => <Skeleton key={i} className="h-36 rounded-2xl" />) : items.map((o) => <Card key={o.id} o={o} colorOf={colorOf} names={names} onOpen={() => onOpen(o)} />)}
          {empty ? <div className="col-span-full py-10 text-center text-sm text-muted-foreground">{emptyNote ?? "Nothing here matches. Widen the filters."}</div> : null}
        </div>
      )}
      <Pager total={page?.total ?? 0} offset={table.offset} limit={page?.limit ?? PAGE_SIZE} noun={objectNoun(selection.type, page?.total ?? 0)} onOffset={(offset) => onTable({ offset })} />
    </>
  );
}
