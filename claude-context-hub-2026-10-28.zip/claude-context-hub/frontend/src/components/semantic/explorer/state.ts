import { useState } from "react";

import type { CatalogObjectParams } from "@/api/endpoints";
import type { CatalogObjectType, CatalogSort } from "@/api/types";
import { OBJECT_TYPES } from "@/components/semantic/catalog-visuals";

export type GroupBy = "domain" | "source" | "lob";

/** Where the explorer is: a tree node. Every field lives in the URL, so any node can be linked. */
export interface Selection {
  by: GroupBy;
  domain: string | null;
  database: string | null;
  model: string | null;
  type: CatalogObjectType | null;
  /** A line of business: the tree node when grouped by line, a filter otherwise. */
  lob: string | null;
}

/** How the list on the right is narrowed, ordered and paged; also in the URL. */
export interface TableState {
  q: string;
  owner: string | null;
  minQuality: number;
  sort: CatalogSort;
  order: "asc" | "desc";
  offset: number;
}

export const PAGE_SIZE = 50;
const SORTS: CatalogSort[] = ["type", "name", "domain", "model", "owner", "quality", "updated"];
const PARAM: Record<Exclude<keyof Selection, "by">, string> = { domain: "domain", database: "db", model: "model", type: "type", lob: "lob" };

export function readSelection(p: URLSearchParams): Selection {
  const type = p.get("type");
  return {
    by: p.get("by") === "source" ? "source" : p.get("by") === "lob" ? "lob" : "domain",
    domain: p.get("domain"),
    database: p.get("db"),
    model: p.get("model"),
    // The page opens on tables; type=all lists every kind of object.
    type: type === "all" ? null : OBJECT_TYPES.includes(type as CatalogObjectType) ? (type as CatalogObjectType) : "entity",
    lob: p.get("lob"),
  };
}

export function readTable(p: URLSearchParams): TableState {
  const sort = p.get("sort") as CatalogSort | null;
  return {
    q: p.get("q") ?? "",
    owner: p.get("owner"),
    minQuality: Number(p.get("minq")) || 0,
    sort: sort && SORTS.includes(sort) ? sort : "type",
    order: p.get("order") === "desc" ? "desc" : "asc",
    offset: Math.max(0, Number(p.get("offset")) || 0),
  };
}

function put(p: URLSearchParams, key: string, value: string | null | undefined) {
  if (value) p.set(key, value);
  else p.delete(key);
}

/** The next URL: a new node replaces the whole selection; table changes keep it. Anything but paging starts at page one. */
export function writeState(current: URLSearchParams, selection: Selection | null, table: Partial<TableState> = {}): URLSearchParams {
  const next = new URLSearchParams(current);
  if (selection) {
    // Links from before the Data Catalog left this tree may still carry these.
    next.delete("root");
    next.delete("schema");
    put(next, "by", selection.by === "domain" ? null : selection.by);
    for (const [field, key] of Object.entries(PARAM)) {
      const value = field === "type" ? (selection.type === "entity" ? null : (selection.type ?? "all")) : selection[field as keyof typeof PARAM];
      put(next, key, value);
    }
  }
  if ("q" in table) put(next, "q", table.q?.trim() || null);
  if ("owner" in table) put(next, "owner", table.owner);
  if ("minQuality" in table) put(next, "minq", table.minQuality ? String(table.minQuality) : null);
  if ("sort" in table) put(next, "sort", table.sort === "type" ? null : table.sort);
  if ("order" in table) put(next, "order", table.order === "desc" ? "desc" : null);
  put(next, "offset", "offset" in table && table.offset ? String(table.offset) : null);
  return next;
}

export const EMPTY: Selection = { by: "domain", domain: null, database: null, model: null, type: null, lob: null };

/** One id per tree node, computed the same way for a node and for the URL, so the selected node is found by id. */
export function nodeId(s: Selection): string {
  if (s.by === "lob") return ["lob", s.lob ?? "", s.domain ?? "", s.type ?? ""].join("|");
  const scope = s.by === "source" ? (s.database ?? "") : (s.domain ?? "");
  return [s.by === "source" ? "src" : "dom", scope, s.model ?? "", s.type ?? ""].join("|");
}

/** What the objects API is asked for at a node. */
export function objectParams(s: Selection, t: TableState): CatalogObjectParams {
  const base: CatalogObjectParams = {
    type: s.type,
    lob: s.lob,
    search: t.q.trim() || null,
    owner: t.owner,
    min_quality: t.minQuality,
    sort: t.sort,
    order: t.order,
    limit: PAGE_SIZE,
    offset: t.offset,
  };
  if (s.by === "source") return { ...base, model: s.model, database: s.model ? null : s.database };
  return { ...base, domain: s.domain, direct: Boolean(s.domain && s.model), model: s.model };
}

/** A per-viewer preference kept in this browser (view mode, columns, tree width); the page works without storage. */
export function useStoredState<T>(key: string, initial: T): [T, (next: T) => void] {
  const [value, setValue] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : initial;
    } catch {
      return initial;
    }
  });
  const set = (next: T) => {
    setValue(next);
    try {
      localStorage.setItem(key, JSON.stringify(next));
    } catch {
      /* storage unavailable */
    }
  };
  return [value, set];
}
