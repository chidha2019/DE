import { ListTree, PanelLeftOpen, X } from "lucide-react";
import { useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";

import type { CatalogObject, SemanticCatalog } from "@/api/types";
import { domainStyle } from "@/components/glossary/visuals";
import { OBJECT_TYPES, QualityBar, TYPE_META } from "@/components/semantic/catalog-visuals";
import { Button } from "@/components/ui/button";
import { useCatalogObjects, useGlossaryCoverage } from "@/hooks/queries";
import { formatInt } from "@/lib/format";
import { cn } from "@/lib/utils";

import { NextStepBanner, TypeBar } from "./explorer-parts";
import { lineStyle } from "./line-style";
import { ObjectsPane } from "./objects-pane";
import { EMPTY, objectParams, readSelection, readTable, useStoredState, writeState, type GroupBy, type Selection, type TableState } from "./state";
import { Breadcrumbs } from "./toolbar";
import { ExplorerTree } from "./tree";
import { UNASSIGNED_KEY, countsFor, crumbsFor, describeNode } from "./tree-model";

interface CatalogExplorerProps {
  catalog: SemanticCatalog | undefined;
  catalogLoading: boolean;
  onOpenObject: (o: CatalogObject) => void;
}

/** The catalog as a tree and a list: every node, filter, sort and page lives in the URL, so any view can be linked. */
export function CatalogExplorer({ catalog, catalogLoading, onOpenObject }: CatalogExplorerProps) {
  const [params, setParams] = useSearchParams();
  const key = params.toString();
  const selection = useMemo(() => readSelection(new URLSearchParams(key)), [key]);
  const table = useMemo(() => readTable(new URLSearchParams(key)), [key]);
  const [treeOpen, setTreeOpen] = useStoredState("ech-catalog-tree", true);
  const [mobileTree, setMobileTree] = useState(false);

  const write = (sel: Selection | null, patch: Partial<TableState>, replace: boolean) => {
    const next = writeState(params, sel, patch);
    next.set("view", "catalog");
    setParams(next, { replace });
  };
  const select = (sel: Selection, patch: Partial<TableState> = {}) => {
    write(sel, patch, false);
    setMobileTree(false);
  };
  const patchTable = (patch: Partial<TableState>) => write(null, patch, true);
  // The tree and the breadcrumbs pick where; the bar above the list picks what (tables unless changed), so moving
  // keeps it, and keeps a line-of-business filter too unless grouped by line, where the node itself is the line.
  const go = (sel: Selection) => {
    const what = sel.type ? sel : { ...sel, type: selection.type };
    select(what.by === "lob" ? what : { ...what, lob: selection.lob });
  };
  const groupBy = (by: GroupBy) => select({ ...EMPTY, by, type: selection.type, lob: by === "lob" ? null : selection.lob });
  const lines = catalog?.lines ?? [];
  const lineFilter = selection.by !== "lob" && selection.lob ? lines.find((l) => l.key === selection.lob) : undefined;

  const objects = useCatalogObjects(objectParams(selection, table));
  const coverage = useGlossaryCoverage();
  const counts = countsFor(selection, catalog);
  const colorOf = useMemo(() => {
    const colors: Record<string, string> = { [UNASSIGNED_KEY]: "200 10% 55%" };
    for (const d of catalog?.domains ?? []) {
      colors[d.key] = domainStyle(d.key).color;
      for (const c of d.children) colors[c.key] = domainStyle(c.key, d.key).color;
    }
    return (k: string | null) => (k ? colors[k] : undefined) ?? "200 10% 55%";
  }, [catalog]);

  const crumbs = crumbsFor(selection, catalog);
  const { quality, note } = describeNode(selection, catalog);
  const total = objects.data?.total;
  const noun = selection.type ? (total === 1 ? TYPE_META[selection.type].label : TYPE_META[selection.type].plural).toLowerCase() : total === 1 ? "business object" : "business objects";
  const tables = catalog?.counts.entities ?? 0;
  const showBanner = Boolean(catalog) && selection.by !== "source" && tables > 0 && (catalog?.entities_placed ?? 0) * 2 < tables;

  // An empty list says where the pieces are instead of "nothing matches": a business area that so far
  // holds only KPI definitions from the glossary shows no tables, but it has metrics.
  const domainKeys = selection.domain ? [selection.domain, ...(catalog?.domains.find((d) => d.key === selection.domain)?.children.map((c) => c.key) ?? [])] : [];
  const onlyKpis = selection.by === "domain" && domainKeys.length > 0 && Boolean(catalog?.domain_models.filter((d) => domainKeys.includes(d.domain_key)).every((d) => d.model === "glossary"));
  const type = selection.type;
  const others = counts && type ? OBJECT_TYPES.filter((t) => t !== type && counts[TYPE_META[t].countKey] > 0) : [];
  const emptyNote =
    type && others.length && !table.q && !table.owner && !table.minQuality ? (
      <span>
        No {TYPE_META[type].plural.toLowerCase()} here{onlyKpis ? ": this business area only holds KPI definitions written in the glossary so far" : ""}.{" "}
        {others.map((t, i) => (
          <span key={t}>
            {i ? " · " : ""}
            <button type="button" className="text-primary hover:underline" onClick={() => select({ ...selection, type: t })}>
              Show {formatInt(counts?.[TYPE_META[t].countKey] ?? 0)} {TYPE_META[t].plural.toLowerCase()}
            </button>
          </span>
        ))}
      </span>
    ) : undefined;
  const tree = (className: string, collapsible: boolean) => (
    <ExplorerTree
      className={className}
      catalog={catalog}
      loading={catalogLoading}
      selection={selection}
      onSelect={go}
      onGroupBy={groupBy}
      onCollapse={collapsible ? () => setTreeOpen(false) : undefined}
    />
  );

  return (
    <div className="flex flex-1 lg:min-h-0">
      {treeOpen ? tree("hidden lg:flex", true) : null}
      <div className="flex min-w-0 flex-1 flex-col lg:min-h-0">
        <div className="flex items-center gap-2 border-b border-border/70 px-4 py-2">
          {!treeOpen ? (
            <Button variant="ghost" size="icon" className="hidden h-8 w-8 text-muted-foreground lg:inline-flex" onClick={() => setTreeOpen(true)} aria-label="Show the catalog tree" title="Show the tree">
              <PanelLeftOpen className="h-4 w-4" />
            </Button>
          ) : null}
          <Button variant="outline" size="sm" className="h-8 gap-1.5 lg:hidden" onClick={() => setMobileTree((open) => !open)} aria-expanded={mobileTree}>
            <ListTree className="h-4 w-4" /> Browse
          </Button>
          <Breadcrumbs crumbs={crumbs} onSelect={go} />
        </div>
        {mobileTree ? tree("max-h-[60vh] w-full border-b border-r-0 lg:hidden", false) : null}
        <div className="flex flex-1 flex-col gap-3 p-4 lg:min-h-0 lg:overflow-y-auto">
          {showBanner && catalog ? (
            <NextStepBanner tables={tables} placed={catalog.entities_placed} suggestions={coverage.data?.links_suggested} onBrowseBySource={() => groupBy("source")} />
          ) : null}
          <div className="flex flex-wrap items-end justify-between gap-x-6 gap-y-2">
            <div className="min-w-0">
              <h2 className="text-lg font-medium">
                {total === undefined ? <span className="inline-block h-5 w-10 animate-pulse rounded bg-muted align-middle" /> : <span className="tabular-nums">{formatInt(total)}</span>} {noun}
              </h2>
              {note ? <p className="line-clamp-2 max-w-3xl text-xs text-muted-foreground" title={note}>{note}</p> : null}
              {lineFilter ? (
                <button
                  type="button"
                  onClick={() => select({ ...selection, lob: null })}
                  className="mt-1 inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium"
                  style={{ background: `hsl(${lineStyle(lineFilter.key).color} / 0.14)`, color: `hsl(${lineStyle(lineFilter.key).color})` }}
                  title="Clear the line-of-business filter"
                >
                  {lineFilter.name} only <X className="h-3 w-3" />
                </button>
              ) : null}
            </div>
            {quality !== null && quality !== undefined ? (
              <div className="text-right">
                <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Mean quality</div>
                <QualityBar value={quality} width="w-28" className="mt-1" />
              </div>
            ) : null}
          </div>
          <TypeBar value={selection.type} counts={counts} onChange={(next) => select({ ...selection, type: next })} />
          {selection.type === "hierarchy" && catalog ? <p className={cn("rounded-xl border border-border/60 bg-muted/30 px-3 py-2 text-xs text-muted-foreground")}>{catalog.hierarchy_note}</p> : null}
          <ObjectsPane
            page={objects.data}
            loading={objects.isLoading}
            selection={selection}
            table={table}
            owners={catalog?.owners ?? []}
            lines={lines}
            colorOf={colorOf}
            onSelection={select}
            onTable={patchTable}
            onOpen={onOpenObject}
            emptyNote={emptyNote}
          />
        </div>
      </div>
    </div>
  );
}
