import { Briefcase, HeartPulse, PiggyBank, Share2, type LucideIcon } from "lucide-react";

export const SHARED_LINE = "__shared__";

const STYLE: Record<string, { color: string; icon: LucideIcon }> = {
  life: { color: "347 77% 58%", icon: HeartPulse },
  annuity: { color: "38 92% 50%", icon: PiggyBank },
  [SHARED_LINE]: { color: "200 10% 55%", icon: Share2 },
};

/** One hue and icon per line of business; lines added to the glossary later get a neutral briefcase. */
export function lineStyle(key: string): { color: string; icon: LucideIcon } {
  return STYLE[key] ?? { color: "262 70% 62%", icon: Briefcase };
}
