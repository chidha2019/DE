import { ArrowRight, Database, Lightbulb } from "lucide-react";
import { Link } from "react-router-dom";

import type { CatalogCounts, CatalogObjectType } from "@/api/types";
import { OBJECT_TYPES, TYPE_META } from "@/components/semantic/catalog-visuals";
import { Button } from "@/components/ui/button";
import { formatInt } from "@/lib/format";
import { cn } from "@/lib/utils";

/** While most tables have no business area, say why and what to do, in place of a footnote. */
export function NextStepBanner({ tables, placed, suggestions, onBrowseBySource }: { tables: number; placed: number; suggestions: number | undefined; onBrowseBySource: () => void }) {
  return (
    <section className="flex flex-wrap items-start gap-3 rounded-2xl border border-amber-500/30 bg-amber-500/10 p-4">
      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-amber-500/20 text-amber-600 dark:text-amber-300">
        <Lightbulb className="h-5 w-5" />
      </span>
      <div className="min-w-[16rem] flex-1 space-y-1">
        <h3 className="text-sm font-medium">
          {placed ? `Only ${formatInt(placed)} of your ${formatInt(tables)} tables are sorted into a business area` : `Your ${formatInt(tables)} tables are not sorted into business areas yet`}
        </h3>
        <p className="text-xs text-muted-foreground">
          A table moves out of <span className="font-medium text-foreground">Unassigned</span> into its business area (Policy Administration, Claims, Billing…) once you approve a glossary
          suggestion for it, such as “POLICY.POLICY is a Policy”.
          {suggestions ? ` After the last sync the hub made ${formatInt(suggestions)} suggestions; they are waiting for you.` : ""}
        </p>
        <div className="flex flex-wrap gap-2 pt-1">
          <Button size="sm" asChild>
            <Link to="/glossary/review">
              {suggestions ? `Review ${formatInt(suggestions)} suggestions` : "Open the glossary review"} <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </Button>
          <Button size="sm" variant="outline" onClick={onBrowseBySource}>
            <Database className="h-3.5 w-3.5" /> Browse by database meanwhile
          </Button>
        </div>
      </div>
    </section>
  );
}

/** What the list shows: tables by default, or one other kind of piece, or everything. */
export function TypeBar({ value, counts, onChange }: { value: CatalogObjectType | null; counts: CatalogCounts | undefined; onChange: (next: CatalogObjectType | null) => void }) {
  const items: { key: CatalogObjectType | null; label: string; hint: string; count: number | undefined; color?: string }[] = [
    ...OBJECT_TYPES.map((t) => ({ key: t, label: TYPE_META[t].plural, hint: TYPE_META[t].hint, count: counts?.[TYPE_META[t].countKey], color: TYPE_META[t].color })),
    { key: null, label: "All", hint: "Every kind of piece at once", count: counts?.total },
  ];
  return (
    <div className="flex flex-wrap gap-1.5" role="radiogroup" aria-label="What to show">
      {items.map((i) => {
        const Icon = i.key ? TYPE_META[i.key].icon : null;
        const active = value === i.key;
        return (
          <button
            key={i.key ?? "all"}
            type="button"
            role="radio"
            aria-checked={active}
            title={i.hint}
            onClick={() => onChange(i.key)}
            className={cn(
              "inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-xs transition-colors",
              active ? "border-transparent font-medium text-white shadow-sm" : "border-border/70 bg-card/60 text-muted-foreground hover:text-foreground",
              !active && i.count === 0 && "opacity-50",
            )}
            style={active ? { background: i.color ? `hsl(${i.color})` : "hsl(var(--primary))" } : undefined}
          >
            {Icon ? <Icon className="h-3.5 w-3.5" /> : null}
            {i.label}
            {i.count !== undefined ? <span className={cn("font-mono text-[10px] tabular-nums", active ? "text-white/80" : "")}>{formatInt(i.count)}</span> : null}
          </button>
        );
      })}
    </div>
  );
}
