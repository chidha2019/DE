import type { CatalogCounts, CatalogDomain, CatalogObjectType, SemanticCatalog } from "@/api/types";
import { OBJECT_TYPES, TYPE_META } from "@/components/semantic/catalog-visuals";

import { EMPTY, nodeId, type GroupBy, type Selection } from "./state";

export const UNASSIGNED_KEY = "__unassigned__";

export type NodeIcon =
  | { kind: "root" }
  | { kind: "domain"; key: string; parentKey: string | null }
  | { kind: "line"; key: string }
  | { kind: "brand"; platform: string }
  | { kind: "model"; platform: string }
  | { kind: "schema" }
  | { kind: "type"; type: CatalogObjectType };

export interface TreeNode {
  id: string;
  label: string;
  /** Second line or tooltip: the technical name behind a business label. */
  hint?: string;
  icon: NodeIcon;
  count?: number;
  quality?: number | null;
  muted?: boolean;
  sel: Selection;
  children: TreeNode[];
}

function node(sel: Selection, label: string, icon: NodeIcon, extra: Partial<TreeNode> = {}): TreeNode {
  return { id: nodeId(sel), label, icon, sel, children: [], ...extra };
}

/** The six object types under a model, zero counts dimmed so every model reads the same way. */
function typeNodes(sel: Selection, counts: CatalogCounts): TreeNode[] {
  return OBJECT_TYPES.map((type) => {
    const n = counts[TYPE_META[type].countKey];
    return node({ ...sel, type }, TYPE_META[type].plural, { kind: "type", type }, { count: n, muted: !n });
  });
}

function weighted(items: { counts: CatalogCounts; quality: number | null }[]): number | null {
  const scored = items.filter((i) => i.quality !== null && i.counts.total);
  const total = scored.reduce((n, i) => n + i.counts.total, 0);
  return total ? Math.round(scored.reduce((n, i) => n + (i.quality ?? 0) * i.counts.total, 0) / total) : null;
}

export const GLOSSARY_KPIS = "Glossary KPI definitions";
export const GLOSSARY_KPIS_HINT = "Written in the glossary with their business area, not read from a table";

export function modelInfo(catalog: SemanticCatalog, model: string): { label: string; hint: string; platform: string } {
  const src = catalog.sources.find((s) => s.model === model);
  if (model === "glossary") return { label: GLOSSARY_KPIS, hint: GLOSSARY_KPIS_HINT, platform: "hub" };
  return { label: src?.model_label ?? model, hint: model, platform: src?.platform ?? "" };
}

function sourceChildren(catalog: SemanticCatalog, rootSel: Selection): TreeNode[] {
  const byDb = new Map<string, typeof catalog.sources>();
  for (const s of catalog.sources) byDb.set(s.database, [...(byDb.get(s.database) ?? []), s]);
  const databases: TreeNode[] = [];
  const loose: TreeNode[] = [];
  for (const [database, sources] of byDb) {
    if (!database) {
      for (const s of sources) {
        const sel = { ...rootSel, model: s.model };
        loose.push(node(sel, GLOSSARY_KPIS, { kind: "model", platform: s.platform }, { hint: GLOSSARY_KPIS_HINT, count: s.counts.total, quality: s.quality, children: typeNodes(sel, s.counts) }));
      }
      continue;
    }
    const dbSel = { ...rootSel, database };
    const schemas = sources.map((s) => {
      const sel = { ...dbSel, model: s.model };
      return node(sel, s.schema_name, { kind: "schema" }, { hint: s.model_label, count: s.counts.total, quality: s.quality, children: typeNodes(sel, s.counts) });
    });
    const count = sources.reduce((n, s) => n + s.counts.total, 0);
    databases.push(node(dbSel, database, { kind: "brand", platform: sources[0]?.platform ?? "" }, { count, quality: weighted(sources), children: schemas }));
  }
  return [...databases, ...loose];
}

/** Line of business → top-level domain → type; a dataset holding two lines appears under both. */
function lineChildren(catalog: SemanticCatalog, rootSel: Selection): TreeNode[] {
  const order = new Map(catalog.domains.map((d, i) => [d.key, i]));
  const names = new Map(catalog.domains.map((d) => [d.key, d.name]));
  return catalog.lines.map((line) => {
    const sel = { ...rootSel, lob: line.key };
    const domains = [...line.domains]
      .sort((a, b) => (order.get(a.domain_key) ?? 999) - (order.get(b.domain_key) ?? 999))
      .map((d) => {
        const dsel = { ...sel, domain: d.domain_key };
        const label = names.get(d.domain_key) ?? (d.domain_key === UNASSIGNED_KEY ? "Unassigned" : d.domain_key);
        return node(dsel, label, { kind: "domain", key: d.domain_key, parentKey: null }, { count: d.counts.total, children: typeNodes(dsel, d.counts) });
      });
    return node(sel, line.name, { kind: "line", key: line.key }, { hint: line.description || undefined, count: line.counts.total, quality: line.quality, muted: !line.counts.total, children: domains });
  });
}

/** Business domain → sub-domain → model → type, or database → schema → type when grouped by source. */
export function semanticTree(catalog: SemanticCatalog, by: GroupBy, showEmpty: boolean): { root: TreeNode; hiddenEmpty: number } {
  const rootSel: Selection = { ...EMPTY, by };
  const root = node(rootSel, "Semantic Catalog", { kind: "root" }, { count: catalog.counts.total, quality: catalog.quality });
  let hiddenEmpty = 0;
  if (by === "source") {
    root.children = sourceChildren(catalog, rootSel);
    return { root, hiddenEmpty };
  }
  if (by === "lob") {
    root.children = lineChildren(catalog, rootSel);
    return { root, hiddenEmpty };
  }
  const direct = new Map<string, typeof catalog.domain_models>();
  for (const dm of catalog.domain_models) direct.set(dm.domain_key, [...(direct.get(dm.domain_key) ?? []), dm]);
  const models = (domainKey: string) =>
    (direct.get(domainKey) ?? []).map((dm) => {
      const sel = { ...rootSel, domain: domainKey, model: dm.model };
      const info = modelInfo(catalog, dm.model);
      return node(sel, info.label, { kind: "model", platform: info.platform }, { hint: info.hint, count: dm.counts.total, quality: dm.quality, children: typeNodes(sel, dm.counts) });
    });
  const domainNode = (d: CatalogDomain, parentKey: string | null, subs: CatalogDomain[]): TreeNode | null => {
    if (!d.counts.total && !showEmpty) {
      hiddenEmpty += 1;
      return null;
    }
    const children = subs.map((c) => domainNode(c, d.key, [])).filter((n): n is TreeNode => n !== null);
    return node({ ...rootSel, domain: d.key }, d.name, { kind: "domain", key: d.key, parentKey }, {
      hint: d.description || undefined,
      count: d.counts.total,
      quality: d.quality,
      muted: !d.counts.total,
      children: [...children, ...models(d.key)],
    });
  };
  for (const d of catalog.domains) {
    const n = domainNode(d, null, d.children);
    if (n) root.children.push(n);
  }
  return { root, hiddenEmpty };
}

/** The node and every node under it whose label or hint matches; ancestors of a match stay. */
export function filterTree(n: TreeNode, needle: string): TreeNode | null {
  const q = needle.trim().toLowerCase();
  if (!q) return n;
  const children = n.children.map((c) => filterTree(c, q)).filter((c): c is TreeNode => c !== null);
  const hit = n.label.toLowerCase().includes(q) || (n.hint ?? "").toLowerCase().includes(q);
  return hit || children.length ? { ...n, children: hit && !children.length ? n.children : children } : null;
}

/** Ids from the root down to the node with this id, or [] when it is not in the tree. */
export function pathTo(n: TreeNode, id: string): string[] {
  if (n.id === id) return [n.id];
  for (const c of n.children) {
    const p = pathTo(c, id);
    if (p.length) return [n.id, ...p];
  }
  return [];
}

export interface Crumb {
  label: string;
  sel: Selection;
}

function findDomain(catalog: SemanticCatalog, key: string): { domain: CatalogDomain; parent: CatalogDomain | null } | null {
  for (const d of catalog.domains) {
    if (d.key === key) return { domain: d, parent: null };
    const child = d.children.find((c) => c.key === key);
    if (child) return { domain: child, parent: d };
  }
  return null;
}

/** The trail from the root to the selected node, each step selectable. */
export function crumbsFor(sel: Selection, catalog: SemanticCatalog | undefined): Crumb[] {
  const base: Selection = { ...EMPTY, by: sel.by };
  const out: Crumb[] = [{ label: "Semantic Catalog", sel: base }];
  let at = base;
  if (sel.by === "domain" && sel.domain) {
    const found = catalog ? findDomain(catalog, sel.domain) : null;
    if (found?.parent) out.push({ label: found.parent.name, sel: { ...base, domain: found.parent.key } });
    at = { ...base, domain: sel.domain };
    out.push({ label: found?.domain.name ?? sel.domain, sel: at });
  }
  if (sel.by === "source" && sel.database) {
    at = { ...base, database: sel.database };
    out.push({ label: sel.database, sel: at });
  }
  if (sel.by === "lob" && sel.lob) {
    at = { ...base, lob: sel.lob };
    out.push({ label: catalog?.lines.find((l) => l.key === sel.lob)?.name ?? sel.lob, sel: at });
    if (sel.domain) {
      at = { ...at, domain: sel.domain };
      const found = catalog ? findDomain(catalog, sel.domain) : null;
      out.push({ label: found?.domain.name ?? (sel.domain === UNASSIGNED_KEY ? "Unassigned" : sel.domain), sel: at });
    }
  }
  if (sel.model) {
    at = { ...at, model: sel.model };
    const label = sel.by === "source" && sel.database ? sel.model.slice(sel.database.length + 1) : catalog ? modelInfo(catalog, sel.model).label : sel.model;
    out.push({ label, sel: at });
  }
  if (sel.type) out.push({ label: TYPE_META[sel.type].plural, sel: { ...at, type: sel.type } });
  return out;
}

/** What the selected node is called and what it holds, for the heading on the right. */
export function describeNode(sel: Selection, catalog: SemanticCatalog | undefined): { quality: number | null; note: string } {
  if (!catalog) return { quality: null, note: "" };
  if (sel.model) {
    const at = sel.by === "domain" ? catalog.domain_models.find((d) => d.domain_key === sel.domain && d.model === sel.model) : catalog.sources.find((s) => s.model === sel.model);
    const info = modelInfo(catalog, sel.model);
    return { quality: at?.quality ?? null, note: sel.by === "domain" ? `${info.label} · ${info.hint}` : info.label };
  }
  if (sel.by === "lob" && sel.lob) {
    const line = catalog.lines.find((l) => l.key === sel.lob);
    return { quality: line?.quality ?? null, note: line?.description ?? "" };
  }
  if (sel.by === "domain" && sel.domain) {
    const found = findDomain(catalog, sel.domain);
    return { quality: found?.domain.quality ?? null, note: found?.domain.description ?? "" };
  }
  if (sel.by === "source" && sel.database) {
    const sources = catalog.sources.filter((s) => s.database === sel.database);
    return { quality: weighted(sources), note: `${sources.length} schemas` };
  }
  return {
    quality: catalog.quality,
    note: "Your Snowflake and Databricks tables, split into the pieces people talk about (columns to group by, amounts to add up, calculations, links) and sorted into business areas from the glossary.",
  };
}

/** The per-type counts of the selected node, for the bar that picks what to show; undefined when no figure fits. */
export function countsFor(sel: Selection, catalog: SemanticCatalog | undefined): CatalogCounts | undefined {
  if (!catalog) return undefined;
  if (sel.by === "lob") {
    const line = sel.lob ? catalog.lines.find((l) => l.key === sel.lob) : undefined;
    if (!sel.lob) return catalog.counts;
    return sel.domain ? line?.domains.find((d) => d.domain_key === sel.domain)?.counts : line?.counts;
  }
  if (sel.lob) return undefined;
  if (sel.by === "source") {
    if (sel.model) return catalog.sources.find((s) => s.model === sel.model)?.counts;
    if (!sel.database) return catalog.counts;
    const sources = catalog.sources.filter((s) => s.database === sel.database);
    const out: CatalogCounts = { entities: 0, dimensions: 0, measures: 0, metrics: 0, relationships: 0, hierarchies: 0, total: 0 };
    for (const s of sources) for (const k of Object.keys(out) as (keyof CatalogCounts)[]) out[k] += s.counts[k];
    return out;
  }
  if (sel.model) return catalog.domain_models.find((d) => d.domain_key === sel.domain && d.model === sel.model)?.counts;
  if (sel.domain) return findDomain(catalog, sel.domain)?.domain.counts;
  return catalog.counts;
}
