import { BookOpen, Box, Briefcase, ChevronRight, Database, Folder, Inbox, LibraryBig, Network, PanelLeftClose, Search } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

import type { SemanticCatalog } from "@/api/types";
import { BrandMark } from "@/components/connectors/brand-mark";
import { Tile, domainStyle } from "@/components/glossary/visuals";
import { TYPE_META, qualityTone } from "@/components/semantic/catalog-visuals";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { formatInt } from "@/lib/format";
import { cn } from "@/lib/utils";

import { lineStyle } from "./line-style";
import { EMPTY, nodeId, useStoredState, type GroupBy, type Selection } from "./state";
import { UNASSIGNED_KEY, filterTree, pathTo, semanticTree, type NodeIcon, type TreeNode } from "./tree-model";

function Glyph({ icon }: { icon: NodeIcon }) {
  switch (icon.kind) {
    case "root":
      return <Tile color="199 89% 48%" icon={LibraryBig} className="h-6 w-6 rounded-lg" iconClass="h-3.5 w-3.5" />;
    case "domain": {
      const v = icon.key === UNASSIGNED_KEY ? { color: "200 10% 55%", icon: Inbox } : domainStyle(icon.key, icon.parentKey);
      return <Tile color={v.color} icon={v.icon} className="h-5 w-5 rounded-md" iconClass="h-3 w-3" />;
    }
    case "line": {
      const v = lineStyle(icon.key);
      return <Tile color={v.color} icon={v.icon} className="h-5 w-5 rounded-md" iconClass="h-3 w-3" />;
    }
    case "brand":
      return <BrandMark icon={icon.platform} size="xs" />;
    case "model":
      return icon.platform === "hub" ? <BookOpen className="h-4 w-4 shrink-0 text-primary" /> : <Box className="h-4 w-4 shrink-0 text-primary" />;
    case "schema":
      return <Folder className="h-4 w-4 shrink-0 text-muted-foreground" />;
    case "type": {
      const meta = TYPE_META[icon.type];
      return <meta.icon className="h-4 w-4 shrink-0" style={{ color: `hsl(${meta.color})` }} />;
    }
  }
}

interface BranchProps {
  node: TreeNode;
  depth: number;
  expanded: Set<string>;
  forceOpen: boolean;
  selectedId: string;
  onToggle: (id: string) => void;
  onSelect: (node: TreeNode) => void;
}

function Branch({ node, depth, expanded, forceOpen, selectedId, onToggle, onSelect }: BranchProps) {
  const hasChildren = node.children.length > 0;
  const open = hasChildren && (forceOpen || expanded.has(node.id));
  const selected = node.id === selectedId;
  return (
    <>
      <div
        role="treeitem"
        aria-expanded={hasChildren ? open : undefined}
        aria-selected={selected}
        className={cn(
          "relative flex items-center gap-1 rounded-lg pr-2 text-[13px] transition-colors",
          selected ? "bg-primary/10 text-foreground" : "hover:bg-muted/60",
          node.muted && !selected && "text-muted-foreground/70",
        )}
        style={{ paddingLeft: 4 + depth * 14 }}
      >
        {selected ? <span className="absolute inset-y-1 left-0 w-0.5 rounded-r-full bg-primary" aria-hidden="true" /> : null}
        <button type="button" tabIndex={-1} aria-label={open ? "Collapse" : "Expand"} onClick={() => onToggle(node.id)} className={cn("flex h-7 w-5 shrink-0 items-center justify-center text-muted-foreground", !hasChildren && "invisible")}>
          <ChevronRight className={cn("h-3.5 w-3.5 transition-transform duration-150", open && "rotate-90")} />
        </button>
        <button type="button" onClick={() => onSelect(node)} title={node.hint} className="flex min-w-0 flex-1 items-center gap-2 rounded py-1 text-left outline-none focus-visible:ring-2 focus-visible:ring-ring">
          <Glyph icon={node.icon} />
          <span className={cn("min-w-0 flex-1 truncate", (depth === 0 || selected) && "font-medium")}>{node.label}</span>
          {node.quality != null && depth > 0 ? <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: `hsl(${qualityTone(node.quality)})` }} title={`mean quality ${node.quality} / 100`} aria-hidden="true" /> : null}
          {node.count !== undefined ? <span className="shrink-0 font-mono text-[11px] tabular-nums text-muted-foreground">({formatInt(node.count)})</span> : null}
        </button>
      </div>
      {open ? (
        <div role="group">
          {node.children.map((c) => (
            <Branch key={c.id} node={c} depth={depth + 1} expanded={expanded} forceOpen={forceOpen} selectedId={selectedId} onToggle={onToggle} onSelect={onSelect} />
          ))}
        </div>
      ) : null}
    </>
  );
}

const GROUPS: { key: GroupBy; label: string; icon: typeof Network; hint: string }[] = [
  { key: "domain", label: "Domain", icon: Network, hint: "Business domain: where accepted glossary terms place each object" },
  { key: "lob", label: "Line of business", icon: Briefcase, hint: "Life, Annuity, or shared: decided at sync from tags, pipeline defaults, column values and joins" },
  { key: "source", label: "Source", icon: Database, hint: "Where each object is read from: database and schema" },
];

interface ExplorerTreeProps {
  catalog: SemanticCatalog | undefined;
  loading: boolean;
  selection: Selection;
  onSelect: (sel: Selection) => void;
  onGroupBy: (by: GroupBy) => void;
  onCollapse?: () => void;
  className?: string;
}

/** The Semantic Catalog as a tree, by business domain, line of business or source. Tables and views live in the Data catalog tab. */
export function ExplorerTree({ catalog, loading, selection, onSelect, onGroupBy, onCollapse, className }: ExplorerTreeProps) {
  const [filter, setFilter] = useState("");
  const [showEmpty, setShowEmpty] = useStoredState("ech-catalog-show-empty", false);
  const [expanded, setExpanded] = useState<Set<string>>(() => new Set([nodeId({ ...EMPTY, by: selection.by })]));
  const semantic = useMemo(() => (catalog ? semanticTree(catalog, selection.by, showEmpty) : null), [catalog, selection.by, showEmpty]);
  // A type picked in the bar above the list has no node of its own outside a model: highlight the place instead.
  const exactId = nodeId(selection);
  const selectedId = semantic && !pathTo(semantic.root, exactId).length ? nodeId({ ...selection, type: null }) : exactId;

  // A deep link or a breadcrumb opens the path down to its node.
  useEffect(() => {
    const path = semantic ? pathTo(semantic.root, selectedId) : [];
    if (!path.length) return;
    setExpanded((prev) => {
      if (path.every((id) => prev.has(id))) return prev;
      const next = new Set(prev);
      for (const id of path) next.add(id);
      return next;
    });
  }, [semantic, selectedId]);

  const toggle = (id: string) =>
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  const select = (n: TreeNode) => {
    onSelect(n.sel);
    if (n.children.length && !expanded.has(n.id)) toggle(n.id);
  };
  const filtering = filter.trim().length > 0;
  const shownSemantic = semantic ? filterTree(semantic.root, filter) : null;
  const branch = { depth: 0, expanded, forceOpen: filtering, selectedId, onToggle: toggle, onSelect: select };

  return (
    <aside className={cn("flex w-80 shrink-0 flex-col border-r border-border/70 bg-card/40", className)}>
      <div className="flex items-center justify-between gap-2 px-3 pt-3">
        <span className="text-sm font-medium">Catalog</span>
        {onCollapse ? (
          <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground" onClick={onCollapse} aria-label="Hide the catalog tree" title="Hide the tree">
            <PanelLeftClose className="h-4 w-4" />
          </Button>
        ) : null}
      </div>
      <div className="mx-3 mt-2 flex gap-1 rounded-xl border border-border/70 bg-muted/40 p-1" role="radiogroup" aria-label="Group the semantic catalog by">
        {GROUPS.map((g) => (
          <button
            key={g.key}
            type="button"
            role="radio"
            aria-checked={selection.by === g.key}
            title={g.hint}
            onClick={() => onGroupBy(g.key)}
            className={cn(
              "flex flex-auto items-center justify-center gap-1 whitespace-nowrap rounded-lg px-1.5 py-1.5 text-[11px] transition-colors",
              selection.by === g.key ? "bg-card font-medium text-foreground shadow-sm ring-1 ring-primary/35" : "text-muted-foreground hover:text-foreground",
            )}
          >
            <g.icon className="h-3.5 w-3.5" /> {g.label}
          </button>
        ))}
      </div>
      <div className="relative mx-3 my-2">
        <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
        <Input value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="Filter tree…" className="h-8 pl-8 text-xs" aria-label="Filter the catalog tree" />
      </div>
      <div role="tree" aria-label="Catalog" className="scrollbar-hidden min-h-0 flex-1 overflow-y-auto px-1.5 pb-3">
        {loading && !semantic ? (
          <div className="space-y-1.5 px-2">
            {Array.from({ length: 8 }).map((_, i) => (
              <Skeleton key={i} className="h-6 w-full" />
            ))}
          </div>
        ) : null}
        {shownSemantic ? <Branch node={shownSemantic} {...branch} /> : null}
        {semantic && selection.by === "domain" && !filtering && (showEmpty || semantic.hiddenEmpty > 0) ? (
          <button type="button" onClick={() => setShowEmpty(!showEmpty)} className="ml-7 mt-1 text-[11px] text-muted-foreground hover:text-foreground">
            {showEmpty ? "Hide empty domains" : `Show ${semantic.hiddenEmpty} empty domain${semantic.hiddenEmpty === 1 ? "" : "s"}`}
          </button>
        ) : null}
        {filtering && !shownSemantic ? <p className="px-3 py-6 text-center text-xs text-muted-foreground">Nothing in the tree matches “{filter.trim()}”.</p> : null}
      </div>
    </aside>
  );
}
