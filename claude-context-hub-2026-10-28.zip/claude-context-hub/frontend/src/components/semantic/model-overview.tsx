import { Info, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";

import type { BusinessModel, EnrichRun, SubjectArea } from "@/api/types";
import { CompositionBar, Gauge, KIND_ORDER, KindTile, MiniRing, PlatformDot, kindColor, kindLabel, kindSegments, platformColor } from "@/components/semantic/visuals";
import { Button } from "@/components/ui/button";
import { formatInt, formatPercent } from "@/lib/format";
import { cn } from "@/lib/utils";

export function areaId(area: SubjectArea): string {
  return `area-${area.platform}-${area.database_name}-${area.schema_name}`.replace(/[^a-zA-Z0-9-]/g, "-").toLowerCase();
}

function areaCounts(area: SubjectArea): Record<string, number> {
  return {
    fact: area.facts.length,
    dimension: area.dimensions.filter((d) => d.kind === "dimension").length,
    reference: area.dimensions.filter((d) => d.kind !== "dimension").length,
    bridge: area.other.filter((a) => a.kind === "bridge").length,
    metric: area.metric_views.length,
    unknown: area.other.filter((a) => a.kind !== "bridge").length,
  };
}

function RunProgress({ run }: { run: EnrichRun }) {
  const finished = run.done + run.failed;
  const pct = run.total ? Math.round((finished / run.total) * 100) : 100;
  if (run.status !== "running" && run.total === 0) {
    return (
      <div className="flex flex-wrap items-center gap-2 text-xs text-warning">
        <Info className="h-3.5 w-3.5 shrink-0" />
        <span>{run.message ?? "Nothing to name in this scope."}</span>
        {run.skipped_proposed ? (
          <Link to="/qa/review" className="text-primary hover:underline">
            Review the proposals
          </Link>
        ) : null}
      </div>
    );
  }
  return (
    <div className="flex items-center gap-2 text-xs text-muted-foreground" title={run.error ?? undefined}>
      <div className="h-1.5 w-28 overflow-hidden rounded-full bg-muted">
        <div className={cn("h-full transition-all", run.status === "failed" ? "bg-destructive" : "bg-primary")} style={{ width: `${pct}%` }} />
      </div>
      <span>
        {finished}/{run.total}
        {run.failed ? <span className="text-destructive"> · {run.failed} failed</span> : null}
        {run.status === "completed" ? " · done" : ""}
      </span>
    </div>
  );
}

/** One row per kind: tile, label, count, share bar. Fills the left column so it sits level with the map. */
function KindBreakdown({ counts, total }: { counts: Record<string, number>; total: number }) {
  const rows = KIND_ORDER.map((kind) => ({ kind, value: counts[kind] ?? 0 })).filter((r) => r.value > 0);
  return (
    <div className="grid gap-1.5" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(13rem, 1fr))" }}>
      {rows.map(({ kind, value }) => {
        const share = total ? value / total : 0;
        return (
          <div key={kind} className="flex items-center gap-2.5 rounded-xl border border-border/60 bg-background/40 px-2.5 py-2">
            <KindTile kind={kind} className="h-8 w-8" iconClass="h-3.5 w-3.5" />
            <div className="min-w-0 flex-1">
              <div className="flex items-baseline justify-between gap-2">
                <span className="truncate text-xs font-medium">{kindLabel(kind)}</span>
                <span className="font-mono text-xs tabular-nums">
                  {formatInt(value)} <span className="text-[10px] text-muted-foreground">· {formatPercent(share)}</span>
                </span>
              </div>
              <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-muted/60">
                <div className="h-full rounded-full" style={{ width: `${Math.max(3, share * 100)}%`, background: `hsl(${kindColor(kind)})` }} />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function AreaTile({ area, onJump }: { area: SubjectArea; onJump: (id: string) => void }) {
  const counts = areaCounts(area);
  const described = area.assets ? area.described / area.assets : 0;
  const accent = platformColor(area.platform);
  return (
    <button
      type="button"
      onClick={() => onJump(areaId(area))}
      className="group relative flex flex-col overflow-hidden rounded-xl border border-border/70 bg-background/50 p-3 text-left transition-all hover:-translate-y-0.5 hover:border-primary/50"
    >
      <span className="absolute inset-x-0 top-0 h-[2px]" style={{ background: `linear-gradient(90deg, hsl(${accent}), hsl(${accent} / 0.1))` }} aria-hidden="true" />
      <span className="pointer-events-none absolute -right-8 -top-8 h-20 w-20 rounded-full opacity-[0.12] blur-2xl transition-opacity group-hover:opacity-30" style={{ background: `hsl(${accent})` }} aria-hidden="true" />
      <span className="relative flex items-start justify-between gap-2">
        <span className="min-w-0">
          <span className="flex items-center gap-1.5 text-[10px] uppercase tracking-wide text-muted-foreground">
            <PlatformDot platform={area.platform} />
            <span className="truncate">{area.platform}</span>
          </span>
          <span className="mt-0.5 line-clamp-1 font-display text-sm font-medium leading-tight">{area.label}</span>
          <span className="block truncate font-mono text-[10px] text-muted-foreground">
            {area.database_name}.{area.schema_name}
          </span>
        </span>
        <MiniRing value={described} title={`${formatPercent(described)} described`} />
      </span>
      <span className="relative mt-2 flex items-baseline gap-1.5">
        <span className="font-display text-2xl font-medium leading-none tabular-nums">{formatInt(area.assets)}</span>
        <span className="text-[10px] text-muted-foreground">datasets</span>
        <span className="ml-auto text-[10px] text-muted-foreground">{area.named}/{area.assets} named</span>
      </span>
      <CompositionBar segments={kindSegments(counts)} legend={false} height="h-1.5" className="relative mt-2" />
      <span className="relative mt-1.5 text-[10px] text-muted-foreground">
        {counts.fact ?? 0} facts · {(counts.dimension ?? 0) + (counts.reference ?? 0)} dimensions · {counts.metric ?? 0} metric views
      </span>
    </button>
  );
}

/** The top of the business model: what the scope is made of, how well it is described, and a map of its subject areas. */
export function ModelOverview({
  model,
  onJump,
  onEnrich,
  enrichPending,
  enrichRun,
}: {
  model: BusinessModel;
  onJump: (id: string) => void;
  onEnrich: () => void;
  enrichPending: boolean;
  enrichRun: EnrichRun | null;
}) {
  const areas = model.subject_areas;
  const totals = areas.reduce(
    (t, a) => {
      t.assets += a.assets;
      t.described += a.described;
      t.named += a.named;
      t.placed += a.assets - a.other.filter((x) => x.kind !== "bridge").length;
      const c = areaCounts(a);
      for (const k of Object.keys(c)) t.counts[k] = (t.counts[k] ?? 0) + (c[k] ?? 0);
      return t;
    },
    { assets: 0, described: 0, named: 0, placed: 0, counts: {} as Record<string, number> },
  );
  const platforms = new Set(areas.map((a) => a.platform));
  const running = enrichRun?.status === "running";
  const ratio = (n: number) => (totals.assets ? n / totals.assets : 0);
  const of = (n: number) => `${formatInt(n)} of ${formatInt(totals.assets)}`;

  return (
    <section className="surface relative overflow-hidden p-4">
      <div className="hero-grid pointer-events-none absolute inset-0 opacity-50" aria-hidden="true" />
      <div className="pointer-events-none absolute -right-20 -top-24 h-56 w-56 rounded-full bg-primary/10 blur-3xl" aria-hidden="true" />
      {/* Two columns from 1536px: the left stack is sized to sit level with two or three rows of area tiles. */}
      <div className="relative grid gap-5 2xl:grid-cols-[minmax(0,1fr)_minmax(0,1.35fr)]">
        <div className="flex min-w-0 flex-col gap-4">
          <div>
            <div className="text-[10px] font-medium uppercase tracking-[0.2em] text-primary">Model composition</div>
            <div className="mt-1 flex flex-wrap items-baseline gap-x-2">
              <span className="font-display text-4xl font-medium leading-none tabular-nums">{formatInt(totals.assets)}</span>
              <span className="text-sm text-muted-foreground">
                datasets in {areas.length} subject area{areas.length === 1 ? "" : "s"} across {platforms.size} platform{platforms.size === 1 ? "" : "s"} · {model.governed_metrics} governed metrics
              </span>
            </div>
            <CompositionBar segments={kindSegments(totals.counts)} legend={false} height="h-2.5" className="mt-3" />
          </div>

          <div className="flex flex-wrap items-center gap-x-6 gap-y-3 rounded-xl border border-border/60 bg-background/40 px-4 py-3">
            <Gauge value={ratio(totals.described)} label="Described" sub={of(totals.described)} hint="datasets with a catalog description" size={64} />
            <Gauge value={ratio(totals.named)} label="Named" sub={of(totals.named)} hint="business names declared, curated or accepted from Claude" size={64} />
            <Gauge value={ratio(totals.placed)} label="Placed" sub={of(totals.placed)} hint="datasets classified as fact, dimension, reference, bridge or metric view" size={64} />
            <div className="min-w-[12rem] flex-1 text-xs text-muted-foreground">
              Described and named come from the catalog and from Claude's accepted proposals; placed means the hub knows what role the dataset plays in the model.
            </div>
          </div>

          <KindBreakdown counts={totals.counts} total={totals.assets} />

          <div className="mt-auto flex flex-wrap items-center gap-3">
            <Button
              size="sm"
              onClick={onEnrich}
              disabled={!model.enrichment_available || enrichPending || running}
              title={model.enrichment_available ? "Ask Claude to name, describe and classify the undocumented datasets in this scope" : "Configure a Claude model to enable enrichment"}
            >
              <Sparkles className="h-3.5 w-3.5" /> {running ? "Naming with Claude…" : "Name with Claude"}
            </Button>
            {enrichRun ? <RunProgress run={enrichRun} /> : <span className="text-[11px] text-muted-foreground">Names, meanings and metrics for the undocumented datasets in this scope.</span>}
          </div>
        </div>

        <div className="min-w-0">
          <div className="flex items-center justify-between gap-2">
            <div className="text-[10px] font-medium uppercase tracking-[0.2em] text-muted-foreground">Subject areas · click to jump</div>
            <div className="text-[10px] text-muted-foreground">ring = described</div>
          </div>
          <div className="mt-2 grid gap-2" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(11.5rem, 1fr))" }}>
            {areas.map((area) => (
              <AreaTile key={areaId(area)} area={area} onJump={onJump} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
