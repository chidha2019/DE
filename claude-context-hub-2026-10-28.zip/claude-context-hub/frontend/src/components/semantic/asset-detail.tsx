import { ArrowLeft, ArrowLeftRight, ArrowRight, ExternalLink, GitFork, KeyRound, Network, Rows3, ShieldCheck, Sigma, Table2 } from "lucide-react";
import { useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";

import type { GraphNode, GraphPayload, SemanticAssetDetail, SemanticGraph } from "@/api/types";
import { ForceGraph } from "@/components/explorer/force-graph";
import { AssetTermChips } from "@/components/glossary/term-chips";
import { KindBadge, MetricSourceBadge, NameSourceBadge, PlatformBadge, RoleBadge, TypeBadge, relationshipLabel } from "@/components/semantic/badges";
import { EnrichmentPanel } from "@/components/semantic/enrichment-panel";
import { CompositionBar, KindTile, Pill, kindColor, roleSegments } from "@/components/semantic/visuals";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatCompact, formatDateTime, formatPercent } from "@/lib/format";
import { documentPath } from "@/lib/knowledge-paths";

interface AssetDetailProps {
  asset: SemanticAssetDetail | undefined;
  loading: boolean;
  graph: SemanticGraph | undefined;
  graphLoading: boolean;
  enrichmentAvailable?: boolean;
  /** Phones and tablets show the list or the dataset; this returns to the list. */
  onBack?: () => void;
}

// The force graph colours by entity type; the semantic kinds borrow the palette.
const KIND_TO_NODE_TYPE: Record<string, string> = {
  fact: "Project",
  dimension: "Technology",
  reference: "Technology",
  bridge: "Concept",
  metric: "Concept",
  unknown: "Document",
};

const JOIN_KINDS = new Set(["foreign_key", "join_declared", "join_inferred"]);

export function toGraphPayload(graph: SemanticGraph): GraphPayload {
  const nodes = graph.nodes.map((n) => ({
    id: n.id,
    label: n.name,
    type: KIND_TO_NODE_TYPE[n.kind] ?? "Document",
    properties: { fqn: n.fqn, kind: n.kind, asset_type: n.asset_type },
    degree: 0,
  }));
  const known = new Set(nodes.map((n) => n.id));
  const edges = graph.edges
    .filter((e) => e.target && known.has(e.source) && known.has(e.target))
    .map((e) => ({ source: e.source, target: e.target as string, type: "REFERENCES", properties: { kind: e.kind, weight: e.confidence } }));
  return { nodes, edges, center_id: graph.center_id, chunk_entities: null };
}

export function AssetDetail({ asset, loading, graph, graphLoading, enrichmentAvailable = false, onBack }: AssetDetailProps) {
  const navigate = useNavigate();
  const payload = useMemo(() => (graph ? toGraphPayload(graph) : undefined), [graph]);

  if (loading && !asset) {
    return (
      <div className="space-y-3 rounded-lg border bg-card p-4">
        <Skeleton className="h-6 w-2/3" />
        <Skeleton className="h-4 w-1/2" />
        <Skeleton className="h-40 w-full" />
      </div>
    );
  }
  if (!asset) {
    return (
      <div className="surface relative flex h-full flex-col items-center justify-center overflow-hidden p-8 text-center">
        <div className="hero-grid pointer-events-none absolute inset-0 opacity-60" aria-hidden="true" />
        <div className="relative flex items-end gap-3">
          <KindTile kind="dimension" className="h-11 w-11 -rotate-6 opacity-80" iconClass="h-5 w-5" />
          <KindTile kind="fact" className="h-14 w-14" iconClass="h-6 w-6" />
          <KindTile kind="metric" className="h-11 w-11 rotate-6 opacity-80" iconClass="h-5 w-5" />
        </div>
        <h3 className="relative mt-4 font-display text-lg font-medium">Pick a dataset</h3>
        <p className="relative mt-1 max-w-md text-sm text-muted-foreground">
          Its columns with inferred roles, keys and joins, lineage, governed metrics, the definition and a one-hop graph appear here. Facts are green, dimensions blue, metric views red.
        </p>
      </div>
    );
  }

  const keys = asset.fields.filter((f) => f.is_primary_key).map((f) => f.name);
  const joins = asset.relationships.filter((r) => JOIN_KINDS.has(r.kind));
  const lineage = asset.relationships.filter((r) => !JOIN_KINDS.has(r.kind));
  const declared = asset.metrics.filter((m) => m.source === "declared");
  const inferred = asset.metrics.filter((m) => m.source !== "declared");
  const roleCounts = asset.fields.reduce<Record<string, number>>((acc, f) => ({ ...acc, [f.role]: (acc[f.role] ?? 0) + 1 }), {});
  const accent = kindColor(asset.kind);

  const onNodeClick = (node: GraphNode) => {
    if (node.id !== asset.id) navigate(`/semantic/${node.id}`);
  };

  return (
    <div className="surface relative flex flex-1 flex-col gap-3 p-4 lg:min-h-0 lg:overflow-y-auto">
      {onBack ? (
        <Button variant="ghost" size="sm" className="-ml-2 -mt-1 w-fit text-xs lg:hidden" onClick={onBack}>
          <ArrowLeft className="h-3.5 w-3.5" /> All datasets
        </Button>
      ) : null}
      <span className="absolute inset-x-0 top-0 h-[3px]" style={{ background: `linear-gradient(90deg, hsl(${accent}), hsl(${accent} / 0.1))` }} aria-hidden="true" />
      <div>
        <div className="flex items-start gap-3">
          <KindTile kind={asset.kind} className="mt-0.5 h-12 w-12" iconClass="h-5 w-5" />
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="font-display text-xl font-medium tracking-tight">{asset.display_name || asset.name}</h2>
              <NameSourceBadge source={asset.name_source} />
              <TypeBadge assetType={asset.asset_type} />
              <KindBadge kind={asset.kind} />
              <PlatformBadge platform={asset.platform} />
            </div>
            <div className="font-mono text-[11px] text-muted-foreground" title={asset.fqn}>
              {asset.fqn}
            </div>
            <div className="mt-2 flex flex-wrap gap-1.5">
              <Pill icon={Table2} value={asset.fields.length} label="columns" />
              <Pill icon={Sigma} value={roleCounts.measure ?? 0} label="measure columns" tone="160 70% 45%" />
              <Pill icon={KeyRound} value={keys.length} label="primary keys" tone="38 92% 52%" />
              <Pill icon={ShieldCheck} value={asset.metrics.length} label="metrics" tone="347 77% 58%" />
              <Pill icon={GitFork} value={asset.relationships.length} label="keys, joins and lineage" tone="217 85% 60%" />
              {asset.row_count !== null ? <Pill icon={Rows3} value={formatCompact(asset.row_count)} label="rows" /> : null}
            </div>
          </div>
        </div>
        <p className="mt-2 text-sm text-muted-foreground">{asset.summary || asset.description || "No description in the catalog."}</p>
        {asset.summary && asset.description && asset.description !== asset.summary ? (
          <p className="mt-0.5 line-clamp-2 text-xs text-muted-foreground/80" title={asset.description}>
            {asset.description}
          </p>
        ) : null}
        <div className="mt-2">
          <EnrichmentPanel asset={asset} available={enrichmentAvailable} />
        </div>
        <div className="mt-2">
          <AssetTermChips assetId={asset.id} />
        </div>
        <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-muted-foreground">
          {asset.owner ? <span>owner {asset.owner}</span> : null}
          {asset.row_count !== null ? <span>{formatCompact(asset.row_count)} rows</span> : null}
          {asset.properties.format ? <span>{String(asset.properties.format)}</span> : null}
          {keys.length ? (
            <span className="flex items-center gap-1">
              <KeyRound className="h-3 w-3" /> {keys.join(", ")}
            </span>
          ) : null}
          {asset.source_updated_at ? <span>updated {formatDateTime(asset.source_updated_at)}</span> : null}
          <span className="flex-1" />
          <Button variant="outline" size="sm" asChild>
            <Link to={documentPath(asset.document_id)}>
              <Network className="h-3.5 w-3.5" /> Entities
            </Link>
          </Button>
          {asset.uri ? (
            <Button variant="outline" size="sm" asChild>
              <a href={asset.uri} target="_blank" rel="noreferrer">
                <ExternalLink className="h-3.5 w-3.5" /> Open in {asset.platform === "databricks" ? "Databricks" : "Snowflake"}
              </a>
            </Button>
          ) : null}
        </div>
        {asset.tags.length ? (
          <div className="mt-2 flex flex-wrap gap-1">
            {asset.tags.map((t) => (
              <Badge key={t} variant="outline" className="h-5 text-[10px]">
                {t}
              </Badge>
            ))}
          </div>
        ) : null}
      </div>

      <Tabs defaultValue="columns" className="flex flex-col gap-2">
        <div className="sticky top-0 z-10 -mx-4 border-b border-border/60 bg-card/95 px-4 py-2 backdrop-blur lg:-top-4">
        <TabsList className="scrollbar-hidden w-fit max-w-full justify-start overflow-x-auto">
          <TabsTrigger value="columns">Columns · {asset.fields.length}</TabsTrigger>
          <TabsTrigger value="relationships">Relationships · {asset.relationships.length}</TabsTrigger>
          <TabsTrigger value="metrics">Metrics · {asset.metrics.length}</TabsTrigger>
          <TabsTrigger value="graph">Graph</TabsTrigger>
          {asset.definition ? <TabsTrigger value="definition">Definition</TabsTrigger> : null}
        </TabsList>
        </div>

        <TabsContent value="columns" className="mt-0 overflow-hidden rounded-md border">
          <div className="border-b bg-background/40 px-3 py-2">
            <CompositionBar segments={roleSegments(roleCounts)} height="h-1.5" />
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-8">#</TableHead>
                <TableHead>Column</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Role</TableHead>
                <TableHead className="text-right">Conf.</TableHead>
                <TableHead>Description</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {asset.fields.map((f) => (
                <TableRow key={f.id}>
                  <TableCell className="font-mono text-[11px] text-muted-foreground">{f.ordinal}</TableCell>
                  <TableCell className="text-xs">
                    <span className="flex flex-wrap items-center gap-1.5">
                      <span className="font-medium">{f.display_name || f.name}</span>
                      <span className="font-mono text-[10px] text-muted-foreground">{f.name}</span>
                      {f.is_primary_key ? <KeyRound className="h-3 w-3 text-amber-500" aria-label="primary key" /> : null}
                      {f.is_partition ? <span className="text-[10px] text-muted-foreground">partition</span> : null}
                    </span>
                  </TableCell>
                  <TableCell className="font-mono text-[11px] text-muted-foreground">{f.data_type || "–"}</TableCell>
                  <TableCell>
                    <RoleBadge role={f.role} aggregation={f.aggregation} />
                  </TableCell>
                  <TableCell className="text-right font-mono text-[11px] text-muted-foreground">
                    {f.role_confidence >= 1 ? "declared" : formatPercent(f.role_confidence)}
                  </TableCell>
                  <TableCell className="max-w-[20rem] truncate text-xs text-muted-foreground" title={f.description}>
                    {f.description}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TabsContent>

        <TabsContent value="relationships" className="mt-0 space-y-4">
          <RelationshipGroup title="Keys and joins" items={joins} />
          <RelationshipGroup title="Lineage and definitions" items={lineage} />
          {asset.relationships.length === 0 ? <p className="text-sm text-muted-foreground">No keys, joins or lineage recorded for this asset.</p> : null}
        </TabsContent>

        <TabsContent value="metrics" className="mt-0 space-y-3">
          {asset.metrics.length === 0 ? (
            <p className="text-sm text-muted-foreground">No metrics: the asset has no measure columns and no declared metric definitions.</p>
          ) : null}
          {[...declared, ...inferred].map((m) => (
            <div key={m.id} className="rounded-md border p-3">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-sm font-medium">{m.display_name || m.name}</span>
                <span className="font-mono text-[10px] text-muted-foreground">{m.name}</span>
                <MetricSourceBadge source={m.source} />
                {m.aggregation ? <span className="text-[11px] text-muted-foreground">{m.aggregation}</span> : null}
              </div>
              <code className="mt-1 block overflow-x-auto rounded bg-muted/60 px-2 py-1 font-mono text-xs">{m.expression}</code>
              {m.description ? <p className="mt-1 text-xs text-muted-foreground">{m.description}</p> : null}
              {m.dimensions.length ? <p className="mt-1 text-[11px] text-muted-foreground">by {m.dimensions.join(", ")}</p> : null}
              {m.synonyms.length ? <p className="mt-1 text-[11px] text-muted-foreground">synonyms: {m.synonyms.join(", ")}</p> : null}
            </div>
          ))}
        </TabsContent>

        <TabsContent value="graph" className="relative mt-0 h-[26rem] overflow-hidden rounded-md border">
          <ForceGraph data={payload} loading={graphLoading} selectedId={asset.id} onNodeClick={onNodeClick} fill emptyMessage="No related assets within one hop." />
          <div className="pointer-events-none absolute bottom-2 left-2 rounded bg-background/80 px-2 py-1 text-[10px] text-muted-foreground">
            fact · dimension/reference · metric/bridge · other
          </div>
        </TabsContent>

        {asset.definition ? (
          <TabsContent value="definition" className="mt-0">
            <pre className="overflow-x-auto rounded-md border bg-muted/50 p-3 font-mono text-xs leading-relaxed">{asset.definition}</pre>
          </TabsContent>
        ) : null}
      </Tabs>
    </div>
  );
}

function RelationshipGroup({ title, items }: { title: string; items: SemanticAssetDetail["relationships"] }) {
  if (items.length === 0) return null;
  return (
    <div>
      <h3 className="mb-1.5 text-xs font-medium uppercase tracking-wide text-muted-foreground">{title}</h3>
      <ul className="space-y-1.5">
        {items.map((r) => (
          <li key={r.id} className="flex flex-wrap items-center gap-2 rounded-md border px-3 py-2 text-xs">
            {r.direction === "out" ? (
              <ArrowRight className="h-3.5 w-3.5 text-muted-foreground" />
            ) : (
              <ArrowLeftRight className="h-3.5 w-3.5 text-muted-foreground" />
            )}
            <Badge variant="outline" className="h-5 text-[10px]">
              {relationshipLabel(r.kind)}
              {r.direction === "in" ? " (incoming)" : ""}
            </Badge>
            {r.other_asset_id ? (
              <Link to={`/semantic/${r.other_asset_id}`} className="font-mono hover:underline">
                {r.other_fqn}
              </Link>
            ) : (
              <span className="font-mono text-muted-foreground" title="not ingested">
                {r.other_fqn}
              </span>
            )}
            {r.source_columns.length ? (
              <span className="text-muted-foreground">
                on {r.source_columns.join(", ")}
                {r.target_columns.length ? ` = ${r.target_columns.join(", ")}` : ""}
              </span>
            ) : null}
            {r.kind === "join_inferred" ? (
              <span className="text-muted-foreground">
                {formatPercent(r.confidence)} · {r.evidence}
              </span>
            ) : null}
            {r.other_kind ? <KindBadge kind={r.other_kind} /> : null}
          </li>
        ))}
      </ul>
    </div>
  );
}
