import { CircleAlert, CircleCheck, Clock3, Layers, Search } from "lucide-react";
import { useState } from "react";

import type { DocumentSummary, GraphSyncStatus, SourceSystem } from "@/api/types";
import { SOURCE_SYSTEMS } from "@/api/types";
import { BrandMark } from "@/components/connectors/brand-mark";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useDocuments } from "@/hooks/queries";
import { describeError } from "@/lib/api-client";
import { formatRelative } from "@/lib/format";
import { cn } from "@/lib/utils";

interface DocumentPickerProps {
  selectedId: string | null;
  onSelect: (doc: DocumentSummary) => void;
  height?: number;
}

/** "DB.SCHEMA.TABLE" reads as TABLE under DB.SCHEMA, "repo/docs/file.md" as file.md under repo/docs. */
function splitTitle(title: string): { name: string; path: string } {
  const sep = title.includes("/") ? "/" : !title.includes(" ") && title.split(".").length >= 3 ? "." : null;
  if (!sep) return { name: title, path: "" };
  const parts = title.split(sep).filter(Boolean);
  return { name: parts[parts.length - 1] ?? title, path: parts.slice(0, -1).join(sep) };
}

const SYNC: Record<GraphSyncStatus, { icon: typeof CircleCheck; label: string; className: string }> = {
  synced: { icon: CircleCheck, label: "in graph", className: "bg-success/10 text-success" },
  pending: { icon: Clock3, label: "pending", className: "bg-warning/10 text-warning" },
  failed: { icon: CircleAlert, label: "failed", className: "bg-destructive/10 text-destructive" },
};

function SyncChip({ status }: { status: GraphSyncStatus }) {
  const { icon: Icon, label, className } = SYNC[status] ?? SYNC.pending;
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full px-1.5 py-px text-[10px] font-medium", className)} title={`graph ${status}`}>
      <Icon className="h-3 w-3" /> {label}
    </span>
  );
}

export function DocumentPicker({ selectedId, onSelect, height = 420 }: DocumentPickerProps) {
  const [search, setSearch] = useState("");
  const [source, setSource] = useState<SourceSystem | "all">("all");
  const { data, isLoading, isError, error } = useDocuments({
    search: search || null,
    source_system: source === "all" ? null : [source],
    limit: 60,
  });

  return (
    <div className="flex flex-col gap-2">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input className="rounded-xl pl-8" placeholder="Search documents…" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <Select value={source} onValueChange={(v) => setSource(v as SourceSystem | "all")}>
          <SelectTrigger className="w-40 rounded-xl">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All sources</SelectItem>
            {SOURCE_SYSTEMS.map((s) => (
              <SelectItem key={s} value={s} className="capitalize">
                <span className="inline-flex items-center gap-2">
                  <BrandMark icon={s} size="xs" /> {s}
                </span>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      {/* Radix wraps content in a display:table div, which would let long titles push the chips out of view. */}
      <ScrollArea style={{ height }} className="rounded-2xl border bg-card/60 [&_[data-radix-scroll-area-viewport]>div]:!block">
        {isLoading ? (
          <div className="space-y-2 p-2">
            {[0, 1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-14 w-full rounded-xl" />
            ))}
          </div>
        ) : isError ? (
          <div className="p-4 text-sm text-destructive">{describeError(error)}</div>
        ) : !data || data.items.length === 0 ? (
          <div className="p-6 text-center text-sm text-muted-foreground">No documents match. Run an ingestion pipeline first.</div>
        ) : (
          <ul className="space-y-1 p-1.5">
            {data.items.map((doc) => {
              const { name, path } = splitTitle(doc.title);
              return (
                <li key={doc.id}>
                  <button
                    type="button"
                    onClick={() => onSelect(doc)}
                    title={doc.title}
                    className={cn(
                      "flex w-full items-center gap-3 rounded-xl px-2.5 py-2 text-left transition-colors",
                      selectedId === doc.id ? "bg-primary/10 ring-1 ring-primary/40" : "hover:bg-muted/70",
                    )}
                  >
                    <BrandMark icon={doc.source_system} size="sm" />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-medium">{name}</span>
                      <span className="block truncate font-mono text-[10.5px] text-muted-foreground">
                        {path || doc.source_system} · {formatRelative(doc.updated_at)}
                      </span>
                    </span>
                    <span className="flex shrink-0 flex-col items-end gap-1">
                      <span className="inline-flex items-center gap-1 text-[10.5px] tabular-nums text-muted-foreground" title="chunks">
                        <Layers className="h-3 w-3" /> {doc.chunk_count ?? 0}
                      </span>
                      <SyncChip status={doc.graph_sync_status} />
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </ScrollArea>
      {data ? (
        <div className="text-right text-[11px] text-muted-foreground">
          showing {data.items.length} of {data.total}
        </div>
      ) : null}
    </div>
  );
}
