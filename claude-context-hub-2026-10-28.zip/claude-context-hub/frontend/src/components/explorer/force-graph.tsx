/**
 * Canvas force-directed graph (react-force-graph-2d) shared by the Knowledge Hub, the Engineer workspace and the
 * Semantic Hub asset detail.
 *
 * - Nodes are glossy spheres in their type's colour with the type's icon inside; radius encodes degree.
 * - Selecting a node dims everything outside its 1-hop neighbourhood.
 * - `rich` adds curved links with flowing particles, roomier spacing and zoom controls.
 * - `dagMode` renders lineage as a left-to-right DAG.
 */

import { Maximize2, Minus, Plus } from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import ForceGraph2D, { type ForceGraphMethods, type LinkObject, type NodeObject } from "react-force-graph-2d";

import type { GraphNode, GraphPayload } from "@/api/types";
import { DIRECTED_EDGES, edgeColor, nodeColor } from "@/components/explorer/graph-colors";
import { drawNodeIcon, iconKind } from "@/components/explorer/graph-icons";
import { Skeleton } from "@/components/ui/skeleton";
import { useTheme } from "@/providers/theme-provider";

interface NodeData {
  id: string;
  label: string;
  type: string;
  degree: number;
  original: GraphNode;
}

interface LinkData {
  type: string;
  weight: number;
}

type GNode = NodeObject<NodeData>;
type GLink = LinkObject<NodeData, LinkData>;
type DagMode = "td" | "bu" | "lr" | "rl" | "radialout" | "radialin";

interface ForceGraphProps {
  data: GraphPayload | undefined;
  loading?: boolean;
  /** Fixed pixel height (ignored when `fill` is set). */
  height?: number;
  /** Fill the parent element (parent must have a definite size). */
  fill?: boolean;
  selectedId?: string | null;
  onNodeClick?: (node: GraphNode) => void;
  onBackgroundClick?: () => void;
  dagMode?: DagMode | null;
  emptyMessage?: string;
  /** Curved links with flowing particles, more room between nodes and zoom controls. */
  rich?: boolean;
}

function radiusFor(node: GNode): number {
  const base = Math.max(4, Math.min(15, 4 + Math.sqrt(node.degree) * 1.7));
  return node.type === "Document" ? base * 1.2 : base;
}

/** Mix a hex colour towards white (amount > 0) or black (amount < 0). */
function shade(hex: string, amount: number): string {
  const n = Number.parseInt(hex.replace("#", ""), 16);
  const target = amount > 0 ? 255 : 0;
  const t = Math.abs(amount);
  const mix = (c: number) => Math.round(c + (target - c) * t);
  return `rgb(${mix((n >> 16) & 255)},${mix((n >> 8) & 255)},${mix(n & 255)})`;
}

function withAlpha(hex: string, a: number): string {
  const n = Number.parseInt(hex.replace("#", ""), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}

/** A label that fits: the table name of a catalog FQN, the last two segments of a path. */
function shortLabel(label: string): string {
  if (label.includes("/")) return label.split("/").filter(Boolean).slice(-2).join("/");
  const dotted = label.split(".");
  if (dotted.length >= 3 && !label.includes(" ")) return dotted[dotted.length - 1] ?? label;
  return label;
}

/** Pushes overlapping nodes apart so a dense cluster (a schema's tables around one hub) stays readable. */
function collideForce(pad: number) {
  let nodes: GNode[] = [];
  const force = (alpha: number) => {
    for (let i = 0; i < nodes.length; i++) {
      const a = nodes[i] as GNode;
      for (let j = i + 1; j < nodes.length; j++) {
        const b = nodes[j] as GNode;
        const dx = (b.x ?? 0) - (a.x ?? 0);
        const dy = (b.y ?? 0) - (a.y ?? 0);
        const min = radiusFor(a) + radiusFor(b) + pad;
        const d2 = dx * dx + dy * dy;
        if (d2 >= min * min) continue;
        const d = Math.sqrt(d2) || 0.01;
        const push = ((min - d) / d) * alpha * 0.5;
        a.vx = (a.vx ?? 0) - dx * push;
        a.vy = (a.vy ?? 0) - dy * push;
        b.vx = (b.vx ?? 0) + dx * push;
        b.vy = (b.vy ?? 0) + dy * push;
      }
    }
  };
  force.initialize = (n: GNode[]) => {
    nodes = n;
  };
  return force;
}

function escapeHtml(text: string): string {
  return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function endId(end: GLink["source"]): string | undefined {
  if (end == null) return undefined;
  return typeof end === "object" ? String((end as GNode).id) : String(end);
}

function roundedRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number): void {
  const rr = Math.min(r, h / 2, w / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

export function ForceGraph({
  data,
  loading,
  height = 420,
  fill = false,
  selectedId = null,
  onNodeClick,
  onBackgroundClick,
  dagMode = null,
  emptyMessage = "No graph data.",
  rich = false,
}: ForceGraphProps) {
  const fgRef = useRef<ForceGraphMethods<GNode, GLink> | undefined>(undefined);
  const observerRef = useRef<ResizeObserver | null>(null);
  const [size, setSize] = useState({ width: 0, height: fill ? 0 : height });
  const [hoverId, setHoverId] = useState<string | null>(null);
  const dark = useTheme().resolved === "dark";

  // Measure the container so the canvas always matches the layout. A callback ref
  // (not an effect) because the container only mounts once data has loaded —
  // an effect keyed on mount would observe nothing and the canvas would never appear.
  const containerRef = useCallback(
    (el: HTMLDivElement | null) => {
      observerRef.current?.disconnect();
      observerRef.current = null;
      if (!el) return;
      const measure = (w: number, h: number) => setSize({ width: Math.floor(w), height: fill ? Math.floor(h) : height });
      const rect = el.getBoundingClientRect();
      measure(rect.width, rect.height);
      const observer = new ResizeObserver((entries) => {
        const r = entries[0]?.contentRect;
        if (r) measure(r.width, r.height);
      });
      observer.observe(el);
      observerRef.current = observer;
    },
    [fill, height],
  );

  // force-graph mutates node objects (x, y, vx, vy) so always hand it fresh copies.
  const graphData = useMemo(() => {
    if (!data) return { nodes: [] as GNode[], links: [] as GLink[] };
    const ids = new Set(data.nodes.map((n) => n.id));
    const nodes: GNode[] = data.nodes.map((n) => ({ id: n.id, label: n.label, type: n.type, degree: n.degree ?? 0, original: n }));
    const links: GLink[] = data.edges
      .filter((e) => ids.has(e.source) && ids.has(e.target))
      .map((e) => ({ source: e.source, target: e.target, type: e.type, weight: Number(e.properties.weight ?? 1) }));
    return { nodes, links };
  }, [data]);
  // In rich mode only the best-connected nodes are labelled until the user zooms in, hovers or selects.
  const hubIds = useMemo(
    () =>
      new Set(
        [...(data?.nodes ?? [])]
          .sort((a, b) => (b.degree ?? 0) - (a.degree ?? 0))
          .slice(0, 10)
          .map((n) => n.id),
      ),
    [data],
  );

  const focusId = selectedId ?? hoverId;
  const neighborIds = useMemo(() => {
    const set = new Set<string>();
    if (!selectedId || !data) return set;
    for (const e of data.edges) {
      if (e.source === selectedId) set.add(e.target);
      if (e.target === selectedId) set.add(e.source);
    }
    return set;
  }, [data, selectedId]);

  useEffect(() => {
    const timer = window.setTimeout(() => fgRef.current?.zoomToFit(500, 48), 400);
    return () => window.clearTimeout(timer);
  }, [graphData, size.width, size.height]);

  // Rich graphs get more room: stronger repulsion, longer links for references between documents.
  useEffect(() => {
    const fg = fgRef.current;
    if (!fg || !rich) return;
    const charge = fg.d3Force("charge") as unknown as { strength?: (v: number) => unknown } | undefined;
    charge?.strength?.(-170);
    const link = fg.d3Force("link") as unknown as { distance?: (fn: (l: GLink) => number) => unknown } | undefined;
    link?.distance?.((l) => (l.type === "MENTIONS" ? 58 : l.type === "REFERENCES" ? 80 : 66));
    fg.d3Force("collide", collideForce(16));
    fg.d3ReheatSimulation();
  }, [graphData, rich, size.width]);

  const paintNode = useCallback(
    (node: GNode, ctx: CanvasRenderingContext2D, globalScale: number) => {
      const x = node.x ?? 0;
      const y = node.y ?? 0;
      const isSelected = node.id === selectedId;
      const isNeighbor = neighborIds.has(node.id);
      const isHover = node.id === hoverId;
      const dim = selectedId !== null && !isSelected && !isNeighbor;
      const r = radiusFor(node);
      const color = nodeColor(node.type);
      const stub = Boolean(node.original.properties?.stub);

      ctx.globalAlpha = dim ? 0.18 : 1;
      if (isSelected || isHover) {
        ctx.beginPath();
        ctx.arc(x, y, r * 2, 0, 2 * Math.PI);
        ctx.fillStyle = withAlpha(color, isSelected ? 0.2 : 0.13);
        ctx.fill();
      }

      ctx.save();
      if (!dim) {
        ctx.shadowColor = withAlpha(color, 0.75);
        ctx.shadowBlur = isSelected ? 24 : isHover ? 18 : 10;
      }
      const sphere = ctx.createRadialGradient(x - r * 0.35, y - r * 0.4, r * 0.1, x, y, r);
      sphere.addColorStop(0, shade(color, 0.5));
      sphere.addColorStop(0.65, color);
      sphere.addColorStop(1, shade(color, -0.3));
      ctx.beginPath();
      ctx.arc(x, y, r, 0, 2 * Math.PI);
      ctx.fillStyle = stub ? withAlpha(color, 0.16) : sphere;
      ctx.fill();
      ctx.restore();

      ctx.beginPath();
      ctx.arc(x, y, r, 0, 2 * Math.PI);
      ctx.lineWidth = (stub ? 1.3 : 0.9) / globalScale;
      ctx.strokeStyle = stub ? color : "rgba(255,255,255,0.55)";
      if (stub) ctx.setLineDash([3 / globalScale, 2 / globalScale]);
      ctx.stroke();
      ctx.setLineDash([]);
      if (isSelected) {
        ctx.beginPath();
        ctx.arc(x, y, r + 3.5 / globalScale, 0, 2 * Math.PI);
        ctx.lineWidth = 2.2 / globalScale;
        ctx.strokeStyle = color;
        ctx.stroke();
      }
      if (r * globalScale >= 7)
        drawNodeIcon(ctx, iconKind(node.type, node.original.properties?.source_system), x, y, r * 1.12, stub ? color : "rgba(255,255,255,0.96)");

      const showLabel =
        isSelected ||
        isHover ||
        // A hub's dozens of neighbours would bury each other's labels; name them only when few or zoomed in.
        (isNeighbor && (!rich || neighborIds.size <= 12 || globalScale > 1.6)) ||
        (rich ? globalScale > 1.8 || hubIds.has(node.id) : globalScale > 1.4 || node.degree >= 5 || node.type === "Document");
      if (showLabel && !dim) {
        const fontSize = Math.max(11 / globalScale, 2.6);
        ctx.font = `${isSelected || isHover ? 600 : 500} ${fontSize}px Inter, system-ui, sans-serif`;
        const short = shortLabel(node.label);
        const text = short.length > 30 ? `${short.slice(0, 29)}…` : short;
        const w = ctx.measureText(text).width;
        const padX = 5 / globalScale;
        const padY = 2.2 / globalScale;
        const h = fontSize + padY * 2;
        const top = y + r + 3.5 / globalScale;
        roundedRect(ctx, x - w / 2 - padX, top, w + padX * 2, h, h / 2);
        ctx.fillStyle = dark ? "rgba(15,23,42,0.86)" : "rgba(255,255,255,0.94)";
        ctx.fill();
        ctx.lineWidth = 0.8 / globalScale;
        ctx.strokeStyle = isSelected ? color : dark ? "rgba(148,163,184,0.28)" : "rgba(15,23,42,0.12)";
        ctx.stroke();
        ctx.fillStyle = dark ? "#e2e8f0" : "#0f172a";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(text, x, top + h / 2 + 0.2 / globalScale);
      }
      ctx.globalAlpha = 1;
    },
    [selectedId, neighborIds, hoverId, dark, rich, hubIds],
  );

  const paintPointerArea = useCallback((node: GNode, color: string, ctx: CanvasRenderingContext2D) => {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(node.x ?? 0, node.y ?? 0, radiusFor(node) + 3, 0, 2 * Math.PI);
    ctx.fill();
  }, []);

  const touches = useCallback(
    (l: GLink) => {
      if (!focusId) return false;
      return endId(l.source) === focusId || endId(l.target) === focusId;
    },
    [focusId],
  );

  const tooltip = useCallback(
    (n: GNode) => {
      const color = nodeColor(n.type);
      const bg = dark ? "rgba(15,23,42,0.95)" : "rgba(255,255,255,0.97)";
      const fg = dark ? "#e2e8f0" : "#0f172a";
      const muted = dark ? "#94a3b8" : "#64748b";
      const source = n.original.properties?.source_system ? ` · ${escapeHtml(String(n.original.properties.source_system))}` : "";
      return (
        `<div style="background:${bg};color:${fg};border:1px solid ${withAlpha(color, 0.45)};border-radius:12px;padding:8px 10px;` +
        `font:12px Inter,system-ui,sans-serif;box-shadow:0 12px 32px -12px rgba(0,0,0,0.45);max-width:320px">` +
        `<div style="display:flex;align-items:center;gap:6px;font-size:10px;text-transform:uppercase;letter-spacing:.14em;color:${color}">` +
        `<span style="width:8px;height:8px;border-radius:999px;background:${color}"></span>${escapeHtml(n.type)}${source}</div>` +
        `<div style="margin-top:4px;font-weight:600;word-break:break-all">${escapeHtml(n.label)}</div>` +
        `<div style="margin-top:2px;color:${muted}">${n.degree} connection${n.degree === 1 ? "" : "s"}</div></div>`
      );
    },
    [dark],
  );

  // In `fill` mode the wrapper is absolutely positioned against the (relative) parent:
  // percentage heights do not resolve inside auto-sized grid/flex rows, but `inset-0` does.
  if (loading) return <Skeleton className={fill ? "absolute inset-0" : "w-full"} style={fill ? undefined : { height }} />;
  if (!data || data.nodes.length === 0) {
    return (
      <div
        className={fill ? "absolute inset-0 flex items-center justify-center" : "flex w-full items-center justify-center"}
        style={fill ? undefined : { height }}
      >
        <span className="text-sm text-muted-foreground">{emptyMessage}</span>
      </div>
    );
  }

  const zoomBy = (factor: number) => {
    const fg = fgRef.current;
    if (fg) fg.zoom(fg.zoom() * factor, 300);
  };

  return (
    <div ref={containerRef} className={fill ? "absolute inset-0" : "relative w-full"} style={fill ? undefined : { height }}>
      {size.width > 0 && size.height > 0 ? (
        <ForceGraph2D<NodeData, LinkData>
          ref={fgRef}
          width={size.width}
          height={size.height}
          graphData={graphData}
          backgroundColor="rgba(0,0,0,0)"
          nodeId="id"
          nodeLabel={tooltip}
          nodeCanvasObject={paintNode}
          nodeCanvasObjectMode={() => "replace"}
          nodePointerAreaPaint={paintPointerArea}
          linkColor={(l) => (selectedId && !touches(l) ? (dark ? "rgba(148,163,184,0.07)" : "rgba(100,116,139,0.08)") : edgeColor(l.type))}
          linkWidth={(l) => Math.min(4, 0.6 + Math.log1p(l.weight)) * (touches(l) ? 1.8 : 1)}
          linkCurvature={(l) => (rich ? (l.type === "REFERENCES" ? 0.24 : l.type === "DEPENDS_ON" ? 0.16 : 0.05) : 0)}
          linkDirectionalArrowLength={(l) => (DIRECTED_EDGES.has(l.type) ? 4 : 0)}
          linkDirectionalArrowRelPos={1}
          linkDirectionalParticles={(l) => (rich ? (DIRECTED_EDGES.has(l.type) ? 2 : l.type === "MENTIONS" ? 1 : 0) : 0)}
          linkDirectionalParticleWidth={(l) => (touches(l) ? 3 : 2)}
          linkDirectionalParticleSpeed={0.0045}
          linkDirectionalParticleColor={(l) => (typeof l.source === "object" ? nodeColor((l.source as GNode).type) : "#94a3b8")}
          linkLabel={(l) => `${l.type}${l.weight !== 1 ? ` (${l.weight.toFixed(1)})` : ""}`}
          onNodeClick={(n) => onNodeClick?.(n.original)}
          onNodeHover={(n) => setHoverId(n?.id ? String(n.id) : null)}
          onBackgroundClick={() => onBackgroundClick?.()}
          onEngineStop={() => fgRef.current?.zoomToFit(400, 40)}
          minZoom={0.3}
          maxZoom={4}
          cooldownTicks={rich ? 220 : 140}
          d3VelocityDecay={0.3}
          enableNodeDrag
          {...(dagMode ? { dagMode, dagLevelDistance: 90 } : {})}
        />
      ) : null}
      {rich ? (
        <div className="absolute bottom-3 right-3 flex flex-col overflow-hidden rounded-xl border border-border/70 bg-card/85 shadow-sm backdrop-blur">
          {[
            { label: "Zoom in", icon: Plus, run: () => zoomBy(1.35) },
            { label: "Zoom out", icon: Minus, run: () => zoomBy(1 / 1.35) },
            { label: "Fit to view", icon: Maximize2, run: () => fgRef.current?.zoomToFit(400, 48) },
          ].map((b) => (
            <button
              key={b.label}
              type="button"
              onClick={b.run}
              title={b.label}
              aria-label={b.label}
              className="flex h-8 w-8 items-center justify-center text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            >
              <b.icon className="h-4 w-4" />
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
}
