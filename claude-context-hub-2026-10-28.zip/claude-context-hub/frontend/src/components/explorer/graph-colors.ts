/** Shared node/edge palette for every graph visual (explorer, lineage, playground). */

export const NODE_COLORS: Record<string, string> = {
  Document: "#3b82f6",
  Chunk: "#64748b",
  Person: "#f59e0b",
  Project: "#8b5cf6",
  Technology: "#10b981",
  Concept: "#f43f5e",
  // Repo graph kinds (tables are coloured by their layer)
  repository: "#94a3b8",
  file: "#64748b",
  symbol: "#a78bfa",
  pipeline: "#f97316",
  source_system: "#0ea5e9",
  source: "#38bdf8",
  column: "#94a3b8",
  check: "#22c55e",
  storage_integration: "#eab308",
  external_volume: "#14b8a6",
  stage: "#06b6d4",
  file_format: "#a3a3a3",
  s3_location: "#f59e0b",
  ci_stage: "#8b5cf6",
  alert: "#ef4444",
  bronze: "#c2773b",
  silver: "#cbd5e1",
  gold: "#eab308",
  serving: "#22c55e",
  control: "#64748b",
  staging: "#60a5fa",
  raw: "#a16207",
  mart: "#10b981",
  default: "#94a3b8",
};

export const EDGE_COLORS: Record<string, string> = {
  HAS_CHUNK: "rgba(100,116,139,0.45)",
  MENTIONS: "rgba(139,92,246,0.45)",
  REFERENCES: "rgba(59,130,246,0.6)",
  DEPENDS_ON: "rgba(16,185,129,0.65)",
  CONTRIBUTED_BY: "rgba(245,158,11,0.6)",
  DERIVED_FROM: "rgba(234,179,8,0.6)",
  LOADED_FROM: "rgba(56,189,248,0.6)",
  LANDS_IN: "rgba(6,182,212,0.55)",
  STORED_ON: "rgba(20,184,166,0.45)",
  CHECKS: "rgba(34,197,94,0.4)",
  IMPORTS: "rgba(167,139,250,0.5)",
  DEFINED_IN: "rgba(100,116,139,0.35)",
  default: "rgba(148,163,184,0.4)",
};

export const DIRECTED_EDGES = new Set(["REFERENCES", "DEPENDS_ON", "HAS_CHUNK", "DERIVED_FROM", "LOADED_FROM", "LANDS_IN", "IMPORTS", "READS", "USES", "STORED_ON", "NEXT"]);

export function nodeColor(type: string): string {
  return NODE_COLORS[type] ?? NODE_COLORS.default ?? "#94a3b8";
}

export function edgeColor(type: string): string {
  return EDGE_COLORS[type] ?? EDGE_COLORS.default ?? "rgba(148,163,184,0.4)";
}

/** Tailwind classes for entity chips, keyed by entity type. */
export const ENTITY_CHIP_CLASS: Record<string, string> = {
  Document: "border-blue-500/40 bg-blue-500/10 text-blue-500",
  Person: "border-amber-500/40 bg-amber-500/10 text-amber-500",
  Project: "border-violet-500/40 bg-violet-500/10 text-violet-400",
  Technology: "border-emerald-500/40 bg-emerald-500/10 text-emerald-500",
  Concept: "border-rose-500/40 bg-rose-500/10 text-rose-400",
};
