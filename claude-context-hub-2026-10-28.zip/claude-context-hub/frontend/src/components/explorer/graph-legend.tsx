import { Cpu, FileText, FolderKanban, Layers, Lightbulb, Shapes, UserRound, type LucideIcon } from "lucide-react";

import { NODE_COLORS } from "@/components/explorer/graph-colors";
import { cn } from "@/lib/utils";

/** The icon each node type carries in the graph, the legend and the entity chips. */
// eslint-disable-next-line react-refresh/only-export-components
export const TYPE_ICON: Record<string, LucideIcon> = {
  Document: FileText,
  Chunk: Layers,
  Person: UserRound,
  Project: FolderKanban,
  Technology: Cpu,
  Concept: Lightbulb,
};

interface GraphLegendProps {
  types?: string[];
  counts?: Record<string, number>;
  className?: string;
}

const DEFAULT_TYPES = ["Document", "Person", "Project", "Technology", "Concept"];

/** One chip per node type: its colour, its icon and, when counts are given, how many are on screen (empty types are left out). */
export function GraphLegend({ types = DEFAULT_TYPES, counts, className }: GraphLegendProps) {
  const shown = counts ? types.filter((t) => (counts[t] ?? 0) > 0) : types;
  return (
    <div className={cn("flex flex-wrap items-center gap-1.5", className)}>
      {shown.map((t) => {
        const color = NODE_COLORS[t] ?? NODE_COLORS.default ?? "#94a3b8";
        const Icon = TYPE_ICON[t] ?? Shapes;
        return (
          <span
            key={t}
            className="inline-flex items-center gap-1.5 rounded-full border bg-card/80 py-0.5 pl-0.5 pr-2 text-[11px] font-medium"
            style={{ borderColor: `${color}55` }}
          >
            <span
              className="flex h-5 w-5 items-center justify-center rounded-full text-white"
              style={{ background: `linear-gradient(140deg, ${color}bb, ${color})` }}
            >
              <Icon className="h-3 w-3" />
            </span>
            {t}
            {counts && counts[t] !== undefined ? <span className="tabular-nums text-muted-foreground">{counts[t]}</span> : null}
          </span>
        );
      })}
    </div>
  );
}
