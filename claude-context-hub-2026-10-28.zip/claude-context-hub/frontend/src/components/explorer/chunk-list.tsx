import { ChevronDown, ChevronRight, Shapes, X } from "lucide-react";
import { useState } from "react";

import type { ChunkOut } from "@/api/types";
import { NODE_COLORS } from "@/components/explorer/graph-colors";
import { TYPE_ICON } from "@/components/explorer/graph-legend";
import { Markdown } from "@/components/genie/markdown";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

interface ChunkListProps {
  chunks: ChunkOut[] | undefined;
  loading?: boolean;
  selectedEntityKey: string | null;
  onSelectEntity: (key: string | null) => void;
  /** chunk ids to emphasise (e.g. retrieval hits) */
  highlightChunkIds?: Set<string>;
}

function ChunkCard({
  chunk,
  maxTokens,
  dimmed,
  highlighted,
  selectedEntityKey,
  onSelectEntity,
}: {
  chunk: ChunkOut;
  maxTokens: number;
  dimmed: boolean;
  highlighted: boolean;
  selectedEntityKey: string | null;
  onSelectEntity: (key: string | null) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const entities = chunk.metadata.entities ?? [];
  const long = chunk.content.length > 400;
  return (
    <article
      className={cn(
        "overflow-hidden rounded-2xl border bg-card shadow-sm transition-all",
        dimmed && "opacity-40",
        highlighted && "border-primary/60 ring-1 ring-primary/30",
      )}
    >
      <header className="flex items-center gap-2 border-b bg-muted/40 px-3 py-2 text-xs text-muted-foreground">
        <span className="flex h-6 min-w-6 items-center justify-center rounded-lg bg-gradient-to-br from-primary/80 to-primary px-1.5 font-mono text-[11px] font-semibold text-primary-foreground">
          {chunk.chunk_index}
        </span>
        {chunk.section_path.length > 0 ? (
          <span className="flex min-w-0 items-center gap-1 truncate">
            {chunk.section_path.map((s, i) => (
              <span key={`${s}-${i}`} className="flex min-w-0 items-center gap-1">
                {i > 0 ? <ChevronRight className="h-3 w-3 shrink-0" /> : null}
                <span className="truncate">{s}</span>
              </span>
            ))}
          </span>
        ) : null}
        <span className="ml-auto flex shrink-0 items-center gap-1.5" title={`${chunk.token_count} tokens`}>
          <span className="h-1.5 w-12 overflow-hidden rounded-full bg-border">
            <span className="block h-full rounded-full bg-primary/70" style={{ width: `${Math.max(6, (chunk.token_count / maxTokens) * 100)}%` }} />
          </span>
          <span className="tabular-nums">{chunk.token_count} tok</span>
        </span>
      </header>
      <div className="relative px-3 py-2.5">
        <div className={cn("text-sm leading-relaxed", !expanded && long && "max-h-36 overflow-hidden")}>
          <Markdown content={chunk.content} />
        </div>
        {!expanded && long ? <div className="pointer-events-none absolute inset-x-0 bottom-0 h-12 bg-gradient-to-t from-card to-transparent" /> : null}
      </div>
      {long ? (
        <button
          type="button"
          className="flex items-center gap-1 px-3 pb-2 text-xs font-medium text-primary hover:underline"
          onClick={() => setExpanded((v) => !v)}
        >
          <ChevronDown className={cn("h-3.5 w-3.5 transition-transform", expanded && "rotate-180")} />
          {expanded ? "Show less" : "Show more"}
        </button>
      ) : null}
      {entities.length > 0 ? (
        <div className="flex flex-wrap gap-1.5 border-t px-3 py-2">
          {entities.map((e) => {
            const active = selectedEntityKey === e.key;
            const color = NODE_COLORS[e.entity_type] ?? NODE_COLORS.default;
            const Icon = TYPE_ICON[e.entity_type] ?? Shapes;
            return (
              <button
                key={e.key}
                type="button"
                onClick={() => onSelectEntity(active ? null : e.key)}
                className="inline-flex items-center gap-1 rounded-full border py-0.5 pl-0.5 pr-2 text-[11px] font-medium leading-4 transition-all hover:-translate-y-px"
                style={{ borderColor: `${color}66`, background: `${color}14`, boxShadow: active ? `0 0 0 2px ${color}` : undefined }}
                title={`${e.entity_type} · confidence ${e.confidence.toFixed(2)}`}
              >
                <span className="flex h-4 w-4 items-center justify-center rounded-full text-white" style={{ background: color }}>
                  <Icon className="h-2.5 w-2.5" />
                </span>
                {e.name}
              </button>
            );
          })}
        </div>
      ) : null}
    </article>
  );
}

export function ChunkList({ chunks, loading, selectedEntityKey, onSelectEntity, highlightChunkIds }: ChunkListProps) {
  if (loading || !chunks) {
    return (
      <div className="space-y-3">
        {[0, 1, 2].map((i) => (
          <Skeleton key={i} className="h-32 w-full rounded-2xl" />
        ))}
      </div>
    );
  }
  if (chunks.length === 0)
    return <div className="rounded-2xl border border-dashed p-6 text-center text-sm text-muted-foreground">This document has no chunks yet.</div>;

  const mentions = (c: ChunkOut) => (c.metadata.entities ?? []).some((e) => e.key === selectedEntityKey);
  const matching = selectedEntityKey ? chunks.filter(mentions).length : chunks.length;
  const maxTokens = Math.max(1, ...chunks.map((c) => c.token_count));

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span>
          {matching} of {chunks.length} chunks{selectedEntityKey ? " mention the selected entity" : ""}
        </span>
        {selectedEntityKey ? (
          <button type="button" className="inline-flex items-center gap-1 rounded-full border px-2 py-0.5 hover:bg-muted" onClick={() => onSelectEntity(null)}>
            <X className="h-3 w-3" /> clear filter
          </button>
        ) : null}
      </div>
      {chunks.map((chunk) => (
        <ChunkCard
          key={chunk.id}
          chunk={chunk}
          maxTokens={maxTokens}
          dimmed={selectedEntityKey !== null && !mentions(chunk)}
          highlighted={highlightChunkIds?.has(chunk.id) ?? false}
          selectedEntityKey={selectedEntityKey}
          onSelectEntity={onSelectEntity}
        />
      ))}
    </div>
  );
}
