/**
 * Icons drawn inside graph nodes on the canvas: lucide path data (24-unit viewBox) turned into cached Path2D
 * objects, so every node type reads at a glance without an icon font.
 */

const PATHS: Record<string, string[]> = {
  // file-text
  Document: ["M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z", "M14 2v4a2 2 0 0 0 2 2h4", "M10 9H8", "M16 13H8", "M16 17H8"],
  // table-2: a catalog dataset rather than a text document
  Dataset: ["M9 3H5a2 2 0 0 0-2 2v4m6-6h10a2 2 0 0 1 2 2v4M9 3v18m0 0h10a2 2 0 0 0 2-2V9M9 21H5a2 2 0 0 1-2-2V9m0 0h18"],
  // layers
  Chunk: [
    "M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z",
    "M22 17.65 12.83 21.81a2 2 0 0 1-1.66 0L2 17.65",
    "M22 12.65 12.83 16.81a2 2 0 0 1-1.66 0L2 12.65",
  ],
  // user
  Person: ["M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2", "M16 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0z"],
  // folder
  Project: ["M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"],
  // cpu
  Technology: [
    "M6 4h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z",
    "M9 9h6v6H9z",
    "M15 2v2",
    "M15 20v2",
    "M2 15h2",
    "M2 9h2",
    "M20 15h2",
    "M20 9h2",
    "M9 2v2",
    "M9 20v2",
  ],
  // lightbulb
  Concept: ["M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5", "M9 18h6", "M10 22h4"],
};

const cache = new Map<string, Path2D[]>();

function pathsFor(kind: string): Path2D[] | null {
  const d = PATHS[kind];
  if (!d) return null;
  let paths = cache.get(kind);
  if (!paths) {
    paths = d.map((p) => new Path2D(p));
    cache.set(kind, paths);
  }
  return paths;
}

/** The icon kind for a node: catalog documents (Snowflake, Databricks) draw as tables. */
export function iconKind(type: string, sourceSystem?: unknown): string {
  if (type === "Document" && (sourceSystem === "snowflake" || sourceSystem === "databricks")) return "Dataset";
  return type;
}

/** Stroke the icon centred on (x, y) at `size` canvas units; nothing is drawn for a type without an icon. */
export function drawNodeIcon(ctx: CanvasRenderingContext2D, kind: string, x: number, y: number, size: number, color: string): void {
  const paths = pathsFor(kind);
  if (!paths) return;
  ctx.save();
  ctx.translate(x - size / 2, y - size / 2);
  ctx.scale(size / 24, size / 24);
  ctx.lineWidth = 2.2;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.strokeStyle = color;
  for (const p of paths) ctx.stroke(p);
  ctx.restore();
}
