import { Bell, Braces, Calendar, Columns3, Database, FileText, Folder, GitBranch, Hash, LayoutDashboard, Table2, ToggleLeft, Type, type LucideIcon } from "lucide-react";

import { cn } from "@/lib/utils";

export interface KindStyle {
  icon: LucideIcon;
  color: string;
  label: string;
}

/** One glyph and hue per kind of node in a source hierarchy. */
const KIND_STYLE: Record<string, KindStyle> = {
  database: { icon: Database, color: "217 85% 58%", label: "Database" },
  catalog: { icon: Database, color: "217 85% 58%", label: "Catalog" },
  schema: { icon: Folder, color: "262 70% 60%", label: "Schema" },
  table: { icon: Table2, color: "160 70% 40%", label: "Table" },
  column: { icon: Columns3, color: "200 12% 52%", label: "Column" },
  repo: { icon: GitBranch, color: "262 70% 60%", label: "Repository" },
  folder: { icon: Folder, color: "199 89% 46%", label: "Folder" },
  file: { icon: FileText, color: "200 12% 52%", label: "File" },
  dashboard: { icon: LayoutDashboard, color: "28 90% 52%", label: "Dashboard" },
  alerts: { icon: Bell, color: "347 77% 56%", label: "Alert rules" },
};

export const kindStyle = (kind: string): KindStyle => KIND_STYLE[kind] ?? { icon: Folder, color: "200 12% 52%", label: kind };

/** The style of a hierarchy level by its name (Database, Schema, Table, Repository, Folder ...). */
export const levelStyle = (level: string): KindStyle => {
  const key = level.toLowerCase() === "repository" ? "repo" : level.toLowerCase();
  return { ...kindStyle(key), label: level };
};

const SIZES = { xs: "h-5 w-5 rounded-md", sm: "h-6 w-6 rounded-md", md: "h-8 w-8 rounded-lg", lg: "h-10 w-10 rounded-xl" } as const;
const ICONS = { xs: "h-3 w-3", sm: "h-3.5 w-3.5", md: "h-4 w-4", lg: "h-5 w-5" } as const;

/** A gradient tile with the glyph of a kind of node. */
export function KindTile({ kind, style, size = "sm", className }: { kind?: string; style?: KindStyle; size?: keyof typeof SIZES; className?: string }) {
  const s = style ?? kindStyle(kind ?? "");
  return (
    <span
      className={cn("flex shrink-0 items-center justify-center border text-white shadow-sm", SIZES[size], className)}
      style={{ background: `linear-gradient(135deg, hsl(${s.color}), hsl(${s.color} / 0.68))`, borderColor: `hsl(${s.color} / 0.45)` }}
      aria-hidden="true"
    >
      <s.icon className={ICONS[size]} />
    </span>
  );
}

/** The family of a column data type, for its glyph and hue in the schema preview. */
export function typeFamily(dataType: string): KindStyle {
  const t = dataType.toLowerCase();
  if (/(char|text|string|varchar|uuid|binary)/.test(t)) return { icon: Type, color: "199 89% 46%", label: "text" };
  if (/(int|number|decimal|numeric|float|double|real|long|short|byte)/.test(t)) return { icon: Hash, color: "160 70% 40%", label: "number" };
  if (/bool/.test(t)) return { icon: ToggleLeft, color: "28 90% 50%", label: "boolean" };
  if (/(date|time|interval)/.test(t)) return { icon: Calendar, color: "262 70% 60%", label: "date" };
  if (/(variant|object|array|struct|map|json|geography|geometry)/.test(t)) return { icon: Braces, color: "330 70% 55%", label: "nested" };
  return { icon: Columns3, color: "200 12% 52%", label: "other" };
}

/** A soft pill in the hue of a kind or level. */
export function TonePill({ color, children, className }: { color: string; children: React.ReactNode; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-1 whitespace-nowrap rounded-full border px-2 py-0.5 text-[10px] font-medium", className)} style={{ background: `hsl(${color} / 0.1)`, borderColor: `hsl(${color} / 0.28)`, color: `hsl(${color})` }}>
      {children}
    </span>
  );
}
