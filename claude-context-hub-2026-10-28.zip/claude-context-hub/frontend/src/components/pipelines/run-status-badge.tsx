import { AlertTriangle, CheckCircle2, Clock, Loader2, PauseCircle, XCircle } from "lucide-react";

import type { RunStatus } from "@/api/types";
import { Badge, type BadgeProps } from "@/components/ui/badge";

const META: Record<RunStatus, { variant: NonNullable<BadgeProps["variant"]>; icon: typeof Clock; spin?: boolean }> = {
  queued: { variant: "muted", icon: Clock },
  running: { variant: "info", icon: Loader2, spin: true },
  paused: { variant: "warning", icon: PauseCircle },
  completed: { variant: "success", icon: CheckCircle2 },
  failed: { variant: "destructive", icon: AlertTriangle },
  cancelled: { variant: "secondary", icon: XCircle },
};

export function RunStatusBadge({ status }: { status: RunStatus }) {
  const meta = META[status];
  const Icon = meta.icon;
  return (
    <Badge variant={meta.variant} className="capitalize">
      <Icon className={meta.spin ? "h-3 w-3 animate-spin" : "h-3 w-3"} />
      {status}
    </Badge>
  );
}
