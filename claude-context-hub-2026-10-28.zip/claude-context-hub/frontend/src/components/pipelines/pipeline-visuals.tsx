import { Activity, Cable, CalendarClock, CirclePause, Hand, Layers, Loader2, Snowflake, TicketCheck, TriangleAlert, type LucideIcon } from "lucide-react";

import { GithubIcon } from "@/components/icons/brand-icons";
import type { PipelineOut, ScopeItem, SourceSystem } from "@/api/types";
import { Badge } from "@/components/ui/badge";
import { pathLabel, pipelineState, type PipelineState } from "@/lib/pipelines";
import { cn } from "@/lib/utils";

interface ConnectionStyle {
  icon: LucideIcon;
  color: string;
}

/** One glyph and hue per kind of connection; unknown ones fall back to a plug. */
const BY_SYSTEM: Partial<Record<SourceSystem, ConnectionStyle>> = {
  databricks: { icon: Layers, color: "14 88% 56%" },
  snowflake: { icon: Snowflake, color: "199 90% 55%" },
  github: { icon: GithubIcon, color: "262 70% 62%" },
  grafana: { icon: Activity, color: "28 90% 55%" },
  jira: { icon: TicketCheck, color: "216 100% 45%" },
};
const FALLBACK: ConnectionStyle = { icon: Cable, color: "172 66% 45%" };

export const connectionStyle = (system?: SourceSystem | null): ConnectionStyle => (system ? BY_SYSTEM[system] : undefined) ?? FALLBACK;

export function ConnectionTile({ system, className, iconClass = "h-4 w-4" }: { system?: SourceSystem | null; className?: string; iconClass?: string }) {
  const { icon: Icon, color } = connectionStyle(system);
  return (
    <span
      className={cn("flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border text-white", className)}
      style={{ background: `linear-gradient(135deg, hsl(${color}), hsl(${color} / 0.62))`, borderColor: `hsl(${color} / 0.5)` }}
    >
      <Icon className={iconClass} />
    </span>
  );
}

const STATE: Record<PipelineState, { label: string; variant: "info" | "destructive" | "success" | "warning" | "muted"; icon: LucideIcon; spin?: boolean }> = {
  running: { label: "Running", variant: "info", icon: Loader2, spin: true },
  failed: { label: "Last run failed", variant: "destructive", icon: TriangleAlert },
  scheduled: { label: "Scheduled", variant: "success", icon: CalendarClock },
  paused: { label: "Schedule paused", variant: "warning", icon: CirclePause },
  idle: { label: "Manual", variant: "muted", icon: Hand },
};

export function StatePill({ pipeline }: { pipeline: PipelineOut }) {
  const meta = STATE[pipelineState(pipeline)];
  const Icon = meta.icon;
  return (
    <Badge variant={meta.variant} className="shrink-0 whitespace-nowrap">
      <Icon className={cn("h-3 w-3", meta.spin && "animate-spin")} />
      {meta.label}
    </Badge>
  );
}

/** The selected paths as chips, with a +N chip for the rest. */
export function ScopeChips({ scope, max = 3, className }: { scope: ScopeItem[]; max?: number; className?: string }) {
  if (scope.length === 0) {
    return <span className={cn("rounded-md bg-muted px-2 py-0.5 text-[11px] text-muted-foreground", className)}>Whole connection</span>;
  }
  const shown = scope.slice(0, max);
  return (
    <span className={cn("flex flex-wrap items-center gap-1", className)}>
      {shown.map((item) => (
        <span
          key={item.path.join("/")}
          className="max-w-[16rem] truncate rounded-md border border-border/70 bg-card/70 px-2 py-0.5 font-mono text-[11px]"
          title={pathLabel(item.path)}
        >
          {pathLabel(item.path, " › ")}
        </span>
      ))}
      {scope.length > max ? <span className="rounded-md bg-muted px-2 py-0.5 text-[11px] text-muted-foreground">+{scope.length - max} more</span> : null}
    </span>
  );
}
