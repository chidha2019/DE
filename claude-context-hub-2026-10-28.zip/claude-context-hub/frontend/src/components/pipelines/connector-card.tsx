import { Play } from "lucide-react";

import type { ConnectorInfo } from "@/api/types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { formatInt } from "@/lib/format";
import { cn } from "@/lib/utils";

interface ConnectorCardProps {
  connector: ConnectorInfo;
  busy?: boolean;
  onRun: (connector: ConnectorInfo) => void;
}

export function ConnectorCard({ connector, busy, onRun }: ConnectorCardProps) {
  return (
    <Card className="flex flex-col">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="flex items-center gap-2">
            <span className={cn("h-2 w-2 rounded-full", connector.healthy ? "bg-success" : "bg-destructive")} />
            {connector.display_name}
          </CardTitle>
          <Badge variant="outline" className="font-mono text-[10px]">
            {connector.source_system}
          </Badge>
        </div>
        <CardDescription className="line-clamp-2">{connector.description}</CardDescription>
      </CardHeader>
      <CardContent className="mt-auto flex items-center justify-between gap-3 pt-0">
        <div className="text-xs text-muted-foreground">
          {connector.estimated_documents !== null ? <>{formatInt(connector.estimated_documents)} documents</> : "size unknown"}
          {busy ? <span className="ml-2 text-warning">· running</span> : null}
        </div>
        <Button size="sm" onClick={() => onRun(connector)} disabled={!connector.healthy || busy}>
          <Play className="h-3.5 w-3.5" /> Run
        </Button>
      </CardContent>
    </Card>
  );
}
