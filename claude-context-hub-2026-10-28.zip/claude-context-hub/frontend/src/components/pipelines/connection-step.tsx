import { ArrowRight, Check, ChevronRight, Files } from "lucide-react";
import { Link } from "react-router-dom";

import type { ConnectorInfo } from "@/api/types";
import { KindTile, levelStyle } from "@/components/pipelines/kind-visuals";
import { ConnectionTile, connectionStyle } from "@/components/pipelines/pipeline-visuals";
import { Skeleton } from "@/components/ui/skeleton";
import { formatInt } from "@/lib/format";
import { cn } from "@/lib/utils";

interface ConnectionStepProps {
  connections: ConnectorInfo[] | undefined;
  loading: boolean;
  selected: string;
  /** Editing a pipeline: its connection cannot change. */
  locked?: boolean;
  onSelect: (name: string) => void;
}

function ConnectionCard({ c, chosen, disabled, onSelect }: { c: ConnectorInfo; chosen: boolean; disabled: boolean; onSelect: () => void }) {
  const { color } = connectionStyle(c.source_system);
  return (
    <button
      type="button"
      disabled={disabled}
      aria-pressed={chosen}
      onClick={onSelect}
      className={cn(
        "surface group relative flex flex-col overflow-hidden p-0 text-left transition-all duration-200",
        chosen ? "border-primary/60 shadow-[0_18px_40px_-24px_hsl(var(--primary))] ring-2 ring-primary/30" : "hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-lg",
        disabled && "cursor-not-allowed opacity-50 hover:translate-y-0 hover:shadow-none",
      )}
    >
      <span className="h-1.5 w-full" style={{ background: `linear-gradient(90deg, hsl(${color}), hsl(${color} / 0.35))` }} aria-hidden="true" />
      <span className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full opacity-60 blur-2xl transition-opacity group-hover:opacity-100" style={{ background: `hsl(${color} / 0.18)` }} aria-hidden="true" />
      <span className="relative flex items-start gap-3 p-4">
        <ConnectionTile system={c.source_system} className="h-12 w-12" iconClass="h-6 w-6" />
        <span className="min-w-0 flex-1">
          <span className="flex items-center gap-2">
            <span className="truncate text-base font-medium">{c.display_name}</span>
            <span className={cn("flex items-center gap-1 rounded-full px-1.5 py-px text-[10px] font-medium", c.healthy ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive")}>
              <span className={cn("h-1.5 w-1.5 rounded-full", c.healthy ? "bg-success" : "bg-destructive")} />
              {c.healthy ? "healthy" : "unreachable"}
            </span>
          </span>
          <span className="mt-1 line-clamp-2 text-xs text-muted-foreground">{c.description}</span>
        </span>
        {chosen ? (
          <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground shadow">
            <Check className="h-3.5 w-3.5" strokeWidth={3} />
          </span>
        ) : null}
      </span>
      <span className="relative mt-auto flex flex-wrap items-center gap-2 border-t border-border/60 bg-muted/20 px-4 py-2.5">
        {c.estimated_documents !== null ? (
          <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <Files className="h-3.5 w-3.5" /> <span className="font-semibold tabular-nums text-foreground">{formatInt(c.estimated_documents)}</span> documents today
          </span>
        ) : null}
        {c.scope_levels.length ? (
          <span className="ml-auto flex items-center gap-1">
            {c.scope_levels.map((level, i) => (
              <span key={level} className="flex items-center gap-1">
                {i > 0 ? <ChevronRight className="h-3 w-3 text-muted-foreground/60" /> : null}
                <KindTile style={levelStyle(level)} size="xs" />
                <span className="hidden text-[10px] text-muted-foreground lg:inline">{level}</span>
              </span>
            ))}
          </span>
        ) : null}
      </span>
    </button>
  );
}

/** Step 1: the saved connection the pipeline reads from. Credentials stay on the server. */
export function ConnectionStep({ connections, loading, selected, locked, onSelect }: ConnectionStepProps) {
  return (
    <div className="space-y-4">
      <section className="surface relative overflow-hidden p-4 sm:p-5">
        <div className="hero-grid pointer-events-none absolute inset-0 opacity-20" aria-hidden="true" />
        <div className="relative">
          <h2 className="text-lg font-medium sm:text-xl">Pick a connection</h2>
          <p className="mt-0.5 max-w-3xl text-sm text-muted-foreground">A pipeline reuses a connection configured on the server, so it never holds credentials. The next step reads the schema of that connection live.</p>
        </div>
      </section>
      {loading && !connections ? (
        <div className="grid gap-4 sm:grid-cols-2 2xl:grid-cols-4">
          {[0, 1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-40 rounded-2xl" />
          ))}
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 2xl:grid-cols-4">
          {(connections ?? []).map((c) => (
            <ConnectionCard key={c.name} c={c} chosen={c.name === selected} disabled={!c.healthy || Boolean(locked && c.name !== selected)} onSelect={() => onSelect(c.name)} />
          ))}
        </div>
      )}
      {connections && connections.length === 0 ? <p className="rounded-xl border border-dashed border-border/80 p-6 text-center text-sm text-muted-foreground">No connection is configured on the server yet.</p> : null}
      <p className="text-xs text-muted-foreground">
        Missing a source?{" "}
        <Link to="/connectors" className="inline-flex items-center gap-1 font-medium text-primary hover:underline">
          Open the connector catalogue <ArrowRight className="h-3 w-3" />
        </Link>
      </p>
    </div>
  );
}
