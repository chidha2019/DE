import { Play, Plus } from "lucide-react";
import { Link } from "react-router-dom";

import type { ConnectorInfo } from "@/api/types";
import { ConnectionTile } from "@/components/pipelines/pipeline-visuals";
import { Button } from "@/components/ui/button";
import { formatInt } from "@/lib/format";
import { cn } from "@/lib/utils";

interface ConnectionStripProps {
  connections: ConnectorInfo[];
  pipelineCounts: Record<string, number>;
  busy: Set<string>;
  /** The large variant shown when there is no pipeline yet. */
  hero?: boolean;
  onRunAll: (connection: ConnectorInfo) => void;
}

/** The saved connections with a way to start a pipeline on each, or to run one whole. */
export function ConnectionStrip({ connections, pipelineCounts, busy, hero, onRunAll }: ConnectionStripProps) {
  return (
    <div className={cn("grid gap-3", hero ? "lg:grid-cols-2" : "lg:grid-cols-2 2xl:grid-cols-4")}>
      {connections.map((c) => (
        <div key={c.name} className="surface flex items-center gap-3 p-3">
          <ConnectionTile system={c.source_system} className={hero ? "h-12 w-12" : "h-9 w-9"} />
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <span className="truncate text-sm font-medium">{c.display_name}</span>
              <span className={cn("h-2 w-2 shrink-0 rounded-full", c.healthy ? "bg-success" : "bg-destructive")} title={c.healthy ? "Healthy" : "Not reachable"} />
            </div>
            <div className="truncate text-[11px] text-muted-foreground">
              {c.estimated_documents !== null ? `${formatInt(c.estimated_documents)} documents` : "size unknown"} · {formatInt(pipelineCounts[c.name] ?? 0)} pipelines
              {busy.has(c.name) ? <span className="text-warning"> · running</span> : null}
            </div>
            {hero ? <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{c.description}</p> : null}
          </div>
          <div className="flex shrink-0 items-center gap-1">
            <Button size="sm" asChild disabled={!c.healthy}>
              <Link to={`/pipelines/new?connection=${encodeURIComponent(c.name)}`}>
                <Plus className="h-3.5 w-3.5" /> Pipeline
              </Link>
            </Button>
            <Button size="icon-sm" variant="ghost" disabled={!c.healthy || busy.has(c.name)} onClick={() => onRunAll(c)} title="Run the whole connection once, without a pipeline" aria-label={`Run all of ${c.display_name}`}>
              <Play className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
      ))}
    </div>
  );
}
