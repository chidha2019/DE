import type { PipelineIn, PipelineOut, PipelineUpdate, RunOptions, Schedule, ScopeItem, SourceOptions } from "@/api/types";

/** Everything the wizard edits; text fields stay strings until they are sent. */
export interface PipelineDraft {
  connector: string;
  name: string;
  description: string;
  owner: string;
  tags: string;
  /** A line-of-business key, or "" for none. */
  lineOfBusiness: string;
  scope: ScopeItem[];
  fullRefresh: boolean;
  limit: string;
  chunkTokens: string;
  overlapTokens: string;
  includeLineage: boolean | null;
  includeTags: boolean | null;
  includeAlertRules: boolean | null;
  extensions: string;
  excludeGlobs: string;
  schedule: Schedule;
  enabled: boolean;
  runNow: boolean;
}

export const MANUAL: Schedule = { type: "manual", every_minutes: null, time: null, days: [] };

export function emptyDraft(connector = ""): PipelineDraft {
  return {
    connector,
    name: "",
    description: "",
    owner: "",
    tags: "",
    lineOfBusiness: "",
    scope: [],
    fullRefresh: false,
    limit: "",
    chunkTokens: "",
    overlapTokens: "",
    includeLineage: null,
    includeTags: null,
    includeAlertRules: null,
    extensions: "",
    excludeGlobs: "",
    schedule: MANUAL,
    enabled: true,
    runNow: false,
  };
}

const list = (text: string): string[] => text.split(",").map((s) => s.trim()).filter(Boolean);
const whole = (text: string): number | null => {
  const n = Number.parseInt(text.trim(), 10);
  return Number.isFinite(n) && n > 0 ? n : null;
};

export function draftFromPipeline(p: PipelineOut): PipelineDraft {
  return {
    connector: p.connector,
    name: p.name,
    description: p.description,
    owner: p.owner,
    tags: p.tags.join(", "),
    lineOfBusiness: p.line_of_business ?? "",
    scope: p.scope,
    fullRefresh: Boolean(p.options.full_refresh),
    limit: p.options.limit ? String(p.options.limit) : "",
    chunkTokens: p.options.chunk_target_tokens ? String(p.options.chunk_target_tokens) : "",
    overlapTokens: p.options.chunk_overlap_tokens ? String(p.options.chunk_overlap_tokens) : "",
    includeLineage: p.source_options.include_lineage ?? null,
    includeTags: p.source_options.include_tags ?? null,
    includeAlertRules: p.source_options.include_alert_rules ?? null,
    extensions: (p.source_options.include_extensions ?? []).join(", "),
    excludeGlobs: (p.source_options.exclude_globs ?? []).join(", "),
    schedule: p.schedule,
    enabled: p.enabled,
    runNow: false,
  };
}

export function runOptions(d: PipelineDraft): RunOptions {
  return {
    full_refresh: d.fullRefresh,
    limit: whole(d.limit),
    chunk_target_tokens: whole(d.chunkTokens),
    chunk_overlap_tokens: d.overlapTokens.trim() === "" ? null : Number.parseInt(d.overlapTokens, 10) || 0,
  };
}

export function sourceOptions(d: PipelineDraft): SourceOptions {
  const extensions = list(d.extensions);
  const globs = list(d.excludeGlobs);
  return {
    include_lineage: d.includeLineage,
    include_tags: d.includeTags,
    include_alert_rules: d.includeAlertRules,
    include_extensions: extensions.length ? extensions : null,
    exclude_globs: globs.length ? globs : null,
  };
}

export function draftToInput(d: PipelineDraft): PipelineIn {
  return {
    name: d.name.trim(),
    description: d.description.trim(),
    connector: d.connector,
    scope: d.scope,
    options: runOptions(d),
    source_options: sourceOptions(d),
    schedule: d.schedule,
    enabled: d.enabled,
    owner: d.owner.trim(),
    tags: list(d.tags),
    line_of_business: d.lineOfBusiness || null,
    run_now: d.runNow,
  };
}

export function draftToUpdate(d: PipelineDraft): PipelineUpdate {
  const input = draftToInput(d);
  return {
    name: input.name,
    description: input.description,
    scope: input.scope,
    options: input.options,
    source_options: input.source_options,
    schedule: input.schedule,
    enabled: input.enabled,
    owner: input.owner,
    tags: input.tags,
    // An empty string clears a default the pipeline had.
    line_of_business: d.lineOfBusiness,
  };
}
