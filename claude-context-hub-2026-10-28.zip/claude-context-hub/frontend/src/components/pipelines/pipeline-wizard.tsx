import { ArrowLeft, ArrowRight, CalendarClock, Cable, Check, ListChecks, ListTree, Loader2, Save, SlidersHorizontal, type LucideIcon } from "lucide-react";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import type { PipelineOut } from "@/api/types";
import { ConnectionStep } from "@/components/pipelines/connection-step";
import { DetailsStep } from "@/components/pipelines/details-step";
import { draftFromPipeline, draftToInput, draftToUpdate, emptyDraft, type PipelineDraft } from "@/components/pipelines/pipeline-form";
import { ReviewStep } from "@/components/pipelines/review-step";
import { ScheduleStep } from "@/components/pipelines/schedule-step";
import { SourceStep } from "@/components/pipelines/source-step";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useConnectors, useCreatePipeline, useUpdatePipeline } from "@/hooks/queries";
import { ApiError, describeError } from "@/lib/api-client";
import { suggestName } from "@/lib/pipelines";
import { validateSchedule } from "@/lib/schedule";
import { cn } from "@/lib/utils";

const STEPS: Array<{ label: string; hint: string; icon: LucideIcon }> = [
  { label: "Connection", hint: "Saved connection", icon: Cable },
  { label: "Source", hint: "Live schema", icon: ListTree },
  { label: "Details", hint: "Name and options", icon: SlidersHorizontal },
  { label: "Schedule", hint: "When it runs", icon: CalendarClock },
  { label: "Review", hint: "Check and save", icon: ListChecks },
];
const LAST = STEPS.length - 1;

function StepTile({ index, step }: { index: number; step: number }) {
  const Icon = STEPS[index]?.icon ?? Cable;
  const done = index < step;
  const current = index === step;
  return (
    <span
      className={cn(
        "flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border transition-all",
        current && "border-primary/60 bg-gradient-to-br from-primary to-primary/70 text-primary-foreground shadow-[0_8px_20px_-10px_hsl(var(--primary))]",
        done && "border-primary/40 bg-primary/15 text-primary",
        !current && !done && "border-border bg-muted/50 text-muted-foreground",
      )}
    >
      {done ? <Check className="h-4 w-4" strokeWidth={3} /> : <Icon className="h-4 w-4" />}
    </span>
  );
}

function Stepper({ step, reachable, onGo }: { step: number; reachable: number; onGo: (i: number) => void }) {
  const current = STEPS[step] ?? STEPS[0];
  return (
    <>
      {/* Phones and tablets: the current step and a segmented progress bar. */}
      <div className="surface p-3 lg:hidden">
        <div className="flex items-center gap-3">
          <StepTile index={step} step={step} />
          <div className="min-w-0 flex-1">
            <div className="text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
              Step {step + 1} of {STEPS.length}
            </div>
            <div className="truncate text-sm font-medium">{current?.label}</div>
          </div>
          {step < LAST ? <span className="truncate text-[11px] text-muted-foreground">Next: {STEPS[step + 1]?.label}</span> : null}
        </div>
        <div className="mt-3 flex gap-1.5" aria-label="Steps">
          {STEPS.map((s, i) => (
            <button key={s.label} type="button" disabled={i > reachable} onClick={() => onGo(i)} aria-label={s.label} aria-current={i === step ? "step" : undefined} className={cn("h-1.5 flex-1 rounded-full transition-colors", i < step ? "bg-primary" : i === step ? "bg-primary/60" : "bg-muted")} />
          ))}
        </div>
      </div>
      {/* Laptops and up: every step with its icon, hint and the line that fills as you go. */}
      <ol className="surface hidden items-center p-2 lg:flex" aria-label="Steps">
        {STEPS.map((s, i) => {
          const open = i <= reachable;
          return (
            <li key={s.label} className={cn("flex items-center", i < LAST && "flex-1")}>
              <button
                type="button"
                disabled={!open}
                aria-current={i === step ? "step" : undefined}
                onClick={() => onGo(i)}
                className={cn("flex shrink-0 items-center gap-2.5 rounded-xl px-2 py-1.5 text-left transition-colors", i === step ? "bg-primary/10" : open ? "hover:bg-muted/60" : "cursor-not-allowed opacity-60")}
              >
                <StepTile index={i} step={step} />
                <span className="min-w-0">
                  <span className={cn("block text-sm", i === step ? "font-medium" : "font-normal text-muted-foreground")}>{s.label}</span>
                  <span className="hidden text-[11px] text-muted-foreground xl:block">{s.hint}</span>
                </span>
              </button>
              {i < LAST ? (
                <span className="mx-2 h-0.5 min-w-4 flex-1 overflow-hidden rounded-full bg-border" aria-hidden="true">
                  <span className="block h-full rounded-full bg-primary transition-all duration-500" style={{ width: i < step ? "100%" : "0%" }} />
                </span>
              ) : null}
            </li>
          );
        })}
      </ol>
    </>
  );
}

interface PipelineWizardProps {
  /** Present when editing an existing pipeline. */
  pipeline?: PipelineOut;
  /** A connection to start from, when the wizard is opened from one. */
  initialConnection?: string | null;
}

/** Five steps: connection, source schema, details, schedule, review. Creates or edits a pipeline. */
export function PipelineWizard({ pipeline, initialConnection }: PipelineWizardProps) {
  const editing = Boolean(pipeline);
  const navigate = useNavigate();
  const connections = useConnectors();
  const create = useCreatePipeline();
  const update = useUpdatePipeline();
  const [draft, setDraft] = useState<PipelineDraft>(() => (pipeline ? draftFromPipeline(pipeline) : emptyDraft(initialConnection ?? "")));
  const startStep = pipeline || initialConnection ? 1 : 0;
  const [step, setStep] = useState(startStep);
  const [reachable, setReachable] = useState(pipeline ? LAST : startStep);
  const [nameTouched, setNameTouched] = useState(false);
  const [nameTaken, setNameTaken] = useState(false);
  const connector = connections.data?.find((c) => c.name === draft.connector);

  const patch = (p: Partial<PipelineDraft>) => {
    if ("name" in p) setNameTaken(false);
    setDraft((d) => ({ ...d, ...p }));
  };
  const chooseConnection = (name: string) =>
    setDraft((d) => (d.connector === name ? d : { ...emptyDraft(name), name: d.name, description: d.description, owner: d.owner, tags: d.tags }));
  const shortName = draft.name.trim().length < 2;
  const nameError = nameTaken ? "Another pipeline already uses that name." : nameTouched && shortName ? "Give the pipeline a name of at least two characters." : null;
  const problem: string | null = step === 0 ? (draft.connector ? null : "Pick a connection to continue.") : step === 2 ? (shortName || nameTaken ? "A unique name is required." : null) : step === 3 ? validateSchedule(draft.schedule) : null;

  const go = (next: number) => {
    if (next === 2 && !draft.name.trim() && connector) patch({ name: suggestName(connector.display_name, draft.scope) });
    if (step === 2) setNameTouched(true);
    setStep(next);
    setReachable((r) => Math.max(r, next));
  };
  const saving = create.isPending || update.isPending;
  const submit = () => {
    const done = (p: PipelineOut) => navigate(`/pipelines/${p.id}`);
    const failed = (error: unknown) => {
      if (error instanceof ApiError && error.status === 409) {
        setNameTaken(true);
        setNameTouched(true);
        setStep(2);
      }
    };
    if (pipeline) update.mutate({ id: pipeline.id, body: draftToUpdate(draft) }, { onSuccess: done, onError: failed });
    else create.mutate(draftToInput(draft), { onSuccess: done, onError: failed });
  };
  const submitError = create.error ?? update.error;
  const showError = submitError && !(submitError instanceof ApiError && submitError.status === 409);

  return (
    <div className="mx-auto flex w-full max-w-[1600px] flex-col gap-4 md:gap-5">
      <Stepper step={step} reachable={draft.connector ? reachable : 0} onGo={go} />
      <div className="min-h-[24rem]">
        {step === 0 ? <ConnectionStep connections={connections.data} loading={connections.isLoading} selected={draft.connector} locked={editing} onSelect={chooseConnection} /> : null}
        {step > 0 && !connector ? (
          connections.isLoading ? (
            <Skeleton className="h-64" />
          ) : (
            <p className="rounded-xl border border-dashed border-border/80 p-8 text-center text-sm text-muted-foreground">The connection {draft.connector || "you picked"} is not available. Go back and pick another.</p>
          )
        ) : null}
        {connector && step === 1 ? <SourceStep connector={connector} draft={draft} onScope={(scope) => patch({ scope })} /> : null}
        {connector && step === 2 ? <DetailsStep connector={connector} draft={draft} nameError={nameError} onChange={patch} /> : null}
        {step === 3 ? (
          <ScheduleStep schedule={draft.schedule} enabled={draft.enabled} runNow={draft.runNow} editing={editing} onSchedule={(schedule) => patch({ schedule })} onEnabled={(enabled) => patch({ enabled })} onRunNow={(runNow) => patch({ runNow })} />
        ) : null}
        {connector && step === 4 ? <ReviewStep connector={connector} draft={draft} editing={editing} onEdit={go} /> : null}
      </div>
      <div className="sticky bottom-3 z-20 flex items-center gap-2 rounded-2xl border border-border/80 bg-card/90 p-2 shadow-[0_18px_40px_-22px_rgba(0,0,0,0.55)] backdrop-blur sm:gap-3 sm:p-2.5">
        <Button variant="ghost" size="sm" asChild>
          <Link to={pipeline ? `/pipelines/${pipeline.id}` : "/pipelines"}>Cancel</Link>
        </Button>
        <div className="min-w-0 flex-1 truncate text-right text-xs">
          {showError ? (
            <span className="text-destructive" title={describeError(submitError)}>
              {describeError(submitError)}
            </span>
          ) : problem ? (
            <span className="hidden text-muted-foreground sm:inline">{problem}</span>
          ) : null}
        </div>
        <Button variant="outline" onClick={() => go(step - 1)} disabled={step === 0} aria-label="Back">
          <ArrowLeft className="h-4 w-4" /> <span className="hidden sm:inline">Back</span>
        </Button>
        {step < LAST ? (
          <Button onClick={() => go(step + 1)} disabled={Boolean(problem) || (step === 0 && !connector)} className="min-w-[7rem]">
            Next <ArrowRight className="h-4 w-4" />
          </Button>
        ) : (
          <Button onClick={submit} disabled={saving || shortName} className="min-w-[9rem]">
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            {editing ? "Save changes" : "Create pipeline"}
          </Button>
        )}
      </div>
    </div>
  );
}
