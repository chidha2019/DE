import {
  Activity,
  AlertTriangle,
  Bug,
  CheckCircle2,
  FileText,
  Info,
  Network,
  PlayCircle,
  Radio,
  Trash2,
  WifiOff,
  XCircle,
  type LucideIcon,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";

import type { RunEvent } from "@/api/types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { SseState } from "@/hooks/use-sse";
import { formatTime, shortId } from "@/lib/format";
import { cn } from "@/lib/utils";

interface RunEventLogProps {
  events: RunEvent[];
  state: SseState;
  runId: string | null;
  onClear: () => void;
  height?: number;
}

const LEVEL_CLASS: Record<string, string> = {
  debug: "text-muted-foreground",
  info: "text-foreground",
  warning: "text-warning",
  error: "text-destructive",
};

const LEVEL_ICON: Record<string, LucideIcon> = { debug: Bug, info: Info, warning: AlertTriangle, error: XCircle };

/** The icon for an event type: run.started, run.progress, run.completed, document.*, graph.* ... */
function eventIcon(type: string): LucideIcon {
  if (type.endsWith(".started")) return PlayCircle;
  if (type.endsWith(".completed")) return CheckCircle2;
  if (type.endsWith(".failed") || type.endsWith(".error")) return XCircle;
  if (type.endsWith(".progress")) return Activity;
  if (type.startsWith("document")) return FileText;
  if (type.startsWith("graph")) return Network;
  return Radio;
}

export function RunEventLog({ events, state, runId, onClear, height = 320 }: RunEventLogProps) {
  const [filter, setFilter] = useState("");
  const [showDebug, setShowDebug] = useState(false);
  const bottomRef = useRef<HTMLDivElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const visible = useMemo(() => {
    const needle = filter.trim().toLowerCase();
    return events.filter(
      (e) =>
        (runId === null || e.run_id === runId) &&
        (showDebug || e.level !== "debug") &&
        (needle === "" || e.message.toLowerCase().includes(needle) || e.event_type.includes(needle)),
    );
  }, [events, filter, runId, showDebug]);

  // Stick to the bottom unless the user has scrolled up to read.
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
    if (nearBottom) bottomRef.current?.scrollIntoView({ block: "end" });
  }, [visible.length]);

  return (
    <div className="flex flex-col rounded-lg border bg-card">
      <div className="flex flex-wrap items-center gap-2 border-b px-3 py-2">
        <Badge variant={state === "open" ? "success" : state === "reconnecting" || state === "connecting" ? "warning" : "destructive"}>
          {state === "open" ? <Radio className="h-3 w-3" /> : <WifiOff className="h-3 w-3" />}
          {state === "open" ? "live" : state}
        </Badge>
        <span className="text-xs text-muted-foreground">
          {runId ? `run ${shortId(runId)}` : "all runs"} · {visible.length} events
        </span>
        <Input placeholder="filter…" value={filter} onChange={(e) => setFilter(e.target.value)} className="ml-auto h-7 w-44 text-xs" />
        <Button size="sm" variant={showDebug ? "secondary" : "ghost"} className="h-7 text-xs" onClick={() => setShowDebug((v) => !v)}>
          debug
        </Button>
        <Button size="icon-sm" variant="ghost" onClick={onClear} title="Clear log">
          <Trash2 className="h-3.5 w-3.5" />
        </Button>
      </div>
      <div ref={containerRef} style={{ height }} className="overflow-auto font-mono text-xs">
        {visible.length === 0 ? (
          <div className="flex h-full items-center justify-center text-muted-foreground">Waiting for events…</div>
        ) : (
          <ul className="divide-y divide-border/60">
            {visible.map((e) => {
              const LevelIcon = LEVEL_ICON[e.level] ?? Info;
              const TypeIcon = eventIcon(e.event_type);
              return (
                <li key={`${e.run_id}-${e.seq}`} className="flex items-center gap-3 px-3 py-1.5 hover:bg-muted/40">
                  <LevelIcon className={cn("h-3.5 w-3.5 shrink-0", LEVEL_CLASS[e.level] ?? "")} aria-label={e.level} />
                  <span className="shrink-0 text-muted-foreground">{formatTime(e.created_at)}</span>
                  <span className="shrink-0 rounded bg-muted px-1 text-muted-foreground">{shortId(e.run_id, 6)}</span>
                  <span className={cn("inline-flex w-36 shrink-0 items-center gap-1 truncate", LEVEL_CLASS[e.level] ?? "")}>
                    <TypeIcon className="h-3 w-3 shrink-0" />
                    <span className="truncate">{e.event_type}</span>
                  </span>
                  <span className={cn("min-w-0 flex-1 truncate", LEVEL_CLASS[e.level] ?? "")} title={e.message}>
                    {e.message}
                  </span>
                  {e.stats ? (
                    <span className="tabular shrink-0 text-muted-foreground">
                      {e.stats.documents_seen ?? 0}
                      {e.stats.estimated_total ? `/${e.stats.estimated_total}` : ""}
                    </span>
                  ) : null}
                </li>
              );
            })}
          </ul>
        )}
        <div ref={bottomRef} />
      </div>
    </div>
  );
}
