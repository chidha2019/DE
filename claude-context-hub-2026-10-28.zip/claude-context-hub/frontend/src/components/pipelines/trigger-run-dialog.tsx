import { Loader2 } from "lucide-react";
import { useEffect, useState } from "react";

import type { ConnectorInfo, RunOptions } from "@/api/types";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useTriggerRun } from "@/hooks/queries";
import { describeError } from "@/lib/api-client";

interface TriggerRunDialogProps {
  connector: ConnectorInfo | null;
  onClose: () => void;
  onStarted?: (runId: string) => void;
}

const DEFAULTS: Required<Pick<RunOptions, "full_refresh" | "simulate_failures">> & { limit: string; chunk_target_tokens: string; chunk_overlap_tokens: string } = {
  full_refresh: false,
  simulate_failures: false,
  limit: "",
  chunk_target_tokens: "",
  chunk_overlap_tokens: "",
};

export function TriggerRunDialog({ connector, onClose, onStarted }: TriggerRunDialogProps) {
  const [form, setForm] = useState(DEFAULTS);
  const trigger = useTriggerRun();

  useEffect(() => {
    if (connector) {
      setForm(DEFAULTS);
      trigger.reset();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connector?.name]);

  const toInt = (v: string): number | null => (v.trim() === "" ? null : Number.parseInt(v, 10));

  const submit = () => {
    if (!connector) return;
    const options: RunOptions = {
      full_refresh: form.full_refresh,
      simulate_failures: form.simulate_failures,
      limit: toInt(form.limit),
      chunk_target_tokens: toInt(form.chunk_target_tokens),
      chunk_overlap_tokens: toInt(form.chunk_overlap_tokens),
    };
    trigger.mutate(
      { connector: connector.name, options, triggered_by: "admin-ui" },
      {
        onSuccess: (run) => {
          onStarted?.(run.id);
          onClose();
        },
      },
    );
  };

  return (
    <Dialog open={connector !== null} onOpenChange={(open) => !open && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Run {connector?.display_name}</DialogTitle>
          <DialogDescription>Crawl, chunk, embed and graph-sync documents from this source. Runs are idempotent — unchanged content is skipped.</DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-2">
          <div className="flex items-center justify-between rounded-md border p-3">
            <div>
              <Label htmlFor="full_refresh">Full refresh</Label>
              <p className="text-xs text-muted-foreground">Re-chunk and re-embed even if content hashes match.</p>
            </div>
            <Switch id="full_refresh" checked={form.full_refresh} onCheckedChange={(v) => setForm((f) => ({ ...f, full_refresh: v }))} />
          </div>
          <div className="flex items-center justify-between rounded-md border p-3">
            <div>
              <Label htmlFor="simulate_failures">Simulate connector failures</Label>
              <p className="text-xs text-muted-foreground">Inject a transient source error to exercise failure handling.</p>
            </div>
            <Switch id="simulate_failures" checked={form.simulate_failures} onCheckedChange={(v) => setForm((f) => ({ ...f, simulate_failures: v }))} />
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="limit">Document limit</Label>
              <Input id="limit" inputMode="numeric" placeholder="all" value={form.limit} onChange={(e) => setForm((f) => ({ ...f, limit: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="target">Chunk tokens</Label>
              <Input id="target" inputMode="numeric" placeholder="320" value={form.chunk_target_tokens} onChange={(e) => setForm((f) => ({ ...f, chunk_target_tokens: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="overlap">Overlap tokens</Label>
              <Input id="overlap" inputMode="numeric" placeholder="48" value={form.chunk_overlap_tokens} onChange={(e) => setForm((f) => ({ ...f, chunk_overlap_tokens: e.target.value }))} />
            </div>
          </div>
          {trigger.isError ? <p className="text-sm text-destructive">{describeError(trigger.error)}</p> : null}
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={submit} disabled={trigger.isPending}>
            {trigger.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
            Start run
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
