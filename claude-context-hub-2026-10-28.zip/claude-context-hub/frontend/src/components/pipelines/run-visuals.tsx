/**
 * Rich visuals for ingestion runs: status pills, trigger chips, document-outcome bars, a run timeline, KPI tiles
 * and the stage flow of one run. Status colours are the reserved status palette and always travel with an icon
 * and a label, never colour alone.
 */

import {
  Activity,
  AlertTriangle,
  CalendarClock,
  CheckCircle2,
  ChevronRight,
  CircleSlash,
  Clock3,
  Cpu,
  FileStack,
  GitBranch,
  Layers,
  Loader2,
  MousePointerClick,
  Network,
  PauseCircle,
  ScanSearch,
  Sparkles,
  Terminal,
  TicketCheck,
  type LucideIcon,
} from "lucide-react";
import { useMemo, useState, type ReactNode } from "react";
import { Link } from "react-router-dom";

import type { IngestionRunOut, RunStats, RunStatus } from "@/api/types";
import { BrandMark } from "@/components/connectors/brand-mark";
import { formatCompact, formatDuration, formatInt, formatRelative, shortId } from "@/lib/format";
import { rgba } from "@/lib/tones";
import { cn } from "@/lib/utils";

// --------------------------------------------------------------------------- status
const GOOD = "#0ca30c";
const WARNING = "#fab219";
const CRITICAL = "#d03b3b";
const INFO = "#0ea5e9";
const NEUTRAL = "#94a3b8";

// eslint-disable-next-line react-refresh/only-export-components
export const RUN_STYLE: Record<RunStatus, { icon: LucideIcon; label: string; color: string; spin?: boolean }> = {
  queued: { icon: Clock3, label: "Queued", color: NEUTRAL },
  running: { icon: Loader2, label: "Running", color: INFO, spin: true },
  paused: { icon: PauseCircle, label: "Paused", color: WARNING },
  completed: { icon: CheckCircle2, label: "Completed", color: GOOD },
  failed: { icon: AlertTriangle, label: "Failed", color: CRITICAL },
  cancelled: { icon: CircleSlash, label: "Cancelled", color: NEUTRAL },
};

export function RunStatusPill({ status, className }: { status: RunStatus; className?: string }) {
  const style = RUN_STYLE[status];
  const Icon = style.icon;
  return (
    <span
      className={cn("inline-flex items-center gap-1.5 rounded-full border py-0.5 pl-0.5 pr-2 text-[11px] font-medium text-foreground", className)}
      style={{ borderColor: rgba(style.color, 0.45), background: rgba(style.color, 0.1) }}
    >
      <span className="flex h-5 w-5 items-center justify-center rounded-full text-white" style={{ background: style.color }}>
        <Icon className={cn("h-3 w-3", style.spin && "animate-spin")} />
      </span>
      {style.label}
      {status === "running" ? <span className="h-1.5 w-1.5 animate-pulse rounded-full" style={{ background: style.color }} aria-hidden="true" /> : null}
    </span>
  );
}

// --------------------------------------------------------------------------- who started a run
interface Trigger {
  icon: LucideIcon;
  label: string;
  hint: string;
  to?: string;
}

// eslint-disable-next-line react-refresh/only-export-components
export function triggerOf(by: string | null | undefined): Trigger {
  const value = (by ?? "").trim();
  if (value.startsWith("intent:")) {
    const key = value.slice("intent:".length);
    return { icon: TicketCheck, label: key, hint: `started by the approved intent ${key}`, to: "/intents" };
  }
  if (value.startsWith("repo-graph crawl")) return { icon: GitBranch, label: "repo crawl", hint: value, to: "/knowledge" };
  if (/^sched/i.test(value)) return { icon: CalendarClock, label: "schedule", hint: "started by the pipeline's schedule" };
  if (value === "admin-ui" || value === "ui") return { icon: MousePointerClick, label: "from the UI", hint: "started from the hub's UI" };
  return { icon: Terminal, label: value || "api", hint: value ? `started by ${value}` : "started through the API" };
}

export function TriggerChip({ by }: { by: string | null | undefined }) {
  const t = triggerOf(by);
  const Icon = t.icon;
  const body = (
    <span
      className="inline-flex max-w-[9rem] items-center gap-1 rounded-md border border-border/70 bg-background/60 px-1.5 py-px text-[10.5px] text-muted-foreground"
      title={t.hint}
    >
      <Icon className="h-3 w-3 shrink-0" />
      <span className="truncate">{t.label}</span>
    </span>
  );
  return t.to ? (
    <Link to={t.to} onClick={(e) => e.stopPropagation()} className="hover:opacity-80">
      {body}
    </Link>
  ) : (
    body
  );
}

// --------------------------------------------------------------------------- what happened to the documents
const OUTCOMES: Array<{ key: "documents_upserted" | "documents_skipped" | "documents_failed"; label: string; color: string }> = [
  { key: "documents_upserted", label: "upserted", color: GOOD },
  { key: "documents_skipped", label: "skipped (unchanged)", color: NEUTRAL },
  { key: "documents_failed", label: "failed", color: CRITICAL },
];

/** Upserted, skipped and failed documents as one stacked bar, with a 2px gap between the parts. */
export function OutcomeBar({ stats, className }: { stats: RunStats; className?: string }) {
  const parts = OUTCOMES.map((o) => ({ ...o, value: stats[o.key] })).filter((p) => p.value > 0);
  const total = parts.reduce((sum, p) => sum + p.value, 0);
  const title = OUTCOMES.map((o) => `${formatInt(stats[o.key])} ${o.label}`).join(" · ");
  if (!total) return <div className={cn("h-1.5 rounded-full bg-muted", className)} title="no documents" />;
  return (
    <div className={cn("flex h-1.5 gap-[2px]", className)} title={title} role="img" aria-label={title}>
      {parts.map((p) => (
        <span key={p.key} className="h-full rounded-[4px]" style={{ width: `${(p.value / total) * 100}%`, background: p.color, minWidth: 3 }} />
      ))}
    </div>
  );
}

export function OutcomeLegend({ stats }: { stats: RunStats }) {
  return (
    <div className="flex flex-wrap gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
      {OUTCOMES.map((o) => (
        <span key={o.key} className="inline-flex items-center gap-1.5">
          <span className="h-2 w-2 rounded-sm" style={{ background: o.color }} aria-hidden="true" />
          <span className="font-medium tabular-nums text-foreground">{formatInt(stats[o.key])}</span> {o.label}
        </span>
      ))}
    </div>
  );
}

/** A run's duration as a bar against the longest run on screen. */
export function DurationBar({ seconds, max }: { seconds: number | null; max: number }) {
  const pct = seconds && max ? Math.max(4, (seconds / max) * 100) : 0;
  return (
    <div className="flex min-w-[5.5rem] items-center gap-2">
      <div className="h-1 flex-1 overflow-hidden rounded-full bg-muted">
        <div className="h-full rounded-full bg-primary/70" style={{ width: `${pct}%` }} />
      </div>
      <span className="w-11 text-right text-[11px] tabular-nums text-muted-foreground">{formatDuration(seconds)}</span>
    </div>
  );
}

// --------------------------------------------------------------------------- KPI tiles
function Sparkline({ values, color }: { values: number[]; color: string }) {
  if (values.length < 2) return null;
  const max = Math.max(...values, 1);
  const step = 100 / (values.length - 1);
  const points = values.map((v, i) => `${(i * step).toFixed(2)},${(28 - (v / max) * 24).toFixed(2)}`).join(" ");
  const id = `spark-${color.replace("#", "")}`;
  return (
    <svg viewBox="0 0 100 30" preserveAspectRatio="none" className="mt-1.5 h-7 w-full" aria-hidden="true">
      <defs>
        <linearGradient id={id} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.28" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon points={`0,30 ${points} 100,30`} fill={`url(#${id})`} />
      <polyline points={points} fill="none" stroke={color} strokeWidth="2" vectorEffect="non-scaling-stroke" strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}

function KpiTile({
  icon: Icon,
  tone,
  label,
  value,
  hint,
  children,
}: {
  icon: LucideIcon;
  tone: string;
  label: string;
  value: ReactNode;
  hint?: string;
  children?: ReactNode;
}) {
  return (
    <div className="relative min-w-0 overflow-hidden rounded-2xl border bg-card/80 p-3.5 shadow-sm" style={{ borderColor: rgba(tone, 0.28) }} title={hint}>
      <span
        className="pointer-events-none absolute -right-8 -top-8 h-24 w-24 rounded-full opacity-60 blur-2xl"
        style={{ background: rgba(tone, 0.3) }}
        aria-hidden="true"
      />
      <div className="relative flex items-center gap-3">
        <span
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-white"
          style={{ background: `linear-gradient(140deg, ${rgba(tone, 0.75)}, ${tone})`, boxShadow: `0 10px 22px -12px ${tone}` }}
        >
          <Icon className="h-5 w-5" />
        </span>
        <div className="min-w-0">
          <div className="font-display text-2xl font-medium leading-tight tabular-nums">{value}</div>
          <div className="truncate text-[10px] uppercase tracking-wide text-muted-foreground">{label}</div>
        </div>
      </div>
      {children ? <div className="relative">{children}</div> : null}
    </div>
  );
}

function median(values: number[]): number | null {
  if (!values.length) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? (sorted[mid] ?? null) : ((sorted[mid - 1] ?? 0) + (sorted[mid] ?? 0)) / 2;
}

/** The run history's headline numbers, from the runs on screen. */
export function RunKpis({ runs, total }: { runs: IngestionRunOut[]; total: number }) {
  const chronological = useMemo(() => [...runs].reverse(), [runs]);
  const finished = runs.filter((r) => r.status === "completed" || r.status === "failed" || r.status === "cancelled");
  const completed = runs.filter((r) => r.status === "completed").length;
  const failed = runs.filter((r) => r.status === "failed").length;
  const rate = finished.length ? Math.round((completed / finished.length) * 100) : null;
  const upserted = runs.reduce((sum, r) => sum + r.stats.documents_upserted, 0);
  const durations = runs.map((r) => r.duration_seconds).filter((d): d is number => d != null);
  const med = median(durations);
  const shown = runs.length < total ? `last ${runs.length} of ${formatInt(total)} runs` : `${formatInt(total)} runs`;
  const spread = durations.length ? `fastest ${formatDuration(Math.min(...durations))} · slowest ${formatDuration(Math.max(...durations))}` : undefined;
  return (
    <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
      <KpiTile icon={Activity} tone="#8B5CF6" label="Runs" value={formatInt(total)} hint={`${shown}; the line is documents seen per run`}>
        <Sparkline values={chronological.map((r) => r.stats.documents_seen)} color="#8B5CF6" />
      </KpiTile>
      <KpiTile
        icon={CheckCircle2}
        tone={GOOD}
        label="Success rate"
        value={rate === null ? "–" : `${rate}%`}
        hint={`${completed} of ${finished.length} finished runs completed (${shown})`}
      >
        <div className="mt-2.5 h-1.5 overflow-hidden rounded-full bg-muted">
          <div className="h-full rounded-full" style={{ width: `${rate ?? 0}%`, background: GOOD }} />
        </div>
      </KpiTile>
      <KpiTile
        icon={FileStack}
        tone="#0EA5E9"
        label="Documents upserted"
        value={formatCompact(upserted)}
        hint={`${shown}; the line is documents upserted per run`}
      >
        <Sparkline values={chronological.map((r) => r.stats.documents_upserted)} color="#0EA5E9" />
      </KpiTile>
      <KpiTile icon={Clock3} tone="#F59E0B" label="Median duration" value={formatDuration(med)} hint={spread}>
        <Sparkline values={chronological.map((r) => r.duration_seconds ?? 0)} color="#F59E0B" />
      </KpiTile>
      <KpiTile icon={AlertTriangle} tone={failed ? CRITICAL : NEUTRAL} label="Failed runs" value={formatInt(failed)} hint={shown}>
        <div className="mt-2.5 text-[11px] text-muted-foreground">{failed ? "open a red bar in the timeline" : "nothing failed"}</div>
      </KpiTile>
    </div>
  );
}

// --------------------------------------------------------------------------- the timeline of runs
/** One bar per run, oldest on the left: height is how long it ran, colour is how it ended. Click a bar to open it. */
export function RunTimeline({ runs, selectedId, onSelect }: { runs: IngestionRunOut[]; selectedId: string | null; onSelect: (run: IngestionRunOut) => void }) {
  const [hover, setHover] = useState<number | null>(null);
  const bars = useMemo(() => [...runs].reverse(), [runs]);
  const max = Math.max(1, ...bars.map((r) => r.duration_seconds ?? 0));
  const statuses = useMemo(() => {
    const counts = new Map<RunStatus, number>();
    for (const r of bars) counts.set(r.status, (counts.get(r.status) ?? 0) + 1);
    return [...counts.entries()];
  }, [bars]);
  if (!bars.length) return null;
  const focus = hover !== null ? bars[hover] : undefined;
  return (
    <div className="rounded-2xl border bg-card/80 p-4 shadow-sm">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div>
          <div className="text-sm font-medium">Run timeline</div>
          <div className="text-[11px] text-muted-foreground">Each bar is a run, oldest left · height is how long it ran · click to open it</div>
        </div>
        <div className="flex flex-wrap gap-2">
          {statuses.map(([status, n]) => {
            const style = RUN_STYLE[status];
            const Icon = style.icon;
            return (
              <span key={status} className="inline-flex items-center gap-1 text-[11px] text-muted-foreground">
                <Icon className="h-3.5 w-3.5" style={{ color: style.color }} /> {style.label} <span className="tabular-nums text-foreground">{n}</span>
              </span>
            );
          })}
        </div>
      </div>
      <div className="relative">
        <div className="flex h-28 items-end gap-[2px] border-b border-border" onMouseLeave={() => setHover(null)}>
          {bars.map((run, i) => {
            const style = RUN_STYLE[run.status];
            const height = run.duration_seconds ? Math.max(8, (Math.sqrt(run.duration_seconds) / Math.sqrt(max)) * 100) : 8;
            const selected = run.id === selectedId;
            return (
              <button
                key={run.id}
                type="button"
                onMouseEnter={() => setHover(i)}
                onFocus={() => setHover(i)}
                onBlur={() => setHover(null)}
                onClick={() => onSelect(run)}
                aria-label={`${style.label} run ${shortId(run.id)} of ${run.connector_name}, ${formatDuration(run.duration_seconds)}`}
                className="flex h-full min-w-[6px] flex-1 items-end justify-center"
              >
                <span
                  className={cn(
                    "w-full max-w-[2.75rem] rounded-t-[4px] transition-opacity",
                    selected || hover === null || hover === i ? "opacity-100" : "opacity-40",
                  )}
                  style={{
                    height: `${height}%`,
                    background: style.color,
                    boxShadow: selected ? `0 0 0 2px hsl(var(--card)), 0 0 0 4px ${style.color}` : undefined,
                  }}
                />
              </button>
            );
          })}
        </div>
        {focus && hover !== null ? (
          <div
            className="pointer-events-none absolute bottom-full z-20 mb-2 w-60 -translate-x-1/2 rounded-xl border bg-popover p-2.5 text-xs shadow-lg"
            style={{ left: `${Math.min(85, Math.max(15, ((hover + 0.5) / bars.length) * 100))}%` }}
          >
            <div className="flex items-center gap-2">
              <BrandMark icon={focus.source_system} size="xs" />
              <span className="min-w-0 flex-1 truncate font-medium">{focus.connector_name}</span>
              <RunStatusPill status={focus.status} />
            </div>
            <div className="mt-1.5 grid grid-cols-2 gap-x-3 gap-y-0.5 text-[11px] text-muted-foreground">
              <span>duration</span>
              <span className="text-right tabular-nums text-foreground">{formatDuration(focus.duration_seconds)}</span>
              <span>upserted</span>
              <span className="text-right tabular-nums text-foreground">{formatInt(focus.stats.documents_upserted)}</span>
              <span>chunks</span>
              <span className="text-right tabular-nums text-foreground">{formatInt(focus.stats.chunks_created)}</span>
              <span>started</span>
              <span className="text-right text-foreground">{formatRelative(focus.started_at ?? focus.created_at)}</span>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}

// --------------------------------------------------------------------------- one run's stages
const STAGES: Array<{ key: keyof RunStats; label: string; icon: LucideIcon; tone: string }> = [
  { key: "documents_seen", label: "Seen", icon: ScanSearch, tone: "#6366F1" },
  { key: "documents_upserted", label: "Upserted", icon: FileStack, tone: "#0EA5E9" },
  { key: "chunks_created", label: "Chunks", icon: Layers, tone: "#14B8A6" },
  { key: "embeddings_created", label: "Embeddings", icon: Cpu, tone: "#8B5CF6" },
  { key: "entities_linked", label: "Entities", icon: Sparkles, tone: "#EC4899" },
  { key: "graph_synced", label: "Graph", icon: Network, tone: "#10B981" },
];

/** What one run did, stage by stage: the documents it read, wrote, chunked, embedded and linked into the graph. */
export function StageFlow({ stats }: { stats: RunStats }) {
  return (
    <ol className="grid grid-cols-3 gap-2">
      {STAGES.map((stage, i) => {
        const Icon = stage.icon;
        const value = stats[stage.key] as number | null;
        const idle = !value;
        return (
          <li
            key={stage.key}
            className="relative flex flex-col items-center rounded-xl border bg-background/50 px-1 py-2 text-center"
            style={{ borderColor: idle ? undefined : rgba(stage.tone, 0.35) }}
          >
            <span
              className={cn("flex h-8 w-8 items-center justify-center rounded-lg", idle ? "bg-muted text-muted-foreground" : "text-white")}
              style={idle ? undefined : { background: `linear-gradient(140deg, ${rgba(stage.tone, 0.75)}, ${stage.tone})` }}
            >
              <Icon className="h-4 w-4" />
            </span>
            <span className="mt-1 font-display text-base font-medium leading-tight tabular-nums">{value === null ? "?" : formatCompact(value)}</span>
            <span className="text-[10px] uppercase tracking-wide text-muted-foreground">{stage.label}</span>
            {i % 3 !== 2 ? <ChevronRight className="absolute -right-2 top-5 z-10 h-3.5 w-3.5 text-muted-foreground/60" aria-hidden="true" /> : null}
          </li>
        );
      })}
    </ol>
  );
}
