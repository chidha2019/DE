import { AlertTriangle, Layers, Network, Pause, Play, Square } from "lucide-react";

import type { IngestionRunOut } from "@/api/types";
import { BrandMark } from "@/components/connectors/brand-mark";
import { DurationBar, OutcomeBar, RunStatusPill, TriggerChip } from "@/components/pipelines/run-visuals";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { useRunControl } from "@/hooks/queries";
import { formatInt, formatRelative, shortId } from "@/lib/format";
import { cn } from "@/lib/utils";

interface RunTableProps {
  runs: IngestionRunOut[] | undefined;
  loading?: boolean;
  selectedId: string | null;
  onSelect: (run: IngestionRunOut) => void;
  /** pipeline id -> name, to say which pipeline a run belongs to */
  pipelineNames?: Record<string, string>;
  /** False when every run belongs to the same pipeline, so the column says nothing. */
  showPipeline?: boolean;
}

export function RunTable({ runs, loading, selectedId, onSelect, pipelineNames, showPipeline = true }: RunTableProps) {
  const control = useRunControl();

  if (loading && !runs) {
    return (
      <div className="space-y-2 p-4">
        {[0, 1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-12 w-full rounded-xl" />
        ))}
      </div>
    );
  }
  if (!runs || runs.length === 0) {
    return <div className="p-8 text-center text-sm text-muted-foreground">No runs yet. Run a pipeline to start ingesting.</div>;
  }
  const longest = Math.max(1, ...runs.map((r) => r.duration_seconds ?? 0));

  return (
    <Table>
      <TableHeader>
        <TableRow className="hover:bg-transparent">
          <TableHead>Run</TableHead>
          <TableHead>Status</TableHead>
          <TableHead className="w-[200px]">Documents</TableHead>
          <TableHead title="chunks created and documents written to the graph">Indexed</TableHead>
          <TableHead>Duration</TableHead>
          <TableHead className="w-10 text-right">
            <span className="sr-only">Actions</span>
          </TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {runs.map((run) => {
          const s = run.stats;
          const pct = Math.round((run.progress ?? 0) * 100);
          const active = run.status === "running" || run.status === "paused" || run.status === "queued";
          const selected = selectedId === run.id;
          return (
            <TableRow
              key={run.id}
              data-state={selected ? "selected" : undefined}
              className={cn("cursor-pointer transition-colors", selected ? "bg-primary/5 shadow-[inset_3px_0_0_hsl(var(--primary))]" : "hover:bg-muted/50")}
              onClick={() => onSelect(run)}
            >
              <TableCell className="max-w-[16rem]">
                <div className="flex items-center gap-2.5">
                  <BrandMark icon={run.source_system} size="sm" />
                  <div className="min-w-0">
                    <div className="truncate text-sm font-medium">
                      {showPipeline ? (run.pipeline_id ? (pipelineNames?.[run.pipeline_id] ?? "Deleted pipeline") : "Ad hoc run") : run.connector_name}
                    </div>
                    <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                      <span className="font-mono">{shortId(run.id)}</span>
                      {showPipeline ? <span className="truncate">· {run.connector_name}</span> : null}
                      <TriggerChip by={run.triggered_by} />
                    </div>
                  </div>
                </div>
              </TableCell>
              <TableCell>
                <RunStatusPill status={run.status} />
                <div className="mt-1 whitespace-nowrap pl-1 text-[10.5px] text-muted-foreground">{formatRelative(run.started_at ?? run.created_at)}</div>
              </TableCell>
              <TableCell>
                <div className="flex items-center justify-between gap-2 text-[11px] text-muted-foreground">
                  <span className="whitespace-nowrap">
                    <span className="font-medium tabular-nums text-foreground">{formatInt(s.documents_upserted)}</span> upserted
                    {s.documents_skipped ? ` · ${formatInt(s.documents_skipped)} skipped` : ""}
                    {s.documents_failed ? (
                      <span className="text-destructive">
                        {" "}
                        · <AlertTriangle className="inline h-3 w-3" /> {formatInt(s.documents_failed)}
                      </span>
                    ) : null}
                  </span>
                  <span className="tabular-nums">
                    {formatInt(s.documents_seen)}/{s.estimated_total !== null ? formatInt(s.estimated_total) : "?"}
                  </span>
                </div>
                {active ? (
                  <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-muted">
                    <div className="h-full rounded-full bg-gradient-to-r from-sky-500 to-violet-500 transition-all" style={{ width: `${pct}%` }} />
                  </div>
                ) : (
                  <OutcomeBar stats={s} className="mt-1" />
                )}
              </TableCell>
              <TableCell className="whitespace-nowrap text-[11px] text-muted-foreground">
                <div className="flex items-center gap-1" title="chunks created">
                  <Layers className="h-3 w-3" /> <span className="tabular-nums text-foreground">{formatInt(s.chunks_created)}</span> chunks
                </div>
                <div className="mt-0.5 flex items-center gap-1" title="documents written to the graph">
                  <Network className="h-3 w-3" /> <span className="tabular-nums text-foreground">{formatInt(s.graph_synced)}</span> in graph
                  {s.graph_failed > 0 ? <span className="text-warning">· {formatInt(s.graph_failed)} failed</span> : null}
                </div>
              </TableCell>
              <TableCell>
                <DurationBar seconds={run.duration_seconds} max={longest} />
              </TableCell>
              <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                {active ? (
                  <div className="flex justify-end gap-1">
                    {run.status === "running" ? (
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button size="icon-sm" variant="ghost" disabled={control.busy} onClick={() => control.pause.mutate(run.id)}>
                            <Pause className="h-3.5 w-3.5" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>Pause</TooltipContent>
                      </Tooltip>
                    ) : null}
                    {run.status === "paused" ? (
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button size="icon-sm" variant="ghost" disabled={control.busy} onClick={() => control.resume.mutate(run.id)}>
                            <Play className="h-3.5 w-3.5" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>Resume</TooltipContent>
                      </Tooltip>
                    ) : null}
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          size="icon-sm"
                          variant="ghost"
                          className="text-destructive"
                          disabled={control.busy}
                          onClick={() => control.cancel.mutate(run.id)}
                        >
                          <Square className="h-3.5 w-3.5" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>Cancel</TooltipContent>
                    </Tooltip>
                  </div>
                ) : run.error ? (
                  <span className="inline-flex items-center gap-1 text-xs text-destructive" title={run.error}>
                    <AlertTriangle className="h-3.5 w-3.5" /> error
                  </span>
                ) : (
                  <span className="text-xs text-muted-foreground">—</span>
                )}
              </TableCell>
            </TableRow>
          );
        })}
      </TableBody>
    </Table>
  );
}
