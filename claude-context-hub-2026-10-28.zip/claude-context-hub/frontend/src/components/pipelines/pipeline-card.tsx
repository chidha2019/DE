import { CirclePause, Clock, Pencil, Play, Trash2 } from "lucide-react";
import { Link } from "react-router-dom";

import type { ConnectorInfo, PipelineOut } from "@/api/types";
import { ConnectionTile, ScopeChips, StatePill, connectionStyle } from "@/components/pipelines/pipeline-visuals";
import { RunStatusBadge } from "@/components/pipelines/run-status-badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { formatDuration, formatInt, formatRelative } from "@/lib/format";
import { scopeSummary } from "@/lib/pipelines";
import { formatUntil } from "@/lib/schedule";
import { cn } from "@/lib/utils";

interface PipelineCardProps {
  pipeline: PipelineOut;
  connection: ConnectorInfo | undefined;
  busy: boolean;
  onRun: (pipeline: PipelineOut) => void;
  onToggle: (pipeline: PipelineOut) => void;
  onDelete: (pipeline: PipelineOut) => void;
}

function IconAction({ label, onClick, disabled, danger, children }: { label: string; onClick: () => void; disabled?: boolean; danger?: boolean; children: React.ReactNode }) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button size="icon-sm" variant="ghost" className={cn(danger && "text-destructive hover:text-destructive")} disabled={disabled} onClick={onClick} aria-label={label}>
          {children}
        </Button>
      </TooltipTrigger>
      <TooltipContent>{label}</TooltipContent>
    </Tooltip>
  );
}

/** One saved pipeline: what it reads, when it runs, how the last run went, and the actions on it. */
export function PipelineCard({ pipeline: p, connection, busy, onRun, onToggle, onDelete }: PipelineCardProps) {
  const run = p.last_run;
  const active = run?.status === "running" || run?.status === "queued" || run?.status === "paused";
  const pct = Math.round((run?.progress ?? 0) * 100);
  const levels = connection?.scope_levels ?? [];
  const scheduled = p.schedule.type !== "manual";
  const { color } = connectionStyle(p.source_system);
  return (
    <article className="surface group relative flex flex-col gap-3 overflow-hidden p-4 pt-5 transition-all duration-200 hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-lg">
      <span className="absolute inset-x-0 top-0 h-1" style={{ background: `linear-gradient(90deg, hsl(${color}), hsl(${color} / 0.25))` }} aria-hidden="true" />
      <span className="pointer-events-none absolute -right-12 -top-12 h-36 w-36 rounded-full opacity-50 blur-3xl transition-opacity group-hover:opacity-90" style={{ background: `hsl(${color} / 0.2)` }} aria-hidden="true" />
      <div className="relative flex items-start gap-3">
        <ConnectionTile system={p.source_system} className="h-11 w-11" iconClass="h-5 w-5" />
        <div className="min-w-0 flex-1">
          <Link to={`/pipelines/${p.id}`} className="block truncate text-base font-medium leading-tight hover:text-primary" title={p.name}>
            {p.name}
          </Link>
          <p className="mt-0.5 truncate text-xs text-muted-foreground" title={p.description || undefined}>
            {p.description || `${p.connector_label} · ${scopeSummary(p.scope, levels)}`}
          </p>
        </div>
        <StatePill pipeline={p} />
      </div>
      <ScopeChips scope={p.scope} className="relative" />
      <dl className="relative grid grid-cols-2 gap-x-4 gap-y-1 rounded-xl border border-border/60 bg-muted/20 p-3 text-xs">
        <div>
          <dt className="text-[10px] uppercase tracking-wide text-muted-foreground">Schedule</dt>
          <dd className="mt-0.5 flex items-center gap-1.5">
            {p.enabled && scheduled ? <Clock className="h-3 w-3 text-muted-foreground" /> : <CirclePause className="h-3 w-3 text-muted-foreground" />}
            <span className={cn(!p.enabled && scheduled && "text-muted-foreground line-through")}>{p.schedule_label}</span>
          </dd>
          {p.next_run_at && p.enabled ? <dd className="text-[11px] text-muted-foreground">next {formatUntil(p.next_run_at)}</dd> : null}
        </div>
        <div>
          <dt className="text-[10px] uppercase tracking-wide text-muted-foreground">Last run</dt>
          <dd className="mt-0.5">{run ? <RunStatusBadge status={run.status} /> : <span className="text-muted-foreground">never run</span>}</dd>
          {run ? <dd className="text-[11px] text-muted-foreground">{formatRelative(run.started_at ?? run.created_at)}</dd> : null}
        </div>
      </dl>
      {active ? (
        <div className="flex items-center gap-2">
          <Progress value={pct} className="h-1.5" />
          <span className="tabular w-20 text-right text-xs text-muted-foreground">
            {formatInt(run?.documents_seen)}/{run?.estimated_total != null ? formatInt(run.estimated_total) : "?"}
          </span>
        </div>
      ) : run ? (
        <p className="text-[11px] text-muted-foreground">
          {formatInt(run.documents_upserted)} upserted · {formatInt(run.documents_skipped)} unchanged
          {run.documents_failed ? <span className="text-destructive"> · {formatInt(run.documents_failed)} failed</span> : null}
          {run.duration_seconds != null ? ` · ${formatDuration(run.duration_seconds)}` : ""}
        </p>
      ) : null}
      {!p.connection_available ? <p className="text-[11px] text-warning">The connection {p.connector} is not configured on the server any more.</p> : null}
      <div className="mt-auto flex items-center justify-between border-t border-border/60 pt-3">
        <span className="truncate text-[11px] text-muted-foreground">
          {p.connector_label} · {formatInt(p.runs_total)} runs{p.runs_failed ? ` · ${p.runs_failed} failed` : ""}
        </span>
        <div className="flex shrink-0 items-center">
          <IconAction label={busy ? "The connection is busy" : "Run now"} onClick={() => onRun(p)} disabled={busy || !p.connection_available}>
            <Play className="h-3.5 w-3.5" />
          </IconAction>
          {scheduled ? (
            <IconAction label={p.enabled ? "Pause the schedule" : "Resume the schedule"} onClick={() => onToggle(p)}>
              {p.enabled ? <CirclePause className="h-3.5 w-3.5" /> : <Clock className="h-3.5 w-3.5" />}
            </IconAction>
          ) : null}
          <Tooltip>
            <TooltipTrigger asChild>
              <Button size="icon-sm" variant="ghost" asChild aria-label="Edit">
                <Link to={`/pipelines/${p.id}/edit`}>
                  <Pencil className="h-3.5 w-3.5" />
                </Link>
              </Button>
            </TooltipTrigger>
            <TooltipContent>Edit</TooltipContent>
          </Tooltip>
          <IconAction label="Delete" danger onClick={() => onDelete(p)}>
            <Trash2 className="h-3.5 w-3.5" />
          </IconAction>
        </div>
      </div>
    </article>
  );
}
