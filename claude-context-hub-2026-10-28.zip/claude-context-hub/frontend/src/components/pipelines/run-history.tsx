import { useMemo, useState } from "react";

import type { IngestionRunOut, RunStatus } from "@/api/types";
import { MousePointerClick, Radio } from "lucide-react";

import { RunDetails } from "@/components/pipelines/run-details";
import { RunEventLog } from "@/components/pipelines/run-event-log";
import { RunTable } from "@/components/pipelines/run-table";
import { RunKpis, RunTimeline } from "@/components/pipelines/run-visuals";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { usePipelines, useRuns } from "@/hooks/queries";
import { useRunEventStream } from "@/hooks/use-sse";
import { describeError } from "@/lib/api-client";
import { formatInt } from "@/lib/format";

const STATUS_FILTERS: Array<{ value: RunStatus | "all"; label: string }> = [
  { value: "all", label: "All statuses" },
  { value: "running", label: "Running" },
  { value: "paused", label: "Paused" },
  { value: "completed", label: "Completed" },
  { value: "failed", label: "Failed" },
  { value: "cancelled", label: "Cancelled" },
];

/** Runs with their counters and the live event log; scoped to one pipeline when a pipeline id is given. */
export function RunHistory({ pipelineId = null }: { pipelineId?: string | null }) {
  const [statusFilter, setStatusFilter] = useState<RunStatus | "all">("all");
  const runs = useRuns({ status: statusFilter === "all" ? null : statusFilter, pipeline_id: pipelineId, limit: 25 });
  const pipelines = usePipelines();
  const [selectedRun, setSelectedRun] = useState<IngestionRunOut | null>(null);
  const stream = useRunEventStream({ maxEvents: 500 });
  const names = useMemo(() => Object.fromEntries((pipelines.data ?? []).map((p) => [p.id, p.name])), [pipelines.data]);
  // Keep the selected run fresh from the polled list.
  const selected = useMemo(() => runs.data?.items.find((r) => r.id === selectedRun?.id) ?? selectedRun, [runs.data, selectedRun]);

  const scoped = pipelineId !== null;
  const items = runs.data?.items ?? [];
  const pick = (r: IngestionRunOut) => setSelectedRun(selected?.id === r.id ? null : r);
  return (
    <div className="space-y-6">
      {items.length ? (
        <section className="space-y-3">
          <RunKpis runs={items} total={runs.data?.total ?? items.length} />
          <RunTimeline runs={items} selectedId={selected?.id ?? null} onSelect={pick} />
        </section>
      ) : null}
      <section className={scoped ? "grid grid-cols-1 gap-6" : "grid grid-cols-1 gap-6 xl:grid-cols-[minmax(0,1fr)_23rem]"}>
        <Card className="min-w-0">
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <div>
              <CardTitle>Runs</CardTitle>
              <CardDescription>{runs.data ? `${formatInt(runs.data.total)} total · click a row to follow its events` : "loading…"}</CardDescription>
            </div>
            <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as RunStatus | "all")}>
              <SelectTrigger className="h-8 w-40 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {STATUS_FILTERS.map((f) => (
                  <SelectItem key={f.value} value={f.value}>
                    {f.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardHeader>
          <CardContent className="p-0">
            {runs.isError ? (
              <div className="p-4 text-sm text-destructive">{describeError(runs.error)}</div>
            ) : (
              <RunTable
                runs={runs.data?.items}
                loading={runs.isLoading}
                selectedId={selected?.id ?? null}
                onSelect={pick}
                pipelineNames={names}
                showPipeline={!scoped}
              />
            )}
          </CardContent>
        </Card>
        <Card className="xl:sticky xl:top-4 xl:self-start">
          <CardHeader>
            <CardTitle>Run details</CardTitle>
            <CardDescription>{selected ? "What this run did, stage by stage." : "Pick a run in the table or the timeline."}</CardDescription>
          </CardHeader>
          <CardContent>
            {selected ? (
              <RunDetails run={selected} pipelineName={selected.pipeline_id ? names[selected.pipeline_id] : undefined} />
            ) : (
              <div className="flex flex-col items-center rounded-2xl border border-dashed px-4 py-10 text-center text-sm text-muted-foreground">
                <span className="mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-muted">
                  <MousePointerClick className="h-5 w-5" />
                </span>
                Select a run to see its stages, documents, scope and options.
              </div>
            )}
          </CardContent>
        </Card>
      </section>
      <section>
        <h2 className="mb-3 inline-flex items-center gap-2 text-sm font-medium text-muted-foreground">
          <Radio className="h-4 w-4 text-primary" /> Live events
        </h2>
        <RunEventLog events={stream.events} state={stream.state} runId={selected?.id ?? null} onClear={stream.clear} />
      </section>
    </div>
  );
}
