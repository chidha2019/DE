import { CalendarClock, Hand, Repeat, Sun } from "lucide-react";

import type { Schedule, ScheduleType } from "@/api/types";
import { Field, SectionCard, StepIntro, ToggleRow } from "@/components/pipelines/form-bits";
import { MANUAL } from "@/components/pipelines/pipeline-form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DAY_NAMES } from "@/lib/pipelines";
import { describeSchedule, formatUntil, nextRuns, validateSchedule } from "@/lib/schedule";
import { cn } from "@/lib/utils";

const INTERVALS: Array<[number, string]> = [
  [15, "Every 15 minutes"],
  [30, "Every 30 minutes"],
  [60, "Every hour"],
  [180, "Every 3 hours"],
  [360, "Every 6 hours"],
  [720, "Every 12 hours"],
  [1440, "Every day"],
  [2880, "Every 2 days"],
  [10080, "Every week"],
];

const KINDS: Array<{ type: ScheduleType; label: string; hint: string; icon: typeof Hand }> = [
  { type: "manual", label: "On demand", hint: "Run it yourself from the list.", icon: Hand },
  { type: "interval", label: "Repeat", hint: "Every few minutes or hours.", icon: Repeat },
  { type: "daily", label: "Daily", hint: "At a set time each day.", icon: Sun },
  { type: "weekly", label: "Weekly", hint: "On chosen days at a set time.", icon: CalendarClock },
];

const defaults = (type: ScheduleType, previous: Schedule): Schedule => {
  if (type === "manual") return MANUAL;
  if (type === "interval") return { type, every_minutes: previous.every_minutes ?? 360, time: null, days: [] };
  if (type === "daily") return { type, every_minutes: null, time: previous.time ?? "02:00", days: [] };
  return { type, every_minutes: null, time: previous.time ?? "06:00", days: previous.days.length ? previous.days : [0, 1, 2, 3, 4] };
};

interface ScheduleStepProps {
  schedule: Schedule;
  enabled: boolean;
  runNow: boolean;
  editing: boolean;
  onSchedule: (schedule: Schedule) => void;
  onEnabled: (enabled: boolean) => void;
  onRunNow: (runNow: boolean) => void;
}

function DayPicker({ schedule, onSchedule }: { schedule: Schedule; onSchedule: (s: Schedule) => void }) {
  return (
    <Field label="Days">
      <div className="flex flex-wrap gap-1" role="group" aria-label="Days of the week">
        {DAY_NAMES.map((name, day) => {
          const on = schedule.days.includes(day);
          return (
            <button
              key={name}
              type="button"
              aria-pressed={on}
              onClick={() => onSchedule({ ...schedule, days: on ? schedule.days.filter((d) => d !== day) : [...schedule.days, day].sort() })}
              className={cn("h-8 w-11 rounded-lg border text-xs transition-colors", on ? "border-primary bg-primary/15 text-foreground" : "border-border/70 text-muted-foreground hover:text-foreground")}
            >
              {name}
            </button>
          );
        })}
      </div>
    </Field>
  );
}

/** Step 4: run on demand or on a schedule. Times are UTC and the next runs are shown in your local time. */
export function ScheduleStep({ schedule, enabled, runNow, editing, onSchedule, onEnabled, onRunNow }: ScheduleStepProps) {
  const problem = validateSchedule(schedule);
  const upcoming = enabled ? nextRuns(schedule, 3) : [];
  const known = INTERVALS.some(([m]) => m === schedule.every_minutes);
  const presets: Array<[number, string]> = known || !schedule.every_minutes ? INTERVALS : [...INTERVALS, [schedule.every_minutes, describeSchedule(schedule)]];
  return (
    <div className="space-y-4">
      <StepIntro title="When should it run?" lead="A scheduled pipeline starts by itself; if its connection is busy it tries again a minute later. You can always run it by hand." />
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4" role="radiogroup" aria-label="Schedule type">
        {KINDS.map((k) => (
          <button
            key={k.type}
            type="button"
            role="radio"
            aria-checked={schedule.type === k.type}
            onClick={() => onSchedule(defaults(k.type, schedule))}
            className={cn("surface flex items-start gap-3 p-3 text-left transition-all", schedule.type === k.type ? "border-primary/60 bg-primary/10 shadow-glow" : "hover:border-primary/40")}
          >
            <span className={cn("flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border transition-all", schedule.type === k.type ? "border-primary/60 bg-gradient-to-br from-primary to-primary/70 text-primary-foreground shadow-[0_8px_20px_-10px_hsl(var(--primary))]" : "border-primary/20 bg-primary/10 text-primary")}>
              <k.icon className="h-4 w-4" />
            </span>
            <span>
              <span className="block text-sm font-medium">{k.label}</span>
              <span className="block text-xs text-muted-foreground">{k.hint}</span>
            </span>
          </button>
        ))}
      </div>
      {schedule.type !== "manual" ? (
        <SectionCard icon={CalendarClock} title="Timing" hint="Times are UTC; the next runs show in your local time" tone="262 70% 60%">
          {schedule.type === "interval" ? (
            <Field label="Repeat" hint="Counted from each start, not aligned to the clock.">
              <Select value={String(schedule.every_minutes ?? 360)} onValueChange={(v) => onSchedule({ ...schedule, every_minutes: Number(v) })}>
                <SelectTrigger className="h-9 w-60">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {presets.map(([minutes, label]) => (
                    <SelectItem key={minutes} value={String(minutes)}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
          ) : (
            <div className="flex flex-wrap items-end gap-6">
              {schedule.type === "weekly" ? <DayPicker schedule={schedule} onSchedule={onSchedule} /> : null}
              <Field label="Time (UTC)" htmlFor="schedule-time">
                <Input id="schedule-time" type="time" value={schedule.time ?? ""} onChange={(e) => onSchedule({ ...schedule, time: e.target.value })} className="h-9 w-36" />
              </Field>
            </div>
          )}
          {problem ? (
            <p className="text-xs text-destructive">{problem}</p>
          ) : (
            <div className="rounded-xl border border-border/70 bg-card/60 p-3">
              <div className="text-sm font-medium">{describeSchedule(schedule)}</div>
              {upcoming.length ? (
                <ol className="relative mt-3 space-y-2.5 border-l-2 border-primary/25 pl-4">
                  {upcoming.map((d, i) => (
                    <li key={d.toISOString()} className="relative text-xs">
                      <span className={cn("absolute -left-[23px] top-0.5 h-3 w-3 rounded-full border-2 border-card", i === 0 ? "bg-primary shadow-[0_0_0_3px_hsl(var(--primary)/0.2)]" : "bg-primary/40")} aria-hidden="true" />
                      <span className="font-medium">{d.toLocaleString(undefined, { weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}</span>
                      <span className="ml-2 text-muted-foreground">{formatUntil(d)}</span>
                    </li>
                  ))}
                </ol>
              ) : null}
              <p className="mt-1.5 text-[11px] text-muted-foreground">Shown in your local time; the server runs on UTC.</p>
            </div>
          )}
          <ToggleRow id="schedule-enabled" label="Schedule is on" hint="Turn it off to keep the schedule but not run it." checked={enabled} onChange={onEnabled} />
        </SectionCard>
      ) : null}
      {!editing ? <ToggleRow id="run-now" label="Run once right after saving" hint="Starts a first run as soon as the pipeline is created." checked={runNow} onChange={onRunNow} /> : null}
    </div>
  );
}
