import { AlertTriangle, CalendarClock, Clock3, Settings2, Workflow } from "lucide-react";
import { Link } from "react-router-dom";

import type { IngestionRunOut, ScopeItem } from "@/api/types";
import { BrandMark } from "@/components/connectors/brand-mark";
import { ScopeChips } from "@/components/pipelines/pipeline-visuals";
import { OutcomeBar, OutcomeLegend, RUN_STYLE, RunStatusPill, StageFlow, TriggerChip } from "@/components/pipelines/run-visuals";
import { formatDateTime, formatDuration, formatInt, shortId } from "@/lib/format";
import { rgba } from "@/lib/tones";

function Label({ children }: { children: string }) {
  return <div className="mb-1.5 text-[10px] font-medium uppercase tracking-[0.18em] text-muted-foreground">{children}</div>;
}

/** One run: who started it and how it ended, what it did stage by stage, what it read and with which options. */
export function RunDetails({ run, pipelineName }: { run: IngestionRunOut; pipelineName?: string }) {
  const { scope: rawScope, source_options: sourceOptions, ...options } = run.config as Record<string, unknown>;
  const scope = (rawScope as ScopeItem[] | undefined) ?? [];
  const shown = Object.entries({ ...options, ...(sourceOptions as object | undefined) }).filter(
    ([, v]) => v !== false && v !== null && v !== undefined && v !== "",
  );
  const tone = RUN_STYLE[run.status].color;
  const s = run.stats;
  return (
    <div className="space-y-4 text-sm">
      <div
        className="relative overflow-hidden rounded-2xl border p-3"
        style={{ borderColor: rgba(tone, 0.3), background: `linear-gradient(120deg, ${rgba(tone, 0.1)}, transparent 65%)` }}
      >
        <div className="flex items-start gap-3">
          <BrandMark icon={run.source_system} size="md" />
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="truncate font-medium">{run.connector_name}</span>
              <RunStatusPill status={run.status} />
            </div>
            <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-muted-foreground">
              <span className="font-mono">{shortId(run.id)}</span>
              <TriggerChip by={run.triggered_by} />
              {run.duration_seconds != null ? (
                <span className="inline-flex items-center gap-1">
                  <Clock3 className="h-3 w-3" /> {formatDuration(run.duration_seconds)}
                </span>
              ) : null}
            </div>
          </div>
        </div>
        <div className="mt-2.5 flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-muted-foreground">
          <span className="inline-flex items-center gap-1">
            <CalendarClock className="h-3 w-3" /> started {formatDateTime(run.started_at ?? run.created_at)}
          </span>
          {run.finished_at ? <span>finished {formatDateTime(run.finished_at)}</span> : null}
          {run.pipeline_id ? (
            <Link to={`/pipelines/${run.pipeline_id}`} className="inline-flex items-center gap-1 font-medium text-primary hover:underline">
              <Workflow className="h-3 w-3" /> {pipelineName ?? "deleted pipeline"}
            </Link>
          ) : (
            <span>ad hoc run, no saved pipeline</span>
          )}
        </div>
      </div>

      <div>
        <Label>What it did</Label>
        <StageFlow stats={s} />
      </div>

      <div>
        <Label>Documents</Label>
        <OutcomeBar stats={s} className="h-2.5" />
        <div className="mt-1.5 flex flex-wrap items-center justify-between gap-2">
          <OutcomeLegend stats={s} />
          <span className="text-[11px] tabular-nums text-muted-foreground">
            {formatInt(s.documents_seen)} seen{s.estimated_total !== null ? ` of ${formatInt(s.estimated_total)} expected` : ""}
          </span>
        </div>
        {s.graph_failed > 0 ? (
          <p className="mt-1.5 inline-flex items-center gap-1 text-[11px] text-warning">
            <AlertTriangle className="h-3 w-3" /> {formatInt(s.graph_failed)} document(s) did not reach the graph; Reconcile graph retries them
          </p>
        ) : null}
      </div>

      <div>
        <Label>Scope</Label>
        {scope.length === 0 ? <p className="text-xs text-muted-foreground">Everything the connection exposes</p> : <ScopeChips scope={scope} max={8} />}
      </div>

      {shown.length ? (
        <div>
          <Label>Options</Label>
          <div className="flex flex-wrap gap-1.5">
            {shown.map(([k, v]) => (
              <span key={k} className="inline-flex items-center gap-1 rounded-md border border-border/70 bg-muted/40 px-1.5 py-0.5 text-[11px]">
                <Settings2 className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">{k.replace(/_/g, " ")}</span>
                {v !== true ? <span className="max-w-[10rem] truncate font-mono">{typeof v === "object" ? JSON.stringify(v) : String(v)}</span> : null}
              </span>
            ))}
          </div>
        </div>
      ) : null}

      {run.error ? (
        <div className="flex items-start gap-2 rounded-xl border border-destructive/40 bg-destructive/5 p-2.5 text-xs text-destructive">
          <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
          <span className="whitespace-pre-wrap">{run.error}</span>
        </div>
      ) : null}
    </div>
  );
}
