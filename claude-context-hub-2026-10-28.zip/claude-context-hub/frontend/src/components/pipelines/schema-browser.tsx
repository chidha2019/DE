import { Check, ChevronRight, ChevronsDownUp, Loader2, Minus, RefreshCw, Search } from "lucide-react";
import { useState } from "react";

import type { ConnectorInfo, DiscoveryNode, ScopeItem } from "@/api/types";
import { KindTile, TonePill, kindStyle, typeFamily } from "@/components/pipelines/kind-visuals";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { useDiscover } from "@/hooks/queries";
import { describeError } from "@/lib/api-client";
import { formatCompact, formatInt } from "@/lib/format";
import { checkState, pathKey, toggleScope, type CheckState } from "@/lib/pipelines";
import { cn } from "@/lib/utils";

const INDENT = 20;
const FILTER_FROM = 12;
const indent = (depth: number) => 8 + depth * INDENT;
const countLabel = (n: number, word: string) => `${formatInt(n)} ${n === 1 ? word : word.endsWith("y") ? `${word.slice(0, -1)}ies` : `${word}s`}`;

/** A checkbox with a partial state: something below the node is selected. */
export function TriCheckbox({ state, disabled, label, onClick }: { state: CheckState; disabled?: boolean; label: string; onClick: () => void }) {
  const on = state === "checked" || state === "inherited";
  return (
    <button
      type="button"
      role="checkbox"
      aria-checked={state === "partial" ? "mixed" : on}
      aria-label={label}
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-[5px] border-2 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
        on || state === "partial" ? "border-primary bg-primary text-primary-foreground shadow-[0_0_0_3px_hsl(var(--primary)/0.15)]" : "border-muted-foreground/40 bg-card hover:border-primary/70",
        state === "inherited" && "opacity-55 shadow-none",
        disabled && "cursor-not-allowed",
      )}
    >
      {state === "partial" ? <Minus className="h-3 w-3" strokeWidth={3} /> : on ? <Check className="h-3 w-3" strokeWidth={3} /> : null}
    </button>
  );
}

interface TreeContext {
  connector: ConnectorInfo;
  scope: ScopeItem[];
  onChange: (next: ScopeItem[]) => void;
  expanded: Set<string>;
  toggleExpanded: (key: string) => void;
}

/** One column of a table: the schema preview under an opened table. */
function ColumnRow({ node, depth }: { node: DiscoveryNode; depth: number }) {
  const notNull = node.detail.endsWith(" not null");
  const dataType = notNull ? node.detail.slice(0, -" not null".length) : node.detail;
  const family = typeFamily(dataType);
  return (
    <li className="flex min-h-7 items-center gap-2 rounded-md pr-2 text-xs hover:bg-muted/40" style={{ paddingLeft: indent(depth) + 38 }} title={node.description || undefined}>
      <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded" style={{ background: `hsl(${family.color} / 0.14)`, color: `hsl(${family.color})` }} aria-hidden="true">
        <family.icon className="h-3 w-3" />
      </span>
      <span className="min-w-0 truncate font-mono text-[11.5px] text-foreground/85">{node.name}</span>
      <span className="ml-auto flex shrink-0 items-center gap-1.5">
        {notNull ? <span className="hidden rounded border border-border/70 px-1 text-[9px] font-medium uppercase tracking-wide text-muted-foreground sm:inline">not null</span> : null}
        <TonePill color={family.color} className="font-mono">
          {dataType || "?"}
        </TonePill>
      </span>
    </li>
  );
}

function RowMeter({ value, max }: { value: number; max: number }) {
  const pct = max > 0 ? Math.max(4, Math.round((value / max) * 100)) : 0;
  return (
    <span className="hidden items-center gap-1.5 sm:flex" title={`${formatInt(value)} rows`}>
      <span className="h-1.5 w-14 overflow-hidden rounded-full bg-muted">
        <span className="block h-full rounded-full bg-gradient-to-r from-primary/60 to-primary" style={{ width: `${pct}%` }} />
      </span>
      <span className="w-14 text-right font-mono text-[10.5px] tabular-nums text-muted-foreground">{formatCompact(value)} rows</span>
    </span>
  );
}

function NodeRow({ node, depth, ctx, maxRows }: { node: DiscoveryNode; depth: number; ctx: TreeContext; maxRows: number }) {
  const key = pathKey(node.path);
  const open = ctx.expanded.has(key);
  const state = checkState(node.path, ctx.scope);
  const style = kindStyle(node.kind);
  const level = ctx.connector.scope_levels[node.path.length - 1] ?? style.label;
  const childLevel = ctx.connector.scope_levels[node.path.length]?.toLowerCase();
  const count = node.child_count != null && node.kind !== "folder" && node.kind !== "alerts" ? countLabel(node.child_count, node.kind === "repo" ? "file" : (childLevel ?? "item")) : null;
  return (
    <li>
      <div
        className={cn(
          "group relative flex min-h-9 items-center gap-2 rounded-lg pr-2 text-sm transition-colors hover:bg-muted/60",
          state === "checked" && "bg-primary/10 ring-1 ring-inset ring-primary/25 hover:bg-primary/15",
          state === "inherited" && "bg-primary/[0.04]",
        )}
        style={{ paddingLeft: indent(depth) }}
      >
        {state === "checked" ? <span className="absolute inset-y-1.5 left-0 w-1 rounded-r-full bg-primary" aria-hidden="true" /> : null}
        {node.expandable ? (
          <button type="button" onClick={() => ctx.toggleExpanded(key)} aria-label={open ? `Collapse ${node.name}` : `Expand ${node.name}`} aria-expanded={open} className="flex h-6 w-5 shrink-0 items-center justify-center rounded text-muted-foreground hover:bg-muted hover:text-foreground">
            <ChevronRight className={cn("h-4 w-4 transition-transform duration-150", open && "rotate-90")} />
          </button>
        ) : (
          <span className="w-5 shrink-0" />
        )}
        {node.selectable ? (
          <TriCheckbox
            state={state}
            disabled={state === "inherited"}
            label={state === "inherited" ? `${node.name} is included by a selection above it` : `Select ${level.toLowerCase()} ${node.name}`}
            onClick={() => ctx.onChange(toggleScope(ctx.scope, { path: node.path, kind: node.kind }))}
          />
        ) : (
          <span className="w-[18px] shrink-0" />
        )}
        <KindTile kind={node.kind} size="sm" />
        <span className="flex min-w-0 flex-1 items-center gap-2">
          <span className={cn("truncate", state === "checked" ? "font-medium" : "font-normal")} title={node.description || node.name}>
            {node.label ?? node.name}
          </span>
          {node.detail ? <span className="hidden shrink-0 rounded-full border border-border/70 px-1.5 py-px text-[10px] text-muted-foreground md:inline">{node.detail}</span> : null}
          {node.description ? <span className="hidden min-w-0 truncate text-[11px] text-muted-foreground 2xl:inline">{node.description}</span> : null}
        </span>
        <span className="ml-auto flex shrink-0 items-center gap-2">
          {node.row_count != null ? <RowMeter value={node.row_count} max={maxRows} /> : null}
          {count ? <TonePill color={kindStyle(childLevel === "table" ? "table" : node.kind).color}>{count}</TonePill> : null}
        </span>
      </div>
      {open ? <Children path={node.path} depth={depth + 1} ctx={ctx} /> : null}
    </li>
  );
}

function Children({ path, depth, ctx }: { path: string[]; depth: number; ctx: TreeContext }) {
  const query = useDiscover(ctx.connector.name, path);
  const [filter, setFilter] = useState("");
  const pad = { paddingLeft: indent(depth) + 4 };
  const guide = depth > 0 ? <span className="pointer-events-none absolute bottom-2 top-0 w-px bg-gradient-to-b from-border to-transparent" style={{ left: indent(depth - 1) + 10 }} aria-hidden="true" /> : null;
  if (query.isLoading) {
    return (
      <div className="relative space-y-2 py-2" style={pad}>
        {guide}
        {[0, 1, 2].map((i) => (
          <div key={i} className="flex items-center gap-2">
            <Skeleton className="h-6 w-6 rounded-md" />
            <Skeleton className="h-4" style={{ width: `${55 - i * 12}%` }} />
          </div>
        ))}
      </div>
    );
  }
  if (query.isError) {
    return (
      <div className="flex items-center gap-2 rounded-lg bg-destructive/10 py-2 pr-2 text-xs text-destructive" style={pad}>
        <span className="min-w-0 flex-1 truncate" title={describeError(query.error)}>
          {describeError(query.error)}
        </span>
        <Button size="sm" variant="outline" className="h-6 px-2 text-[11px]" onClick={() => void query.refetch()}>
          Retry
        </Button>
      </div>
    );
  }
  const everything = query.data?.nodes ?? [];
  const needle = filter.trim().toLowerCase();
  const nodes = everything.filter((n) => !needle || n.name.toLowerCase().includes(needle) || (n.label ?? "").toLowerCase().includes(needle));
  const maxRows = Math.max(0, ...everything.map((n) => n.row_count ?? 0));
  const columns = nodes.length > 0 && nodes.every((n) => n.kind === "column");
  return (
    <div className="relative">
      {guide}
      {everything.length > FILTER_FROM ? (
        <div className="relative py-1 pr-2" style={pad}>
          <Search className="pointer-events-none absolute top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" style={{ left: indent(depth) + 14 }} />
          <Input value={filter} onChange={(e) => setFilter(e.target.value)} placeholder={`Filter ${formatInt(everything.length)} items here…`} className="h-8 rounded-lg pl-8 text-xs" aria-label="Filter this level" />
        </div>
      ) : null}
      {nodes.length === 0 ? (
        <p className="py-2 text-xs text-muted-foreground" style={pad}>
          {needle ? "Nothing at this level matches the filter." : "Nothing here."}
        </p>
      ) : columns ? (
        <ul className="my-0.5 rounded-lg border border-dashed border-border/70 bg-muted/20 py-1" style={{ marginLeft: indent(depth) - 4, marginRight: 8 }}>
          {nodes.map((node) => (
            <ColumnRow key={pathKey(node.path)} node={node} depth={0} />
          ))}
        </ul>
      ) : (
        <ul className="space-y-0.5">
          {nodes.map((node) => (
            <NodeRow key={pathKey(node.path)} node={node} depth={depth} ctx={ctx} maxRows={maxRows} />
          ))}
        </ul>
      )}
      {query.data?.truncated ? (
        <p className="py-1 text-[11px] text-warning" style={pad}>
          Only the first {formatInt(query.data.nodes.length)} items are listed. Tick the parent to include all of them.
        </p>
      ) : null}
    </div>
  );
}

interface SchemaBrowserProps {
  connector: ConnectorInfo;
  scope: ScopeItem[];
  onChange: (next: ScopeItem[]) => void;
  className?: string;
}

/** The live schema of a connection as a tree: open levels, tick what the pipeline should ingest. */
export function SchemaBrowser({ connector, scope, onChange, className }: SchemaBrowserProps) {
  // Editing a pipeline: open the levels above everything already selected so the ticks are visible.
  const [expanded, setExpanded] = useState<Set<string>>(() => new Set(scope.flatMap((item) => item.path.slice(0, -1).map((_, i) => pathKey(item.path.slice(0, i + 1))))));
  const root = useDiscover(connector.name, []);
  const toggleExpanded = (key: string) =>
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  const ctx: TreeContext = { connector, scope, onChange, expanded, toggleExpanded };
  return (
    <section className={cn("surface flex min-h-0 flex-col overflow-hidden", className)}>
      <header className="flex flex-wrap items-center gap-3 border-b border-border/70 bg-gradient-to-r from-primary/[0.07] to-transparent px-4 py-3">
        <span className="relative flex h-2.5 w-2.5" aria-hidden="true">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-success opacity-60" />
          <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-success" />
        </span>
        <div className="min-w-0 flex-1">
          <h3 className="text-sm font-medium">Live schema</h3>
          <p className="truncate text-[11px] text-muted-foreground">Read from {connector.display_name} as you open each level · tables open to their columns</p>
        </div>
        <div className="flex items-center gap-1.5">
          <Button variant="ghost" size="sm" className="h-8 gap-1.5 px-2.5 text-xs" onClick={() => setExpanded(new Set())} disabled={expanded.size === 0}>
            <ChevronsDownUp className="h-3.5 w-3.5" /> <span className="hidden sm:inline">Collapse</span>
          </Button>
          <Button variant="ghost" size="sm" className="h-8 gap-1.5 px-2.5 text-xs" onClick={() => void root.refetch()} disabled={root.isFetching} title="Read the top level from the connection again">
            {root.isFetching ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />} <span className="hidden sm:inline">Refresh</span>
          </Button>
        </div>
      </header>
      <div className="scrollbar-hidden min-h-0 flex-1 overflow-auto p-2">
        <Children path={[]} depth={0} ctx={ctx} />
      </div>
    </section>
  );
}
