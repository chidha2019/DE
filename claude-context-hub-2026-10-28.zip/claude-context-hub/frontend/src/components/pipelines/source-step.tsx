import { ChevronRight, Files, Loader2, ScanSearch, X } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

import { pipelinesApi } from "@/api/endpoints";
import type { ConnectorInfo, PreviewResult, ScopeItem } from "@/api/types";
import { KindTile, levelStyle } from "@/components/pipelines/kind-visuals";
import { runOptions, sourceOptions, type PipelineDraft } from "@/components/pipelines/pipeline-form";
import { ConnectionTile, connectionStyle } from "@/components/pipelines/pipeline-visuals";
import { SchemaBrowser } from "@/components/pipelines/schema-browser";
import { Button } from "@/components/ui/button";
import { describeError } from "@/lib/api-client";
import { formatInt } from "@/lib/format";
import { pathKey, pathLabel, scopeSummary } from "@/lib/pipelines";
import { cn } from "@/lib/utils";

interface Estimate {
  loading: boolean;
  data?: PreviewResult;
  error?: string;
}

/** How many documents the current selection would read, asked of the connection (debounced). */
export function useScopeEstimate(connector: string, draft: PipelineDraft): Estimate {
  const [estimate, setEstimate] = useState<Estimate>({ loading: true });
  const key = useMemo(
    () => JSON.stringify([connector, draft.scope.map((s) => pathKey(s.path)), draft.limit, draft.includeLineage, draft.includeTags, draft.includeAlertRules, draft.extensions, draft.excludeGlobs]),
    [connector, draft.scope, draft.limit, draft.includeLineage, draft.includeTags, draft.includeAlertRules, draft.extensions, draft.excludeGlobs],
  );
  useEffect(() => {
    let cancelled = false;
    setEstimate((s) => ({ ...s, loading: true, error: undefined }));
    const timer = window.setTimeout(() => {
      pipelinesApi
        .preview({ connector, scope: draft.scope, options: runOptions(draft), source_options: sourceOptions(draft) })
        .then((data) => !cancelled && setEstimate({ loading: false, data }))
        .catch((error: unknown) => !cancelled && setEstimate({ loading: false, error: describeError(error) }));
    }, 500);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
    // The key stands for every field the estimate depends on.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
  return estimate;
}

/** The documents a run would read, with its share of what the connection reads by default. */
export function EstimateCard({ estimate, scope, total }: { estimate: Estimate; scope: ScopeItem[]; total?: number | null }) {
  const n = estimate.data?.estimated_documents;
  const warning = estimate.error ?? estimate.data?.note;
  const share = scope.length > 0 && total && n != null && n <= total ? n / total : null;
  return (
    <section className="surface relative overflow-hidden p-4">
      <div className="pointer-events-none absolute -right-12 -top-12 h-36 w-36 rounded-full bg-primary/20 blur-3xl" aria-hidden="true" />
      <div className="relative flex items-start gap-3">
        <span className="icon-tile h-11 w-11 shrink-0">
          <Files className="h-5 w-5" />
        </span>
        <div className="min-w-0">
          <div className="text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">Each run reads about</div>
          <div className="mt-0.5 flex items-baseline gap-2">
            <span className={cn("font-display text-4xl font-medium tabular-nums tracking-tight transition-opacity", estimate.loading && "opacity-40")}>{n === null || n === undefined ? "–" : formatInt(n)}</span>
            <span className="text-sm text-muted-foreground">documents</span>
            {estimate.loading ? <Loader2 className="h-4 w-4 animate-spin self-center text-primary" /> : null}
          </div>
        </div>
      </div>
      {share !== null ? (
        <div className="relative mt-3">
          <div className="h-2 overflow-hidden rounded-full bg-muted">
            <div className="h-full rounded-full bg-gradient-to-r from-primary/70 to-primary transition-all duration-500" style={{ width: `${Math.max(2, Math.round(share * 100))}%` }} />
          </div>
          <div className="mt-1 flex justify-between text-[11px] text-muted-foreground">
            <span>{Math.round(share * 100)}% of the default scan</span>
            <span className="tabular-nums">{formatInt(total)} by default</span>
          </div>
        </div>
      ) : null}
      <p className="relative mt-2 text-[11px] text-muted-foreground">{scope.length === 0 ? "Nothing ticked: the pipeline reads everything this connection exposes." : "Counted by the connection for exactly this selection."}</p>
      {warning ? <p className="relative mt-1 text-[11px] text-warning">{warning}</p> : null}
    </section>
  );
}

/** The ticked paths grouped by level, each removable, with an empty state that explains the default. */
function SelectionBasket({ scope, levels, onScope }: { scope: ScopeItem[]; levels: string[]; onScope: (scope: ScopeItem[]) => void }) {
  const groups = levels.map((level, i) => ({ level, items: scope.filter((s) => s.path.length === i + 1 && s.kind !== "alerts") }));
  const alerts = scope.filter((s) => s.kind === "alerts");
  const remove = (item: ScopeItem) => onScope(scope.filter((s) => pathKey(s.path) !== pathKey(item.path)));
  return (
    <section className="surface flex min-h-0 flex-col p-4">
      <div className="flex items-center justify-between gap-2">
        <div>
          <h3 className="text-sm font-medium">Selected</h3>
          <p className="text-[11px] text-muted-foreground">{scopeSummary(scope, levels)}</p>
        </div>
        {scope.length ? (
          <Button variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={() => onScope([])}>
            Clear all
          </Button>
        ) : null}
      </div>
      {scope.length === 0 ? (
        <div className="mt-3 flex flex-col items-center rounded-xl border border-dashed border-border/80 px-4 py-6 text-center">
          <span className="flex h-11 w-11 items-center justify-center rounded-full bg-primary/10 text-primary">
            <ScanSearch className="h-5 w-5" />
          </span>
          <p className="mt-2 text-sm font-medium">Nothing ticked yet</p>
          <p className="mt-0.5 text-xs text-muted-foreground">The pipeline reads the whole connection. Tick a level in the schema to narrow it.</p>
        </div>
      ) : (
        <div className="scrollbar-hidden mt-3 max-h-[22rem] space-y-3 overflow-auto">
          {[...groups, { level: "Alert rules", items: alerts }]
            .filter((g) => g.items.length)
            .map((g) => {
              const style = g.level === "Alert rules" ? undefined : levelStyle(g.level);
              return (
                <div key={g.level}>
                  <div className="mb-1 flex items-center gap-1.5 text-[10px] font-medium uppercase tracking-[0.16em] text-muted-foreground">
                    <KindTile style={style} kind={style ? undefined : "alerts"} size="xs" />
                    {g.level} · {g.items.length}
                  </div>
                  <ul className="space-y-1">
                    {g.items.map((item) => (
                      <li key={pathKey(item.path)} className="group flex items-center gap-2 rounded-lg border border-border/60 bg-card/70 px-2.5 py-1.5 text-xs transition-colors hover:border-primary/40">
                        <span className="min-w-0 flex-1 truncate font-mono" title={pathLabel(item.path)}>
                          {item.path.length > 1 ? <span className="text-muted-foreground">{pathLabel(item.path.slice(0, -1))} › </span> : null}
                          <span className="font-medium">{pathLabel(item.path.slice(-1))}</span>
                        </span>
                        <button type="button" aria-label={`Remove ${pathLabel(item.path)}`} className="rounded p-0.5 text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive" onClick={() => remove(item)}>
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
        </div>
      )}
    </section>
  );
}

/** The connection, its hierarchy and what is ticked at each level. */
function SourceBanner({ connector, scope }: { connector: ConnectorInfo; scope: ScopeItem[] }) {
  const { color } = connectionStyle(connector.source_system);
  const lead = connector.discoverable
    ? `Browse the live ${connector.display_name} schema and tick what this pipeline ingests. A ticked level brings everything below it; nothing ticked reads the whole connection.`
    : `${connector.display_name} has no browsable schema, so the pipeline reads everything it exposes.`;
  return (
    <section className="surface relative overflow-hidden p-4 sm:p-5">
      <div className="pointer-events-none absolute inset-0" style={{ background: `radial-gradient(120% 160% at 0% 0%, hsl(${color} / 0.16), transparent 60%)` }} aria-hidden="true" />
      <div className="hero-grid pointer-events-none absolute inset-0 opacity-20" aria-hidden="true" />
      <div className="relative flex flex-col gap-4 lg:flex-row lg:items-center">
        <div className="flex min-w-0 flex-1 items-start gap-3 sm:items-center">
          <ConnectionTile system={connector.source_system} className="h-12 w-12" iconClass="h-6 w-6" />
          <div className="min-w-0">
            <h2 className="text-lg font-medium leading-tight sm:text-xl">Choose what to ingest</h2>
            <p className="mt-0.5 max-w-2xl text-sm text-muted-foreground">{lead}</p>
          </div>
        </div>
        {connector.scope_levels.length ? (
          <ol className="flex flex-wrap items-center gap-1.5" aria-label="Levels of the source">
            {connector.scope_levels.map((level, i) => {
              const ticked = scope.filter((s) => s.path.length === i + 1).length;
              return (
                <li key={level} className="flex items-center gap-1.5">
                  {i > 0 ? <ChevronRight className="h-3.5 w-3.5 text-muted-foreground/60" aria-hidden="true" /> : null}
                  <span className={cn("flex items-center gap-2 rounded-xl border bg-card/80 px-2.5 py-1.5 shadow-sm backdrop-blur", ticked ? "border-primary/40" : "border-border/70")}>
                    <KindTile style={levelStyle(level)} size="xs" />
                    <span className="text-xs font-medium">{level}</span>
                    <span className={cn("rounded-md px-1.5 font-mono text-[10px] tabular-nums", ticked ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground")}>{ticked}</span>
                  </span>
                </li>
              );
            })}
          </ol>
        ) : null}
      </div>
    </section>
  );
}

interface SourceStepProps {
  connector: ConnectorInfo;
  draft: PipelineDraft;
  onScope: (scope: ScopeItem[]) => void;
}

/** Step 2: browse the schema of the connection and tick what to ingest. The tree grows with the window. */
export function SourceStep({ connector, draft, onScope }: SourceStepProps) {
  const estimate = useScopeEstimate(connector.name, draft);
  return (
    <div className="flex flex-col gap-4">
      <SourceBanner connector={connector} scope={draft.scope} />
      <div className="grid items-start gap-4 xl:grid-cols-[minmax(0,1fr)_23rem]">
        {connector.discoverable ? (
          <SchemaBrowser connector={connector} scope={draft.scope} onChange={onScope} className="h-[clamp(22rem,calc(100vh_-_32rem),64rem)]" />
        ) : (
          <div className="surface flex h-64 items-center justify-center p-8 text-center text-sm text-muted-foreground">Nothing to pick on this connection.</div>
        )}
        <div className="grid gap-4 md:grid-cols-2 xl:sticky xl:top-0 xl:grid-cols-1">
          <EstimateCard estimate={estimate} scope={draft.scope} total={connector.estimated_documents} />
          <SelectionBasket scope={draft.scope} levels={connector.scope_levels} onScope={onScope} />
        </div>
      </div>
    </div>
  );
}
