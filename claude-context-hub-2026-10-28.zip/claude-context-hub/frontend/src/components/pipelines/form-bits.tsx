import type { LucideIcon } from "lucide-react";
import type { ReactNode } from "react";

import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";

/** A label, the control and a line of help below it. */
export function Field({ label, hint, htmlFor, className, children }: { label: string; hint?: ReactNode; htmlFor?: string; className?: string; children: ReactNode }) {
  return (
    <div className={cn("space-y-1.5", className)}>
      <Label htmlFor={htmlFor} className="text-xs">
        {label}
      </Label>
      {children}
      {hint ? <p className="text-[11px] leading-snug text-muted-foreground">{hint}</p> : null}
    </div>
  );
}

/** A switch with its explanation, as a bordered row. */
export function ToggleRow({ id, label, hint, checked, onChange, disabled }: { id: string; label: string; hint: ReactNode; checked: boolean; onChange: (v: boolean) => void; disabled?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-4 rounded-xl border border-border/70 bg-card/60 p-3">
      <div className="min-w-0">
        <Label htmlFor={id}>{label}</Label>
        <p className="mt-0.5 text-xs text-muted-foreground">{hint}</p>
      </div>
      <Switch id={id} checked={checked} onCheckedChange={onChange} disabled={disabled} />
    </div>
  );
}

/** Server default, on or off: the pipeline only overrides what you set. */
export function TriState({ label, hint, value, onChange }: { label: string; hint: ReactNode; value: boolean | null; onChange: (v: boolean | null) => void }) {
  const options: Array<{ key: string; label: string; value: boolean | null }> = [
    { key: "default", label: "Default", value: null },
    { key: "on", label: "On", value: true },
    { key: "off", label: "Off", value: false },
  ];
  return (
    <div className="flex items-center justify-between gap-4 rounded-xl border border-border/70 bg-card/60 p-3">
      <div className="min-w-0">
        <div className="text-sm font-medium">{label}</div>
        <p className="mt-0.5 text-xs text-muted-foreground">{hint}</p>
      </div>
      <div className="flex shrink-0 rounded-lg border border-border/80 bg-card/60 p-0.5" role="radiogroup" aria-label={label}>
        {options.map((o) => (
          <button
            key={o.key}
            type="button"
            role="radio"
            aria-checked={value === o.value}
            onClick={() => onChange(o.value)}
            className={cn("rounded-md px-2.5 py-1 text-xs transition-colors", value === o.value ? "bg-primary/15 text-foreground shadow-glow" : "text-muted-foreground hover:text-foreground")}
          >
            {o.label}
          </button>
        ))}
      </div>
    </div>
  );
}

/** The title band of a wizard step. */
export function StepIntro({ title, lead, children }: { title: string; lead: ReactNode; children?: ReactNode }) {
  return (
    <section className="surface relative overflow-hidden p-4 sm:p-5">
      <div className="hero-grid pointer-events-none absolute inset-0 opacity-20" aria-hidden="true" />
      <div className="pointer-events-none absolute -right-16 -top-20 h-48 w-48 rounded-full bg-primary/15 blur-3xl" aria-hidden="true" />
      <div className="relative flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="min-w-0">
          <h2 className="text-lg font-medium sm:text-xl">{title}</h2>
          <p className="mt-0.5 max-w-3xl text-sm text-muted-foreground">{lead}</p>
        </div>
        {children}
      </div>
    </section>
  );
}

/** A card with an icon tile in its header, tinted with one hue. */
export function SectionCard({ icon: Icon, title, hint, tone = "172 66% 45%", action, className, children }: { icon: LucideIcon; title: string; hint?: ReactNode; tone?: string; action?: ReactNode; className?: string; children: ReactNode }) {
  return (
    <section className={cn("surface flex flex-col overflow-hidden", className)}>
      <header className="flex items-center gap-3 border-b border-border/60 px-4 py-3" style={{ background: `linear-gradient(90deg, hsl(${tone} / 0.09), transparent 70%)` }}>
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border text-white shadow-sm" style={{ background: `linear-gradient(135deg, hsl(${tone}), hsl(${tone} / 0.68))`, borderColor: `hsl(${tone} / 0.45)` }}>
          <Icon className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <h3 className="text-sm font-medium leading-tight">{title}</h3>
          {hint ? <p className="truncate text-[11px] text-muted-foreground">{hint}</p> : null}
        </div>
        {action}
      </header>
      <div className="flex-1 space-y-3 p-4">{children}</div>
    </section>
  );
}
