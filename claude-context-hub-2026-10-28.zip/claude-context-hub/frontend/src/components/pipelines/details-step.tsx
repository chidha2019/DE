import { FileText, Settings2 } from "lucide-react";

import type { ConnectorInfo } from "@/api/types";
import { Field, SectionCard, StepIntro, ToggleRow, TriState } from "@/components/pipelines/form-bits";
import type { PipelineDraft } from "@/components/pipelines/pipeline-form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useSemanticCatalog } from "@/hooks/queries";

interface DetailsStepProps {
  connector: ConnectorInfo;
  draft: PipelineDraft;
  nameError: string | null;
  onChange: (patch: Partial<PipelineDraft>) => void;
}

const NONE = "__none__";
const SEMANTIC_SOURCES = new Set(["snowflake", "databricks"]);

/** The default line of business: tags on a table win, and tables with neither are read from their data or joins. */
function LineOfBusiness({ value, onChange }: { value: string; onChange: (next: string) => void }) {
  const catalog = useSemanticCatalog();
  const lines = (catalog.data?.lines ?? []).filter((l) => l.key !== "__shared__");
  return (
    <Field label="Line of business" htmlFor="pipeline-lob" hint="Default for tables no Snowflake tag assigns. Without one, each table's line comes from its data or its joins.">
      <Select value={value || NONE} onValueChange={(v) => onChange(v === NONE ? "" : v)}>
        <SelectTrigger id="pipeline-lob" className="text-sm">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value={NONE}>Decide per table</SelectItem>
          {lines.map((l) => (
            <SelectItem key={l.key} value={l.key}>
              {l.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </Field>
  );
}

const LINEAGE_HINT: Record<string, string> = {
  databricks: "Upstream and downstream tables from Unity Catalog lineage.",
  snowflake: "Object dependencies from ACCOUNT_USAGE, when the role can see them.",
};

/** Step 3: the name and details of the pipeline, and how each run behaves. */
export function DetailsStep({ connector, draft, nameError, onChange }: DetailsStepProps) {
  const has = (key: string) => connector.option_keys.includes(key);
  return (
    <div className="space-y-4">
      <StepIntro title="Name it and set the details" lead="The name identifies the pipeline in the list and in run history. The options apply to every run; a run only changes documents whose content changed." />
      <div className="grid gap-4 lg:grid-cols-2">
        <SectionCard icon={FileText} title="About this pipeline" hint="How people find it and who to ask" tone="217 85% 58%">
          <Field label="Name" htmlFor="pipeline-name" hint={nameError ?? "Required. Must be unique."}>
            <Input id="pipeline-name" value={draft.name} onChange={(e) => onChange({ name: e.target.value })} placeholder="Policy metadata nightly" aria-invalid={Boolean(nameError)} className={nameError ? "border-destructive" : undefined} maxLength={80} />
          </Field>
          <Field label="Description" htmlFor="pipeline-description" hint="What it ingests and who relies on it.">
            <Textarea id="pipeline-description" value={draft.description} onChange={(e) => onChange({ description: e.target.value })} rows={3} maxLength={1000} />
          </Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Owner" htmlFor="pipeline-owner" hint="A person or team to ask when it fails.">
              <Input id="pipeline-owner" value={draft.owner} onChange={(e) => onChange({ owner: e.target.value })} placeholder="data-engineering" maxLength={120} />
            </Field>
            <Field label="Tags" htmlFor="pipeline-tags" hint="Comma separated.">
              <Input id="pipeline-tags" value={draft.tags} onChange={(e) => onChange({ tags: e.target.value })} placeholder="core, insurance" />
            </Field>
          </div>
          {SEMANTIC_SOURCES.has(connector.source_system) ? <LineOfBusiness value={draft.lineOfBusiness} onChange={(v) => onChange({ lineOfBusiness: v })} /> : null}
        </SectionCard>
        <SectionCard icon={Settings2} title="How a run behaves" hint="Applied to every run of this pipeline" tone="160 70% 40%">
          <ToggleRow id="full-refresh" label="Full refresh" hint="Re-chunk and re-embed even when the content has not changed." checked={draft.fullRefresh} onChange={(v) => onChange({ fullRefresh: v })} />
          {has("include_lineage") ? <TriState label="Lineage" hint={LINEAGE_HINT[connector.source_system] ?? "Read upstream and downstream objects."} value={draft.includeLineage} onChange={(v) => onChange({ includeLineage: v })} /> : null}
          {has("include_tags") ? <TriState label="Tags" hint="Tag references on tables and columns." value={draft.includeTags} onChange={(v) => onChange({ includeTags: v })} /> : null}
          {has("include_alert_rules") ? <TriState label="Alert rules" hint="Grafana alert rules next to the dashboards." value={draft.includeAlertRules} onChange={(v) => onChange({ includeAlertRules: v })} /> : null}
          {has("include_extensions") ? (
            <Field label="File extensions" htmlFor="extensions" hint="Only these are read. Empty keeps the server defaults.">
              <Input id="extensions" value={draft.extensions} onChange={(e) => onChange({ extensions: e.target.value })} placeholder="md, py, sql, yaml" />
            </Field>
          ) : null}
          {has("exclude_globs") ? (
            <Field label="Skip paths" htmlFor="exclude-globs" hint="Patterns added to the server exclusions.">
              <Input id="exclude-globs" value={draft.excludeGlobs} onChange={(e) => onChange({ excludeGlobs: e.target.value })} placeholder="tests/*, *.lock" />
            </Field>
          ) : null}
          <div className="grid grid-cols-3 gap-3">
            <Field label="Document limit" htmlFor="limit" hint="Empty reads all.">
              <Input id="limit" inputMode="numeric" value={draft.limit} onChange={(e) => onChange({ limit: e.target.value })} placeholder="all" />
            </Field>
            <Field label="Chunk tokens" htmlFor="chunk" hint="Default 320.">
              <Input id="chunk" inputMode="numeric" value={draft.chunkTokens} onChange={(e) => onChange({ chunkTokens: e.target.value })} placeholder="320" />
            </Field>
            <Field label="Overlap" htmlFor="overlap" hint="Default 48.">
              <Input id="overlap" inputMode="numeric" value={draft.overlapTokens} onChange={(e) => onChange({ overlapTokens: e.target.value })} placeholder="48" />
            </Field>
          </div>
        </SectionCard>
      </div>
    </div>
  );
}
