import { Cable, CalendarClock, FileText, Pencil, Settings2, type LucideIcon } from "lucide-react";
import type { ReactNode } from "react";

import type { ConnectorInfo } from "@/api/types";
import { SectionCard, StepIntro } from "@/components/pipelines/form-bits";
import { runOptions, sourceOptions, type PipelineDraft } from "@/components/pipelines/pipeline-form";
import { ConnectionTile, ScopeChips } from "@/components/pipelines/pipeline-visuals";
import { EstimateCard, useScopeEstimate } from "@/components/pipelines/source-step";
import { Button } from "@/components/ui/button";
import { scopeSummary } from "@/lib/pipelines";
import { describeSchedule, formatUntil, nextRuns } from "@/lib/schedule";

function Card({ title, step, icon, tone, onEdit, children }: { title: string; step: number; icon: LucideIcon; tone: string; onEdit: (step: number) => void; children: ReactNode }) {
  return (
    <SectionCard
      icon={icon}
      title={title}
      tone={tone}
      action={
        <Button variant="ghost" size="sm" className="h-7 px-2 text-[11px]" onClick={() => onEdit(step)}>
          <Pencil className="h-3 w-3" /> Edit
        </Button>
      }
    >
      {children}
    </SectionCard>
  );
}

function Row({ k, v }: { k: string; v: ReactNode }) {
  return (
    <div className="flex items-baseline justify-between gap-4 border-b border-border/50 py-1 text-xs last:border-0">
      <dt className="text-muted-foreground">{k}</dt>
      <dd className="min-w-0 truncate text-right font-medium">{v}</dd>
    </div>
  );
}

const onOff = (v: boolean | null | undefined): string => (v === null || v === undefined ? "server default" : v ? "on" : "off");

interface ReviewStepProps {
  connector: ConnectorInfo;
  draft: PipelineDraft;
  editing: boolean;
  onEdit: (step: number) => void;
}

/** Step 5: everything in one place before it is saved. */
export function ReviewStep({ connector, draft, editing, onEdit }: ReviewStepProps) {
  const estimate = useScopeEstimate(connector.name, draft);
  const options = runOptions(draft);
  const source = sourceOptions(draft);
  const next = draft.enabled ? nextRuns(draft.schedule, 1)[0] : undefined;
  return (
    <div className="space-y-4">
      <StepIntro title={editing ? "Review the changes" : "Review and create"} lead={`Nothing runs until you save${draft.runNow ? ", and then one run starts right away" : ""}. Everything here can be changed later.`} />
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Connection and source" step={editing ? 1 : 0} icon={Cable} tone="199 89% 46%" onEdit={onEdit}>
          <div className="flex items-center gap-3">
            <ConnectionTile system={connector.source_system} />
            <div className="min-w-0">
              <div className="truncate font-medium">{connector.display_name}</div>
              <div className="truncate text-xs text-muted-foreground">{scopeSummary(draft.scope, connector.scope_levels)}</div>
            </div>
          </div>
          <ScopeChips scope={draft.scope} max={8} />
          <EstimateCard estimate={estimate} scope={draft.scope} total={connector.estimated_documents} />
        </Card>
        <Card title="Details" step={2} icon={FileText} tone="217 85% 58%" onEdit={onEdit}>
          <dl>
            <Row k="Name" v={draft.name || "–"} />
            <Row k="Description" v={draft.description || "–"} />
            <Row k="Owner" v={draft.owner || "–"} />
            <Row k="Tags" v={draft.tags || "–"} />
          </dl>
        </Card>
        <Card title="How a run behaves" step={2} icon={Settings2} tone="160 70% 40%" onEdit={onEdit}>
          <dl>
            <Row k="Full refresh" v={options.full_refresh ? "yes" : "no"} />
            <Row k="Document limit" v={options.limit ?? "all"} />
            <Row k="Chunk tokens / overlap" v={`${options.chunk_target_tokens ?? "default"} / ${options.chunk_overlap_tokens ?? "default"}`} />
            {connector.option_keys.includes("include_lineage") ? <Row k="Lineage" v={onOff(source.include_lineage)} /> : null}
            {connector.option_keys.includes("include_tags") ? <Row k="Tags" v={onOff(source.include_tags)} /> : null}
            {connector.option_keys.includes("include_alert_rules") ? <Row k="Alert rules" v={onOff(source.include_alert_rules)} /> : null}
            {connector.option_keys.includes("include_extensions") ? <Row k="File extensions" v={source.include_extensions?.join(", ") ?? "server default"} /> : null}
            {connector.option_keys.includes("exclude_globs") ? <Row k="Skipped paths" v={source.exclude_globs?.join(", ") ?? "server default"} /> : null}
          </dl>
        </Card>
        <Card title="Schedule" step={3} icon={CalendarClock} tone="262 70% 60%" onEdit={onEdit}>
          <dl>
            <Row k="Runs" v={describeSchedule(draft.schedule)} />
            <Row k="Schedule" v={draft.schedule.type === "manual" ? "not applicable" : draft.enabled ? "on" : "off"} />
            {next ? <Row k="Next run" v={`${next.toLocaleString(undefined, { weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })} (${formatUntil(next)})`} /> : null}
            {!editing ? <Row k="First run" v={draft.runNow ? "right after saving" : "not yet"} /> : null}
          </dl>
        </Card>
      </div>
    </div>
  );
}
