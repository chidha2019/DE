import { Navigate, createBrowserRouter } from "react-router-dom";

import { AppShell } from "@/components/layout/app-shell";
import { AnalystPage } from "@/pages/analyst-page";
import { ArchitectPage } from "@/pages/architect-page";
import { ConnectorsPage } from "@/pages/connectors-page";
import { EngineerPage } from "@/pages/engineer-page";
import { GeniePage } from "@/pages/genie-page";
import { GlossaryPage } from "@/pages/glossary-page";
import { HomePage } from "@/pages/home-page";
import { IntentsPage } from "@/pages/intents-page";
import { DocumentRedirect, KnowledgeHubPage, RepoGraphRedirect } from "@/pages/knowledge-hub-page";
import { LandingPage } from "@/pages/landing-page";
import { NotFoundPage } from "@/pages/not-found-page";
import { PersonasPage } from "@/pages/personas-page";
import { PipelineDetailPage } from "@/pages/pipeline-detail-page";
import { PipelineWizardPage } from "@/pages/pipeline-wizard-page";
import { PipelinesPage } from "@/pages/pipelines-page";
import { QaPage } from "@/pages/qa-page";
import { SamplePersonaPage } from "@/pages/sample-persona-page";
import { SemanticPage } from "@/pages/semantic-page";
import { SrePage } from "@/pages/sre-page";
import { PERSONA_LIST } from "@/lib/personas";

export const router = createBrowserRouter([
  // The entry page lives outside the shell; every workspace route sits under the shell.
  { path: "/", element: <LandingPage /> },
  {
    path: "/",
    element: <AppShell />,
    children: [
      { path: "home", element: <HomePage /> },
      // The old Overview dashboard: its numbers live on Home and the persona workspaces now.
      { path: "dashboard", element: <Navigate to="/home" replace /> },
      { path: "personas", element: <PersonasPage /> },
      { path: "engineer", element: <EngineerPage /> },
      { path: "engineer/:tab", element: <EngineerPage /> },
      { path: "analyst", element: <AnalystPage /> },
      { path: "analyst/:tab", element: <AnalystPage /> },
      { path: "qa", element: <QaPage /> },
      { path: "qa/:tab", element: <QaPage /> },
      { path: "architect", element: <ArchitectPage /> },
      { path: "architect/:tab", element: <ArchitectPage /> },
      { path: "sre", element: <SrePage /> },
      { path: "sre/:tab", element: <SrePage /> },
      // DevOps, DevSecOps, Data Steward, Data Scientist and Compliance preview with sample data.
      ...PERSONA_LIST.filter((p) => p.preview).flatMap((p) => {
        const path = p.path.slice(1);
        return [
          { path, element: <SamplePersonaPage persona={p.key} /> },
          { path: `${path}/:tab`, element: <SamplePersonaPage persona={p.key} /> },
        ];
      }),
      { path: "genie", element: <GeniePage /> },
      { path: "genie/:conversationId", element: <GeniePage /> },
      { path: "semantic", element: <SemanticPage /> },
      { path: "semantic/:assetId", element: <SemanticPage /> },
      { path: "glossary", element: <GlossaryPage /> },
      { path: "glossary/:tab", element: <GlossaryPage /> },
      { path: "connectors", element: <ConnectorsPage /> },
      { path: "intents", element: <IntentsPage /> },
      { path: "intents/:intentId", element: <IntentsPage /> },
      { path: "pipelines", element: <PipelinesPage /> },
      { path: "pipelines/new", element: <PipelineWizardPage /> },
      { path: "pipelines/:pipelineId", element: <PipelineDetailPage /> },
      { path: "pipelines/:pipelineId/edit", element: <PipelineWizardPage /> },
      { path: "knowledge", element: <KnowledgeHubPage section="repositories" /> },
      { path: "knowledge/documents", element: <KnowledgeHubPage section="documents" /> },
      { path: "knowledge/documents/:documentId", element: <KnowledgeHubPage section="documents" /> },
      // Repo Graph, Knowledge Explorer, Documents, Data Lineage and the API Playground were folded in or
      // removed; old links land somewhere useful.
      { path: "repo-graph", element: <RepoGraphRedirect /> },
      { path: "explorer", element: <Navigate to="/knowledge/documents" replace /> },
      { path: "explorer/:documentId", element: <DocumentRedirect /> },
      { path: "documents", element: <Navigate to="/knowledge/documents" replace /> },
      { path: "lineage", element: <Navigate to="/knowledge" replace /> },
      { path: "lineage/:documentId", element: <DocumentRedirect /> },
      { path: "playground", element: <Navigate to="/home" replace /> },
      { path: "*", element: <NotFoundPage /> },
    ],
  },
]);
