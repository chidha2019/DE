/** Accent colours for icon tiles, tabs and stat chips, picked by position when a caller names none. */
export const TONES = ["#0EA5E9", "#8B5CF6", "#10B981", "#F59E0B", "#EC4899", "#14B8A6", "#6366F1"];

export function toneAt(index: number): string {
  return TONES[index % TONES.length] ?? "#14B8A6";
}

export function rgba(hex: string, alpha: number): string {
  const n = Number.parseInt(hex.replace("#", ""), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${alpha})`;
}
