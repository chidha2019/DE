import { QueryClient } from "@tanstack/react-query";

import { ApiError } from "@/lib/api-client";

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 10_000,
      gcTime: 5 * 60_000,
      refetchOnWindowFocus: false,
      retry: (failureCount, error) => {
        // Never retry 4xx — the request is wrong, not the network.
        if (error instanceof ApiError && error.status < 500) return false;
        return failureCount < 2;
      },
    },
    mutations: { retry: 0 },
  },
});

/** Query key factory — one place to keep invalidation consistent. */
export const queryKeys = {
  health: (service: string) => ["health", service] as const,
  overview: ["stats", "overview"] as const,
  latency: (params: object) => ["stats", "latency", params] as const,
  activity: (hours: number, bucket: number) => ["stats", "activity", hours, bucket] as const,
  engineering: (days: number) => ["stats", "engineering", days] as const,
  quality: (days: number) => ["stats", "quality", days] as const,
  analyst: (days: number) => ["stats", "analyst", days] as const,
  platform: (hours: number) => ["stats", "platform", hours] as const,
  worker: (worker: string) => ["worker", worker] as const,
  architecture: ["stats", "architecture"] as const,
  audit: (limit: number, action?: string, status?: string) => ["stats", "audit", limit, action ?? null, status ?? null] as const,
  connectors: ["connectors"] as const,
  runs: (params: object) => ["runs", params] as const,
  pipelines: (params: object) => ["pipelines", "list", params] as const,
  pipeline: (id: string) => ["pipelines", "one", id] as const,
  discover: (connector: string, path: string[]) => ["discover", connector, ...path] as const,
  run: (id: string) => ["runs", "detail", id] as const,
  runEvents: (id: string) => ["runs", "events", id] as const,
  documents: (params: object) => ["documents", params] as const,
  document: (id: string) => ["documents", "detail", id] as const,
  documentChunks: (id: string) => ["documents", "chunks", id] as const,
  documentGraph: (id: string) => ["documents", "graph", id] as const,
  documentLineage: (id: string, depth: number) => ["documents", "lineage", id, depth] as const,
  entities: (params: object) => ["graph", "entities", params] as const,
  entitySearch: (q: string, type: string | null) => ["graph", "entity-search", q, type] as const,
  entityNeighborhood: (key: string) => ["graph", "neighborhood", key] as const,
  graphStats: ["graph", "stats"] as const,
  genieStatus: ["genie", "status"] as const,
  genieSpaces: ["genie", "spaces"] as const,
  genieConversations: (spaceId: string) => ["genie", "conversations", spaceId] as const,
  genieConversation: (id: string) => ["genie", "conversation", id] as const,
  semanticOverview: ["semantic", "overview"] as const,
  semanticAssets: (params: object) => ["semantic", "assets", params] as const,
  semanticAsset: (id: string) => ["semantic", "asset", id] as const,
  semanticGraph: (id: string, depth: number) => ["semantic", "graph", id, depth] as const,
  semanticSearch: (q: string) => ["semantic", "search", q] as const,
  semanticMetrics: (params: object) => ["semantic", "metrics", params] as const,
  semanticGlossary: (params: object) => ["semantic", "glossary", params] as const,
  semanticHealth: ["semantic", "health"] as const,
  semanticModel: (params: object) => ["semantic", "model", params] as const,
  semanticCatalog: ["semantic", "catalog"] as const,
  semanticCatalogObjects: (params: object) => ["semantic", "catalog", "objects", params] as const,
  enrichRun: (id: string) => ["semantic", "enrich", id] as const,
  glossaryDomains: ["glossary", "domains"] as const,
  glossaryCoverage: ["glossary", "coverage"] as const,
  glossaryTerms: (params: object) => ["glossary", "terms", params] as const,
  glossaryTerm: (id: string) => ["glossary", "term", id] as const,
  glossaryLinks: (params: object) => ["glossary", "links", params] as const,
  glossaryLinkGroups: (params: object) => ["glossary", "links", "groups", params] as const,
  glossaryKpis: (domain: string | null) => ["glossary", "kpis", domain] as const,
  glossaryMapRun: (id: string) => ["glossary", "map", id] as const,
  glossaryMapRuns: ["glossary", "map", "list"] as const,
  glossaryAutoMap: ["glossary", "auto-map"] as const,
  intentsConfig: ["intents", "config"] as const,
  intents: (params: object) => ["intents", "list", params] as const,
  intent: (id: string) => ["intents", "one", id] as const,
  intentFiles: (id: string) => ["intents", "one", id, "files"] as const,
  intentDiagram: (id: string) => ["intents", "one", id, "er"] as const,
  designDiagrams: ["intents", "designs", "er"] as const,
};
