/**
 * Sample data for the workspaces previewed before their sources are connected: DevOps,
 * DevSecOps, Data Steward, Data Scientist and Compliance & Risk. Every number here is
 * illustrative and the workspace says so; KPIs marked `live` are read from the hub instead.
 */

import {
  BookCheck,
  BrainCircuit,
  Bug,
  CalendarClock,
  Clock3,
  FileSignature,
  Fingerprint,
  KeySquare,
  LifeBuoy,
  Rocket,
  ScanSearch,
  ShieldCheck,
  Target,
  Timer,
  TriangleAlert,
  type LucideIcon,
} from "lucide-react";

import type { PersonaKey } from "@/lib/personas";

export type SampleStatus = "ok" | "warn" | "bad" | "info";

export interface SampleKpi {
  label: string;
  value: string;
  unit?: string;
  delta: string;
  good: boolean;
  /** A week or so of the trend; live KPIs draw their share instead. */
  spark?: number[];
  color: string;
  icon: LucideIcon;
  hint: string;
  /** Read from the hub instead of the sample: the review queue, tables placed, or terms in use. */
  live?: "review" | "placed" | "terms";
}

export interface SampleSeries {
  key: string;
  label: string;
  color: string;
}

interface SectionBase {
  key: string;
  /** The workspace tabs the section appears on; every section also appears on the Overview. */
  tabs: string[];
  title: string;
  description: string;
  wide?: boolean;
}

export type SampleSection =
  | (SectionBase & { kind: "bars" | "area" | "line"; x: string; series: SampleSeries[]; data: Record<string, string | number>[]; stacked?: boolean })
  | (SectionBase & { kind: "donut"; data: { label: string; value: number; color: string }[]; center: { value: string; label: string } })
  | (SectionBase & { kind: "table"; columns: { key: string; label: string; kind?: "status" | "mono" | "muted" }[]; rows: Record<string, string>[] })
  | (SectionBase & { kind: "cards"; items: { title: string; subtitle: string; status: SampleStatus; facts: { label: string; value: string }[] }[] })
  | (SectionBase & { kind: "timeline"; items: { when: string; title: string; detail: string; status: SampleStatus }[] })
  | (SectionBase & { kind: "meters"; items: { label: string; value: number; color: string; detail: string }[] });

export interface SampleSpec {
  /** What to connect to replace the sample with live data. */
  connect: string;
  kpis: SampleKpi[];
  sections: SampleSection[];
}

const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const WEEKS = ["W1", "W2", "W3", "W4", "W5", "W6", "W7", "W8"];
const pick = (values: number[], i: number) => values[i] ?? 0;

const devops: SampleSpec = {
  connect: "Connect GitHub Actions and your deployment tool (Argo CD, Helm or Docker Compose) to make this live.",
  kpis: [
    {
      label: "Deployment frequency",
      value: "2.6",
      unit: "/day",
      delta: "+18% vs last week",
      good: true,
      spark: [1, 3, 2, 4, 2, 3, 3],
      color: "#F97316",
      icon: Rocket,
      hint: "Production deployments per day, last 7 days",
    },
    {
      label: "Lead time for changes",
      value: "3.4",
      unit: "h",
      delta: "−42 min",
      good: true,
      spark: [5.1, 4.6, 4.2, 3.9, 3.8, 3.5, 3.4],
      color: "#0EA5E9",
      icon: Timer,
      hint: "Commit to production, median",
    },
    {
      label: "Change failure rate",
      value: "5.6",
      unit: "%",
      delta: "+1.2 pts",
      good: false,
      spark: [3, 4, 4, 5, 6, 5, 5.6],
      color: "#EF4444",
      icon: TriangleAlert,
      hint: "Deployments that needed a fix or rollback",
    },
    {
      label: "Time to restore",
      value: "38",
      unit: "min",
      delta: "−12 min",
      good: true,
      spark: [62, 55, 50, 48, 44, 40, 38],
      color: "#10B981",
      icon: LifeBuoy,
      hint: "Failed change to recovered service, median",
    },
  ],
  sections: [
    {
      key: "deploys",
      kind: "bars",
      tabs: ["deployments"],
      title: "Deployments per day",
      description: "By environment, last 7 days",
      x: "day",
      stacked: true,
      series: [
        { key: "production", label: "Production", color: "#F97316" },
        { key: "staging", label: "Staging", color: "#8B5CF6" },
        { key: "dev", label: "Dev", color: "#0EA5E9" },
      ],
      data: DAYS.map((day, i) => ({
        day,
        production: pick([2, 3, 2, 4, 3, 1, 3], i),
        staging: pick([4, 5, 3, 6, 4, 1, 2], i),
        dev: pick([9, 11, 8, 12, 10, 3, 4], i),
      })),
    },
    {
      key: "duration",
      kind: "area",
      tabs: ["delivery"],
      title: "Pipeline duration",
      description: "Median minutes per stage, last 7 days",
      x: "day",
      stacked: true,
      series: [
        { key: "build", label: "Build", color: "#0EA5E9" },
        { key: "test", label: "Test", color: "#10B981" },
        { key: "scan", label: "Scan & sign", color: "#8B5CF6" },
      ],
      data: DAYS.map((day, i) => ({
        day,
        build: pick([4.2, 4.0, 4.4, 3.9, 3.8, 3.6, 3.7], i),
        test: pick([6.1, 5.8, 6.4, 5.5, 5.2, 5.0, 5.1], i),
        scan: pick([2.2, 2.1, 2.4, 2.0, 1.9, 1.9, 1.8], i),
      })),
    },
    {
      key: "recent",
      kind: "table",
      tabs: ["deployments"],
      wide: true,
      title: "Recent deployments",
      description: "Newest first",
      columns: [
        { key: "service", label: "Service", kind: "mono" },
        { key: "version", label: "Version", kind: "mono" },
        { key: "env", label: "Environment" },
        { key: "status", label: "Status", kind: "status" },
        { key: "duration", label: "Duration" },
        { key: "author", label: "Team", kind: "muted" },
        { key: "when", label: "When", kind: "muted" },
      ],
      rows: [
        {
          service: "query-service",
          version: "v0.1.12",
          env: "production",
          status: "Deployed",
          duration: "4m 12s",
          author: "platform-team",
          when: "38 min ago",
        },
        { service: "frontend", version: "v0.1.31", env: "production", status: "Deployed", duration: "2m 48s", author: "ui-team", when: "1 hour ago" },
        {
          service: "ingestion-service",
          version: "v0.1.9",
          env: "staging",
          status: "Rolled back",
          duration: "6m 03s",
          author: "data-platform",
          when: "3 hours ago",
        },
        { service: "migrate", version: "0018", env: "production", status: "Deployed", duration: "41s", author: "data-platform", when: "5 hours ago" },
        { service: "frontend", version: "v0.1.30", env: "staging", status: "Deployed", duration: "2m 51s", author: "ui-team", when: "6 hours ago" },
        { service: "query-service", version: "v0.1.11", env: "staging", status: "Failed", duration: "1m 20s", author: "platform-team", when: "yesterday" },
      ],
    },
    {
      key: "envs",
      kind: "cards",
      tabs: ["environments"],
      wide: true,
      title: "Environments",
      description: "What runs where",
      items: [
        {
          title: "Production",
          subtitle: "4 services · 2 regions",
          status: "ok",
          facts: [
            { label: "query-service", value: "v0.1.12" },
            { label: "uptime, 30 days", value: "99.94%" },
            { label: "last deploy", value: "38 min ago" },
          ],
        },
        {
          title: "Staging",
          subtitle: "4 services · 1 region",
          status: "warn",
          facts: [
            { label: "ingestion-service", value: "v0.1.8" },
            { label: "uptime, 30 days", value: "99.2%" },
            { label: "last deploy", value: "3 hours ago" },
          ],
        },
        {
          title: "Dev",
          subtitle: "Docker Compose",
          status: "ok",
          facts: [
            { label: "query-service", value: "main@3e2a1f" },
            { label: "builds today", value: "11" },
            { label: "last deploy", value: "12 min ago" },
          ],
        },
      ],
    },
    {
      key: "repos",
      kind: "table",
      tabs: ["delivery"],
      wide: true,
      title: "CI pipelines by repository",
      description: "Workflows, pass rate and duration, last 7 days",
      columns: [
        { key: "repo", label: "Repository", kind: "mono" },
        { key: "workflow", label: "Workflow" },
        { key: "pass", label: "Pass rate" },
        { key: "p50", label: "Median" },
        { key: "runs", label: "Runs" },
        { key: "status", label: "Last run", kind: "status" },
      ],
      rows: [
        { repo: "claude-context-hub", workflow: "build-test-scan", pass: "96%", p50: "11m 40s", runs: "48", status: "Passed" },
        { repo: "claude-context-hub", workflow: "frontend-e2e", pass: "91%", p50: "7m 05s", runs: "22", status: "Passed" },
        { repo: "omniclaim-lakehouse-pipelines", workflow: "dbt-build", pass: "88%", p50: "14m 12s", runs: "17", status: "Failed" },
        { repo: "omniclaim-lakehouse-pipelines", workflow: "contract-checks", pass: "100%", p50: "3m 30s", runs: "17", status: "Passed" },
      ],
    },
    {
      key: "incidents",
      kind: "timeline",
      tabs: ["deployments", "environments"],
      title: "Incidents and rollbacks",
      description: "Last 14 days",
      items: [
        {
          when: "3 hours ago",
          title: "ingestion-service rolled back on staging",
          detail: "Health check failed after v0.1.9; v0.1.8 restored in 9 minutes.",
          status: "warn",
        },
        { when: "yesterday", title: "query-service build failed", detail: "Type error in the catalog explorer; fixed in the next commit.", status: "bad" },
        { when: "6 days ago", title: "Database migration applied", detail: "Zero downtime; three tables added.", status: "ok" },
      ],
    },
  ],
};

const devsecops: SampleSpec = {
  connect: "Connect your scanners (GitHub Advanced Security, Snyk or Trivy) and secret scanning to make this live.",
  kpis: [
    {
      label: "Critical vulnerabilities",
      value: "3",
      delta: "−2 this week",
      good: true,
      spark: [7, 6, 6, 5, 5, 4, 3],
      color: "#EF4444",
      icon: Bug,
      hint: "Open critical findings across services and images",
    },
    {
      label: "Mean time to remediate",
      value: "4.2",
      unit: "days",
      delta: "−0.8 days",
      good: true,
      spark: [6.5, 6.1, 5.6, 5.2, 5.0, 4.6, 4.2],
      color: "#F97316",
      icon: Clock3,
      hint: "Critical and high, detection to fix",
    },
    {
      label: "Secrets exposed",
      value: "2",
      unit: "open",
      delta: "+1 this week",
      good: false,
      spark: [0, 1, 1, 1, 2, 1, 2],
      color: "#8B5CF6",
      icon: KeySquare,
      hint: "Credentials found in code or config, not yet rotated",
    },
    {
      label: "Images signed",
      value: "96",
      unit: "%",
      delta: "+4 pts",
      good: true,
      spark: [84, 86, 88, 90, 92, 94, 96],
      color: "#10B981",
      icon: FileSignature,
      hint: "Container images with a verified signature",
    },
  ],
  sections: [
    {
      key: "trend",
      kind: "area",
      tabs: ["vulnerabilities"],
      title: "Open vulnerabilities by severity",
      description: "Last 8 weeks",
      x: "week",
      stacked: true,
      series: [
        { key: "critical", label: "Critical", color: "#EF4444" },
        { key: "high", label: "High", color: "#F97316" },
        { key: "medium", label: "Medium", color: "#F59E0B" },
        { key: "low", label: "Low", color: "#94A3B8" },
      ],
      data: WEEKS.map((week, i) => ({
        week,
        critical: pick([8, 7, 7, 6, 5, 5, 4, 3], i),
        high: pick([21, 20, 18, 18, 16, 15, 14, 12], i),
        medium: pick([44, 43, 41, 40, 38, 37, 35, 34], i),
        low: pick([58, 57, 57, 55, 54, 53, 52, 51], i),
      })),
    },
    {
      key: "sources",
      kind: "donut",
      tabs: ["vulnerabilities"],
      title: "Findings by source",
      description: "Where the open findings come from",
      center: { value: "100", label: "open findings" },
      data: [
        { label: "Dependencies", value: 46, color: "#F97316" },
        { label: "Container images", value: 28, color: "#0EA5E9" },
        { label: "Infrastructure as code", value: 14, color: "#8B5CF6" },
        { label: "Code (SAST)", value: 9, color: "#14B8A6" },
        { label: "Secrets", value: 3, color: "#EF4444" },
      ],
    },
    {
      key: "top",
      kind: "table",
      tabs: ["vulnerabilities"],
      wide: true,
      title: "Top vulnerabilities",
      description: "Critical and high, fix available first",
      columns: [
        { key: "id", label: "Finding", kind: "mono" },
        { key: "package", label: "Package", kind: "mono" },
        { key: "severity", label: "Severity", kind: "status" },
        { key: "service", label: "Where" },
        { key: "fix", label: "Fix" },
        { key: "age", label: "Age", kind: "muted" },
      ],
      rows: [
        { id: "SAMPLE-0412", package: "openssl 3.0.13", severity: "Critical", service: "query-service image", fix: "3.0.15", age: "6 days" },
        { id: "SAMPLE-0398", package: "jinja2 3.1.3", severity: "Critical", service: "ingestion-service", fix: "3.1.6", age: "9 days" },
        { id: "SAMPLE-0377", package: "nginx 1.25.3", severity: "Critical", service: "frontend image", fix: "1.27.2", age: "12 days" },
        { id: "SAMPLE-0351", package: "requests 2.31.0", severity: "High", service: "ingestion-service", fix: "2.32.3", age: "15 days" },
        { id: "SAMPLE-0340", package: "esbuild 0.21.5", severity: "High", service: "frontend build", fix: "0.25.0", age: "18 days" },
        { id: "SAMPLE-0322", package: "postgres 16.2", severity: "High", service: "database image", fix: "16.6", age: "21 days" },
      ],
    },
    {
      key: "secrets",
      kind: "table",
      tabs: ["secrets"],
      wide: true,
      title: "Secret scanning",
      description: "Where credentials were found; values are never shown",
      columns: [
        { key: "type", label: "Type" },
        { key: "location", label: "Location", kind: "mono" },
        { key: "found", label: "Found", kind: "muted" },
        { key: "status", label: "Status", kind: "status" },
        { key: "owner", label: "Owner", kind: "muted" },
      ],
      rows: [
        { type: "Cloud access key", location: "pipelines/deploy/env.sample:4", found: "2 days ago", status: "Open", owner: "data-platform" },
        { type: "Database password", location: "infra/compose/override.yml:18", found: "5 days ago", status: "Open", owner: "platform-team" },
        { type: "API token", location: "notebooks/scratch/test.py:12", found: "11 days ago", status: "Rotated", owner: "data-science" },
        { type: "Webhook URL", location: "docs/runbooks/alerts.md:33", found: "20 days ago", status: "Rotated", owner: "sre" },
      ],
    },
    {
      key: "supply",
      kind: "meters",
      tabs: ["supply"],
      title: "Supply chain",
      description: "Share of repositories and images meeting each policy",
      items: [
        { label: "Images signed", value: 96, color: "#10B981", detail: "24 of 25 images" },
        { label: "SBOM published", value: 88, color: "#0EA5E9", detail: "22 of 25 images" },
        { label: "Branch protection", value: 100, color: "#8B5CF6", detail: "6 of 6 repositories" },
        { label: "Dependencies pinned", value: 74, color: "#F59E0B", detail: "lockfiles in 4 of 6 repositories" },
      ],
    },
    {
      key: "access",
      kind: "table",
      tabs: ["supply"],
      wide: true,
      title: "Service accounts and access",
      description: "Who can reach the data, and when the credentials last rotated",
      columns: [
        { key: "account", label: "Account", kind: "mono" },
        { key: "scope", label: "Scope" },
        { key: "role", label: "Role" },
        { key: "rotated", label: "Last rotated", kind: "muted" },
        { key: "status", label: "Review", kind: "status" },
      ],
      rows: [
        { account: "svc-ingestion", scope: "Snowflake INSURANCE_ENTERPRISE", role: "read metadata", rotated: "12 days ago", status: "Passed" },
        { account: "svc-genie", scope: "Postgres + Neo4j", role: "read", rotated: "30 days ago", status: "Passed" },
        { account: "svc-pipelines", scope: "S3 landing bucket", role: "read/write", rotated: "94 days ago", status: "Overdue" },
        { account: "ci-deployer", scope: "container registry", role: "push", rotated: "8 days ago", status: "Passed" },
      ],
    },
  ],
};

const dataSteward: SampleSpec = {
  connect: "The review queue, tables placed and terms in use are live; stewardship tasks and contracts are samples until a workflow tool is connected.",
  kpis: [
    {
      label: "Suggestions to review",
      value: "…",
      delta: "live from the glossary",
      good: true,
      color: "#F59E0B",
      icon: BookCheck,
      hint: "Glossary suggestions waiting for a decision",
      live: "review",
    },
    {
      label: "Tables with a business area",
      value: "…",
      unit: "%",
      delta: "live from the catalog",
      good: true,
      color: "#10B981",
      icon: Target,
      hint: "Tables an approved term places in a domain",
      live: "placed",
    },
    {
      label: "Terms in use",
      value: "…",
      delta: "live from the glossary",
      good: true,
      color: "#0EA5E9",
      icon: ScanSearch,
      hint: "Glossary terms with at least one approved link",
      live: "terms",
    },
    {
      label: "Data contracts signed",
      value: "9",
      unit: "of 14",
      delta: "+2 this month",
      good: true,
      spark: [3, 4, 5, 6, 7, 8, 9],
      color: "#8B5CF6",
      icon: FileSignature,
      hint: "Tables with an agreed owner, freshness and schema",
    },
  ],
  sections: [
    {
      key: "decisions",
      kind: "bars",
      tabs: ["stewardship"],
      title: "Review decisions per day",
      description: "Approved and rejected suggestions, last 7 days",
      x: "day",
      stacked: true,
      series: [
        { key: "approved", label: "Approved", color: "#10B981" },
        { key: "rejected", label: "Rejected", color: "#EF4444" },
      ],
      data: DAYS.map((day, i) => ({ day, approved: pick([12, 30, 18, 44, 26, 0, 8], i), rejected: pick([3, 6, 2, 9, 5, 0, 1], i) })),
    },
    {
      key: "coverage",
      kind: "meters",
      tabs: ["stewardship", "ownership"],
      title: "Documentation by business area",
      description: "Tables with an owner, a description and an approved term",
      items: [
        { label: "Policy Administration", value: 92, color: "#0EA5E9", detail: "11 of 12 tables" },
        { label: "Product & Coverage", value: 88, color: "#14B8A6", detail: "7 of 8 tables" },
        { label: "Claims", value: 85, color: "#EF4444", detail: "6 of 7 tables" },
        { label: "Billing & Collections", value: 78, color: "#F59E0B", detail: "7 of 9 tables" },
        { label: "Party & Customer", value: 70, color: "#8B5CF6", detail: "7 of 10 tables" },
        { label: "Distribution & Sales", value: 64, color: "#EC4899", detail: "4 of 6 tables" },
      ],
    },
    {
      key: "tasks",
      kind: "table",
      tabs: ["stewardship"],
      wide: true,
      title: "Stewardship tasks",
      description: "Open work, nearest due date first",
      columns: [
        { key: "task", label: "Task" },
        { key: "table", label: "Table", kind: "mono" },
        { key: "area", label: "Business area" },
        { key: "assignee", label: "Assignee", kind: "muted" },
        { key: "due", label: "Due", kind: "muted" },
        { key: "status", label: "Status", kind: "status" },
      ],
      rows: [
        { task: "Reject AS_OF_DATE → Valuation Date outside valuations", table: "26 tables", area: "Actuarial", assignee: "you", due: "today", status: "Due" },
        { task: "Name an owner", table: "PARTY.POSTAL_ADDRESS", area: "Party & Customer", assignee: "you", due: "tomorrow", status: "Open" },
        {
          task: "Describe the columns",
          table: "BILLING.PAYMENT_ALLOCATION",
          area: "Billing & Collections",
          assignee: "billing-data",
          due: "in 3 days",
          status: "Open",
        },
        { task: "Sign the data contract", table: "CLAIMS.CLAIM", area: "Claims", assignee: "claims-data", due: "in 5 days", status: "In review" },
        { task: "Merge duplicate terms", table: "Policy Number / Policy ID", area: "Policy Administration", assignee: "you", due: "next week", status: "Open" },
      ],
    },
    {
      key: "owners",
      kind: "donut",
      tabs: ["ownership"],
      title: "Owner coverage",
      description: "Tables with a named owner",
      center: { value: "72%", label: "owned" },
      data: [
        { label: "Owned", value: 31, color: "#10B981" },
        { label: "No owner", value: 12, color: "#F59E0B" },
      ],
    },
    {
      key: "contracts",
      kind: "cards",
      tabs: ["ownership"],
      wide: true,
      title: "Data contracts",
      description: "Owner, freshness and schema agreed with the consumers",
      items: [
        {
          title: "POLICY.POLICY",
          subtitle: "owner policy-data",
          status: "ok",
          facts: [
            { label: "freshness", value: "daily · met" },
            { label: "schema checks", value: "12/12" },
            { label: "consumers", value: "5" },
          ],
        },
        {
          title: "CLAIMS.CLAIM",
          subtitle: "owner claims-data",
          status: "warn",
          facts: [
            { label: "freshness", value: "daily · 1 miss" },
            { label: "schema checks", value: "14/15" },
            { label: "consumers", value: "4" },
          ],
        },
        {
          title: "BILLING.INVOICE",
          subtitle: "no owner yet",
          status: "bad",
          facts: [
            { label: "freshness", value: "not agreed" },
            { label: "schema checks", value: "—" },
            { label: "consumers", value: "3" },
          ],
        },
      ],
    },
  ],
};

const dataScientist: SampleSpec = {
  connect: "Connect a model registry (MLflow or Databricks Model Registry) and feature store to make this live.",
  kpis: [
    {
      label: "Models in production",
      value: "4",
      delta: "+1 this month",
      good: true,
      spark: [2, 2, 3, 3, 3, 4, 4],
      color: "#06B6D4",
      icon: BrainCircuit,
      hint: "Registered models serving predictions",
    },
    {
      label: "Average AUC",
      value: "0.86",
      delta: "+0.02",
      good: true,
      spark: [0.82, 0.83, 0.83, 0.84, 0.85, 0.85, 0.86],
      color: "#8B5CF6",
      icon: Target,
      hint: "Across production classifiers, last evaluation",
    },
    {
      label: "Drift alerts",
      value: "1",
      unit: "open",
      delta: "+1 this week",
      good: false,
      spark: [0, 0, 0, 1, 0, 0, 1],
      color: "#F43F5E",
      icon: TriangleAlert,
      hint: "Inputs whose distribution moved past the threshold",
    },
    {
      label: "Feature freshness",
      value: "98",
      unit: "%",
      delta: "−1 pt",
      good: true,
      spark: [99, 99, 99, 98, 99, 99, 98],
      color: "#10B981",
      icon: Clock3,
      hint: "Features refreshed within their SLA",
    },
  ],
  sections: [
    {
      key: "auc",
      kind: "line",
      tabs: ["models"],
      title: "Model performance",
      description: "AUC per model, last 8 weeks",
      x: "week",
      series: [
        { key: "lapse", label: "Lapse propensity", color: "#06B6D4" },
        { key: "mortality", label: "Mortality risk", color: "#8B5CF6" },
        { key: "fraud", label: "Claim fraud", color: "#F43F5E" },
      ],
      data: WEEKS.map((week, i) => ({
        week,
        lapse: pick([0.84, 0.85, 0.85, 0.86, 0.86, 0.87, 0.87, 0.88], i),
        mortality: pick([0.81, 0.81, 0.82, 0.82, 0.83, 0.83, 0.84, 0.84], i),
        fraud: pick([0.9, 0.9, 0.89, 0.89, 0.88, 0.86, 0.85, 0.84], i),
      })),
    },
    {
      key: "importance",
      kind: "bars",
      tabs: ["features"],
      title: "What drives lapse",
      description: "Feature importance, lapse propensity v3",
      x: "feature",
      series: [{ key: "importance", label: "Importance", color: "#06B6D4" }],
      data: [
        { feature: "months in force", importance: 0.24 },
        { feature: "premium change", importance: 0.19 },
        { feature: "payment method", importance: 0.14 },
        { feature: "missed payments", importance: 0.12 },
        { feature: "agent tenure", importance: 0.09 },
        { feature: "product type", importance: 0.07 },
      ],
    },
    {
      key: "registry",
      kind: "table",
      tabs: ["models"],
      wide: true,
      title: "Model registry",
      description: "Every model with its stage and the governed tables it learns from",
      columns: [
        { key: "model", label: "Model" },
        { key: "version", label: "Version", kind: "mono" },
        { key: "stage", label: "Stage", kind: "status" },
        { key: "metric", label: "Metric" },
        { key: "data", label: "Training data", kind: "mono" },
        { key: "trained", label: "Trained", kind: "muted" },
      ],
      rows: [
        { model: "Lapse propensity", version: "v3", stage: "Production", metric: "AUC 0.88", data: "POLICY.POLICY, BILLING.INVOICE", trained: "5 days ago" },
        { model: "Mortality risk", version: "v2", stage: "Production", metric: "AUC 0.84", data: "UNDERWRITING.APPLICATION", trained: "3 weeks ago" },
        { model: "Claim fraud", version: "v5", stage: "Production", metric: "AUC 0.84", data: "CLAIMS.CLAIM, CLAIMS.CLAIM_PAYMENT", trained: "2 months ago" },
        {
          model: "Next best product",
          version: "v1",
          stage: "Staging",
          metric: "MAP@5 0.31",
          data: "PRODUCT.PRODUCT, ANALYTICS.CUSTOMER_360",
          trained: "yesterday",
        },
        { model: "Reserve adequacy", version: "v1", stage: "Production", metric: "MAPE 4.1%", data: "CLAIMS.CLAIM_RESERVE", trained: "6 weeks ago" },
      ],
    },
    {
      key: "drift",
      kind: "meters",
      tabs: ["models", "features"],
      title: "Input drift",
      description: "Population stability against the training baseline; 100% is the alert threshold",
      items: [
        { label: "payment method (claim fraud)", value: 112, color: "#F43F5E", detail: "PSI 0.28 · alert" },
        { label: "premium change (lapse)", value: 46, color: "#F59E0B", detail: "PSI 0.11" },
        { label: "issue age (mortality)", value: 18, color: "#10B981", detail: "PSI 0.05" },
        { label: "product type (next best product)", value: 22, color: "#10B981", detail: "PSI 0.06" },
      ],
    },
    {
      key: "features",
      kind: "table",
      tabs: ["features"],
      wide: true,
      title: "Feature store",
      description: "Features and the governed columns behind them",
      columns: [
        { key: "feature", label: "Feature", kind: "mono" },
        { key: "source", label: "Source", kind: "mono" },
        { key: "freshness", label: "Freshness" },
        { key: "nulls", label: "Nulls" },
        { key: "status", label: "Status", kind: "status" },
      ],
      rows: [
        { feature: "months_in_force", source: "POLICY.POLICY.ISSUE_DATE", freshness: "daily", nulls: "0%", status: "Healthy" },
        { feature: "premium_change_12m", source: "BILLING.INVOICE.AMOUNT", freshness: "daily", nulls: "0.4%", status: "Healthy" },
        { feature: "missed_payments_6m", source: "BILLING.PAYMENT_ALLOCATION", freshness: "daily", nulls: "1.2%", status: "Healthy" },
        { feature: "payment_method", source: "BILLING.INVOICE.PAYMENT_METHOD", freshness: "daily", nulls: "0%", status: "Drift" },
        { feature: "agent_tenure_years", source: "DISTRIBUTION.AGENT.HIRE_DATE", freshness: "weekly", nulls: "3.0%", status: "Stale" },
      ],
    },
  ],
};

const compliance: SampleSpec = {
  connect: "Connect a GRC tool or policy engine and the regulatory calendar to make this live.",
  kpis: [
    {
      label: "Controls passing",
      value: "89",
      unit: "%",
      delta: "42 of 47",
      good: true,
      spark: [80, 82, 84, 85, 87, 88, 89],
      color: "#10B981",
      icon: ShieldCheck,
      hint: "Controls whose last test passed",
    },
    {
      label: "Personal data classified",
      value: "81",
      unit: "%",
      delta: "+6 pts",
      good: true,
      spark: [62, 66, 70, 73, 75, 78, 81],
      color: "#8B5CF6",
      icon: Fingerprint,
      hint: "Columns holding personal data with a classification",
    },
    {
      label: "Open findings",
      value: "5",
      delta: "−2 this month",
      good: true,
      spark: [9, 8, 8, 7, 7, 6, 5],
      color: "#F59E0B",
      icon: TriangleAlert,
      hint: "Audit and control findings not yet closed",
    },
    {
      label: "Next filing",
      value: "12",
      unit: "days",
      delta: "Solvency II QRT",
      good: false,
      spark: [40, 34, 28, 23, 19, 15, 12],
      color: "#EF4444",
      icon: CalendarClock,
      hint: "Days until the next regulatory submission",
    },
  ],
  sections: [
    {
      key: "testing",
      kind: "donut",
      tabs: ["controls"],
      title: "Control testing",
      description: "Result of each control's last test",
      center: { value: "47", label: "controls" },
      data: [
        { label: "Passed", value: 42, color: "#10B981" },
        { label: "Failed", value: 2, color: "#EF4444" },
        { label: "Not tested", value: 3, color: "#94A3B8" },
      ],
    },
    {
      key: "calendar",
      kind: "timeline",
      tabs: ["filings"],
      title: "Regulatory calendar",
      description: "Filings and attestations coming due",
      items: [
        {
          when: "in 12 days",
          title: "Solvency II quarterly reporting (QRT)",
          detail: "Fed by FINANCE.POLICY_VALUATION and CLAIMS.CLAIM_RESERVE.",
          status: "warn",
        },
        { when: "in 26 days", title: "SOX quarter-end attestation", detail: "47 controls; 2 failed tests to remediate first.", status: "warn" },
        { when: "in 41 days", title: "IFRS 17 disclosure", detail: "Contractual service margin roll-forward by product.", status: "info" },
        { when: "in 63 days", title: "GDPR records of processing review", detail: "Personal data inventory from the Privacy tab.", status: "ok" },
      ],
    },
    {
      key: "pii",
      kind: "bars",
      tabs: ["privacy"],
      title: "Personal data by schema",
      description: "Columns holding personal data, classified and not",
      x: "schema",
      stacked: true,
      series: [
        { key: "classified", label: "Classified", color: "#10B981" },
        { key: "unclassified", label: "Not classified", color: "#F59E0B" },
      ],
      data: [
        { schema: "PARTY", classified: 14, unclassified: 3 },
        { schema: "POLICY", classified: 6, unclassified: 1 },
        { schema: "CLAIMS", classified: 5, unclassified: 2 },
        { schema: "BILLING", classified: 4, unclassified: 1 },
        { schema: "UNDERWRITING", classified: 7, unclassified: 2 },
      ],
    },
    {
      key: "controls",
      kind: "table",
      tabs: ["controls"],
      wide: true,
      title: "Controls",
      description: "Failed and due first",
      columns: [
        { key: "id", label: "Control", kind: "mono" },
        { key: "name", label: "What it checks" },
        { key: "framework", label: "Framework" },
        { key: "owner", label: "Owner", kind: "muted" },
        { key: "tested", label: "Last tested", kind: "muted" },
        { key: "status", label: "Status", kind: "status" },
      ],
      rows: [
        {
          id: "SOX-DM-07",
          name: "Reserve changes approved by a second person",
          framework: "SOX",
          owner: "finance-ops",
          tested: "4 days ago",
          status: "Failed",
        },
        { id: "GDPR-AC-03", name: "Access to personal data reviewed quarterly", framework: "GDPR", owner: "security", tested: "9 days ago", status: "Failed" },
        { id: "S2-DQ-12", name: "QRT inputs reconciled to the ledger", framework: "Solvency II", owner: "actuarial", tested: "2 days ago", status: "Passed" },
        {
          id: "SOX-CH-02",
          name: "Production changes linked to an approved ticket",
          framework: "SOX",
          owner: "platform-team",
          tested: "1 day ago",
          status: "Passed",
        },
        { id: "GDPR-RT-01", name: "Records past retention are deleted", framework: "GDPR", owner: "data-platform", tested: "not yet", status: "Due" },
      ],
    },
    {
      key: "columns",
      kind: "table",
      tabs: ["privacy"],
      wide: true,
      title: "Personal data columns",
      description: "Where personal data lives and how it is protected",
      columns: [
        { key: "column", label: "Column", kind: "mono" },
        { key: "category", label: "Category" },
        { key: "masking", label: "Protection" },
        { key: "status", label: "Classification", kind: "status" },
      ],
      rows: [
        { column: "PARTY.CUSTOMER_PROFILE.DATE_OF_BIRTH", category: "Date of birth", masking: "masked outside actuarial", status: "Classified" },
        { column: "PARTY.POSTAL_ADDRESS.ADDRESS_LINE1", category: "Address", masking: "masked", status: "Classified" },
        { column: "POLICY.BENEFICIARY.BENEFICIARY_NAME", category: "Name", masking: "none", status: "Not classified" },
        { column: "CLAIMS.CLAIM.CLAIMANT_PHONE", category: "Phone", masking: "none", status: "Not classified" },
        { column: "UNDERWRITING.APPLICATION.HEALTH_DISCLOSURE", category: "Health data", masking: "encrypted", status: "Classified" },
      ],
    },
    {
      key: "retention",
      kind: "meters",
      tabs: ["controls", "privacy"],
      title: "Retention and audit",
      description: "Coverage of the policies auditors ask about first",
      items: [
        { label: "Audit trail completeness", value: 99, color: "#10B981", detail: "every change attributed" },
        { label: "Access reviews done", value: 88, color: "#0EA5E9", detail: "22 of 25 systems" },
        { label: "Retention policy coverage", value: 76, color: "#F59E0B", detail: "33 of 43 tables" },
      ],
    },
  ],
};

export const PERSONA_SAMPLES: Partial<Record<PersonaKey, SampleSpec>> = {
  devops,
  devsecops,
  data_steward: dataSteward,
  data_scientist: dataScientist,
  compliance,
};
