/** The audiences the console serves; each gets its own workspace and Genie space. */

import {
  BookCheck,
  Briefcase,
  ClipboardCheck,
  DraftingCompass,
  FlaskConical,
  Gauge,
  Infinity as InfinityIcon,
  Scale,
  ShieldHalf,
  Wrench,
  type LucideIcon,
} from "lucide-react";

export type PersonaKey =
  "data_engineer" | "business_analyst" | "qa_engineer" | "architect" | "sre" | "devops" | "devsecops" | "data_steward" | "data_scientist" | "compliance";

export interface PersonaTab {
  key: string;
  label: string;
}

export interface Persona {
  key: PersonaKey;
  label: string;
  /** Route prefix; sub-tabs live under it (`/engineer/health`). */
  path: string;
  icon: LucideIcon;
  tagline: string;
  description: string;
  /** The discipline shown above the name on the hub card. */
  domain: string;
  /** Three things the workspace is for, as chips on the hub card. */
  skills: string[];
  tabs: PersonaTab[];
  /** True for workspaces shown with sample data until their sources are connected. */
  preview?: boolean;
}

export const PERSONAS: Record<PersonaKey, Persona> = {
  data_engineer: {
    key: "data_engineer",
    label: "Data Engineer",
    path: "/engineer",
    icon: Wrench,
    tagline: "Requests turned into modelled, validated pipelines.",
    description:
      "Hand the digital worker a Jira ticket: it works out the request, designs Silver and Gold, prepares and validates the pipeline, investigates failures and explains what depends on what.",
    domain: "Data engineering",
    skills: ["Requests", "Models", "Pipelines", "Validation", "Failures", "Lineage"],
    tabs: [
      { key: "overview", label: "Digital worker" },
      { key: "datamodels", label: "Data models" },
      { key: "goals", label: "Goals" },
      { key: "pipelines", label: "Pipelines" },
      { key: "health", label: "Catalog health" },
      { key: "lineage", label: "Lineage" },
      { key: "ask", label: "Ask Genie" },
    ],
  },
  business_analyst: {
    key: "business_analyst",
    label: "Business Analyst",
    path: "/analyst",
    icon: Briefcase,
    tagline: "Business questions turned into answers and requests.",
    description:
      "Answer what the governed model covers in plain language, check how each metric is defined and whether it is certified, and turn what it does not cover into a clear request for engineering.",
    domain: "Business intelligence",
    skills: ["Requirements", "Governed metrics", "Acceptance testing", "Reconciliation"],
    tabs: [
      { key: "overview", label: "Overview" },
      { key: "metrics", label: "Metrics" },
      { key: "glossary", label: "Glossary" },
      { key: "domains", label: "Domains" },
      { key: "ask", label: "Ask Genie" },
    ],
  },
  qa_engineer: {
    key: "qa_engineer",
    label: "QA Engineer",
    path: "/qa",
    icon: ClipboardCheck,
    tagline: "Quality gates, failures and what still needs a reviewer.",
    description:
      "Check the gates before a release, see which runs and documents failed and why, work through the review queue, and ask Genie for the checks that would catch a regression.",
    domain: "Quality engineering",
    skills: ["Quality gates", "Failures", "Review queue", "SQL checks"],
    tabs: [
      { key: "overview", label: "Overview" },
      { key: "gates", label: "Quality gates" },
      { key: "failures", label: "Failures" },
      { key: "review", label: "Review queue" },
      { key: "ask", label: "Ask Genie" },
    ],
  },
  architect: {
    key: "architect",
    label: "Architect",
    path: "/architect",
    icon: DraftingCompass,
    tagline: "Platforms, domains, conformed dimensions and the integration surface.",
    description:
      "See what each platform holds, how the business model is composed, which dimensions are shared across facts, and every way data enters and leaves the hub.",
    domain: "Architecture",
    skills: ["Landscape", "Business model", "Integrations", "Conformed dims"],
    tabs: [
      { key: "overview", label: "Overview" },
      { key: "landscape", label: "Landscape" },
      { key: "model", label: "Business model" },
      { key: "integrations", label: "Integrations" },
      { key: "ask", label: "Ask Genie" },
    ],
  },
  sre: {
    key: "sre",
    label: "SRE",
    path: "/sre",
    icon: Gauge,
    tagline: "Service health, SLOs, error budget and capacity.",
    description:
      "Watch both services and their dependencies, latency and error rates against targets, stalled runs and graph failures, and how much storage the hub uses.",
    domain: "Reliability",
    skills: ["Services", "SLOs", "Capacity", "Runbooks"],
    tabs: [
      { key: "overview", label: "Overview" },
      { key: "services", label: "Services" },
      { key: "slos", label: "SLOs" },
      { key: "capacity", label: "Capacity" },
      { key: "observability", label: "Observability" },
      { key: "ask", label: "Ask Genie" },
    ],
  },
  devops: {
    key: "devops",
    label: "DevOps",
    path: "/devops",
    icon: InfinityIcon,
    tagline: "Deployments, delivery pipelines and environments.",
    description:
      "Ship the hub's services safely: deployment frequency and lead time, CI pipelines per repository, what runs in each environment, and the changes that failed.",
    domain: "Delivery",
    skills: ["DORA metrics", "CI/CD", "Environments", "Rollbacks"],
    preview: true,
    tabs: [
      { key: "overview", label: "Overview" },
      { key: "deployments", label: "Deployments" },
      { key: "delivery", label: "CI/CD" },
      { key: "environments", label: "Environments" },
      { key: "ask", label: "Ask Genie" },
    ],
  },
  devsecops: {
    key: "devsecops",
    label: "DevSecOps",
    path: "/devsecops",
    icon: ShieldHalf,
    tagline: "Vulnerabilities, secrets and the software supply chain.",
    description:
      "Keep the platform secure as it ships: open vulnerabilities by severity, exposed secrets, image signing and SBOMs, and who can reach the data.",
    domain: "Security engineering",
    skills: ["Vulnerabilities", "Secrets", "Supply chain", "Access"],
    preview: true,
    tabs: [
      { key: "overview", label: "Overview" },
      { key: "vulnerabilities", label: "Vulnerabilities" },
      { key: "secrets", label: "Secrets" },
      { key: "supply", label: "Supply chain" },
      { key: "ask", label: "Ask Genie" },
    ],
  },
  data_steward: {
    key: "data_steward",
    label: "Data Steward",
    path: "/steward",
    icon: BookCheck,
    tagline: "Business meaning, ownership and the review queue.",
    description:
      "Decide what the data means: approve glossary suggestions, close ownership and description gaps, and keep every business area's tables documented.",
    domain: "Data governance",
    skills: ["Review queue", "Ownership", "Coverage", "Data contracts"],
    preview: true,
    tabs: [
      { key: "overview", label: "Overview" },
      { key: "stewardship", label: "Stewardship" },
      { key: "ownership", label: "Ownership" },
      { key: "ask", label: "Ask Genie" },
    ],
  },
  data_scientist: {
    key: "data_scientist",
    label: "Data Scientist",
    path: "/science",
    icon: FlaskConical,
    tagline: "Models, features and the data they learn from.",
    description: "Track models from training to production: performance and drift, the features behind them, and the governed tables each one learns from.",
    domain: "Machine learning",
    skills: ["Model registry", "Drift", "Features", "Training data"],
    preview: true,
    tabs: [
      { key: "overview", label: "Overview" },
      { key: "models", label: "Models" },
      { key: "features", label: "Features" },
      { key: "ask", label: "Ask Genie" },
    ],
  },
  compliance: {
    key: "compliance",
    label: "Compliance & Risk",
    path: "/compliance",
    icon: Scale,
    tagline: "Controls, privacy and regulatory deadlines.",
    description: "Prove the data is under control: control testing, personal data and where it lives, retention, audit evidence and the filings coming due.",
    domain: "Risk & compliance",
    skills: ["Controls", "PII", "Audit trail", "Filings"],
    preview: true,
    tabs: [
      { key: "overview", label: "Overview" },
      { key: "controls", label: "Controls" },
      { key: "privacy", label: "Privacy" },
      { key: "filings", label: "Filings" },
      { key: "ask", label: "Ask Genie" },
    ],
  },
};

export const PERSONA_LIST: Persona[] = [
  PERSONAS.data_engineer,
  PERSONAS.business_analyst,
  PERSONAS.qa_engineer,
  PERSONAS.architect,
  PERSONAS.sre,
  PERSONAS.devops,
  PERSONAS.devsecops,
  PERSONAS.data_steward,
  PERSONAS.data_scientist,
  PERSONAS.compliance,
];

export function personaTab(persona: Persona, key: string | undefined): PersonaTab {
  return persona.tabs.find((t) => t.key === key) ?? persona.tabs[0] ?? { key: "overview", label: "Overview" };
}
