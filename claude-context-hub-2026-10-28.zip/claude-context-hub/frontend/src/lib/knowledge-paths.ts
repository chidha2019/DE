/** Where the Knowledge Hub shows things; the old /repo-graph, /explorer and /documents links redirect here. */
export const KNOWLEDGE_PATH = "/knowledge";
export const KNOWLEDGE_DOCUMENTS_PATH = "/knowledge/documents";
export const documentPath = (id: string) => `${KNOWLEDGE_DOCUMENTS_PATH}/${encodeURIComponent(id)}`;
