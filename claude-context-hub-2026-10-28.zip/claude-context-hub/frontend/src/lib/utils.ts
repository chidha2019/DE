import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}

/** Clamp a number into [min, max]. */
export function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

/** Stable, URL-safe-ish id for React keys when the backend gives none. */
export function keyFrom(...parts: Array<string | number | null | undefined>): string {
  return parts.map((p) => String(p ?? "")).join("|");
}
