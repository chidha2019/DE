/** Schedule labels, validation and the next runs, with the same arithmetic as the server (times are UTC). */

import type { Schedule } from "@/api/types";
import { DAY_LONG, DAY_NAMES } from "@/lib/pipelines";

export function validateSchedule(s: Schedule): string | null {
  if (s.type === "interval" && !(s.every_minutes && s.every_minutes >= 5)) return "Pick how often it should run.";
  if ((s.type === "daily" || s.type === "weekly") && !/^([01][0-9]|2[0-3]):[0-5][0-9]$/.test(s.time ?? "")) return "Set a time as HH:MM.";
  if (s.type === "weekly" && s.days.length === 0) return "Pick at least one day.";
  return null;
}

export function describeSchedule(s: Schedule): string {
  if (s.type === "manual") return "Manual";
  if (s.type === "interval") {
    const minutes = s.every_minutes ?? 60;
    if (minutes % 1440 === 0) return minutes === 1440 ? "Every day" : `Every ${minutes / 1440} days`;
    if (minutes % 60 === 0) return minutes === 60 ? "Every hour" : `Every ${minutes / 60} hours`;
    return `Every ${minutes} minutes`;
  }
  if (s.type === "daily") return `Daily at ${s.time} UTC`;
  const days = [...s.days].sort();
  const label = days.join() === "0,1,2,3,4" ? "Weekdays" : days.length === 1 ? `${DAY_LONG[days[0] ?? 0]}s` : days.map((d) => DAY_NAMES[d]).join(", ");
  return `${label} at ${s.time} UTC`;
}

function nextAfter(s: Schedule, after: number): number | null {
  if (s.type === "interval") return after + (s.every_minutes ?? 60) * 60_000;
  const [hours, minutes] = (s.time ?? "00:00").split(":").map(Number);
  const start = new Date(after);
  for (let offset = 0; offset < 8; offset++) {
    const candidate = Date.UTC(start.getUTCFullYear(), start.getUTCMonth(), start.getUTCDate() + offset, hours, minutes);
    if (candidate <= after) continue;
    if (s.type === "daily") return candidate;
    const weekday = (new Date(candidate).getUTCDay() + 6) % 7;
    if (s.days.includes(weekday)) return candidate;
  }
  return null;
}

export function nextRuns(s: Schedule, count: number, from: Date = new Date()): Date[] {
  const out: Date[] = [];
  if (s.type === "manual" || validateSchedule(s)) return out;
  let after = from.getTime();
  for (let i = 0; i < count; i++) {
    const next = nextAfter(s, after);
    if (next === null) break;
    out.push(new Date(next));
    after = next;
  }
  return out;
}

/** "in 3h 12m" for a future time, "any moment" when it is due. */
export function formatUntil(iso: string | Date | null | undefined, now: number = Date.now()): string {
  if (!iso) return "–";
  const ms = new Date(iso).getTime() - now;
  if (ms <= 30_000) return "any moment";
  const minutes = Math.round(ms / 60_000);
  if (minutes < 60) return `in ${minutes}m`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `in ${hours}h ${minutes % 60}m`;
  return `in ${Math.floor(hours / 24)}d ${hours % 24}h`;
}
