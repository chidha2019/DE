/** What Genie does for each persona, and the companion that fronts it. */

import {
  BookCheck,
  Boxes,
  BrainCircuit,
  Bug,
  Fingerprint,
  KeySquare,
  PackageCheck,
  Rocket,
  Scale,
  UsersRound,
  Cable,
  ClipboardCheck,
  Database,
  FileSearch,
  Gauge,
  GitFork,
  KeyRound,
  Layers,
  ListChecks,
  Network,
  Search,
  ShieldAlert,
  ShieldCheck,
  Sigma,
  Siren,
  Workflow,
  type LucideIcon,
} from "lucide-react";

import type { PersonaKey } from "@/lib/personas";

export interface Capability {
  title: string;
  detail: string;
  icon: LucideIcon;
}

export interface PersonaGenie {
  /** The companion's name. */
  petName: string;
  /** Body colour as an HSL triplet (hue, saturation %, lightness %). */
  color: [number, number, number];
  /** What the companion says when the workspace opens. */
  greeting: string;
  intro: string;
  capabilities: Capability[];
  /** The Genie tools this persona leans on most. */
  tools: string[];
  /** Lines the companion offers when poked. */
  tips: string[];
}

export const NEUTRAL_COLOR: [number, number, number] = [172, 66, 42];

export const PERSONA_GENIE: Record<PersonaKey, PersonaGenie> = {
  data_engineer: {
    petName: "Bolt",
    color: [172, 66, 42],
    greeting: "Keys, joins, lineage, SQL. Point me at a table.",
    intro: "I answer with fully qualified names, data types, declared versus inferred joins and the pipeline code that builds an asset. Ask for SQL and I write it in the platform's dialect, naming every key I rely on.",
    capabilities: [
      { title: "Keys and joins", detail: "Which facts are keyed, which joins are declared, which are only inferred and how confident.", icon: KeyRound },
      { title: "Lineage", detail: "What feeds an asset and what reads from it, across layers and platforms.", icon: GitFork },
      { title: "SQL on request", detail: "Databricks SQL or Snowflake, with the keys and risks spelled out.", icon: Workflow },
    ],
    tools: ["describe_asset", "get_lineage", "semantic_search", "search_knowledge", "query_graph"],
    tips: [
      "Try: which fact tables have no primary key?",
      "I cite every asset and file I read.",
      "Ask me to write the join and I'll name every key it relies on.",
      "Inferred-only joins are a risk. I'll flag them.",
    ],
  },
  business_analyst: {
    petName: "Pip",
    color: [262, 70, 60],
    greeting: "Plain language, governed numbers. What do you need to know?",
    intro: "I explain what a metric means, how it is calculated in words, what it can be broken down by and whether it is governed or only inferred. No SQL unless you ask for it.",
    capabilities: [
      { title: "What a metric means", detail: "Definition in words, the dimensions it supports, where it is governed.", icon: Sigma },
      { title: "Certified or not", detail: "Declared metric views first; drafts and inferred numbers are called out plainly.", icon: ShieldCheck },
      { title: "Domains", detail: "Which business areas the catalog covers and how complete each one is.", icon: Boxes },
    ],
    tools: ["semantic_search", "describe_asset", "search_knowledge"],
    tips: [
      "Try: how is claim count defined?",
      "I say plainly when a number is not certified.",
      "Ask what a metric can be broken down by.",
      "Want SQL after all? Just ask; I'll label the dialect.",
    ],
  },
  qa_engineer: {
    petName: "Scout",
    color: [150, 60, 42],
    greeting: "Evidence first. Let's find what would break.",
    intro: "I look for gaps and risks: missing keys and descriptions, inferred-only joins, inferred metrics, failed runs, and declared definitions that disagree with the columns. Then I write the check that would catch it, as a SQL assertion.",
    capabilities: [
      { title: "Checks as assertions", detail: "Null, uniqueness, referential integrity, freshness and reconciliation checks in the platform's SQL.", icon: ListChecks },
      { title: "Risk and severity", detail: "Every finding rated, with the asset, run or document it rests on.", icon: ShieldAlert },
      { title: "Review backlog", detail: "What is unclassified or still waiting for a reviewer's decision.", icon: ClipboardCheck },
    ],
    tools: ["describe_asset", "semantic_search", "get_lineage", "search_knowledge"],
    tips: [
      "Try: write a uniqueness check for the claims fact.",
      "Ask which joins sit below 80% confidence.",
      "I rate every finding by risk and severity.",
      "Failed runs and their errors are one question away.",
    ],
  },
  architect: {
    petName: "Atlas",
    color: [28, 85, 52],
    greeting: "Domains, platforms, trade-offs. Where shall we start?",
    intro: "I answer at the level of platforms, subject areas and integration points: which dimensions are conformed across facts, where lineage crosses layers, where datasets are modelled twice, and what the governed model exposes to consumers.",
    capabilities: [
      { title: "Conformed dimensions", detail: "Which dimensions several facts share, and which facts stand alone.", icon: Layers },
      { title: "Across platforms", detail: "Lineage that crosses layers and systems; duplicated bronze and silver copies.", icon: Network },
      { title: "Target state", detail: "Star schemas and integration designs grounded in the assets that exist today.", icon: Cable },
    ],
    tools: ["semantic_search", "get_lineage", "describe_asset", "query_graph", "search_knowledge"],
    tips: [
      "Try: which dimensions are shared by two or more facts?",
      "I can draw a Mermaid diagram when it clarifies.",
      "Ask where the same entity is modelled twice.",
      "I state my assumptions and name the assets I build on.",
    ],
  },
  sre: {
    petName: "Pager",
    color: [200, 80, 50],
    greeting: "On call and ready. What is broken, or at risk?",
    intro: "I prioritise what is failing now: stuck or failed runs, documents that never reached the graph, slow or erroring retrieval, stale catalogs. Answers come runbook-style: symptom, likely cause, how to confirm, the fix, how to verify.",
    capabilities: [
      { title: "Runbook answers", detail: "Symptom, cause, confirmation, remediation and verification, every time.", icon: Siren },
      { title: "Numbers, not reassurance", detail: "Latency, error rates and run outcomes quoted from the audit log and run records.", icon: Gauge },
      { title: "Stores and sync", detail: "Postgres, Neo4j and the graph reconciliation that keeps them aligned.", icon: Database },
    ],
    tools: ["search_knowledge", "find_documents", "get_lineage", "query_graph"],
    tips: [
      "Try: which runs failed or stalled recently?",
      "Ask for a runbook for an expired token mid-run.",
      "I never call something healthy without evidence.",
      "Graph reconciliation is on the Capacity tab.",
    ],
  },
  devops: {
    petName: "Ship",
    color: [43, 92, 47],
    greeting: "Green builds, small changes. What are we shipping?",
    intro: "I think in deployments and pipelines: which change went where, how long it took to reach production, what failed and how fast it was restored. Until CI is connected I answer from the hub's runs, schedules and crawled repositories, and say when a question needs deployment data.",
    capabilities: [
      { title: "Delivery metrics", detail: "Deployment frequency, lead time, change failure rate and time to restore, per service.", icon: Rocket },
      { title: "Pipeline triage", detail: "Why a workflow failed, which step, and the smallest fix.", icon: Workflow },
      { title: "Environment drift", detail: "Which version runs where, and what differs between staging and production.", icon: Layers },
    ],
    tools: ["search_knowledge", "find_documents", "read_document", "query_graph"],
    tips: [
      "Try: what changed between staging and production?",
      "Ask which workflow fails most and why.",
      "This workspace shows sample delivery data until CI is connected.",
      "Rollbacks are on the Deployments tab.",
    ],
  },
  devsecops: {
    petName: "Aegis",
    color: [234, 62, 52],
    greeting: "Trust nothing unverified. What should I check?",
    intro: "I look for what an attacker would: critical vulnerabilities with a fix available, secrets in code or config, unsigned images, over-broad access. Until a scanner is connected I work from dependency manifests, connector settings, audit records and personal-data columns, with severity and a fix for each finding.",
    capabilities: [
      { title: "Vulnerability triage", detail: "Critical and high findings first, with the fix version and the services affected.", icon: Bug },
      { title: "Secrets hygiene", detail: "Exposed credentials, where they were found and whether they were rotated.", icon: KeySquare },
      { title: "Supply chain", detail: "Signed images, SBOM coverage and branch protection across repositories.", icon: PackageCheck },
    ],
    tools: ["search_knowledge", "find_documents", "read_document", "semantic_search"],
    tips: [
      "Try: which critical vulnerabilities have a fix available?",
      "Ask which secrets were not rotated after exposure.",
      "This workspace shows sample security data until scanners are connected.",
      "I never print a secret, only where it was found.",
    ],
  },
  data_steward: {
    petName: "Ledger",
    color: [86, 60, 41],
    greeting: "Every table deserves an owner and a meaning. Where do we start?",
    intro: "I help decide what the data means and who answers for it: glossary suggestions worth approving, tables without an owner or a description, terms that conflict, and the business areas that still have gaps.",
    capabilities: [
      { title: "Review faster", detail: "Which suggestions are safe to approve in bulk and which need a closer look.", icon: BookCheck },
      { title: "Ownership gaps", detail: "Tables and columns with no owner, description or business term.", icon: UsersRound },
      { title: "Coverage by area", detail: "How documented each business area is, and what to fix first.", icon: ShieldCheck },
    ],
    tools: ["semantic_search", "describe_asset", "search_knowledge", "query_graph"],
    tips: [
      "Try: which tables have no owner?",
      "Ask which glossary suggestions look wrong.",
      "The review queue and coverage numbers here are live.",
      "Grouped review is in the Glossary under Review.",
    ],
  },
  data_scientist: {
    petName: "Sigma",
    color: [298, 58, 50],
    greeting: "Show me the data and I'll show you the signal.",
    intro: "I connect models to the data they learn from: which governed tables feed a feature, how fresh it is, where a model is drifting and which version is in production. I write the feature SQL against the semantic layer, and say when a question needs a model registry that is not connected yet.",
    capabilities: [
      { title: "Training data", detail: "Which governed tables and columns a model's features come from, with lineage.", icon: Database },
      { title: "Drift and performance", detail: "Where a model's accuracy or input distribution moved, and since when.", icon: BrainCircuit },
      { title: "Feature SQL", detail: "Point-in-time correct feature queries on Snowflake or Databricks.", icon: Sigma },
    ],
    tools: ["semantic_search", "describe_asset", "get_lineage", "search_knowledge"],
    tips: [
      "Try: which tables would a lapse propensity model need?",
      "Ask me to write a point-in-time feature query.",
      "This workspace shows a sample model registry until one is connected.",
      "Lineage of a feature is one question away.",
    ],
  },
  compliance: {
    petName: "Warden",
    color: [345, 65, 50],
    greeting: "Evidence first. What do we need to prove?",
    intro: "I answer as an auditor would: where personal data lives and who can see it, how long records are kept, and which tables feed each filing. Control test results need a GRC tool connected; until then I say so, and cite the evidence for every claim.",
    capabilities: [
      { title: "Control evidence", detail: "Each control's last test, result and the record that proves it.", icon: Scale },
      { title: "Personal data", detail: "Which columns hold personal data, how they are classified and protected.", icon: Fingerprint },
      { title: "Deadlines", detail: "Regulatory filings and attestations due, with what feeds them.", icon: ShieldAlert },
    ],
    tools: ["semantic_search", "search_knowledge", "describe_asset", "find_documents"],
    tips: [
      "Try: which columns hold personal data without a classification?",
      "Ask what feeds the next Solvency II submission.",
      "This workspace shows sample control data until a GRC tool is connected.",
      "Every answer cites its evidence.",
    ],
  },
};

/** What the companion says while a tool runs. */
const TOOL_LINES: Record<string, string> = {
  search_knowledge: "Reading the indexed sources…",
  semantic_search: "Searching the semantic layer…",
  describe_asset: "Looking an asset up…",
  get_lineage: "Tracing lineage…",
  query_graph: "Querying the knowledge graph…",
  find_documents: "Finding documents…",
  read_document: "Reading a document…",
  explore_entity: "Exploring an entity…",
};

export function thinkingLine(tool: string | undefined): string {
  return (tool && TOOL_LINES[tool]) || "Thinking…";
}

/** The icon the welcome panel shows next to a tool name. */
export const TOOL_ICONS: Record<string, LucideIcon> = {
  search_knowledge: Search,
  semantic_search: Layers,
  describe_asset: FileSearch,
  get_lineage: GitFork,
  query_graph: Network,
  find_documents: FileSearch,
  read_document: FileSearch,
  explore_entity: Boxes,
};
