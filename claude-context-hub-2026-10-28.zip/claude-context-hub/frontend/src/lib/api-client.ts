/**
 * Minimal typed fetch wrapper. Both services share the error envelope
 * `{ error: { code, message, details, request_id } }` produced by
 * `ech_core.middleware.errors`, which we surface as `ApiError`.
 */

export const INGESTION_BASE = (import.meta.env.VITE_INGESTION_API_URL ?? "/ingestion").replace(/\/$/, "");
export const QUERY_BASE = (import.meta.env.VITE_QUERY_API_URL ?? "/query").replace(/\/$/, "");

export class ApiError extends Error {
  readonly status: number;
  readonly code: string;
  readonly details: unknown;
  readonly requestId: string | null;

  constructor(status: number, code: string, message: string, details: unknown, requestId: string | null) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
    this.details = details;
    this.requestId = requestId;
  }

  get isNotFound(): boolean {
    return this.status === 404;
  }
}

export type QueryParams = Record<string, string | number | boolean | null | undefined | Array<string | number>>;

export function buildQuery(params?: QueryParams): string {
  if (!params) return "";
  const search = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value === undefined || value === null || value === "") continue;
    if (Array.isArray(value)) value.forEach((v) => search.append(key, String(v)));
    else search.set(key, String(value));
  }
  const qs = search.toString();
  return qs ? `?${qs}` : "";
}

export async function parseApiError(response: Response): Promise<ApiError> {
  const requestId = response.headers.get("x-request-id");
  try {
    const body = (await response.json()) as { error?: { code?: string; message?: string; details?: unknown } };
    const err = body.error ?? {};
    return new ApiError(response.status, err.code ?? "http_error", err.message ?? response.statusText, err.details, requestId);
  } catch {
    return new ApiError(response.status, "http_error", response.statusText || `HTTP ${response.status}`, null, requestId);
  }
}

async function request<T>(base: string, path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  if (init.body !== undefined && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  headers.set("Accept", "application/json");

  const response = await fetch(`${base}${path}`, { ...init, headers });
  if (!response.ok) throw await parseApiError(response);
  if (response.status === 204) return undefined as T;
  return (await response.json()) as T;
}

function client(base: string) {
  return {
    base,
    get: <T>(path: string, params?: QueryParams, init?: RequestInit) =>
      request<T>(base, `${path}${buildQuery(params)}`, { ...init, method: "GET" }),
    post: <T>(path: string, body?: unknown, init?: RequestInit) =>
      request<T>(base, path, { ...init, method: "POST", body: body === undefined ? undefined : JSON.stringify(body) }),
    patch: <T>(path: string, body?: unknown, init?: RequestInit) =>
      request<T>(base, path, { ...init, method: "PATCH", body: body === undefined ? undefined : JSON.stringify(body) }),
    put: <T>(path: string, body?: unknown, init?: RequestInit) =>
      request<T>(base, path, { ...init, method: "PUT", body: body === undefined ? undefined : JSON.stringify(body) }),
    delete: <T = void>(path: string, init?: RequestInit) => request<T>(base, path, { ...init, method: "DELETE" }),
  };
}

export const ingestionClient = client(INGESTION_BASE);
export const queryClientHttp = client(QUERY_BASE);

export function describeError(error: unknown): string {
  if (error instanceof ApiError) {
    return error.requestId ? `${error.message} (${error.code}, request ${error.requestId.slice(0, 8)})` : `${error.message} (${error.code})`;
  }
  if (error instanceof Error) return error.message;
  return String(error);
}
