/**
 * Who each persona is: role, what they own, goals bound to live KPIs, a typical day,
 * pain points, sample Genie questions, hand-offs and the tools they use.
 * Rendered by the Profile section at the top of every persona Overview.
 */

import type { PersonaKey } from "@/lib/personas";

/** Which report a goal's KPI comes from. */
export type GoalSource = "engineering" | "quality" | "platform" | "analyst";

export interface PersonaGoal {
  /** A KpiValue key in the source report. */
  kpi: string;
  source: GoalSource;
  /** What the target means for this persona, in plain words. */
  why: string;
}

export interface PersonaProfile {
  role: string;
  owns: string[];
  goals: PersonaGoal[];
  painPoints: string[];
  day: Array<{ when: string; what: string }>;
  questions: string[];
  handoffs: Array<{ to: PersonaKey; what: string }>;
  tools: Array<{ label: string; to: string; why: string }>;
}

/** Rate and latency KPIs measured over a window; only these get a trend. */
export const WINDOWED_KPIS = new Set([
  "run_success_rate",
  "doc_failure_rate",
  "avg_run_duration",
  "throughput",
  "request_error_rate",
  "retrieval_p95_ms",
  "genie_error_rate",
  "genie_answered_pct",
  "intent_decision_h",
]);

/** Short window and its baseline per source: 7 vs 30 days, or 24 vs 168 hours. */
export const TREND_WINDOWS: Record<GoalSource, { now: number; base: number; label: string }> = {
  engineering: { now: 7, base: 30, label: "vs 30-day" },
  quality: { now: 7, base: 30, label: "vs 30-day" },
  platform: { now: 24, base: 168, label: "vs 7-day" },
  analyst: { now: 7, base: 30, label: "vs 30-day" },
};

/** Workspaces previewed with sample data have no live goals yet, so no profile. */
export const EMPTY_PROFILE: PersonaProfile = { role: "", owns: [], goals: [], painPoints: [], day: [], questions: [], handoffs: [], tools: [] };

export const PERSONA_PROFILES: Partial<Record<PersonaKey, PersonaProfile>> = {
  data_engineer: {
    role: "Builds and runs the pipelines that land Databricks and Snowflake metadata in the hub, and keeps the catalog keyed, connected and fresh.",
    owns: ["Connectors and pipelines", "Run schedules", "Keys and joins", "Graph sync", "Catalog freshness"],
    goals: [
      { kpi: "run_success_rate", source: "engineering", why: "Scheduled loads finish without a re-run." },
      { kpi: "doc_failure_rate", source: "engineering", why: "Records that fail to load stay the exception." },
      { kpi: "graph_sync_rate", source: "engineering", why: "Everything in Postgres also reaches Neo4j." },
      { kpi: "assets_fresh_24h_pct", source: "engineering", why: "The catalog shows yesterday's warehouse, not last week's." },
      { kpi: "facts_keyed_pct", source: "engineering", why: "Every fact table has a declared primary key." },
      { kpi: "assets_connected_pct", source: "engineering", why: "No table sits alone without a join." },
    ],
    painPoints: [
      "A run fails overnight and nobody notices until a report is wrong.",
      "Schema drift in Snowflake or Unity Catalog breaks a downstream join.",
      "Facts land without keys, so joins have to be guessed.",
      "Nobody can say what breaks when an upstream column changes.",
    ],
    day: [
      { when: "09:00", what: "Check last night's runs and failures in Pipelines." },
      { when: "10:00", what: "Fix or re-run what failed, starting from the connector's error." },
      { when: "11:30", what: "Work through undocumented assets and facts without a key." },
      { when: "14:00", what: "Build or extend a pipeline for a new source or schema." },
      { when: "16:00", what: "Trace lineage for a change before it ships." },
    ],
    questions: [
      "Which pipelines failed in the last 7 days and why?",
      "Which fact tables have no primary key?",
      "Write the SQL to join claims to policies.",
      "What is downstream of the BILLING schema?",
    ],
    handoffs: [
      { to: "qa_engineer", what: "Failed runs and gates to verify before a release." },
      { to: "architect", what: "New schemas and joins that change the business model." },
      { to: "sre", what: "Stalled runs and graph-sync failures that need the platform." },
    ],
    tools: [
      { label: "Pipelines", to: "/pipelines", why: "Saved pipelines, schedules and live run events" },
      { label: "New pipeline", to: "/pipelines/new", why: "Pick a connection, browse the schema, set a schedule" },
      { label: "Semantic Hub", to: "/semantic", why: "Assets, columns, keys and joins" },
      { label: "Knowledge Hub", to: "/knowledge", why: "Pipeline lineage crawled from the GitHub repo" },
      { label: "Catalog health", to: "/engineer/health", why: "What is undocumented, unkeyed or isolated" },
    ],
  },
  business_analyst: {
    role: "Takes business questions from finance, actuarial and distribution, answers what the governed model already covers, and turns what it does not into a clear request for engineering.",
    owns: ["Business requirements", "Report specifications", "Requests to engineering", "Acceptance testing", "Reconciliation before sign-off"],
    goals: [
      { kpi: "genie_answered_pct", source: "analyst", why: "Most questions get an answer without waiting on engineering." },
      { kpi: "intent_decision_h", source: "analyst", why: "A request becomes an approved or rejected plan within two days." },
      { kpi: "intents_clarifying", source: "analyst", why: "The planner's questions get answered, so no request stalls." },
      { kpi: "reporting_metrics_declared_pct", source: "analyst", why: "Report numbers come from declared metrics on curated layers, not raw tables." },
    ],
    painPoints: [
      "Finance and actuarial report different numbers for the same metric, and nobody can say which is right.",
      "A column called POL_STAT_CD does not say what it means in business terms.",
      "It is unclear which table is the source of truth for persistency or claims.",
      "A simple question waits days in the engineering queue.",
    ],
    day: [
      { when: "09:00", what: "Pick up questions from finance, actuarial and distribution." },
      { when: "10:00", what: "Answer what the governed model covers with Genie, and check how each metric is defined." },
      { when: "11:30", what: "Write a request for what it does not cover, and answer the planner's questions." },
      { when: "14:00", what: "Test what engineering delivered against the acceptance criteria." },
      { when: "15:30", what: "Reconcile the numbers to finance and actuarial figures." },
      { when: "16:30", what: "Send the report, noting any metric that is not certified yet." },
    ],
    questions: [
      "What was new business annualised premium (APE) by product last quarter?",
      "How is 13-month persistency defined, and which tables feed it?",
      "Show lapsed and surrendered policies in the last 90 days by branch.",
      "Which governed metrics cover claims, and which are certified?",
    ],
    handoffs: [
      { to: "data_steward", what: "A definition to agree or a glossary mapping to approve." },
      { to: "data_engineer", what: "Missing data, a broken join or a new source, raised as an intent." },
      { to: "qa_engineer", what: "A number that does not reconcile and needs a check." },
      { to: "architect", what: "A new subject area or metric that needs a model decision." },
    ],
    tools: [
      { label: "Ask Genie", to: "/analyst/ask", why: "Plain-language questions over the governed model" },
      { label: "Metrics", to: "/analyst/metrics", why: "Which metrics are certified and how each is computed" },
      { label: "Intents", to: "/intents", why: "Requests to engineering, the planner's questions and the plan" },
      { label: "Business Glossary", to: "/glossary", why: "What a term means and the columns it maps to" },
      { label: "Semantic Hub", to: "/semantic", why: "Find the table behind a number" },
    ],
  },
  qa_engineer: {
    role: "Gates every release on data quality: checks runs, catalog integrity and serving, and works the review queue until it is clear.",
    owns: ["Quality gates", "Failure triage", "Review queue", "Regression checks"],
    goals: [
      { kpi: "run_success_rate", source: "quality", why: "Loads pass before a release goes out." },
      { kpi: "doc_failure_rate", source: "quality", why: "Rejected records are investigated, not ignored." },
      { kpi: "review_backlog", source: "quality", why: "No suggestion waits without a reviewer." },
      { kpi: "request_error_rate", source: "quality", why: "Users do not see errors from the hub." },
      { kpi: "joins_declared_pct", source: "quality", why: "Joins are declared, not only inferred." },
    ],
    painPoints: [
      "A user finds the failure before a check does.",
      "Inferred joins look right but double-count rows.",
      "The review queue grows faster than it is cleared.",
      "There is no clear pass or fail before a release.",
    ],
    day: [
      { when: "09:00", what: "Read the quality gates and anything off target." },
      { when: "10:00", what: "Triage failed runs and documents from the connector's error." },
      { when: "12:00", what: "Clear the review queue: accept or reject suggestions." },
      { when: "14:30", what: "Write SQL checks for this week's regressions." },
      { when: "16:30", what: "Sign off or block the release." },
    ],
    questions: [
      "Which quality gates are failing right now?",
      "Write a SQL check for duplicate policy numbers.",
      "Which joins are only inferred and low confidence?",
      "What errors did users hit in the last 24 hours?",
    ],
    handoffs: [
      { to: "data_engineer", what: "Failed runs and missing keys to fix at the source." },
      { to: "data_steward", what: "Reviewed mappings and metric definitions to approve." },
      { to: "sre", what: "Serving errors and latency regressions." },
    ],
    tools: [
      { label: "Quality gates", to: "/qa/gates", why: "Every gate with its target and verdict" },
      { label: "Failures", to: "/qa/failures", why: "Failed runs, graph sync and request errors" },
      { label: "Review queue", to: "/qa/review", why: "Suggestions waiting for a reviewer" },
      { label: "Pipelines", to: "/pipelines", why: "Re-run a failed load and read its events" },
      { label: "Documents & entities", to: "/knowledge/documents", why: "Inspect what was ingested" },
    ],
  },
  architect: {
    role: "Owns the shape of the data estate: how platforms, domains, facts and conformed dimensions fit together, and how data moves in and out.",
    owns: ["Platform landscape", "Business model", "Conformed dimensions", "Integration surface", "Key and join standards"],
    goals: [
      { kpi: "assets_connected_pct", source: "engineering", why: "The model is one graph, not islands." },
      { kpi: "joins_declared_pct", source: "engineering", why: "Relationships are designed, not discovered." },
      { kpi: "metrics_declared_pct", source: "engineering", why: "Each metric has one governed definition." },
      { kpi: "facts_keyed_pct", source: "engineering", why: "Every fact has a grain and a key." },
      { kpi: "columns_described_pct", source: "engineering", why: "Columns are described well enough to reuse." },
    ],
    painPoints: [
      "The same dimension is modelled differently on each platform.",
      "There is no single view of what Databricks and Snowflake each hold.",
      "Integrations get added without a record of how data flows.",
      "Design rules drift once teams ship on their own.",
    ],
    day: [
      { when: "09:30", what: "Review schemas and assets that landed since yesterday." },
      { when: "11:00", what: "Check the conformed dimensions shared across facts." },
      { when: "13:30", what: "Design a model change or a new subject area." },
      { when: "15:00", what: "Review integrations and lineage for a proposal." },
      { when: "16:30", what: "Record the decision and the standard it sets." },
    ],
    questions: [
      "Which dimensions are shared across fact tables?",
      "What does each platform hold, by subject area?",
      "Which relationships cross from Databricks to Snowflake?",
      "Which facts have no conformed date dimension?",
    ],
    handoffs: [
      { to: "data_engineer", what: "Keys, joins and pipelines to build to the design." },
      { to: "business_analyst", what: "Domains and metrics ready to use." },
      { to: "sre", what: "Integrations and capacity the design needs." },
    ],
    tools: [
      { label: "Landscape", to: "/architect/landscape", why: "What each platform and catalog holds" },
      { label: "Business model", to: "/architect/model", why: "Facts, dimensions and conformed keys" },
      { label: "Integrations", to: "/architect/integrations", why: "Every way data enters and leaves" },
      { label: "Knowledge Hub", to: "/knowledge", why: "How data flows from CSV to Gold, crawled from the repo" },
      { label: "Documents & entities", to: "/knowledge/documents", why: "The graph behind the model" },
    ],
  },
  sre: {
    role: "Keeps the hub's services, dependencies and pipelines inside their SLOs, and plans capacity before it runs out.",
    owns: ["Service health", "SLOs and error budget", "Stalled runs", "Capacity", "Observability"],
    goals: [
      { kpi: "request_error_rate", source: "platform", why: "Users get answers, not errors." },
      { kpi: "retrieval_p95_ms", source: "platform", why: "Context retrieval stays fast enough for Genie." },
      { kpi: "genie_error_rate", source: "platform", why: "Genie answers reliably." },
      { kpi: "catalog_sync_age_h", source: "platform", why: "The catalog syncs at least daily." },
      { kpi: "runs_stale", source: "platform", why: "No run sits stuck in the queue." },
    ],
    painPoints: [
      "A dependency degrades and nobody hears until users complain.",
      "A hung run holds the queue.",
      "Storage grows without a forecast.",
      "Latency spikes with no trace to the cause.",
    ],
    day: [
      { when: "08:30", what: "Check both services and their dependency probes." },
      { when: "09:30", what: "Read the SLOs and error budget for the last 24 hours." },
      { when: "11:00", what: "Clear stalled runs and graph-sync failures." },
      { when: "14:00", what: "Review capacity: Postgres, vectors and the graph." },
      { when: "16:00", what: "Tune alerts and update a runbook." },
    ],
    questions: [
      "How much error budget is left this week?",
      "Which API calls are slowest at p95?",
      "Are any runs stalled right now?",
      "How fast is the database growing?",
    ],
    handoffs: [
      { to: "data_engineer", what: "Failing or stalled pipelines to fix." },
      { to: "qa_engineer", what: "Error spikes that need a regression check." },
      { to: "architect", what: "Capacity limits that need a design change." },
    ],
    tools: [
      { label: "Services", to: "/sre/services", why: "Both services, probes and latency" },
      { label: "SLOs", to: "/sre/slos", why: "Targets and the error budget" },
      { label: "Capacity", to: "/sre/capacity", why: "Postgres, vectors and graph size" },
      { label: "Observability", to: "/sre/observability", why: "Metrics, traces and alerts" },
      { label: "Pipelines", to: "/pipelines", why: "Stalled and failed runs" },
    ],
  },
};
