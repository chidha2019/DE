/**
 * Server-Sent Events over `fetch()`.
 *
 * `EventSource` only does GET, but Genie's `ask` is a POST with a JSON body, so the
 * response body is read as a stream and split into frames here. Resolves when the
 * server closes the stream; rejects on abort or network failure.
 */

export interface SseFrame {
  event: string;
  data: string;
  id?: string;
}

export async function readSse(response: Response, onFrame: (frame: SseFrame) => void): Promise<void> {
  if (!response.body) throw new Error("the response has no body to stream");
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  try {
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true }).replace(/\r\n/g, "\n");
      let boundary = buffer.indexOf("\n\n");
      while (boundary !== -1) {
        const frame = parseFrame(buffer.slice(0, boundary));
        buffer = buffer.slice(boundary + 2);
        if (frame) onFrame(frame);
        boundary = buffer.indexOf("\n\n");
      }
    }
    buffer += decoder.decode();
    const tail = parseFrame(buffer);
    if (tail) onFrame(tail);
  } finally {
    reader.releaseLock();
  }
}

export function parseFrame(raw: string): SseFrame | null {
  let event = "message";
  let id: string | undefined;
  const data: string[] = [];
  for (const line of raw.split("\n")) {
    if (!line || line.startsWith(":")) continue; // blank or keep-alive comment
    const colon = line.indexOf(":");
    const field = colon === -1 ? line : line.slice(0, colon);
    let value = colon === -1 ? "" : line.slice(colon + 1);
    if (value.startsWith(" ")) value = value.slice(1);
    if (field === "event") event = value;
    else if (field === "data") data.push(value);
    else if (field === "id") id = value;
  }
  if (data.length === 0) return null;
  return { event, data: data.join("\n"), id };
}
