/** Pure helpers for pipelines: scope selection, labels and schedule previews. */

import type { PipelineOut, ScopeItem } from "@/api/types";

/** The path segment of the Grafana node that stands for alert rules. */
export const ALERTS_KEY = "__alerts__";
export const DAY_NAMES = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
export const DAY_LONG = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

export const pathKey = (path: string[]): string => JSON.stringify(path);
export const pathLabel = (path: string[], sep = " › "): string => path.map((p) => (p === ALERTS_KEY ? "Alert rules" : p)).join(sep);

/** True when prefix is the path or one of its ancestors. */
export function isPrefix(prefix: string[], path: string[]): boolean {
  return prefix.length <= path.length && prefix.every((segment, i) => segment === path[i]);
}

/**
 * checked: selected itself; inherited: an ancestor is selected so everything below is included;
 * partial: something below it is selected; none otherwise.
 */
export type CheckState = "checked" | "inherited" | "partial" | "none";

export function checkState(path: string[], scope: ScopeItem[]): CheckState {
  let partial = false;
  for (const item of scope) {
    if (item.path.length === path.length && isPrefix(item.path, path)) return "checked";
    if (item.path.length < path.length && isPrefix(item.path, path)) return "inherited";
    if (item.path.length > path.length && isPrefix(path, item.path)) partial = true;
  }
  return partial ? "partial" : "none";
}

/** Selecting a node replaces any narrower selection below it; selecting it again clears it. */
export function toggleScope(scope: ScopeItem[], node: ScopeItem): ScopeItem[] {
  const state = checkState(node.path, scope);
  if (state === "inherited") return scope;
  if (state === "checked") return scope.filter((i) => pathKey(i.path) !== pathKey(node.path));
  return [...scope.filter((i) => !isPrefix(node.path, i.path)), { path: node.path, kind: node.kind }];
}

const PLURAL_IRREGULAR: Record<string, string> = { repository: "repositories" };

function plural(word: string, n: number): string {
  if (n === 1) return word;
  return PLURAL_IRREGULAR[word] ?? (word.endsWith("y") ? `${word.slice(0, -1)}ies` : `${word}s`);
}

/** "2 schemas · 3 tables", from the levels of the connection (Database, Schema, Table). */
export function scopeSummary(scope: ScopeItem[], levels: string[]): string {
  if (scope.length === 0) return "Everything the connection exposes";
  const counts = new Map<string, number>();
  for (const item of scope) {
    const word = item.kind === "alerts" ? "alert rules" : (levels[item.path.length - 1] ?? (item.kind || "item")).toLowerCase();
    counts.set(word, (counts.get(word) ?? 0) + 1);
  }
  return [...counts.entries()].map(([word, n]) => `${n} ${word === "alert rules" ? word : plural(word, n)}`).join(" · ");
}

/** A first name for a new pipeline from its connection and first selection. */
export function suggestName(connectorLabel: string, scope: ScopeItem[]): string {
  const head = scope[0];
  if (!head) return `${connectorLabel} full scan`;
  const first = pathLabel(head.path, " ");
  return scope.length === 1 ? `${connectorLabel} ${first}` : `${connectorLabel} ${first} and ${scope.length - 1} more`;
}

export type PipelineState = "running" | "failed" | "scheduled" | "paused" | "idle";

/** What a card should say first: running beats failed beats the schedule. */
export function pipelineState(p: PipelineOut): PipelineState {
  const status = p.last_run?.status;
  if (status === "running" || status === "queued" || status === "paused") return "running";
  if (status === "failed") return "failed";
  if (p.schedule.type === "manual") return "idle";
  return p.enabled ? "scheduled" : "paused";
}
