/**
 * TypeScript mirrors of the backend Pydantic schemas (`backend/ech_core/schemas/*`).
 * Keep field names snake_case to match the wire format exactly.
 */

export type SourceSystem = "confluence" | "sharepoint" | "github" | "manual" | "snowflake" | "databricks" | "grafana" | "jira";
export type GraphSyncStatus = "pending" | "synced" | "failed";
export type DocumentKind = "document" | "dataset";
export type RunStatus = "queued" | "running" | "paused" | "completed" | "failed" | "cancelled";
export type EntityType = "Person" | "Project" | "Technology" | "Concept";
export type NodeType = EntityType | "Document" | "Chunk";

export const SOURCE_SYSTEMS: SourceSystem[] = ["github", "databricks", "snowflake", "manual", "confluence", "sharepoint"];
export const ENTITY_TYPES: EntityType[] = ["Person", "Project", "Technology", "Concept"];
export const ACTIVE_RUN_STATUSES: RunStatus[] = ["queued", "running", "paused"];

// ----------------------------------------------------------------------------- common
export interface Page<T> {
  items: T[];
  total: number;
  limit: number;
  offset: number;
}

export interface HealthStatus {
  status: "ok" | "degraded" | "down";
  service: string;
  version: string;
  checks: Record<string, boolean>;
  timestamp: string;
}

// ----------------------------------------------------------------------------- documents
export interface DocumentSummary {
  id: string;
  source_system: SourceSystem;
  kind: DocumentKind;
  external_id: string;
  title: string;
  uri: string | null;
  author: string | null;
  mime_type: string;
  language: string;
  version: number;
  content_length: number;
  attributes: Record<string, unknown>;
  graph_sync_status: GraphSyncStatus;
  graph_synced_at: string | null;
  source_updated_at: string | null;
  ingested_at: string;
  updated_at: string;
  chunk_count: number | null;
  embedding_count: number | null;
}

export interface DocumentDetail extends DocumentSummary {
  content_hash: string;
  graph_node_id: string | null;
  graph_sync_error: string | null;
  last_run_id: string | null;
  source_created_at: string | null;
}

export interface ChunkEntityMeta {
  key: string;
  name: string;
  entity_type: EntityType;
  normalized_name: string;
  confidence: number;
}

export interface ChunkOut {
  id: string;
  document_id: string;
  chunk_index: number;
  content: string;
  token_count: number;
  char_start: number;
  char_end: number;
  section_path: string[];
  metadata: { entities?: ChunkEntityMeta[]; overlap_tokens?: number } & Record<string, unknown>;
  created_at: string | null;
}

export interface ManualDocumentIn {
  title: string;
  content: string;
  external_id?: string | null;
  uri?: string | null;
  author?: string | null;
  attributes?: Record<string, unknown>;
  contributors?: string[];
  references?: string[];
}

export interface DocumentIngestResult {
  document_id: string;
  changed: boolean;
  chunks: number;
  embeddings: number;
  entities: number;
  graph_sync_status: GraphSyncStatus;
}

// ----------------------------------------------------------------------------- ingestion
export interface ConnectorInfo {
  name: string;
  source_system: SourceSystem;
  display_name: string;
  description: string;
  healthy: boolean;
  details: Record<string, unknown>;
  estimated_documents: number | null;
  /** The schema of the source can be browsed live to pick what a pipeline ingests. */
  discoverable: boolean;
  /** Names of the levels of the source hierarchy, top down: Database, Schema, Table. */
  scope_levels: string[];
  /** The SourceOptions this connection honours. */
  option_keys: string[];
  /** How long the health check took. */
  latency_ms?: number | null;
}

export type CatalogAvailability = "configured" | "available" | "planned";
export type CatalogFeeds = "semantic" | "documents" | "both";

/** One card of the connector catalogue: a static descriptor merged with live state. */
export interface ConnectorCatalogEntry {
  key: string;
  name: string;
  vendor: string;
  category: string;
  description: string;
  feeds: CatalogFeeds;
  capabilities: string[];
  /** Setting names only, never values. */
  env_vars: string[];
  availability: CatalogAvailability;
  adapter: string | null;
  source_system: string | null;
  healthy: boolean | null;
  health_details: Record<string, unknown>;
  estimated_documents: number | null;
  documents: number;
  last_success_at: string | null;
  last_status: string | null;
  runs_7d: number;
  failed_7d: number;
  docs_url: string | null;
  accent: string;
  icon: string;
  /** The connection can be edited and tested from the hub. */
  editable: boolean;
  /** hub: some settings were saved from the Connectors page. */
  settings_source: "env" | "hub" | null;
  health_latency_ms: number | null;
}

export interface ConnectorCatalogCategory {
  key: string;
  label: string;
  tagline: string;
  count: number;
}

export interface ConnectorCatalog {
  generated_at: string;
  total: number;
  configured: number;
  available: number;
  planned: number;
  categories: ConnectorCatalogCategory[];
  entries: ConnectorCatalogEntry[];
}

export interface GrafanaDashboardSummary {
  uid: string;
  title: string;
  url: string | null;
  folder: string | null;
  tags: string[];
}

export interface GrafanaAlertRule {
  uid: string | null;
  title: string;
  folder: string | null;
  group: string | null;
  /** firing | pending | inactive | unknown */
  state: string;
  health: string | null;
  severity: string | null;
  summary: string | null;
  active_alerts: number;
  labels: Record<string, string>;
  url: string | null;
}

/** Live read of Grafana for the SRE workspace; `configured` false means the settings are missing. */
export interface GrafanaObservability {
  configured: boolean;
  healthy: boolean;
  reason: string | null;
  url: string | null;
  org: string | null;
  version: string | null;
  dashboards: GrafanaDashboardSummary[];
  alert_rules: GrafanaAlertRule[];
  rules_total: number;
  firing: number;
  pending: number;
  documents: number;
  /** The hub's own dashboard on the stack, once provisioned. */
  hub_dashboard_url: string | null;
  generated_at: string;
}

export interface DashboardProvisionResult {
  ok: boolean;
  uid: string | null;
  url: string | null;
  version: number | null;
  reason: string | null;
}

export interface RunOptions {
  full_refresh?: boolean;
  limit?: number | null;
  chunk_target_tokens?: number | null;
  chunk_overlap_tokens?: number | null;
  simulate_failures?: boolean;
}

export interface TriggerRunRequest {
  connector: string;
  options?: RunOptions;
  triggered_by?: string | null;
}

export interface RunStats {
  documents_seen: number;
  documents_upserted: number;
  documents_skipped: number;
  documents_failed: number;
  chunks_created: number;
  embeddings_created: number;
  entities_linked: number;
  graph_synced: number;
  graph_failed: number;
  estimated_total: number | null;
}

export interface IngestionRunOut {
  id: string;
  connector_name: string;
  source_system: SourceSystem;
  status: RunStatus;
  config: Record<string, unknown>;
  stats: RunStats;
  pipeline_id: string | null;
  triggered_by: string | null;
  error: string | null;
  started_at: string | null;
  finished_at: string | null;
  created_at: string;
  updated_at: string;
  progress: number | null;
  duration_seconds: number | null;
}

export interface RunEventOut {
  id: number | null;
  run_id: string;
  level: string;
  event_type: string;
  message: string;
  payload: Record<string, unknown>;
  created_at: string;
}

/** Shape of each SSE `data:` payload (`ingestion_service.services.event_bus.RunEvent`). */
export interface RunEvent {
  seq: number;
  run_id: string;
  level: "debug" | "info" | "warning" | "error" | string;
  event_type: string;
  message: string;
  payload: Record<string, unknown>;
  stats: Partial<RunStats> | null;
  status: RunStatus | null;
  created_at: string;
}

export interface ReconcileResult {
  scanned: number;
  synced: number;
  failed: number;
  orphan_entities_removed: number;
}

// ----------------------------------------------------------------------------- graph
export interface GraphNode {
  id: string;
  label: string;
  type: NodeType | string;
  properties: Record<string, unknown>;
  degree: number | null;
}

export interface GraphEdge {
  source: string;
  target: string;
  type: string;
  properties: Record<string, unknown>;
}

export interface GraphPayload {
  nodes: GraphNode[];
  edges: GraphEdge[];
  center_id: string | null;
  chunk_entities: Record<string, string[]> | null;
}

export interface EntitySearchHit {
  key: string;
  name: string;
  entity_type: EntityType | string;
  score: number | null;
  mention_count: number | null;
}

export interface EntityListItem {
  key: string;
  name: string;
  entity_type: EntityType | string;
  mention_count: number;
  document_count: number;
}

export interface GraphStats {
  nodes_total: number;
  edges_total: number;
  nodes_by_label: Record<string, number>;
  edges_by_type: Record<string, number>;
  density: number;
}

// ----------------------------------------------------------------------------- context retrieval
export interface RetrievalFilters {
  source_systems?: SourceSystem[] | null;
  document_ids?: string[] | null;
  attributes?: Record<string, unknown> | null;
}

export interface RetrievalOptions {
  use_vector?: boolean;
  use_keyword?: boolean;
  use_graph?: boolean;
  use_rerank?: boolean;
  graph_hops?: 1 | 2;
  vector_top_k?: number | null;
  keyword_top_k?: number | null;
  rerank_candidates?: number | null;
  include_graph_context?: boolean;
  include_debug?: boolean;
  max_content_chars?: number | null;
}

export interface AgentState {
  goal?: string | null;
  current_task?: string | null;
  recent_messages?: string[];
  entities?: string[];
  metadata?: Record<string, unknown>;
}

export interface ContextRetrieveRequest {
  query?: string | null;
  agent_state?: AgentState | null;
  top_k?: number;
  filters?: RetrievalFilters;
  options?: RetrievalOptions;
}

export interface ScoreBreakdown {
  vector: number | null;
  keyword: number | null;
  fused: number;
  graph_boost: number;
  rerank: number | null;
  final: number;
}

export interface EntityRef {
  key: string;
  name: string;
  entity_type: EntityType | string;
}

export interface ContextChunk {
  chunk_id: string;
  document_id: string;
  document_title: string;
  source_system: SourceSystem;
  uri: string | null;
  chunk_index: number;
  section_path: string[];
  content: string;
  token_count: number;
  scores: ScoreBreakdown;
  retrieval_paths: Array<"vector" | "keyword" | "graph">;
  entities: EntityRef[];
  document_attributes: Record<string, unknown>;
}

export interface GraphContext {
  nodes: GraphNode[];
  edges: GraphEdge[];
  seed_chunk_ids: string[];
  expanded_chunk_ids: string[];
  first_degree_entities: string[];
  second_degree_entities: string[];
}

export interface StageTimings {
  embed_ms: number;
  vector_ms: number;
  keyword_ms: number;
  fusion_ms: number;
  graph_ms: number;
  hydrate_ms: number;
  rerank_ms: number;
  total_ms: number;
}

export interface ContextRetrieveResponse {
  request_id: string | null;
  query: string;
  top_k: number;
  results: ContextChunk[];
  graph_context: GraphContext | null;
  timings: StageTimings;
  candidates_considered: number;
  reranker: string;
  embedding_model: string;
  debug: Record<string, unknown> | null;
}

// ----------------------------------------------------------------------------- stats
export interface LatencyPoint {
  bucket_start: string;
  count: number;
  p50_ms: number;
  p95_ms: number;
  p99_ms: number;
  avg_ms: number;
  error_rate: number;
}

export interface LatencySeries {
  window_minutes: number;
  bucket_seconds: number;
  path_prefix: string | null;
  points: LatencyPoint[];
  overall: LatencyPoint | null;
}

export interface RunActivityPoint {
  bucket_start: string;
  completed: number;
  failed: number;
  cancelled: number;
  documents: number;
}

export type KpiStatus = "ok" | "warn" | "bad" | "info" | "na";
export type KpiUnit = "percent" | "count" | "hours" | "seconds" | "per_minute" | "ms";

export interface KpiValue {
  key: string;
  label: string;
  value: number | null;
  unit: KpiUnit;
  target: number | null;
  direction: "higher" | "lower";
  status: KpiStatus;
  detail: string;
}

export interface KpiGroup {
  key: string;
  label: string;
  description: string;
  kpis: KpiValue[];
}

export interface ConnectorFreshness {
  connector: string;
  source_system: string;
  last_success_at: string | null;
  age_hours: number | null;
  last_status: string | null;
  runs: number;
  failed: number;
  documents_upserted: number;
}

export interface KpiTarget {
  key: string;
  label: string;
  env_var: string;
  unit: KpiUnit;
  direction: "higher" | "lower";
  value: number;
  default: number;
  overridden: boolean;
}

export interface EngineeringKpis {
  window_days: number;
  generated_at: string;
  targets: KpiTarget[];
  groups: KpiGroup[];
  connectors: ConnectorFreshness[];
}

// ----------------------------------------------------------------------------- persona reports
export interface RunFailure {
  id: string;
  connector: string;
  source_system: string;
  status: string;
  error: string | null;
  started_at: string | null;
  finished_at: string | null;
  documents_failed: number;
}

export interface ReviewItem {
  asset_id: string;
  fqn: string;
  display_name: string;
  kind: string;
  proposed_name: string;
  proposed_kind: string;
  confidence: number;
  metrics: number;
  generated_at: string | null;
}

export interface QualityReport {
  window_days: number;
  generated_at: string;
  gates_total: number;
  gates_passed: number;
  targets: KpiTarget[];
  groups: KpiGroup[];
  failed_runs: RunFailure[];
  review_queue: ReviewItem[];
  recent_errors: AuditRecord[];
}

/** Business Analyst scorecard: self-serve answers, request turnaround, certified report metrics. */
export interface AnalystReport {
  window_days: number;
  generated_at: string;
  targets: KpiTarget[];
  groups: KpiGroup[];
}

export interface RequestRollup {
  action: string;
  requests: number;
  errors: number;
  error_rate: number | null;
  p50_ms: number | null;
  p95_ms: number | null;
  p99_ms: number | null;
  avg_ms: number | null;
}

export interface ErrorBudget {
  target_error_rate: number;
  requests: number;
  errors: number;
  allowed_errors: number;
  consumed_pct: number | null;
}

export interface TableSize {
  table: string;
  rows: number;
  bytes: number;
}

export interface PlatformReport {
  window_hours: number;
  generated_at: string;
  targets: KpiTarget[];
  groups: KpiGroup[];
  requests: RequestRollup[];
  error_budget: ErrorBudget;
  storage: TableSize[];
  database_bytes: number;
  embeddings_total: number;
  vector_dimensions: number;
  embeddings_bytes_estimate: number;
  graph_nodes: number;
  graph_edges: number;
  audit_rows_per_day: number;
  runs_active: number;
  runs_stale: number;
  recent_errors: AuditRecord[];
}

export interface PlatformSummary {
  platform: string;
  databases: number;
  schemas: number;
  assets: number;
  metric_views: number;
  by_kind: Record<string, number>;
  by_asset_type: Record<string, number>;
  last_synced_at: string | null;
}

export interface SharedDimension {
  id: string;
  fqn: string;
  display_name: string;
  facts: number;
}

export type IntegrationKind = "source" | "store" | "model" | "export" | "api" | "assistant";
export type IntegrationStatus = "configured" | "available" | "missing";

export interface Integration {
  key: string;
  label: string;
  kind: IntegrationKind;
  status: IntegrationStatus;
  detail: string;
  href: string | null;
}

export interface ArchitectureReport {
  generated_at: string;
  platforms: PlatformSummary[];
  document_sources: Record<string, number>;
  documents_by_kind: Record<string, number>;
  assets_by_kind: Record<string, number>;
  fields_by_role: Record<string, number>;
  relationships_by_kind: Record<string, number>;
  metrics_by_source: Record<string, number>;
  graph_nodes_by_label: Record<string, number>;
  graph_edges_by_type: Record<string, number>;
  graph_density: number;
  subject_areas: number;
  facts: number;
  dimensions: number;
  metric_views: number;
  governed_metrics: number;
  cross_platform_links: number;
  shared_dimensions: SharedDimension[];
  integrations: Integration[];
  embedding_model: string;
  vector_dimensions: number;
  genie_provider: string | null;
  genie_model: string | null;
  reranker: string;
}

export interface OverviewStats {
  documents_total: number;
  documents_by_source: Record<string, number>;
  documents_by_kind: Record<string, number>;
  documents_graph_pending: number;
  chunks_total: number;
  embeddings_total: number;
  embedding_model: string;
  vector_dimensions: number;
  graph_nodes_total: number;
  graph_edges_total: number;
  graph_nodes_by_label: Record<string, number>;
  graph_edges_by_type: Record<string, number>;
  graph_density: number;
  runs_total: number;
  runs_active: number;
  last_run_at: string | null;
  retrieval_requests_24h: number;
  retrieval_p95_ms_24h: number | null;
  generated_at: string;
}

export interface AuditRecord {
  id: number;
  request_id: string | null;
  actor: string | null;
  action: string;
  resource_type: string | null;
  resource_id: string | null;
  status: string;
  latency_ms: number | null;
  details: Record<string, unknown>;
  created_at: string;
}

// ----------------------------------------------------------------------------- genie
export interface GenieSpaceIn {
  name: string;
  description?: string;
  instructions?: string;
  filters?: RetrievalFilters;
  sample_questions?: string[];
}

export type GenieSpaceUpdate = Partial<GenieSpaceIn>;

export interface GenieSpace {
  id: string;
  name: string;
  description: string;
  instructions: string;
  filters: RetrievalFilters;
  sample_questions: string[];
  is_default: boolean;
  persona: "data_engineer" | "business_analyst" | "qa_engineer" | "architect" | "sre" | null;
  conversation_count: number;
  created_at: string;
  updated_at: string;
}

export interface GenieConversation {
  id: string;
  space_id: string;
  title: string;
  message_count: number;
  last_message_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface GenieCitation {
  marker: string;
  chunk_id: string;
  document_id: string;
  title: string;
  path: string | null;
  source_system: string;
  uri: string | null;
  score: number;
  chunk_index: number;
  snippet: string;
  kind?: "chunk" | "asset";
}

export interface GenieTraceStep {
  step: number;
  tool: string;
  summary: string;
  input: Record<string, unknown>;
  detail: string | null;
  ok: boolean;
  duration_ms: number;
  rows: number | null;
  narration: string | null;
}

export type GenieMessageStatus = "complete" | "error" | "cancelled";

export interface GenieMessage {
  id: string;
  conversation_id: string;
  role: "user" | "assistant";
  content: string;
  status: GenieMessageStatus;
  error: string | null;
  citations: GenieCitation[];
  trace: GenieTraceStep[];
  follow_ups: string[];
  usage: Record<string, number>;
  model: string | null;
  latency_ms: number | null;
  feedback: number | null;
  created_at: string;
}

export interface GenieConversationDetail extends GenieConversation {
  messages: GenieMessage[];
}

export interface GenieStatus {
  enabled: boolean;
  configured: boolean;
  provider: string | null;
  model: string | null;
  host: string | null;
  credential: string | null;
  reason: string | null;
  degraded_fields: string[];
}

export interface GenieAskRequest {
  question: string;
  conversation_id?: string | null;
}

// ----------------------------------------------------------------------------- semantic layer
export type SemanticExportFormat = "cortex" | "databricks_metric_view" | "hub";

export interface SemanticScope {
  source_system: string;
  platform: string;
  database_name: string;
  schema_name: string;
  assets: number;
  facts: number;
  dimensions: number;
  metric_views: number;
  synced_at: string | null;
}

export interface SemanticOverview {
  assets: number;
  fields: number;
  relationships: number;
  metrics: number;
  declared_metrics: number;
  last_synced_at: string | null;
  by_platform: Record<string, number>;
  by_asset_type: Record<string, number>;
  by_kind: Record<string, number>;
  by_role: Record<string, number>;
  scopes: SemanticScope[];
}

export interface SemanticAssetSummary {
  id: string;
  document_id: string;
  source_system: string;
  platform: string;
  fqn: string;
  database_name: string;
  schema_name: string;
  name: string;
  asset_type: string;
  kind: string;
  display_name: string;
  summary: string;
  name_source: "derived" | "declared" | "model" | "curated";
  kind_source: "inferred" | "declared" | "model" | "curated";
  enrichment: Partial<EnrichmentSuggestion>;
  description: string;
  owner: string | null;
  tags: string[];
  field_count: number;
  metric_count: number;
  relationship_count: number;
  row_count: number | null;
  uri: string | null;
  source_updated_at: string | null;
  synced_at: string;
}

export interface SemanticField {
  id: string;
  name: string;
  display_name: string;
  ordinal: number;
  data_type: string;
  description: string;
  nullable: boolean | null;
  is_primary_key: boolean;
  is_partition: boolean;
  role: string;
  role_confidence: number;
  aggregation: string | null;
  tags: string[];
  synonyms: string[];
}

export interface SemanticRelationship {
  id: string;
  direction: "out" | "in";
  kind: string;
  source_asset_id: string;
  target_asset_id: string | null;
  target_fqn: string;
  other_asset_id: string | null;
  other_fqn: string;
  other_name: string | null;
  other_asset_type: string | null;
  other_kind: string | null;
  source_columns: string[];
  target_columns: string[];
  confidence: number;
  evidence: string;
}

export interface SemanticMetric {
  id: string;
  name: string;
  display_name: string;
  expression: string;
  aggregation: string | null;
  description: string;
  source: string;
  dimensions: string[];
  fields: string[];
  synonyms: string[];
}

export interface SemanticAssetDetail extends SemanticAssetSummary {
  properties: Record<string, unknown>;
  definition: string | null;
  bytes: number | null;
  source_created_at: string | null;
  fields: SemanticField[];
  relationships: SemanticRelationship[];
  metrics: SemanticMetric[];
}

export interface SemanticFieldHit {
  name: string;
  data_type: string;
  role: string;
  description: string;
  is_primary_key: boolean;
  asset_id: string;
  asset_fqn: string;
  asset_type: string;
}

export interface SemanticMetricHit {
  name: string;
  expression: string;
  aggregation: string | null;
  description: string;
  source: string;
  asset_id: string;
  asset_fqn: string;
}

export interface SemanticSearchResponse {
  query: string;
  assets: SemanticAssetSummary[];
  fields: SemanticFieldHit[];
  metrics: SemanticMetricHit[];
}

export interface EnrichmentMetric {
  name: string;
  display_name: string;
  expression: string;
  description: string;
  dimensions: string[];
}

export interface EnrichmentSuggestion {
  status: "suggested" | "accepted" | "rejected";
  display_name: string;
  summary: string;
  kind: string;
  metrics: EnrichmentMetric[];
  confidence: number;
  rationale: string;
  model: string | null;
  generated_at: string;
  decided_at: string | null;
}

export interface EnrichmentDecision {
  action: "accept" | "reject";
  display_name?: string | null;
  summary?: string | null;
  kind?: string | null;
  metric_names?: string[] | null;
}

export interface EnrichRequest {
  source_system?: SourceSystem | null;
  database?: string | null;
  schema?: string | null;
  asset_ids?: string[] | null;
  only_undocumented?: boolean;
  redo?: boolean;
  limit?: number;
}

export interface EnrichRun {
  id: string;
  status: "running" | "completed" | "failed" | "cancelled";
  total: number;
  done: number;
  failed: number;
  /** Datasets in scope left out because Claude already proposed names for them (awaiting review or accepted). */
  skipped_proposed: number;
  /** Datasets in scope left out because they are already described, classified and named. */
  skipped_documented: number;
  /** Why the run had nothing to do, when total is zero. */
  message: string | null;
  started_at: string;
  finished_at: string | null;
  error: string | null;
  current: string | null;
}

export interface StarDimension {
  asset: SemanticAssetSummary | null;
  fqn: string;
  display_name: string;
  kind: string;
  relationship: string;
  join_columns: string[];
  confidence: number;
}

export interface FactStar {
  asset: SemanticAssetSummary;
  measures: string[];
  time: string[];
  roles: Record<string, number>;
  dimensions: StarDimension[];
  metrics: SemanticMetric[];
}

export interface MetricViewCard {
  asset: SemanticAssetSummary;
  source_fqn: string | null;
  dimensions: string[];
  metrics: SemanticMetric[];
}

export interface SubjectArea {
  platform: string;
  database_name: string;
  schema_name: string;
  label: string;
  assets: number;
  described: number;
  named: number;
  facts: FactStar[];
  metric_views: MetricViewCard[];
  dimensions: SemanticAssetSummary[];
  other: SemanticAssetSummary[];
}

export interface BusinessModel {
  subject_areas: SubjectArea[];
  assets: number;
  facts: number;
  dimensions: number;
  metric_views: number;
  governed_metrics: number;
  enrichment_available: boolean;
}

export interface SemanticGraphNode {
  id: string;
  fqn: string;
  name: string;
  asset_type: string;
  kind: string;
}

export interface SemanticGraphEdge {
  source: string;
  target: string | null;
  target_fqn: string;
  kind: string;
  confidence: number;
  source_columns: string[];
  target_columns: string[];
}

export interface SemanticGraph {
  center_id: string;
  nodes: SemanticGraphNode[];
  edges: SemanticGraphEdge[];
}

/** One SSE frame of `POST /api/v1/genie/spaces/{id}/ask` (`event:` is `type`). */
export interface SemanticMetricRow {
  id: string;
  name: string;
  expression: string;
  aggregation: string | null;
  description: string;
  source: "declared" | "inferred";
  dimensions: string[];
  synonyms: string[];
  asset_id: string;
  asset_fqn: string;
  asset_name: string;
  asset_type: string;
  asset_kind: string;
  platform: string;
  database_name: string;
  schema_name: string;
  uri: string | null;
}

// ----------------------------------------------------------------------------- intents (migration 0013)
export type IntentStatus =
  | "received"
  | "clarifying"
  | "planning"
  | "waiting"
  | "modeling"
  | "spec_proposed"
  | "approved"
  | "coding"
  | "pr_open"
  | "running"
  | "loaded"
  | "done"
  | "rejected"
  | "failed";
export type IntentKind = "ingest_csv_to_iceberg" | "model_layer" | "gold_fact" | "other";
export type Layer = "bronze" | "silver" | "gold";
export interface IntentSource {
  folder: string | null;
  file_pattern: string;
  s3_bucket: string | null;
  s3_prefix: string | null;
  storage_integration?: string | null;
  storage_provider?: "s3" | "azure";
  azure_account?: string | null;
  azure_container?: string | null;
  azure_prefix?: string | null;
  stage?: string | null;
  file_format?: string | null;
  delimiter: string;
  header: boolean;
  encoding: string;
  database?: string | null;
  schema?: string | null;
  /** model_layer: design files (mapping, data model, DDL) the layer is compiled from, under the data directory */
  mapping_files?: string[];
}
export interface IntentTarget {
  platform: "snowflake" | "databricks";
  database: string | null;
  schema: string | null;
  table: string | null;
  table_pattern?: string | null;
  table_format: "iceberg" | "native";
  external_volume: string | null;
  base_location: string | null;
  load_mode: "append" | "full_refresh" | "merge";
  merge_keys: string[];
}
export interface StructuredIntent {
  kind: IntentKind;
  summary: string;
  source: IntentSource;
  target: IntentTarget;
  grain: string;
  business_terms: string[];
  columns_hint: string[];
  freshness: string;
  owner: string;
  acceptance_criteria: string[];
  layer?: Layer | null;
  depends_on?: string[];
  open_questions: string[];
  confidence: number;
}
export interface ValidatedObject {
  kind: "database" | "schema" | "table" | "external_volume" | "integration" | "stage";
  name: string;
  role: "source" | "target" | "prerequisite";
  exists: boolean;
  rows: number | null;
  columns: string[];
  detail: string;
  properties?: Record<string, string>;
}
export interface IntentValidation {
  checked_at: string;
  reachable: boolean;
  error: string;
  objects: ValidatedObject[];
  summary: string;
}
export type RouteKey = "ingest_new" | "ingest_existing" | "model_new" | "model_existing" | "wait_upstream" | "manual";
export type RouteStageStatus = "done" | "current" | "pending" | "blocked" | "skipped";
export interface RouteStage {
  key: string;
  label: string;
  status: RouteStageStatus;
  detail: string;
}
export interface IntentRoute {
  key: RouteKey;
  title: string;
  reason: string;
  waits_on: string[];
  stages: RouteStage[];
}
export type ReviewStatus = "ok" | "warn" | "missing";
export interface ReviewCheck {
  key: string;
  label: string;
  status: ReviewStatus;
  detail: string;
  blocking: boolean;
}
export interface IntentReview {
  score: number;
  verdict: "ready" | "needs_answers" | "thin";
  headline: string;
  checks: ReviewCheck[];
}
export type WorkflowKind = "prepare" | "source" | "land" | "stage" | "table" | "model" | "load" | "validate" | "schedule" | "govern" | "relate" | "downstream";
export interface WorkflowStep {
  key: string;
  kind: WorkflowKind;
  title: string;
  summary: string;
  items: string[];
  metrics: { label: string; value: string }[];
  status: "ready" | "attention";
  note: string;
}
export interface SpecColumn {
  name: string;
  type: string;
  nullable: boolean;
  description: string;
  term_key: string | null;
  term_name: string | null;
  source_header: string | null;
  sample: string | null;
  catalog_type: string | null;
}
export interface SpecTest {
  name: string;
  kind: string;
  columns: string[];
  detail: string;
  condition: string | null;
  origin: string | null;
  sample_failures: number | null;
  sample_examples: string[];
}
export interface SpecExemplarCheck {
  name: string;
  outcome: "copied" | "covered" | "skipped";
  test: string | null;
  detail: string;
}
export type DownstreamColumnStatus = "mapped" | "constant" | "needs" | "missing" | "untraced";
export interface SpecDownstreamColumn {
  column: string;
  status: DownstreamColumnStatus;
  sources: string[];
  provided_by: string[];
}
export interface SpecDownstream {
  table: string;
  layer: string | null;
  repo: string;
  files: string[];
  file_url: string | null;
  link: string | null;
  reads: string[];
  affects: string[];
  columns: SpecDownstreamColumn[];
}
export interface SpecMatch {
  kind: "dataset" | "term" | "exemplar";
  name: string;
  detail: string;
  link: string | null;
  score: number | null;
}
export interface PipelineSpec {
  name: string;
  kind: IntentKind;
  summary: string;
  source: IntentSource;
  target: IntentTarget;
  columns: SpecColumn[];
  sampled_files: string[];
  sampled_rows: number;
  stage_name: string;
  file_format_name: string;
  transformations: string[];
  tests: SpecTest[];
  schedule: string;
  matches: SpecMatch[];
  risks: string[];
  assumptions: string[];
  exemplar_checks: SpecExemplarCheck[];
  downstream: SpecDownstream[];
  catalog_match: SpecCatalogMatch | null;
  joins: SpecJoin[];
  tables?: SpecTable[];
  models?: ModelTable[];
  create?: ("database" | "schema")[];
  /** Source tables that hold no rows (missing, or created and never loaded): the plan cannot be approved */
  blockers?: string[];
}
export interface SpecTable {
  name: string;
  source_file: string;
  source_system: string;
  columns: SpecColumn[];
  keys: string[];
  tests: SpecTest[];
  rows: number;
  base_location: string;
  exemplar: string | null;
  exemplar_checks: SpecExemplarCheck[];
  missing_columns: string[];
  extra_columns: string[];
  exists: boolean;
}
export interface ModelColumn {
  name: string;
  type: string;
  expression: string;
  nullable: boolean;
  description: string;
  sources: string[];
  term_key: string | null;
  term_name: string | null;
}
export interface ModelTable {
  name: string;
  kind: "dimension" | "fact" | "bridge" | "reference" | "aggregate";
  grain: string;
  description: string;
  keys: string[];
  load_mode: "full_refresh" | "merge";
  sources: string[];
  sql: string;
  columns: ModelColumn[];
  relationships: { columns: string[]; to_table: string; to_columns: string[] }[];
  tests: SpecTest[];
  exemplar: string | null;
  deviations: string[];
  findings: string[];
  exists: boolean;
  /** Compiled from design files: the DDL as written, CDC and the read-only dry run */
  ddl?: string;
  hash_column?: string | null;
  created_column?: string | null;
  updated_column?: string | null;
  rows?: number | null;
  duplicates?: number | null;
  nulls?: Record<string, number>;
  waiting_on?: string[];
}
export interface SpecJoin {
  columns: string[];
  to_table: string;
  to_columns: string[];
  kind: string;
  confidence: number;
  via: string;
  link: string | null;
}
export interface SpecCatalogMatch {
  fqn: string;
  asset_id: string | null;
  link: string | null;
  kind: string | null;
  asset_type: string | null;
  coverage: number;
  similarity: number;
  matched_columns: string[];
  feed_columns: number;
  table_columns: number;
  key: string[];
  key_in_feed: boolean;
  types_adopted: number;
  type_conflicts: number;
  duplicate: boolean;
  duplicate_reason: string;
}
export interface GeneratedFile {
  path: string;
  bytes: number;
  reason: string;
}
export interface CoderResult {
  generator: "template" | "agent";
  workspace: string;
  files: GeneratedFile[];
  tests_passed: boolean | null;
  test_output: string;
  branch: string | null;
  pr_url: string | null;
  summary: string;
}
export interface IntentRecord {
  id: string;
  source: "manual" | "jira";
  jira_key: string | null;
  jira_url: string | null;
  title: string;
  text: string;
  reporter: string;
  status: IntentStatus;
  intent: StructuredIntent | null;
  questions: string[];
  answers: string[];
  spec: PipelineSpec | null;
  spec_markdown: string;
  coder: CoderResult | null;
  branch: string | null;
  pr_url: string | null;
  error: string | null;
  posted: Record<string, unknown>[];
  validation?: IntentValidation | null;
  route?: IntentRoute | null;
  run?: PipelineRun | null;
  run_missing?: string[];
  created_at: string;
  updated_at: string;
  decided_at: string | null;
  review: IntentReview | null;
  workflow: WorkflowStep[];
}
export type RunStepKey = "preflight" | "upload" | "apply" | "load" | "catalog";
export interface RunStep {
  key: RunStepKey;
  label: string;
  status: "pending" | "running" | "ok" | "failed" | "skipped";
  started_at: string | null;
  finished_at: string | null;
  detail: string;
  log: string;
  metrics: { label: string; value: string }[];
}
export interface RunCheck {
  name: string;
  failures: number;
  passed: boolean;
  /** a warning is reported but does not fail the run */
  severity?: "error" | "warn";
}
/** One table's source against its target after a load: its rows, its distinct keys or a total. */
export interface RunReconciliation {
  table: string;
  /** rows, keys, or sum:<COLUMN> */
  measure: string;
  source: number;
  target: number;
  /** Rows or keys the load rejected with a reason */
  explained: number;
  /** source - target - explained; 0 when they reconcile */
  gap: number;
  /** A gap fails the load; a total that differs only warns */
  status: "match" | "explained" | "warn" | "gap";
}
/** One table of a modelled layer as the load built it. */
export interface RunModel {
  name: string;
  staged: number;
  rejected: number;
  inserted: number;
  updated: number;
  rows: number;
}
/** The approved pipeline run by the hub: upload, create, load, check, refresh the catalog. */
export interface PipelineRun {
  status: "running" | "succeeded" | "failed";
  triggered_by: "approval" | "manual";
  started_at: string;
  finished_at: string | null;
  role: string | null;
  warnings: string[];
  steps: RunStep[];
  checks: RunCheck[];
  models?: RunModel[];
  /** Each loaded table's source against its target */
  reconciliation?: RunReconciliation[];
  files_uploaded: number;
  statements: number;
  catalog_run_id: string | null;
  error: string;
}
export interface IntentCreate {
  title: string;
  text?: string;
  reporter?: string;
  jira_key?: string | null;
  jira_url?: string | null;
}
export interface IntentAnswer {
  answers: string[];
}
export interface IntentDecision {
  decision: "approve" | "reject" | "done";
  note?: string;
}
export interface IntentFile {
  path: string;
  content: string;
}
export interface IntentsConfig {
  jira_configured: boolean;
  jira_jql: string | null;
  poll_seconds: number;
  workspace: string;
  data_dir: string;
  snowflake_configured: boolean;
  model_available: boolean;
  run_enabled?: boolean;
  autorun?: boolean;
  run_role?: string | null;
  run_missing?: string[];
  kinds: string[];
}
export interface JiraSyncResult {
  fetched: number;
  created: number;
  answered: number;
  approved: number;
  rejected: number;
  errors: string[];
}

// ----------------------------------------------------------------------------- business glossary (migration 0011)
export type GlossaryStandard = "acord" | "fibo" | "hub";
export type GlossaryTermKind = "entity" | "attribute" | "measure" | "event" | "code";
export type TermTargetType = "asset" | "field" | "metric";
export type TermLinkStatus = "suggested" | "accepted" | "rejected";
export type TermLinkSource = "rule" | "model" | "curated";

export interface GlossaryDomain {
  key: string;
  name: string;
  parent_key: string | null;
  description: string;
  standard: GlossaryStandard;
  standard_ref: string;
  sort_order: number;
  term_count: number;
  asset_count: number;
  kpi_count: number;
}
export interface GlossaryDomainNode extends GlossaryDomain {
  children: GlossaryDomain[];
}
export interface GlossaryTermRow {
  id: string;
  key: string;
  name: string;
  definition: string;
  domain_key: string | null;
  domain_name: string | null;
  kind: GlossaryTermKind;
  synonyms: string[];
  standard: GlossaryStandard;
  standard_ref: string;
  status: "seeded" | "curated" | "proposed";
  proposed_by: string | null;
  rationale: string;
  linked_assets: number;
  linked_fields: number;
  linked_metrics: number;
  suggested: number;
  updated_at: string;
}
export interface TermLink {
  id: string;
  term_id: string;
  term_key: string;
  term_name: string;
  domain_key: string | null;
  target_type: TermTargetType;
  target_id: string;
  target_label: string | null;
  target_context: string | null;
  asset_id: string | null;
  confidence: number;
  source: TermLinkSource;
  status: TermLinkStatus;
  rationale: string;
  model: string | null;
  created_at: string;
  decided_at: string | null;
}
export interface GlossaryTermDetail extends GlossaryTermRow {
  links: TermLink[];
}
export interface GlossaryTermCreate {
  name: string;
  definition?: string;
  domain_key?: string | null;
  kind?: GlossaryTermKind;
  synonyms?: string[];
}
export interface GlossaryTermUpdate {
  name?: string;
  definition?: string;
  domain_key?: string | null;
  kind?: GlossaryTermKind;
  synonyms?: string[];
}
export interface TermLinkDecision {
  decision: "accept" | "reject";
}
/** One proposal repeated across tables: the same term for the same column, metric or dataset name. */
export interface TermLinkGroup {
  key: string;
  term_id: string;
  term_key: string;
  term_name: string;
  domain_key: string | null;
  target_type: TermTargetType;
  target_label: string;
  count: number;
  min_confidence: number;
  max_confidence: number;
  sources: TermLinkSource[];
  links: TermLink[];
}
export interface TermLinksDecisionResult {
  decision: "accept" | "reject";
  decided: number;
  missing: number;
}
export interface TermLinkCreate {
  term_id: string;
  target_type: TermTargetType;
  target_id: string;
}
export interface GlossaryKpi {
  id: string;
  key: string;
  name: string;
  domain_key: string | null;
  domain_name: string | null;
  term_id: string | null;
  term_name: string | null;
  metric_id: string | null;
  metric_name: string | null;
  metric_asset_id: string | null;
  metric_asset_fqn: string | null;
  definition: string;
  formula: string;
  grain: string;
  period: string;
  unit: string;
  direction: "higher" | "lower";
  target_value: number | null;
  warn_value: number | null;
  owner: string;
  standard_ref: string;
  status: "seeded" | "curated";
  updated_at: string;
}
export interface GlossaryKpiUpdate {
  metric_id?: string | null;
  clear_metric?: boolean;
  target_value?: number | null;
  warn_value?: number | null;
  owner?: string;
  definition?: string;
  formula?: string;
  grain?: string;
  period?: string;
  unit?: string;
  direction?: "higher" | "lower";
}
export interface GlossaryMapRequest {
  source_system?: string | null;
  database?: string | null;
  schema?: string | null;
  asset_ids?: string[] | null;
  use_model?: boolean;
  limit?: number;
}
export interface TermDecision {
  decision: "accept" | "reject";
  accept_links?: boolean;
}
export interface TermDecisionResult {
  id: string;
  decision: "accept" | "reject";
  links_accepted: number;
}
export interface ProposeTermsRequest {
  source_system?: string | null;
  database?: string | null;
  schema?: string | null;
  asset_ids?: string[] | null;
  limit?: number;
  batch_size?: number;
}
export interface GlossaryMapRun {
  id: string;
  mode: "map" | "propose";
  /** sync: started by a successful Snowflake or Databricks sync. */
  trigger: "manual" | "sync";
  status: "running" | "completed" | "failed" | "cancelled";
  total: number;
  done: number;
  failed: number;
  rule_links: number;
  model_links: number;
  terms_proposed: number;
  /** Datasets not sent to Claude because nothing changed since it last mapped them. */
  skipped: number;
  message: string | null;
  started_at: string;
  finished_at: string | null;
  error: string | null;
  current: string | null;
}
/** One automatic mapping pass after a sync: name rules on every dataset, Claude on new or changed ones. */
export interface GlossaryAutoMapRun {
  id: string;
  source_system: string;
  ingestion_run_ids: string[];
  status: "running" | "completed" | "failed";
  datasets: number;
  model_datasets: number;
  unchanged: number;
  model_failed: number;
  rule_links: number;
  model_links: number;
  message: string | null;
  error: string | null;
  started_at: string;
  finished_at: string | null;
}
export interface GlossaryAutoMapStatus {
  enabled: boolean;
  interval_seconds: number;
  model_available: boolean;
  runs: GlossaryAutoMapRun[];
}
export interface GlossaryCoverage {
  model_available: boolean;
  terms_total: number;
  terms_proposed: number;
  terms_linked: number;
  domains_total: number;
  assets_total: number;
  assets_with_domain: number;
  assets_with_terms: number;
  fields_total: number;
  fields_with_terms: number;
  fields_with_synonyms: number;
  metrics_total: number;
  metrics_with_terms: number;
  kpis_total: number;
  kpis_with_metric: number;
  kpis_with_target: number;
  links_suggested: number;
  links_accepted: number;
  links_rejected: number;
}

export interface GlossaryTerm {
  term: string;
  role: string;
  data_types: string[];
  description: string;
  asset_count: number;
  declared: boolean;
  assets: { id: string; fqn: string }[];
}

export interface HealthAssetRef {
  id: string;
  fqn: string;
  asset_type: string;
  kind: string;
  field_count: number;
  owner: string | null;
  platform: string;
}

export interface HealthJoinRef {
  id: string;
  source_asset_id: string;
  source_fqn: string;
  target_asset_id: string | null;
  target_fqn: string;
  source_columns: string[];
  target_columns: string[];
  confidence: number;
  evidence: string;
}

export interface HealthCoverage {
  platform: string;
  database_name: string;
  schema_name: string;
  assets: number;
  described: number;
  owned: number;
  facts: number;
  keyed_facts: number;
  synced_at: string | null;
}

export interface SemanticHealth {
  assets: number;
  described: number;
  owned: number;
  facts: number;
  keyed_facts: number;
  with_relationships: number;
  isolated: number;
  inferred_joins: number;
  low_confidence_joins: number;
  stale_assets: number;
  last_synced_at: string | null;
  undocumented: HealthAssetRef[];
  unowned: HealthAssetRef[];
  keyless_facts: HealthAssetRef[];
  orphans: HealthAssetRef[];
  review_joins: HealthJoinRef[];
  coverage: HealthCoverage[];
}

export type GenieStreamEvent =
  | { type: "conversation"; data: { conversation: GenieConversation; user_message: GenieMessage } }
  | { type: "delta"; data: { text: string } }
  | { type: "turn_reset"; data: { text: string } }
  | { type: "step"; data: { step: number; tool: string; input: Record<string, unknown> } }
  | { type: "step_done"; data: GenieTraceStep }
  | { type: "message"; data: GenieMessage }
  | { type: "error"; data: { error: string; message: GenieMessage | null } };

// ----------------------------------------------------------------------------- semantic catalog
export type CatalogObjectType = "entity" | "dimension" | "measure" | "metric" | "relationship" | "hierarchy";
export type CatalogDomainSource = "dataset" | "term" | "columns" | "kpi" | "none";

export interface CatalogCounts {
  entities: number;
  dimensions: number;
  measures: number;
  metrics: number;
  relationships: number;
  hierarchies: number;
  total: number;
}
export interface CatalogDomain {
  key: string;
  name: string;
  parent_key: string | null;
  description: string;
  standard: string;
  sort_order: number;
  counts: CatalogCounts;
  quality: number | null;
}
export interface CatalogDomainNode extends CatalogDomain {
  children: CatalogDomain[];
}
export interface QualityCheck {
  name: string;
  ok: boolean;
}
export interface CatalogObject {
  id: string;
  type: CatalogObjectType;
  subtype: string;
  name: string;
  technical_name: string;
  description: string;
  domain_key: string | null;
  domain_name: string | null;
  domain_source: CatalogDomainSource;
  model: string;
  model_label: string;
  platform: string;
  asset_id: string | null;
  asset_name: string | null;
  owner: string | null;
  quality: number;
  checks: QualityCheck[];
  term: string | null;
  /** Line-of-business keys of the dataset; empty when shared across lines. */
  lines: string[];
  /** How the sync knows: a tag, a pipeline default, column values or inheritance. */
  lines_note: string;
  detail: string;
  updated_at: string | null;
}
export interface SemanticCatalog {
  domains: CatalogDomainNode[];
  counts: CatalogCounts;
  placed: number;
  entities_placed: number;
  quality: number | null;
  models: string[];
  /** Objects per model (database.schema): the tree grouped by source. */
  sources: CatalogSource[];
  /** Objects placed directly in a domain (sub-domains apart), per model. */
  domain_models: CatalogDomainModel[];
  /** Each line of business, then what is shared across lines, with counts per top-level domain. */
  lines: CatalogLine[];
  owners: string[];
  hierarchy_note: string;
  generated_at: string;
}
export interface CatalogSource {
  model: string;
  model_label: string;
  platform: string;
  /** Empty for glossary KPIs bound to no dataset. */
  database: string;
  schema_name: string;
  counts: CatalogCounts;
  quality: number | null;
}
export interface CatalogDomainModel {
  domain_key: string;
  model: string;
  counts: CatalogCounts;
  quality: number | null;
}
export interface CatalogLine {
  key: string;
  name: string;
  description: string;
  counts: CatalogCounts;
  quality: number | null;
  domains: { domain_key: string; counts: CatalogCounts }[];
}
export type CatalogSort = "type" | "name" | "domain" | "model" | "owner" | "quality" | "updated";

// ----------------------------------------------------------------------------- saved pipelines
export interface ScopeItem {
  /** A position in the hierarchy of the source: [database, schema, table], [repo, folder] ... */
  path: string[];
  kind: string;
}

export interface SourceOptions {
  include_lineage?: boolean | null;
  include_tags?: boolean | null;
  include_alert_rules?: boolean | null;
  include_extensions?: string[] | null;
  exclude_globs?: string[] | null;
}

export type ScheduleType = "manual" | "interval" | "daily" | "weekly";

export interface Schedule {
  type: ScheduleType;
  every_minutes?: number | null;
  /** HH:MM, UTC */
  time?: string | null;
  /** 0 = Monday ... 6 = Sunday */
  days: number[];
}

export interface PipelineRunSummary {
  id: string;
  status: RunStatus;
  triggered_by: string | null;
  started_at: string | null;
  finished_at: string | null;
  created_at: string;
  documents_seen: number;
  documents_upserted: number;
  documents_skipped: number;
  documents_failed: number;
  estimated_total: number | null;
  progress: number | null;
  duration_seconds: number | null;
  error: string | null;
}

export interface PipelineOut {
  id: string;
  name: string;
  description: string;
  connector: string;
  source_system: SourceSystem;
  connector_label: string;
  scope: ScopeItem[];
  options: RunOptions;
  source_options: SourceOptions;
  schedule: Schedule;
  schedule_label: string;
  enabled: boolean;
  owner: string;
  tags: string[];
  /** Default line of business for what this pipeline syncs when no tag says otherwise. */
  line_of_business: string | null;
  next_run_at: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
  last_run: PipelineRunSummary | null;
  runs_total: number;
  runs_failed: number;
  connection_available: boolean;
}

export interface PipelineIn {
  name: string;
  description: string;
  connector: string;
  scope: ScopeItem[];
  options: RunOptions;
  source_options: SourceOptions;
  schedule: Schedule;
  enabled: boolean;
  owner: string;
  tags: string[];
  line_of_business?: string | null;
  run_now: boolean;
}

export type PipelineUpdate = Partial<Omit<PipelineIn, "connector" | "run_now">>;

export interface DiscoveryNode {
  name: string;
  label: string | null;
  path: string[];
  kind: string;
  selectable: boolean;
  expandable: boolean;
  description: string;
  detail: string;
  child_count: number | null;
  row_count: number | null;
}

export interface DiscoveryResult {
  connector: string;
  path: string[];
  nodes: DiscoveryNode[];
  truncated: boolean;
  note: string | null;
}

export interface PreviewRequest {
  connector: string;
  scope: ScopeItem[];
  options: RunOptions;
  source_options: SourceOptions;
}

export interface PreviewResult {
  connector: string;
  scope_items: number;
  estimated_documents: number | null;
  whole_connection: boolean;
  note: string | null;
}

// --------------------------------------------------------------------------- digital worker
export type WorkerTier = "T0" | "T1" | "T2" | "T3";
export type WorkerItemStatus = "detected" | "diagnosed" | "waiting" | "running" | "done" | "failed" | "dismissed";
export type WorkerJournalKind = "shift" | "observed" | "diagnosed" | "proposed" | "approved" | "acted" | "done" | "failed" | "dismissed";

export interface WorkerPlaybook {
  name: string;
  package: string;
  description: string;
  rules: string[];
  red_flags: string[];
  checks: string[];
}
export interface WorkerSkill {
  key: string;
  name: string;
  description: string;
  tier: WorkerTier;
  gate: string;
  stops: string[];
  actions: string[];
  /** The governing package's own rules, by section */
  rules: string[];
  source: "hub" | "package";
  package: string | null;
  /** A reference-only playbook's own red flags and done-when checks */
  red_flags: string[];
  checks: string[];
  /** Playbook packages bound to the skill: guidance, never its tier or gate */
  playbooks: WorkerPlaybook[];
  where: string;
  handled: number;
  succeeded: number;
  open: number;
  last_at: string | null;
}
export interface WorkerAction {
  kind: "rerun" | "sync" | "crawl" | "approve_intent" | "open";
  label: string;
  params: Record<string, unknown>;
  link: string | null;
}
export interface WorkerItem {
  key: string;
  skill: string;
  title: string;
  detail: string;
  status: WorkerItemStatus;
  tier: WorkerTier;
  action: WorkerAction | null;
  evidence: Record<string, unknown>;
  created_at: string;
  updated_at: string;
  decided_by: string | null;
  decided_at: string | null;
}
export interface WorkerJournalEntry {
  id: number;
  at: string;
  kind: WorkerJournalKind;
  item_key: string | null;
  skill: string | null;
  message: string;
  evidence: Record<string, unknown>;
  record_hash: string;
}
export interface WorkerSnapshot {
  worker: string;
  title: string;
  autonomy: WorkerTier;
  paused: boolean;
  last_tick: string | null;
  tick_seconds: number;
  now: string;
  counts: { open: number; waiting: number; running: number; done_today: number; failed_today: number; signals: number };
  items: WorkerItem[];
  journal: WorkerJournalEntry[];
  chain_ok: boolean;
  skills: WorkerSkill[];
  integrity: WorkerIntegrity | null;
  capabilities: WorkerCapability[];
}
export type Readiness = "available" | "missing_connection" | "missing_rules" | "tool_unavailable";
/** One connection, set of rules or tool a capability needs, as the hub found it */
export interface CapabilityNeed {
  key: string;
  kind: "connection" | "rules" | "tool";
  label: string;
  ok: boolean;
  detail: string;
}
export interface CapabilityAbility {
  label: string;
  status: Readiness;
  reason: string;
  /** One way to deliver the outcome; any available one makes the capability available */
  headline: boolean;
  /** Shown, but never decides the capability's readiness */
  optional: boolean;
}
/** An outcome the worker can deliver, ready only when a headline ability has everything it needs */
export interface WorkerCapability {
  key: string;
  title: string;
  outcome: string;
  readiness: Readiness;
  reason: string;
  action: string;
  link: string;
  /** A second action, when the capability has one */
  more_action: string;
  more_link: string;
  needs_input: string;
  skills: string[];
  tools: string[];
  abilities: CapabilityAbility[];
  context: CapabilityNeed[];
}
export type ErEntityKind = "dimension" | "fact" | "bridge" | "reference" | "aggregate" | "table" | "external";
export interface ErColumn {
  name: string;
  type: string;
  pk: boolean;
  /** The TABLE.COLUMN it references */
  fk: string | null;
  nullable: boolean;
  description: string;
}
export interface ErEntity {
  name: string;
  schema_name: string;
  kind: ErEntityKind;
  description: string;
  grain: string;
  /** The ontology concept the design names, e.g. ACORD Party */
  concept: string;
  columns: ErColumn[];
  /** Rows the read-only dry run returned, for a plan */
  rows: number | null;
  findings: string[];
}
/** One foreign key: the referencing table's columns to the referenced table's */
export interface ErRelationship {
  from_table: string;
  from_columns: string[];
  to_table: string;
  to_columns: string[];
  cardinality: "many_to_one" | "one_to_one";
  /** Every referencing column is NOT NULL */
  required: boolean;
}
export interface ErDiagram {
  key: string;
  title: string;
  source: "design" | "plan";
  origin: string;
  files: string[];
  entities: ErEntity[];
  relationships: ErRelationship[];
  problems: string[];
  /** The same diagram as Mermaid erDiagram text */
  mermaid: string;
}
export type IntegrityStatus = "live" | "empty" | "exists" | "planned_only";
export interface IntegrityTable {
  origin: string;
  kind: "repo" | "design";
  layer: string | null;
  table: string;
  status: IntegrityStatus;
  observed: string | null;
  loaded_as: string | null;
  rows: number | null;
  synced_at: string | null;
  readers: string[];
}
export interface IntegrityOrigin {
  origin: string;
  kind: "repo" | "design";
  declared: number;
  live: number;
  empty: number;
  exists: number;
  planned_only: number;
  aliases: number;
}
export interface WorkerIntegrity {
  available: boolean;
  problem: string;
  checked_at: string | null;
  origins: IntegrityOrigin[];
  tables: IntegrityTable[];
  observed: number;
  undeclared: number;
}
export interface WorkerDecision {
  decision: "approve" | "dismiss" | "done";
  note?: string;
  /** On approve: the done-when checks of the skill's playbooks the person confirmed */
  checks?: string[];
}
