/** Connection settings edited and tested from the Connectors page (ingestion service). Credentials are write-only. */
import { ingestionClient } from "@/lib/api-client";

export type ConnectionFieldKind = "text" | "url" | "secret" | "list" | "number" | "bool" | "select";

export interface ConnectionField {
  name: string;
  label: string;
  kind: ConnectionFieldKind;
  group: string;
  help: string;
  placeholder: string;
  required: boolean;
  options: string[];
  /** Never set for secrets. */
  value: string | number | boolean | null;
  secret_set: boolean;
  source: "hub" | "env" | "default";
}

export interface ConnectionOut {
  connector: string;
  display_name: string;
  registered: boolean;
  fields: ConnectionField[];
  updated_at: string | null;
  updated_by: string | null;
  can_store_secrets: boolean;
}

export interface ConnectionDraft {
  values: Record<string, string | number | boolean>;
  /** A new value, or null to go back to the environment's. */
  secrets: Record<string, string | null>;
  updated_by?: string;
}

export interface ConnectionTestResult {
  connector: string;
  ok: boolean;
  latency_ms: number;
  details: Record<string, unknown>;
  error: string | null;
  tested_at: string;
  draft: boolean;
}

const path = (name: string, rest: string) => `/api/v1/connectors/${encodeURIComponent(name)}/${rest}`;

export const connectionsApi = {
  get: (name: string) => ingestionClient.get<ConnectionOut>(path(name, "connection")),
  save: (name: string, draft: ConnectionDraft) => ingestionClient.put<ConnectionOut>(path(name, "connection"), draft),
  reset: (name: string) => ingestionClient.delete<ConnectionOut>(path(name, "connection")),
  test: (name: string, draft?: ConnectionDraft) => ingestionClient.post<ConnectionTestResult>(path(name, "test"), draft ?? null),
};
