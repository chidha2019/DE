/** Typed endpoint functions. Ingestion-service calls go through `ingestionClient`, everything else through `queryClientHttp`. */

import { INGESTION_BASE, QUERY_BASE, buildQuery, ingestionClient, queryClientHttp } from "@/lib/api-client";

import type {
  ErDiagram,
  WorkerDecision,
  WorkerItem,
  WorkerSnapshot,
  AnalystReport,
  ArchitectureReport,
  ConnectorCatalog,
  DashboardProvisionResult,
  GrafanaObservability,
  PlatformReport,
  QualityReport,
  BusinessModel,
  CatalogObject,
  CatalogObjectType,
  CatalogSort,
  SemanticCatalog,
  EnrichRequest,
  EnrichRun,
  EnrichmentDecision,
  EnrichmentSuggestion,
  EngineeringKpis,
  DocumentKind,
  GlossaryTerm,
  GlossaryAutoMapStatus,
  GlossaryCoverage,
  GlossaryDomainNode,
  GlossaryKpi,
  GlossaryKpiUpdate,
  GlossaryMapRequest,
  GlossaryMapRun,
  GlossaryTermCreate,
  GlossaryTermDetail,
  GlossaryTermRow,
  GlossaryTermUpdate,
  TermLink,
  TermLinkCreate,
  TermLinkDecision,
  TermLinkGroup,
  TermLinksDecisionResult,
  ProposeTermsRequest,
  TermDecision,
  TermDecisionResult,
  IntentAnswer,
  IntentCreate,
  IntentDecision,
  IntentFile,
  IntentRecord,
  IntentsConfig,
  JiraSyncResult,
  SemanticHealth,
  SemanticMetricRow,
  AuditRecord,
  ChunkOut,
  ConnectorInfo,
  DiscoveryResult,
  PipelineIn,
  PipelineOut,
  PipelineUpdate,
  PreviewRequest,
  PreviewResult,
  ContextRetrieveRequest,
  ContextRetrieveResponse,
  DocumentDetail,
  DocumentIngestResult,
  DocumentSummary,
  EntityListItem,
  EntitySearchHit,
  EntityType,
  GenieConversation,
  GenieConversationDetail,
  GenieMessage,
  GenieSpace,
  GenieSpaceIn,
  GenieSpaceUpdate,
  GenieStatus,
  GraphPayload,
  GraphStats,
  GraphSyncStatus,
  HealthStatus,
  IngestionRunOut,
  LatencySeries,
  ManualDocumentIn,
  OverviewStats,
  Page,
  ReconcileResult,
  RunActivityPoint,
  RunEventOut,
  RunStatus,
  SemanticAssetDetail,
  SemanticAssetSummary,
  SemanticExportFormat,
  SemanticGraph,
  SemanticOverview,
  SemanticSearchResponse,
  SourceSystem,
  TriggerRunRequest,
} from "@/api/types";

// ----------------------------------------------------------------------------- health
export const observabilityApi = {
  grafana: () => queryClientHttp.get<GrafanaObservability>("/api/v1/observability/grafana"),
  provisionDashboard: () => queryClientHttp.post<DashboardProvisionResult>("/api/v1/observability/grafana/dashboard", {}),
};

export const healthApi = {
  ingestion: () => ingestionClient.get<HealthStatus>("/health/ready"),
  query: () => queryClientHttp.get<HealthStatus>("/health/ready"),
};

// ----------------------------------------------------------------------------- stats (query service)
export interface LatencyParams {
  window_minutes?: number;
  bucket_seconds?: number;
  path_prefix?: string | null;
  source?: "memory" | "audit";
}

export const statsApi = {
  overview: () => queryClientHttp.get<OverviewStats>("/api/v1/stats/overview"),
  latency: (params: LatencyParams) => queryClientHttp.get<LatencySeries>("/api/v1/stats/latency", { ...params }),
  activity: (hours: number, bucket_minutes = 60) => queryClientHttp.get<RunActivityPoint[]>("/api/v1/stats/activity", { hours, bucket_minutes }),
  engineering: (days: number) => queryClientHttp.get<EngineeringKpis>("/api/v1/stats/engineering", { days }),
  quality: (days: number) => queryClientHttp.get<QualityReport>("/api/v1/stats/quality", { days }),
  analyst: (days: number) => queryClientHttp.get<AnalystReport>("/api/v1/stats/analyst", { days }),
  platform: (hours: number) => queryClientHttp.get<PlatformReport>("/api/v1/stats/platform", { hours }),
  architecture: () => queryClientHttp.get<ArchitectureReport>("/api/v1/stats/architecture"),
  audit: (limit = 50, action?: string, status?: string) => queryClientHttp.get<AuditRecord[]>("/api/v1/stats/audit", { limit, action, status }),
};

// ----------------------------------------------------------------------------- pipelines (ingestion service)
export interface RunListParams {
  status?: RunStatus | null;
  connector?: string | null;
  pipeline_id?: string | null;
  limit?: number;
  offset?: number;
}

export const pipelinesApi = {
  connectors: () => ingestionClient.get<ConnectorInfo[]>("/api/v1/connectors"),
  catalog: () => ingestionClient.get<ConnectorCatalog>("/api/v1/connectors/catalog"),
  runs: (params: RunListParams) => ingestionClient.get<Page<IngestionRunOut>>("/api/v1/pipelines/runs", { ...params }),
  run: (id: string) => ingestionClient.get<IngestionRunOut>(`/api/v1/pipelines/runs/${id}`),
  runEvents: (id: string, after_id = 0, limit = 200) => ingestionClient.get<RunEventOut[]>(`/api/v1/pipelines/runs/${id}/events`, { after_id, limit }),
  trigger: (body: TriggerRunRequest) => ingestionClient.post<IngestionRunOut>("/api/v1/pipelines/runs", body),
  // Saved pipelines on a connection
  discover: (connector: string, path: string[]) =>
    ingestionClient.get<DiscoveryResult>(`/api/v1/connectors/${encodeURIComponent(connector)}/discover`, { path }),
  list: (params: { connector?: string | null; search?: string | null } = {}) => ingestionClient.get<PipelineOut[]>("/api/v1/pipelines", { ...params }),
  get: (id: string) => ingestionClient.get<PipelineOut>(`/api/v1/pipelines/${id}`),
  create: (body: PipelineIn) => ingestionClient.post<PipelineOut>("/api/v1/pipelines", body),
  update: (id: string, body: PipelineUpdate) => ingestionClient.put<PipelineOut>(`/api/v1/pipelines/${id}`, body),
  remove: (id: string) => ingestionClient.delete(`/api/v1/pipelines/${id}`),
  runPipeline: (id: string) => ingestionClient.post<IngestionRunOut>(`/api/v1/pipelines/${id}/run`),
  setSchedule: (id: string, enabled: boolean) => ingestionClient.post<PipelineOut>(`/api/v1/pipelines/${id}/schedule`, { enabled }),
  preview: (body: PreviewRequest) => ingestionClient.post<PreviewResult>("/api/v1/pipelines/preview", body),
  pause: (id: string) => ingestionClient.post<IngestionRunOut>(`/api/v1/pipelines/runs/${id}/pause`),
  resume: (id: string) => ingestionClient.post<IngestionRunOut>(`/api/v1/pipelines/runs/${id}/resume`),
  cancel: (id: string) => ingestionClient.post<IngestionRunOut>(`/api/v1/pipelines/runs/${id}/cancel`),
  reconcileGraph: (limit = 500) => ingestionClient.post<ReconcileResult>(`/api/v1/admin/reconcile-graph?limit=${limit}`),
  /** Absolute URL for the EventSource (SSE) — EventSource cannot set headers so it needs a plain GET URL. */
  eventStreamUrl: (runId?: string | null, replay = 50) =>
    `${INGESTION_BASE}/api/v1/events/stream?replay=${replay}${runId ? `&run_id=${encodeURIComponent(runId)}` : ""}`,
};

// ----------------------------------------------------------------------------- documents
export interface DocumentListParams {
  source_system?: SourceSystem[] | null;
  search?: string | null;
  graph_sync_status?: GraphSyncStatus | null;
  kind?: DocumentKind | null;
  limit?: number;
  offset?: number;
}

export const documentsApi = {
  list: (params: DocumentListParams) => queryClientHttp.get<Page<DocumentSummary>>("/api/v1/documents", { ...params }),
  get: (id: string) => queryClientHttp.get<DocumentDetail>(`/api/v1/documents/${id}`),
  chunks: (id: string) => queryClientHttp.get<ChunkOut[]>(`/api/v1/documents/${id}/chunks`),
  graph: (id: string) => queryClientHttp.get<GraphPayload>(`/api/v1/documents/${id}/graph`),
  lineage: (id: string, depth = 3) => queryClientHttp.get<GraphPayload>(`/api/v1/documents/${id}/lineage`, { depth }),
  ingestManual: (body: ManualDocumentIn) => ingestionClient.post<DocumentIngestResult>("/api/v1/documents", body),
  delete: (id: string) => ingestionClient.delete(`/api/v1/documents/${id}`),
};

// ----------------------------------------------------------------------------- context
export const contextApi = {
  retrieve: (body: ContextRetrieveRequest) => queryClientHttp.post<ContextRetrieveResponse>("/api/v1/context/retrieve", body),
  retrieveUrl: () => `${QUERY_BASE}/api/v1/context/retrieve`,
};

// ----------------------------------------------------------------------------- graph
export const graphApi = {
  entities: (params: { entity_type?: EntityType | null; limit?: number; offset?: number }) =>
    queryClientHttp.get<EntityListItem[]>("/api/v1/graph/entities", { ...params }),
  search: (q: string, entity_type?: EntityType | null, limit = 20) =>
    queryClientHttp.get<EntitySearchHit[]>("/api/v1/graph/entities/search", { q, entity_type, limit }),
  neighborhood: (entity_key: string, max_documents = 25) => queryClientHttp.get<GraphPayload>("/api/v1/graph/neighborhood", { entity_key, max_documents }),
  stats: () => queryClientHttp.get<GraphStats>("/api/v1/graph/stats"),
  overview: () => queryClientHttp.get<GraphPayload>("/api/v1/graph/overview"),
};

// ----------------------------------------------------------------------------- genie
export const genieApi = {
  status: () => queryClientHttp.get<GenieStatus>("/api/v1/genie/status"),
  spaces: () => queryClientHttp.get<GenieSpace[]>("/api/v1/genie/spaces"),
  createSpace: (body: GenieSpaceIn) => queryClientHttp.post<GenieSpace>("/api/v1/genie/spaces", body),
  updateSpace: (id: string, body: GenieSpaceUpdate) => queryClientHttp.patch<GenieSpace>(`/api/v1/genie/spaces/${id}`, body),
  deleteSpace: (id: string) => queryClientHttp.delete(`/api/v1/genie/spaces/${id}`),
  conversations: (spaceId: string, limit = 50) => queryClientHttp.get<Page<GenieConversation>>(`/api/v1/genie/spaces/${spaceId}/conversations`, { limit }),
  conversation: (id: string) => queryClientHttp.get<GenieConversationDetail>(`/api/v1/genie/conversations/${id}`),
  deleteConversation: (id: string) => queryClientHttp.delete(`/api/v1/genie/conversations/${id}`),
  feedback: (messageId: string, value: 1 | -1 | null) => queryClientHttp.post<GenieMessage>(`/api/v1/genie/messages/${messageId}/feedback`, { value }),
  /** POST + SSE: read with `readSse` from `@/lib/sse` (EventSource cannot POST). */
  askUrl: (spaceId: string) => `${QUERY_BASE}/api/v1/genie/spaces/${spaceId}/ask`,
};

// ----------------------------------------------------------------------------- semantic layer
export interface SemanticMetricParams {
  search?: string | null;
  source?: "declared" | "inferred" | null;
  database?: string | null;
  schema?: string | null;
  limit?: number;
  offset?: number;
}

export interface GlossaryParams {
  search?: string | null;
  role?: string | null;
  limit?: number;
  offset?: number;
}

export interface BusinessModelParams {
  source_system?: SourceSystem | null;
  database?: string | null;
  schema?: string | null;
}

export interface SemanticAssetParams {
  search?: string | null;
  source_system?: SourceSystem | null;
  database?: string | null;
  schema?: string | null;
  asset_type?: string | null;
  kind?: string | null;
  limit?: number;
  offset?: number;
}

export interface CatalogObjectParams {
  domain?: string | null;
  /** Only objects placed in the domain itself, sub-domains apart. */
  direct?: boolean;
  type?: CatalogObjectType | null;
  model?: string | null;
  database?: string | null;
  /** A line-of-business key, or "__shared__". */
  lob?: string | null;
  sort?: CatalogSort;
  order?: "asc" | "desc";
  owner?: string | null;
  search?: string | null;
  min_quality?: number;
  limit?: number;
  offset?: number;
}

export interface SemanticExportParams {
  format: SemanticExportFormat;
  source_system?: SourceSystem | null;
  database?: string | null;
  schema?: string | null;
  asset_id?: string[] | null;
}

export const semanticApi = {
  overview: () => queryClientHttp.get<SemanticOverview>("/api/v1/semantic/overview"),
  assets: (params: SemanticAssetParams) => queryClientHttp.get<Page<SemanticAssetSummary>>("/api/v1/semantic/assets", { ...params }),
  asset: (id: string) => queryClientHttp.get<SemanticAssetDetail>(`/api/v1/semantic/assets/${id}`),
  graph: (id: string, depth = 1) => queryClientHttp.get<SemanticGraph>(`/api/v1/semantic/assets/${id}/graph`, { depth }),
  search: (q: string, limit = 20) => queryClientHttp.get<SemanticSearchResponse>("/api/v1/semantic/search", { q, limit }),
  metrics: (params: SemanticMetricParams) => queryClientHttp.get<Page<SemanticMetricRow>>("/api/v1/semantic/metrics", { ...params }),
  glossary: (params: GlossaryParams) => queryClientHttp.get<Page<GlossaryTerm>>("/api/v1/semantic/glossary", { ...params }),
  health: () => queryClientHttp.get<SemanticHealth>("/api/v1/semantic/health"),
  businessModel: (params: BusinessModelParams) => queryClientHttp.get<BusinessModel>("/api/v1/semantic/business-model", { ...params }),
  catalog: () => queryClientHttp.get<SemanticCatalog>("/api/v1/semantic/catalog"),
  catalogObjects: (params: CatalogObjectParams) => queryClientHttp.get<Page<CatalogObject>>("/api/v1/semantic/catalog/objects", { ...params }),
  enrich: (body: EnrichRequest) => queryClientHttp.post<EnrichRun>("/api/v1/semantic/enrich", body),
  enrichRun: (id: string) => queryClientHttp.get<EnrichRun>(`/api/v1/semantic/enrich/${id}`),
  enrichAsset: (id: string) => queryClientHttp.post<EnrichmentSuggestion>(`/api/v1/semantic/assets/${id}/enrich`, {}),
  decideEnrichment: (id: string, body: EnrichmentDecision) => queryClientHttp.post<SemanticAssetDetail>(`/api/v1/semantic/assets/${id}/enrichment`, body),
  /** A plain URL: the response carries Content-Disposition, so the browser downloads the file. */
  exportUrl: (params: SemanticExportParams) => `${QUERY_BASE}/api/v1/semantic/export${buildQuery({ ...params })}`,
};

// ----------------------------------------------------------------------------- business glossary
export interface GlossaryTermParams {
  search?: string | null;
  domain?: string | null;
  kind?: string | null;
  standard?: string | null;
  /** seeded | curated | proposed */
  status?: string | null;
  /** false hides candidate terms awaiting review */
  include_proposed?: boolean;
  limit?: number;
  offset?: number;
}
export interface TermLinkParams {
  status?: string | null;
  target_type?: string | null;
  target_id?: string | null;
  term_id?: string | null;
  asset_id?: string | null;
  /** proposed: links of candidate terms; reviewed: links of the accepted vocabulary */
  term_status?: string | null;
  limit?: number;
  offset?: number;
}

export const glossaryApi = {
  domains: () => queryClientHttp.get<GlossaryDomainNode[]>("/api/v1/glossary/domains"),
  coverage: () => queryClientHttp.get<GlossaryCoverage>("/api/v1/glossary/coverage"),
  terms: (params: GlossaryTermParams) => queryClientHttp.get<Page<GlossaryTermRow>>("/api/v1/glossary/terms", { ...params }),
  term: (id: string) => queryClientHttp.get<GlossaryTermDetail>(`/api/v1/glossary/terms/${id}`),
  createTerm: (body: GlossaryTermCreate) => queryClientHttp.post<GlossaryTermRow>("/api/v1/glossary/terms", body),
  updateTerm: (id: string, body: GlossaryTermUpdate) => queryClientHttp.patch<GlossaryTermRow>(`/api/v1/glossary/terms/${id}`, body),
  links: (params: TermLinkParams) => queryClientHttp.get<Page<TermLink>>("/api/v1/glossary/links", { ...params }),
  createLink: (body: TermLinkCreate) => queryClientHttp.post<TermLink>("/api/v1/glossary/links", body),
  decideLink: (id: string, body: TermLinkDecision) => queryClientHttp.post<TermLink>(`/api/v1/glossary/links/${id}/decide`, body),
  linkGroups: (params: TermLinkParams) => queryClientHttp.get<Page<TermLinkGroup>>("/api/v1/glossary/links/groups", { ...params }),
  decideMany: (body: { ids: string[]; decision: "accept" | "reject" }) =>
    queryClientHttp.post<TermLinksDecisionResult>("/api/v1/glossary/links/decide-many", body),
  kpis: (domain: string | null) => queryClientHttp.get<GlossaryKpi[]>("/api/v1/glossary/kpis", { domain }),
  updateKpi: (id: string, body: GlossaryKpiUpdate) => queryClientHttp.patch<GlossaryKpi>(`/api/v1/glossary/kpis/${id}`, body),
  map: (body: GlossaryMapRequest) => queryClientHttp.post<GlossaryMapRun>("/api/v1/glossary/map", body),
  mapRun: (id: string) => queryClientHttp.get<GlossaryMapRun>(`/api/v1/glossary/map/${id}`),
  mapRuns: () => queryClientHttp.get<GlossaryMapRun[]>("/api/v1/glossary/map"),
  autoMap: () => queryClientHttp.get<GlossaryAutoMapStatus>("/api/v1/glossary/auto-map"),
  proposeTerms: (body: ProposeTermsRequest) => queryClientHttp.post<GlossaryMapRun>("/api/v1/glossary/propose-terms", body),
  decideTerm: (id: string, body: TermDecision) => queryClientHttp.post<TermDecisionResult>(`/api/v1/glossary/terms/${id}/decide`, body),
};

// ----------------------------------------------------------------------------- intents
export interface IntentListParams {
  status?: string | null;
  limit?: number;
  offset?: number;
}

export const intentsApi = {
  config: () => queryClientHttp.get<IntentsConfig>("/api/v1/intents/config"),
  list: (params: IntentListParams) => queryClientHttp.get<Page<IntentRecord>>("/api/v1/intents", { ...params }),
  create: (body: IntentCreate) => queryClientHttp.post<IntentRecord>("/api/v1/intents", body),
  importJira: (issue: string) => queryClientHttp.post<IntentRecord>("/api/v1/intents/jira", { issue }),
  get: (id: string) => queryClientHttp.get<IntentRecord>(`/api/v1/intents/${id}`),
  files: (id: string) => queryClientHttp.get<IntentFile[]>(`/api/v1/intents/${id}/files`),
  diagram: (id: string) => queryClientHttp.get<ErDiagram>(`/api/v1/intents/${id}/er`),
  designDiagrams: () => queryClientHttp.get<ErDiagram[]>("/api/v1/intents/designs/er"),
  answer: (id: string, body: IntentAnswer) => queryClientHttp.post<IntentRecord>(`/api/v1/intents/${id}/answer`, body),
  decide: (id: string, body: IntentDecision) => queryClientHttp.post<IntentRecord>(`/api/v1/intents/${id}/decide`, body),
  replan: (id: string) => queryClientHttp.post<IntentRecord>(`/api/v1/intents/${id}/replan`, {}),
  validate: (id: string) => queryClientHttp.post<IntentRecord>(`/api/v1/intents/${id}/validate`, {}),
  run: (id: string) => queryClientHttp.post<IntentRecord>(`/api/v1/intents/${id}/run`, {}),
  sync: () => queryClientHttp.post<JiraSyncResult>("/api/v1/intents/sync", {}),
};

export const workerApi = {
  get: (worker: string) => queryClientHttp.get<WorkerSnapshot>(`/api/v1/worker/${worker}`),
  sweep: (worker: string) => queryClientHttp.post<WorkerSnapshot>(`/api/v1/worker/${worker}/sweep`, {}),
  pause: (worker: string, paused: boolean) => queryClientHttp.post<WorkerSnapshot>(`/api/v1/worker/${worker}/pause`, { paused }),
  decide: (worker: string, key: string, body: WorkerDecision) =>
    queryClientHttp.post<WorkerItem>(`/api/v1/worker/${worker}/items/${encodeURIComponent(key)}/decision`, body),
};
