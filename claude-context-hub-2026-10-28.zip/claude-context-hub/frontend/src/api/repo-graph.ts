/** Repository graphs for the Knowledge Hub: crawl a GitHub repository into a typed knowledge graph (ingestion service). */

import type { GraphNode, GraphPayload } from "@/api/types";
import { buildQuery, ingestionClient } from "@/lib/api-client";

export type RepoNodeKind =
  | "repository"
  | "file"
  | "symbol"
  | "pipeline"
  | "source_system"
  | "source"
  | "table"
  | "column"
  | "check"
  | "storage_integration"
  | "external_volume"
  | "stage"
  | "file_format"
  | "s3_location"
  | "ci_stage"
  | "alert";

export type CrawlStatus = "queued" | "running" | "completed" | "failed";

export interface RepoCrawlStats {
  nodes: number;
  edges: number;
  nodes_by_kind: Record<string, number>;
  edges_by_type: Record<string, number>;
  edges_by_method: Record<string, number>;
  lineage: { model_columns: number; traced: number; constant: number; failed: number };
  declared_vs_parsed: string[];
  tables_by_layer: Record<string, number>;
  written?: { nodes: number; edges: number; removed: number };
}

export interface RepoCrawl {
  id: string;
  repo: string;
  ref: string | null;
  sha: string | null;
  status: CrawlStatus;
  phase: string;
  files_total: number;
  files_read: number;
  stats: Partial<RepoCrawlStats>;
  warnings: string[];
  error: string | null;
  index_text: boolean;
  index_run_id: string | null;
  requested_by: string | null;
  created_at: string;
  started_at: string | null;
  finished_at: string | null;
}

export interface CrawledRepo {
  repo: string;
  ref: string | null;
  sha: string | null;
  url: string | null;
  description: string | null;
  crawled_at: string | null;
  crawl_id: string | null;
  files: number | null;
  counts: Record<string, number>;
  configured: boolean;
}

export interface RepoGraphRepos {
  crawled: CrawledRepo[];
  configured: string[];
}

export interface RepoNodeLink {
  type: string;
  outgoing: boolean;
  key: string;
  kind: RepoNodeKind | null;
  name: string | null;
  display: string | null;
  methods: string[];
  evidence: string[];
  role: string | null;
}

export interface RepoColumn {
  name: string;
  column: string;
  table: string;
  type?: string | null;
  position?: number | null;
  source_header?: string | null;
  is_key?: boolean;
  required?: boolean;
  derivation?: string | null;
  description?: string | null;
  inferred?: boolean;
  upstream: string[];
  origins: { name: string; header: string | null; table: string | null }[];
  used_by: string[];
}

export interface RepoNodeDetail {
  node: Record<string, unknown> & { kind: RepoNodeKind; name: string; node_key: string; display?: string; repo: string };
  links: RepoNodeLink[];
  columns: RepoColumn[];
  upstream: string[];
  downstream: string[];
  trace: { path: string[]; header: string | null }[];
}

export type RepoGraphPayload = GraphPayload & { truncated?: boolean };

export interface RepoCrawlRequest {
  repo: string;
  ref?: string | null;
  index_text?: boolean;
  requested_by?: string | null;
}

const BASE = "/api/v1/repo-graph";

export const repoGraphApi = {
  repos: () => ingestionClient.get<RepoGraphRepos>(`${BASE}/repos`),
  crawl: (body: RepoCrawlRequest) => ingestionClient.post<RepoCrawl>(`${BASE}/crawls`, body),
  crawls: (repo?: string | null, limit = 20) => ingestionClient.get<RepoCrawl[]>(`${BASE}/crawls`, { repo, limit }),
  graph: (repo: string, view: "all" | "lineage", kinds?: string[] | null) =>
    ingestionClient.get<RepoGraphPayload>(`${BASE}/graph`, { repo, view, kinds: kinds?.length ? kinds.join(",") : null }),
  node: (key: string) => ingestionClient.get<RepoNodeDetail>(`${BASE}/node`, { key }),
  search: (repo: string, q: string) => ingestionClient.get<GraphNode[]>(`${BASE}/search`, { repo, q, limit: 15 }),
  remove: (repo: string) => ingestionClient.delete<{ deleted_nodes: number }>(`${BASE}/repos${buildQuery({ repo })}`),
};

/** node_key is "<owner/name>|<kind>|<name>". */
export function nodeKey(repo: string, kind: RepoNodeKind, name: string): string {
  return `${repo}|${kind}|${name}`;
}

export function kindOfKey(key: string): RepoNodeKind | null {
  const parts = key.split("|");
  return parts.length >= 3 ? (parts[1] as RepoNodeKind) : null;
}

export function nameOfKey(key: string): string {
  const parts = key.split("|");
  return parts.length >= 3 ? parts.slice(2).join("|") : key;
}
