/** React Query hooks — the only place components talk to the API layer. */

import { keepPreviousData, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect } from "react";

import {
  type BusinessModelParams,
  type CatalogObjectParams,
  contextApi,
  documentsApi,
  genieApi,
  glossaryApi,
  graphApi,
  intentsApi,
  healthApi,
  pipelinesApi,
  semanticApi,
  statsApi,
  workerApi,
  type DocumentListParams,
  type LatencyParams,
  type RunListParams,
  type GlossaryParams,
  type GlossaryTermParams,
  type IntentListParams,
  type SemanticAssetParams,
  type SemanticMetricParams,
  type TermLinkParams,
} from "@/api/endpoints";
import type {
  WorkerDecision,
  ContextRetrieveRequest,
  PipelineIn,
  PipelineUpdate,
  EnrichRequest,
  EnrichmentDecision,
  EntityType,
  GenieSpaceIn,
  GenieSpaceUpdate,
  GlossaryKpiUpdate,
  GlossaryMapRequest,
  GlossaryTermCreate,
  GlossaryTermUpdate,
  IntentCreate,
  IntentDecision,
  ProposeTermsRequest,
  TermDecision,
  TermLinkCreate,
  TermLinkDecision,
  TriggerRunRequest,
} from "@/api/types";
import { queryKeys } from "@/lib/query-client";

// ----------------------------------------------------------------------------- health & stats
export function useServiceHealth(service: "ingestion" | "query") {
  return useQuery({
    queryKey: queryKeys.health(service),
    queryFn: () => (service === "ingestion" ? healthApi.ingestion() : healthApi.query()),
    refetchInterval: 20_000,
    retry: false,
  });
}

export function useOverview() {
  return useQuery({ queryKey: queryKeys.overview, queryFn: statsApi.overview, refetchInterval: 15_000 });
}

export function useLatency(params: LatencyParams) {
  return useQuery({
    queryKey: queryKeys.latency(params),
    queryFn: () => statsApi.latency(params),
    refetchInterval: 10_000,
    placeholderData: keepPreviousData,
  });
}

export function useActivity(hours = 24, bucketMinutes = 60) {
  return useQuery({
    queryKey: queryKeys.activity(hours, bucketMinutes),
    queryFn: () => statsApi.activity(hours, bucketMinutes),
    refetchInterval: 30_000,
  });
}

export function useEngineeringKpis(days = 7, opts: { enabled?: boolean } = {}) {
  return useQuery({ queryKey: queryKeys.engineering(days), queryFn: () => statsApi.engineering(days), refetchInterval: 60_000, enabled: opts.enabled ?? true });
}

export function useAudit(limit = 25, action?: string, status?: string) {
  return useQuery({ queryKey: queryKeys.audit(limit, action, status), queryFn: () => statsApi.audit(limit, action, status), refetchInterval: 15_000 });
}

export function useQualityReport(days = 7, opts: { enabled?: boolean } = {}) {
  return useQuery({ queryKey: queryKeys.quality(days), queryFn: () => statsApi.quality(days), refetchInterval: 60_000, enabled: opts.enabled ?? true });
}

export function useAnalystReport(days = 7, opts: { enabled?: boolean } = {}) {
  return useQuery({ queryKey: queryKeys.analyst(days), queryFn: () => statsApi.analyst(days), refetchInterval: 60_000, enabled: opts.enabled ?? true });
}

export function usePlatformReport(hours = 24, opts: { enabled?: boolean } = {}) {
  return useQuery({ queryKey: queryKeys.platform(hours), queryFn: () => statsApi.platform(hours), refetchInterval: 30_000, enabled: opts.enabled ?? true });
}

export function useArchitectureReport() {
  return useQuery({ queryKey: queryKeys.architecture, queryFn: statsApi.architecture, refetchInterval: 60_000 });
}

// ----------------------------------------------------------------------------- pipelines
export function useConnectors() {
  return useQuery({ queryKey: queryKeys.connectors, queryFn: pipelinesApi.connectors, refetchInterval: 60_000 });
}

/** Every connector the hub knows, configured or planned, with health, last run and document counts. */
export function useConnectorCatalog() {
  return useQuery({ queryKey: [...queryKeys.connectors, "catalog"], queryFn: pipelinesApi.catalog, refetchInterval: 60_000 });
}

export function useRuns(params: RunListParams) {
  return useQuery({
    queryKey: queryKeys.runs(params),
    queryFn: () => pipelinesApi.runs(params),
    refetchInterval: 5_000,
    placeholderData: keepPreviousData,
  });
}

export function useRun(id: string | null) {
  return useQuery({
    queryKey: queryKeys.run(id ?? ""),
    queryFn: () => pipelinesApi.run(id as string),
    enabled: Boolean(id),
    refetchInterval: 4_000,
  });
}

export function useRunEventsHistory(id: string | null) {
  return useQuery({
    queryKey: queryKeys.runEvents(id ?? ""),
    queryFn: () => pipelinesApi.runEvents(id as string),
    enabled: Boolean(id),
  });
}

export function useTriggerRun() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: TriggerRunRequest) => pipelinesApi.trigger(body),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["runs"] });
      void qc.invalidateQueries({ queryKey: queryKeys.overview });
    },
  });
}

export function useRunControl() {
  const qc = useQueryClient();
  const invalidate = () => {
    void qc.invalidateQueries({ queryKey: ["runs"] });
  };
  const pause = useMutation({ mutationFn: pipelinesApi.pause, onSuccess: invalidate });
  const resume = useMutation({ mutationFn: pipelinesApi.resume, onSuccess: invalidate });
  const cancel = useMutation({ mutationFn: pipelinesApi.cancel, onSuccess: invalidate });
  return { pause, resume, cancel, busy: pause.isPending || resume.isPending || cancel.isPending };
}

// ----------------------------------------------------------------------------- saved pipelines
export function usePipelines(params: { connector?: string | null; search?: string | null } = {}) {
  return useQuery({
    queryKey: queryKeys.pipelines(params),
    queryFn: () => pipelinesApi.list(params),
    refetchInterval: 5_000,
    placeholderData: keepPreviousData,
  });
}

export function usePipeline(id: string | null) {
  return useQuery({
    queryKey: queryKeys.pipeline(id ?? ""),
    queryFn: () => pipelinesApi.get(id as string),
    enabled: Boolean(id),
    refetchInterval: 5_000,
    retry: false,
  });
}

/** Children of a node in the source hierarchy, read live from the connection (cached for two minutes). */
export function useDiscover(connector: string | null, path: string[], enabled = true) {
  return useQuery({
    queryKey: queryKeys.discover(connector ?? "", path),
    queryFn: () => pipelinesApi.discover(connector as string, path),
    enabled: Boolean(connector) && enabled,
    staleTime: 120_000,
    retry: false,
  });
}

function useRefreshPipelines() {
  const qc = useQueryClient();
  return () => {
    void qc.invalidateQueries({ queryKey: ["pipelines"] });
    void qc.invalidateQueries({ queryKey: ["runs"] });
    void qc.invalidateQueries({ queryKey: queryKeys.overview });
  };
}

export function useCreatePipeline() {
  const refresh = useRefreshPipelines();
  return useMutation({ mutationFn: (body: PipelineIn) => pipelinesApi.create(body), onSuccess: refresh });
}

export function useUpdatePipeline() {
  const refresh = useRefreshPipelines();
  return useMutation({ mutationFn: (input: { id: string; body: PipelineUpdate }) => pipelinesApi.update(input.id, input.body), onSuccess: refresh });
}

export function useDeletePipeline() {
  const refresh = useRefreshPipelines();
  return useMutation({ mutationFn: (id: string) => pipelinesApi.remove(id), onSuccess: refresh });
}

export function useRunPipeline() {
  const refresh = useRefreshPipelines();
  return useMutation({ mutationFn: (id: string) => pipelinesApi.runPipeline(id), onSuccess: refresh });
}

export function useToggleSchedule() {
  const refresh = useRefreshPipelines();
  return useMutation({ mutationFn: (input: { id: string; enabled: boolean }) => pipelinesApi.setSchedule(input.id, input.enabled), onSuccess: refresh });
}

export function useReconcileGraph() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () => pipelinesApi.reconcileGraph(),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["documents"] });
      void qc.invalidateQueries({ queryKey: queryKeys.overview });
    },
  });
}

// ----------------------------------------------------------------------------- documents
export function useDocuments(params: DocumentListParams) {
  return useQuery({
    queryKey: queryKeys.documents(params),
    queryFn: () => documentsApi.list(params),
    placeholderData: keepPreviousData,
    refetchInterval: 20_000,
  });
}

export function useDocument(id: string | null) {
  return useQuery({ queryKey: queryKeys.document(id ?? ""), queryFn: () => documentsApi.get(id as string), enabled: Boolean(id) });
}

export function useDocumentChunks(id: string | null) {
  return useQuery({ queryKey: queryKeys.documentChunks(id ?? ""), queryFn: () => documentsApi.chunks(id as string), enabled: Boolean(id) });
}

export function useDocumentGraph(id: string | null) {
  return useQuery({ queryKey: queryKeys.documentGraph(id ?? ""), queryFn: () => documentsApi.graph(id as string), enabled: Boolean(id), retry: false });
}

export function useDocumentLineage(id: string | null, depth: number) {
  return useQuery({
    queryKey: queryKeys.documentLineage(id ?? "", depth),
    queryFn: () => documentsApi.lineage(id as string, depth),
    enabled: Boolean(id),
    retry: false,
  });
}

// ----------------------------------------------------------------------------- graph
export function useEntities(entity_type: EntityType | null, limit = 50) {
  return useQuery({ queryKey: queryKeys.entities({ entity_type, limit }), queryFn: () => graphApi.entities({ entity_type, limit }) });
}

export function useEntitySearch(q: string, entity_type: EntityType | null) {
  const trimmed = q.trim();
  return useQuery({
    queryKey: queryKeys.entitySearch(trimmed, entity_type),
    queryFn: () => graphApi.search(trimmed, entity_type),
    enabled: trimmed.length >= 2,
    placeholderData: keepPreviousData,
  });
}

export function useEntityNeighborhood(key: string | null) {
  return useQuery({
    queryKey: queryKeys.entityNeighborhood(key ?? ""),
    queryFn: () => graphApi.neighborhood(key as string),
    enabled: Boolean(key),
    retry: false,
  });
}

export function useGraphStats() {
  return useQuery({ queryKey: queryKeys.graphStats, queryFn: graphApi.stats, refetchInterval: 30_000 });
}

/** Every document with the entities most of them share and the links between them (Knowledge Hub map). */
export function useKnowledgeMap(enabled = true) {
  return useQuery({ queryKey: ["graph", "overview"], queryFn: graphApi.overview, enabled, staleTime: 30_000 });
}

// ----------------------------------------------------------------------------- context
export function useRetrieveContext() {
  return useMutation({ mutationFn: (body: ContextRetrieveRequest) => contextApi.retrieve(body) });
}

// ----------------------------------------------------------------------------- genie
export function useGenieStatus() {
  return useQuery({ queryKey: queryKeys.genieStatus, queryFn: genieApi.status, refetchInterval: 30_000, retry: false });
}

export function useGenieSpaces() {
  return useQuery({ queryKey: queryKeys.genieSpaces, queryFn: genieApi.spaces });
}

export function useCreateGenieSpace() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: GenieSpaceIn) => genieApi.createSpace(body),
    onSuccess: () => void qc.invalidateQueries({ queryKey: queryKeys.genieSpaces }),
  });
}

export function useUpdateGenieSpace() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, body }: { id: string; body: GenieSpaceUpdate }) => genieApi.updateSpace(id, body),
    onSuccess: () => void qc.invalidateQueries({ queryKey: queryKeys.genieSpaces }),
  });
}

export function useDeleteGenieSpace() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => genieApi.deleteSpace(id),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: queryKeys.genieSpaces });
      void qc.invalidateQueries({ queryKey: ["genie", "conversations"] });
    },
  });
}

export function useGenieConversations(spaceId: string | null) {
  return useQuery({
    queryKey: queryKeys.genieConversations(spaceId ?? ""),
    queryFn: () => genieApi.conversations(spaceId as string),
    enabled: Boolean(spaceId),
    placeholderData: keepPreviousData,
  });
}

export function useGenieConversation(id: string | null) {
  return useQuery({
    queryKey: queryKeys.genieConversation(id ?? ""),
    queryFn: () => genieApi.conversation(id as string),
    enabled: Boolean(id),
    retry: false,
  });
}

export function useDeleteGenieConversation() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => genieApi.deleteConversation(id),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["genie", "conversations"] });
      void qc.invalidateQueries({ queryKey: queryKeys.genieSpaces });
    },
  });
}

// ----------------------------------------------------------------------------- semantic layer
export function useSemanticOverview() {
  return useQuery({ queryKey: queryKeys.semanticOverview, queryFn: semanticApi.overview, refetchInterval: 30_000 });
}

export function useSemanticAssets(params: SemanticAssetParams, enabled = true) {
  return useQuery({
    queryKey: queryKeys.semanticAssets(params),
    queryFn: () => semanticApi.assets(params),
    placeholderData: keepPreviousData,
    enabled,
  });
}

export function useSemanticAsset(id: string | null) {
  return useQuery({
    queryKey: queryKeys.semanticAsset(id ?? ""),
    queryFn: () => semanticApi.asset(id as string),
    enabled: Boolean(id),
    retry: false,
  });
}

export function useSemanticGraph(id: string | null, depth = 1) {
  return useQuery({
    queryKey: queryKeys.semanticGraph(id ?? "", depth),
    queryFn: () => semanticApi.graph(id as string, depth),
    enabled: Boolean(id),
  });
}

export function useSemanticSearch(q: string) {
  const trimmed = q.trim();
  return useQuery({
    queryKey: queryKeys.semanticSearch(trimmed),
    queryFn: () => semanticApi.search(trimmed),
    enabled: trimmed.length >= 2,
    placeholderData: keepPreviousData,
  });
}

export function useSemanticMetrics(params: SemanticMetricParams) {
  return useQuery({
    queryKey: queryKeys.semanticMetrics(params),
    queryFn: () => semanticApi.metrics(params),
    placeholderData: keepPreviousData,
  });
}

export function useSemanticGlossary(params: GlossaryParams) {
  return useQuery({
    queryKey: queryKeys.semanticGlossary(params),
    queryFn: () => semanticApi.glossary(params),
    placeholderData: keepPreviousData,
  });
}

export function useSemanticHealth() {
  return useQuery({ queryKey: queryKeys.semanticHealth, queryFn: semanticApi.health, refetchInterval: 60_000 });
}

export function useBusinessModel(params: BusinessModelParams) {
  return useQuery({
    queryKey: queryKeys.semanticModel(params),
    queryFn: () => semanticApi.businessModel(params),
    placeholderData: keepPreviousData,
  });
}

export function useSemanticCatalog() {
  return useQuery({ queryKey: queryKeys.semanticCatalog, queryFn: semanticApi.catalog, refetchInterval: 60_000 });
}

export function useCatalogObjects(params: CatalogObjectParams, enabled = true) {
  return useQuery({
    queryKey: queryKeys.semanticCatalogObjects(params),
    queryFn: () => semanticApi.catalogObjects(params),
    placeholderData: keepPreviousData,
    enabled,
  });
}

export function useEnrichScope() {
  return useMutation({ mutationFn: (body: EnrichRequest) => semanticApi.enrich(body) });
}

/** Polls a running enrichment and refreshes every semantic query once it has finished. */
export function useEnrichRun(id: string | null) {
  const qc = useQueryClient();
  const query = useQuery({
    queryKey: queryKeys.enrichRun(id ?? ""),
    queryFn: () => semanticApi.enrichRun(id as string),
    enabled: Boolean(id),
    refetchInterval: (q) => (q.state.data?.status === "running" ? 2000 : false),
  });
  const status = query.data?.status;
  useEffect(() => {
    if (status && status !== "running") void qc.invalidateQueries({ queryKey: ["semantic"] });
  }, [status, qc]);
  return query;
}

export function useEnrichAsset() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => semanticApi.enrichAsset(id),
    onSuccess: (_suggestion, id) => void qc.invalidateQueries({ queryKey: queryKeys.semanticAsset(id) }),
  });
}

export function useDecideEnrichment() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, body }: { id: string; body: EnrichmentDecision }) => semanticApi.decideEnrichment(id, body),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["semantic"] }),
  });
}

export function useGenieFeedback() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ messageId, value }: { messageId: string; value: 1 | -1 | null }) => genieApi.feedback(messageId, value),
    onSuccess: (message) => void qc.invalidateQueries({ queryKey: queryKeys.genieConversation(message.conversation_id) }),
  });
}

// ----------------------------------------------------------------------------- business glossary

export function useGlossaryDomains() {
  return useQuery({ queryKey: queryKeys.glossaryDomains, queryFn: glossaryApi.domains, refetchInterval: 60_000 });
}

export function useGlossaryCoverage() {
  return useQuery({ queryKey: queryKeys.glossaryCoverage, queryFn: glossaryApi.coverage, refetchInterval: 30_000 });
}

export function useGlossaryTerms(params: GlossaryTermParams, refetchInterval: number | false = false) {
  return useQuery({ queryKey: queryKeys.glossaryTerms(params), queryFn: () => glossaryApi.terms(params), placeholderData: keepPreviousData, refetchInterval });
}

export function useGlossaryTerm(id: string | null) {
  return useQuery({ queryKey: queryKeys.glossaryTerm(id ?? ""), queryFn: () => glossaryApi.term(id as string), enabled: Boolean(id) });
}

export function useTermLinks(params: TermLinkParams, refetchInterval: number | false = false) {
  return useQuery({ queryKey: queryKeys.glossaryLinks(params), queryFn: () => glossaryApi.links(params), placeholderData: keepPreviousData, refetchInterval });
}

/** The review queue grouped by term and column name: one decision can cover a column in every table. */
export function useTermLinkGroups(params: TermLinkParams, refetchInterval: number | false = false) {
  return useQuery({
    queryKey: queryKeys.glossaryLinkGroups(params),
    queryFn: () => glossaryApi.linkGroups(params),
    placeholderData: keepPreviousData,
    refetchInterval,
  });
}

export function useDecideTermLinks() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: { ids: string[]; decision: "accept" | "reject" }) => glossaryApi.decideMany(body),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["glossary"] });
      void qc.invalidateQueries({ queryKey: ["semantic"] });
    },
  });
}

export function useGlossaryKpis(domain: string | null) {
  return useQuery({ queryKey: queryKeys.glossaryKpis(domain), queryFn: () => glossaryApi.kpis(domain), placeholderData: keepPreviousData });
}

export function useCreateTerm() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: GlossaryTermCreate) => glossaryApi.createTerm(body),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["glossary"] }),
  });
}

export function useUpdateTerm() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, body }: { id: string; body: GlossaryTermUpdate }) => glossaryApi.updateTerm(id, body),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["glossary"] }),
  });
}

/** Accepting copies the term's synonyms onto the column or metric and places the dataset, so semantic views refresh too. */
export function useDecideTermLink() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, body }: { id: string; body: TermLinkDecision }) => glossaryApi.decideLink(id, body),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["glossary"] });
      void qc.invalidateQueries({ queryKey: ["semantic"] });
    },
  });
}

export function useCreateTermLink() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: TermLinkCreate) => glossaryApi.createLink(body),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["glossary"] });
      void qc.invalidateQueries({ queryKey: ["semantic"] });
    },
  });
}

export function useUpdateKpi() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, body }: { id: string; body: GlossaryKpiUpdate }) => glossaryApi.updateKpi(id, body),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["glossary"] }),
  });
}

export function useGlossaryMap() {
  return useMutation({ mutationFn: (body: GlossaryMapRequest) => glossaryApi.map(body) });
}

export function useProposeTerms() {
  return useMutation({ mutationFn: (body: ProposeTermsRequest) => glossaryApi.proposeTerms(body) });
}

/** Accepting a proposed term adds it to the vocabulary (and optionally its links); rejecting deletes it with its links. */
export function useDecideTerm() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, body }: { id: string; body: TermDecision }) => glossaryApi.decideTerm(id, body),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["glossary"] });
      void qc.invalidateQueries({ queryKey: ["semantic"] });
    },
  });
}

// ----------------------------------------------------------------------------- intents

const INTENT_BUSY = new Set(["received", "planning", "modeling", "approved", "coding", "running"]);

export function useIntentsConfig() {
  return useQuery({ queryKey: queryKeys.intentsConfig, queryFn: intentsApi.config, refetchInterval: 60_000 });
}

export function useIntents(params: IntentListParams) {
  return useQuery({ queryKey: queryKeys.intents(params), queryFn: () => intentsApi.list(params), placeholderData: keepPreviousData, refetchInterval: 10_000 });
}

export function useIntent(id: string | null) {
  return useQuery({
    queryKey: queryKeys.intent(id ?? ""),
    queryFn: () => intentsApi.get(id as string),
    enabled: Boolean(id),
    refetchInterval: (q) => (q.state.data && INTENT_BUSY.has(q.state.data.status) ? 3000 : 15_000),
  });
}

export function useIntentDiagram(id: string | null, enabled = true) {
  return useQuery({ queryKey: queryKeys.intentDiagram(id ?? ""), queryFn: () => intentsApi.diagram(id as string), enabled: Boolean(id) && enabled });
}

export function useDesignDiagrams() {
  return useQuery({ queryKey: queryKeys.designDiagrams, queryFn: intentsApi.designDiagrams, staleTime: 60_000 });
}

export function useIntentFiles(id: string | null, enabled: boolean) {
  return useQuery({ queryKey: queryKeys.intentFiles(id ?? ""), queryFn: () => intentsApi.files(id as string), enabled: Boolean(id) && enabled });
}

function useIntentMutation<TInput, TResult>(fn: (input: TInput) => Promise<TResult>) {
  const qc = useQueryClient();
  return useMutation({ mutationFn: fn, onSuccess: () => void qc.invalidateQueries({ queryKey: ["intents"] }) });
}

export function useCreateIntent() {
  return useIntentMutation((body: IntentCreate) => intentsApi.create(body));
}

export function useImportJira() {
  return useIntentMutation((issue: string) => intentsApi.importJira(issue));
}

export function useAnswerIntent() {
  return useIntentMutation(({ id, answers }: { id: string; answers: string[] }) => intentsApi.answer(id, { answers }));
}

export function useDecideIntent() {
  return useIntentMutation(({ id, body }: { id: string; body: IntentDecision }) => intentsApi.decide(id, body));
}

export function useReplanIntent() {
  return useIntentMutation((id: string) => intentsApi.replan(id));
}

export function useRevalidateIntent() {
  return useIntentMutation((id: string) => intentsApi.validate(id));
}

export function useRunIntent() {
  return useIntentMutation((id: string) => intentsApi.run(id));
}

export function useSyncJira() {
  return useIntentMutation(() => intentsApi.sync());
}

/** Mapping after every successful sync: the latest passes, and the live run while one is mapping. */
export function useGlossaryAutoMap() {
  const qc = useQueryClient();
  const status = useQuery({
    queryKey: queryKeys.glossaryAutoMap,
    queryFn: () => glossaryApi.autoMap(),
    refetchInterval: (q) => (q.state.data?.runs[0]?.status === "running" ? 3000 : 20_000),
  });
  const running = status.data?.runs[0]?.status === "running";
  const runs = useQuery({
    queryKey: queryKeys.glossaryMapRuns,
    queryFn: () => glossaryApi.mapRuns(),
    enabled: running,
    refetchInterval: running ? 2500 : false,
  });
  const live = running ? ((runs.data ?? []).find((r) => r.trigger === "sync" && r.status === "running") ?? null) : null;
  const latest = status.data?.runs[0];
  const marker = latest ? `${latest.id}:${latest.status}:${live ? live.done + live.rule_links + live.model_links : ""}` : "";
  useEffect(() => {
    if (!marker) return;
    void qc.invalidateQueries({ queryKey: ["glossary", "links"] });
    void qc.invalidateQueries({ queryKey: queryKeys.glossaryCoverage });
  }, [marker, qc]);
  return { status: status.data, live };
}

/** Polls a mapping run; proposals land while it runs, so the queue and coverage refresh as it goes. */
export function useGlossaryMapRun(id: string | null) {
  const qc = useQueryClient();
  const query = useQuery({
    queryKey: queryKeys.glossaryMapRun(id ?? ""),
    queryFn: () => glossaryApi.mapRun(id as string),
    enabled: Boolean(id),
    refetchInterval: (q) => (q.state.data?.status === "running" ? 2000 : false),
  });
  const status = query.data?.status;
  const progress = (query.data?.done ?? 0) + (query.data?.rule_links ?? 0) + (query.data?.model_links ?? 0) + (query.data?.terms_proposed ?? 0);
  useEffect(() => {
    if (!status) return;
    void qc.invalidateQueries({ queryKey: ["glossary", "links"] });
    void qc.invalidateQueries({ queryKey: ["glossary", "terms"] });
    void qc.invalidateQueries({ queryKey: queryKeys.glossaryCoverage });
    if (status !== "running") void qc.invalidateQueries({ queryKey: ["glossary"] });
  }, [status, progress, qc]);
  return query;
}

// --------------------------------------------------------------------------- digital worker
/** The worker's live state: polled every few seconds so new findings and journal entries arrive on their own. */
export function useWorker(worker: string) {
  return useQuery({ queryKey: queryKeys.worker(worker), queryFn: () => workerApi.get(worker), refetchInterval: 4_000 });
}

function useWorkerMutation<T>(worker: string, fn: (arg: T) => Promise<unknown>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: fn,
    onSettled: () => {
      void qc.invalidateQueries({ queryKey: queryKeys.worker(worker) });
      void qc.invalidateQueries({ queryKey: ["intents"] });
      void qc.invalidateQueries({ queryKey: ["runs"] });
    },
  });
}

export function useWorkerDecision(worker: string) {
  return useWorkerMutation(worker, (args: { key: string; decision: WorkerDecision["decision"]; note?: string; checks?: string[] }) =>
    workerApi.decide(worker, args.key, { decision: args.decision, note: args.note, checks: args.checks }),
  );
}

export function useWorkerSweep(worker: string) {
  return useWorkerMutation(worker, () => workerApi.sweep(worker));
}

export function useWorkerPause(worker: string) {
  return useWorkerMutation(worker, (paused: boolean) => workerApi.pause(worker, paused));
}
