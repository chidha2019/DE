import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { connectionsApi, type ConnectionDraft } from "@/api/connections";
import { queryKeys } from "@/lib/query-client";

export const connectionKeys = {
  one: (name: string) => ["connections", name] as const,
};

export function useConnection(name: string | null) {
  // No background refetch: the editor rebuilds its form whenever this data changes.
  return useQuery({
    queryKey: connectionKeys.one(name ?? ""),
    queryFn: () => connectionsApi.get(name as string),
    enabled: Boolean(name),
    staleTime: Infinity,
    refetchOnWindowFocus: false,
  });
}

/** Saving or resetting changes the live adapter, so the catalogue (health, source) is refetched too. */
function useRefresh(name: string) {
  const qc = useQueryClient();
  return () => {
    void qc.invalidateQueries({ queryKey: connectionKeys.one(name) });
    void qc.invalidateQueries({ queryKey: queryKeys.connectors });
  };
}

export function useSaveConnection(name: string) {
  const refresh = useRefresh(name);
  return useMutation({
    mutationFn: (draft: ConnectionDraft) => connectionsApi.save(name, draft),
    onSuccess: refresh,
  });
}

export function useResetConnection(name: string) {
  const refresh = useRefresh(name);
  return useMutation({
    mutationFn: () => connectionsApi.reset(name),
    onSuccess: refresh,
  });
}

export function useTestConnection(name: string) {
  return useMutation({
    mutationFn: (draft?: ConnectionDraft) => connectionsApi.test(name, draft),
  });
}
