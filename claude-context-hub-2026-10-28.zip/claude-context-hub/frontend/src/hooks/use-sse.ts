/**
 * Live pipeline events over Server-Sent Events.
 *
 * Keeps a bounded in-memory log, tracks connection state and nudges React Query
 * to refetch run lists (throttled) so tables update without manual polling.
 */

import { useQueryClient } from "@tanstack/react-query";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import { pipelinesApi } from "@/api/endpoints";
import type { RunEvent } from "@/api/types";

export type SseState = "connecting" | "open" | "reconnecting" | "closed";

export interface UseRunEventStreamOptions {
  runId?: string | null;
  maxEvents?: number;
  enabled?: boolean;
}

export interface RunEventStream {
  events: RunEvent[];
  latestByRun: Record<string, RunEvent>;
  state: SseState;
  clear: () => void;
}

const INVALIDATE_THROTTLE_MS = 1000;

export function useRunEventStream({ runId = null, maxEvents = 400, enabled = true }: UseRunEventStreamOptions = {}): RunEventStream {
  const qc = useQueryClient();
  const [events, setEvents] = useState<RunEvent[]>([]);
  const [latestByRun, setLatestByRun] = useState<Record<string, RunEvent>>({});
  const [state, setState] = useState<SseState>("connecting");
  const lastInvalidate = useRef(0);
  const timer = useRef<number | null>(null);

  const scheduleInvalidate = useCallback(() => {
    const now = Date.now();
    const run = () => {
      lastInvalidate.current = Date.now();
      void qc.invalidateQueries({ queryKey: ["runs"] });
      void qc.invalidateQueries({ queryKey: ["pipelines"] });
      void qc.invalidateQueries({ queryKey: ["stats", "overview"] });
    };
    if (now - lastInvalidate.current >= INVALIDATE_THROTTLE_MS) {
      run();
    } else if (timer.current === null) {
      timer.current = window.setTimeout(() => {
        timer.current = null;
        run();
      }, INVALIDATE_THROTTLE_MS);
    }
  }, [qc]);

  useEffect(() => {
    if (!enabled) {
      setState("closed");
      return;
    }
    const url = pipelinesApi.eventStreamUrl(runId);
    const source = new EventSource(url);
    setState("connecting");

    const handle = (raw: MessageEvent<string>) => {
      let event: RunEvent;
      try {
        event = JSON.parse(raw.data) as RunEvent;
      } catch {
        return;
      }
      setEvents((prev) => {
        const next = prev.length >= maxEvents ? prev.slice(prev.length - maxEvents + 1) : prev.slice();
        next.push(event);
        return next;
      });
      setLatestByRun((prev) => ({ ...prev, [event.run_id]: event }));
      if (event.event_type.startsWith("run.") || event.event_type === "document.failed") scheduleInvalidate();
    };

    // The server names events by type; listen to the known families + the default channel.
    const types = [
      "message",
      "run.started", "run.progress", "run.paused", "run.resumed", "run.cancelling", "run.completed", "run.failed", "run.cancelled",
      "document.upserted", "document.skipped", "document.failed", "graph.failed",
    ];
    types.forEach((t) => source.addEventListener(t, handle as EventListener));
    source.onopen = () => setState("open");
    source.onerror = () => setState(source.readyState === EventSource.CLOSED ? "closed" : "reconnecting");

    return () => {
      types.forEach((t) => source.removeEventListener(t, handle as EventListener));
      source.close();
      if (timer.current !== null) {
        window.clearTimeout(timer.current);
        timer.current = null;
      }
    };
  }, [enabled, runId, maxEvents, scheduleInvalidate]);

  const clear = useCallback(() => {
    setEvents([]);
  }, []);

  return useMemo(() => ({ events, latestByRun, state, clear }), [events, latestByRun, state, clear]);
}
