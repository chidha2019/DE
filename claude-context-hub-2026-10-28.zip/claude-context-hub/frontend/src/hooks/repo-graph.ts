import { keepPreviousData, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { repoGraphApi, type RepoCrawl, type RepoCrawlRequest } from "@/api/repo-graph";

const BUSY = new Set<RepoCrawl["status"]>(["queued", "running"]);

export const repoGraphKeys = {
  all: ["repo-graph"] as const,
  repos: ["repo-graph", "repos"] as const,
  crawls: (repo: string | null) => ["repo-graph", "crawls", repo] as const,
  graph: (repo: string | null, view: string, kinds: string) => ["repo-graph", "graph", repo, view, kinds] as const,
  node: (key: string | null) => ["repo-graph", "node", key] as const,
};

export function useRepoGraphRepos() {
  return useQuery({ queryKey: repoGraphKeys.repos, queryFn: repoGraphApi.repos, refetchInterval: 60_000 });
}

export function useRepoCrawls(repo: string | null = null) {
  return useQuery({
    queryKey: repoGraphKeys.crawls(repo),
    queryFn: () => repoGraphApi.crawls(repo, 25),
    refetchInterval: (q) => (q.state.data?.some((c) => BUSY.has(c.status)) ? 1500 : 30_000),
  });
}

export function useRepoGraph(repo: string | null, view: "all" | "lineage", kinds: string[] | null = null) {
  const kindKey = kinds?.slice().sort().join(",") ?? "";
  return useQuery({
    queryKey: repoGraphKeys.graph(repo, view, kindKey),
    queryFn: () => repoGraphApi.graph(repo as string, view, kinds),
    enabled: Boolean(repo),
    staleTime: 60_000,
    placeholderData: keepPreviousData,
  });
}

export function useRepoNode(key: string | null) {
  return useQuery({ queryKey: repoGraphKeys.node(key), queryFn: () => repoGraphApi.node(key as string), enabled: Boolean(key), staleTime: 60_000 });
}

export function useRepoSearch(repo: string | null, q: string) {
  return useQuery({
    queryKey: ["repo-graph", "search", repo, q] as const,
    queryFn: () => repoGraphApi.search(repo as string, q),
    enabled: Boolean(repo) && q.length >= 2,
    staleTime: 60_000,
  });
}

export function useStartCrawl() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: RepoCrawlRequest) => repoGraphApi.crawl(body),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["repo-graph", "crawls"] }),
  });
}

export function useRemoveRepoGraph() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (repo: string) => repoGraphApi.remove(repo),
    onSuccess: () => void qc.invalidateQueries({ queryKey: repoGraphKeys.all }),
  });
}

export function isCrawlBusy(crawl: RepoCrawl | null | undefined): boolean {
  return Boolean(crawl && BUSY.has(crawl.status));
}
