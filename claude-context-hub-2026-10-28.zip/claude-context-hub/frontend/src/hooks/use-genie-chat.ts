/**
 * The live side of a Genie conversation: sends a question, consumes the SSE stream
 * (`conversation` → `delta`/`turn_reset`/`step`/`step_done` → `message` | `error`) and keeps
 * the persisted messages in sync with React Query once the answer has landed.
 */

import { useQueryClient } from "@tanstack/react-query";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import { genieApi } from "@/api/endpoints";
import type { GenieConversation, GenieMessage, GenieStreamEvent, GenieTraceStep } from "@/api/types";
import { useGenieConversation } from "@/hooks/queries";
import { describeError, parseApiError } from "@/lib/api-client";
import { queryKeys } from "@/lib/query-client";
import { readSse } from "@/lib/sse";

export interface LiveStep {
  step: number;
  tool: string;
  input: Record<string, unknown>;
  done?: GenieTraceStep;
}

export interface LiveAnswer {
  text: string;
  narration: string[];
  steps: LiveStep[];
}

interface Options {
  onConversation?: (conversation: GenieConversation) => void;
}

export function useGenieChat(spaceId: string | null, conversationId: string | null, { onConversation }: Options = {}) {
  const qc = useQueryClient();
  const [messages, setMessages] = useState<GenieMessage[]>([]);
  const [live, setLive] = useState<LiveAnswer | null>(null);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const activeConversation = useRef<string | null>(conversationId);

  const stored = useGenieConversation(conversationId);

  // Switching to another conversation (or space) resets the thread and the stored messages load
  // in. Landing on the URL of the conversation that is streaming right now is not a switch.
  useEffect(() => {
    if (conversationId === activeConversation.current) return;
    abortRef.current?.abort();
    activeConversation.current = conversationId;
    if (!conversationId) setMessages([]);
    setLive(null);
    setError(null);
  }, [conversationId, spaceId]);

  useEffect(() => {
    if (stored.data && !pending && stored.data.id === activeConversation.current) setMessages(stored.data.messages);
  }, [stored.data, pending]);

  const ask = useCallback(
    async (question: string) => {
      const trimmed = question.trim();
      if (!spaceId || !trimmed || pending) return;
      const controller = new AbortController();
      abortRef.current = controller;
      setPending(true);
      setError(null);
      setLive({ text: "", narration: [], steps: [] });
      const optimisticId = `pending-${Date.now()}`;
      setMessages((prev) => [
        ...prev,
        {
          id: optimisticId,
          conversation_id: activeConversation.current ?? "",
          role: "user",
          content: trimmed,
          status: "complete",
          error: null,
          citations: [],
          trace: [],
          follow_ups: [],
          usage: {},
          model: null,
          latency_ms: null,
          feedback: null,
          created_at: new Date().toISOString(),
        },
      ]);

      try {
        const response = await fetch(genieApi.askUrl(spaceId), {
          method: "POST",
          headers: { "Content-Type": "application/json", Accept: "text/event-stream" },
          body: JSON.stringify({ question: trimmed, conversation_id: activeConversation.current }),
          signal: controller.signal,
        });
        if (!response.ok) throw await parseApiError(response);

        await readSse(response, (frame) => {
          const event = { type: frame.event, data: JSON.parse(frame.data) } as GenieStreamEvent;
          switch (event.type) {
            case "conversation": {
              const { conversation, user_message } = event.data;
              const isNew = activeConversation.current !== conversation.id;
              activeConversation.current = conversation.id;
              setMessages((prev) => prev.map((m) => (m.id === optimisticId ? user_message : m)));
              if (isNew) onConversation?.(conversation);
              break;
            }
            case "delta":
              setLive((l) => (l ? { ...l, text: l.text + event.data.text } : l));
              break;
            case "turn_reset":
              setLive((l) => (l ? { ...l, text: "", narration: [...l.narration, event.data.text] } : l));
              break;
            case "step":
              setLive((l) => (l ? { ...l, steps: [...l.steps, { step: event.data.step, tool: event.data.tool, input: event.data.input }] } : l));
              break;
            case "step_done":
              setLive((l) => (l ? { ...l, steps: l.steps.map((s) => (s.step === event.data.step ? { ...s, done: event.data } : s)) } : l));
              break;
            case "message":
              setMessages((prev) => [...prev, event.data]);
              setLive(null);
              break;
            case "error":
              setError(event.data.error);
              if (event.data.message) setMessages((prev) => [...prev, event.data.message as GenieMessage]);
              setLive(null);
              break;
          }
        });
      } catch (err) {
        if (!(err instanceof DOMException && err.name === "AbortError")) setError(describeError(err));
        setLive(null);
      } finally {
        setPending(false);
        abortRef.current = null;
        void qc.invalidateQueries({ queryKey: ["genie", "conversations"] });
        void qc.invalidateQueries({ queryKey: ["genie", "spaces"] });
        if (activeConversation.current) void qc.invalidateQueries({ queryKey: queryKeys.genieConversation(activeConversation.current) });
      }
    },
    [spaceId, pending, onConversation, qc],
  );

  const stop = useCallback(() => abortRef.current?.abort(), []);

  return useMemo(
    () => ({ messages, live, pending, error, ask, stop, loading: stored.isLoading && Boolean(conversationId) }),
    [messages, live, pending, error, ask, stop, stored.isLoading, conversationId],
  );
}
