import { Boxes, Cable, Database, GitFork, Layers, type LucideIcon, Share2, ShieldCheck } from "lucide-react";
import { Link, useNavigate, useParams } from "react-router-dom";

import type { Integration, IntegrationKind, PlatformSummary } from "@/api/types";
import { MetricCard } from "@/components/dashboard/metric-card";
import { SourceBreakdown } from "@/components/dashboard/source-breakdown";
import { PersonaChat } from "@/components/personas/persona-chat";
import { AssetLink, EmptyRow, PersonaShell, SectionCard } from "@/components/personas/persona-shell";
import { PersonaProfile } from "@/components/personas/persona-profile";
import { KindBadge, PlatformBadge } from "@/components/semantic/badges";
import { BusinessModelView } from "@/components/semantic/business-model";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useArchitectureReport, useBusinessModel, useSemanticOverview } from "@/hooks/queries";
import { formatInt, formatRelative } from "@/lib/format";
import { PERSONAS, personaTab } from "@/lib/personas";
import { cn } from "@/lib/utils";

const persona = PERSONAS.architect;

const KIND_COLORS: Record<string, string> = {
  fact: "bg-emerald-500",
  dimension: "bg-blue-500",
  bridge: "bg-amber-500",
  metric: "bg-rose-500",
  reference: "bg-cyan-500",
  unknown: "bg-slate-500",
  foreign_key: "bg-emerald-500",
  join_declared: "bg-teal-500",
  join_inferred: "bg-amber-500",
  lineage_upstream: "bg-blue-500",
  lineage_downstream: "bg-indigo-500",
  metric_source: "bg-rose-500",
  declared: "bg-emerald-500",
  curated: "bg-teal-500",
  inferred: "bg-slate-400",
  databricks: "bg-orange-500",
  snowflake: "bg-sky-500",
};

const INTEGRATION_GROUPS: Array<{ kind: IntegrationKind; label: string; description: string; icon: LucideIcon }> = [
  { kind: "source", label: "Sources", description: "Where metadata, documents and code come from.", icon: Database },
  { kind: "store", label: "Stores", description: "Where the hub keeps documents, vectors, the semantic layer and the graph.", icon: Layers },
  { kind: "model", label: "Models", description: "Embeddings, reranking and the Claude model behind Genie and enrichment.", icon: ShieldCheck },
  { kind: "export", label: "Exports", description: "What the governed model can be handed to other tools as.", icon: Share2 },
  { kind: "api", label: "APIs", description: "How agents and applications retrieve context.", icon: Cable },
  { kind: "assistant", label: "Assistants", description: "Conversational access with citations.", icon: Boxes },
];

export function ArchitectPage() {
  const { tab } = useParams<{ tab: string }>();
  const active = personaTab(persona, tab).key;
  return (
    <PersonaShell persona={persona} active={active} fill={active === "ask"}>
      {active === "overview" ? <Overview /> : null}
      {active === "landscape" ? <Landscape /> : null}
      {active === "model" ? <Model /> : null}
      {active === "integrations" ? <Integrations /> : null}
      {active === "ask" ? <PersonaChat persona="architect" /> : null}
    </PersonaShell>
  );
}

function StatusBadge({ status }: { status: Integration["status"] }) {
  return (
    <Badge variant={status === "configured" ? "success" : status === "available" ? "info" : "muted"} className="h-5 text-[10px]">
      {status}
    </Badge>
  );
}

// ----------------------------------------------------------------------------- overview
function Overview() {
  const report = useArchitectureReport();
  const r = report.data;
  const configured = r ? r.integrations.filter((i) => i.status === "configured").length : 0;

  return (
    <div className="space-y-6">
      <PersonaProfile persona={persona} />

      {/* Only what exists: a count tile shows once it is above zero. */}
      <section className="stat-grid stat-grid-wide">
        <MetricCard
          title="Platforms"
          value={formatInt(r?.platforms.length)}
          hint={r?.platforms.length ? r.platforms.map((p) => `${p.platform} · ${p.databases} catalogs`).join(", ") : "no catalog metadata yet"}
          icon={Database}
          loading={report.isLoading}
        />
        {r && r.subject_areas > 0 ? (
          <MetricCard title="Subject areas" value={formatInt(r.subject_areas)} hint="one per database and schema" icon={Boxes} loading={report.isLoading} />
        ) : null}
        {r && r.facts > 0 ? (
          <MetricCard
            title="Fact stars"
            value={formatInt(r?.facts)}
            hint={r ? `${formatInt(r.dimensions)} dimensions · ${formatInt(r.metric_views)} metric views` : undefined}
            icon={Layers}
            loading={report.isLoading}
          />
        ) : null}
        {r && r.shared_dimensions.length > 0 ? (
          <MetricCard
            title="Conformed dimensions"
            value={formatInt(r?.shared_dimensions.length)}
            hint="joined from two or more facts"
            icon={GitFork}
            tone={r && r.shared_dimensions.length > 0 ? "success" : "default"}
            loading={report.isLoading}
          />
        ) : null}
        {r && r.governed_metrics > 0 ? (
          <MetricCard
            title="Governed metrics"
            value={formatInt(r?.governed_metrics)}
            hint={r ? `${formatInt(r.metrics_by_source.inferred ?? 0)} more are only inferred` : undefined}
            icon={ShieldCheck}
            tone="success"
            loading={report.isLoading}
          />
        ) : null}
        <MetricCard
          title="Integrations configured"
          value={r ? `${configured}/${r.integrations.length}` : "—"}
          hint={r ? `${r.integrations.filter((i) => i.status === "missing").length} not configured` : undefined}
          icon={Cable}
          loading={report.isLoading}
        />
      </section>

      <section className="grid gap-6 lg:grid-cols-5">
        <SectionCard
          className="lg:col-span-3"
          title="Platforms"
          description="What each platform contributes to the model."
          actions={
            <Button variant="outline" size="sm" asChild>
              <Link to={`${persona.path}/landscape`}>Landscape</Link>
            </Button>
          }
        >
          <PlatformTable platforms={r?.platforms} />
        </SectionCard>
        <SectionCard className="lg:col-span-2" title="Model composition" description="Assets by kind, relationships by how they were established, metrics by provenance.">
          <div className="space-y-4 p-4">
            <div>
              <div className="mb-1 text-[10px] uppercase tracking-wide text-muted-foreground">Assets</div>
              <SourceBreakdown data={r?.assets_by_kind} loading={report.isLoading} colors={KIND_COLORS} emptyLabel="No assets yet" />
            </div>
            <div>
              <div className="mb-1 text-[10px] uppercase tracking-wide text-muted-foreground">Relationships</div>
              <SourceBreakdown data={r?.relationships_by_kind} loading={report.isLoading} colors={KIND_COLORS} emptyLabel="No relationships yet" />
            </div>
            <div>
              <div className="mb-1 text-[10px] uppercase tracking-wide text-muted-foreground">Metrics</div>
              <SourceBreakdown data={r?.metrics_by_source} loading={report.isLoading} colors={KIND_COLORS} emptyLabel="No metrics yet" />
            </div>
          </div>
        </SectionCard>
      </section>
    </div>
  );
}

function PlatformTable({ platforms }: { platforms: PlatformSummary[] | undefined }) {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Platform</TableHead>
          <TableHead className="text-right">Catalogs</TableHead>
          <TableHead className="text-right">Schemas</TableHead>
          <TableHead className="text-right">Assets</TableHead>
          <TableHead className="text-right">Metric views</TableHead>
          <TableHead>Kinds</TableHead>
          <TableHead>Synced</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {platforms?.map((p) => (
          <TableRow key={p.platform}>
            <TableCell>
              <PlatformBadge platform={p.platform} />
            </TableCell>
            <TableCell className="text-right font-mono text-xs">{p.databases}</TableCell>
            <TableCell className="text-right font-mono text-xs">{p.schemas}</TableCell>
            <TableCell className="text-right font-mono text-xs">{p.assets}</TableCell>
            <TableCell className="text-right font-mono text-xs">{p.metric_views}</TableCell>
            <TableCell>
              <span className="flex flex-wrap gap-1">
                {Object.entries(p.by_kind)
                  .sort((a, b) => b[1] - a[1])
                  .map(([kind, n]) => (
                    <span key={kind} className="inline-flex items-center gap-1 text-[10px]">
                      <KindBadge kind={kind} />
                      <span className="font-mono text-muted-foreground">{n}</span>
                    </span>
                  ))}
              </span>
            </TableCell>
            <TableCell className="text-xs text-muted-foreground">{formatRelative(p.last_synced_at)}</TableCell>
          </TableRow>
        ))}
        {platforms && platforms.length === 0 ? <EmptyRow colSpan={7}>No catalog metadata yet. Run the Databricks or Snowflake connector from Pipelines.</EmptyRow> : null}
      </TableBody>
    </Table>
  );
}

// ----------------------------------------------------------------------------- landscape
function Landscape() {
  const report = useArchitectureReport();
  const overview = useSemanticOverview();
  const r = report.data;
  const o = overview.data;
  const graphNodes = r ? Object.values(r.graph_nodes_by_label).reduce((a, b) => a + b, 0) : 0;

  return (
    <div className="space-y-6">
      <SectionCard title="Platforms" description="Catalogs, schemas and the mix of asset kinds each platform holds.">
        <PlatformTable platforms={r?.platforms} />
      </SectionCard>

      <section className="grid gap-6 lg:grid-cols-5">
        <SectionCard
          className="lg:col-span-3"
          title={`Subject areas · ${o?.scopes.length ?? "…"}`}
          description="Every database and schema the connectors synced, with what it contributes. Open one in the Semantic Hub."
        >
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Scope</TableHead>
                <TableHead className="text-right">Assets</TableHead>
                <TableHead className="text-right">Facts</TableHead>
                <TableHead className="text-right">Dims</TableHead>
                <TableHead className="text-right">Metric views</TableHead>
                <TableHead>Synced</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {o?.scopes.map((s) => (
                <TableRow key={`${s.platform}.${s.database_name}.${s.schema_name}`}>
                  <TableCell className="font-mono text-xs">
                    <span className="text-muted-foreground">{s.platform} · </span>
                    <Link to={`/semantic?database=${encodeURIComponent(s.database_name)}&schema=${encodeURIComponent(s.schema_name)}`} className="hover:underline">
                      {s.database_name}.{s.schema_name}
                    </Link>
                  </TableCell>
                  <TableCell className="text-right font-mono text-xs">{s.assets}</TableCell>
                  <TableCell className="text-right font-mono text-xs">{s.facts}</TableCell>
                  <TableCell className="text-right font-mono text-xs">{s.dimensions}</TableCell>
                  <TableCell className="text-right font-mono text-xs">{s.metric_views}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{formatRelative(s.synced_at)}</TableCell>
                </TableRow>
              ))}
              {o && o.scopes.length === 0 ? <EmptyRow colSpan={6}>No catalog metadata yet.</EmptyRow> : null}
            </TableBody>
          </Table>
        </SectionCard>
        <div className="space-y-6 lg:col-span-2">
          <SectionCard title="Document sources" description="Documents and datasets by the system they came from.">
            <div className="space-y-4 p-4">
              <SourceBreakdown data={r?.document_sources} loading={report.isLoading} emptyLabel="Nothing ingested yet" />
              <SourceBreakdown data={r?.documents_by_kind} loading={report.isLoading} colors={{ document: "bg-blue-500", dataset: "bg-teal-500" }} emptyLabel="Nothing ingested yet" />
            </div>
          </SectionCard>
          <SectionCard title="Knowledge graph" description={r ? `${formatInt(graphNodes)} nodes · density ${r.graph_density.toFixed(4)}` : undefined}>
            <div className="space-y-4 p-4">
              <SourceBreakdown data={r?.graph_nodes_by_label} loading={report.isLoading} emptyLabel="Graph is empty" />
              <SourceBreakdown data={r?.graph_edges_by_type} loading={report.isLoading} emptyLabel="No edges yet" />
            </div>
          </SectionCard>
        </div>
      </section>

      <section className="grid gap-6 lg:grid-cols-2">
        <SectionCard title="Column roles" description="How the columns across every asset are classified.">
          <div className="p-4">
            <SourceBreakdown
              data={r?.fields_by_role}
              loading={report.isLoading}
              colors={{ identifier: "bg-slate-400", dimension: "bg-blue-500", time: "bg-violet-500", measure: "bg-emerald-500", attribute: "bg-slate-600" }}
              emptyLabel="No columns yet"
            />
          </div>
        </SectionCard>
        <SectionCard title="Lineage across platforms" description="Relationships whose source and target live on different platforms.">
          <div className="flex items-center gap-4 p-4">
            <div className="font-display text-4xl font-medium tabular-nums">{formatInt(r?.cross_platform_links)}</div>
            <p className="text-xs text-muted-foreground">
              {r && r.cross_platform_links > 0
                ? "Cross-platform links exist; the Lineage tab of the Data Engineer workspace shows them per asset."
                : "No cross-platform links yet. They appear when a Snowflake view reads a Databricks table or vice versa."}
            </p>
          </div>
        </SectionCard>
      </section>
    </div>
  );
}

// ----------------------------------------------------------------------------- model
function Model() {
  const model = useBusinessModel({});
  const report = useArchitectureReport();
  const navigate = useNavigate();
  const r = report.data;

  return (
    <div className="space-y-6">
      <SectionCard
        title={`Conformed dimensions · ${r?.shared_dimensions.length ?? "…"}`}
        description="Dimensions that two or more facts join to. Govern these first: a change here reaches every star."
      >
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Dimension</TableHead>
              <TableHead>Qualified name</TableHead>
              <TableHead className="text-right">Facts joined</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {r?.shared_dimensions.map((d) => (
              <TableRow key={d.id}>
                <TableCell>
                  <AssetLink id={d.id} fqn={d.fqn} name={d.display_name} kind="dimension" />
                </TableCell>
                <TableCell className="font-mono text-xs text-muted-foreground">{d.fqn}</TableCell>
                <TableCell className="text-right font-mono text-xs">{d.facts}</TableCell>
              </TableRow>
            ))}
            {r && r.shared_dimensions.length === 0 ? <EmptyRow colSpan={3}>No dimension is joined from more than one fact yet.</EmptyRow> : null}
          </TableBody>
        </Table>
      </SectionCard>
      {model.isLoading && !model.data ? (
        <Skeleton className="h-96 w-full" />
      ) : (
        <BusinessModelView model={model.data} loading={model.isLoading} onOpen={(id) => navigate(`/semantic/${id}`)} onEnrich={() => navigate("/semantic")} enrichPending={false} enrichRun={null} />
      )}
    </div>
  );
}

// ----------------------------------------------------------------------------- integrations
function Integrations() {
  const report = useArchitectureReport();
  const r = report.data;

  return (
    <div className="space-y-6">
      <section className="tile-grid">
        <MetricCard title="Embedding model" value={<span className="text-base">{r?.embedding_model ?? "—"}</span>} hint={r ? `${r.vector_dimensions} dimensions` : undefined} icon={Layers} loading={report.isLoading} />
        <MetricCard
          title="Genie model"
          value={<span className="text-base">{r?.genie_model ?? "not configured"}</span>}
          hint={r?.genie_provider ? `via ${r.genie_provider}` : "set DATABRICKS_HOST/TOKEN or ANTHROPIC_API_KEY"}
          icon={ShieldCheck}
          tone={r?.genie_model ? "success" : "warning"}
          loading={report.isLoading}
        />
        <MetricCard title="Reranker" value={<span className="text-base">{r?.reranker ?? "—"}</span>} hint="ECH_RERANKER_PROVIDER" icon={GitFork} loading={report.isLoading} />
      </section>

      {!r ? (
        <Skeleton className="h-64 w-full" />
      ) : (
        INTEGRATION_GROUPS.map((group) => {
          const items = r.integrations.filter((i) => i.kind === group.kind);
          if (!items.length) return null;
          return (
            <section key={group.kind}>
              <div className="mb-3 flex items-center gap-2">
                <group.icon className="h-4 w-4 text-primary" />
                <h2 className="text-sm font-medium">{group.label}</h2>
                <span className="text-xs text-muted-foreground">{group.description}</span>
              </div>
              <div className="kpi-grid kpi-grid-wide">
                {items.map((i) => (
                  <div key={i.key} className={cn("surface flex flex-col gap-2 rounded-xl border p-4", i.status === "missing" && "opacity-70")}>
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-sm font-medium">{i.label}</span>
                      <StatusBadge status={i.status} />
                    </div>
                    <p className="text-xs text-muted-foreground">{i.detail}</p>
                    {i.href ? (
                      <Link to={i.href} className="mt-auto text-xs text-primary hover:underline">
                        Open →
                      </Link>
                    ) : null}
                  </div>
                ))}
              </div>
            </section>
          );
        })
      )}
    </div>
  );
}
