import {
  BrainCircuit,
  CircleAlert,
  ClipboardCheck,
  GitPullRequestArrow,
  PenLine,
  Plus,
  RefreshCw,
  Rocket,
  Snowflake,
  TicketCheck,
  type LucideIcon,
} from "lucide-react";
import { useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import type { IntentRecord, IntentStatus } from "@/api/types";
import { Intake } from "@/components/intents/intake";
import { IntentDetail } from "@/components/intents/intent-detail";
import { ReviewChip } from "@/components/intents/intent-review";
import { FLOW, INTENT_STATUS, IntentStatusBadge, Lifecycle, stageOf } from "@/components/intents/intent-status";
import { HeroStats, PageHero } from "@/components/layout/page-hero";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useIntent, useIntents, useIntentsConfig, useSyncJira } from "@/hooks/queries";
import { describeError } from "@/lib/api-client";
import { formatRelative } from "@/lib/format";
import { cn } from "@/lib/utils";

function IntentRow({ intent, selected, onSelect }: { intent: IntentRecord; selected: boolean; onSelect: () => void }) {
  const stage = stageOf(intent.status);
  const color = INTENT_STATUS[intent.status].color;
  const Icon = intent.source === "jira" ? TicketCheck : PenLine;
  return (
    <button
      type="button"
      onClick={onSelect}
      className={cn(
        "relative w-full overflow-hidden rounded-2xl border p-3 text-left transition-all hover:-translate-y-px hover:shadow-md",
        selected ? "bg-card shadow-md" : "border-border/60 bg-card/60",
      )}
      style={selected ? { borderColor: `hsl(${color} / 0.6)`, boxShadow: `0 0 0 3px hsl(${color} / 0.12)` } : undefined}
    >
      <span className="absolute inset-y-0 left-0 w-1" style={{ background: `hsl(${color})` }} aria-hidden="true" />
      <div className="flex items-start gap-2.5 pl-1">
        <span
          className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-xl"
          style={{ background: `hsl(${color} / 0.14)`, color: `hsl(${color})` }}
        >
          <Icon className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="truncate text-sm font-medium">{intent.title}</span>
            <IntentStatusBadge status={intent.status} />
          </div>
          <div className="mt-0.5 flex min-w-0 items-center gap-1.5 text-[11px] text-muted-foreground">
            {intent.jira_key ? (
              <span className="shrink-0 rounded border border-border/70 px-1 font-mono text-[10px] text-foreground/80">{intent.jira_key}</span>
            ) : null}
            <span className="truncate">{intent.intent?.summary || intent.text || "being read…"}</span>
          </div>
          <div className="mt-2 flex items-center gap-3">
            <div className="flex flex-1 items-center gap-1" aria-hidden="true">
              {FLOW.map((s, i) => (
                <span key={s.key} className="h-1.5 flex-1 rounded-full" style={{ background: i <= stage ? `hsl(${s.color})` : "hsl(var(--muted))" }} />
              ))}
            </div>
            {intent.review ? <ReviewChip review={intent.review} /> : null}
          </div>
        </div>
        <span className="shrink-0 text-[10px] text-muted-foreground">{formatRelative(intent.updated_at)}</span>
      </div>
    </button>
  );
}

function Capability({ on, icon: Icon, label }: { on: boolean; icon: LucideIcon; label: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium",
        on ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300" : "border-border/70 bg-background/60 text-muted-foreground",
      )}
    >
      <Icon className="h-3.5 w-3.5" /> {label}
    </span>
  );
}

export function IntentsPage() {
  const { intentId = null } = useParams<{ intentId: string }>();
  const navigate = useNavigate();
  const config = useIntentsConfig();
  const list = useIntents({ limit: 100 });
  const current = useIntent(intentId);
  const sync = useSyncJira();
  const [showIntake, setShowIntake] = useState(true);
  const [filter, setFilter] = useState<IntentStatus | null>(null);

  const items = useMemo(() => list.data?.items ?? [], [list.data]);
  const counts = useMemo(() => {
    const out: Record<string, number> = {};
    for (const i of items) out[i.status] = (out[i.status] ?? 0) + 1;
    return out;
  }, [items]);
  const stageCount = (statuses: IntentStatus[]) => statuses.reduce((n, s) => n + (counts[s] ?? 0), 0);
  const shown = filter ? items.filter((i) => i.status === filter) : items;
  const c = config.data;

  return (
    <>
      <div className="px-6 pt-6">
        <PageHero
          slim
          eyebrow="Ingestion"
          icon={ClipboardCheck}
          title="Intents"
          lead="Hand the hub a Jira ticket: Claude reads it, a review scores what is missing, and the planner lays the pipeline out as a workflow you approve before anything is generated."
          aside={
            <HeroStats
              items={[
                { label: "In review", value: stageCount(["received", "clarifying", "planning"]), icon: TicketCheck },
                { label: "To approve", value: stageCount(["spec_proposed"]), icon: ClipboardCheck },
                { label: "Generated", value: stageCount(["pr_open"]), icon: GitPullRequestArrow },
                { label: "Done", value: stageCount(["done"]), icon: Rocket },
                { label: "Failed", value: stageCount(["failed"]), icon: CircleAlert },
              ]}
            />
          }
          actions={
            <div className="flex items-center gap-2">
              {c?.jira_configured ? (
                <Button
                  size="sm"
                  variant="outline"
                  disabled={sync.isPending}
                  onClick={() => sync.mutate(undefined)}
                  title={`Pull tickets matching: ${c.jira_jql}`}
                >
                  <RefreshCw className={cn("h-3.5 w-3.5", sync.isPending && "animate-spin")} /> Sync Jira
                </Button>
              ) : null}
              <Button size="sm" variant={showIntake ? "outline" : "default"} onClick={() => setShowIntake((v) => !v)}>
                <Plus className={cn("h-3.5 w-3.5 transition-transform", showIntake && "rotate-45")} /> {showIntake ? "Hide" : "New intent"}
              </Button>
            </div>
          }
        />
      </div>
      <div className="flex min-h-0 flex-1 flex-col gap-4 overflow-y-auto p-4 [&>*]:shrink-0">
        {showIntake ? <Intake jiraConfigured={Boolean(c?.jira_configured)} onCreated={(record) => navigate(`/intents/${record.id}`)} /> : null}

        <section className="surface relative overflow-hidden p-4">
          <div className="hero-grid pointer-events-none absolute inset-0 opacity-40" aria-hidden="true" />
          <div className="relative">
            <Lifecycle count={(stage) => stageCount(stage.statuses)} active={current.data?.status ?? null} />
          </div>
          <div className="relative mt-3 flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground">
            <Capability
              on={Boolean(c?.jira_configured)}
              icon={TicketCheck}
              label={c?.jira_configured ? `Jira · replies checked every ${c.poll_seconds}s, new tickets on request` : "Jira not connected"}
            />
            <Capability on={Boolean(c?.model_available)} icon={BrainCircuit} label={c?.model_available ? "Claude reads tickets" : "Claude off: rules only"} />
            <Capability
              on={Boolean(c?.snowflake_configured)}
              icon={Snowflake}
              label={c?.snowflake_configured ? "Snowflake connected" : "Snowflake not connected"}
            />
            {c ? (
              <span className="font-mono text-[10px]">
                workspace {c.workspace} · data {c.data_dir}
              </span>
            ) : null}
            {sync.data ? (
              <span>
                last sync: {sync.data.fetched} fetched, {sync.data.created} new, {sync.data.answered} answered, {sync.data.approved} approved
                {sync.data.errors.length ? `, ${sync.data.errors.length} errors` : ""}
              </span>
            ) : null}
            {sync.error ? <span className="text-destructive">{describeError(sync.error)}</span> : null}
          </div>
        </section>

        <div className="grid min-h-0 gap-4 lg:grid-cols-5">
          <div className="flex min-h-0 min-w-0 flex-col gap-2 lg:col-span-2">
            <div className="flex flex-wrap gap-1">
              <button
                type="button"
                onClick={() => setFilter(null)}
                className={cn(
                  "rounded-full border px-2.5 py-1 text-[11px]",
                  filter === null ? "border-primary/50 bg-primary/10 text-foreground" : "border-border/70 text-muted-foreground hover:text-foreground",
                )}
              >
                All · {items.length}
              </button>
              {(Object.keys(INTENT_STATUS) as IntentStatus[])
                .filter((s) => counts[s])
                .map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setFilter(filter === s ? null : s)}
                    className={cn(
                      "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px]",
                      filter === s ? "border-primary/50 bg-primary/10 text-foreground" : "border-border/70 text-muted-foreground hover:text-foreground",
                    )}
                  >
                    <span className="h-1.5 w-1.5 rounded-full" style={{ background: `hsl(${INTENT_STATUS[s].color})` }} aria-hidden="true" />
                    {INTENT_STATUS[s].label} · {counts[s]}
                  </button>
                ))}
            </div>
            {list.isLoading && !list.data ? (
              <div className="space-y-2">
                {[0, 1, 2].map((i) => (
                  <Skeleton key={i} className="h-24 w-full rounded-2xl" />
                ))}
              </div>
            ) : null}
            {list.data && shown.length === 0 ? (
              <div className="surface p-6 text-center text-sm text-muted-foreground">
                No intents yet. Hand the hub a ticket above{c?.jira_configured ? " or sync Jira" : ""}.
              </div>
            ) : null}
            <div className="space-y-2">
              {shown.map((i) => (
                <IntentRow key={i.id} intent={i} selected={i.id === intentId} onSelect={() => navigate(`/intents/${i.id}`)} />
              ))}
            </div>
          </div>
          <div className="flex min-h-0 min-w-0 flex-col lg:col-span-3">
            <IntentDetail intent={current.data} loading={current.isLoading} />
          </div>
        </div>
      </div>
    </>
  );
}
