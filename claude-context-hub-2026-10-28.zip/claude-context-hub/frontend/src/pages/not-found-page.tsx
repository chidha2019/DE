import { Link } from "react-router-dom";

import { Button } from "@/components/ui/button";

export function NotFoundPage() {
  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-3 p-10 text-center">
      <div className="font-mono text-6xl font-medium text-muted-foreground/40">404</div>
      <p className="text-sm text-muted-foreground">That page does not exist in the Context Hub.</p>
      <Button asChild variant="outline" size="sm">
        <Link to="/home">Back to Home</Link>
      </Button>
    </div>
  );
}
