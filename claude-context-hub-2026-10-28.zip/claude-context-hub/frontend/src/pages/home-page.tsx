import { ArrowRight, BadgeCheck, Cable, Radio, Sparkles, UserRoundCheck, Users, type LucideIcon } from "lucide-react";
import { useMemo, type ReactNode } from "react";
import { Link } from "react-router-dom";

import { ActivityChart } from "@/components/dashboard/activity-chart";
import { ContextLayer } from "@/components/landing/context-layer";
import { LiveKpis } from "@/components/landing/kpi-cards";
import { LivePipelineFeed, RecentActivity } from "@/components/landing/live-feed";
import { SystemGlance } from "@/components/landing/system-glance";
import { HeroKpis } from "@/components/landing/hero-kpis";
import { BrandMark } from "@/components/connectors/brand-mark";
import { Companion } from "@/components/personas/companion";
import { Button } from "@/components/ui/button";
import { useActivity, useConnectors, useGenieStatus, useGlossaryCoverage, useOverview, useServiceHealth } from "@/hooks/queries";
import { formatCompact, formatInt } from "@/lib/format";
import { rgba } from "@/lib/tones";
import { PERSONA_GENIE } from "@/lib/persona-genie";
import { PERSONA_LIST } from "@/lib/personas";
import { cn } from "@/lib/utils";

/** One reason to trust the hub, backed by a live number. */
function ProofPoint({ icon: Icon, color, title, children, to }: { icon: LucideIcon; color: string; title: string; children: ReactNode; to: string }) {
  return (
    <Link
      to={to}
      className="group flex min-w-0 items-start gap-2.5 rounded-2xl border border-border/60 bg-card/60 p-3 backdrop-blur transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-md"
    >
      <span
        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl text-white"
        style={{ background: `linear-gradient(145deg, ${rgba(color, 0.7)}, ${color})`, boxShadow: `0 8px 18px -10px ${color}` }}
        aria-hidden="true"
      >
        <Icon className="h-4 w-4" />
      </span>
      <span className="min-w-0">
        <span className="block text-[13px] font-medium leading-tight">{title}</span>
        <span className="mt-0.5 block text-[11px] leading-snug text-muted-foreground">{children}</span>
      </span>
    </Link>
  );
}

/** Home: what the hub is and whether it is up, the meaning it keeps, what is happening now, and the way into every workspace. */
export function HomePage() {
  const ingestion = useServiceHealth("ingestion");
  const query = useServiceHealth("query");
  const overview = useOverview();
  const genie = useGenieStatus();
  const connectors = useConnectors();
  const coverage = useGlossaryCoverage();
  // Daily buckets over a week: an hourly 24h window is empty whenever the last run is a day old.
  const activity = useActivity(24 * 7, 24 * 60);

  const o = overview.data;
  const online = ingestion.data?.status === "ok" && query.data?.status === "ok";
  const liveSources = connectors.data?.filter((c) => c.healthy).length;
  const sourceBrands = [...new Set((connectors.data ?? []).filter((c) => c.healthy).map((c) => c.source_system as string))];
  const waiting = coverage.data?.links_suggested;
  const runs7d = activity.data?.reduce((n, p) => n + p.completed + p.failed + p.cancelled, 0);
  const failed7d = activity.data?.reduce((n, p) => n + p.failed, 0);
  const docs7d = activity.data?.reduce((n, p) => n + p.documents, 0);
  const dayLabel = (iso: string) => new Date(iso).toLocaleDateString(undefined, { weekday: "short", day: "numeric" });
  // The API only returns buckets that saw a run; fill the other days with zeros so the week reads as a week.
  const pulse = useMemo(() => {
    if (!activity.data) return undefined;
    const byDay = new Map(activity.data.map((p) => [new Date(p.bucket_start).toDateString(), p] as const));
    return Array.from({ length: 7 }, (_, i) => {
      const day = new Date();
      day.setHours(0, 0, 0, 0);
      day.setDate(day.getDate() - (6 - i));
      const p = byDay.get(day.toDateString());
      return {
        bucket_start: day.toISOString(),
        completed: p?.completed ?? 0,
        failed: p?.failed ?? 0,
        cancelled: p?.cancelled ?? 0,
        documents: p?.documents ?? 0,
      };
    });
  }, [activity.data]);

  return (
    <div className="relative flex-1 overflow-auto p-3 sm:p-6 short:py-4">
      <div className="relative mx-auto max-w-[160rem] space-y-10">
        {/* On desktop the hero fills the window (up to 56rem, so a tall screen is not mostly empty): copy and system panel
            centred, the six numbers on the bottom edge. */}
        <section className="home-hero relative flex flex-col overflow-hidden rounded-3xl border border-border/70 bg-card/40 px-4 py-6 sm:px-6 sm:py-7 lg:min-h-[min(calc(100dvh-3rem),56rem)] lg:px-8 short:py-4 lg:short:min-h-[calc(100dvh-2rem)]">
          <div className="home-aurora pointer-events-none absolute inset-0" aria-hidden="true" />
          <div className="hero-grid pointer-events-none absolute inset-0 opacity-80" aria-hidden="true" />
          <div className="home-hero-grid relative flex-1">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="flex items-center gap-2 text-[10px] font-medium uppercase tracking-[0.2em] text-primary">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary" aria-hidden="true" /> Enterprise Context Hub
                </span>
                <span className="inline-flex items-center gap-2 rounded-full border border-border/80 bg-card/60 px-2.5 py-0.5 text-[11px] text-muted-foreground">
                  <span className={cn("h-1.5 w-1.5 rounded-full", online ? "animate-pulse-dot bg-success" : "bg-warning")} aria-hidden="true" />
                  {online ? `services online · v${query.data?.version ?? ""}` : "checking services"}
                </span>
                {genie.data?.configured ? (
                  <span className="inline-flex items-center gap-2 rounded-full border border-success/40 bg-success/10 px-2.5 py-0.5 font-mono text-[11px] text-success">
                    {genie.data.model}
                  </span>
                ) : null}
              </div>
              <h1 className="mt-5 font-display text-[clamp(1.9rem,min(3.1cqi,6.4vh),3.5rem)] font-medium leading-[1.04] tracking-[-0.025em] short:mt-3">
                Every source. One context.
                <br />
                <span className="text-gradient-hub">Evidence</span> for every answer.
              </h1>
              <p className="mt-5 max-w-2xl text-[15px] leading-relaxed text-muted-foreground short:mt-3 short:text-sm">
                The hub reads the metadata, documents and code behind your data platforms and keeps it as one governed semantic layer and a knowledge graph.{" "}
                <span className="text-foreground">Genie answers from it, and every answer shows exactly what it used</span>, from the point of view of the
                person asking.
              </p>
              <div className="mt-5 grid max-w-3xl gap-2 sm:grid-cols-3 short:mt-3">
                <ProofPoint icon={Cable} color="#0EA5E9" title={`${liveSources ?? "…"} sources live`} to="/connectors">
                  <span className="mt-1 flex -space-x-1.5">
                    {sourceBrands.map((b) => (
                      <BrandMark key={b} icon={b} size="xs" className="ring-2 ring-card" />
                    ))}
                  </span>
                </ProofPoint>
                <ProofPoint icon={BadgeCheck} color="#10B981" title="Answers with evidence" to="/genie">
                  every answer cites its tables, documents and graph paths
                </ProofPoint>
                <ProofPoint icon={UserRoundCheck} color="#8B5CF6" title="You approve the meaning" to="/glossary/review">
                  {waiting === undefined ? "…" : waiting ? `${formatInt(waiting)} suggestions waiting for you` : "the review queue is clear"}
                </ProofPoint>
              </div>
              <div className="mt-6 flex flex-wrap items-center gap-2 short:mt-4">
                <Button size="lg" className="shadow-[0_14px_30px_-14px_hsl(var(--primary))]" asChild>
                  <Link to="/personas">
                    <Users className="h-4 w-4" /> Choose a persona
                  </Link>
                </Button>
                <Button size="lg" variant="outline" className="bg-card/60 backdrop-blur" asChild>
                  <Link to="/genie">
                    <Sparkles className="h-4 w-4" /> Ask Genie
                  </Link>
                </Button>
                <Link to="/semantic" className="inline-flex items-center gap-1 px-2 text-sm text-primary hover:underline">
                  Explore the Semantic Hub <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </div>
            </div>

            <SystemGlance />
          </div>

          <div className="relative mt-7 short:mt-4">
            <div className="mb-3 flex items-center gap-2 short:mb-2 text-[10px] font-medium uppercase tracking-[0.22em] text-muted-foreground">
              <span className="h-px w-6 bg-primary/50" aria-hidden="true" /> What the hub knows right now
            </div>
            <HeroKpis pulse={pulse} />
          </div>
        </section>

        <section>
          <SectionHeading
            eyebrow="The context layer"
            title="Turning data into business meaning for AI"
            caption="Your sources on the left, the meaning the hub keeps in the middle, who uses it on the right. Every count is live; grey rows are not built yet."
          />
          <ContextLayer />
        </section>

        <section>
          <SectionHeading
            eyebrow="Live"
            title="What is happening right now"
            caption={
              <span className="inline-flex flex-wrap items-center gap-3">
                <ServiceDot label="Ingestion" health={ingestion.data} down={ingestion.isError} />
                <ServiceDot label="Query" health={query.data} down={query.isError} />
              </span>
            }
          />
          <LiveKpis pulse={pulse} />
          <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-2 xl:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)_minmax(0,1fr)]">
            <div className="surface flex flex-col p-4 lg:col-span-2 xl:col-span-1">
              <header className="flex flex-wrap items-center gap-2.5">
                <span
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-white"
                  style={{ background: "linear-gradient(145deg, rgba(16,185,129,0.75), #10B981)", boxShadow: "0 10px 22px -12px #10B981" }}
                  aria-hidden="true"
                >
                  <Radio className="h-[18px] w-[18px]" />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-medium">Ingestion pulse</div>
                  <div className="truncate text-[11px] text-muted-foreground">Run outcomes per day, last 7 days</div>
                </div>
                <span className="flex flex-wrap items-center gap-1.5 text-[11px] tabular-nums">
                  <span className="rounded-full bg-emerald-500/10 px-2 py-0.5 text-emerald-600 dark:text-emerald-400">
                    {runs7d === undefined ? "…" : `${formatInt(runs7d)} runs`}
                  </span>
                  {failed7d ? (
                    <span className="rounded-full bg-red-500/10 px-2 py-0.5 text-red-600 dark:text-red-400">{formatInt(failed7d)} failed</span>
                  ) : null}
                  {docs7d !== undefined ? (
                    <span className="rounded-full bg-violet-500/10 px-2 py-0.5 text-violet-600 dark:text-violet-300">{formatCompact(docs7d)} documents</span>
                  ) : null}
                </span>
              </header>
              <div className="mt-3 flex-1">
                <ActivityChart points={pulse} loading={activity.isLoading} height={200} label={dayLabel} />
              </div>
              <div className="mt-2 flex flex-wrap items-center justify-between gap-2 text-[11px] text-muted-foreground">
                <span>{o ? `${formatInt(o.runs_total)} runs in total · ${o.runs_active ? `${o.runs_active} active now` : "none active"}` : "…"}</span>
                <Link to="/pipelines" className="inline-flex items-center gap-1 text-primary hover:underline">
                  Pipelines <ArrowRight className="h-3 w-3" />
                </Link>
              </div>
            </div>
            <LivePipelineFeed />
            <RecentActivity />
          </div>
        </section>

        <section>
          <SectionHeading
            eyebrow="Perspectives"
            title="Choose how you want to see it"
            caption={`${PERSONA_LIST.length} workspaces, each focusing the catalog, the pipelines and Genie on one role, with a companion who narrates the work.`}
          />
          <div className="persona-hub">
            <div className="persona-strip">
              {PERSONA_LIST.map((p) => {
                const [h, sat, l] = PERSONA_GENIE[p.key].color;
                const accent = `hsl(${h} ${sat}% ${l}%)`;
                return (
                  <Link
                    key={p.key}
                    to={p.path}
                    className="surface group relative flex items-center gap-3 overflow-hidden p-4 transition-all hover:-translate-y-0.5 hover:border-primary/40"
                  >
                    <span
                      className="pointer-events-none absolute -right-10 -top-10 h-28 w-28 rounded-full opacity-20 blur-2xl transition-opacity group-hover:opacity-50"
                      style={{ background: accent }}
                      aria-hidden="true"
                    />
                    <span
                      className="absolute inset-x-0 top-0 h-0.5"
                      style={{ background: `linear-gradient(90deg, ${accent}, transparent 70%)` }}
                      aria-hidden="true"
                    />
                    <Companion persona={p.key} size="3.25rem" interactive={false} still className="shrink-0" />
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-medium">{p.label}</span>
                      <span className="line-clamp-2 text-[11px] leading-snug text-muted-foreground">{p.tagline}</span>
                      <span className="mt-1.5 inline-flex items-center gap-1 text-[10px] font-medium uppercase tracking-wider text-primary opacity-0 transition-opacity group-hover:opacity-100">
                        Open workspace <ArrowRight className="h-3 w-3" />
                      </span>
                    </span>
                  </Link>
                );
              })}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}

function SectionHeading({ eyebrow, title, caption }: { eyebrow: string; title: string; caption?: ReactNode }) {
  return (
    <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
      <div>
        <div className="text-[10px] font-medium uppercase tracking-[0.2em] text-primary">{eyebrow}</div>
        <h2 className="mt-1 font-display text-2xl font-medium tracking-tight">{title}</h2>
      </div>
      {caption ? <div className="max-w-2xl text-xs text-muted-foreground">{caption}</div> : null}
    </div>
  );
}

function ServiceDot({ label, health, down }: { label: string; health: { status: string; version: string } | undefined; down: boolean }) {
  const ok = health?.status === "ok";
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className={cn("h-1.5 w-1.5 rounded-full", down ? "bg-destructive" : ok ? "animate-pulse-dot bg-success" : "bg-warning")} aria-hidden="true" />
      {label} {health ? <span className="text-muted-foreground/70">v{health.version}</span> : null}
    </span>
  );
}
