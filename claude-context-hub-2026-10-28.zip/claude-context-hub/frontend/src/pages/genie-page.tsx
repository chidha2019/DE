import { Boxes, FileText, Layers, MessageSquare, Sparkles } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import type { GenieStatus } from "@/api/types";
import { ChatThread, EmptyState } from "@/components/genie/chat-thread";
import { Composer } from "@/components/genie/composer";
import { SpaceRail } from "@/components/genie/space-rail";
import { HeroStats, PageHero } from "@/components/layout/page-hero";
import { PersonaWelcome } from "@/components/personas/genie-welcome";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { useGenieConversation, useGenieSpaces, useGenieStatus, useOverview, useSemanticOverview } from "@/hooks/queries";
import { useGenieChat } from "@/hooks/use-genie-chat";

export function GeniePage() {
  const { conversationId = null } = useParams<{ conversationId: string }>();
  const navigate = useNavigate();
  const status = useGenieStatus();
  const spaces = useGenieSpaces();
  const overview = useOverview();
  const semantic = useSemanticOverview();
  const conversation = useGenieConversation(conversationId);
  const [chosenSpaceId, setChosenSpaceId] = useState<string | null>(null);

  // A deep link to a conversation decides the space; otherwise the user's choice, else the default.
  const spaceId = conversation.data?.space_id ?? chosenSpaceId ?? spaces.data?.find((s) => s.is_default)?.id ?? spaces.data?.[0]?.id ?? null;
  const space = spaces.data?.find((s) => s.id === spaceId) ?? null;

  useEffect(() => {
    if (conversation.data) setChosenSpaceId(conversation.data.space_id);
  }, [conversation.data]);

  const onConversation = useCallback((c: { id: string }) => navigate(`/genie/${c.id}`, { replace: true }), [navigate]);
  const chat = useGenieChat(spaceId, conversationId, { onConversation });

  const configured = status.data?.configured ?? false;
  const showEmpty = chat.messages.length === 0 && !chat.live && !chat.loading;

  return (
    <>
      <div className="px-6 pt-6">
        <PageHero
          slim
          eyebrow="Knowledge"
          icon={Sparkles}
          title="Genie"
          lead="Ask the hub in plain language. Genie searches the indexed sources, queries the knowledge graph read-only and cites every source it used."
          actions={<StatusBadge status={status.data} loading={status.isLoading} />}
          aside={
            <HeroStats
              items={[
                { label: "spaces", value: spaces.data?.length, icon: Boxes },
                { label: "conversations", value: spaces.data?.reduce((n, s) => n + s.conversation_count, 0), icon: MessageSquare },
                { label: "documents", value: overview.data?.documents_total, icon: FileText },
                { label: "catalog assets", value: semantic.data?.assets, icon: Layers },
              ]}
            />
          }
        />
      </div>
      <div className="flex min-h-0 flex-1">
        <SpaceRail
          spaces={spaces.data}
          loading={spaces.isLoading}
          selectedSpaceId={spaceId}
          conversationId={conversationId}
          onSelectSpace={(id) => {
            setChosenSpaceId(id);
            if (id !== spaceId || conversationId) navigate("/genie");
          }}
          onSelectConversation={(id) => navigate(`/genie/${id}`)}
          onNewChat={() => navigate("/genie")}
        />
        <section className="flex min-w-0 flex-1 flex-col">
          {showEmpty ? (
            space?.persona ? (
              <PersonaWelcome persona={space.persona} space={space} status={status.data} onAsk={chat.ask} disabled={!configured} />
            ) : (
              <EmptyState space={space} onAsk={chat.ask} disabled={!configured} />
            )
          ) : (
            <ChatThread messages={chat.messages} live={chat.live} error={chat.error} onAsk={chat.ask} persona={space?.persona ?? null} />
          )}
          <Composer
            onSend={chat.ask}
            onStop={chat.stop}
            pending={chat.pending}
            disabled={!configured || !spaceId}
            disabledReason={status.data?.reason ?? "Genie has no model configured"}
            placeholder={space ? `Ask ${space.name}…` : undefined}
          />
        </section>
      </div>
    </>
  );
}

function StatusBadge({ status, loading }: { status: GenieStatus | undefined; loading: boolean }) {
  if (loading) return <Badge variant="muted">checking model…</Badge>;
  if (!status?.configured) {
    return (
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge variant="warning">no model configured</Badge>
        </TooltipTrigger>
        <TooltipContent side="bottom" className="max-w-sm">
          {status?.reason ?? "Set DATABRICKS_HOST and DATABRICKS_TOKEN (or ANTHROPIC_API_KEY) for the query service."}
        </TooltipContent>
      </Tooltip>
    );
  }
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Badge variant="success" className="font-mono">
          {status.model}
        </Badge>
      </TooltipTrigger>
      <TooltipContent side="bottom">
        <div className="space-y-0.5 text-xs">
          <div>
            {status.provider} · {status.host}
          </div>
          <div className="text-muted-foreground">credential: {status.credential}</div>
          {status.degraded_fields.length ? <div className="text-warning">gateway rejected: {status.degraded_fields.join(", ")}</div> : null}
        </div>
      </TooltipContent>
    </Tooltip>
  );
}
