import { AlertOctagon, FileWarning, GitFork, ListChecks, ServerCrash, Sparkles } from "lucide-react";
import { useState } from "react";
import { Link, useParams } from "react-router-dom";

import type { KpiValue, ReviewItem } from "@/api/types";
import { MetricCard } from "@/components/dashboard/metric-card";
import { KpiSummaryLine, KpiTile, TargetsTable, formatKpi } from "@/components/personas/kpi-tiles";
import { PersonaChat } from "@/components/personas/persona-chat";
import { AssetLink, EmptyRow, PersonaShell, SectionCard } from "@/components/personas/persona-shell";
import { PersonaProfile } from "@/components/personas/persona-profile";
import { KindBadge } from "@/components/semantic/badges";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useDocuments, useQualityReport, useSemanticHealth } from "@/hooks/queries";
import { formatDateTime, formatInt, formatMs, formatPercent, formatRelative } from "@/lib/format";
import { documentPath } from "@/lib/knowledge-paths";
import { PERSONAS, personaTab } from "@/lib/personas";
import { cn } from "@/lib/utils";

const persona = PERSONAS.qa_engineer;
const WINDOWS = [7, 14, 30] as const;
type Window = (typeof WINDOWS)[number];

export function QaPage() {
  const { tab } = useParams<{ tab: string }>();
  const active = personaTab(persona, tab).key;
  return (
    <PersonaShell persona={persona} active={active} fill={active === "ask"}>
      {active === "overview" ? <Overview /> : null}
      {active === "gates" ? <Gates /> : null}
      {active === "failures" ? <Failures /> : null}
      {active === "review" ? <Review /> : null}
      {active === "ask" ? <PersonaChat persona="qa_engineer" /> : null}
    </PersonaShell>
  );
}

function WindowSelect({ value, onChange }: { value: Window; onChange: (next: Window) => void }) {
  return (
    <Select value={String(value)} onValueChange={(v) => onChange(Number(v) as Window)}>
      <SelectTrigger className="h-8 w-36 text-xs">
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {WINDOWS.map((w) => (
          <SelectItem key={w} value={String(w)}>
            Last {w} days
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

function kpiTone(k: KpiValue | undefined): "default" | "success" | "warning" | "destructive" {
  if (!k) return "default";
  return k.status === "ok" ? "success" : k.status === "warn" ? "warning" : k.status === "bad" ? "destructive" : "default";
}

function confidenceVariant(c: number): "success" | "warning" | "destructive" {
  return c >= 0.85 ? "success" : c >= 0.7 ? "warning" : "destructive";
}

// ----------------------------------------------------------------------------- overview
function Overview() {
  const report = useQualityReport(7);
  const health = useSemanticHealth();
  const r = report.data;
  const kpis = r ? r.groups.flatMap((g) => g.kpis) : [];
  const byKey = new Map(kpis.map((k) => [k.key, k]));
  const offTarget = kpis.filter((k) => k.status === "bad" || k.status === "warn").sort((a, b) => (a.status === "bad" ? -1 : 1) - (b.status === "bad" ? -1 : 1));
  const allPass = r ? r.gates_passed === r.gates_total : false;
  const backlog = byKey.get("review_backlog");
  const unclassified = byKey.get("unclassified_assets");
  const errors = byKey.get("request_error_rate");
  const latestFailure = r?.failed_runs[0];

  const needs = (k: KpiValue | undefined) => (k?.value ?? 0) > 0;
  return (
    <div className="space-y-6">
      <PersonaProfile persona={persona} />

      {/* Only what needs attention: a count tile shows once it is above zero. */}
      <section className="stat-grid stat-grid-wide">
        <MetricCard
          title="Quality gates passing"
          value={r ? `${r.gates_passed}/${r.gates_total}` : "—"}
          hint={r ? (allPass ? "every measured gate is on target" : `${r.gates_total - r.gates_passed} gates to look at · last 7 days`) : undefined}
          icon={ListChecks}
          tone={r ? (allPass ? "success" : r.gates_passed / Math.max(r.gates_total, 1) >= 0.5 ? "warning" : "destructive") : "default"}
          loading={report.isLoading}
        />
        {r && r.failed_runs.length > 0 ? (
          <MetricCard
            title="Failed runs"
            value={formatInt(r?.failed_runs.length)}
            hint={latestFailure ? `latest: ${latestFailure.connector} ${formatRelative(latestFailure.finished_at ?? latestFailure.started_at)}` : "no failures in the window"}
            icon={ServerCrash}
            tone={r && r.failed_runs.length > 0 ? "destructive" : "success"}
            loading={report.isLoading}
          />
        ) : null}
        {needs(backlog) && backlog ? (
          <MetricCard title="Suggestions awaiting review" value={formatKpi(backlog)} hint={backlog.detail} icon={Sparkles} tone={kpiTone(backlog)} loading={report.isLoading} />
        ) : null}
        {needs(unclassified) ? (
          <MetricCard
            title="Unclassified assets"
            value={unclassified ? formatKpi(unclassified) : "—"}
            hint="kind still unknown after sync and review"
            icon={AlertOctagon}
            tone={kpiTone(unclassified)}
            loading={report.isLoading}
          />
        ) : null}
        {health.data && health.data.low_confidence_joins > 0 ? (
          <MetricCard
            title="Joins only inferred"
            value={formatInt(health.data?.low_confidence_joins)}
            hint={health.data ? `${health.data.inferred_joins} inferred joins in total` : undefined}
            icon={GitFork}
            tone={health.data && health.data.low_confidence_joins > 0 ? "warning" : "success"}
            loading={health.isLoading}
          />
        ) : null}
        {needs(errors) && errors ? (
          <MetricCard title="Request error rate" value={formatKpi(errors)} hint={errors.detail} icon={FileWarning} tone={kpiTone(errors)} loading={report.isLoading} />
        ) : null}
      </section>

      <section className="grid gap-6 lg:grid-cols-5">
        <SectionCard
          className="lg:col-span-3"
          title={`Gates off target · ${offTarget.length}`}
          description="Worst first. Every gate has a target you can change with ECH_KPI_TARGET_*."
          actions={
            <Button variant="outline" size="sm" asChild>
              <Link to={`${persona.path}/gates`}>All gates</Link>
            </Button>
          }
        >
          {!r ? (
            <Skeleton className="m-4 h-32" />
          ) : offTarget.length ? (
            <div className="grid gap-3 p-4 sm:grid-cols-2">
              {offTarget.slice(0, 6).map((k) => (
                <KpiTile key={k.key} kpi={k} />
              ))}
            </div>
          ) : (
            <p className="p-6 text-center text-sm text-muted-foreground">Every measured gate is on target.</p>
          )}
        </SectionCard>
        <SectionCard
          className="lg:col-span-2"
          title="Review queue"
          description="Lowest confidence first."
          actions={
            <Button variant="outline" size="sm" asChild>
              <Link to={`${persona.path}/review`}>Open queue</Link>
            </Button>
          }
        >
          <ul className="divide-y text-xs">
            {r?.review_queue.slice(0, 6).map((item) => (
              <li key={item.asset_id} className="flex items-center gap-2 px-4 py-2">
                <div className="min-w-0 flex-1">
                  <div className="truncate font-medium">{item.proposed_name || item.display_name}</div>
                  <div className="truncate font-mono text-[10px] text-muted-foreground">{item.fqn}</div>
                </div>
                <Badge variant={confidenceVariant(item.confidence)} className="h-5 text-[10px]">
                  {formatPercent(item.confidence)}
                </Badge>
              </li>
            ))}
            {r && r.review_queue.length === 0 ? <li className="px-4 py-6 text-center text-muted-foreground">Nothing waiting for a decision.</li> : null}
          </ul>
        </SectionCard>
      </section>
    </div>
  );
}

// ----------------------------------------------------------------------------- gates
function Gates() {
  const [days, setDays] = useState<Window>(7);
  const report = useQualityReport(days);
  const r = report.data;
  const kpis = r ? r.groups.flatMap((g) => g.kpis) : [];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center gap-3">
        <WindowSelect value={days} onChange={setDays} />
        {r ? <KpiSummaryLine kpis={kpis} suffix={`${r.gates_passed} of ${r.gates_total} gates pass · computed ${formatRelative(r.generated_at)}`} /> : null}
      </div>
      {!r ? (
        <Skeleton className="h-64 w-full" />
      ) : (
        r.groups.map((group) => (
          <section key={group.key}>
            <h2 className="text-sm font-medium">{group.label}</h2>
            <p className="mb-3 text-xs text-muted-foreground">{group.description}</p>
            <div className="kpi-grid">
              {group.kpis.map((k) => (
                <KpiTile key={k.key} kpi={k} />
              ))}
            </div>
          </section>
        ))
      )}
      <SectionCard
        title={`Active targets${r?.targets.some((t) => t.overridden) ? ` · ${r.targets.filter((t) => t.overridden).length} custom` : ""}`}
        description="Set ECH_KPI_TARGET_* in .env and restart the query service to change a target; unset variables keep the defaults."
      >
        <TargetsTable targets={r?.targets} />
      </SectionCard>
    </div>
  );
}

// ----------------------------------------------------------------------------- failures
function Failures() {
  const [days, setDays] = useState<Window>(7);
  const report = useQualityReport(days);
  const failedDocs = useDocuments({ graph_sync_status: "failed", limit: 25, offset: 0 });
  const r = report.data;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center gap-3">
        <WindowSelect value={days} onChange={setDays} />
        {r ? (
          <span className="text-xs text-muted-foreground">
            {r.failed_runs.length} failed runs · {failedDocs.data?.total ?? 0} documents failed graph sync · {r.recent_errors.length} recent request errors
          </span>
        ) : null}
      </div>

      <SectionCard title="Failed runs" description="Newest first, with the error the connector reported. Open Pipelines to re-run or read the live events.">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Connector</TableHead>
              <TableHead>Started</TableHead>
              <TableHead className="text-right">Docs failed</TableHead>
              <TableHead>Error</TableHead>
              <TableHead />
            </TableRow>
          </TableHeader>
          <TableBody>
            {r?.failed_runs.map((run) => (
              <TableRow key={run.id}>
                <TableCell>
                  <div className="font-mono text-xs">{run.connector}</div>
                  <div className="text-[11px] text-muted-foreground">{run.source_system}</div>
                </TableCell>
                <TableCell className="text-xs text-muted-foreground" title={run.started_at ? formatDateTime(run.started_at) : undefined}>
                  {formatRelative(run.started_at ?? run.finished_at)}
                </TableCell>
                <TableCell className={cn("text-right font-mono text-xs", run.documents_failed > 0 && "text-destructive")}>{run.documents_failed}</TableCell>
                <TableCell className="max-w-[28rem] truncate font-mono text-[11px] text-destructive" title={run.error ?? undefined}>
                  {run.error ?? "—"}
                </TableCell>
                <TableCell className="text-right">
                  <Button size="sm" variant="outline" asChild>
                    <Link to="/pipelines">Pipelines</Link>
                  </Button>
                </TableCell>
              </TableRow>
            ))}
            {r && r.failed_runs.length === 0 ? <EmptyRow colSpan={5}>No run failed in the last {days} days.</EmptyRow> : null}
          </TableBody>
        </Table>
      </SectionCard>

      <section className="grid gap-6 lg:grid-cols-2">
        <SectionCard title="Documents that failed graph sync" description="In Postgres but not in Neo4j. Reconcile from the SRE workspace or the Overview page.">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Document</TableHead>
                <TableHead>Source</TableHead>
                <TableHead>Updated</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {failedDocs.data?.items.map((d) => (
                <TableRow key={d.id}>
                  <TableCell className="max-w-[22rem]">
                    <Link to={documentPath(d.id)} className="block truncate text-xs font-medium hover:underline" title={d.title}>
                      {d.title}
                    </Link>
                    <div className="truncate font-mono text-[10px] text-muted-foreground">{d.external_id}</div>
                  </TableCell>
                  <TableCell className="text-xs">
                    {d.source_system}
                    <span className="text-muted-foreground"> · {d.kind}</span>
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">{formatRelative(d.updated_at)}</TableCell>
                </TableRow>
              ))}
              {failedDocs.data && failedDocs.data.items.length === 0 ? <EmptyRow colSpan={3}>Every document reached the graph.</EmptyRow> : null}
            </TableBody>
          </Table>
        </SectionCard>
        <SectionCard title="Recent request errors" description="Audited API calls that returned an error, newest first.">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Action</TableHead>
                <TableHead>When</TableHead>
                <TableHead className="text-right">Latency</TableHead>
                <TableHead>Detail</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {r?.recent_errors.map((e) => (
                <TableRow key={e.id}>
                  <TableCell className="font-mono text-xs">{e.action}</TableCell>
                  <TableCell className="text-xs text-muted-foreground" title={formatDateTime(e.created_at)}>
                    {formatRelative(e.created_at)}
                  </TableCell>
                  <TableCell className="text-right font-mono text-xs">{formatMs(e.latency_ms)}</TableCell>
                  <TableCell className="max-w-[18rem] truncate font-mono text-[11px] text-muted-foreground" title={JSON.stringify(e.details)}>
                    {typeof e.details.error === "string" ? e.details.error : (e.resource_id ?? "—")}
                  </TableCell>
                </TableRow>
              ))}
              {r && r.recent_errors.length === 0 ? <EmptyRow colSpan={4}>No request errors recorded.</EmptyRow> : null}
            </TableBody>
          </Table>
        </SectionCard>
      </section>
    </div>
  );
}

// ----------------------------------------------------------------------------- review
function Review() {
  const report = useQualityReport(7);
  const health = useSemanticHealth();
  const r = report.data;
  const h = health.data;

  return (
    <div className="space-y-6">
      <SectionCard
        title={`Claude suggestions awaiting a decision · ${r?.review_queue.length ?? "…"}`}
        description="Least confident first. Open the asset to accept as-is, edit, or reject; accepted names are attributed to the model, edited ones to you."
      >
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Asset</TableHead>
              <TableHead>Proposed name</TableHead>
              <TableHead>Kind</TableHead>
              <TableHead className="text-right">Confidence</TableHead>
              <TableHead className="text-right">Metrics</TableHead>
              <TableHead>Proposed</TableHead>
              <TableHead />
            </TableRow>
          </TableHeader>
          <TableBody>
            {r?.review_queue.map((item: ReviewItem) => (
              <TableRow key={item.asset_id}>
                <TableCell className="max-w-[20rem]">
                  <AssetLink id={item.asset_id} fqn={item.fqn} name={item.display_name} />
                  <div className="truncate font-mono text-[10px] text-muted-foreground">{item.fqn}</div>
                </TableCell>
                <TableCell className="text-xs font-medium">{item.proposed_name || "—"}</TableCell>
                <TableCell>
                  <span className="flex items-center gap-1">
                    <KindBadge kind={item.kind} />
                    {item.proposed_kind !== item.kind ? (
                      <>
                        <span className="text-[10px] text-muted-foreground">→</span>
                        <KindBadge kind={item.proposed_kind} />
                      </>
                    ) : null}
                  </span>
                </TableCell>
                <TableCell className="text-right">
                  <Badge variant={confidenceVariant(item.confidence)} className="h-5 text-[10px]">
                    {formatPercent(item.confidence)}
                  </Badge>
                </TableCell>
                <TableCell className="text-right font-mono text-xs">{item.metrics}</TableCell>
                <TableCell className="text-xs text-muted-foreground">{formatRelative(item.generated_at)}</TableCell>
                <TableCell className="text-right">
                  <Button size="sm" variant="outline" asChild>
                    <Link to={`/semantic/${item.asset_id}`}>Review</Link>
                  </Button>
                </TableCell>
              </TableRow>
            ))}
            {r && r.review_queue.length === 0 ? <EmptyRow colSpan={7}>Nothing waiting. Run “Name with Claude” on the Semantic Hub to propose names for undocumented assets.</EmptyRow> : null}
          </TableBody>
        </Table>
      </SectionCard>

      <SectionCard
        title={`Inferred joins to confirm · ${h?.inferred_joins ?? "…"}`}
        description="Lowest confidence first. A referential-integrity check on each pair tells you whether to declare it on the platform."
        actions={
          <Button variant="outline" size="sm" asChild>
            <Link to="/engineer/health">Catalog health</Link>
          </Button>
        }
      >
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Source</TableHead>
              <TableHead>Target</TableHead>
              <TableHead>On</TableHead>
              <TableHead className="text-right">Confidence</TableHead>
              <TableHead>Evidence</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {h?.review_joins.slice(0, 12).map((j) => (
              <TableRow key={j.id}>
                <TableCell>
                  <AssetLink id={j.source_asset_id} fqn={j.source_fqn} />
                </TableCell>
                <TableCell>
                  {j.target_asset_id ? <AssetLink id={j.target_asset_id} fqn={j.target_fqn} /> : <span className="font-mono text-xs text-muted-foreground">{j.target_fqn}</span>}
                </TableCell>
                <TableCell className="font-mono text-xs">
                  {j.source_columns.join(", ")}
                  {j.target_columns.length ? ` = ${j.target_columns.join(", ")}` : ""}
                </TableCell>
                <TableCell className="text-right">
                  <Badge variant={confidenceVariant(j.confidence)} className="h-5 text-[10px]">
                    {formatPercent(j.confidence)}
                  </Badge>
                </TableCell>
                <TableCell className="text-xs text-muted-foreground">{j.evidence}</TableCell>
              </TableRow>
            ))}
            {h && h.review_joins.length === 0 ? <EmptyRow colSpan={5}>Every join is declared.</EmptyRow> : null}
          </TableBody>
        </Table>
      </SectionCard>
    </div>
  );
}
