import { BookOpen, Landmark, ListChecks, Tags, Target, type LucideIcon } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";

import type { GlossaryTermKind, GlossaryTermRow } from "@/api/types";
import { DomainRail } from "@/components/glossary/domain-rail";
import { GlossaryOverview } from "@/components/glossary/glossary-overview";
import { KpiBoard } from "@/components/glossary/kpi-board";
import { ReviewQueue } from "@/components/glossary/review-queue";
import { TermDialog } from "@/components/glossary/term-dialog";
import { TermList } from "@/components/glossary/term-list";
import { HeroStats, PageHero } from "@/components/layout/page-hero";
import { ViewSwitcher } from "@/components/layout/view-switcher";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useGlossaryAutoMap, useGlossaryCoverage, useGlossaryDomains, useGlossaryKpis, useGlossaryMap, useGlossaryMapRun, useGlossaryTerms, useProposeTerms } from "@/hooks/queries";
import { describeError } from "@/lib/api-client";

const PAGE = 60;
const ALL = "__all__";
type Tab = "terms" | "kpis" | "review";
const TABS: { key: Tab; label: string; icon: LucideIcon; hint: string; tone: string }[] = [
  { key: "terms", label: "Terms", icon: Tags, hint: "Business terms by domain, with synonyms and mappings", tone: "#0EA5E9" },
  { key: "kpis", label: "KPIs", icon: Target, hint: "Formulas, grain, period and targets", tone: "#10B981" },
  { key: "review", label: "Review", icon: ListChecks, hint: "Claude's proposals waiting for a reviewer", tone: "#F59E0B" },
];

export function GlossaryPage() {
  const { tab: tabParam } = useParams<{ tab: string }>();
  const tab: Tab = tabParam === "kpis" || tabParam === "review" ? tabParam : "terms";
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const domain = searchParams.get("domain");
  const [search, setSearch] = useState(searchParams.get("search") ?? "");
  const [debounced, setDebounced] = useState(search.trim());
  const [kind, setKind] = useState<GlossaryTermKind | null>(null);
  const [offset, setOffset] = useState(0);
  const [dialogTerm, setDialogTerm] = useState<GlossaryTermRow | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [runId, setRunId] = useState<string | null>(null);

  useEffect(() => {
    const timer = window.setTimeout(() => setDebounced(search.trim()), 250);
    return () => window.clearTimeout(timer);
  }, [search]);
  useEffect(() => setOffset(0), [debounced, domain, kind]);

  const setDomain = (key: string | null) => {
    const next = new URLSearchParams(searchParams);
    if (key) next.set("domain", key);
    else next.delete("domain");
    setSearchParams(next, { replace: true });
  };
  const setTab = (next: Tab) => {
    const query = searchParams.toString();
    navigate({ pathname: next === "terms" ? "/glossary" : `/glossary/${next}`, search: query ? `?${query}` : "" });
  };

  const domains = useGlossaryDomains();
  const coverage = useGlossaryCoverage();
  const termParams = useMemo(() => ({ search: debounced || null, domain, kind, include_proposed: false, limit: PAGE, offset }), [debounced, domain, kind, offset]);
  const terms = useGlossaryTerms(termParams);
  const kpis = useGlossaryKpis(domain);
  const map = useGlossaryMap();
  const propose = useProposeTerms();
  const run = useGlossaryMapRun(runId);
  const auto = useGlossaryAutoMap();
  const startMap = () => map.mutate({ use_model: true, limit: 2000 }, { onSuccess: (r) => setRunId(r.id) });
  const startPropose = () => propose.mutate({ limit: 2000, batch_size: 24 }, { onSuccess: (r) => setRunId(r.id) });
  const running = run.data?.status === "running";
  const runError = map.error ?? propose.error;
  const toReview = (coverage.data?.links_suggested ?? 0) + (coverage.data?.terms_proposed ?? 0);
  const openTerm = (term: GlossaryTermRow | null) => {
    setDialogTerm(term);
    setDialogOpen(true);
  };
  const c = coverage.data;

  return (
    <>
      <div className="px-6 pt-6">
        <PageHero
          slim
          eyebrow="Data & semantics"
          icon={BookOpen}
          title="Business Glossary"
          lead="Canonical insurance terms with synonyms and definitions, a domain taxonomy aligned to ACORD with FIBO for party, contract and money, Claude-assisted mapping of datasets, columns and metrics to terms with review, and KPI definitions with grain, period and targets."
          aside={
            <HeroStats
              items={[
                { label: "Terms", value: c?.terms_total, icon: Tags },
                { label: "Domains", value: c?.domains_total, icon: Landmark },
                { label: "KPIs", value: c?.kpis_total, icon: Target },
                { label: "To review", value: c ? toReview : undefined, icon: ListChecks },
              ]}
            />
          }
        />
        <ViewSwitcher
          className="mt-3"
          label="Glossary sections"
          value={tab}
          onChange={setTab}
          views={TABS.map((t) => ({
            key: t.key,
            label: t.label,
            icon: t.icon,
            tone: t.tone,
            description: t.hint,
            count: !c ? null : t.key === "terms" ? `${c.terms_total} terms` : t.key === "kpis" ? `${c.kpis_total} KPIs` : `${toReview} to review`,
          }))}
        />
      </div>
      <div className="flex min-h-0 flex-1">
        <DomainRail domains={domains.data} loading={domains.isLoading} selected={domain} onSelect={setDomain} />
        <div className="flex min-h-0 min-w-0 flex-1 flex-col gap-4 overflow-y-auto p-4">
          <GlossaryOverview
            coverage={c}
            run={run.data ?? null}
            auto={auto.status}
            autoLive={auto.live}
            onMap={startMap}
            mapPending={map.isPending}
            onPropose={startPropose}
            proposePending={propose.isPending}
            error={runError ? describeError(runError) : null}
          />
          <div className="lg:hidden">
            <Select value={domain ?? ALL} onValueChange={(v) => setDomain(v === ALL ? null : v)}>
              <SelectTrigger className="h-8 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL} className="text-xs">
                  All domains
                </SelectItem>
                {(domains.data ?? []).flatMap((d) => [
                  <SelectItem key={d.key} value={d.key} className="text-xs">
                    {d.name}
                  </SelectItem>,
                  ...d.children.map((ch) => (
                    <SelectItem key={ch.key} value={ch.key} className="pl-6 text-xs">
                      {ch.name}
                    </SelectItem>
                  )),
                ])}
              </SelectContent>
            </Select>
          </div>
          {tab === "terms" ? (
            <TermList
              page={terms.data}
              loading={terms.isLoading}
              domains={domains.data}
              search={search}
              onSearch={setSearch}
              kind={kind}
              onKind={setKind}
              onOpen={openTerm}
              onCreate={() => openTerm(null)}
              offset={offset}
              onOffset={setOffset}
              pageSize={PAGE}
            />
          ) : null}
          {tab === "kpis" ? <KpiBoard kpis={kpis.data} loading={kpis.isLoading} domains={domains.data} /> : null}
          {tab === "review" ? <ReviewQueue domains={domains.data} running={running} /> : null}
        </div>
      </div>
      <TermDialog open={dialogOpen} onOpenChange={setDialogOpen} term={dialogTerm} domains={domains.data} defaultDomain={domain} />
    </>
  );
}
