import { BookOpen, Boxes, Layers, ShieldCheck } from "lucide-react";
import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";

import type { SemanticScope } from "@/api/types";
import { MetricCard } from "@/components/dashboard/metric-card";
import { PersonaChat } from "@/components/personas/persona-chat";
import { AssetLink, EmptyRow, PersonaShell, SectionCard, useDebounced } from "@/components/personas/persona-shell";
import { PersonaProfile } from "@/components/personas/persona-profile";
import { MetricSourceBadge, RoleBadge } from "@/components/semantic/badges";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useSemanticGlossary, useSemanticMetrics, useSemanticOverview } from "@/hooks/queries";
import { formatInt, formatRelative } from "@/lib/format";
import { PERSONAS, personaTab } from "@/lib/personas";

const persona = PERSONAS.business_analyst;
const PAGE = 50;

export function AnalystPage() {
  const { tab } = useParams<{ tab: string }>();
  const active = personaTab(persona, tab).key;
  return (
    <PersonaShell persona={persona} active={active} fill={active === "ask"}>
      {active === "overview" ? <Overview /> : null}
      {active === "metrics" ? <Metrics /> : null}
      {active === "glossary" ? <Glossary /> : null}
      {active === "domains" ? <Domains /> : null}
      {active === "ask" ? <PersonaChat persona="business_analyst" /> : null}
    </PersonaShell>
  );
}

// ----------------------------------------------------------------------------- overview
function Overview() {
  const overview = useSemanticOverview();
  const governed = useSemanticMetrics({ search: null, source: "declared", database: null, schema: null, limit: 8, offset: 0 });
  const o = overview.data;
  const metricViews = o ? (o.by_asset_type.metric_view ?? 0) + (o.by_asset_type.semantic_view ?? 0) : 0;
  const databases = o ? new Set(o.scopes.map((s) => `${s.platform}.${s.database_name}`)).size : 0;

  return (
    <div className="space-y-6">
      <PersonaProfile persona={persona} />

      {/* Only what needs attention or exists: a count tile shows once it is above zero. */}
      <section className="stat-grid">
        {o && o.declared_metrics > 0 ? (
          <MetricCard
            title="Governed metrics"
            value={formatInt(o?.declared_metrics)}
            hint={o ? `${formatInt(o.metrics - o.declared_metrics)} more are inferred, not certified` : undefined}
            icon={ShieldCheck}
            tone="success"
            loading={overview.isLoading}
          />
        ) : null}
        {metricViews > 0 ? (
          <MetricCard title="Metric views" value={formatInt(metricViews)} hint="governed definitions on the platform" icon={Layers} loading={overview.isLoading} />
        ) : null}
        <MetricCard
          title="Business domains"
          value={formatInt(o?.scopes.length)}
          hint={o ? `${databases} database${databases === 1 ? "" : "s"} · ${formatInt(o.assets)} datasets` : undefined}
          icon={Boxes}
          loading={overview.isLoading}
        />
        {o && (o.by_role.dimension ?? 0) > 0 ? (
          <MetricCard
            title="Dimensions"
            value={formatInt(o?.by_role.dimension)}
            hint={o ? `${formatInt(o.by_role.measure)} measures · ${formatInt(o.by_role.time)} time columns` : undefined}
            icon={BookOpen}
            loading={overview.isLoading}
          />
        ) : null}
      </section>

      <SectionCard
        title="Governed metrics"
        description="Declared in metric views or semantic views; the numbers the business can rely on."
        actions={
          <Button variant="outline" size="sm" asChild>
            <Link to={`${persona.path}/metrics`}>All metrics</Link>
          </Button>
        }
      >
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Metric</TableHead>
              <TableHead>Break down by</TableHead>
              <TableHead>Dataset</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {governed.data?.items.map((m) => (
              <TableRow key={m.id}>
                <TableCell>
                  <div className="font-medium">{m.name}</div>
                  <div className="line-clamp-2 text-xs text-muted-foreground">{m.description || m.expression}</div>
                </TableCell>
                <TableCell className="text-xs text-muted-foreground">{m.dimensions.join(", ") || "–"}</TableCell>
                <TableCell>
                  <AssetLink id={m.asset_id} fqn={m.asset_fqn} name={m.asset_name} />
                </TableCell>
              </TableRow>
            ))}
            {governed.data && governed.data.items.length === 0 ? (
              <EmptyRow colSpan={3}>No governed metrics yet. Declare metric views on the platform and re-run the connector.</EmptyRow>
            ) : null}
          </TableBody>
        </Table>
      </SectionCard>

    </div>
  );
}

// ----------------------------------------------------------------------------- metrics catalog
function Metrics() {
  const [search, setSearch] = useState("");
  const [source, setSource] = useState<"all" | "declared" | "inferred">("all");
  const [offset, setOffset] = useState(0);
  const debounced = useDebounced(search);
  useEffect(() => setOffset(0), [debounced, source]);
  const page = useSemanticMetrics({ search: debounced || null, source: source === "all" ? null : source, database: null, schema: null, limit: PAGE, offset });
  const total = page.data?.total ?? 0;

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search metrics by name, meaning or dataset…" className="max-w-md" />
        <Select value={source} onValueChange={(v) => setSource(v as typeof source)}>
          <SelectTrigger className="h-9 w-44 text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Governed and inferred</SelectItem>
            <SelectItem value="declared">Governed only</SelectItem>
            <SelectItem value="inferred">Inferred only</SelectItem>
          </SelectContent>
        </Select>
        <span className="text-xs text-muted-foreground">{total ? `${offset + 1}–${Math.min(offset + PAGE, total)} of ${total}` : page.isLoading ? "loading…" : "0 metrics"}</span>
      </div>
      <div className="overflow-auto rounded-lg border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Metric</TableHead>
              <TableHead>Calculation</TableHead>
              <TableHead>Break down by</TableHead>
              <TableHead>Dataset</TableHead>
              <TableHead>Governance</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {page.isLoading && !page.data
              ? Array.from({ length: 6 }).map((_, i) => (
                  <TableRow key={i}>
                    <TableCell colSpan={5}>
                      <Skeleton className="h-5 w-full" />
                    </TableCell>
                  </TableRow>
                ))
              : page.data?.items.map((m) => (
                  <TableRow key={m.id}>
                    <TableCell className="max-w-[22rem]">
                      <div className="font-medium">{m.name}</div>
                      {m.description ? <div className="line-clamp-2 text-xs text-muted-foreground">{m.description}</div> : null}
                    </TableCell>
                    <TableCell>
                      <code className="rounded bg-muted/60 px-1.5 py-0.5 font-mono text-[11px]">{m.expression || m.aggregation || "–"}</code>
                    </TableCell>
                    <TableCell className="max-w-[16rem] text-xs text-muted-foreground">{m.dimensions.join(", ") || "–"}</TableCell>
                    <TableCell>
                      <AssetLink id={m.asset_id} fqn={m.asset_fqn} name={m.asset_name} kind={m.asset_kind} />
                    </TableCell>
                    <TableCell>
                      <MetricSourceBadge source={m.source === "declared" ? "declared" : "inferred"} />
                    </TableCell>
                  </TableRow>
                ))}
            {page.data && page.data.items.length === 0 ? <EmptyRow colSpan={5}>No metrics match.</EmptyRow> : null}
          </TableBody>
        </Table>
      </div>
      <Pager offset={offset} total={total} onOffset={setOffset} />
    </div>
  );
}

// ----------------------------------------------------------------------------- glossary
const ROLES = ["dimension", "measure", "time", "identifier", "attribute"];

function Glossary() {
  const [search, setSearch] = useState("");
  const [role, setRole] = useState<string>("all");
  const [offset, setOffset] = useState(0);
  const debounced = useDebounced(search);
  useEffect(() => setOffset(0), [debounced, role]);
  const page = useSemanticGlossary({ search: debounced || null, role: role === "all" ? null : role, limit: PAGE, offset });
  const total = page.data?.total ?? 0;

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Look up a business term or column name…" className="max-w-md" />
        <Select value={role} onValueChange={setRole}>
          <SelectTrigger className="h-9 w-40 text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Every role</SelectItem>
            {ROLES.map((r) => (
              <SelectItem key={r} value={r} className="capitalize">
                {r}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <span className="text-xs text-muted-foreground">{total ? `${offset + 1}–${Math.min(offset + PAGE, total)} of ${total} terms` : page.isLoading ? "loading…" : "0 terms"}</span>
      </div>
      <div className="overflow-auto rounded-lg border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Term</TableHead>
              <TableHead>Meaning</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Types</TableHead>
              <TableHead>Used in</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {page.isLoading && !page.data
              ? Array.from({ length: 6 }).map((_, i) => (
                  <TableRow key={i}>
                    <TableCell colSpan={5}>
                      <Skeleton className="h-5 w-full" />
                    </TableCell>
                  </TableRow>
                ))
              : page.data?.items.map((t) => (
                  <TableRow key={t.term}>
                    <TableCell className="font-mono text-xs font-medium">{t.term}</TableCell>
                    <TableCell className="max-w-[24rem] text-xs text-muted-foreground">{t.description || <span className="italic">No business description yet</span>}</TableCell>
                    <TableCell>
                      <RoleBadge role={t.role} />
                      {t.declared ? <span className="ml-1 text-[10px] text-muted-foreground">declared</span> : null}
                    </TableCell>
                    <TableCell className="font-mono text-[11px] text-muted-foreground">{t.data_types.join(", ") || "–"}</TableCell>
                    <TableCell className="text-xs">
                      <span className="flex flex-wrap items-center gap-1">
                        {t.assets.slice(0, 3).map((a) => (
                          <Link key={a.id} to={`/semantic/${a.id}`} className="font-mono hover:underline" title={a.fqn}>
                            {a.fqn.split(".").slice(-1)[0]}
                          </Link>
                        ))}
                        {t.asset_count > 3 ? <Badge variant="muted" className="h-4 px-1 text-[10px]">+{t.asset_count - 3}</Badge> : null}
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
            {page.data && page.data.items.length === 0 ? <EmptyRow colSpan={5}>No terms match.</EmptyRow> : null}
          </TableBody>
        </Table>
      </div>
      <Pager offset={offset} total={total} onOffset={setOffset} />
    </div>
  );
}

// ----------------------------------------------------------------------------- domains
function Domains() {
  const overview = useSemanticOverview();
  if (overview.isLoading || !overview.data) return <Skeleton className="h-64 w-full" />;
  const groups = new Map<string, SemanticScope[]>();
  for (const scope of overview.data.scopes) {
    const key = `${scope.platform}.${scope.database_name}`;
    groups.set(key, [...(groups.get(key) ?? []), scope]);
  }
  if (groups.size === 0) {
    return <p className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">No domains yet. Once a connector has synced catalog metadata, each database and schema appears here.</p>;
  }
  return (
    <div className="grid gap-6 lg:grid-cols-2">
      {[...groups.entries()].map(([key, scopes]) => {
        const first = scopes[0];
        if (!first) return null;
        return (
          <SectionCard
            key={key}
            title={<span className="font-mono">{first.database_name}</span>}
            description={`${first.platform} · ${scopes.reduce((n, s) => n + s.assets, 0)} datasets across ${scopes.length} schema${scopes.length === 1 ? "" : "s"}`}
          >
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Schema</TableHead>
                  <TableHead className="text-right">Datasets</TableHead>
                  <TableHead className="text-right">Facts</TableHead>
                  <TableHead className="text-right">Dimensions</TableHead>
                  <TableHead className="text-right">Metric views</TableHead>
                  <TableHead />
                </TableRow>
              </TableHeader>
              <TableBody>
                {scopes.map((s) => (
                  <TableRow key={s.schema_name}>
                    <TableCell>
                      <div className="font-mono text-xs">{s.schema_name}</div>
                      <div className="text-[11px] text-muted-foreground">synced {formatRelative(s.synced_at)}</div>
                    </TableCell>
                    <TableCell className="text-right font-mono text-xs">{s.assets}</TableCell>
                    <TableCell className="text-right font-mono text-xs">{s.facts}</TableCell>
                    <TableCell className="text-right font-mono text-xs">{s.dimensions}</TableCell>
                    <TableCell className="text-right font-mono text-xs">{s.metric_views}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm" asChild>
                        <Link to={`/semantic?platform=${encodeURIComponent(s.platform)}&database=${encodeURIComponent(s.database_name)}&schema=${encodeURIComponent(s.schema_name)}`}>Browse</Link>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </SectionCard>
        );
      })}
    </div>
  );
}

function Pager({ offset, total, onOffset }: { offset: number; total: number; onOffset: (next: number) => void }) {
  if (total <= PAGE) return null;
  return (
    <div className="flex justify-end gap-1">
      <Button variant="outline" size="sm" disabled={offset === 0} onClick={() => onOffset(Math.max(0, offset - PAGE))}>
        Previous
      </Button>
      <Button variant="outline" size="sm" disabled={offset + PAGE >= total} onClick={() => onOffset(offset + PAGE)}>
        Next
      </Button>
    </div>
  );
}
