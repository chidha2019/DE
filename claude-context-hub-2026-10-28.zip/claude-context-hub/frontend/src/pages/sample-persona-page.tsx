import { useParams } from "react-router-dom";

import { PersonaChat } from "@/components/personas/persona-chat";
import { PersonaShell } from "@/components/personas/persona-shell";
import { SampleWorkspace } from "@/components/personas/sample-workspace";
import { PERSONAS, personaTab, type PersonaKey } from "@/lib/personas";

/** The workspaces that preview with sample data until their sources are connected; Ask runs on the live hub. */
export function SamplePersonaPage({ persona: key }: { persona: PersonaKey }) {
  const persona = PERSONAS[key];
  const { tab } = useParams<{ tab: string }>();
  const active = personaTab(persona, tab).key;
  // Keyed by persona so moving between two of these workspaces starts a fresh conversation.
  return (
    <PersonaShell key={key} persona={persona} active={active} fill={active === "ask"}>
      {active === "ask" ? <PersonaChat persona={key} /> : <SampleWorkspace persona={key} tab={active} />}
    </PersonaShell>
  );
}
