import { ArrowRight, Lock, ShieldCheck } from "lucide-react";
import { useNavigate } from "react-router-dom";

import { HeroArt } from "@/components/landing/hero-art";
import { BrandLogo } from "@/components/layout/brand";
import { useServiceHealth } from "@/hooks/queries";

const LAST_PATH_KEY = "ech-last-path";

/** Where "Open Context Hub" goes: the page the user left, else the Home dashboard. */
export function rememberPath(path: string) {
  try {
    if (path !== "/") sessionStorage.setItem(LAST_PATH_KEY, path);
  } catch {
    /* storage unavailable */
  }
}

function lastPath(): string {
  try {
    return sessionStorage.getItem(LAST_PATH_KEY) || "/home";
  } catch {
    return "/home";
  }
}

/** The entry page: cream, editorial, with the particle "connected context" artwork. Always light. */
export function LandingPage() {
  const navigate = useNavigate();
  const ingestion = useServiceHealth("ingestion");
  const query = useServiceHealth("query");
  const online = ingestion.data?.status === "ok" && query.data?.status === "ok";

  return (
    <div className="landing min-h-screen bg-[#f4f0e8] text-[#1b272b] antialiased">
      <div className="mx-auto flex min-h-screen max-w-[100rem] flex-col px-8 py-8 md:px-12">
        <header className="flex items-center justify-between">
          <BrandLogo variant="light" />
          <span className="hidden items-center gap-2 rounded-full border border-[#1b272b]/10 bg-white/60 px-3 py-1 text-[11px] text-[#1b272b]/70 md:flex">
            <span className={online ? "h-1.5 w-1.5 rounded-full bg-emerald-500" : "h-1.5 w-1.5 rounded-full bg-amber-500"} />
            {online ? "services online" : "checking services"}
          </span>
        </header>

        <main className="grid flex-1 items-center gap-10 py-10 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,1.3fr)_minmax(0,0.9fr)]">
          <div>
            <div className="flex items-center gap-2 text-[10px] font-medium uppercase tracking-[0.2em] text-[#1b272b]/60">
              <span className="h-1.5 w-1.5 rounded-full bg-[#b48a2e]" /> Context Hub
            </div>
            <h1 className="mt-7 font-serif text-[clamp(3rem,6vw,5.5rem)] leading-[0.98] tracking-[-0.01em]">
              Context that <em className="not-italic text-[#b48a2e]">moves</em> with the work.
            </h1>
            <p className="mt-8 max-w-sm text-[15px] leading-relaxed text-[#1b272b]/70">
              Connect enterprise sources, ingest their metadata, and build governed semantic definitions from the evidence.
            </p>
          </div>

          <div className="relative mx-auto w-full max-w-[640px]">
            <HeroArt color="#1b272b" />
            <div className="mt-3 border-t border-[#1b272b]/10 pt-2 text-center text-[9px] font-medium uppercase tracking-[0.3em] text-[#1b272b]/50">Connected context</div>
          </div>

          <div className="lg:justify-self-end">
            <div className="text-[10px] font-medium uppercase tracking-[0.2em] text-[#1b272b]/50">Your workspace, connected</div>
            <div className="mt-5 w-full max-w-[360px] rounded-xl border border-[#1b272b]/10 bg-[#f9f7f2] p-7 shadow-[0_24px_60px_-30px_rgba(27,39,43,0.35)]">
              <Lock className="h-5 w-5 text-[#1b272b]/60" />
              <h2 className="mt-6 font-display text-2xl font-medium tracking-tight">Open Context Hub</h2>
              <p className="mt-2 text-[13px] leading-relaxed text-[#1b272b]/65">Local development workspace. Source credentials are configured on the server.</p>
              <button
                type="button"
                onClick={() => navigate(lastPath())}
                className="mt-7 flex w-full items-center justify-center gap-2 rounded-md bg-[#1f2b2f] px-4 py-3 text-sm font-medium text-[#f4f0e8] transition-colors hover:bg-[#2c3b40]"
              >
                Open Context Hub <ArrowRight className="h-4 w-4" />
              </button>
            </div>
            <p className="mt-4 flex items-center gap-1.5 text-[11px] text-[#1b272b]/55">
              <ShieldCheck className="h-3.5 w-3.5" /> Governed context. Clear evidence.
            </p>
          </div>
        </main>

        <footer className="grid gap-6 border-t border-[#1b272b]/10 pt-6 md:grid-cols-3">
          {[
            ["Connect", "Saved source services"],
            ["Ingest", "Observed metadata"],
            ["Certify", "Reviewed definitions"],
          ].map(([title, caption]) => (
            <div key={title}>
              <div className="text-sm font-medium">{title}</div>
              <div className="text-xs text-[#1b272b]/55">{caption}</div>
            </div>
          ))}
        </footer>
      </div>
    </div>
  );
}
