import { AlertTriangle, Database, GitFork, KeyRound, Layers, RefreshCw, Workflow } from "lucide-react";
import { useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

import type { ConnectorInfo, HealthAssetRef } from "@/api/types";
import { ActivityChart } from "@/components/dashboard/activity-chart";
import { ErDiagramView } from "@/components/er/er-diagram";
import { MetricCard } from "@/components/dashboard/metric-card";
import { ForceGraph } from "@/components/explorer/force-graph";
import { KpiSummaryLine, KpiTile, TargetsTable } from "@/components/personas/kpi-tiles";
import { PersonaChat } from "@/components/personas/persona-chat";
import { AssetLink, EmptyRow, PersonaShell, SectionCard } from "@/components/personas/persona-shell";
import { PersonaProfile } from "@/components/personas/persona-profile";
import { ConnectorCard } from "@/components/pipelines/connector-card";
import { RunTable } from "@/components/pipelines/run-table";
import { TriggerRunDialog } from "@/components/pipelines/trigger-run-dialog";
import { WorkerConsole } from "@/components/worker/worker-console";
import { toGraphPayload } from "@/components/semantic/asset-detail";
import { KindBadge, TypeBadge, relationshipLabel } from "@/components/semantic/badges";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  useActivity,
  useConnectors,
  useDesignDiagrams,
  useEngineeringKpis,
  useIntentDiagram,
  useIntents,
  useOverview,
  useRuns,
  useSemanticAsset,
  useSemanticAssets,
  useSemanticGraph,
  useSemanticHealth,
  useSemanticOverview,
  useSemanticSearch,
} from "@/hooks/queries";
import { formatCompact, formatDateTime, formatInt, formatPercent, formatRelative } from "@/lib/format";
import { documentPath } from "@/lib/knowledge-paths";
import { PERSONAS, personaTab } from "@/lib/personas";
import { cn } from "@/lib/utils";

const persona = PERSONAS.data_engineer;

export function EngineerPage() {
  const { tab } = useParams<{ tab: string }>();
  const active = personaTab(persona, tab).key;
  return (
    <PersonaShell persona={persona} active={active} fill={active === "ask"}>
      {/* The workspace opens on its digital worker; the targets it works toward are one tab over. */}
      {active === "overview" ? <WorkerConsole worker="data_engineer" /> : null}
      {active === "datamodels" ? <DataModels /> : null}
      {active === "goals" ? <Overview /> : null}
      {active === "pipelines" ? <Pipelines /> : null}
      {active === "health" ? <Health /> : null}
      {active === "lineage" ? <Lineage /> : null}
      {active === "ask" ? <PersonaChat persona="data_engineer" /> : null}
    </PersonaShell>
  );
}

// ----------------------------------------------------------------------------- data models
/** The ER diagram of each modelled layer: the design documents under the data folder, and every plan that models tables. */
function DataModels() {
  const designs = useDesignDiagrams();
  const intents = useIntents({ status: null, limit: 50, offset: 0 });
  const plans = (intents.data?.items ?? []).filter((i) => i.spec?.models?.length);
  const sources = [
    ...(designs.data ?? []).map((d) => ({ key: d.key, label: d.origin, hint: `design documents · ${d.entities.filter((e) => e.kind !== "external").length} tables` })),
    ...plans.map((i) => ({ key: `intent:${i.id}`, label: i.jira_key ?? i.title, hint: `plan · ${i.spec?.models?.length ?? 0} tables · ${i.status.replace(/_/g, " ")}` })),
  ];
  const [picked, setPicked] = useState<string | null>(null);
  const current = picked && sources.some((s) => s.key === picked) ? picked : (sources[0]?.key ?? null);
  const planId = current?.startsWith("intent:") ? current.slice("intent:".length) : null;
  const plan = useIntentDiagram(planId, Boolean(planId));
  const diagram = planId ? plan.data : designs.data?.find((d) => d.key === current);
  const loading = designs.isLoading || intents.isLoading || (Boolean(planId) && plan.isLoading);

  return (
    <SectionCard
      title="Data models"
      description="Entities, keys and relationships of each modelled layer, drawn from the design documents under the data folder and from every plan the worker has modelled."
    >
      <div className="space-y-4 px-6 pb-6">
        {sources.length > 1 ? (
          <div className="flex flex-wrap gap-2" role="group" aria-label="Which model">
            {sources.map((s) => (
              <button
                key={s.key}
                type="button"
                aria-pressed={s.key === current}
                onClick={() => setPicked(s.key)}
                className={cn(
                  "rounded-xl border px-3 py-1.5 text-left text-xs transition-colors",
                  s.key === current ? "border-primary/50 bg-primary/10" : "border-border/70 bg-card hover:bg-muted/50",
                )}
              >
                <span className="block font-medium">{s.label}</span>
                <span className="block text-[11px] text-muted-foreground">{s.hint}</span>
              </button>
            ))}
          </div>
        ) : null}
        {loading ? (
          <Skeleton className="h-96 w-full rounded-xl" />
        ) : diagram ? (
          <>
            <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
              <h3 className="font-display text-base font-medium">{diagram.title}</h3>
              {diagram.files.length ? <span className="text-[11px] text-muted-foreground">from {diagram.files.join(" · ")}</span> : null}
            </div>
            <ErDiagramView diagram={diagram} />
          </>
        ) : (
          <p className="rounded-xl border border-dashed p-4 text-sm text-muted-foreground">
            No model to draw yet. Put a data model and its DDL under the data folder, or{" "}
            <Link to="/intents" className="font-medium text-primary hover:underline">
              start a Silver or Gold request from Jira
            </Link>
            .
          </p>
        )}
      </div>
    </SectionCard>
  );
}

// ----------------------------------------------------------------------------- overview
function Overview() {
  const semantic = useSemanticOverview();
  const health = useSemanticHealth();
  const connectors = useConnectors();
  const stats = useOverview();
  const runs = useRuns({ status: null, limit: 5 });
  const navigate = useNavigate();
  const s = semantic.data;
  const h = health.data;
  const st = stats.data;
  const healthy = connectors.data?.filter((c) => c.healthy).length ?? 0;
  const undocumented = h ? h.assets - h.described : 0;
  const keyless = h ? h.facts - h.keyed_facts : 0;

  return (
    <div className="space-y-6">
      <PersonaProfile persona={persona} allKpis={<AllKpis />} />

      {/* Only what needs attention: a count tile shows once it is above zero. */}
      <section className="stat-grid">
        <MetricCard
          title="Catalog assets"
          value={formatInt(s?.assets)}
          hint={s ? `${formatCompact(s.fields)} columns · synced ${formatRelative(s.last_synced_at)}` : undefined}
          icon={Layers}
          loading={semantic.isLoading}
        />
        <MetricCard
          title="Connectors healthy"
          value={connectors.data ? `${healthy}/${connectors.data.length}` : "—"}
          hint={connectors.data?.length ? connectors.data.map((c) => c.name).join(", ") : "none configured"}
          icon={Workflow}
          tone={connectors.data && healthy < connectors.data.length ? "warning" : "success"}
          loading={connectors.isLoading}
        />
        {st && st.runs_active > 0 ? (
          <MetricCard
            title="Runs active"
            value={formatInt(st?.runs_active)}
            hint={st ? `${formatInt(st.runs_total)} total · last ${formatRelative(st.last_run_at)}` : undefined}
            icon={RefreshCw}
            tone={st && st.runs_active > 0 ? "warning" : "default"}
            loading={stats.isLoading}
          />
        ) : null}
        {st && st.documents_graph_pending > 0 ? (
          <MetricCard
            title="Graph sync pending"
            value={formatInt(st?.documents_graph_pending)}
            hint={st && st.documents_graph_pending > 0 ? "documents not yet in Neo4j" : "Postgres and Neo4j consistent"}
            icon={Database}
            tone={st && st.documents_graph_pending > 0 ? "warning" : "success"}
            loading={stats.isLoading}
          />
        ) : null}
        {undocumented > 0 ? (
          <MetricCard
            title="Undocumented assets"
            value={formatInt(undocumented)}
            hint={h ? `${formatPercent(h.assets ? h.described / h.assets : 0)} of assets described` : undefined}
            icon={AlertTriangle}
            tone={undocumented > 0 ? "warning" : "success"}
            loading={health.isLoading}
          />
        ) : null}
        {keyless > 0 ? (
          <MetricCard
            title="Facts without a key"
            value={formatInt(keyless)}
            hint={h ? `${h.keyed_facts} of ${h.facts} facts have a primary key` : undefined}
            icon={KeyRound}
            tone={keyless > 0 ? "warning" : "success"}
            loading={health.isLoading}
          />
        ) : null}
        {h && h.low_confidence_joins > 0 ? (
          <MetricCard
            title="Joins to review"
            value={formatInt(h?.low_confidence_joins)}
            hint={h ? `${h.inferred_joins} inferred joins in total` : undefined}
            icon={GitFork}
            tone={h && h.low_confidence_joins > 0 ? "warning" : "success"}
            loading={health.isLoading}
          />
        ) : null}
        {s && s.declared_metrics > 0 ? (
          <MetricCard
            title="Declared metrics"
            value={formatInt(s?.declared_metrics)}
            hint={s ? `${formatInt(s.metrics - s.declared_metrics)} inferred` : undefined}
            icon={Layers}
            loading={semantic.isLoading}
          />
        ) : null}
      </section>

      <section className="grid gap-6 lg:grid-cols-5">
        <SectionCard
          className="lg:col-span-3"
          title="Catalog scopes"
          description="What the connectors synced, by database and schema."
          actions={
            <Button variant="outline" size="sm" asChild>
              <Link to="/semantic">Semantic Hub</Link>
            </Button>
          }
        >
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Scope</TableHead>
                <TableHead className="text-right">Assets</TableHead>
                <TableHead className="text-right">Facts</TableHead>
                <TableHead className="text-right">Dims</TableHead>
                <TableHead className="text-right">Metric views</TableHead>
                <TableHead>Synced</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {s?.scopes.map((scope) => (
                <TableRow key={`${scope.platform}.${scope.database_name}.${scope.schema_name}`}>
                  <TableCell className="font-mono text-xs">
                    <span className="text-muted-foreground">{scope.platform} · </span>
                    {scope.database_name}.{scope.schema_name}
                  </TableCell>
                  <TableCell className="text-right font-mono text-xs">{scope.assets}</TableCell>
                  <TableCell className="text-right font-mono text-xs">{scope.facts}</TableCell>
                  <TableCell className="text-right font-mono text-xs">{scope.dimensions}</TableCell>
                  <TableCell className="text-right font-mono text-xs">{scope.metric_views}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{formatRelative(scope.synced_at)}</TableCell>
                </TableRow>
              ))}
              {s && s.scopes.length === 0 ? <EmptyRow colSpan={6}>No catalog metadata yet. Run the Databricks or Snowflake connector from the Pipelines tab.</EmptyRow> : null}
            </TableBody>
          </Table>
        </SectionCard>
        <SectionCard className="lg:col-span-2" title="Recent runs" description="Click a run to open Pipelines with live events.">
          <RunTable runs={runs.data?.items} loading={runs.isLoading} selectedId={null} onSelect={() => navigate("/pipelines")} />
        </SectionCard>
      </section>
    </div>
  );
}

// ----------------------------------------------------------------------------- all KPIs (under Goals)
const WINDOWS = [7, 14, 30] as const;
type Days = (typeof WINDOWS)[number];

function WindowSelect({ value, onChange }: { value: Days; onChange: (next: Days) => void }) {
  return (
    <Select value={String(value)} onValueChange={(v) => onChange(Number(v) as Days)}>
      <SelectTrigger className="h-8 w-36 text-xs">
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {WINDOWS.map((w) => (
          <SelectItem key={w} value={String(w)}>
            Last {w} days
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

/** Every engineering KPI by group, plus the targets behind them. Opened from the Goals card. */
function AllKpis() {
  const [days, setDays] = useState<Days>(7);
  const kpis = useEngineeringKpis(days);
  const data = kpis.data;
  const overridden = data?.targets.filter((t) => t.overridden).length ?? 0;
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center gap-3">
        <WindowSelect value={days} onChange={setDays} />
        {data ? <KpiSummaryLine kpis={data.groups.flatMap((g) => g.kpis)} suffix={`computed ${formatRelative(data.generated_at)}`} /> : null}
      </div>
      {!data ? (
        <Skeleton className="h-64 w-full" />
      ) : (
        data.groups.map((group) => (
          <section key={group.key}>
            <h2 className="text-sm font-medium">{group.label}</h2>
            <p className="mb-3 text-xs text-muted-foreground">{group.description}</p>
            <div className="kpi-grid">
              {group.kpis.map((k) => (
                <KpiTile key={k.key} kpi={k} />
              ))}
            </div>
          </section>
        ))
      )}
      <SectionCard
        title={`Active targets${overridden ? ` · ${overridden} custom` : ""}`}
        description="Set ECH_KPI_TARGET_* in .env and restart the query service to change a target; unset variables keep the defaults."
      >
        <TargetsTable targets={data?.targets} />
      </SectionCard>
    </div>
  );
}

/** Runs per day and connector freshness for the Pipelines tab. */
function RunActivity() {
  const [days, setDays] = useState<Days>(7);
  const kpis = useEngineeringKpis(days);
  const activity = useActivity(days * 24, 24 * 60);
  const connectors = useConnectors();
  const registered = new Set(connectors.data?.map((c) => c.name) ?? []);
  const data = kpis.data;
  return (
    <section className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-sm font-medium text-muted-foreground">Run activity</h2>
        <WindowSelect value={days} onChange={setDays} />
      </div>
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
        <SectionCard className="lg:col-span-3" title="Runs per day" description="Completed, failed and cancelled runs with documents upserted.">
          <div className="p-4">
            <ActivityChart points={activity.data} loading={activity.isLoading} height={240} />
          </div>
        </SectionCard>
        <SectionCard className="lg:col-span-2" title="Connector freshness" description="Last successful run per connector and its activity in the window.">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Connector</TableHead>
                <TableHead>Last success</TableHead>
                <TableHead className="text-right">Runs</TableHead>
                <TableHead className="text-right">Failed</TableHead>
                <TableHead className="text-right">Docs</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data?.connectors.map((c) => {
                const live = registered.has(c.connector);
                const stale = c.age_hours === null || c.age_hours > 24;
                return (
                  <TableRow key={c.connector} className={cn(!live && "opacity-60")}>
                    <TableCell>
                      <div className="font-mono text-xs">{c.connector}</div>
                      <div className="text-[11px] text-muted-foreground">
                        {live ? c.source_system : "not registered"}
                        {c.last_status && c.last_status !== "completed" ? ` · last ${c.last_status}` : ""}
                      </div>
                    </TableCell>
                    <TableCell className="text-xs" title={c.last_success_at ? formatDateTime(c.last_success_at) : undefined}>
                      <span className={cn(live && stale ? "text-warning" : "text-muted-foreground")}>
                        {c.last_success_at ? formatRelative(c.last_success_at) : "never"}
                      </span>
                    </TableCell>
                    <TableCell className="text-right font-mono text-xs">{c.runs}</TableCell>
                    <TableCell className={cn("text-right font-mono text-xs", c.failed > 0 && "text-destructive")}>{c.failed}</TableCell>
                    <TableCell className="text-right font-mono text-xs">{formatInt(c.documents_upserted)}</TableCell>
                  </TableRow>
                );
              })}
              {data && data.connectors.length === 0 ? <EmptyRow colSpan={5}>No runs recorded yet.</EmptyRow> : null}
            </TableBody>
          </Table>
        </SectionCard>
      </div>
    </section>
  );
}

// ----------------------------------------------------------------------------- pipelines
function Pipelines() {
  const connectors = useConnectors();
  const runs = useRuns({ status: null, limit: 15 });
  const [dialog, setDialog] = useState<ConnectorInfo | null>(null);
  const navigate = useNavigate();
  const busy = useMemo(() => {
    const set = new Set<string>();
    for (const r of runs.data?.items ?? []) if (r.status === "running" || r.status === "paused" || r.status === "queued") set.add(r.connector_name);
    return set;
  }, [runs.data]);

  return (
    <div className="space-y-6">
      <section>
        <h2 className="mb-3 text-sm font-medium text-muted-foreground">Connectors</h2>
        {connectors.isLoading ? (
          <Skeleton className="h-36" />
        ) : connectors.data?.length ? (
          <div className="tile-grid">
            {connectors.data.map((c) => (
              <ConnectorCard key={c.name} connector={c} busy={busy.has(c.name)} onRun={setDialog} />
            ))}
          </div>
        ) : (
          <p className="rounded-lg border border-dashed p-4 text-sm text-muted-foreground">
            No connectors are configured. Set DATABRICKS_HOST, DATABRICKS_TOKEN and ECH_DATABRICKS_CATALOGS, the ECH_SNOWFLAKE_* variables, or ECH_GITHUB_REPOS, then restart the ingestion service.
          </p>
        )}
      </section>
      <SectionCard
        title="Recent runs"
        description={runs.data ? `${formatInt(runs.data.total)} runs · open Pipelines for live events, pause, resume and cancel` : "loading…"}
        actions={
          <Button variant="outline" size="sm" asChild>
            <Link to="/pipelines">Pipelines</Link>
          </Button>
        }
      >
        <RunTable runs={runs.data?.items} loading={runs.isLoading} selectedId={null} onSelect={() => navigate("/pipelines")} />
      </SectionCard>
      <RunActivity />
      <TriggerRunDialog connector={dialog} onClose={() => setDialog(null)} />
    </div>
  );
}

// ----------------------------------------------------------------------------- catalog health
function Health() {
  const health = useSemanticHealth();
  const h = health.data;
  if (!h) return <Skeleton className="h-64 w-full" />;
  const lists: Array<{ title: string; description: string; items: HealthAssetRef[] }> = [
    { title: `Undocumented · ${h.assets - h.described}`, description: "No description in the catalog, so Genie and analysts cannot explain them.", items: h.undocumented },
    { title: `No owner · ${h.assets - h.owned}`, description: "Nobody to ask. Set an owner on the platform and re-sync.", items: h.unowned },
    { title: `Facts without a primary key · ${h.facts - h.keyed_facts}`, description: "Joins to these can only be inferred.", items: h.keyless_facts },
    { title: `Isolated assets · ${h.isolated}`, description: "No keys, joins or lineage connect them to anything.", items: h.orphans },
  ];

  return (
    <div className="space-y-6">
      <SectionCard title="Coverage by schema" description="Documented, owned and keyed shares per scope; the gaps below are what to fix first.">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Scope</TableHead>
              <TableHead className="text-right">Assets</TableHead>
              <TableHead className="text-right">Described</TableHead>
              <TableHead className="text-right">Owned</TableHead>
              <TableHead className="text-right">Facts keyed</TableHead>
              <TableHead>Synced</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {h.coverage.map((c) => (
              <TableRow key={`${c.platform}.${c.database_name}.${c.schema_name}`}>
                <TableCell className="font-mono text-xs">
                  <span className="text-muted-foreground">{c.platform} · </span>
                  {c.database_name}.{c.schema_name}
                </TableCell>
                <TableCell className="text-right font-mono text-xs">{c.assets}</TableCell>
                <TableCell className="text-right font-mono text-xs">{formatPercent(c.assets ? c.described / c.assets : 0)}</TableCell>
                <TableCell className="text-right font-mono text-xs">{formatPercent(c.assets ? c.owned / c.assets : 0)}</TableCell>
                <TableCell className="text-right font-mono text-xs">{c.facts ? `${c.keyed_facts}/${c.facts}` : "–"}</TableCell>
                <TableCell className="text-xs text-muted-foreground">{formatRelative(c.synced_at)}</TableCell>
              </TableRow>
            ))}
            {h.coverage.length === 0 ? <EmptyRow colSpan={6}>No catalog metadata yet.</EmptyRow> : null}
          </TableBody>
        </Table>
      </SectionCard>

      <section className="grid gap-6 lg:grid-cols-2">
        {lists.map((list) => (
          <SectionCard key={list.title} title={list.title} description={list.description}>
            <AssetList items={list.items} />
          </SectionCard>
        ))}
      </section>

      <SectionCard
        title={`Inferred joins to review · ${h.inferred_joins}`}
        description="Lowest confidence first. Declare them as constraints or metric-view joins on the platform once confirmed."
      >
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Source</TableHead>
              <TableHead>Target</TableHead>
              <TableHead>On</TableHead>
              <TableHead className="text-right">Confidence</TableHead>
              <TableHead>Evidence</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {h.review_joins.map((j) => (
              <TableRow key={j.id}>
                <TableCell>
                  <AssetLink id={j.source_asset_id} fqn={j.source_fqn} />
                </TableCell>
                <TableCell>
                  {j.target_asset_id ? (
                    <AssetLink id={j.target_asset_id} fqn={j.target_fqn} />
                  ) : (
                    <span className="font-mono text-xs text-muted-foreground">{j.target_fqn}</span>
                  )}
                </TableCell>
                <TableCell className="font-mono text-xs">
                  {j.source_columns.join(", ")}
                  {j.target_columns.length ? ` = ${j.target_columns.join(", ")}` : ""}
                </TableCell>
                <TableCell className="text-right font-mono text-xs">{formatPercent(j.confidence)}</TableCell>
                <TableCell className="text-xs text-muted-foreground">{j.evidence}</TableCell>
              </TableRow>
            ))}
            {h.review_joins.length === 0 ? <EmptyRow colSpan={5}>No inferred joins; every join is declared.</EmptyRow> : null}
          </TableBody>
        </Table>
      </SectionCard>
    </div>
  );
}

function AssetList({ items }: { items: HealthAssetRef[] }) {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Asset</TableHead>
          <TableHead className="text-right">Columns</TableHead>
          <TableHead>Owner</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {items.map((a) => (
          <TableRow key={a.id}>
            <TableCell>
              <span className="flex items-center gap-2">
                <AssetLink id={a.id} fqn={a.fqn} kind={a.kind} />
                <TypeBadge assetType={a.asset_type} />
              </span>
            </TableCell>
            <TableCell className="text-right font-mono text-xs">{a.field_count}</TableCell>
            <TableCell className="text-xs text-muted-foreground">{a.owner ?? "–"}</TableCell>
          </TableRow>
        ))}
        {items.length === 0 ? <EmptyRow colSpan={3}>Nothing to fix here.</EmptyRow> : null}
      </TableBody>
    </Table>
  );
}

// ----------------------------------------------------------------------------- lineage
function Lineage() {
  const [query, setQuery] = useState("");
  const [picked, setPicked] = useState<string | null>(null);
  const search = useSemanticSearch(query);
  const facts = useSemanticAssets({ search: null, source_system: null, database: null, schema: null, kind: "fact", limit: 1, offset: 0 });
  const assetId = picked ?? facts.data?.items[0]?.id ?? null;
  const asset = useSemanticAsset(assetId);
  const graph = useSemanticGraph(assetId, 2);
  const payload = useMemo(() => (graph.data ? toGraphPayload(graph.data) : undefined), [graph.data]);

  return (
    <div className="grid min-h-[70vh] gap-6 lg:grid-cols-5">
      <div className="space-y-3 lg:col-span-2">
        <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Find a table, view or metric view…" />
        <div className="max-h-56 overflow-auto rounded-lg border bg-card">
          {search.data?.assets.length ? (
            search.data.assets.map((a) => (
              <button
                key={a.id}
                type="button"
                onClick={() => setPicked(a.id)}
                className={cn("flex w-full items-center justify-between gap-2 px-3 py-2 text-left text-xs hover:bg-accent", a.id === assetId && "bg-accent")}
              >
                <span className="truncate font-mono">{a.fqn}</span>
                <KindBadge kind={a.kind} />
              </button>
            ))
          ) : (
            <p className="p-3 text-xs text-muted-foreground">{query.trim().length >= 2 ? "No matches." : "Type at least two characters, or start from the fact table shown."}</p>
          )}
        </div>
        {asset.data ? (
          <SectionCard
            title={asset.data.name}
            description={asset.data.fqn}
            actions={
              <div className="flex gap-1">
                <Button size="sm" variant="outline" asChild>
                  <Link to={`/semantic/${asset.data.id}`}>Asset</Link>
                </Button>
                <Button size="sm" variant="outline" asChild>
                  <Link to={documentPath(asset.data.document_id)}>Entities</Link>
                </Button>
              </div>
            }
          >
            <ul className="divide-y text-xs">
              {asset.data.relationships.map((r) => (
                <li key={r.id} className="flex flex-wrap items-center gap-2 px-4 py-2">
                  <Badge variant="outline" className="h-5 text-[10px]">
                    {relationshipLabel(r.kind)}
                    {r.direction === "in" ? " (incoming)" : ""}
                  </Badge>
                  {r.other_asset_id ? (
                    <Link to={`/semantic/${r.other_asset_id}`} className="font-mono hover:underline">
                      {r.other_fqn}
                    </Link>
                  ) : (
                    <span className="font-mono text-muted-foreground">{r.other_fqn}</span>
                  )}
                  {r.source_columns.length ? <span className="text-muted-foreground">on {r.source_columns.join(", ")}</span> : null}
                  {r.kind === "join_inferred" ? <span className="text-muted-foreground">{formatPercent(r.confidence)}</span> : null}
                </li>
              ))}
              {asset.data.relationships.length === 0 ? <li className="px-4 py-6 text-center text-muted-foreground">No keys, joins or lineage recorded.</li> : null}
            </ul>
          </SectionCard>
        ) : null}
      </div>
      <div className="relative min-h-[420px] overflow-hidden rounded-lg border bg-card lg:col-span-3">
        <ForceGraph
          data={payload}
          loading={graph.isLoading}
          selectedId={assetId ?? undefined}
          fill
          onNodeClick={(n) => setPicked(n.id)}
          emptyMessage="Pick an asset to see two hops of keys, joins and lineage."
        />
      </div>
    </div>
  );
}
