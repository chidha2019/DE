import { BrainCircuit, Columns3, Focus, FolderGit2, GitFork, Library, Share2, ShieldCheck, Table2, type LucideIcon } from "lucide-react";
import { Navigate, useLocation, useParams } from "react-router-dom";

import { DocumentsSection } from "@/components/knowledge/documents-section";
import { RepositoriesSection } from "@/components/knowledge/repositories-section";
import { HeroStats, PageHero } from "@/components/layout/page-hero";
import { ViewSwitcher } from "@/components/layout/view-switcher";
import { useGraphStats } from "@/hooks/queries";
import { useRepoGraphRepos } from "@/hooks/repo-graph";
import { formatCompact } from "@/lib/format";
import { KNOWLEDGE_DOCUMENTS_PATH, KNOWLEDGE_PATH, documentPath } from "@/lib/knowledge-paths";

export type KnowledgeSection = "repositories" | "documents";

const SECTIONS: { key: KnowledgeSection; to: string; label: string; icon: LucideIcon; hint: string; tone: string }[] = [
  { key: "repositories", to: KNOWLEDGE_PATH, label: "Repositories", icon: FolderGit2, hint: "Crawled GitHub repos: lineage, graph, files", tone: "#8B5CF6" },
  { key: "documents", to: KNOWLEDGE_DOCUMENTS_PATH, label: "Documents & entities", icon: BrainCircuit, hint: "What Genie retrieves: chunks and entities", tone: "#EC4899" },
];

export function KnowledgeHubPage({ section }: { section: KnowledgeSection }) {
  const repos = useRepoGraphRepos();
  const graph = useGraphStats();
  const crawled = repos.data?.crawled ?? [];
  const total = (kind: string) => crawled.reduce((sum, r) => sum + (r.counts[kind] ?? 0), 0);
  const stats =
    section === "repositories"
      ? [
          { label: "Repos", value: crawled.length, icon: FolderGit2 },
          { label: "Tables", value: total("table"), icon: Table2 },
          { label: "Columns", value: total("column"), icon: Columns3 },
          { label: "Checks", value: total("check"), icon: ShieldCheck },
        ]
      : [
          { label: "Nodes", value: graph.data?.nodes_total, icon: Share2 },
          { label: "Edges", value: graph.data?.edges_total, icon: GitFork },
          { label: "Entities", value: graph.data?.nodes_by_label.Entity ?? 0, icon: Focus },
        ];

  return (
    <div className="flex-1 space-y-5 overflow-auto p-4 md:space-y-6 md:p-6">
      <PageHero
        slim
        eyebrow="Knowledge"
        icon={Library}
        title="Knowledge Hub"
        lead="GitHub repositories crawled into a graph of their data pipelines, and the documents and entities Genie retrieves from."
        sub="Genie queries both; the intent planner reuses the repository graph when it designs a new pipeline."
        aside={<HeroStats items={stats} />}
      />
      <ViewSwitcher
        label="Knowledge Hub sections"
        value={section}
        views={SECTIONS.map((s) => ({
          key: s.key,
          label: s.label,
          icon: s.icon,
          to: s.to,
          tone: s.tone,
          description: s.hint,
          count: s.key === "repositories" ? (repos.data ? `${crawled.length} repos` : null) : graph.data ? `${formatCompact(graph.data.nodes_total)} nodes` : null,
        }))}
      />
      {section === "repositories" ? <RepositoriesSection /> : <DocumentsSection />}
    </div>
  );
}

/** /repo-graph?repo=…&node=… links (planner specs store them) keep their query. */
export function RepoGraphRedirect() {
  const { search } = useLocation();
  return <Navigate to={`${KNOWLEDGE_PATH}${search}`} replace />;
}

/** /explorer/:id and /lineage/:id open the document in the Knowledge Hub. */
export function DocumentRedirect() {
  const { documentId } = useParams<{ documentId: string }>();
  return <Navigate to={documentId ? documentPath(documentId) : KNOWLEDGE_DOCUMENTS_PATH} replace />;
}
