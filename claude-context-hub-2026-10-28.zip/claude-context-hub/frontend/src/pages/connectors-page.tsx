import {
  Activity,
  BookOpen,
  Cable,
  CheckCircle2,
  Database,
  FileText,
  GitBranch,
  Layers,
  LayoutDashboard,
  Plug,
  RefreshCw,
  Search,
  Sparkles,
  Workflow,
  type LucideIcon,
} from "lucide-react";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import { Link, useSearchParams } from "react-router-dom";

import type { CatalogAvailability, ConnectorCatalogEntry, ConnectorInfo, SourceSystem } from "@/api/types";
import { BrandMark } from "@/components/connectors/brand-mark";
import { ConnectionCard } from "@/components/connectors/connection-card";
import { ConnectionEditor } from "@/components/connectors/connection-editor";
import { ConnectorDetail, LibraryTile } from "@/components/connectors/library-tile";
import { TriggerRunDialog } from "@/components/pipelines/trigger-run-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { useConnectorCatalog } from "@/hooks/queries";
import { formatInt, formatRelative } from "@/lib/format";
import { rgba } from "@/lib/tones";
import { cn } from "@/lib/utils";

const CATEGORY_ICONS: Record<string, LucideIcon> = {
  platforms: Layers,
  databases: Database,
  sdlc: GitBranch,
  knowledge: BookOpen,
  transformation: Workflow,
  bi: LayoutDashboard,
  observability: Activity,
};

type LibraryFilter = "all" | Exclude<CatalogAvailability, "configured">;

/** The run dialog speaks ConnectorInfo; a live catalogue entry carries the same facts. */
function toConnectorInfo(entry: ConnectorCatalogEntry): ConnectorInfo {
  return {
    name: entry.adapter ?? entry.key,
    source_system: (entry.source_system ?? "manual") as SourceSystem,
    display_name: entry.name,
    description: entry.description,
    healthy: entry.healthy ?? false,
    details: entry.health_details,
    estimated_documents: entry.estimated_documents,
    discoverable: false,
    scope_levels: [],
    option_keys: [],
    latency_ms: entry.health_latency_ms,
  };
}

function Stat({ icon: Icon, value, label, tone }: { icon: LucideIcon; value: ReactNode; label: string; tone: string }) {
  return (
    <div className="flex items-center gap-2.5 rounded-xl border bg-background/70 px-3 py-2 backdrop-blur" style={{ borderColor: rgba(tone, 0.28) }}>
      <span
        className="flex h-8 w-8 items-center justify-center rounded-lg"
        style={{
          background: `linear-gradient(145deg, ${rgba(tone, 0.22)}, ${rgba(tone, 0.08)})`,
          color: tone,
          boxShadow: `inset 0 0 0 1px ${rgba(tone, 0.35)}`,
        }}
      >
        <Icon className="h-4 w-4" aria-hidden="true" />
      </span>
      <span>
        <span className="block font-display text-lg font-medium leading-none tabular-nums">{value}</span>
        <span className="mt-0.5 block text-[10px] uppercase tracking-wide text-muted-foreground">{label}</span>
      </span>
    </div>
  );
}

function Chip({ active, onClick, children, count }: { active: boolean; onClick: () => void; children: ReactNode; count?: number }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "inline-flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs transition-colors",
        active ? "border-primary/50 bg-primary/10 text-primary" : "border-border/80 bg-card/60 text-muted-foreground hover:border-border hover:text-foreground",
      )}
    >
      {children}
      {count !== undefined ? (
        <span className={cn("rounded-full px-1.5 text-[10px] tabular-nums", active ? "bg-primary/15" : "bg-muted/70")}>{count}</span>
      ) : null}
    </button>
  );
}

function SectionTitle({ title, count, sub }: { title: string; count?: number; sub: ReactNode }) {
  return (
    <div>
      <h2 className="flex items-center gap-2 font-display text-xl font-medium tracking-tight">
        {title}
        {count !== undefined ? (
          <span className="rounded-full border border-border/80 bg-card/70 px-2 py-0.5 font-mono text-[11px] font-normal text-muted-foreground">{count}</span>
        ) : null}
      </h2>
      <p className="mt-0.5 text-xs text-muted-foreground">{sub}</p>
    </div>
  );
}

/** Live connections up front with health, test and edit; the rest of the catalogue as a compact library. */
export function ConnectorsPage() {
  const catalog = useConnectorCatalog();
  const [query, setQuery] = useState("");
  const [library, setLibrary] = useState<LibraryFilter>("all");
  const [category, setCategory] = useState("all");
  const [runFor, setRunFor] = useState<ConnectorInfo | null>(null);
  const [detail, setDetail] = useState<ConnectorCatalogEntry | null>(null);
  const [editing, setEditing] = useState<ConnectorCatalogEntry | null>(null);
  const data = catalog.data;

  // ?connect=jira opens that connection's editor, so other pages can send people straight to it.
  const [params, setParams] = useSearchParams();
  const connect = params.get("connect");
  useEffect(() => {
    if (!connect || !data) return;
    const entry = data.entries.find((e) => e.key === connect);
    if (entry) setEditing(entry);
    const next = new URLSearchParams(params);
    next.delete("connect");
    setParams(next, { replace: true });
  }, [connect, data, params, setParams]);

  const view = useMemo(() => {
    const entries = data?.entries ?? [];
    const q = query.trim().toLowerCase();
    const matches = (e: ConnectorCatalogEntry) => !q || [e.name, e.vendor, e.description, ...e.capabilities].some((t) => t.toLowerCase().includes(q));
    const configured = entries.filter((e) => e.availability === "configured");
    const others = entries.filter((e) => e.availability !== "configured" && matches(e));
    return {
      configured,
      live: configured.filter(matches),
      library: others.filter((e) => (library === "all" || e.availability === library) && (category === "all" || e.category === category)),
      inLibrary: others,
      healthy: configured.filter((e) => e.healthy !== false).length,
      documents: configured.reduce((sum, e) => sum + e.documents, 0),
      runs: configured.reduce((sum, e) => sum + e.runs_7d, 0),
      failed: configured.reduce((sum, e) => sum + e.failed_7d, 0),
    };
  }, [data, query, library, category]);

  const count = (key: LibraryFilter) => view.inLibrary.filter((e) => key === "all" || e.availability === key).length;

  return (
    <div className="flex-1 space-y-6 overflow-auto p-4 md:p-6">
      <section className="relative overflow-hidden rounded-2xl border border-primary/15 bg-gradient-to-br from-card via-card to-accent/60 px-5 py-4 shadow-[inset_0_1px_0_0_hsl(var(--primary)/0.14)]">
        <div className="hero-grid pointer-events-none absolute inset-0 opacity-30" aria-hidden="true" />
        <div className="pointer-events-none absolute -right-16 -top-24 h-64 w-64 rounded-full bg-primary/15 blur-3xl" aria-hidden="true" />
        <div className="relative flex flex-wrap items-center justify-between gap-x-6 gap-y-4">
          <div className="min-w-0 flex-1 basis-[22rem]">
            <div className="flex items-center gap-2 text-[10px] font-medium uppercase tracking-[0.16em] text-primary">
              <span className="icon-tile h-7 w-7">
                <Cable className="h-3.5 w-3.5" />
              </span>
              Ingestion
            </div>
            <div className="mt-2 flex flex-wrap items-center gap-3">
              <h1 className="font-display text-2xl font-medium tracking-tight md:text-3xl">
                Connectors<span className="text-primary">.</span>
              </h1>
              <div className="flex -space-x-2" aria-hidden="true">
                {view.configured.map((e) => (
                  <BrandMark key={e.key} icon={e.icon} size="sm" className="ring-2 ring-card" />
                ))}
              </div>
            </div>
            <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
              Live connections with their health, and the library of sources one configuration away. Test and edit a connection without leaving the page.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Stat
              icon={CheckCircle2}
              value={data ? `${view.healthy}/${view.configured.length}` : "…"}
              label="healthy"
              tone={view.healthy < view.configured.length ? "#EF4444" : "#10B981"}
            />
            <Stat icon={FileText} value={data ? formatInt(view.documents) : "…"} label="documents" tone="#0EA5E9" />
            <Stat icon={Activity} value={data ? formatInt(view.runs) : "…"} label="runs · 7 days" tone="#8B5CF6" />
            <Stat icon={Sparkles} value={data ? formatInt(data.total) : "…"} label="in the library" tone="#F59E0B" />
            <div className="flex flex-col gap-1.5">
              <Button size="sm" variant="outline" className="h-8 gap-1.5" onClick={() => void catalog.refetch()} disabled={catalog.isFetching}>
                <RefreshCw className={cn("h-3.5 w-3.5", catalog.isFetching && "animate-spin")} /> Re-check
              </Button>
              <Button size="sm" variant="outline" className="h-8 gap-1.5" asChild>
                <Link to="/pipelines">
                  <Workflow className="h-3.5 w-3.5" /> Pipelines
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {catalog.isError ? (
        <div className="rounded-xl border border-destructive/40 bg-destructive/10 p-4 text-sm text-destructive">
          The ingestion service did not answer. Check that it is running, then re-check.
        </div>
      ) : null}

      <section className="space-y-3">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <SectionTitle
            title="Live connections"
            count={view.configured.length}
            sub={
              data
                ? `${view.healthy} healthy${view.failed ? ` · ${view.failed} failed runs this week` : ""} · checked ${formatRelative(data.generated_at)}`
                : "Checking every connection…"
            }
          />
          <div className="relative w-full sm:w-72">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search connectors and capabilities…"
              className="h-9 pl-9"
              aria-label="Search connectors"
            />
          </div>
        </div>
        {!data ? (
          <div className="grid gap-4 lg:grid-cols-2 2xl:grid-cols-3">
            {[0, 1, 2].map((i) => (
              <Skeleton key={i} className="h-64 rounded-2xl" />
            ))}
          </div>
        ) : view.live.length ? (
          <div className="grid gap-4 lg:grid-cols-2 2xl:grid-cols-3">
            {view.live.map((entry) => (
              <ConnectionCard key={entry.key} entry={entry} onEdit={() => setEditing(entry)} onRun={() => setRunFor(toConnectorInfo(entry))} />
            ))}
          </div>
        ) : (
          <div className="rounded-2xl border border-dashed border-border/80 p-8 text-center text-sm text-muted-foreground">
            No live connection matches the search.
          </div>
        )}
      </section>

      <section className="space-y-3">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <SectionTitle title="Library" count={view.inLibrary.length} sub="Adapters ready to configure, and the roadmap with what each will collect." />
          <div className="flex gap-1.5">
            <Chip active={library === "all"} onClick={() => setLibrary("all")} count={count("all")}>
              All
            </Chip>
            <Chip active={library === "available"} onClick={() => setLibrary("available")} count={count("available")}>
              Ready to configure
            </Chip>
            <Chip active={library === "planned"} onClick={() => setLibrary("planned")} count={count("planned")}>
              Planned
            </Chip>
          </div>
        </div>
        <div className="-mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1">
          <Chip active={category === "all"} onClick={() => setCategory("all")}>
            <Plug className="h-3.5 w-3.5" /> Every category
          </Chip>
          {(data?.categories ?? []).map((c) => {
            const Icon = CATEGORY_ICONS[c.key] ?? Plug;
            const n = view.inLibrary.filter((e) => e.category === c.key).length;
            if (!n) return null;
            return (
              <Chip key={c.key} active={category === c.key} onClick={() => setCategory(c.key)} count={n}>
                <Icon className="h-3.5 w-3.5" /> {c.label}
              </Chip>
            );
          })}
        </div>
        {view.library.length ? (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4">
            {view.library.map((entry) => (
              <LibraryTile key={entry.key} entry={entry} onOpen={() => setDetail(entry)} />
            ))}
          </div>
        ) : data ? (
          <div className="rounded-2xl border border-dashed border-border/80 p-8 text-center text-sm text-muted-foreground">
            No connector in the library matches these filters.
          </div>
        ) : null}
      </section>

      <TriggerRunDialog connector={runFor} onClose={() => setRunFor(null)} />
      <ConnectorDetail
        entry={detail}
        onClose={() => setDetail(null)}
        onConfigure={(entry) => {
          setDetail(null);
          setEditing(entry);
        }}
      />
      <ConnectionEditor entry={editing} onClose={() => setEditing(null)} />
    </div>
  );
}
