import { ArrowRight, FlaskConical, Sparkles, Users } from "lucide-react";
import { useState } from "react";
import { Link } from "react-router-dom";

import { PageHero } from "@/components/layout/page-hero";
import { PersonaIcon3D } from "@/components/personas/persona-icon-3d";
import { Button } from "@/components/ui/button";
import {
  useArchitectureReport,
  useConnectors,
  useGlossaryCoverage,
  usePlatformReport,
  useQualityReport,
  useSemanticOverview,
  useServiceHealth,
} from "@/hooks/queries";
import { formatInt } from "@/lib/format";
import { PERSONA_GENIE } from "@/lib/persona-genie";
import { PERSONA_LIST, type Persona, type PersonaKey } from "@/lib/personas";

interface LiveStat {
  label: string;
  value: string;
}

/** The hub: one card per workspace, with its companion, skills and two live numbers; fits one screen. */
export function PersonasPage() {
  const semantic = useSemanticOverview();
  const connectors = useConnectors();
  const quality = useQualityReport(7);
  const architecture = useArchitectureReport();
  const platform = usePlatformReport(24);
  const ingestion = useServiceHealth("ingestion");
  const query = useServiceHealth("query");
  const coverage = useGlossaryCoverage();

  const s = semantic.data;
  const healthy = connectors.data?.filter((c) => c.healthy).length;
  const servicesUp = [ingestion, query].filter((h) => h.data?.status === "ok").length;
  const metricViews = s ? (s.by_asset_type.metric_view ?? 0) + (s.by_asset_type.semantic_view ?? 0) : undefined;
  const dash = (v: number | undefined) => (v === undefined ? "…" : formatInt(v));

  const stats: Record<PersonaKey, LiveStat[]> = {
    data_engineer: [
      { label: "catalog assets", value: dash(s?.assets) },
      { label: "connectors healthy", value: connectors.data ? `${healthy}/${connectors.data.length}` : "…" },
    ],
    business_analyst: [
      { label: "governed metrics", value: dash(s?.declared_metrics) },
      { label: "metric views", value: dash(metricViews) },
    ],
    qa_engineer: [
      { label: "gates passing", value: quality.data ? `${quality.data.gates_passed}/${quality.data.gates_total}` : "…" },
      { label: "awaiting review", value: dash(quality.data?.review_queue.length) },
    ],
    architect: [
      { label: "platforms", value: dash(architecture.data?.platforms.length) },
      { label: "subject areas", value: dash(architecture.data?.subject_areas) },
    ],
    sre: [
      { label: "services healthy", value: ingestion.data || query.data ? `${servicesUp}/2` : "…" },
      { label: "stalled runs", value: dash(platform.data?.runs_stale) },
    ],
    // Preview workspaces: sample figures until their sources are connected; the steward's are live.
    devops: [
      { label: "deploys this week", value: "18" },
      { label: "change failure", value: "5.6%" },
    ],
    devsecops: [
      { label: "critical vulns", value: "3" },
      { label: "secrets open", value: "2" },
    ],
    data_steward: [
      { label: "suggestions waiting", value: dash(coverage.data?.links_suggested) },
      { label: "tables placed", value: coverage.data ? `${coverage.data.assets_with_domain}/${coverage.data.assets_total}` : "…" },
    ],
    data_scientist: [
      { label: "models in production", value: "4" },
      { label: "drift alerts", value: "1" },
    ],
    compliance: [
      { label: "controls passing", value: "42/47" },
      { label: "filings due", value: "2" },
    ],
  };

  return (
    // Children keep their height and the page scrolls: a shrinking hero clips its own last lines.
    <div className="flex flex-1 flex-col gap-5 overflow-auto p-6 [&>*]:shrink-0">
      <PageHero
        slim
        eyebrow="Workspaces"
        icon={Users}
        title="Personas"
        lead="Pick a perspective. Each one focuses the catalog, the pipelines and Genie on one role."
        aside={<Lineup />}
      />

      <div className="persona-hub">
        <div className="persona-grid">
          {PERSONA_LIST.map((p) => (
            <PersonaCard key={p.key} persona={p} stats={stats[p.key]} />
          ))}
        </div>
      </div>

      <Link
        to="/genie"
        className="group flex min-w-0 items-center gap-3 rounded-xl border border-dashed border-primary/35 bg-primary/5 px-4 py-3 transition-all hover:-translate-y-0.5 hover:shadow-glow"
      >
        <span className="icon-tile h-10 w-10 rounded-xl">
          <Sparkles className="h-4 w-4" />
        </span>
        <span className="min-w-0 flex-1">
          <span className="block text-sm font-medium">Start with a question</span>
          <span className="block truncate text-xs text-muted-foreground">
            Not sure which perspective? Ask Genie; the answer and its sources point to the workspace that owns it.
          </span>
        </span>
        <Button size="sm" variant="outline" className="shrink-0 border-primary/40 text-primary group-hover:bg-primary/10" tabIndex={-1}>
          Open Genie <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
        </Button>
      </Link>
    </div>
  );
}

/** Every workspace's icon in the hero, live workspaces first; the one under the pointer lifts and names itself. */
function Lineup() {
  const live = PERSONA_LIST.filter((p) => !p.preview);
  const preview = PERSONA_LIST.filter((p) => p.preview);
  return (
    <nav aria-label="Workspaces" className="flex flex-wrap items-end gap-x-4 gap-y-2 pb-3">
      {[live, preview].map((group, i) => (
        <div key={i} className="flex items-end">
          {group.map((p) => (
            <LineupMember key={p.key} persona={p} />
          ))}
        </div>
      ))}
    </nav>
  );
}

function LineupMember({ persona }: { persona: Persona }) {
  const [hover, setHover] = useState(false);
  const genie = PERSONA_GENIE[persona.key];
  const [h, s, l] = genie.color;
  return (
    <Link
      to={persona.path}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      onFocus={() => setHover(true)}
      onBlur={() => setHover(false)}
      className="relative mx-1.5 rounded-xl outline-none hover:z-10 focus-visible:ring-2 focus-visible:ring-primary/50"
      aria-label={`${persona.label} workspace`}
      title={persona.label}
    >
      <PersonaIcon3D persona={persona.key} active={hover} size="2.9rem" />
      <span
        className="pointer-events-none absolute left-1/2 top-full -translate-x-1/2 whitespace-nowrap rounded-full px-1.5 text-[10px] font-medium transition-opacity duration-150"
        style={{ opacity: hover ? 1 : 0, color: `hsl(${h} ${s}% ${Math.max(l - 12, 28)}%)`, background: `hsl(${h} ${s}% ${l}% / 0.12)` }}
        aria-hidden="true"
      >
        {persona.label}
      </span>
    </Link>
  );
}

function PersonaCard({ persona, stats }: { persona: Persona; stats: LiveStat[] }) {
  const genie = PERSONA_GENIE[persona.key];
  const [h, s, l] = genie.color;
  const tint = (alpha: number) => `hsl(${h} ${s}% ${l}% / ${alpha})`;
  const accent = tint(1);
  const [hover, setHover] = useState(false);

  return (
    <Link
      to={persona.path}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      className="surface group relative flex min-w-0 flex-col overflow-hidden p-4 transition-all duration-200 hover:-translate-y-1"
      style={{ boxShadow: hover ? `0 0 0 1px ${tint(0.45)}, 0 24px 48px -28px ${tint(0.7)}` : undefined }}
    >
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-0.5"
        style={{ background: `linear-gradient(90deg, ${accent}, transparent 70%)` }}
        aria-hidden="true"
      />
      <div className="hero-grid pointer-events-none absolute inset-0 opacity-30" aria-hidden="true" />
      <div
        className="pointer-events-none absolute -right-12 -top-16 h-48 w-48 rounded-full blur-3xl transition-opacity duration-300"
        style={{ background: accent, opacity: hover ? 0.32 : 0.16 }}
        aria-hidden="true"
      />

      {/* The name gets its own line under the icon row, so it is never cut short beside the icon. */}
      <div className="relative flex items-start justify-between gap-2">
        <PersonaIcon3D persona={persona.key} active={hover} size="3.4rem" className="-mb-1" />
        <div className="flex min-w-0 items-center gap-2 pt-1">
          {persona.preview ? (
            <span
              className="inline-flex shrink-0 items-center gap-1 rounded-full bg-amber-500/12 px-2 py-0.5 text-[10px] font-medium text-amber-700 dark:text-amber-300"
              title="Shown with sample data until its sources are connected"
            >
              <FlaskConical className="h-3 w-3" /> Sample data
            </span>
          ) : (
            <span
              className="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-emerald-500/12 px-2 py-0.5 text-[10px] font-medium text-emerald-700 dark:text-emerald-300"
              title="Runs on the hub's own numbers"
            >
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-500" /> Live
            </span>
          )}
        </div>
      </div>
      <div className="relative mt-1 text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">{persona.domain}</div>
      <div className="relative font-display text-lg font-medium leading-snug">{persona.label}</div>

      <p className="relative mt-1.5 text-sm text-muted-foreground">{persona.tagline}</p>
      <div className="relative mt-3 flex flex-wrap gap-1.5">
        {persona.skills.map((skill) => (
          <span key={skill} className="rounded-md border border-border/80 bg-background/60 px-2 py-0.5 text-[11px] text-foreground/80">
            {skill}
          </span>
        ))}
      </div>

      <div className="relative mt-auto flex items-end justify-between gap-3 pt-3">
        {/* Two numbers side by side in every card, so the rows line up across the grid. */}
        <div className="grid min-w-0 flex-1 grid-cols-2 gap-3">
          {stats.map((st) => (
            <div key={st.label} className="min-w-0">
              <div className="font-display text-base font-medium leading-tight tabular-nums">{st.value}</div>
              <div className="text-[10px] uppercase leading-tight tracking-wide text-muted-foreground">{st.label}</div>
            </div>
          ))}
        </div>
        <span
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border transition-transform duration-200 group-hover:translate-x-0.5"
          style={{ borderColor: tint(0.45), color: accent, background: tint(0.1) }}
        >
          <ArrowRight className="h-4 w-4" />
        </span>
      </div>
    </Link>
  );
}
