import { ArrowLeft, CirclePause, Clock, Pencil, Play, Trash2, Workflow } from "lucide-react";
import type { ReactNode } from "react";
import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

import { PageHero } from "@/components/layout/page-hero";
import { ConfirmDialog } from "@/components/pipelines/confirm-dialog";
import { ConnectionTile, ScopeChips, StatePill } from "@/components/pipelines/pipeline-visuals";
import { RunHistory } from "@/components/pipelines/run-history";
import { RunStatusBadge } from "@/components/pipelines/run-status-badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { useConnectors, useDeletePipeline, usePipeline, useRunPipeline, useToggleSchedule } from "@/hooks/queries";
import { describeError } from "@/lib/api-client";
import { formatDateTime, formatDuration, formatInt, formatRelative } from "@/lib/format";
import { pathLabel, scopeSummary } from "@/lib/pipelines";
import { formatUntil } from "@/lib/schedule";

function Panel({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="surface space-y-2 p-4">
      <h3 className="text-sm font-medium">{title}</h3>
      {children}
    </section>
  );
}

function Row({ k, v }: { k: string; v: ReactNode }) {
  return (
    <div className="flex items-baseline justify-between gap-4 border-b border-border/50 py-1 text-xs last:border-0">
      <dt className="shrink-0 text-muted-foreground">{k}</dt>
      <dd className="min-w-0 truncate text-right font-medium">{v}</dd>
    </div>
  );
}

const onOff = (v: boolean | null | undefined): string => (v === null || v === undefined ? "server default" : v ? "on" : "off");

export function PipelineDetailPage() {
  const { pipelineId = null } = useParams<{ pipelineId: string }>();
  const navigate = useNavigate();
  const pipeline = usePipeline(pipelineId);
  const connections = useConnectors();
  const run = useRunPipeline();
  const toggle = useToggleSchedule();
  const remove = useDeletePipeline();
  const [confirm, setConfirm] = useState(false);
  const p = pipeline.data;
  const connection = connections.data?.find((c) => c.name === p?.connector);
  const levels = connection?.scope_levels ?? [];
  const last = p?.last_run;
  const active = last?.status === "running" || last?.status === "queued" || last?.status === "paused";
  const scheduled = p ? p.schedule.type !== "manual" : false;

  if (pipeline.isError) {
    return (
      <div className="flex-1 p-6">
        <div className="mx-auto max-w-2xl rounded-xl border border-destructive/40 p-6 text-sm">
          <p className="text-destructive">{describeError(pipeline.error)}</p>
          <Link to="/pipelines" className="mt-2 inline-block text-primary underline">
            Back to pipelines
          </Link>
        </div>
      </div>
    );
  }
  if (!p) {
    return (
      <div className="flex-1 space-y-5 p-6">
        <Skeleton className="h-32" />
        <Skeleton className="h-96" />
      </div>
    );
  }
  return (
    <>
      <div className="flex-1 space-y-4 overflow-auto p-4 md:space-y-5 md:p-6">
        <PageHero
          slim
          eyebrow={`Pipeline · ${p.connector_label}`}
          icon={Workflow}
          title={p.name}
          lead={p.description || `${scopeSummary(p.scope, levels)} from ${p.connector_label}.`}
          aside={<StatePill pipeline={p} />}
          actions={
            <>
              <Button variant="outline" size="sm" asChild>
                <Link to="/pipelines">
                  <ArrowLeft className="h-3.5 w-3.5" /> All pipelines
                </Link>
              </Button>
              <Button size="sm" disabled={run.isPending || active || !p.connection_available} onClick={() => run.mutate(p.id)}>
                <Play className="h-3.5 w-3.5" /> {active ? "Running…" : "Run now"}
              </Button>
              {scheduled ? (
                <Button variant="outline" size="sm" onClick={() => toggle.mutate({ id: p.id, enabled: !p.enabled })}>
                  {p.enabled ? <CirclePause className="h-3.5 w-3.5" /> : <Clock className="h-3.5 w-3.5" />} {p.enabled ? "Pause schedule" : "Resume schedule"}
                </Button>
              ) : null}
              <Button variant="outline" size="sm" asChild>
                <Link to={`/pipelines/${p.id}/edit`}>
                  <Pencil className="h-3.5 w-3.5" /> Edit
                </Link>
              </Button>
              <Button variant="outline" size="sm" className="text-destructive" onClick={() => setConfirm(true)}>
                <Trash2 className="h-3.5 w-3.5" /> Delete
              </Button>
            </>
          }
        />
        {run.isError || toggle.isError ? <div className="rounded-xl border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive">{describeError(run.error ?? toggle.error)}</div> : null}
        {!p.connection_available ? <div className="rounded-xl border border-warning/40 bg-warning/10 p-3 text-sm text-warning">The connection {p.connector} is not configured on the server any more, so this pipeline cannot run.</div> : null}
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-[22rem_minmax(0,1fr)]">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-1 lg:content-start">
            <Panel title="Source">
              <div className="flex items-center gap-3">
                <ConnectionTile system={p.source_system} />
                <div className="min-w-0">
                  <div className="truncate font-medium">{p.connector_label}</div>
                  <div className="truncate text-xs text-muted-foreground">{scopeSummary(p.scope, levels)}</div>
                </div>
              </div>
              {p.scope.length ? (
                <ul className="scrollbar-hidden max-h-48 space-y-1 overflow-auto">
                  {p.scope.map((s) => (
                    <li key={s.path.join("/")} className="truncate rounded-lg bg-muted/40 px-2 py-1 font-mono text-[11px]" title={pathLabel(s.path)}>
                      {pathLabel(s.path)}
                    </li>
                  ))}
                </ul>
              ) : (
                <ScopeChips scope={[]} />
              )}
            </Panel>
            <Panel title="Schedule">
              <dl>
                <Row k="Runs" v={p.schedule_label} />
                {scheduled ? <Row k="Schedule" v={p.enabled ? "on" : "paused"} /> : null}
                {p.next_run_at && p.enabled ? <Row k="Next run" v={`${formatDateTime(p.next_run_at)} (${formatUntil(p.next_run_at)})`} /> : null}
              </dl>
            </Panel>
            <Panel title="Options">
              <dl>
                <Row k="Full refresh" v={p.options.full_refresh ? "yes" : "no"} />
                <Row k="Document limit" v={p.options.limit ?? "all"} />
                <Row k="Chunk tokens / overlap" v={`${p.options.chunk_target_tokens ?? "default"} / ${p.options.chunk_overlap_tokens ?? "default"}`} />
                {connection?.option_keys.includes("include_lineage") ? <Row k="Lineage" v={onOff(p.source_options.include_lineage)} /> : null}
                {connection?.option_keys.includes("include_tags") ? <Row k="Tags" v={onOff(p.source_options.include_tags)} /> : null}
                {connection?.option_keys.includes("include_alert_rules") ? <Row k="Alert rules" v={onOff(p.source_options.include_alert_rules)} /> : null}
                {p.source_options.include_extensions?.length ? <Row k="File extensions" v={p.source_options.include_extensions.join(", ")} /> : null}
                {p.source_options.exclude_globs?.length ? <Row k="Skipped paths" v={p.source_options.exclude_globs.join(", ")} /> : null}
              </dl>
            </Panel>
            <Panel title="About">
              <dl>
                <Row k="Owner" v={p.owner || "–"} />
                <Row k="Tags" v={p.tags.join(", ") || "–"} />
                <Row k="Created" v={`${formatRelative(p.created_at)}${p.created_by ? ` by ${p.created_by}` : ""}`} />
                <Row k="Runs" v={`${formatInt(p.runs_total)}${p.runs_failed ? ` (${p.runs_failed} failed)` : ""}`} />
              </dl>
            </Panel>
          </div>
          <div className="min-w-0 space-y-5">
            {last ? (
              <section className="surface space-y-3 p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h3 className="text-sm font-medium">Last run</h3>
                  <span className="flex items-center gap-2 text-xs text-muted-foreground">
                    <RunStatusBadge status={last.status} /> {formatRelative(last.started_at ?? last.created_at)}
                    {last.duration_seconds != null ? ` · ${formatDuration(last.duration_seconds)}` : ""} · {last.triggered_by ?? "—"}
                  </span>
                </div>
                {active ? (
                  <div className="flex items-center gap-3">
                    <Progress value={Math.round((last.progress ?? 0) * 100)} className="h-2" />
                    <span className="tabular w-24 text-right text-xs text-muted-foreground">
                      {formatInt(last.documents_seen)}/{last.estimated_total != null ? formatInt(last.estimated_total) : "?"}
                    </span>
                  </div>
                ) : null}
                <dl className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                  {(
                    [
                      ["Documents seen", last.documents_seen],
                      ["Upserted", last.documents_upserted],
                      ["Unchanged", last.documents_skipped],
                      ["Failed", last.documents_failed],
                    ] as const
                  ).map(([k, v]) => (
                    <div key={k} className="rounded-xl border border-border/60 bg-card/60 p-3">
                      <dt className="text-[10px] uppercase tracking-wide text-muted-foreground">{k}</dt>
                      <dd className="tabular mt-1 text-xl font-semibold">{formatInt(v)}</dd>
                    </div>
                  ))}
                </dl>
                {last.error ? <p className="whitespace-pre-wrap rounded-md bg-destructive/10 p-2 text-xs text-destructive">{last.error}</p> : null}
              </section>
            ) : (
              <section className="surface p-6 text-center text-sm text-muted-foreground">This pipeline has not run yet. Use Run now to start the first run.</section>
            )}
            <RunHistory pipelineId={p.id} />
          </div>
        </div>
      </div>
      <ConfirmDialog
        open={confirm}
        title={`Delete ${p.name}?`}
        description="The pipeline and its schedule are removed. Its past runs and everything it ingested stay."
        confirmLabel="Delete pipeline"
        pending={remove.isPending}
        error={remove.isError ? describeError(remove.error) : null}
        onClose={() => {
          setConfirm(false);
          remove.reset();
        }}
        onConfirm={() => remove.mutate(p.id, { onSuccess: () => navigate("/pipelines") })}
      />
    </>
  );
}
