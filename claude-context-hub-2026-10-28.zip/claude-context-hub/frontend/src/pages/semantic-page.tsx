import { ChevronDown, Download, GitFork, Layers, LibraryBig, Orbit, ShieldCheck, SlidersHorizontal, Table2, TableProperties, type LucideIcon } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";

import { semanticApi } from "@/api/endpoints";
import type { CatalogObject, SemanticExportFormat, SourceSystem } from "@/api/types";
import { HeroStats, PageHero } from "@/components/layout/page-hero";
import { ViewSwitcher } from "@/components/layout/view-switcher";
import { AssetDetail } from "@/components/semantic/asset-detail";
import { AssetTable } from "@/components/semantic/asset-table";
import { BusinessModelView } from "@/components/semantic/business-model";
import { CatalogExplorer } from "@/components/semantic/explorer/explorer";
import { ScopeRail, type ScopeSelection } from "@/components/semantic/scope-rail";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  useArchitectureReport,
  useBusinessModel,
  useEnrichRun,
  useEnrichScope,
  useSemanticAsset,
  useSemanticAssets,
  useSemanticCatalog,
  useSemanticGraph,
  useSemanticOverview,
} from "@/hooks/queries";
import { cn } from "@/lib/utils";

const PAGE = 50;
const FORMAT_LABEL: Record<SemanticExportFormat, string> = {
  cortex: "Snowflake Cortex Analyst model (YAML)",
  databricks_metric_view: "Databricks metric views (YAML)",
  hub: "Hub JSON",
};
const EMPTY_SCOPE: ScopeSelection = { platform: null, database: null, schema: null, kind: null };
type View = "catalog" | "model" | "inventory";
const VIEWS: { key: View; label: string; icon: LucideIcon; hint: string; tone: string }[] = [
  { key: "catalog", label: "Semantic catalog", icon: LibraryBig, hint: "What your tables mean, sorted by business area", tone: "#0EA5E9" },
  { key: "model", label: "Business model", icon: Orbit, hint: "Fact stars, metric views and dimensions per subject area", tone: "#8B5CF6" },
  { key: "inventory", label: "Data catalog", icon: TableProperties, hint: "Every table and view with columns, keys, joins and lineage", tone: "#10B981" },
];
const VIEW_KEY = "ech-semantic-view";

function isView(value: string | null): value is View {
  return value === "catalog" || value === "model" || value === "inventory";
}

function readView(param: string | null, legacyDataRoot: boolean): View {
  // The catalog tree once had a Data Catalog root (root=data&db=&schema=); those links open the Data catalog view.
  if (legacyDataRoot) return "inventory";
  if (isView(param)) return param;
  try {
    const stored = localStorage.getItem(VIEW_KEY);
    if (isView(stored)) return stored;
  } catch {
    /* storage unavailable */
  }
  return "catalog";
}

export function SemanticPage() {
  const { assetId = null } = useParams<{ assetId: string }>();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const legacyDataRoot = searchParams.get("root") === "data";
  const [selection, setSelection] = useState<ScopeSelection>(() => ({
    ...EMPTY_SCOPE,
    platform: searchParams.get("platform"),
    database: searchParams.get("database") ?? (legacyDataRoot ? searchParams.get("db") : null),
    schema: searchParams.get("schema"),
    kind: searchParams.get("kind"),
  }));
  const [search, setSearch] = useState("");
  const [debounced, setDebounced] = useState("");
  const [offset, setOffset] = useState(0);
  const [format, setFormat] = useState<SemanticExportFormat>("cortex");
  const [view, setViewState] = useState<View>(() => readView(searchParams.get("view"), legacyDataRoot));
  const setView = (next: View) => {
    setViewState(next);
    try {
      localStorage.setItem(VIEW_KEY, next);
    } catch {
      /* storage unavailable */
    }
    // The URL names the view, so a link or a reload opens the same one.
    if (next !== "inventory" && assetId) navigate(`/semantic?view=${next}`);
    else setSearchParams({ view: next }, { replace: true });
  };
  const [runId, setRunId] = useState<string | null>(null);
  // Phones and tablets: the scope rail folds behind a toggle above the content.
  const [scopeOpen, setScopeOpen] = useState(false);
  const scopeLabel = [selection.platform, selection.database, selection.schema, selection.kind].filter(Boolean).join(" › ") || "All sources";
  const enrichScope = useEnrichScope();
  const enrichRun = useEnrichRun(runId);


  useEffect(() => {
    const timer = window.setTimeout(() => setDebounced(search.trim()), 250);
    return () => window.clearTimeout(timer);
  }, [search]);
  useEffect(() => setOffset(0), [debounced, selection]);

  const overview = useSemanticOverview();
  // Hub-wide, like the other hero stats; the business model's count follows the selected scope.
  const architecture = useArchitectureReport();
  const params = useMemo(
    () => ({
      search: debounced || null,
      source_system: (selection.platform as SourceSystem | null) ?? null,
      database: selection.database,
      schema: selection.schema,
      kind: selection.kind,
      limit: PAGE,
      offset,
    }),
    [debounced, selection, offset],
  );
  const assets = useSemanticAssets(params);
  const modelParams = useMemo(
    () => ({ source_system: (selection.platform as SourceSystem | null) ?? null, database: selection.database, schema: selection.schema }),
    [selection.platform, selection.database, selection.schema],
  );
  const showCatalog = view === "catalog" && !assetId;
  const showModel = view === "model" && !assetId;
  const activeView: View = showCatalog ? "catalog" : showModel ? "model" : "inventory";
  const businessModel = useBusinessModel(modelParams);
  const catalog = useSemanticCatalog();
  const startEnrichment = () =>
    enrichScope.mutate(
      { ...modelParams, only_undocumented: true, limit: 100 },
      { onSuccess: (run) => setRunId(run.id) },
    );
  const asset = useSemanticAsset(assetId);
  const graph = useSemanticGraph(assetId, 1);
  const openAsset = (id: string) => {
    setViewState("inventory");
    navigate(`/semantic/${id}`);
  };
  const openObject = (o: CatalogObject) => {
    if (o.asset_id) {
      // Columns, metrics, relationships and hierarchies open on the dataset that carries them.
      openAsset(o.asset_id);
    } else {
      navigate(o.domain_key ? `/glossary/kpis?domain=${encodeURIComponent(o.domain_key)}` : "/glossary/kpis");
    }
  };

  // A deep link decides the scope the first time its asset loads.
  const loadedPlatform = asset.data?.platform;
  const loadedDatabase = asset.data?.database_name;
  useEffect(() => {
    if (!loadedPlatform || !loadedDatabase) return;
    setSelection((s) => (s.database ? s : { ...s, platform: loadedPlatform, database: loadedDatabase }));
  }, [loadedPlatform, loadedDatabase]);

  const exportHref = semanticApi.exportUrl({
    format,
    source_system: assetId ? null : ((selection.platform as SourceSystem | null) ?? null),
    database: assetId ? null : selection.database,
    schema: assetId ? null : selection.schema,
    asset_id: assetId ? [assetId] : null,
  });

  return (
    // Below lg the whole page scrolls; from lg each column scrolls on its own.
    <div className="flex min-h-0 flex-1 flex-col overflow-y-auto lg:overflow-hidden">
      <div className="px-4 pt-4 md:px-6">
      <PageHero
        slim
        className="py-4"
        eyebrow="Data & semantics"
        icon={Layers}
        title="Semantic Hub"
        lead="The hub's semantic layer: Snowflake and Databricks metadata as a semantic catalog by business domain, a business model of fact stars, and a data catalog of every table, view and column."
        aside={
          <HeroStats
            items={[
              { label: "Datasets", value: overview.data?.assets, icon: Layers },
              { label: "Columns", value: overview.data?.fields, icon: Table2 },
              { label: "Governed metrics", value: architecture.data?.governed_metrics ?? overview.data?.declared_metrics, icon: ShieldCheck },
              { label: "Relationships", value: overview.data?.relationships, icon: GitFork },
            ]}
          />
        }
        actions={
          <div className="flex w-full flex-wrap items-center gap-2 sm:w-auto">
            <Select value={format} onValueChange={(v) => setFormat(v as SemanticExportFormat)}>
              <SelectTrigger className="h-8 w-full min-w-0 flex-1 text-xs sm:w-64 sm:flex-none">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {(Object.keys(FORMAT_LABEL) as SemanticExportFormat[]).map((f) => (
                  <SelectItem key={f} value={f} className="text-xs">
                    {FORMAT_LABEL[f]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {overview.data?.assets ? (
              <Button variant="outline" size="sm" asChild>
                <a href={exportHref} download>
                  <Download className="h-3.5 w-3.5" /> Export {assetId ? "asset" : "scope"}
                </a>
              </Button>
            ) : (
              <Button variant="outline" size="sm" disabled>
                <Download className="h-3.5 w-3.5" /> Export
              </Button>
            )}
          </div>
        }
      />
      <ViewSwitcher
        className="mt-3"
        label="Semantic Hub views"
        value={activeView}
        onChange={setView}
        views={VIEWS.map((v) => ({
          key: v.key,
          label: v.label,
          icon: v.icon,
          tone: v.tone,
          description: v.hint,
          count:
            v.key === "catalog"
              ? catalog.data
                ? `${catalog.data.domains.length} domains`
                : null
              : v.key === "model"
                ? businessModel.data
                  ? `${businessModel.data.facts} facts`
                  : null
                : overview.data
                  ? `${overview.data.assets} datasets`
                  : null,
        }))}
      />
      </div>
      {showCatalog ? (
        <CatalogExplorer catalog={catalog.data} catalogLoading={catalog.isLoading} onOpenObject={openObject} />
      ) : (
      <div className="flex flex-1 lg:min-h-0">
        <ScopeRail className="hidden lg:flex" overview={overview.data} loading={overview.isLoading} selection={selection} onChange={setSelection} />
        <div className="flex min-w-0 flex-1 flex-col lg:min-h-0">
        <div className="border-b border-border/70 lg:hidden">
          <button type="button" onClick={() => setScopeOpen((open) => !open)} aria-expanded={scopeOpen} className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm">
            <SlidersHorizontal className="h-4 w-4 text-primary" />
            <span className="text-muted-foreground">Scope</span>
            <span className="min-w-0 flex-1 truncate font-medium">{scopeLabel}</span>
            <ChevronDown className={cn("h-4 w-4 text-muted-foreground transition-transform", scopeOpen && "rotate-180")} />
          </button>
          {scopeOpen ? (
            <ScopeRail
              className="max-h-[55vh] w-full border-r-0 border-t"
              overview={overview.data}
              loading={overview.isLoading}
              selection={selection}
              onChange={(next) => {
                setSelection(next);
                setScopeOpen(false);
              }}
            />
          ) : null}
        </div>
        {showModel ? (
          <BusinessModelView
            model={businessModel.data}
            loading={businessModel.isLoading}
            onOpen={(id) => {
              setViewState("inventory");
              navigate(`/semantic/${id}`);
            }}
            onEnrich={startEnrichment}
            enrichPending={enrichScope.isPending}
            enrichRun={enrichRun.data ?? null}
          />
        ) : (
        <div className="grid flex-1 grid-cols-1 gap-4 p-3 md:p-4 lg:min-h-0 lg:grid-cols-5 lg:overflow-hidden">
          <div className={cn("flex min-w-0 flex-col lg:col-span-2 lg:min-h-0", assetId && "hidden lg:flex")}>
            <AssetTable
              page={assets.data}
              loading={assets.isLoading}
              search={search}
              onSearch={setSearch}
              selectedId={assetId}
              onSelect={(a) => navigate(`/semantic/${a.id}`)}
              offset={offset}
              onOffset={setOffset}
            />
          </div>
          <div className={cn("flex min-w-0 flex-col lg:col-span-3 lg:min-h-0", !assetId && "hidden lg:flex")}>
            <AssetDetail asset={asset.data} loading={asset.isLoading} graph={graph.data} graphLoading={graph.isLoading} enrichmentAvailable={businessModel.data?.enrichment_available ?? false} onBack={() => {
                setView("inventory");
                navigate("/semantic");
              }} />
          </div>
        </div>
        )}
        </div>
      </div>
      )}
    </div>
  );
}
