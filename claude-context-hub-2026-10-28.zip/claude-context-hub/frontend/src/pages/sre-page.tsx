import { Activity, AlertTriangle, Database, Gauge, HardDrive, Network, RefreshCw, Server, Timer } from "lucide-react";
import { useState } from "react";
import { Link, useParams } from "react-router-dom";

import type { AuditRecord, HealthStatus, KpiValue } from "@/api/types";
import { ActivityChart } from "@/components/dashboard/activity-chart";
import { LatencyChart } from "@/components/dashboard/latency-chart";
import { MetricCard } from "@/components/dashboard/metric-card";
import { KpiSummaryLine, KpiTile, TargetsTable, formatKpi } from "@/components/personas/kpi-tiles";
import { ObservabilityPanel } from "@/components/personas/observability-panel";
import { PersonaChat } from "@/components/personas/persona-chat";
import { EmptyRow, PersonaShell, SectionCard } from "@/components/personas/persona-shell";
import { PersonaProfile } from "@/components/personas/persona-profile";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useActivity, useLatency, usePlatformReport, useReconcileGraph, useServiceHealth } from "@/hooks/queries";
import { describeError } from "@/lib/api-client";
import { formatBytes, formatCompact, formatDateTime, formatInt, formatMs, formatRelative } from "@/lib/format";
import { PERSONAS, personaTab } from "@/lib/personas";
import { cn } from "@/lib/utils";

const persona = PERSONAS.sre;
const WINDOWS = [
  { value: 6, label: "Last 6 hours" },
  { value: 24, label: "Last 24 hours" },
  { value: 72, label: "Last 3 days" },
  { value: 168, label: "Last 7 days" },
] as const;
type Hours = (typeof WINDOWS)[number]["value"];
type Tone = "default" | "success" | "warning" | "destructive";

export function SrePage() {
  const { tab } = useParams<{ tab: string }>();
  const active = personaTab(persona, tab).key;
  return (
    <PersonaShell persona={persona} active={active} fill={active === "ask"}>
      {active === "overview" ? <Overview /> : null}
      {active === "services" ? <Services /> : null}
      {active === "slos" ? <Slos /> : null}
      {active === "capacity" ? <Capacity /> : null}
      {active === "observability" ? <ObservabilityPanel /> : null}
      {active === "ask" ? <PersonaChat persona="sre" /> : null}
    </PersonaShell>
  );
}

function HoursSelect({ value, onChange }: { value: Hours; onChange: (next: Hours) => void }) {
  return (
    <Select value={String(value)} onValueChange={(v) => onChange(Number(v) as Hours)}>
      <SelectTrigger className="h-8 w-40 text-xs">
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {WINDOWS.map((w) => (
          <SelectItem key={w.value} value={String(w.value)}>
            {w.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

function kpiTone(k: KpiValue | undefined): Tone {
  if (!k) return "default";
  return k.status === "ok" ? "success" : k.status === "warn" ? "warning" : k.status === "bad" ? "destructive" : "default";
}

function countValue(k: KpiValue | undefined): string {
  return k && k.value !== null ? formatInt(k.value) : "—";
}

function serviceState(q: { data?: HealthStatus; isError: boolean; isLoading: boolean }): { label: string; tone: Tone } {
  if (q.isLoading) return { label: "checking…", tone: "default" };
  if (q.isError || !q.data) return { label: "unreachable", tone: "destructive" };
  return q.data.status === "ok" ? { label: "healthy", tone: "success" } : { label: q.data.status, tone: "warning" };
}

function toneVariant(tone: Tone): "success" | "warning" | "destructive" | "muted" {
  return tone === "success" ? "success" : tone === "warning" ? "warning" : tone === "destructive" ? "destructive" : "muted";
}

// ----------------------------------------------------------------------------- overview
function Overview() {
  const ingestion = useServiceHealth("ingestion");
  const query = useServiceHealth("query");
  const report = usePlatformReport(24);
  const r = report.data;
  const kpis = r ? r.groups.flatMap((g) => g.kpis) : [];
  const byKey = new Map(kpis.map((k) => [k.key, k]));
  const offTarget = kpis.filter((k) => k.status === "bad" || k.status === "warn");
  const p95 = byKey.get("retrieval_p95_ms");
  const pending = byKey.get("graph_pending");
  const failed = byKey.get("graph_failed");
  const budget = r?.error_budget;
  const ing = serviceState(ingestion);
  const qry = serviceState(query);

  const graphBacklog = (pending?.value ?? 0) + (failed?.value ?? 0);
  return (
    <div className="space-y-6">
      <PersonaProfile persona={persona} />

      {/* Services always; the rest only once there is something to show. */}
      <section className="stat-grid stat-grid-wide">
        <MetricCard
          title="Ingestion service"
          value={ing.label}
          hint={ingestion.data ? `v${ingestion.data.version} · checked ${formatRelative(ingestion.data.timestamp)}` : "GET /health/ready on :8001"}
          icon={Server}
          tone={ing.tone}
          loading={ingestion.isLoading}
        />
        <MetricCard
          title="Query service"
          value={qry.label}
          hint={query.data ? `v${query.data.version} · checked ${formatRelative(query.data.timestamp)}` : "GET /health/ready on :8002"}
          icon={Server}
          tone={qry.tone}
          loading={query.isLoading}
        />
        {p95 && p95.value !== null ? (
          <MetricCard title="Retrieval p95" value={formatKpi(p95)} hint={p95.detail} icon={Timer} tone={kpiTone(p95)} loading={report.isLoading} />
        ) : null}
        {budget && budget.consumed_pct !== null ? (
          <MetricCard
            title="Error budget used"
            value={budget ? (budget.consumed_pct === null ? "—" : `${budget.consumed_pct.toFixed(0)}%`) : "—"}
            hint={budget ? `${budget.errors} errors of ${budget.allowed_errors} allowed · ${formatInt(budget.requests)} requests in 24 h` : undefined}
            icon={Gauge}
            tone={budget && budget.consumed_pct !== null ? (budget.consumed_pct > 100 ? "destructive" : budget.consumed_pct > 50 ? "warning" : "success") : "default"}
            loading={report.isLoading}
          />
        ) : null}
        {r && r.runs_active + r.runs_stale > 0 ? (
          <MetricCard
            title="Runs active / stalled"
            value={r ? `${r.runs_active} / ${r.runs_stale}` : "—"}
            hint="stalled = no progress for an hour"
            icon={RefreshCw}
            tone={r ? (r.runs_stale > 0 ? "destructive" : r.runs_active > 0 ? "warning" : "success") : "default"}
            loading={report.isLoading}
          />
        ) : null}
        {graphBacklog > 0 ? (
          <MetricCard
            title="Graph pending / failed"
            value={r ? `${countValue(pending)} / ${countValue(failed)}` : "—"}
            hint="documents not yet (or never) written to Neo4j"
            icon={Network}
            tone={kpiTone(failed) === "success" ? kpiTone(pending) : kpiTone(failed)}
            loading={report.isLoading}
          />
        ) : null}
      </section>

      <section className="grid gap-6 lg:grid-cols-5">
        <SectionCard
          className="lg:col-span-3"
          title={`SLOs off target · ${offTarget.length}`}
          description="Serving, pipelines and freshness, measured over the last 24 hours."
          actions={
            <Button variant="outline" size="sm" asChild>
              <Link to={`${persona.path}/slos`}>All SLOs</Link>
            </Button>
          }
        >
          {!r ? (
            <Skeleton className="m-4 h-32" />
          ) : offTarget.length ? (
            <div className="grid gap-3 p-4 sm:grid-cols-2">
              {offTarget.slice(0, 6).map((k) => (
                <KpiTile key={k.key} kpi={k} />
              ))}
            </div>
          ) : (
            <p className="p-6 text-center text-sm text-muted-foreground">Every measured SLO is on target.</p>
          )}
        </SectionCard>
        <SectionCard className="lg:col-span-2" title="Dependency checks" description="What each service's readiness probe reports right now.">
          <ChecksTable ingestion={ingestion.data} query={query.data} ingestionDown={ingestion.isError} queryDown={query.isError} />
        </SectionCard>
      </section>

      <SectionCard title="Recent request errors" description="Audited API calls that returned an error, newest first.">
        <ErrorsTable errors={r?.recent_errors} />
      </SectionCard>
    </div>
  );
}

function ChecksTable({ ingestion, query, ingestionDown, queryDown }: { ingestion: HealthStatus | undefined; query: HealthStatus | undefined; ingestionDown: boolean; queryDown: boolean }) {
  const rows: Array<{ service: string; check: string; ok: boolean }> = [];
  const services: Array<[string, HealthStatus | undefined, boolean]> = [
    ["Ingestion", ingestion, ingestionDown],
    ["Query", query, queryDown],
  ];
  for (const [name, h, down] of services) {
    if (down) rows.push({ service: name, check: "reachable", ok: false });
    else if (h) {
      rows.push({ service: name, check: "reachable", ok: true });
      for (const [check, ok] of Object.entries(h.checks)) rows.push({ service: name, check, ok });
    }
  }
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Service</TableHead>
          <TableHead>Check</TableHead>
          <TableHead className="text-right">State</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {rows.map((row) => (
          <TableRow key={`${row.service}-${row.check}`}>
            <TableCell className="text-xs">{row.service}</TableCell>
            <TableCell className="font-mono text-xs">{row.check}</TableCell>
            <TableCell className="text-right">
              <Badge variant={row.ok ? "success" : "destructive"} className="h-5 text-[10px]">
                {row.ok ? "ok" : "failing"}
              </Badge>
            </TableCell>
          </TableRow>
        ))}
        {rows.length === 0 ? <EmptyRow colSpan={3}>Waiting for the readiness probes…</EmptyRow> : null}
      </TableBody>
    </Table>
  );
}

function ErrorsTable({ errors }: { errors: AuditRecord[] | undefined }) {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Action</TableHead>
          <TableHead>When</TableHead>
          <TableHead className="text-right">Latency</TableHead>
          <TableHead>Detail</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {errors?.map((e) => (
          <TableRow key={e.id}>
            <TableCell className="font-mono text-xs">{e.action}</TableCell>
            <TableCell className="text-xs text-muted-foreground" title={formatDateTime(e.created_at)}>
              {formatRelative(e.created_at)}
            </TableCell>
            <TableCell className="text-right font-mono text-xs">{formatMs(e.latency_ms)}</TableCell>
            <TableCell className="max-w-[28rem] truncate font-mono text-[11px] text-muted-foreground" title={JSON.stringify(e.details)}>
              {typeof e.details.error === "string" ? e.details.error : (e.resource_id ?? "—")}
            </TableCell>
          </TableRow>
        ))}
        {errors && errors.length === 0 ? <EmptyRow colSpan={4}>No request errors recorded.</EmptyRow> : null}
      </TableBody>
    </Table>
  );
}

// ----------------------------------------------------------------------------- services
const LATENCY_WINDOWS = [
  { value: "15", label: "Last 15 min", bucket: 30 },
  { value: "60", label: "Last hour", bucket: 60 },
  { value: "360", label: "Last 6 hours", bucket: 300 },
  { value: "1440", label: "Last 24 hours", bucket: 900 },
] as const;
type LatencyWindow = (typeof LATENCY_WINDOWS)[number]["value"];

function ServiceCard({ name, port, health }: { name: string; port: number; health: ReturnType<typeof useServiceHealth> }) {
  const state = serviceState(health);
  const h = health.data;
  return (
    <div className="surface rounded-xl border p-4">
      <div className="flex items-start justify-between gap-2">
        <div>
          <div className="text-sm font-medium">{name}</div>
          <div className="font-mono text-[11px] text-muted-foreground">
            :{port} · GET /health/ready{h ? ` · v${h.version}` : ""}
          </div>
        </div>
        <Badge variant={toneVariant(state.tone)} className="h-5 text-[10px]">
          {state.label}
        </Badge>
      </div>
      <ul className="mt-3 space-y-1 text-xs">
        {h
          ? Object.entries(h.checks).map(([check, ok]) => (
              <li key={check} className="flex items-center gap-2">
                <span className={cn("h-1.5 w-1.5 rounded-full", ok ? "bg-success" : "bg-destructive")} />
                <span className="font-mono">{check}</span>
                <span className="ml-auto text-muted-foreground">{ok ? "ok" : "failing"}</span>
              </li>
            ))
          : null}
        {health.isError ? <li className="text-destructive">{describeError(health.error)}</li> : null}
        {h ? <li className="pt-1 text-[11px] text-muted-foreground">probed {formatRelative(h.timestamp)}</li> : null}
      </ul>
    </div>
  );
}

function Services() {
  const ingestion = useServiceHealth("ingestion");
  const query = useServiceHealth("query");
  const [window, setWindow] = useState<LatencyWindow>("60");
  const [scope, setScope] = useState<"all" | "retrieve">("all");
  const win = LATENCY_WINDOWS.find((w) => w.value === window) ?? LATENCY_WINDOWS[1];
  const latency = useLatency({ window_minutes: Number(win.value), bucket_seconds: win.bucket, path_prefix: scope === "retrieve" ? "/api/v1/context/retrieve" : null });
  const report = usePlatformReport(24);
  const r = report.data;

  return (
    <div className="space-y-6">
      <section className="grid gap-4 md:grid-cols-2">
        <ServiceCard name="Ingestion service" port={8001} health={ingestion} />
        <ServiceCard name="Query service" port={8002} health={query} />
      </section>

      <SectionCard
        title="Query service latency"
        description="p50 / p95 / p99 and error rate per bucket from the in-memory recorder of the running process."
        actions={
          <div className="flex gap-2">
            <Select value={scope} onValueChange={(v) => setScope(v as "all" | "retrieve")}>
              <SelectTrigger className="h-8 w-36 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All requests</SelectItem>
                <SelectItem value="retrieve">Context retrieval</SelectItem>
              </SelectContent>
            </Select>
            <Select value={window} onValueChange={(v) => setWindow(v as LatencyWindow)}>
              <SelectTrigger className="h-8 w-36 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {LATENCY_WINDOWS.map((w) => (
                  <SelectItem key={w.value} value={w.value}>
                    {w.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        }
      >
        <div className="p-4">
          <LatencyChart series={latency.data} loading={latency.isLoading} height={240} />
        </div>
      </SectionCard>

      <SectionCard title="Audited calls by action · last 24 hours" description="Persisted in audit_logs, so it survives restarts. Retrieval and Genie are the user-facing paths.">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Action</TableHead>
              <TableHead className="text-right">Requests</TableHead>
              <TableHead className="text-right">Errors</TableHead>
              <TableHead className="text-right">Error rate</TableHead>
              <TableHead className="text-right">p50</TableHead>
              <TableHead className="text-right">p95</TableHead>
              <TableHead className="text-right">p99</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {r?.requests.map((row) => (
              <TableRow key={row.action}>
                <TableCell className="font-mono text-xs">{row.action}</TableCell>
                <TableCell className="text-right font-mono text-xs">{formatInt(row.requests)}</TableCell>
                <TableCell className={cn("text-right font-mono text-xs", row.errors > 0 && "text-destructive")}>{row.errors}</TableCell>
                <TableCell className="text-right font-mono text-xs">{row.error_rate === null ? "—" : `${row.error_rate.toFixed(1)}%`}</TableCell>
                <TableCell className="text-right font-mono text-xs">{formatMs(row.p50_ms)}</TableCell>
                <TableCell className="text-right font-mono text-xs">{formatMs(row.p95_ms)}</TableCell>
                <TableCell className="text-right font-mono text-xs">{formatMs(row.p99_ms)}</TableCell>
              </TableRow>
            ))}
            {r && r.requests.length === 0 ? <EmptyRow colSpan={7}>No audited calls in the window.</EmptyRow> : null}
          </TableBody>
        </Table>
      </SectionCard>
    </div>
  );
}

// ----------------------------------------------------------------------------- SLOs
function Slos() {
  const [hours, setHours] = useState<Hours>(24);
  const report = usePlatformReport(hours);
  const r = report.data;
  const kpis = r ? r.groups.flatMap((g) => g.kpis) : [];
  const budget = r?.error_budget;
  const consumed = budget?.consumed_pct ?? null;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center gap-3">
        <HoursSelect value={hours} onChange={setHours} />
        {r ? <KpiSummaryLine kpis={kpis} suffix={`computed ${formatRelative(r.generated_at)}`} /> : null}
      </div>

      <SectionCard title="Error budget" description={budget ? `Target error rate ${budget.target_error_rate}% (ECH_KPI_TARGET_REQUEST_ERROR_RATE) over the last ${hours} hours.` : undefined}>
        <div className="space-y-3 p-4">
          <div className="flex flex-wrap items-baseline gap-x-6 gap-y-1 text-sm">
            <span>
              <span className="font-display text-3xl font-medium tabular-nums">{consumed === null ? "—" : `${consumed.toFixed(0)}%`}</span>
              <span className="ml-2 text-xs text-muted-foreground">of the budget used</span>
            </span>
            <span className="text-xs text-muted-foreground">{budget ? `${budget.errors} errors · ${budget.allowed_errors} allowed · ${formatInt(budget.requests)} audited requests` : "…"}</span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
            <div
              className={cn("h-full rounded-full transition-all", consumed === null ? "bg-muted-foreground/30" : consumed > 100 ? "bg-destructive" : consumed > 50 ? "bg-warning" : "bg-success")}
              style={{ width: `${Math.min(100, Math.max(2, consumed ?? 0))}%` }}
            />
          </div>
          <p className="text-[11px] text-muted-foreground">
            {consumed === null ? "No audited requests in the window, so no budget is consumed." : consumed > 100 ? "Budget exhausted: treat new errors as incidents until the rate recovers." : "Under budget."}
          </p>
        </div>
      </SectionCard>

      {!r ? (
        <Skeleton className="h-64 w-full" />
      ) : (
        r.groups.map((group) => (
          <section key={group.key}>
            <h2 className="text-sm font-medium">{group.label}</h2>
            <p className="mb-3 text-xs text-muted-foreground">{group.description}</p>
            <div className="kpi-grid">
              {group.kpis.map((k) => (
                <KpiTile key={k.key} kpi={k} />
              ))}
            </div>
          </section>
        ))
      )}

      <SectionCard
        title={`Active targets${r?.targets.some((t) => t.overridden) ? ` · ${r.targets.filter((t) => t.overridden).length} custom` : ""}`}
        description="Set ECH_KPI_TARGET_* in .env and restart the query service to change a target; unset variables keep the defaults."
      >
        <TargetsTable targets={r?.targets} />
      </SectionCard>
    </div>
  );
}

// ----------------------------------------------------------------------------- capacity
function Capacity() {
  const report = usePlatformReport(24);
  const activity = useActivity(7 * 24, 24 * 60);
  const reconcile = useReconcileGraph();
  const r = report.data;
  const largest = r?.storage[0]?.bytes ?? 1;

  return (
    <div className="space-y-6">
      <section className="stat-grid">
        <MetricCard title="Postgres database" value={formatBytes(r?.database_bytes)} hint={r ? `${r.storage.length} tables · heap, indexes and TOAST` : undefined} icon={Database} loading={report.isLoading} />
        <MetricCard
          title="Vectors"
          value={formatCompact(r?.embeddings_total)}
          hint={r ? `${r.vector_dimensions} dims · about ${formatBytes(r.embeddings_bytes_estimate)} of float32` : undefined}
          icon={HardDrive}
          loading={report.isLoading}
        />
        <MetricCard title="Knowledge graph" value={formatCompact(r?.graph_nodes)} hint={r ? `${formatCompact(r.graph_edges)} edges in Neo4j` : undefined} icon={Network} loading={report.isLoading} />
        <MetricCard title="Audit rows per day" value={formatCompact(r?.audit_rows_per_day)} hint="7-day average · audit_logs grows by this much" icon={Activity} loading={report.isLoading} />
      </section>

      <section className="grid gap-6 lg:grid-cols-5">
        <SectionCard className="lg:col-span-3" title="Storage by table" description="Live row estimates and on-disk size per hub table, largest first.">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Table</TableHead>
                <TableHead className="text-right">Rows</TableHead>
                <TableHead className="text-right">Size</TableHead>
                <TableHead className="w-[30%]">Share</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {r?.storage.map((t) => (
                <TableRow key={t.table}>
                  <TableCell className="font-mono text-xs">{t.table}</TableCell>
                  <TableCell className="text-right font-mono text-xs">{formatInt(t.rows)}</TableCell>
                  <TableCell className="text-right font-mono text-xs">{formatBytes(t.bytes)}</TableCell>
                  <TableCell>
                    <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
                      <div className="h-full rounded-full bg-primary/70" style={{ width: `${Math.max(2, (t.bytes / largest) * 100)}%` }} />
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {r && r.storage.length === 0 ? <EmptyRow colSpan={4}>No table statistics available.</EmptyRow> : null}
            </TableBody>
          </Table>
        </SectionCard>
        <div className="space-y-6 lg:col-span-2">
          <SectionCard title="Graph reconciliation" description="Postgres is the system of record; Neo4j is rebuilt from it for pending and failed documents.">
            <div className="space-y-3 p-4 text-sm">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Active / stalled runs</span>
                <span className="font-mono">{r ? `${r.runs_active} / ${r.runs_stale}` : "—"}</span>
              </div>
              <Button size="sm" variant="outline" className="w-full" disabled={reconcile.isPending} onClick={() => reconcile.mutate()}>
                <RefreshCw className={cn("h-3.5 w-3.5", reconcile.isPending && "animate-spin")} />
                {reconcile.isPending ? "Reconciling…" : "Reconcile graph now"}
              </Button>
              {reconcile.data ? (
                <p className="text-xs text-muted-foreground">
                  scanned {reconcile.data.scanned}, synced {reconcile.data.synced}, failed {reconcile.data.failed}
                </p>
              ) : null}
              {reconcile.isError ? <p className="text-xs text-destructive">{describeError(reconcile.error)}</p> : null}
              {r && r.runs_stale > 0 ? (
                <p className="flex items-start gap-2 text-xs text-warning">
                  <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                  {r.runs_stale} run(s) have not reported progress for an hour. Cancel them from Pipelines; the ingestion service also fails stale runs on restart.
                </p>
              ) : null}
            </div>
          </SectionCard>
          <SectionCard title="Runs per day · last 7 days" description="Completed, failed and cancelled runs with documents upserted.">
            <div className="p-4">
              <ActivityChart points={activity.data} loading={activity.isLoading} height={200} />
            </div>
          </SectionCard>
        </div>
      </section>
    </div>
  );
}
