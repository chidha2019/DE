import { ArrowLeft, Workflow } from "lucide-react";
import { Link, useParams, useSearchParams } from "react-router-dom";

import { PageHero } from "@/components/layout/page-hero";
import { PipelineWizard } from "@/components/pipelines/pipeline-wizard";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { usePipeline } from "@/hooks/queries";
import { describeError } from "@/lib/api-client";

/** Create a pipeline (/pipelines/new) or edit one (/pipelines/:id/edit). */
export function PipelineWizardPage() {
  const { pipelineId = null } = useParams<{ pipelineId: string }>();
  const [params] = useSearchParams();
  const pipeline = usePipeline(pipelineId);
  const editing = pipelineId !== null;
  const back = editing ? `/pipelines/${pipelineId}` : "/pipelines";
  return (
    <div className="flex-1 space-y-4 overflow-auto p-4 md:space-y-5 md:p-6">
      <PageHero
        slim
        eyebrow="Ingestion"
        icon={Workflow}
        title={editing ? "Edit pipeline" : "New pipeline"}
        lead={editing ? (pipeline.data ? `Change what ${pipeline.data.name} reads, how it runs and when.` : "Loading the pipeline…") : "Pick a connection, choose what to ingest from its live schema, set the details and a schedule."}
        actions={
          <Button variant="outline" size="sm" asChild>
            <Link to={back}>
              <ArrowLeft className="h-3.5 w-3.5" /> {editing ? "Back to pipeline" : "Back to pipelines"}
            </Link>
          </Button>
        }
      />
      {editing && pipeline.isLoading ? <Skeleton className="mx-auto h-96 max-w-6xl" /> : null}
      {editing && pipeline.isError ? (
        <div className="mx-auto max-w-6xl rounded-xl border border-destructive/40 p-6 text-sm text-destructive">
          {describeError(pipeline.error)}{" "}
          <Link to="/pipelines" className="underline">
            Back to pipelines
          </Link>
        </div>
      ) : null}
      {!editing || pipeline.data ? <PipelineWizard key={pipeline.data?.id ?? "new"} pipeline={pipeline.data} initialConnection={params.get("connection")} /> : null}
    </div>
  );
}
