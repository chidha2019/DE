import { Activity, CalendarClock, History, Layers, Plus, RefreshCw, Search, TriangleAlert, Workflow, X } from "lucide-react";
import { useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";

import type { ConnectorInfo, PipelineOut } from "@/api/types";
import { HeroStats, PageHero } from "@/components/layout/page-hero";
import { ViewSwitcher } from "@/components/layout/view-switcher";
import { ConfirmDialog } from "@/components/pipelines/confirm-dialog";
import { ConnectionStrip } from "@/components/pipelines/connection-strip";
import { PipelineCard } from "@/components/pipelines/pipeline-card";
import { RunHistory } from "@/components/pipelines/run-history";
import { TriggerRunDialog } from "@/components/pipelines/trigger-run-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { useConnectors, useDeletePipeline, usePipelines, useReconcileGraph, useRunPipeline, useRuns, useToggleSchedule } from "@/hooks/queries";
import { useRunEventStream } from "@/hooks/use-sse";
import { describeError } from "@/lib/api-client";
import { cn } from "@/lib/utils";

type Tab = "pipelines" | "history";

function matches(p: PipelineOut, source: string | null, needle: string): boolean {
  if (source && p.connector !== source) return false;
  if (!needle) return true;
  const hay = [p.name, p.description, p.owner, p.tags.join(" "), p.scope.map((s) => s.path.join(" ")).join(" ")].join(" ").toLowerCase();
  return needle.split(" ").every((t) => hay.includes(t));
}

export function PipelinesPage() {
  const [params, setParams] = useSearchParams();
  const tab: Tab = params.get("tab") === "history" ? "history" : "pipelines";
  const [source, setSource] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [runAll, setRunAll] = useState<ConnectorInfo | null>(null);
  const [toDelete, setToDelete] = useState<PipelineOut | null>(null);
  const [notice, setNotice] = useState<{ tone: "error" | "info"; text: string } | null>(null);
  const connections = useConnectors();
  const pipelines = usePipelines();
  const runs = useRuns({ limit: 25 });
  const run = useRunPipeline();
  const toggle = useToggleSchedule();
  const remove = useDeletePipeline();
  const reconcile = useReconcileGraph();
  // Run events refresh the cards as they happen; the History tab mounts its own stream for the log.
  useRunEventStream({ maxEvents: 1, enabled: tab === "pipelines" });

  const all = pipelines.data ?? [];
  const needle = search.trim().toLowerCase();
  const shown = useMemo(() => all.filter((p) => matches(p, source, needle)), [all, source, needle]);
  const connectionList = connections.data ?? [];
  const counts = useMemo(() => {
    const out: Record<string, number> = {};
    for (const p of all) out[p.connector] = (out[p.connector] ?? 0) + 1;
    return out;
  }, [all]);
  const busy = useMemo(() => {
    const set = new Set<string>();
    for (const r of runs.data?.items ?? []) if (r.status === "running" || r.status === "paused" || r.status === "queued") set.add(r.connector_name);
    return set;
  }, [runs.data]);
  const running = all.filter((p) => ["running", "queued", "paused"].includes(p.last_run?.status ?? "")).length;
  const failing = all.filter((p) => p.last_run?.status === "failed").length;
  const scheduled = all.filter((p) => p.enabled && p.schedule.type !== "manual").length;
  const connectionOf = (p: PipelineOut) => connectionList.find((c) => c.name === p.connector);
  const setTab = (next: Tab) => setParams(next === "history" ? { tab: "history" } : {}, { replace: true });
  const fail = (error: unknown) => setNotice({ tone: "error", text: describeError(error) });

  return (
    <>
      <div className="flex-1 space-y-4 overflow-auto p-4 md:space-y-5 md:p-6">
        <PageHero
          slim
          eyebrow="Ingestion"
          icon={Workflow}
          title="Pipelines"
          lead="Saved ingestion jobs on your connections: pick what to read from the live schema, set a schedule, run and watch."
          aside={
            <HeroStats
              items={[
                { label: "Pipelines", value: pipelines.data ? all.length : undefined, icon: Workflow },
                { label: "Scheduled", value: pipelines.data ? scheduled : undefined, icon: CalendarClock },
                { label: "Running", value: pipelines.data ? running : undefined, icon: Activity, tone: "#10B981" },
                { label: "Failing", value: pipelines.data ? failing : undefined, icon: TriangleAlert, tone: failing ? "#EF4444" : "#F59E0B" },
              ]}
            />
          }
          actions={
            <>
              <Button variant="outline" size="sm" disabled={reconcile.isPending} onClick={() => reconcile.mutate()}>
                <RefreshCw className={reconcile.isPending ? "h-3.5 w-3.5 animate-spin" : "h-3.5 w-3.5"} /> Reconcile graph
              </Button>
              <Button size="sm" asChild>
                <Link to="/pipelines/new">
                  <Plus className="h-3.5 w-3.5" /> New pipeline
                </Link>
              </Button>
            </>
          }
        />
        {notice ? (
          <div className={cn("flex items-start justify-between gap-3 rounded-xl border p-3 text-sm", notice.tone === "error" ? "border-destructive/40 bg-destructive/10 text-destructive" : "border-border bg-muted/40")}>
            <span>{notice.text}</span>
            <button type="button" aria-label="Dismiss" onClick={() => setNotice(null)}>
              <X className="h-4 w-4" />
            </button>
          </div>
        ) : null}
        {reconcile.data ? <p className="text-xs text-muted-foreground">Reconcile: scanned {reconcile.data.scanned}, synced {reconcile.data.synced}, failed {reconcile.data.failed}, orphan entities removed {reconcile.data.orphan_entities_removed}.</p> : null}

        <div className="flex flex-wrap items-center justify-between gap-3">
          <ViewSwitcher
            size="md"
            label="Pipelines"
            value={tab}
            onChange={setTab}
            views={[
              { key: "pipelines", label: "Pipelines", count: pipelines.data ? all.length : undefined, icon: Workflow, tone: "#0EA5E9", description: "Saved jobs and their last run" },
              { key: "history", label: "Run history", count: runs.data?.total, icon: History, tone: "#8B5CF6", description: "Every run with its live log" },
            ]}
          />
          {tab === "pipelines" ? (
            <div className="relative w-full sm:max-w-xs">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
              <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search pipelines or sources…" className="h-9 pl-9 text-sm" aria-label="Search pipelines" />
            </div>
          ) : null}
        </div>

        {tab === "history" ? (
          <RunHistory />
        ) : (
          <>
            <div className="flex flex-wrap items-center gap-2" role="group" aria-label="Source filter">
              <span className="text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">Source</span>
              <SourceChip active={source === null} label="All sources" count={all.length} onClick={() => setSource(null)} />
              {connectionList.map((c) => (
                <SourceChip key={c.name} active={source === c.name} label={c.display_name} count={counts[c.name] ?? 0} healthy={c.healthy} onClick={() => setSource(source === c.name ? null : c.name)} />
              ))}
              <Link to="/connectors" className="ml-auto text-xs text-primary hover:underline">
                Manage connections
              </Link>
            </div>
            {pipelines.isError ? (
              <div className="rounded-xl border border-destructive/40 p-4 text-sm text-destructive">{describeError(pipelines.error)}</div>
            ) : pipelines.isLoading ? (
              <div className="grid gap-4 lg:grid-cols-2 2xl:grid-cols-3">
                {[0, 1, 2].map((i) => (
                  <Skeleton key={i} className="h-60" />
                ))}
              </div>
            ) : all.length === 0 ? (
              <section className="surface space-y-6 p-5 sm:p-8">
                <div className="mx-auto max-w-xl text-center">
                  <span className="icon-tile mx-auto h-14 w-14">
                    <Workflow className="h-6 w-6" />
                  </span>
                  <h2 className="mt-4 text-xl font-medium">Start with a source connection</h2>
                  <p className="mt-1 text-sm text-muted-foreground">Pick a connection, browse its schema and choose what to ingest. A pipeline keeps that choice, runs it on a schedule and records every run.</p>
                </div>
                <ConnectionStrip hero connections={connectionList} pipelineCounts={counts} busy={busy} onRunAll={setRunAll} />
              </section>
            ) : shown.length === 0 ? (
              <p className="rounded-xl border border-dashed border-border/80 p-10 text-center text-sm text-muted-foreground">No pipeline matches. Clear the search or pick another source.</p>
            ) : (
              <div className="grid gap-4 lg:grid-cols-2 2xl:grid-cols-3">
                {shown.map((p) => (
                  <PipelineCard
                    key={p.id}
                    pipeline={p}
                    connection={connectionOf(p)}
                    busy={busy.has(p.connector)}
                    onRun={(pl) => run.mutate(pl.id, { onError: fail, onSuccess: () => setNotice({ tone: "info", text: `Started ${pl.name}. Follow it in Run history.` }) })}
                    onToggle={(pl) => toggle.mutate({ id: pl.id, enabled: !pl.enabled }, { onError: fail })}
                    onDelete={setToDelete}
                  />
                ))}
              </div>
            )}
            {all.length > 0 ? (
              <section>
                <h2 className="mb-3 flex items-center gap-2 text-sm font-medium text-muted-foreground">
                  <Layers className="h-3.5 w-3.5" /> Connections
                </h2>
                <ConnectionStrip connections={connectionList} pipelineCounts={counts} busy={busy} onRunAll={setRunAll} />
              </section>
            ) : null}
          </>
        )}
      </div>

      <TriggerRunDialog connector={runAll} onClose={() => setRunAll(null)} />
      <ConfirmDialog
        open={toDelete !== null}
        title={`Delete ${toDelete?.name ?? "pipeline"}?`}
        description="The pipeline and its schedule are removed. Its past runs and everything it ingested stay."
        confirmLabel="Delete pipeline"
        pending={remove.isPending}
        error={remove.isError ? describeError(remove.error) : null}
        onClose={() => {
          setToDelete(null);
          remove.reset();
        }}
        onConfirm={() => toDelete && remove.mutate(toDelete.id, { onSuccess: () => setToDelete(null) })}
      />
    </>
  );
}

function SourceChip({ active, label, count, healthy, onClick }: { active: boolean; label: string; count: number; healthy?: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={cn("flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs transition-colors", active ? "border-primary/60 bg-primary/15 text-foreground" : "border-border/70 text-muted-foreground hover:text-foreground")}
    >
      {healthy !== undefined ? <span className={cn("h-1.5 w-1.5 rounded-full", healthy ? "bg-success" : "bg-destructive")} aria-hidden="true" /> : null}
      {label}
      <span className="font-mono text-[10px] tabular-nums text-muted-foreground">{count}</span>
    </button>
  );
}
