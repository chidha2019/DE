# Enterprise Context Hub (ECH)

The **Enterprise Context Hub** is the unified semantic, relational and document context layer that
powers downstream AI orchestrators and agents. It ingests catalog metadata from **Snowflake** and
**Databricks Unity Catalog** into a governed **semantic layer** (tables, columns with roles, keys and
joins, lineage, metrics), crawls GitHub repositories for the documents around that data, structures
everything into chunks, vectors and an entity graph, and serves it with sub-second latency through a
single hybrid-retrieval API and a Genie-style conversational interface. There is no demo data: only
connectors with credentials are registered.

```
                ┌──────────────────────────── Admin UI (React / Vite / Tailwind / shadcn) ───────────────────────────┐
                │  Personas: Data Engineer · Analyst · QA · Architect · SRE · DevOps · DevSecOps · Steward · ... · Genie  │
                └───────────────┬─────────────────────────────────────────────────────┬───────────────────────────────┘
                                │ /ingestion/*                                        │ /query/*
                ┌───────────────▼───────────────┐                     ┌───────────────▼────────────────────────────────┐
                │ Ingestion & Processing Service │                     │ Query & Context API Service                   │
                │ FastAPI · :8001                │                     │ FastAPI · :8002                               │
                │ connectors → semantic chunking │                     │ POST /api/v1/context/retrieve                 │
                │ → entity extraction → embedding│                     │ dense (pgvector) ‖ lexical (FTS) → RRF        │
                │ → Postgres tx → Neo4j tx       │                     │ → Neo4j 1st/2nd-degree expansion → rerank     │
                └──────┬───────────────┬─────────┘                     └──────┬───────────────────────┬────────────────┘
                       │               │                                      │                       │
          ┌────────────▼──────┐   ┌────▼─────────────────┐        ┌───────────▼─────┐   ┌─────────────▼──────────┐
          │ PostgreSQL+pgvector│   │ Neo4j                │        │ PostgreSQL      │   │ Neo4j                  │
          │ documents, chunks, │   │ Document/Chunk/Entity│        │ HNSW cosine +   │   │ MENTIONS, DEPENDS_ON,  │
          │ embeddings(1536),  │   │ HAS_CHUNK, MENTIONS, │        │ GIN tsvector    │   │ REFERENCES, CONTRIBUTED│
          │ runs, audit        │   │ REFERENCES, DEPENDS_ON│       └─────────────────┘   └────────────────────────┘
          └────────────────────┘   │ CONTRIBUTED_BY       │
                                   └──────────────────────┘
```

---

## Quick start (Docker)

```bash
cp .env.example .env
docker compose up --build -d
```

| URL | What |
| --- | --- |
| http://localhost:3000 | Admin UI |
| http://localhost:8001/docs | Ingestion service OpenAPI |
| http://localhost:8002/docs | Query service OpenAPI |
| http://localhost:7474 | Neo4j Browser (`neo4j` / `ech_dev_password`) |
| `:8001/metrics`, `:8002/metrics` | Prometheus exposition |

Point a connector at real metadata (in `.env`) and run it:

```bash
# Databricks Unity Catalog -> semantic layer (DATABRICKS_HOST/TOKEN are shared with Genie)
ECH_DATABRICKS_CATALOGS=my_catalog,other_catalog
# Snowflake -> semantic layer (programmatic access token, OAuth or key-pair JWT)
ECH_SNOWFLAKE_ACCOUNT=myorg-myaccount  ECH_SNOWFLAKE_TOKEN=...  ECH_SNOWFLAKE_DATABASES=ANALYTICS
# Documents around the data
ECH_GITHUB_REPOS=owner/repo
```

```bash
docker compose up -d --force-recreate ingestion-service query-service
make ingest-databricks    # or: make ingest-snowflake / make ingest-github
```

Or create a pipeline in the UI (**Pipelines → New pipeline**: pick a connection, tick what to ingest from its live schema, set a schedule) and watch the SSE event log. Then open **Semantic Hub**
to browse the assets, **Genie** to ask *"Which fact tables hold claim payments and how do they join to
policies?"*, or **Knowledge Hub** to crawl a GitHub repository into a graph of its pipelines, tables and columns.

---

## Repository layout

```
.
├── docker-compose.yml           postgres (pgvector), neo4j, migrate job, 2 services, frontend
├── infra/
│   ├── postgres/init/           extensions created at initdb (vector, pg_trgm, pgcrypto)
│   ├── postgres/migrations/     0001 schema · 0002 embeddings+HNSW · 0003 pipelines+audit · 0004 genie · 0005 semantic · … · 0011 glossary
│   └── neo4j/schema/            constraints + indexes (idempotent Cypher)
├── backend/
│   ├── ech_core/                shared kernel: config, logging, db adapters, domain, repositories,
│   │                            schemas, embeddings, middleware, app factory, llm (Claude client),
│   │                            semantic (asset model, role/join inference, markdown, exports)
│   ├── ingestion_service/       connectors (github-live, databricks, snowflake), chunking,
│   │                            extraction, pipeline, SSE, routers
│   ├── query_service/           hybrid retrieval engine, reranker, graph/stats services, Genie, routers
│   ├── scripts/                 migrate · neo4j_schema
│   └── tests/                   unit tests (no databases needed)
└── frontend/                    React 18 + TypeScript + Vite + Tailwind + shadcn/ui
```

Both services follow a DDD-style layering: **routers** (`api/`) → **services** → **repositories**
(the only layer with SQL/Cypher) → **domain models / schemas**. Everything is `async` end-to-end
(`asyncpg`, `neo4j.AsyncGraphDatabase`, `httpx.AsyncClient`).

---

## Local development (host)

```bash
# datastores + migrations in Docker, services on the host
make dev-infra

cd backend
python -m venv .venv && . .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -e ".[dev]"
cp ../.env.example .env                              # then set ECH_POSTGRES_DSN / ECH_NEO4J_* to localhost
uvicorn ingestion_service.main:app --reload --port 8001
uvicorn query_service.main:app     --reload --port 8002
pytest -q

cd ../frontend
npm install
npm run dev                                          # http://localhost:5173, proxies /ingestion and /query
npm run build                                        # tsc -b && vite build
```

---

## Retrieval pipeline (`POST /api/v1/context/retrieve`)

```jsonc
{
  "query": "Which fact tables hold claim payments and how do they join to policies?",   // or "agent_state": {...}
  "top_k": 8,
  "filters":  { "source_systems": ["databricks","github"], "attributes": {"catalog": "life_edw"} },
  "options":  { "use_vector": true, "use_keyword": true, "use_graph": true, "use_rerank": true,
                "graph_hops": 2, "include_graph_context": true, "include_debug": false }
}
```

| Stage | Implementation | Notes |
| --- | --- | --- |
| embed | same provider as ingestion | `hashing` (dev, deterministic) · `openai` text-embedding-3-small · `local` sentence-transformers |
| vector | `embeddings <=> $q` with HNSW, `SET LOCAL hnsw.ef_search` | iterative scan enabled when filters are present (pgvector ≥ 0.8) |
| keyword | `websearch_to_tsquery` + `ts_rank_cd(..., 1\|32)` on a GIN index | BM25-style length normalisation, scores in [0,1) |
| fusion | reciprocal rank fusion (`k=60`, per-leg weights) | robust to incomparable score scales |
| graph | Neo4j: entities of the hits (1st degree) → `DEPENDS_ON` neighbours (2nd) → other chunks mentioning them | injected into the pool with a bounded `graph_boost` |
| hydrate | one `SELECT … WHERE id = ANY($1)` | drops deleted documents |
| rerank | `cross_encoder` (ms-marco-MiniLM) or `heuristic` (BM25 over the pool + title/phrase bonuses) | blended with `reranker_weight` |

Every response carries per-stage timings, a per-result score breakdown
(`vector`, `keyword`, `fused`, `graph_boost`, `rerank`, `final`), the retrieval paths that produced
each chunk and, optionally, the graph neighbourhood (`nodes`, `edges`, 1st/2nd-degree entity keys).

---

## Postgres ↔ Neo4j consistency model

* **Deterministic identifiers.** `documents.id = uuid5(ECH_NAMESPACE, "<source_system>:<external_id>")`
  and `chunks.id = uuid5(document_id, "chunk:<index>")`. Neo4j `Document.document_id` and
  `Chunk.chunk_id` hold the *same* values, so the two stores join without a mapping table and
  re-ingestion is idempotent.
* **Postgres is the system of record; Neo4j is derived.** Per document the pipeline runs:
  1. metadata upsert + change detection (`SELECT … FOR UPDATE`, content hash, `version`),
  2. chunk / extract / embed outside any transaction,
  3. one Postgres transaction: replace chunks, upsert embeddings, `graph_sync_status = pending`,
  4. one Neo4j managed write transaction rewriting the whole document subgraph
     (`HAS_CHUNK`, `MENTIONS`, `CONTRIBUTED_BY`, `REFERENCES`, `DEPENDS_ON`),
  5. mark `synced` (+ `graph_node_id`) or `failed` (+ error).
* **Reconciliation.** Entities are also persisted in `chunks.metadata.entities`, so
  `POST /api/v1/admin/reconcile-graph` can rebuild any `pending`/`failed` subgraph without
  re-running extraction. Search keeps working from Postgres while the graph is stale.
* **Entity→entity evidence is retractable.** `DEPENDS_ON` edges carry parallel `evidence`
  (document ids) and `weights` lists; every re-sync or delete first retracts the document's
  own contribution, so re-extraction never leaves phantom entities behind.
  `reconcile-graph` additionally prunes evidence pointing at documents that no longer exist
  and removes orphaned entities.
* **Graph writes are serialised** (`ECH_GRAPH_SYNC_CONCURRENCY=1` by default): documents
  share Entity nodes, and parallel `MERGE`s only produce deadlock retries. Chunking,
  embedding and Postgres writes still run with `ECH_INGESTION_CONCURRENCY` workers.
* **Deletes** go graph-first, then Postgres, so a failure never leaves orphaned graph nodes
  without a marker.

---

## Configuration (`ECH_*` environment variables)

| Variable | Default | Purpose |
| --- | --- | --- |
| `ECH_POSTGRES_DSN` | `postgresql://ech:…@localhost:5432/ech` | asyncpg DSN |
| `ECH_NEO4J_URI` / `_USER` / `_PASSWORD` | `bolt://localhost:7687` / `neo4j` | Neo4j driver |
| `ECH_EMBEDDING_PROVIDER` | `hashing` | `hashing` · `openai` · `local` |
| `ECH_EMBEDDING_MODEL` / `ECH_EMBEDDING_DIMENSIONS` | `text-embedding-3-small` / `1536` | must match the `vector(1536)` column |
| `ECH_OPENAI_API_KEY` | – | required for `openai` |
| `ECH_RERANKER_PROVIDER` | `heuristic` | `heuristic` · `cross_encoder` · `none` |
| `ECH_RETRIEVAL_VECTOR_TOP_K` / `_KEYWORD_TOP_K` | `40` / `40` | leg sizes before fusion |
| `ECH_RETRIEVAL_GRAPH_BOOST_WEIGHT` | `0.25` | max boost for graph-expanded chunks |
| `ECH_HNSW_EF_SEARCH` | `100` | per-query recall knob |
| `ECH_CHUNK_TARGET_TOKENS` / `_MAX_TOKENS` / `_OVERLAP_TOKENS` | `320` / `512` / `48` | semantic chunker |
| `ECH_CHUNK_OVERLAP_STRATEGY` | `sentence` | `sentence` · `token` · `none` |
| `ECH_GITHUB_REPOS` / `ECH_GITHUB_TOKEN` | – | live GitHub connector: `owner/name[@ref]` list; token lifts the API quota |
| `ECH_GITHUB_MAX_FILE_KB` | `256` | skip larger files (lock files are excluded by glob anyway) |
| `DATABRICKS_HOST` / `DATABRICKS_TOKEN` + `ECH_DATABRICKS_CATALOGS` / `_SCHEMAS` | – | `databricks` connector: Unity Catalog tables, views, metric views (+ `ECH_DATABRICKS_INCLUDE_LINEAGE`, `_MAX_TABLES`, `_FETCH_CONCURRENCY`) |
| `ECH_SNOWFLAKE_ACCOUNT` / `_HOST` / `_USER` / `_TOKEN` / `_AUTH_SCHEME` | – / `PROGRAMMATIC_ACCESS_TOKEN` | `snowflake` connector via the SQL REST API; `OAUTH` or `KEYPAIR_JWT` (`_PRIVATE_KEY_PATH`, `_PRIVATE_KEY_PASSPHRASE`) |
| `ECH_SNOWFLAKE_DATABASES` / `_SCHEMAS` / `_WAREHOUSE` / `_ROLE` | – | scope and session for the metadata queries (`_INCLUDE_TAGS`, `_INCLUDE_LINEAGE` read ACCOUNT_USAGE when granted) |
| `ECH_SEMANTIC_INFER_JOINS` | `true` | infer joins across ingested assets after each run (shared keys, dimension base names) |
| `ECH_KPI_TARGET_<KEY>` | see `.env.example` | Data Engineer KPI targets (`RUN_SUCCESS_RATE=95`, `FACTS_KEYED_PCT=80`, `CATALOG_SYNC_AGE_H=24`, …); the KPIs tab lists the active values and marks overrides |
| `ECH_INGESTION_CONCURRENCY` | `4` | parallel documents per run |
| `ECH_GRAPH_SYNC_CONCURRENCY` | `1` | parallel Neo4j subgraph writes (keep at 1 unless entities rarely overlap) |
| `ECH_PIPELINE_SCHEDULER_ENABLED` / `_INTERVAL_SECONDS` | `true` / `30` | the ingestion service starts due scheduled pipelines; how often it looks |
| `ECH_LLM_PROVIDER` / `ECH_LLM_MODEL` / `ECH_LLM_EFFORT` | `auto` / provider default / `medium` | Genie's Claude: `auto` picks `databricks` when `DATABRICKS_HOST` + `DATABRICKS_TOKEN` are set, else the Claude API (`ANTHROPIC_API_KEY`) |
| `ECH_GENIE_MAX_TURNS` / `ECH_GENIE_CYPHER_ROW_LIMIT` / `ECH_GENIE_CYPHER_TIMEOUT_SECONDS` | `8` / `50` / `10` | Genie's tool-loop cap and read-only Cypher guardrails |
| `ECH_LOG_JSON` | `false` | JSON logs (set `true` in containers) |

See `backend/ech_core/config.py` for the full list (connection retries/backoff, pool sizes, …).

---

## API surface

**Ingestion service (`:8001`)**

| Method & path | Purpose |
| --- | --- |
| `GET /api/v1/connectors` | registered connectors with health, estimated size and whether their schema can be browsed (`discoverable`, `scope_levels`, `option_keys`) |
| `GET /api/v1/connectors/{name}/discover?path=a&path=b` | browse the live schema of a connection: no path lists databases (catalogs, repositories, folders), each path segment opens one level down to tables and columns |
| `GET/POST /api/v1/pipelines` · `GET/PUT/DELETE /api/v1/pipelines/{id}` | saved pipelines: connection, selected scope, run options, schedule; `409` on a duplicate name |
| `POST /api/v1/pipelines/preview` | how many documents a scope would read, asked of the connection |
| `POST /api/v1/pipelines/{id}/run` · `POST /api/v1/pipelines/{id}/schedule {enabled}` | run now (`202`, `409` if the connection is busy); turn the schedule on or off |
| `POST /api/v1/pipelines/runs` | trigger a run (`202`), `409` if the connector is busy |
| `GET /api/v1/pipelines/runs[/{id}[/events]]` | list (filter by `status`, `connector`, `pipeline_id`) / inspect / persisted events |
| `POST /api/v1/pipelines/runs/{id}/pause|resume|cancel` | co-operative control |
| `GET /api/v1/events/stream?run_id=` | **SSE** live progress (heartbeat every 15 s) |
| `POST /api/v1/documents` · `DELETE /api/v1/documents/{id}` | manual ingest / delete (Postgres + Neo4j) |
| `POST /api/v1/admin/reconcile-graph` | retry Neo4j sync for pending/failed documents |

**Query service (`:8002`)**

| Method & path | Purpose |
| --- | --- |
| `POST /api/v1/context/retrieve` | hybrid + GraphRAG context for agents |
| `GET /api/v1/documents[...]` | list (`kind=document|dataset`, source, graph status, search) / detail / chunks / `graph` / `lineage` |
| `GET /api/v1/graph/entities[/search]`, `/graph/neighborhood`, `/graph/stats` | explorer |
| `GET /api/v1/stats/overview`, `/stats/latency`, `/stats/activity`, `/stats/audit` | dashboard |
| `GET /api/v1/stats/engineering?days=7` | Data Engineer KPIs with targets and verdicts: run success rate, failed runs, document failure rate, throughput; graph sync rate/failures/pending; catalog coverage (described, owned, keyed facts, connected, declared joins, described columns, declared metrics); freshness (synced in 24h, stale 7d, hours since last sync); per-connector last success |
| `GET /api/v1/stats/quality?days=7` | QA Engineer quality gates (ingestion, catalog integrity, semantic review, serving) with `gates_passed/gates_total`, failed runs with errors, the enrichment review queue (least confident first), recent audited request errors |
| `GET /api/v1/stats/analyst?days=7` | Business Analyst scorecard: questions answered self-serve in the analyst's Genie space, request-to-decision hours for intents, intents waiting on clarification, curated-layer metrics declared |
| `GET /api/v1/stats/platform?hours=24` | SRE report: serving SLOs (request error rate, retrieval p95, Genie error rate), pipeline and freshness SLOs, error budget, audited calls per action with percentiles, storage per table and database size, vector memory estimate, graph size, audit growth, active and stalled runs, recent errors |
| `GET /api/v1/stats/architecture` | Architect landscape: per-platform catalogs/schemas/assets/kinds, document sources, assets by kind, fields by role, relationships by kind, metrics by provenance, graph composition, subject areas, conformed dimensions (joined from two or more facts), cross-platform links, every integration point with its status |
| `GET /api/v1/genie/status` · `/genie/spaces[/{id}]` (`GET`/`POST`/`PATCH`/`DELETE`) | Genie: configured model; curated spaces |
| `POST /api/v1/genie/spaces/{id}/ask` | **SSE** streamed answer: `conversation`, `delta`, `turn_reset`, `step`, `step_done`, `message` / `error` |
| `GET /api/v1/genie/spaces/{id}/conversations`, `/genie/conversations/{id}`, `POST /genie/messages/{id}/feedback` | saved conversations, messages with citations and trace, thumbs up/down |
| `GET /api/v1/semantic/overview` · `/semantic/assets[/{id}[/graph]]` · `/semantic/search?q=` | semantic layer: totals per scope, assets with columns/roles/keys/joins/lineage/metrics, neighbourhood graph, search |
| `GET /api/v1/semantic/business-model` · `POST /semantic/enrich` · `GET /semantic/enrich[/{id}]` · `POST /semantic/assets/{id}/enrich` · `POST /semantic/assets/{id}/enrichment` | business model (subject areas, fact stars, governed metrics); Claude enrichment runs and per-asset suggestions with accept/reject |
| `GET /api/v1/semantic/catalog` · `/semantic/catalog/objects?domain=&direct=&type=&model=&database=&owner=&search=&min_quality=&sort=&order=` | semantic catalog: the business-domain tree with entity, dimension, measure, metric, relationship and hierarchy counts and mean quality per node, and the filterable object list with name, type, domain (and how it was placed), model, owner, quality checks and last update |
| `GET /api/v1/semantic/metrics` · `/semantic/glossary` · `/semantic/health` | persona views: metrics catalog (declared first), business glossary (column names across datasets), catalog health (undocumented, unowned, keyless facts, isolated assets, inferred joins to review) |
| `GET /api/v1/semantic/export?format=cortex` \| `databricks_metric_view` \| `hub` | export the scope as a Snowflake Cortex Analyst semantic model, Databricks metric-view YAML or hub JSON |
| `GET /api/v1/glossary/domains` · `/glossary/coverage` · `/glossary/terms[/{id}]` · `POST/PATCH /glossary/terms[/{id}]` | business glossary: the insurance domain tree (ACORD areas, FIBO-flagged party/contract/money) with term, KPI and dataset counts; how much of the catalog carries business meaning; terms with definitions, synonyms, standard references and where they are used; add or curate terms |
| `GET /api/v1/glossary/links?status=suggested` · `POST /glossary/links` · `POST /glossary/links/{id}/decide` | term links on datasets, columns and metrics with confidence and provenance (`rule` \| `model` \| `curated`); link by hand; accept (copies the term's synonyms onto the column or metric, places the dataset in the term's domain, binds a KPI waiting on that term) or reject |
| `GET /api/v1/glossary/kpis` · `PATCH /glossary/kpis/{id}` | KPI definitions with grain, period, unit, direction, target and warning thresholds, owner and the governed metric that computes them |
| `POST /api/v1/glossary/map` · `GET /glossary/map[/{id}]` | map a scope to terms: name and synonym rules first, then Claude per dataset (datasets, columns, metrics and the domain), as a polled run; proposals land in the review queue |
| `POST /api/v1/glossary/propose-terms` · `POST /glossary/terms/{id}/decide` | Claude proposes new candidate terms (name, kind, domain, definition, synonyms) for unmapped columns and metrics, de-duplicated against the glossary, as `proposed` rows with evidence links; accept (optionally with links) or reject them |
| `GET /api/v1/intents[/config]` · `POST /intents` · `POST /intents/jira` · `GET /intents/{id}[/files]` · `POST /intents/{id}/answer` | `/decide` | `/replan` | `/validate` · `POST /intents/sync` | intents: submit\| `/decide` \| `/replan` · `POST /intents/sync` | intents: submit a request (typed, pasted from Jira with its key, or read from Jira by key or URL; or pull them from Jira), read the structured intent, its review and the plan as workflow steps, the planner's spec and the generated files, answer the open questions, approve / reject / mark done, re-plan |

Both expose `GET /health/live`, `GET /health/ready` (checks Postgres + Neo4j), `GET /metrics`,
`GET /docs`. Errors share one envelope: `{"error": {"code", "message", "details", "request_id"}}`;
every response carries `X-Request-ID` and `X-Response-Time-ms`.

---

## Genie: ask the hub in plain language

`/genie` in the admin UI (API: `/api/v1/genie/*`) is a Databricks-Genie-style conversational interface
over everything the hub has indexed. A **space** curates scope and behaviour the way a Genie space
curates tables: retrieval filters (source systems, a repository attribute, explicit documents),
standing instructions appended to the system prompt, and sample questions shown on the empty screen.
Migration 0004 creates a default space covering everything.

Each question runs a short tool loop inside the query service and streams over SSE:

| Tool | What it does |
| --- | --- |
| `search_knowledge` | hybrid + graph retrieval scoped to the space; chunks come back labelled `[S#]` |
| `query_graph` | **read-only Cypher** against Neo4j: one statement, `MATCH`/`OPTIONAL MATCH`/`WITH`/`UNWIND`/`RETURN` only (no `CALL`, no writes, checked outside string literals), every `LIMIT` capped, 10 s timeout; the query is shown in the trace the way Genie shows its SQL |
| `find_documents` · `read_document` | list documents by title/path; read a whole document, chunks labelled `[S#]` |
| `get_lineage` · `explore_entity` | references between files; where an entity is mentioned, what it depends on, who contributed |
| `semantic_search` · `describe_asset` | the semantic layer: find tables/columns/metrics by name or meaning; a table's columns with roles, keys, joins, lineage and metrics, so SQL proposals use real names and the right dialect |

Answers cite inline with `[S#]` markers that resolve to the exact chunks the tools returned (only
cited sources are kept, invented markers are dropped), end with suggested follow-ups, and are
persisted with their trace (tool calls, Cypher, row counts, timings), token usage and thumbs
up/down. A conversation keeps its `[S#]` registry, so a follow-up question can cite an earlier
turn's sources. The model is the shared client in `backend/ech_core/llm` (first-party Claude API
or Databricks-hosted Claude, see the agent section below); `GET /api/v1/genie/status` says which
model is configured, or why none is, and the UI disables the composer accordingly.

```bash
curl -N -X POST localhost:8002/api/v1/genie/spaces/00000000-0000-4000-8000-000000000001/ask \
  -H 'content-type: application/json' \
  -d '{"question": "Which technologies does the knowledge base mention most, and where?"}'
```

---

## Admin UI: entry page, navigation and theme

`/` is the entry page (cream, editorial, with the animated "connected context" artwork): **Open Context Hub**
returns to the last workspace page, or Home. Every workspace route sits under the shell with a
collapsible sidebar (Data Economy logo from `frontend/public/brand/`, grouped sections: Start, Personas,
Data & semantics, Ingestion, Knowledge, each with its own accent colour on the icon tiles and
on the separators of the collapsed rail; a System widget with both service health dots and the Genie
model; and theme and **Sign out** controls, the latter returning to `/`).
The house theme is dark teal (tokens in `frontend/src/index.css`, fonts Inter / Space Grotesk / Instrument Serif
/ JetBrains Mono via Google Fonts); light mode is an explicit choice. The console is built for desktop
screens of any size rather than for phones: the root font size follows the viewport width
(`clamp(14px, 12px + 0.2083vw, 16px)`, so about 15px at 1440 and 16px from 1920 up) and every
rem-based size scales with it. Type stays light: headings in Space Grotesk and titles at medium (500),
small uppercase labels at medium with modest letter spacing, sidebar items regular with the active
one medium, and semibold kept for key numbers; stat, KPI, tile and card grids use `auto-fit` columns with a
minimum tile width (`.stat-grid`, `.kpi-grid`, `.tile-grid`, `.card-grid` in `index.css`) instead of
fixed breakpoints; two-pane sections sit side by side from 1024px; and the sidebar starts collapsed
below 1280px (a scaled-down laptop) until the user picks a width. Page heroes (`PageHero`, `HeroFlow`) and
stat tiles (`MetricCard`) carry the look across Home and the five persona workspaces. A page's main views
use `ViewSwitcher` (`components/layout/view-switcher.tsx`): large tinted tabs with an icon, a count and a hint on
Semantic Hub, Glossary and Knowledge Hub, and icon pills on the persona workspaces and Pipelines. Accent colours
come from `lib/tones.ts`, which also tints the `HeroStats` tiles and the `HeroFlow` targets. Icons are lucide-react
1.62; it no longer ships brand icons, so the GitHub and GitLab marks live in `components/icons/brand-icons.tsx`. The original
Overview dashboard at `/dashboard` was retired once Home and the workspaces covered everything on it:
the route now redirects to `/home`, and its latency, activity and source-breakdown charts live on in
`components/dashboard/` for the SRE, Data Engineer and Architect workspaces.

**Responsive shell.** Below 768px the sidebar becomes a drawer opened from a top bar (closes on navigation, Escape or the backdrop); from 768px to 1023px it is a collapsed icon rail whatever was stored for wide screens, so pages keep their width; from 1024px it follows the stored choice. Page grids use `grid-cols-1` at the base so wide tables scroll inside their cards instead of widening the page. The Semantic Hub Data catalog shows either the dataset list or the selected dataset below 1024px (with an All datasets button) and folds the scope rail behind a Scope toggle; the dataset panel scrolls as one with its Columns, Relationships, Metrics and Graph tabs pinned, so the column table is never squeezed out by the header.

**Semantic Hub visuals.** The page shares one palette per kind (facts green, dimensions blue,
reference data cyan, bridges amber, metric views red, unplaced grey; `components/semantic/visuals.tsx`)
across gradient kind tiles, segmented composition bars, ring gauges and count pills. The business model
opens with a *model overview*: dataset count and composition bar for the scope, three gauges (described,
named, placed), the Name with Claude action, and a clickable map of subject-area tiles that scrolls to the
area's section; each section carries its platform's accent line and dot, and fact-star cards start with a
kind tile. The scope rail shows platform tiles, catalog and schema rows with proportional bars, kind
filters as coloured chips and a column-role bar. The inventory lists datasets as cards (kind tile, type,
platform dot, summary, column/metric/link pills, name provenance) with an illustrated empty state, and the
detail opens with a kind-coloured header band, stat pills and a role composition bar above the columns.
The Semantic catalog view reuses the glossary's domain tiles for its tree and adds one hue and icon per
object type (`components/semantic/catalog-visuals.tsx`) for the count strips, type tiles, chips and the
quality bars (green from 75, amber from 50, red below).

## Connector catalogue

**Connectors** (`/connectors`, under Ingestion) is the catalogue of every source the hub can read or
plans to. The ingestion service keeps a static descriptor per connector in
`ingestion_service/connectors/catalog.py` (name, category, what it collects, whether it feeds the
semantic layer, documents or both, and the *names* of the settings it needs) and
`GET /api/v1/connectors/catalog` merges that with live state: which adapters are registered
(their settings are present), their health, last run and failures from the run history, and the
documents each source has contributed. The page shows **live connections** as cards with health
and check latency, documents, runs and failures this week, the last good run and the facts the last
health check saw (account, role, warehouse, catalogs, repositories), each with **Test**, **Edit**,
**Run** and **Browse schema** (the new-pipeline wizard on that connection). Below them is a compact
**library** of the other connectors, filterable by readiness and category; a tile opens what the
connector collects and the settings it needs. Each connector has a brand tile
(`components/connectors/brand-mark.tsx`).

**Editing and testing a connection.** Snowflake, Databricks, GitHub, Grafana and Jira connections open in a
side panel with their settings grouped (connection, scope, options), each marked as coming from
`.env`, saved in the hub or a default. **Test** checks the saved connection, or the unsaved edits
when there are any, by building a throwaway adapter and running its health check (Snowflake also
fails when the configured warehouse is unusable). **Save** stores the changed values in
`connector_settings` (migration `0016`), rebuilds the adapter and swaps it into the registry, so
the next run uses it without a restart; **Reset to .env** forgets them. The query service applies the
same saved connections (read through `ech_core/connections.py`, cached for ten seconds) to the SRE
workspace's live Grafana tab, the Architect integrations list, the Intents page's Snowflake
status and the intent service's Jira client. `/connectors?connect=<key>` opens a connection's editor directly. Credentials are write-only: the API returns only whether one is set and where from, and
stores them Fernet-encrypted with `ECH_SECRETS_KEY` or a key the first service to start generates
into `ECH_STATE_DIR` (the `ech-state` volume, mounted by both services).
Saves, resets and tests are audited by field name. API: `GET`/`PUT`/`DELETE
/api/v1/connectors/{name}/connection`, `POST /api/v1/connectors/{name}/test` (optional draft body).
Code: `ingestion_service/connectors/connections.py`, tests in `tests/test_connections.py`. The
catalogue itself never carries setting values. Today Databricks, Snowflake, GitHub, Grafana, Jira and the
manual ingestion API are connected, and PostgreSQL, Oracle, SQL Server, Trino, GitLab, Confluence,
SharePoint, dbt, Airflow, Tableau and Power BI are planned.

**Grafana.** `GRAFANA_URL` and `GRAFANA_TOKEN` (a service account with the Viewer role; both read
by name, never displayed) switch on two things. The **connector** (`ingestion_service/connectors/grafana.py`,
source system `grafana`, migration 0010) ingests one document per dashboard, listing its panels and the
queries they run plus the tables (from SQL `FROM`/`JOIN`) and metrics (from PromQL) they reference, and one
document per Grafana-managed alert rule with its condition, labels, annotations and current state; the
shared read-only client lives in `ech_core/grafana_client.py`. The **SRE workspace** gains an
*Observability* tab backed by `GET /api/v1/observability/grafana` on the query service: a live read of
the stack with firing and pending rules first, every dashboard with folder and tags (opening in Grafana),
all rules in a table, and how many Grafana documents the hub already holds. Without the settings the tab
explains what to set; with them but unreachable, it shows the error and a retry.

**Jira.** Connect it on the Connectors page (*Jira* card, or *Connect Jira* on the Intents page): site URL,
account email and an API token (created at id.atlassian.com; stored encrypted, never displayed), or
`JIRA_BASE_URL` / `JIRA_EMAIL` / `JIRA_API_TOKEN`. **Test** signs in (`/myself`) and counts the tickets the
intent JQL matches. One connection serves two things. The **intent service** follows it through
`ech_core.jira_client.JiraLink`, which rebuilds the client when the saved site, email or token changes, so a
save takes effect without a restart: reading a ticket by key or link, *Sync Jira*, the poll loop (idle until
Jira is connected) and the questions and plans posted back on the issue. Its *Intents* group sets the intent
JQL and the poll interval. Tickets are never imported on their own: the poll loop only follows the replies
(`/answer`, `/approve`, `/reject`, `/done`) on tickets already imported; a new ticket comes in when it is read by
key or link, pasted, or pulled with *Sync Jira*. The **connector** (`ingestion_service/connectors/jira.py`, source system `jira`,
migration `0020`) ingests the issues `jira_ingest_jql` matches (up to `jira_max_issues`, paged through the
enhanced search with the legacy search as fallback) as documents: summary, type, status, priority,
project, reporter, assignee, labels and description, with the people and project as graph entities.
Tests in `tests/test_jira.py`.

**The hub's own metrics in Grafana.** Both services export Prometheus metrics at `/metrics`. Because
Grafana Cloud cannot scrape a laptop, an opt-in **Grafana Alloy** container (`infra/alloy/config.alloy`,
compose profile `observability`) scrapes `ingestion-service:8001` and `query-service:8002` every 15 s,
drops the `*_created` series, and remote-writes the rest with basic auth to the stack's Prometheus
endpoint. Set `GRAFANA_CLOUD_PROM_URL`, `GRAFANA_CLOUD_PROM_USER` (the numeric instance id) and
`GRAFANA_CLOUD_PROM_TOKEN` (an access-policy token with `metrics:write`) from the stack's "Send
metrics" page, then `docker compose --profile observability up -d alloy`; compose refuses to start the
service while any of the three is missing, and Alloy's own UI is on port 12345. The dashboard that reads
those metrics is built in code (`ech_core/grafana_dashboard.py`, uid `ech-context-hub`: request rate,
error rate, p95 latency, 5xx by route, database pool, retrieval outcomes and stage p95, candidates,
embeddings, documents by connector, chunks, graph sync) and the Observability tab's **Provision
dashboard** button posts it to `/api/dashboards/db` through `POST /api/v1/observability/grafana/dashboard`,
creating or updating it by uid; that needs the Grafana token to have the Editor role. The tab then links
to it, and a test checks every panel query only names metrics the services actually export.

## Personas: five live workspaces and five previews

The sidebar's single **Personas** entry opens the hub at `/personas`: one card per workspace (five across, live
workspaces on the first row and previews on the second; two or one across on narrower screens, sized by
a container query so a collapsed sidebar counts), each marked Live or Sample data, with its
companion, discipline, three skill chips and two live numbers (assets and healthy connectors, governed
metrics and metric views, gates passing and the review backlog, platforms and subject areas, healthy
services and stalled runs; the preview workspaces show sample numbers marked "Sample data"), plus a "Start with a question" link that opens Genie. The banner holds the companion lineup (live
workspaces first): their eyes follow the pointer, the one under it perks up and says its name, and each opens its workspace. Inside a workspace the
banner carries a switcher with the other companions and an "All personas" link; the landing page's
"Open Context Hub" starts there. The entry page at `/` is the plain cream card; "Open Context Hub" lands on **Home** (`/home`, first in the
sidebar), a living overview: a hero stage (a slow teal
aurora behind the headline) with the system-at-a-glance panel (both services with their readiness
checks and versions, each connector with its last run, the Postgres size with documents and vectors,
the Neo4j node and edge counts, the Genie and embedding models, and the last catalog sync) and a
full-width band of counting-up live numbers (documents, assets, governed metrics, graph nodes,
conversations, runs; each cell opens the page that owns the number), a context-layer diagram (the
data sources with connector status, the four layers of meaning the hub keeps, each with live counts
and a live, partial or planned chip, the AI consumers, and a governance strip with the four
foundation statuses), a live section with a seven-day ingestion pulse chart beside the SSE event
feed and the audit log, and the ten personas with their companions. The page is fluid from laptop
to ultrawide: the band, the persona cards and the diagram columns use `auto-fit` grids and wrap
instead of truncating. The hero (headline, system at a glance and the six numbers) fills one screen
on desktop (the full width, and the window's height up to 56rem) from about 1440×800 up, including short
ultrawide windows: its columns follow the hero's own width
(container queries in `index.css`, so a collapsed sidebar counts), the headline scales with that width
and the window height, and the `short:` Tailwind variant (windows under 800px tall) tightens spacing. Each workspace is a route with bookmarkable sub-tabs, and
each asks Genie through its own space (migrations 0006, 0009 and 0019 seed them with persona-specific
instructions and sample questions; `GET /api/v1/genie/spaces` returns `persona`). The scorecards
(Data Engineer goals, QA quality gates, SRE SLOs) share one target table: `ECH_KPI_TARGET_*`.

**Persona profiles.** Every persona Overview opens on a profile (`components/personas/persona-profile.tsx`,
content in `lib/persona-profiles.ts`): the role and what the persona owns, **goals** bound to live KPIs
with their target, verdict and a bar against the target, a typical day, pain points, sample Genie
questions (a click opens Ask Genie and asks it), hand-offs to the other personas and links to the
tools they use. Each goal names a KPI key and its report (`engineering`, `quality`, `platform` or
`analyst`), and the profile fetches only the reports its goals need. The Business Analyst is scored on
the analyst's own work, not catalog hygiene (that sits with the Data Engineer, Architect, QA and the
Data Steward): `GET /api/v1/stats/analyst?days=7` reports questions answered self-serve in the
analyst's Genie space (complete and not thumbs-down), the median hours from an intent arriving to an
approve/reject decision, intents waiting in `clarifying`, and the share of metrics on curated layers
that are declared (raw schemas such as BRONZE, RAW or STAGING are left out, so a bronze-only catalog
reads "no data", not "off target"). Rate and latency KPIs get a trend: the last 7 days
against the last 30 (24 hours against 7 days for SRE), marked better or worse from the KPI's
direction. Catalog coverage and other point-in-time KPIs are marked "snapshot", because the hub does
not keep their history. Below the profile the Overview keeps only tiles with something in them; a
count of zero is hidden. The Data Engineer's old KPIs tab now sits under its goals as "Show all KPIs"
(every group plus the active targets), and its runs-per-day chart and connector freshness moved to the
Pipelines tab; `/engineer/kpis` falls back to the Overview.

**Ask Genie and the companions.** Every persona's Ask Genie tab opens on a welcome panel: the
persona's companion (`components/personas/companion.tsx`, an SVG creature whose eyes follow the
pointer and who blinks, perks up while you type, sways while Genie thinks, bounces when an answer
lands, sulks on an error and sleeps when no model is configured; click it to make it wave and
offer a tip), what Genie does for that persona, live context counts (assets, facts, dimensions,
governed metrics, documents, graph nodes), the tools it reaches for, and the sample questions as
cards. During a conversation the companion docks beside the thread and narrates the steps
("Searching the semantic layer…", "Writing it up…", "Done — 4 sources cited."). The companions
are Bolt (Data Engineer), Pip (Business Analyst), Scout (QA Engineer), Atlas (Architect) and
Pager (SRE), Ship (DevOps), Aegis (DevSecOps), Ledger (Data Steward), Sigma (Data Scientist) and Warden
(Compliance & Risk); their names, colours, capabilities and tips live in `lib/persona-genie.ts`. The
Genie page shows the same welcome panel whenever a persona space is selected. On the Genie page itself the space
rail shows each persona space with its companion and accent, the default space opens on a welcome
panel with Genie's own companion and live context counts, answers are cards with a header (who
answered, model, latency, sources, steps), citations are chips that light up when their marker is
clicked, and the banner carries live counts of spaces, conversations, documents and assets.

| Persona | Route | Tabs |
| --- | --- | --- |
| Data Engineer | `/engineer/{overview,pipelines,health,lineage,ask}` | profile with six goals and "Show all KPIs" (pipeline reliability, graph consistency, catalog coverage, freshness; each KPI with a target and an on-target / watch / off-target verdict, plus the active targets), sync and run status, connectors with run triggers, runs per day and connector freshness, catalog health (coverage per schema, undocumented, unowned, keyless facts, isolated assets, inferred joins ranked by confidence), two-hop lineage graph per asset, Genie answering with keys, joins, lineage and SQL |
| Business Analyst | `/analyst/{overview,metrics,glossary,domains,ask}` | a profile scored on self-serve answers, request turnaround and certified report metrics; governed metric counts, metrics catalog (declared first, searchable, break-down dimensions, dataset links), business glossary (every column name across datasets with role, types and best description), domains per database and schema with a link into the Semantic Hub, Genie answering in business language |
| QA Engineer | `/qa/{overview,gates,failures,review,ask}` | gates passing count, **quality gates** in four groups (ingestion: run success, document failure rate, graph failures/pending; catalog integrity: unclassified assets, keyed facts, connected assets, declared joins; semantic review: suggestions awaiting review, described assets/columns, declared metrics; serving: request error rate, retrieval p95, Genie error rate) each with a target and verdict; **failures** (failed runs with the connector's error, documents that failed graph sync, audited request errors); **review queue** (Claude suggestions least confident first with the proposed kind change, inferred joins to confirm); Genie proposing checks as SQL assertions |
| Architect | `/architect/{overview,landscape,model,integrations,ask}` | platforms, subject areas, fact stars, conformed dimensions, governed metrics; **landscape** (per-platform catalogs/schemas/kinds, every subject area, document sources, graph composition, column roles, cross-platform lineage); **business model** (conformed dimensions joined from two or more facts, then the full subject-area / fact-star view); **integrations** (every source, store, model, export, API and assistant with configured / available / missing and a link); Genie answering on domains, trade-offs and target structures |
| SRE | `/sre/{overview,services,slos,capacity,ask}` | both services' readiness with dependency checks, retrieval p95, **error budget** (errors allowed by the target error rate versus errors seen), active/stalled runs, graph pending/failed; **services** (readiness cards, in-memory latency chart, audited calls per action with p50/p95/p99 and error rate); **SLOs** (serving, pipelines, freshness with targets; the budget bar); **capacity** (database size, vectors and their memory estimate, graph size, audit growth, storage per table, graph reconciliation button, runs per day); Genie answering runbook-style |
| DevOps (sample) | `/devops/{overview,deployments,delivery,environments,ask}` | DORA KPIs (deployment frequency, lead time, change failure rate, time to restore); deployments per day by environment, recent deployments, incidents and rollbacks; pipeline duration per stage and CI pipelines by repository; environment cards |
| DevSecOps (sample) | `/devsecops/{overview,vulnerabilities,secrets,supply,ask}` | open vulnerabilities by severity over 8 weeks, findings by source, top vulnerabilities with fixes; secret scanning (locations only, never values); supply-chain policy meters and service-account rotation |
| Data Steward (live + sample) | `/steward/{overview,stewardship,ownership,ask}` | live review queue, tables placed and terms in use; review decisions per day, documentation by business area, stewardship tasks; owner coverage and data contracts |
| Data Scientist (sample) | `/science/{overview,models,features,ask}` | models in production, AUC over 8 weeks, model registry with the governed tables each learns from; feature importance, feature store with source columns, input drift against the alert threshold |
| Compliance & Risk (sample) | `/compliance/{overview,controls,privacy,filings,ask}` | control testing, controls with framework and owner, retention and audit meters; personal data by schema and personal-data columns; regulatory calendar (Solvency II, SOX, IFRS 17, GDPR) |

**Preview workspaces.** DevOps, DevSecOps, Data Steward, Data Scientist and Compliance & Risk need
sources the hub does not ingest yet (CI/CD and deployments, security scanners, a workflow tool for
stewardship tasks, a model registry and feature store, a GRC tool). Until then they render
`components/personas/sample-workspace.tsx` from `lib/persona-samples.ts`: a banner naming what to
connect, four KPI cards, and charts, tables, status cards, timelines and meters, each tagged
**Sample**. The Data Steward's review queue, tables placed and terms in use are read live and tagged
**Live**. Routes come from `Persona.preview` in `lib/personas.ts` (`pages/sample-persona-page.tsx`).
Their Ask Genie tabs run on the live hub through their own spaces (migration 0019), whose instructions
tell Genie to say so when a question needs a source that is not connected.

## Semantic layer: Snowflake and Databricks metadata as a governed model

The hub treats the **semantic layer** as a structured part of the context layer. The context layer is
everything an agent can retrieve (documents, chunks, entities, lineage); the semantic layer is the
governed business model of the data assets inside it: what each table is, what its columns mean, how
tables join, which metrics are defined over them. Connectors read the metadata where it already
lives, the pipeline turns every asset into a document (so it is chunked, embedded and graphed like
anything else) **and** into typed rows that the API, Genie and the exports read directly.

| Connector | Source of truth | What it reads |
| --- | --- | --- |
| `databricks` | Unity Catalog REST API (`/api/2.1/unity-catalog/*`, lineage tracking) | catalogs → schemas → tables, views, materialized/streaming tables, **metric views** (YAML parsed into declared dimensions, measures, joins), primary/foreign key constraints, owners, comments, tags, properties, table lineage; view SQL is parsed for upstream tables |
| `snowflake` | SQL REST API (`/api/v2/statements`, PAT / OAuth / key-pair JWT) | `INFORMATION_SCHEMA` tables, views, columns, `SHOW PRIMARY KEYS` / `IMPORTED KEYS`, **semantic views** (`SHOW/DESCRIBE SEMANTIC VIEW`), optional `ACCOUNT_USAGE` tag references and object dependencies when granted |

For every asset the hub stores (migration 0005, `semantic_*` tables):

* **Asset** — platform, fully qualified name, type, inferred *kind* (fact, dimension, bridge, metric,
  reference), description, owner, tags, properties, definition SQL/YAML, row count, timestamps, URI
  back to the platform.
* **Fields** — data type, nullability, keys, partition flag, a *role* (identifier, dimension, time,
  measure, attribute) with a confidence: `1.0` when declared by a constraint or a metric/semantic
  view, lower when inferred from name and type cues; measures carry a default aggregation.
* **Relationships** — foreign keys, declared joins, inferred joins (shared primary key, dimension
  base name, shared identifier; each with confidence and evidence), lineage upstream/downstream,
  metric → source table. Inferred joins are recomputed after every run across all ingested assets.
* **Metrics** — declared (metric views, semantic views) or inferred (`total_*`, `average_*`,
  `record_count` on facts) with expression, aggregation, dimensions and synonyms.

**Business names and meanings.** Every asset, column and metric carries a `display_name` and the
asset a one-line `summary` next to its technical name. Derived names come from naming rules
(`fact_claim_payment_v1` → "Claim Payment", `cust_acct_id` → "Customer Account ID"), the summary from the
first sentence of the catalog comment or from what the columns say. `name_source` / `kind_source` record
where a name or classification came from (`derived`, `declared`, `model`, `curated`); a sync never
overwrites model or curated values. Assets whose name says nothing are classified from their columns
(measures + time → fact, keys + attributes → dimension, two keys → bridge, small code/name lists → reference).

**Model-assisted enrichment.** `POST /api/v1/semantic/enrich` (a scope, `only_undocumented` by default) or
`POST /semantic/assets/{id}/enrich` asks the configured Claude model for a business name, meaning, kind and
up to five metrics with SQL expressions over the real columns. Proposals are stored as suggestions with
provenance and confidence; `POST /semantic/assets/{id}/enrichment` accepts them (optionally edited, which
records `curated`) or rejects them. Accepted metrics are `curated` and survive re-syncs.

**Business model.** `GET /api/v1/semantic/business-model` groups a scope into subject areas with fact stars
(measures, time columns, joined dimensions with confidence, metrics), governed metric views and dimensions.
The Semantic Hub page offers this view next to the Semantic catalog and the Data catalog (the inventory
table); each fact is drawn as a star with its dimensions, coverage rings show described and named shares,
and "Name with Claude" runs the enrichment over the scope with live progress. The asset detail shows the
suggestion with accept/reject.

**Semantic catalog.** `GET /api/v1/semantic/catalog` and `/semantic/catalog/objects` read the same rows
as business objects, the way a semantic catalog presents them rather than the way a platform stores them:
one *entity* per dataset (fact, dimension, reference, bridge, metric view), a *dimension* per dimension or
time column, a *measure* per measure column, a *metric* per declared, curated or inferred metric and per
glossary KPI, a *relationship* per key, join or lineage edge, and *hierarchies* inferred from column
patterns on one dataset (calendar, geography, product and parent-child keys; Snowflake and Databricks
declare none, and the view says so). Every object is placed in a glossary domain: through its own
accepted term link, its dataset's domain, or the plurality of its columns' terms when the dataset has
none, so accepting glossary links moves objects into domains (on 2026-10-26: 89 of 96 datasets placed
against 39 with an explicit domain). Each object carries a quality score, the share of the checks that
apply to its type (described, business name, owner, keys, connected, classified, term-linked and placed
for entities; typed and role-confident for columns; governed and dimensions listed for metrics;
confidence, resolved target and join columns or evidence for relationships). The Semantic Hub page
opens on this view as a tree-and-table explorer (`frontend/src/components/semantic/explorer/`), the business
view; tables and views belong to the Data catalog view, and a row opens its dataset there. The tree is the
**Semantic Catalog** grouped by business domain (domain → sub-domain → model → entities, dimensions,
measures, metrics, relationships, hierarchies, with counts and a mean-quality dot; *Unassigned* holds what
no accepted term places, empty domains hide behind a toggle), by line of business, or by source
(database → schema → type, plus glossary KPIs bound to no dataset). An early version also had a Data
Catalog root; its links (`root=data&db=&schema=`) now open the Data catalog view on that scope. The right side has
a plain-language heading ("43 tables" and what the view is), a bar that picks what to list (Tables by default, then
dimensions, measures, metrics, links, hierarchies or all; the tree picks where and keeps the choice), a banner
while fewer than half the tables have a business area that links to the pending glossary suggestions,
"KPI from the glossary" on KPI definitions, empty lists that point to what the place does hold,
breadcrumbs, a search box, a Filters menu (line of business, owner, minimum quality), a column chooser, a list/grid
toggle and server-side sorting on every column (`sort`, `order`), paged by 50. Every node, filter, sort and
page lives in the URL (`?view=catalog&by=&domain=&db=&model=&type=&lob=&q=&owner=&minq=&sort=&order=&offset=`),
so any view can be linked; layout, columns and the tree's open state are per-browser preferences. The
catalog API carries what the tree needs: `sources` (objects per model) and `domain_models` (objects placed
directly in a domain, per model), and `/semantic/catalog/objects` takes `direct` (this domain only),
`database`, `sort` and `order`. A row opens its dataset in the Data catalog view (a KPI opens the glossary). The catalog is rebuilt on every request
(about 40 ms for 1,300 objects) and stored nowhere; `backend/query_service/services/catalog_service.py`
holds the projection and `tests/test_catalog.py` covers placement, typing, hierarchy inference, quality
and the filters.

**Line of business.** A facet, not a level above the domains: the domains are capability areas every line
shares, and in the Snowflake warehouse line of business is a column (`PRODUCT.LINE_OF_BUSINESS` holds LIFE or
ANNUITY), so most tables hold both lines. The values belong to the glossary's Line of Business term
(`semantic_term_values`, migration 0018: Life and Annuity, with aliases). After every Snowflake or Databricks
sync the ingestion service decides, per dataset, which lines it holds; the first source that answers wins:
a Snowflake tag such as `LINE_OF_BUSINESS=ANNUITY` on the table or a column, then the default of the most
specific pipeline whose scope covers it (`pipelines.line_of_business`, set in the wizard's Details step,
validated against the term's values), then one `SELECT DISTINCT` on a line-of-business column (named like
the term or linked to it by an accepted glossary link; Snowflake only, through `distinct_values` on the
connector), and last inheritance along foreign keys, declared joins and upstream lineage, nearest first
(CLAIMS.CLAIM inherits via POLICY.POLICY → PRODUCT.PRODUCT_VERSION → PRODUCT.PRODUCT). Inferred joins are not
followed. A dataset none of these reach is shared across lines. Results are stored with their evidence in
`semantic_asset_lines` and summarised in the run log; the first live run found 3 tables by column values,
18 by inheritance and 22 shared. The catalog carries `lines` and `lines_note` on every object and per-line
counts by top-level domain; the explorer groups by line (line → domain → type), filters by line in the other
groupings (`lob=` in the URL, kept while browsing the tree) and shows a Line of business column. Inheritance
gives a table the union of what it references, so a table that holds one line only (POLICY.ANNUITY_ACCOUNT)
needs a tag to say so.

**Business glossary and insurance domain layer.** Migration `0011_glossary_domains_kpis.sql` seeds a curated
vocabulary rather than deriving one from the data: 22 domains two levels deep following the ACORD
capability areas (Party & Customer, Product & Coverage, Distribution, Underwriting, Policy Administration
with lifecycle events and the in-force portfolio, Billing, Claims with intake / adjudication / reserves,
Reinsurance, Actuarial with valuation and experience studies, Finance, Customer Service, Risk & Compliance
and a Data Platform bucket for technical columns), about 90 canonical terms with definitions and synonyms
(policy, policyholder, insured, coverage, rider, premium, annualized premium, lapse, surrender, claim,
claim reserve, cession, retention, exposure, A/E ratio, persistency, earned premium, loss ratio …), each
tagged `acord`, `fibo` (party, contract, currency and monetary amount) or `hub` with a `standard_ref`, and
18 KPI definitions with grain, period, unit, direction, target and warning thresholds (loss, combined and
expense ratio, lapse rate, 13-month persistency, mortality A/E, claim settlement days, frequency,
severity, new-business APE, in-force count, premium growth, surrender, renewal, commission ratio,
quote-to-bind, reserve adequacy, arrears rate). ACORD's models are member-only and FIBO is not ingested,
so the references are pointers, not imports. What is dynamic is the mapping: `POST /api/v1/glossary/map`
runs name and synonym rules over datasets, columns and metrics (prefixes such as `dim_` or `total_` and
identifier suffixes are understood), then shows Claude the whole glossary and one dataset at a time to
propose terms per dataset, column and metric (the domain Claude names is context for choosing coherent
terms; a dataset is placed in a domain when one of its dataset-level terms is accepted). On the live
catalog the first run took two minutes for 96 datasets: 356 rule proposals and 325 from Claude, 680 to
review. Every proposal is a `semantic_term_links`
row with confidence and provenance (`rule` | `model` | `curated`) and nothing applies until it is accepted:
accepting copies the term's synonyms onto the column or metric (`synonyms` JSONB, so search and Genie
find business words), gives the dataset its domain (`semantic_assets.domain_key`) and binds a KPI that
waits on that term to the accepted metric. Column and metric rows are now upserted by name on every
catalog sync so their ids, links and synonyms survive. The review queue opens grouped by column: one row per target name and proposed term across every table
(`GET /api/v1/glossary/links/groups`, biggest groups first), with Accept all and Reject all for the group
(`POST /api/v1/glossary/links/decide-many`, each link decided as if alone, so synonyms and domains apply) and
the tables underneath for exceptions; on the live queue 285 suggestions became 186 decisions, led by
AS_OF_DATE → Valuation Date in 26 tables. "By table" keeps the per-dataset view. Mapping also runs on its own after every successful
Snowflake or Databricks sync (`ECH_GLOSSARY_AUTO_MAP`, on by default): the query service picks up completed
runs from `ingestion_runs` every `ECH_GLOSSARY_AUTO_MAP_SECONDS` (30) and maps their source system once,
however many syncs finished in between. The name rules look at every dataset; Claude sees only datasets whose
source metadata (name, description, columns with types and descriptions, metrics with expressions) changed
since it last mapped them, tracked as a hash in `glossary_map_state` (migration 0017). Review decisions such
as accepted synonyms, display names or domains do not count as changes, rejected links are never reopened,
and a dataset whose Claude call failed is retried on the next sync. Each pass is recorded in
`glossary_auto_runs` (`GET /api/v1/glossary/auto-map`) and summarised on the Glossary page. Syncs that
finished before the migration are not mapped retroactively. `/glossary` in the admin UI has a domain rail with
counts, a coverage band (placed datasets, columns and metrics with terms, synonyms, KPIs bound, link
states) and three tabs: term cards with a create/edit dialog that also lists where a term is used, KPI
cards with an editor that binds a governed metric, and the review queue grouped by dataset with
accept / reject and "accept all at 85 %+". Dataset details show the terms and domain they carry.

**The vocabulary grows from the data too.** `POST /api/v1/glossary/propose-terms` (the "Propose new terms"
button) takes every column and metric in the scope that no term covers or awaits, batches them by dataset
(about 24 rows per call; a batch that times out at the gateway or comes back as cut-off JSON is halved and
retried, two levels deep) and shows Claude the existing term names, the domains and those rows. Claude
answers with candidate terms: a Title Case name, kind, domain, a one-sentence definition, synonyms and the
columns and metrics each one covers, with confidence and rationale. Answers are validated against the batch
(unknown columns, domains and kinds are dropped) and de-duplicated against the glossary: a proposal whose
name or synonyms already name an existing term becomes pending links to that term instead. New terms land
as `status = 'proposed'` rows (migration `0012_glossary_proposed_terms.sql`, with `proposed_by` and
`rationale`) and are kept out of the Terms tab, the name rules and the mapping prompt until reviewed. The
review queue shows them first, each with its evidence links: accept with links adds the term and applies
every link, accept the term alone leaves its links in the queue, reject deletes the term and its links
(`POST /glossary/terms/{id}/decide`). On the live catalog the first two runs proposed 193 candidate terms
with 413 evidence links from 637 unmapped columns and 106 unmapped metrics; a third of them describe the
hub's own governance tables and sit in the Data Platform bucket, the rest are insurance vocabulary the seed
lacked (issue age, paid-to date, beneficiary share, PEP status, commission chargeback, reserve factor …).

`/semantic` in the admin UI browses it by platform → database → schema with kind filters, search,
an asset detail (columns, relationships, metrics, graph, definition) and one-click export. The export
API renders the same model as a **Snowflake Cortex Analyst** semantic model (YAML with tables,
dimensions, time dimensions, facts, metrics, relationships), as **Databricks metric views** (one
`version: 0.1` spec per fact with joins, dimensions and measures) or as hub JSON, so the governed model
round-trips to the platforms instead of living only in the hub.

## Pipelines: saved, scheduled ingestion on a connection

A **connection** is a connector with the credentials configured on the server (GitHub, Databricks Unity
Catalog, Snowflake, Grafana). A **pipeline** is a saved definition on top of one: what to read from it,
how a run behaves and when it runs. Pipelines never hold credentials; the connection does.

**Create one in the UI** (**Pipelines → New pipeline**, five steps):
1. *Connection*: the healthy connections, each with its document count and the levels of its hierarchy.
2. *Source*: a live schema browser. It queries the connection as you open it (Snowflake `SHOW DATABASES`
   and `INFORMATION_SCHEMA`, Unity Catalog REST, the git tree of a repository, the dashboard folders of
   Grafana), so every database, catalog, schema, table and column the credential can see is listed, not
   only the ones in the server configuration. Tick a level to include everything below it (tri-state
   ticks, a filter box on each long list, columns with their types under every table). A debounced
   preview asks the connection how many documents the selection would read. Nothing ticked means the
   whole connection.
3. *Details*: name (unique), description, owner, tags; full refresh, document limit and chunk sizes; the
   switches the connection honours: lineage (Databricks, Snowflake), tags (Snowflake), alert rules
   (Grafana), file extensions and skipped paths (GitHub). Each switch is default, on or off, so a
   pipeline only overrides what you set.
4. *Schedule*: on demand, repeat (15 minutes to a week), daily or weekly at a time in UTC, with the next
   runs shown in your local time, a switch to keep the schedule but pause it, and an option to start a
   first run on save.
5. *Review*: everything in one place, with links back to each step.

**On the page**: pipeline cards (scope, schedule and next run, last run and its counters, run, pause or
resume the schedule, edit, delete), a source filter and search, a *Run history* tab (every run, with
the pipeline it belongs to or *Ad hoc run*, the counters and the live event log), and a strip of the
connections to start a pipeline on or to run a whole connection once without a pipeline. A pipeline
page shows its source, schedule, options, last run and its own run history.

**How it works**: migration `0014_pipelines.sql` adds `pipelines` (scope, options, source options and
schedule as JSONB) and `ingestion_runs.pipeline_id`. A scope is a list of paths in the hierarchy of the
source: `[database, schema, table]`, `[repo, folder, ...]`, `[grafana folder, dashboard]`. Running a
pipeline builds an ordinary run request carrying the scope and options, so pause, cancel, events and
statistics are unchanged; deleting a pipeline keeps its runs. Each connector turns the scope into a
narrower read: Snowflake adds `TABLE_SCHEMA` and `TABLE_NAME` filters to its `INFORMATION_SCHEMA` queries,
Unity Catalog lists only the selected schemas and tables, GitHub keeps the files under the selected
folders, Grafana the selected folders and dashboards (alert rules only with their node). The scheduler is a
loop in the ingestion service (`ECH_PIPELINE_SCHEDULER_INTERVAL_SECONDS`, 30 by default): it starts each
enabled pipeline whose `next_run_at` has passed, books the following run, and retries a minute later
when the connection is busy. Schedules are UTC; there is no cron expression yet. Code:
`ingestion_service/services/pipeline_definitions.py`, `ingestion_service/connectors/scope.py`, `discover`
on each connector, `ech_core/schedule.py`, and `frontend/src/components/pipelines/`.

## Reference agent: intent → pipeline change

`backend/pipeline_agent` is a small Claude tool-loop agent that shows how an orchestrator consumes
the hub. Give it an intent and a repository the hub has crawled; it grounds itself through
`retrieve_context` / `get_lineage`, reads the exemplar files from a local checkout, writes the new
artifacts in the repository's own conventions, runs the repository's tests in a sandboxed virtualenv
and finishes with a manifest, citations and next steps.

```bash
cd backend && pip install -e ".[agent]"            # adds the anthropic SDK

# Claude API (first party)
export ANTHROPIC_API_KEY=...                        # or `ant auth login`
python -m pipeline_agent "Add a gold fact table fact_claims_aging (agreement grain, age buckets)" \
    --repo chidha2019/omniclaim-lakehouse-pipelines \
    --workspace ./workspace/omniclaim-lakehouse-pipelines \
    --effort high --max-turns 30 --publish

# Claude served by Databricks (Mosaic AI Gateway, Anthropic Messages API)
export DATABRICKS_HOST=https://adb-<id>.azuredatabricks.net   # workspace host
export DATABRICKS_TOKEN=...                                   # personal access token
python -m pipeline_agent "<intent>" --repo owner/name --provider databricks   # model: system.ai.claude-opus-5-5
# or keep both out of shell history: the two KEY=VALUE lines in backend/.env.agent (gitignored), then
python -m pipeline_agent "<intent>" --repo owner/name --env-file .env.agent
```

`--provider` defaults to `auto`: `DATABRICKS_HOST` plus `DATABRICKS_TOKEN`, or a Databricks
`ANTHROPIC_BASE_URL`, selects the `databricks` profile; anything else the first-party API. The Databricks
profile only ever sends `DATABRICKS_TOKEN` (an inherited `ANTHROPIC_AUTH_TOKEN` stays with api.anthropic.com)
and calls `https://<host>/ai-gateway/anthropic/v1/messages` with it as a Bearer header (use
`--base-url https://<host>/serving-endpoints/anthropic --model databricks-claude-opus-5-5` for the older
pay-per-token route), stays on the GA `messages` namespace (no server-side fallbacks, no eager input
streaming), and when the gateway rejects an optional field (`strict`, `cache_control`, `output_config`)
with a 400 it drops that field, logs it to stderr and retries. Cost estimates use first-party list prices
only, so they are omitted for gateway models.

| Tool | Backed by |
| --- | --- |
| `retrieve_context`, `search_documents`, `get_lineage` | query service (`/context/retrieve`, `/documents`, `/documents/{id}/lineage`) |
| `get_document`, `list_files`, `write_file` | the workspace checkout (path-traversal guarded; writes tracked) |
| `run_command` | allow-listed `pytest` / `ruff` / `pip install -r <file>` in `.agent-venv` inside the workspace |
| `finish` | ends the run with summary, files, `tests_passed`, next steps, confidence |

Model defaults follow the current API: `claude-opus-5-5`, adaptive thinking with explicit
`output_config.effort`, streamed responses, strict tool schemas with eager input streaming (validated
client-side), server-side refusal fallbacks (`--no-fallbacks` to disable), full content blocks echoed
back each turn. Every turn is logged to `<workspace>/.agent/transcript.jsonl`; `--publish` ingests the
written files back into the hub so the next agent can retrieve them.

## Intents: Jira ticket → spec → approval → generated pipeline

The intent service (`backend/query_service/intents/`, migration `0013_intents.sql`, page `/intents`) puts the
intelligence in front of the coder. A request arrives from Jira (tickets matching `ECH_JIRA_INTENT_JQL`, pulled
with *Sync Jira* through `JIRA_BASE_URL` / `JIRA_EMAIL` / `JIRA_API_TOKEN`; replies on imported tickets are
followed every `ECH_JIRA_POLL_SECONDS`, and nothing is imported on its own), from a Jira key
or link given on the Intents page (`POST /intents/jira`, read once: the same key returns the same intent), or
pasted into the page (summary, description and optionally the key), and moves through one state machine.

The page leads with that intake and walks every ticket through **Read → Review → Plan → Approve → Generate →
Ship → Done**. *Read* shows what Claude took from the ticket (source → target, grain, freshness, owner, load
mode, business terms and the **acceptance criteria**, which the parser now extracts, from an "Acceptance
criteria" list by rule when no model is configured). *Review* (`intents/review.py`, derived on every read) is a
scored checklist (goal, source files, file format, target table, Iceberg storage, load mode, grain, freshness,
owner, business meaning, acceptance criteria, open questions): blocking checks weigh double, and the verdict is
*needs answers* while one blocks, *ready* from 75 and *thin* below; once planned, location and storage are
judged by the plan. *Plan* (`intents/workflow.py`) lays the spec out as the steps the pipeline runs (read the
files, land in S3, stage and file format, create the Iceberg table, copy or merge, validate, schedule, govern,
feed downstream), each with metrics, items and a *needs attention* note where the plan falls back to a default.

**The semantic layer shapes the plan** (`intents/catalog.py`). The planner looks for the catalog table the new
feed resembles: candidates are the tables and views the semantic search finds for the target name, the business
terms and the feed's identifier columns, scored by the share of the feed's columns they hold (at least three
and 40%; base tables before views, since only tables declare keys and joins). From the match it takes:
- **column types** where the files agree (`FACE_AMOUNT NUMBER(18,0)` from the sample becomes the catalog's
  `NUMBER(18,2)`; Databricks names are written the Snowflake way; text keeps the size sampled from the files),
  reporting a conflict instead when the files disagree;
- **the declared primary key** when the feed carries it, for the uniqueness test and the default merge key
  (ticket keys first, then the repo-graph exemplar's key, then the catalog's, then an identifier-like guess), or
  a risk when it does not ("POLICY is keyed on POLICY_ID, which these files do not carry; rows match it on
  POLICY_NUMBER instead");
- **joins**: shared identifiers to the matched table, plus the foreign keys and declared or inferred joins it
  has on columns the feed carries.
A target that already exists in the catalog, or a near-identical column set (Jaccard ≥ 0.8), is flagged as a
possible duplicate: a risk, a *Not a duplicate* warning in the review and an attention note on the new **Relate**
workflow step. The spec shows the match (with its coverage, key and the types it lent), the joins and each
column's catalog type.

1. **Parse.** Rules read what the text states outright (a folder or `s3://` location, `DATABASE.SCHEMA.TABLE`,
   `external volume X`, merge / full refresh, the cadence); Claude fills in the rest using the glossary term
   names and lists open questions. Anything still missing is posted back as a comment ("Before I can plan
   this I need to know: …") and the intent waits in `clarifying` until a `/answer …` reply or the form.
2. **Plan.** The planner samples the CSV folder (under `./data`, mounted into the query service): headers
   become `UPPER_SNAKE` identifiers, values become Snowflake types (`NUMBER(18,2)`, `DATE`, `TIMESTAMP_NTZ`,
   `BOOLEAN`, sized `VARCHAR`), nullability comes from the rows seen, glossary terms attach to columns by name
   and synonym, related datasets come from the semantic layer, and tests (file count, row count, not null,
   per-file uniqueness of the key, freshness), the stage and file-format names, the base location and a cron
   schedule are laid out. The result is a one-page spec, posted to the ticket and shown on the page.
3. **Gate.** A person approves (`/approve`, or the button), rejects, or answers to change the spec. Nothing is
   generated before that.
4. **Code.** For `ingest_csv_to_iceberg` a deterministic template renders the pipeline into
   `./pipelines/<name>/`: `sql/010_setup.sql` (file format, external stage on the S3 landing prefix with a
   storage integration), `sql/020_table.sql` (`CREATE ICEBERG TABLE … CATALOG = 'SNOWFLAKE' EXTERNAL_VOLUME …
   BASE_LOCATION …` with `_SOURCE_FILE` and `_LOADED_AT`), `sql/030_load.sql` (`COPY INTO` with typed `$n`
   casts and `METADATA$FILENAME`; append, truncate-and-load, or staging table plus `MERGE`). The merge
   staging table is re-created each run, so every staged file is read again; it also loads
   `METADATA$FILE_LAST_MODIFIED` and `METADATA$FILE_ROW_NUMBER`, and the `MERGE` source keeps one row per key
   (newest file, then the later file name, then the later row), so a key repeated across files neither
   duplicates nor fails the merge, and the merge uniqueness check covers the whole table.
   `sql/040_checks.sql`, `sql/050_task.sql` (a Snowflake task on the cron; a load of several statements runs
   as one `EXECUTE IMMEDIATE $$ BEGIN … END; $$` block, which the runner keeps whole), `pipeline.py` (`plan`, `upload`
   to S3 with boto3, `apply`, `load`, `schedule` over the Snowflake SQL REST API, placeholders from the
   environment), offline `tests/`, a README and the spec. The service runs those tests before handing over and
   records the result, the branch name and the file list; the ticket gets a "Pipeline generated" comment and
   `/done` closes it. Other kinds get the spec and a README for the reference agent (`ECH_INTENT_REPO`) or a
   person.

The generated pipeline needs `SNOWFLAKE_HOST`, `SNOWFLAKE_TOKEN`, `SNOWFLAKE_WAREHOUSE`, `S3_BUCKET`,
`S3_PREFIX`, `STORAGE_INTEGRATION` and `ECH_EXTERNAL_VOLUME` (plus AWS credentials for the upload) at run time;
`python pipeline.py plan` renders every statement without connecting. A sample folder, `data/policies_sample`,
drives the example intent on the page.

5. **Run (human in the loop).** With `ECH_INTENT_RUN_ENABLED` (on in compose) approval is the gate: *Approve and
   run* generates the pipeline, runs its offline tests and then has the hub run it (`intents/runner.py`, status
   `running` → `loaded`, migration `0022_intent_runs.sql`): a preflight names any runtime setting still missing,
   then the generated runner's own `upload`, `apply` and `load` (checks included), then a Snowflake sync of the
   target schema through the ingestion service so the tables reach the catalog. The pipeline's settings reach it
   only as `ECH_RUN_<NAME>` (compose maps `SNOWFLAKE_*`, `AZURE_*`, `STORAGE_INTEGRATION` and `ECH_EXTERNAL_VOLUME`
   from `.env`); the hub's own credentials never go with them, secret values are masked in every stored log, and an
   admin role is flagged. The *Run* tab shows each step, its output and the checks; *Run again* retries, and a
   person marks the intent done. A failed run leaves the intent `failed` with the step that stopped it.

A ticket can name its tables with a pattern (`<FILE>_ICEBERG`: `claimStatus.csv` → `CLAIMSTATUS_ICEBERG`), an
existing stage to load through (the setup then creates none and needs no integration name) and a file format; a
file whose first column is its own id (`branch_id` in `branch.csv`) needs no identifier question. Loading into
tables that already exist takes their column names (`HOUSE_NR_ID` → `HOUSENR_ID`), and the plan warns when they
lack the load columns (`_SOURCE_FILE`, `_LOADED_AT`) or already hold rows an append would duplicate.

### Validation and routes: the workflow follows the intent

After the parse, every intent is **validated in Snowflake, read-only** (`intents/validate.py`, migration
`0021_intent_routes.sql`): the planner states what the intent will read and write (`Planner.expectations`: the
target database, schema and tables, the source layer's tables, the external volume and the storage integration,
taken from the ticket, the files and the repository graph), and `ReadOnlySql` looks them up with `SHOW`,
`INFORMATION_SCHEMA` `SELECT`s and `EXPLAIN` only: any other statement is refused before it is sent. The result
(what exists, row counts, columns, and a one-line summary) is stored on the intent, and `intents/route.py`
chooses the path from it:

| route | when | what happens next |
|---|---|---|
| `ingest_new` | files to load, target tables missing | the planner plans them from the repository contracts |
| `ingest_existing` | every target table exists | the load is planned into the tables as they are |
| `model_new` | the layer below is loaded, the target layer is not | the **data modeler** proposes the layer |
| `model_existing` | the target layer's tables exist | a change plan |
| `wait_upstream` | the tables it builds from are not loaded | status `waiting`; re-checked every 5 minutes, and it carries on by itself once they land |
| `manual` | no route builds this kind | the spec goes to a person |

The page's journey bar shows the route's own stages (Read, Review, Validate, Plan or Model or Wait, Approve,
Generate, Run, Catalog) and the **Validate** tab lists every object with exists / missing; *Check again*
(`POST /intents/{id}/validate`) looks once more. A question the repository graph already answers (each file's
identifier, when every file has a contract with its key) is not asked.

**A folder of different files is a table set** (`intents/tableset.py`): each CSV is matched to a crawled source by
its path (`vantage_core/claim.csv` → `BRONZE.A_CLAIM`; a file of the same name elsewhere only when at least half its columns
agree), then by its headers, and becomes its own table with the
contract's column types (`STRING` → `VARCHAR`), its declared key and its checks. Checks that join other tables
are copied too when those tables are loaded alongside (`kind: query`, re-pointed at the new tables), and every
check that can run in Python is tried against the files before anything is loaded (references between the files
included). Contract columns a file lacks, files no repository knows, and missing databases, volumes and
integrations become risks or `CREATE … IF NOT EXISTS` in the setup. Each file's encoding is detected (UTF-8, Windows-1250 for
Central European text, Latin-1) and the shared file format's `ENCODING` is set to the one that reads them all; files of up to
20,000 rows are read whole so checks across files see every row. The generated pipeline creates one stage, all
the tables, one `COPY` per table (by its file's path), checks named per table and one task for the set; the runner
uploads the files keeping their folders.

**S3 or Azure Blob Storage** (`intents/landing.py`). Files land in S3 or in an Azure Blob container; the parser reads which
from the ticket (the provider it names last, an `azure://` or `https://<account>.blob.core.windows.net/<container>/<folder>`
URL, or "storage account X" / "container Y" / "prefix 'z'", where an answer overrides the ticket). The generated stage then
reads `azure://<account>.blob.core.windows.net/<container>/<folder>/` through the named storage integration, the runner uploads
with the Azure SDK (`AZURE_STORAGE_CONNECTION_STRING`, or your Azure login through `DefaultAzureCredential`) and anything the
ticket leaves open (`AZURE_STORAGE_ACCOUNT`, `AZURE_CONTAINER`, `AZURE_PREFIX`) comes from the environment; a container with no
folder named gets one per pipeline. Validation also runs `DESCRIBE INTEGRATION` / `DESCRIBE EXTERNAL VOLUME` (read-only): an
integration for the other cloud, or one whose allowed locations miss the landing URL, is a risk, and the plan names the Azure
consent step and the role each app needs (Storage Blob Data Reader for the stage, Contributor for the volume).

**The data modeler** (`intents/modeler.py`) designs a silver or gold layer when its route is `model_new`. Claude
works with read-only tools: `profile_columns` (counts, distinct values, blanks, samples), `repo_model` (a
repository model's grain, key, columns with their source columns, and checks) and `test_sql` (`EXPLAIN`, then rows,
distinct keys and blank keys of its SELECT). It starts from the models the repository already defines and records
every deviation. Its answer is then checked without it: the SQL must parse as one SELECT, read only loaded source
tables or models of the layer, use columns those tables have, return the columns it declares, compile in
Snowflake and keep its key unique; findings appear on each table and as risks. It runs in the background (status
`modeling`), and the proposal is approved like any spec. A layer is built from whatever tables its source schema
really holds (a hand-loaded `CITY_ICEBERG` as much as the repository's `B_CITY`; the repository's names only stand in
while that schema is empty), and the repository's tables are matched to the loaded ones by name and shared columns,
so its models' source columns reach the modeler under the loaded names. The generator builds the layer in dependency order
(`TRUNCATE` + `INSERT … SELECT`, or `MERGE` on the key) with key, not-null and relationship checks and one task.
Nothing is created or loaded in Snowflake or S3 before approval.

## Knowledge Hub: GitHub repositories crawled into a knowledge graph

**Knowledge Hub** (`/knowledge`, sidebar Knowledge group) has two sections. **Repositories** crawls a GitHub
repository and turns its structure into a typed graph in Neo4j: the data pipeline it implements, not just
its files. **Documents & entities** (`/knowledge/documents[/:id]`) shows what Genie retrieves from: each
document's chunks and the entity graph that connects them. Its graph opens on the **Knowledge map**
(`GET /api/v1/graph/overview`, up to 150 documents and the 80 entities they share most, with contributors,
references and dependencies), and switches to one document's graph or an entity's neighbourhood. Nodes
carry type icons (catalog datasets draw as tables), links curve and carry flow particles, and clicking an
entity filters the chunks on the left. The hub replaced the Repo Graph and Knowledge
Explorer pages, and the Documents page (the document store holds the catalog datasets the Semantic Hub
already shows; ingestion runs through Connectors). Old links redirect: `/repo-graph` (with its query) to
`/knowledge`, `/explorer`, `/explorer/:id`, `/documents` and `/lineage/:id` to the documents section,
`/lineage` to `/knowledge` and `/playground` to Home. The Semantic Layer page is now called **Semantic Hub**
(same `/semantic` route).

**What a crawl understands.** Every edge records how it was established (`methods`: declared, parsed or
inferred) and its evidence files.

* *Declared* in config: source contracts (`sources:` YAML with columns, keys, CSV headers, landing paths),
  model contracts (`models:` with layer, key, typed columns), asset dependencies (`assets:` with
  `depends_on`, grain, owner, definition and checks files), the pipeline (`pipeline_id`), Prometheus alert
  rules, Jenkins and GitHub Actions stages.
* *Parsed* from SQL with sqlglot after normalising Jinja (`{{ bronze('X') }}`, dbt `ref`/`source`,
  `{{ database }}.SCHEMA.T`, key macros kept as hashes over their columns): table lineage and
  column-level lineage for every model in `sql/<layer>/<name>.sql`, secure views, control tables,
  and named quality checks (`'<name>' CHECK_NAME` unions) attached to the tables they check.
  Storage integrations, external volumes, stages, file formats, `CREATE ICEBERG TABLE` and `COPY INTO`
  are read from SQL and from Python f-strings. Python gives imports, classes, functions, the config and
  SQL files a module reads, and which tests exercise which modules.
* *Inferred* from conventions: sources land in the stage the `COPY INTO <BRONZE>` uses, that stage reads
  the integration's single allowed S3 location, and the tables an Iceberg DDL template creates are
  stored on the repository's external volume.
* Drift: when a model's SQL reads a table its `assets` entry does not declare (or the reverse), the crawl
  reports it as a warning.

On `chidha2019/omniclaim-lakehouse-pipelines` (61 files) a crawl takes about 4 seconds and writes 852
nodes and 1,725 edges: 23 CSV sources from 2 source systems, 23 Bronze, 8 Silver and 3 Gold
Snowflake-managed Iceberg tables on `OMNICLAIM_ICEBERG_VOL`, 7 secure serving views, 5 control tables,
337 columns, 257 quality checks, the landing stage, integration and file format, 7 alerts and 4 CI stages.
Column lineage traces 80 of the 89 Silver and Gold columns (the other 9 are constants), for example
`SERVING.LOSS_METRICS.PAID_TO_TERM_PREMIUM_RATIO` back to the CSV header `Current_Term_Amount`.

**Graph model** (labels whitelisted in `ech_core/repo_graph/model.py`; constraint in
`infra/neo4j/schema/002_repo_graph.cypher`). Every node is `(:RepoGraph:<Kind> {node_key, repo, kind,
name, display, ...})` with `node_key = "<owner/name>|<kind>|<name>"`; kinds are Repository, RepoFile,
CodeSymbol, Pipeline, SourceSystem, DataSource, DataTable, DataColumn, QualityCheck, StorageIntegration,
ExternalVolume, Stage, FileFormat, S3Location, CiStage and Alert. Relationships: CONTAINS, DEFINES,
INGESTS, BUILDS, FROM_SYSTEM, LANDS_IN, READS_FROM, ALLOWS, WRITES_TO, USES, LOADED_FROM, DERIVED_FROM
(tables and columns), STORED_ON, HAS_COLUMN, DEFINED_IN, CHECKS, IMPORTS, DECLARES, READS, TESTS, NEXT,
MONITORS, DOCUMENTS. A crawl replaces one repository's subgraph in a single transaction.

**Who reads it.** Genie's Cypher tool has the schema and examples in its prompt, so it can answer
"what feeds GOLD.FACT_LOSS_PERFORMANCE" or "which CSV column does SETTLED_AMOUNT come from". The intent
planner (`query_service/intents/planner.py`) reads `RepoGraphRepository.conventions()` before it writes a
CSV-to-Iceberg spec: it reuses the repository's external volume and Bronze schema convention, names the
storage integration to set, links the closest existing source by CSV-header overlap as an exemplar,
and flags a target table that already exists in the repository. It does not point the new pipeline at
an existing shared stage, because the generator qualifies names by the target schema and a shared
bucket root would match other sources' files.

From the exemplar (`RepoGraphRepository.exemplar()`, `query_service/intents/exemplar.py`) the planner
also copies the quality checks, translated rather than pasted. The crawl keeps each check's SQL and its
run-time parameters. A key-uniqueness check becomes the unique test, `IS NULL` checks join the not-null
test, and other single-table checks become `condition` tests with columns renamed to the new feed.
A format check on a column the load already casts (a date or a decimal) counts as covered, because the
load stops on a value that does not fit. Checks that join other tables are listed as skipped until the
new source has its own counterparts. The copied tests run against the sampled CSV rows before approval,
so a mismatch shows up as a risk (for example a status value the exemplar does not accept). Nullability
follows the exemplar's contract where the sample agrees. The spec also lists each model that reads the
exemplar directly, with its file and what it feeds, and says for every one of its columns whether the
new feed supplies it, it needs another feed, or it is a constant.

**The Repositories section.** A crawl panel takes `owner/name`, a GitHub URL or `owner/name@branch` plus an optional
branch, and can also start the normal github-live ingestion for the same repository so its text becomes
searchable (only for repositories in `ECH_GITHUB_REPOS`). Progress, the result (files, nodes, edges,
columns traced, commit) and warnings show live. Four views: **Lineage** (infrastructure strip for the
landing path and Iceberg storage, then CSV sources grouped by system, Bronze, Silver, Gold and Serving
columns with curved edges; clicking a node lights its full upstream and downstream path), **Graph**
(`components/repo-graph/repo-network.tsx`: clusters laid out in data-flow order from source systems
through landing, Bronze, Silver, Gold and Serving, with orchestration above and Iceberg storage below;
one shape per kind, tables coloured by layer; lineage edges animated in the direction data moves, the
pipeline's build and storage edges shown only for the hovered or selected node; labels by zoom level
without overlaps; tooltip cards, zoom, fit, animation and cluster toggles; kind filters), **Files** (role, lines, what each file holds,
GitHub links) and **Crawls** (history with warnings). A detail panel shows properties, GitHub links to
the defining files, all upstream and downstream tables, columns with their origin CSV headers, column
traces, and every relationship grouped and clickable. Search finds tables, columns, checks and files.
Remove deletes a repository's subgraph (not the crawl history).

**API** (ingestion service): `GET /api/v1/repo-graph/repos`, `DELETE /repo-graph/repos?repo=`,
`POST /repo-graph/crawls` (`{repo, ref?, index_text?}`, 202), `GET /repo-graph/crawls[?repo=]`,
`GET /repo-graph/crawls/{id}`, `GET /repo-graph/graph?repo=&view=all|lineage&kinds=`,
`GET /repo-graph/node?key=`, `GET /repo-graph/search?repo=&q=`. Crawl history lives in `repo_crawls`
(migration `0015_repo_crawls.sql`); crawls left running by a restart are marked failed at startup.
Code: `ech_core/repo_graph/` (`sql_text.py`, `extract.py`, `model.py`),
`ech_core/repositories/repo_graph_repository.py`, `ingestion_service/services/repo_crawler.py`,
`ingestion_service/api/repo_graph.py`; frontend `pages/knowledge-hub-page.tsx`,
`components/knowledge/` (the two sections), `components/repo-graph/` and `components/explorer/`. Tests: `tests/test_repo_graph.py`. Files over `ECH_GITHUB_MAX_FILE_KB`
(256 KB) and binaries are skipped; at most 3,000 text files are read per crawl.

## Production notes

* **Scaling the query service** is horizontal (stateless; `QUERY_WORKERS` or more replicas).
  The in-memory latency ring buffer is per process — use Prometheus for fleet-wide SLOs.
* **Scaling ingestion** beyond one process requires moving the in-memory `EventBus`/`RunManager`
  to a shared transport (Redis Pub/Sub, Postgres `LISTEN/NOTIFY`) — the interfaces are isolated
  in `ingestion_service/services/` for exactly that reason.
* **Connectors**: implement `BaseConnector.iter_documents()` (async generator) and register it
  in `connectors/registry.py`. Deterministic `external_id`s are all the pipeline needs.
* **Crawling real GitHub repositories**: set `ECH_GITHUB_REPOS=owner/name[@ref],…` (and
  optionally `GITHUB_TOKEN`) and the `github-live` connector is registered.
  It spends ~4 REST calls per repository (metadata, tree, languages, contributors — cached
  for 10 min) and streams file bodies from `raw.githubusercontent.com`, so even the
  unauthenticated 60 req/h quota crawls a repo comfortably. Markdown is ingested as-is;
  code/config files are wrapped in a fenced block; markdown links, Python imports and
  path-like tokens become `REFERENCES` edges (lineage); the repository becomes a Project,
  detected languages become Technologies and contributors become People.
* **Semantic layer freshness**: every connector run upserts assets by deterministic id
  (`source_system:fqn`), replaces their fields and metrics, keeps inferred joins until the
  post-run inference pass recomputes them, and the Postgres rows cascade with the document.
  Give the `databricks` / `snowflake` pipelines a schedule (Pipelines page) at the cadence
  your catalogs change; the ingestion service starts them itself.
* **Entity extraction** is a protocol (`EntityExtractor`); swap the rule-based default for an
  LLM/spaCy implementation without touching the pipeline.
* **Security**: put the services behind your gateway/IdP; CORS origins are configurable via
  `ECH_CORS_ORIGINS`. Set `ech-data` network `internal: true` to isolate the datastores.
