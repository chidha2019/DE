"""Entity extraction: Person / Project / Technology / Concept.

The default implementation is deterministic and dependency-free (gazetteers +
cue-phrase patterns). It is intentionally conservative: precision matters more
than recall here because every entity becomes a graph node that influences
retrieval. Swap in an LLM- or spaCy-backed extractor by implementing the
:class:`EntityExtractor` protocol — the pipeline only depends on the protocol.
"""

from __future__ import annotations

import re
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass
from typing import Protocol

from ech_core.domain.enums import EntityType
from ech_core.ids import normalize_entity_name

DEFAULT_TECHNOLOGIES: tuple[str, ...] = (
    "Kubernetes",
    "Terraform",
    "ArgoCD",
    "Helm",
    "Docker",
    "Go",
    "Java",
    "Python",
    "TypeScript",
    "Node.js",
    "React",
    "Tailwind CSS",
    "GraphQL",
    "REST",
    "gRPC",
    "PostgreSQL",
    "Redis",
    "Kafka",
    "RabbitMQ",
    "Celery",
    "Apache Spark",
    "Apache Iceberg",
    "dbt",
    "Airflow",
    "ClickHouse",
    "Keycloak",
    "OAuth2",
    "OpenID Connect",
    "Spring Boot",
    "FastAPI",
    "Stripe",
    "Prometheus",
    "Grafana",
    "Loki",
    "Tempo",
    "OpenTelemetry",
    "Alertmanager",
    "GitHub Actions",
    "GitHub",
    "AWS",
    "AWS S3",
    "AWS KMS",
    "etcd",
    "Neo4j",
    "pgvector",
    "Elasticsearch",
    "Snowflake",
    "Databricks",
    "Azure",
    "GCP",
    "Jenkins",
    "Ansible",
    "Vault",
    "Istio",
    "Envoy",
    "NGINX",
    "Linux",
    "Windows",
    "Confluence",
    "SharePoint",
    "Jira",
    "Slack",
    "SQL",
    "Parquet",
    "Delta Lake",
    "DuckDB",
    "Trino",
    "MinIO",
    "Pandas",
    "PyArrow",
    "Polars",
    "Pydantic",
    "pytest",
    "Great Expectations",
    "Bash",
    "JavaScript",
    "Kotlin",
    "Rust",
    "Scala",
    "Ruby",
    "Jupyter",
)

DEFAULT_CONCEPTS: tuple[str, ...] = (
    "Zero Trust",
    "Least Privilege",
    "Disaster Recovery",
    "Service Level Objective",
    "Blue/Green Deployment",
    "Canary Release",
    "Event Sourcing",
    "CQRS",
    "Data Mesh",
    "Multi-tenancy",
    "Idempotency",
    "Rate Limiting",
    "Circuit Breaker",
    "Incident Response",
    "Change Management",
    "Feature Flags",
    "Schema Evolution",
    "Backpressure",
    "Observability",
    "Role-Based Access Control",
    "SOC 2",
    "GDPR",
    "ISO 27001",
    "Error Budget",
    "Recovery Time Objective",
    "Recovery Point Objective",
    "On-call",
    "Postmortem",
)

# A person name is exactly two Title Case tokens (optionally joined by a particle or
# an initial): "Aiko Tanaka", "Fatima Al-Sayed", "Jean de Vries", "Mary J. Blige".
# Tokens may be hyphenated with a capitalised second half and are separated by
# spaces/tabs only — never newlines — so a name cannot swallow the next line.
_NAME_WORD = r"[A-Z][a-zà-ÿ']+(?:-[A-Z][a-zà-ÿ']+)?"
_NAME_PARTICLE = r"(?:van|von|de|der|den|da|di|du|la|le|al|bin|el|[A-Z]\.)"
_NAME = rf"{_NAME_WORD}(?:[ \t]+{_NAME_PARTICLE})?[ \t]+{_NAME_WORD}"
_PERSON_NAME_RE = re.compile(rf"^{_NAME}$", re.UNICODE)
_NAME_SEP_RE = re.compile(r"[ \t]*(?:,|\band\b|&|·|;)[ \t]*")

# Cue words are matched case-insensitively (scoped (?i:...) group); the captured
# names must still be Title Case so ordinary words are never promoted to people.
# A cue may introduce a list: "maintained by Lena Okafor, Daniel Brooks and Aiko Tanaka".
_PERSON_CUE_RE = re.compile(
    r"(?i:\b(?:by|owner|owners|author|authors|maintainer|maintainers|reviewer|reviewers|"
    r"assignee|approved|reported|presented|contact|buddy|manager|deciders?|primary on-call|"
    r"backup|escalations go to|page)\b[ \t]*(?:by[ \t]+|is[ \t]+|:[ \t]*)?)"
    rf"({_NAME}(?:[ \t]*(?:,|\band\b|&)[ \t]*{_NAME})*)",
    re.UNICODE,
)
_PERSON_LIST_RE = re.compile(
    r"\b(?:Attendees|Contributors|Reviewers|Owners|Deciders|Maintainers)\s*:\s*([^\n]+)"
)
_PROJECT_CUE_RE = re.compile(
    r"\b(?:Project|project)\s+([A-Z][A-Za-z0-9]+(?:\s+[A-Z][A-Za-z0-9]+)?)\b"
)
_ORG_SUFFIXES = (
    "Platform",
    "Identity",
    "Billing",
    "Analytics",
    "Observability",
    "Mesh",
    "Gateway",
    "Portal",
    "Pipeline",
    "Service",
    "Engine",
)
_PROJECT_SUFFIX_RE = re.compile(rf"\b([A-Z][a-z]+)\s+({'|'.join(_ORG_SUFFIXES)})\b")
_HEADING_CONCEPT_RE = re.compile(r"^(?:[A-Z][a-z]+)(?:\s+(?:[A-Z][a-z]+|and|of|the)){1,3}$")

# Words that never start a person name (field labels, generic nouns).
_NOT_NAMES = frozenset(
    {
        "Status",
        "Date",
        "Owner",
        "Reviewer",
        "Approved",
        "Primary",
        "Backup",
        "Pager",
        "Accepted",
        "Draft",
        "Repository",
        "Issue",
        "Labels",
        "Reported",
        "Assignee",
        "Recovery",
        "Time",
        "Objective",
        "Point",
        "Service",
        "Level",
    }
)
# Generic first words that make "<Word> Platform/Service/..." too vague to be a project.
_GENERIC_PROJECT_HEADS = frozenset(
    {
        "Data",
        "The",
        "Our",
        "Internal",
        "Customer",
        "Public",
        "Private",
        "New",
        "Legacy",
        "Core",
        "Shared",
        "Developer",
        "Payment",
        "Self",
        "Managed",
    }
)
_PERSON_LAST_TOKEN_BLOCKLIST = frozenset(
    {*_ORG_SUFFIXES, "Team", "Guide", "Policy", "Review", "Runbook", "Standard", "Overview"}
)


@dataclass(frozen=True)
class ExtractedEntity:
    name: str
    entity_type: EntityType
    confidence: float
    normalized_name: str
    occurrences: int = 1


class EntityExtractor(Protocol):
    def extract(self, text: str, *, section_path: Sequence[str] = ()) -> list[ExtractedEntity]: ...


AddFn = Callable[[str, EntityType, float], None]


def _compile_gazetteer(terms: Iterable[str], *, ignore_case: bool) -> re.Pattern[str] | None:
    cleaned = sorted({t.strip() for t in terms if t and t.strip()}, key=len, reverse=True)
    if not cleaned:
        return None
    alternation = "|".join(re.escape(t) for t in cleaned)
    flags = re.IGNORECASE if ignore_case else 0
    return re.compile(rf"(?<![\w/])({alternation})(?![\w/])", flags)


class RuleBasedEntityExtractor:
    """Gazetteer + cue-pattern extractor. Deterministic; safe to run twice."""

    def __init__(
        self,
        *,
        technologies: Iterable[str] = DEFAULT_TECHNOLOGIES,
        concepts: Iterable[str] = DEFAULT_CONCEPTS,
        projects: Iterable[str] = (),
        people: Iterable[str] = (),
    ) -> None:
        technologies = list(technologies)
        concepts = list(concepts)
        projects = list(projects)
        people = list(people)
        self._tech_re = _compile_gazetteer(technologies, ignore_case=True)
        self._tech_canonical = {t.casefold(): t for t in technologies}
        self._concept_re = _compile_gazetteer(concepts, ignore_case=True)
        self._concept_canonical = {c.casefold(): c for c in concepts}
        self._project_re = _compile_gazetteer(projects, ignore_case=False)
        self._people_re = _compile_gazetteer(people, ignore_case=False)
        self._project_norms = {normalize_entity_name(p) for p in projects}
        self._tech_norms = {normalize_entity_name(t) for t in technologies}
        self._concept_norms = {normalize_entity_name(c) for c in concepts}
        self._people_norms = {normalize_entity_name(p) for p in people}

    # ------------------------------------------------------------------ public
    def extract(self, text: str, *, section_path: Sequence[str] = ()) -> list[ExtractedEntity]:
        found: dict[tuple[EntityType, str], tuple[str, float, int]] = {}

        def add(name: str, etype: EntityType, confidence: float) -> None:
            name = name.strip().strip(".,;:()[]-")
            if not name:
                return
            norm = normalize_entity_name(name)
            key = (etype, norm)
            if key in found:
                prev_name, prev_conf, n = found[key]
                found[key] = (prev_name, max(prev_conf, confidence), n + 1)
            else:
                found[key] = (name, confidence, 1)

        # Technologies & concepts (gazetteers, case-insensitive, canonical casing)
        if self._tech_re:
            for m in self._tech_re.finditer(text):
                add(
                    self._tech_canonical.get(m.group(1).casefold(), m.group(1)),
                    EntityType.TECHNOLOGY,
                    0.9,
                )
        if self._concept_re:
            for m in self._concept_re.finditer(text):
                add(
                    self._concept_canonical.get(m.group(1).casefold(), m.group(1)),
                    EntityType.CONCEPT,
                    0.7,
                )

        # Projects: gazetteer first, then "Project X", then the "<Name> Platform" heuristic
        gazetteer_projects: set[str] = set()
        if self._project_re:
            for m in self._project_re.finditer(text):
                add(m.group(1), EntityType.PROJECT, 0.9)
                gazetteer_projects.add(normalize_entity_name(m.group(1)))
        for m in _PROJECT_CUE_RE.finditer(text):
            add(m.group(1), EntityType.PROJECT, 0.7)
        for m in _PROJECT_SUFFIX_RE.finditer(text):
            head, candidate = m.group(1), f"{m.group(1)} {m.group(2)}"
            norm = normalize_entity_name(candidate)
            if head in _NOT_NAMES or head in _GENERIC_PROJECT_HEADS:
                continue
            if norm in self._concept_norms or norm in self._tech_norms:
                continue  # "Data Mesh" is a concept, not a project
            if any(
                p != norm and p.endswith(norm) for p in gazetteer_projects | self._project_norms
            ):
                continue  # "Data Mesh" inside "Orion Data Mesh"
            add(candidate, EntityType.PROJECT, 0.65)

        # People: directory gazetteer, then cue phrases and labelled lists
        if self._people_re:
            for m in self._people_re.finditer(text):
                add(m.group(1), EntityType.PERSON, 0.9)
        for m in _PERSON_CUE_RE.finditer(text):
            for name in _NAME_SEP_RE.split(m.group(1)):
                self._add_person(name, add, 0.8)
        for m in _PERSON_LIST_RE.finditer(text):
            for part in _NAME_SEP_RE.split(m.group(1)):
                self._add_person(part, add, 0.75)

        # Concepts from sub-headings. The first path element is the document title
        # ("Nimbus Billing Onboarding Guide") and is never a concept; headings that
        # name a project, person or technology are not concepts either.
        for heading in list(section_path)[1:]:
            h = heading.strip()
            if not _HEADING_CONCEPT_RE.match(h):
                continue
            if self._mentions_known_entity(h):
                continue
            add(h, EntityType.CONCEPT, 0.55)

        results = [
            ExtractedEntity(
                name=name,
                entity_type=etype,
                confidence=min(1.0, round(conf + 0.05 * (n - 1), 3)),
                normalized_name=norm,
                occurrences=n,
            )
            for (etype, norm), (name, conf, n) in found.items()
        ]
        results = self._resolve_conflicts(results)
        results.sort(key=lambda e: (-e.confidence, e.entity_type.value, e.normalized_name))
        return results

    # ------------------------------------------------------------------ helpers
    def _add_person(self, candidate: str, add: AddFn, confidence: float) -> None:
        candidate = candidate.strip().strip(".,;:()[]-")
        if not _PERSON_NAME_RE.match(candidate):
            return
        tokens = candidate.split()
        if tokens[0] in _NOT_NAMES or tokens[-1] in _PERSON_LAST_TOKEN_BLOCKLIST:
            return
        norm = normalize_entity_name(candidate)
        if norm in self._project_norms or norm in self._tech_norms or norm in self._concept_norms:
            return  # "managed by Atlas Platform" is a system, not a person
        add(candidate, EntityType.PERSON, confidence)

    def _mentions_known_entity(self, text: str) -> bool:
        for pattern in (self._project_re, self._people_re, self._tech_re):
            if pattern and pattern.search(text):
                return True
        return normalize_entity_name(text) in self._concept_norms and False

    @staticmethod
    def _resolve_conflicts(results: list[ExtractedEntity]) -> list[ExtractedEntity]:
        """Defence in depth: the same surface form never carries two labels."""
        by_type: dict[EntityType, set[str]] = {}
        for e in results:
            by_type.setdefault(e.entity_type, set()).add(e.normalized_name)
        tech = by_type.get(EntityType.TECHNOLOGY, set())
        projects = by_type.get(EntityType.PROJECT, set())
        concepts = by_type.get(EntityType.CONCEPT, set())
        kept: list[ExtractedEntity] = []
        for e in results:
            n = e.normalized_name
            if e.entity_type is EntityType.PERSON and (n in projects or n in tech or n in concepts):
                continue
            if e.entity_type is EntityType.PROJECT and (
                n.split(" ")[0] in tech  # "Prometheus Service"
                or any(p != n and p.endswith(n) for p in projects)  # suffix of a longer project
            ):
                continue
            if e.entity_type is EntityType.CONCEPT and (n in projects or n in tech):
                continue
            kept.append(e)
        return kept
