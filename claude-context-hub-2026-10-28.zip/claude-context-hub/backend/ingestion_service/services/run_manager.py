"""Tracks in-flight pipeline runs and their pause/cancel control signals."""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from uuid import UUID

from ech_core.exceptions import InvalidRunStateError
from ech_core.logging import get_logger

log = get_logger(__name__)


@dataclass
class RunHandle:
    run_id: UUID
    connector_name: str
    # set   -> workers may proceed; clear -> workers block at the next checkpoint
    pause_event: asyncio.Event = field(default_factory=asyncio.Event)
    cancel_event: asyncio.Event = field(default_factory=asyncio.Event)
    task: asyncio.Task[None] | None = None
    started_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))

    def __post_init__(self) -> None:
        self.pause_event.set()

    @property
    def paused(self) -> bool:
        return not self.pause_event.is_set() and not self.cancel_event.is_set()

    @property
    def cancelling(self) -> bool:
        return self.cancel_event.is_set()


class RunManager:
    def __init__(self) -> None:
        self._handles: dict[UUID, RunHandle] = {}

    # ------------------------------------------------------------------ registry
    def register(self, run_id: UUID, connector_name: str) -> RunHandle:
        handle = RunHandle(run_id=run_id, connector_name=connector_name)
        self._handles[run_id] = handle
        return handle

    def start(self, handle: RunHandle, work: Callable[[], Awaitable[None]]) -> asyncio.Task[None]:
        task = asyncio.create_task(work(), name=f"ingestion-run-{handle.run_id}")
        handle.task = task
        task.add_done_callback(lambda _t: self._handles.pop(handle.run_id, None))
        return task

    def get(self, run_id: UUID) -> RunHandle | None:
        return self._handles.get(run_id)

    def active(self) -> list[RunHandle]:
        return list(self._handles.values())

    def active_for_connector(self, connector_name: str) -> RunHandle | None:
        for handle in self._handles.values():
            if handle.connector_name == connector_name:
                return handle
        return None

    # ------------------------------------------------------------------ control
    def pause(self, run_id: UUID) -> RunHandle:
        handle = self._require(run_id)
        if handle.cancelling:
            raise InvalidRunStateError("Run is being cancelled")
        handle.pause_event.clear()
        return handle

    def resume(self, run_id: UUID) -> RunHandle:
        handle = self._require(run_id)
        if handle.cancelling:
            raise InvalidRunStateError("Run is being cancelled")
        handle.pause_event.set()
        return handle

    def cancel(self, run_id: UUID) -> RunHandle:
        handle = self._require(run_id)
        handle.cancel_event.set()
        handle.pause_event.set()  # unblock paused workers so they can exit
        return handle

    def _require(self, run_id: UUID) -> RunHandle:
        handle = self._handles.get(run_id)
        if handle is None:
            raise InvalidRunStateError(
                "Run is not active in this process", details={"run_id": str(run_id)}
            )
        return handle

    # ------------------------------------------------------------------ lifecycle
    async def shutdown(self, timeout: float = 20.0) -> None:
        """Cancel every run co-operatively, then wait for tasks to finish."""
        handles = list(self._handles.values())
        if not handles:
            return
        log.info("run_manager.shutdown", active_runs=len(handles))
        for handle in handles:
            handle.cancel_event.set()
            handle.pause_event.set()
        tasks = [h.task for h in handles if h.task is not None]
        if tasks:
            done, pending = await asyncio.wait(tasks, timeout=timeout)
            for task in pending:
                task.cancel()
            if pending:
                await asyncio.gather(*pending, return_exceptions=True)
