"""Crawl a GitHub repository into the repo knowledge graph (the Knowledge Hub).

A crawl reads the repository tree and every text file through the GitHub connector, builds the typed
graph with :func:`ech_core.repo_graph.build_repo_graph` (off the event loop), replaces that
repository's subgraph in Neo4j in one transaction, and records progress and the outcome in
``repo_crawls``. Optionally it also starts the ordinary github-live ingestion run for the same
repository, so its files become searchable text for Genie.
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from ech_core.config import Settings
from ech_core.exceptions import ConflictError, InvalidRequestError, NotFoundError
from ech_core.logging import get_logger
from ech_core.repo_graph import RepoInfo, build_repo_graph, is_text_path
from ech_core.repositories.repo_graph_repository import RepoCrawlRepository, RepoGraphRepository
from ech_core.schemas.ingestion import ScopeItem, TriggerRunRequest
from ech_core.schemas.repo_graph import CrawledRepo, RepoCrawlCreate, RepoCrawlOut, RepoGraphRepos
from ingestion_service.connectors.github_live import GitHubRepoConnector, RepoSpec

log = get_logger(__name__)
MAX_FILES = 3000
PROGRESS_EVERY = 10


class RepoCrawlService:
    def __init__(
        self,
        *,
        settings: Settings,
        crawls: RepoCrawlRepository,
        graph: RepoGraphRepository,
        pipeline: Any,
        settings_for: Callable[[], Settings] | None = None,
    ) -> None:
        self._base_settings = settings
        self._settings_for = settings_for
        self._crawls = crawls
        self._graph = graph
        self._pipeline = pipeline
        self._tasks: set[asyncio.Task[None]] = set()

    @property
    def _settings(self) -> Settings:
        """The GitHub settings in force now, including a connection saved from the Connectors page."""
        return self._settings_for() if self._settings_for else self._base_settings

    # ------------------------------------------------------------------ queries
    def configured(self) -> list[str]:
        names: list[str] = []
        for raw in self._settings.github_repo_list:
            try:
                names.append(RepoSpec.parse(raw).full_name)
            except ValueError:
                continue
        return names

    async def repos(self) -> RepoGraphRepos:
        configured = self.configured()
        lower = {c.lower() for c in configured}
        crawled = [
            CrawledRepo(
                repo=str(p.get("repo") or p.get("name")),
                ref=p.get("ref"),
                sha=p.get("sha"),
                url=p.get("url"),
                description=p.get("description"),
                crawled_at=p.get("crawled_at"),
                crawl_id=p.get("crawl_id"),
                files=p.get("files"),
                counts=p.get("counts") or {},
                configured=str(p.get("repo") or "").lower() in lower,
            )
            for p in await self._graph.repos()
        ]
        return RepoGraphRepos(crawled=crawled, configured=configured)

    async def get(self, crawl_id: UUID) -> RepoCrawlOut:
        row = await self._crawls.get(crawl_id)
        if row is None:
            raise NotFoundError(f"crawl {crawl_id} not found")
        return RepoCrawlOut.model_validate(row)

    async def list(self, *, repo: str | None, limit: int) -> list[RepoCrawlOut]:
        return [RepoCrawlOut.model_validate(r) for r in await self._crawls.list(repo=repo, limit=limit)]

    # ------------------------------------------------------------------ commands
    async def start(self, body: RepoCrawlCreate) -> RepoCrawlOut:
        try:
            spec = RepoSpec.parse(body.repo)
        except ValueError as exc:
            raise InvalidRequestError(str(exc)) from exc
        if body.ref and body.ref.strip():
            spec = RepoSpec(owner=spec.owner, name=spec.name, ref=body.ref.strip())
        if await self._crawls.active(spec.full_name):
            raise ConflictError(f"{spec.full_name} is already being crawled")
        if body.index_text and spec.full_name.lower() not in {c.lower() for c in self.configured()}:
            raise InvalidRequestError(
                f"{spec.full_name} is not in ECH_GITHUB_REPOS, so its text cannot be indexed; crawl the graph only, "
                "or add the repository to ECH_GITHUB_REPOS and restart the ingestion service"
            )
        crawl_id = await self._crawls.create(repo=spec.full_name, ref=spec.ref, index_text=body.index_text, requested_by=body.requested_by)
        task = asyncio.create_task(self._run(crawl_id, spec, body.index_text), name=f"repo-crawl-{crawl_id}")
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)
        return await self.get(crawl_id)

    async def delete_repo(self, repo: str) -> int:
        if await self._crawls.active(repo):
            raise ConflictError(f"{repo} is being crawled; wait for the crawl to finish")
        return await self._graph.delete(repo)

    async def fail_stale(self) -> int:
        return await self._crawls.fail_stale("ingestion-service restarted while the crawl was running", datetime.now(UTC))

    async def shutdown(self) -> None:
        for task in list(self._tasks):
            task.cancel()
        if self._tasks:
            await asyncio.gather(*self._tasks, return_exceptions=True)

    # ------------------------------------------------------------------ the crawl
    def _connector(self, spec: RepoSpec) -> GitHubRepoConnector:
        s = self._settings
        token = s.github_token.get_secret_value() if s.github_token else None
        return GitHubRepoConnector(
            repos=[f"{spec.full_name}@{spec.ref}" if spec.ref else spec.full_name],
            token=token or None,
            api_url=s.github_api_url,
            raw_url=s.github_raw_url,
            max_file_bytes=s.github_max_file_kb * 1024,
            fetch_concurrency=s.github_fetch_concurrency,
        )

    async def _run(self, crawl_id: UUID, spec: RepoSpec, index_text: bool) -> None:
        connector = self._connector(spec)
        max_bytes = self._settings.github_max_file_kb * 1024
        try:
            await self._crawls.update(crawl_id, status="running", phase="reading repository", started_at=datetime.now(UTC))
            snap = await connector.repository_snapshot(spec)
            text_blobs = [b for b in snap["blobs"] if is_text_path(str(b.get("path", "")))]
            blobs = [b for b in text_blobs if 0 < int(b.get("size") or 0) <= max_bytes]
            warnings: list[str] = []
            if len(text_blobs) > len(blobs):
                warnings.append(f"{len(text_blobs) - len(blobs)} text files skipped: empty or larger than {self._settings.github_max_file_kb} KB")
            if len(blobs) > MAX_FILES:
                warnings.append(f"only the first {MAX_FILES} of {len(blobs)} text files were read")
                blobs = blobs[:MAX_FILES]
            await self._crawls.update(crawl_id, ref=snap["ref"], sha=snap["sha"], files_total=len(blobs), phase="reading files")

            done = 0

            async def read(blob: dict[str, Any]) -> tuple[dict[str, Any], str | None]:
                nonlocal done
                text = await connector.read_blob_text(snap["snapshot"], blob)
                done += 1
                if done % PROGRESS_EVERY == 0:
                    await self._crawls.update(crawl_id, files_read=done)
                return blob, text

            files: dict[str, str] = {}
            sizes: dict[str, int] = {}
            for result in await asyncio.gather(*(read(b) for b in blobs), return_exceptions=True):
                if isinstance(result, BaseException):
                    warnings.append(f"file not read: {getattr(result, 'message', None) or result}")
                    continue
                blob, text = result
                if text is not None:
                    files[str(blob["path"])] = text
                    sizes[str(blob["path"])] = int(blob.get("size") or 0)
            await self._crawls.update(crawl_id, files_read=len(files), phase="extracting")

            meta = snap["meta"]
            info = RepoInfo(
                full_name=spec.full_name,
                ref=snap["ref"],
                sha=snap["sha"],
                url=str(meta.get("html_url") or f"https://github.com/{spec.full_name}"),
                description=meta.get("description"),
                default_branch=meta.get("default_branch"),
                languages=dict(snap["languages"] or {}),
            )
            build, summary = await asyncio.to_thread(build_repo_graph, info, files, sizes)
            repo_node = build.nodes[build.key("repository", spec.full_name)]
            repo_node.props.update(crawled_at=datetime.now(UTC).isoformat(), crawl_id=str(crawl_id))

            await self._crawls.update(crawl_id, phase="writing graph")
            await self._graph.ensure_schema()
            summary["written"] = await self._graph.replace(build)
            warnings += build.warnings

            run_id: UUID | None = None
            if index_text:
                await self._crawls.update(crawl_id, phase="indexing text")
                try:
                    run = await self._pipeline.trigger(
                        TriggerRunRequest(
                            connector="github-live",
                            triggered_by=f"repo-graph crawl {crawl_id}",
                            scope=[ScopeItem(path=[spec.full_name], kind="repo")],
                        )
                    )
                    run_id = run.id
                except Exception as exc:  # noqa: BLE001 - the graph is written; indexing is optional
                    warnings.append(f"text indexing not started: {getattr(exc, 'message', None) or exc}")
            await self._crawls.update(
                crawl_id,
                status="completed",
                phase="completed",
                stats=summary,
                warnings=warnings[:200],
                index_run_id=run_id,
                finished_at=datetime.now(UTC),
            )
            log.info("repo_crawl.completed", repo=spec.full_name, crawl=str(crawl_id), nodes=summary["nodes"], edges=summary["edges"])
        except asyncio.CancelledError:
            await self._crawls.update(crawl_id, status="failed", phase="failed", error="cancelled", finished_at=datetime.now(UTC))
            raise
        except Exception as exc:  # noqa: BLE001 - the crawl record carries the failure
            message = str(getattr(exc, "message", None) or exc)
            details = getattr(exc, "details", None)
            if isinstance(details, dict) and details.get("status"):
                message = f"{message} (HTTP {details['status']})"
            log.warning("repo_crawl.failed", repo=spec.full_name, crawl=str(crawl_id), error=message)
            await self._crawls.update(crawl_id, status="failed", phase="failed", error=message[:500], finished_at=datetime.now(UTC))
        finally:
            await connector.aclose()
