"""Saved pipelines: validate, store, run now or on a schedule.

A pipeline is a connector plus the scope picked from its schema, the options of a run and a
schedule. Running one builds an ordinary run request, so everything about runs (events, pause,
cancel, statistics) stays as it was; the run only remembers which pipeline it belongs to.
"""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime, timedelta
from typing import Any
from uuid import UUID

import asyncpg

from ech_core.domain.models import IngestionRunRecord
from ech_core.exceptions import ConflictError, InvalidRequestError, NotFoundError
from ech_core.logging import get_logger
from ech_core.repositories import AuditRepository, PipelineRepository
from ech_core.repositories.lines_repository import LinesRepository
from ech_core.schedule import describe, next_run_at
from ech_core.schemas.ingestion import (
    RunOptions,
    RunStats,
    ScopeItem,
    SourceOptions,
    TriggerRunRequest,
)
from ech_core.schemas.pipelines import (
    PipelineIn,
    PipelineOut,
    PipelineRunSummary,
    PipelineUpdate,
    PreviewRequest,
    PreviewResult,
    Schedule,
)
from ingestion_service.connectors.base import ConnectorOptions
from ingestion_service.connectors.registry import ConnectorRegistry
from ingestion_service.services.pipeline_service import PipelineService

log = get_logger(__name__)

PREVIEW_TIMEOUT_SECONDS = 60
BUSY_RETRY = timedelta(minutes=1)


def _dump(model: Any) -> dict[str, Any]:
    return model.model_dump(exclude_none=True)


class PipelineDefinitionService:
    def __init__(
        self,
        *,
        repo: PipelineRepository,
        registry: ConnectorRegistry,
        pipeline: PipelineService,
        audit: AuditRepository,
        lines: LinesRepository | None = None,
    ) -> None:
        self._repo = repo
        self._registry = registry
        self._pipeline = pipeline
        self._audit = audit
        self._lines = lines

    async def _check_line(self, value: str | None) -> str | None:
        """A default line of business must be one of the Line of Business term's values; empty clears it."""
        if not value or not value.strip():
            return None
        key = value.strip().lower()
        known = [v["key"] for v in await self._lines.values()] if self._lines else []
        if known and key not in known:
            raise InvalidRequestError(f"Unknown line of business '{value}'; choose one of {', '.join(known)}")
        return key

    # ------------------------------------------------------------------ reads
    async def list(self, *, connector: str | None = None, search: str | None = None) -> list[PipelineOut]:
        return [self._out(r) for r in await self._repo.list(connector_name=connector, search=search)]

    async def get(self, pipeline_id: UUID) -> PipelineOut:
        return self._out(await self._row(pipeline_id))

    async def _row(self, pipeline_id: UUID) -> dict[str, Any]:
        row = await self._repo.get(pipeline_id)
        if row is None:
            raise NotFoundError("Pipeline not found", details={"pipeline_id": str(pipeline_id)})
        return row

    # ------------------------------------------------------------------ writes
    def _check_scope(self, connector_name: str, scope: list[ScopeItem]) -> None:
        connector = self._registry.get(connector_name)
        if scope and not connector.discoverable:
            raise InvalidRequestError(
                f"{connector.display_name} cannot narrow a pipeline to a scope; leave the scope empty"
            )

    async def create(self, body: PipelineIn, *, actor: str | None = None) -> PipelineOut:
        connector = self._registry.get(body.connector)
        self._check_scope(connector.name, body.scope)
        taken = f"A pipeline named {body.name} already exists"
        if await self._repo.name_taken(body.name):
            raise ConflictError(taken)
        now = datetime.now(tz=UTC)
        try:
            pipeline_id = await self._repo.create(
                name=body.name,
                description=body.description,
                connector_name=connector.name,
                source_system=connector.source_system,
                scope=[i.model_dump() for i in body.scope],
                options=_dump(body.options),
                source_options=_dump(body.source_options),
                schedule=_dump(body.schedule),
                enabled=body.enabled,
                owner=body.owner,
                tags=body.tags,
                next_run_at=next_run_at(body.schedule, now) if body.enabled else None,
                created_by=actor or (body.owner or None),
                line_of_business=await self._check_line(body.line_of_business),
            )
        except asyncpg.UniqueViolationError as exc:
            raise ConflictError(taken) from exc
        await self._audit.record(
            action="pipeline.create",
            resource_type="pipeline",
            resource_id=str(pipeline_id),
            actor=actor,
            details={"name": body.name, "connector": connector.name, "scope_items": len(body.scope)},
        )
        if body.run_now:
            try:
                await self._start(await self._row(pipeline_id), actor or "api")
            except ConflictError:
                log.info("pipeline.run_now_skipped", pipeline_id=str(pipeline_id), reason="busy")
        return await self.get(pipeline_id)

    async def update(self, pipeline_id: UUID, body: PipelineUpdate, *, actor: str | None = None) -> PipelineOut:
        row = await self._row(pipeline_id)
        fields: dict[str, Any] = {}
        if body.name is not None:
            name = " ".join(body.name.split())
            if await self._repo.name_taken(name, except_id=pipeline_id):
                raise ConflictError(f"A pipeline named {name} already exists")
            fields["name"] = name
        if body.description is not None:
            fields["description"] = body.description
        if body.scope is not None:
            self._check_scope(row["connector_name"], body.scope)
            fields["scope"] = [i.model_dump() for i in body.scope]
        if body.options is not None:
            fields["options"] = _dump(body.options)
        if body.source_options is not None:
            fields["source_options"] = _dump(body.source_options)
        if body.owner is not None:
            fields["owner"] = body.owner
        if body.tags is not None:
            fields["tags"] = [t.strip().lower() for t in body.tags if t.strip()]
        if body.line_of_business is not None:
            fields["line_of_business"] = await self._check_line(body.line_of_business)
        schedule = body.schedule or Schedule.model_validate(row["schedule"] or {})
        enabled = row["enabled"] if body.enabled is None else body.enabled
        if body.schedule is not None:
            fields["schedule"] = _dump(body.schedule)
        if body.enabled is not None:
            fields["enabled"] = enabled
        if body.schedule is not None or body.enabled is not None:
            fields["next_run_at"] = next_run_at(schedule, datetime.now(tz=UTC)) if enabled else None
        try:
            await self._repo.update(pipeline_id, **fields)
        except asyncpg.UniqueViolationError as exc:
            raise ConflictError("A pipeline with that name already exists") from exc
        await self._audit.record(
            action="pipeline.update",
            resource_type="pipeline",
            resource_id=str(pipeline_id),
            actor=actor,
            details={"fields": sorted(fields)},
        )
        return await self.get(pipeline_id)

    async def set_enabled(self, pipeline_id: UUID, enabled: bool) -> PipelineOut:
        return await self.update(pipeline_id, PipelineUpdate(enabled=enabled))

    async def delete(self, pipeline_id: UUID, *, actor: str | None = None) -> None:
        row = await self._row(pipeline_id)
        if not await self._repo.delete(pipeline_id):
            raise NotFoundError("Pipeline not found", details={"pipeline_id": str(pipeline_id)})
        await self._audit.record(
            action="pipeline.delete",
            resource_type="pipeline",
            resource_id=str(pipeline_id),
            actor=actor,
            details={"name": row["name"]},
        )

    # ------------------------------------------------------------------ running
    async def run(self, pipeline_id: UUID, *, actor: str | None = None) -> IngestionRunRecord:
        return await self._start(await self._row(pipeline_id), actor or "api")

    async def _start(self, row: dict[str, Any], actor: str) -> IngestionRunRecord:
        request = TriggerRunRequest(
            connector=row["connector_name"],
            options=RunOptions.model_validate(row["options"] or {}),
            triggered_by=actor,
            scope=[ScopeItem.model_validate(i) for i in row["scope"] or []],
            source_options=SourceOptions.model_validate(row["source_options"] or {}),
            pipeline_id=row["id"],
        )
        return await self._pipeline.trigger(request)

    async def preview(self, body: PreviewRequest) -> PreviewResult:
        connector = self._registry.get(body.connector)
        self._check_scope(connector.name, body.scope)
        options = ConnectorOptions(
            limit=body.options.limit, scope=body.scope, source_options=body.source_options
        )
        note: str | None = None
        estimate: int | None = None
        try:
            async with asyncio.timeout(PREVIEW_TIMEOUT_SECONDS):
                estimate = await connector.estimate_count(options)
        except Exception as exc:  # noqa: BLE001 - a failed estimate must not block the wizard
            note = f"Could not estimate: {exc}"
        return PreviewResult(
            connector=connector.name,
            scope_items=len(body.scope),
            estimated_documents=estimate,
            whole_connection=not body.scope,
            note=note,
        )

    # ------------------------------------------------------------------ scheduler
    async def tick(self, now: datetime | None = None) -> int:
        """Start every enabled pipeline that is due; returns how many were started."""
        now = now or datetime.now(tz=UTC)
        started = 0
        for row in await self._repo.due(now):
            following = next_run_at(Schedule.model_validate(row["schedule"] or {}), now)
            try:
                await self._start(row, "scheduler")
                started += 1
            except ConflictError:
                following = now + BUSY_RETRY  # the connection is busy: try again shortly
                log.info("pipeline.schedule_busy", pipeline_id=str(row["id"]))
            except Exception:  # noqa: BLE001 - one broken pipeline must not stop the others
                log.exception("pipeline.schedule_failed", pipeline_id=str(row["id"]))
            await self._repo.set_next_run(row["id"], following)
        return started

    async def poll_loop(self, interval_seconds: float = 30.0) -> None:
        while True:
            try:
                await self.tick()
            except Exception:  # noqa: BLE001
                log.exception("pipeline.scheduler_tick_failed")
            await asyncio.sleep(interval_seconds)

    # ------------------------------------------------------------------ mapping
    def _out(self, row: dict[str, Any]) -> PipelineOut:
        available = row["connector_name"] in self._registry.names()
        label = self._registry.get(row["connector_name"]).display_name if available else row["connector_name"]
        schedule = Schedule.model_validate(row["schedule"] or {})
        return PipelineOut(
            id=row["id"],
            name=row["name"],
            description=row["description"],
            connector=row["connector_name"],
            source_system=row["source_system"],
            connector_label=label,
            scope=[ScopeItem.model_validate(i) for i in row["scope"] or []],
            options=RunOptions.model_validate(row["options"] or {}),
            source_options=SourceOptions.model_validate(row["source_options"] or {}),
            schedule=schedule,
            schedule_label=describe(schedule),
            enabled=row["enabled"],
            owner=row["owner"],
            tags=list(row["tags"] or []),
            line_of_business=row.get("line_of_business"),
            next_run_at=row["next_run_at"] if row["enabled"] else None,
            created_by=row["created_by"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            last_run=_last_run(row),
            runs_total=row["runs_total"],
            runs_failed=row["runs_failed"],
            connection_available=available,
        )


def _last_run(row: dict[str, Any]) -> PipelineRunSummary | None:
    if not row.get("lr_id"):
        return None
    stats = RunStats.model_validate(row["lr_stats"] or {})
    status = row["lr_status"]
    started, finished = row["lr_started_at"], row["lr_finished_at"]
    progress: float | None = None
    if stats.estimated_total:
        progress = min(1.0, stats.documents_seen / stats.estimated_total)
    elif status in ("completed", "failed", "cancelled"):
        progress = 1.0
    duration = None
    if started:
        end = finished or datetime.now(tz=started.tzinfo)
        duration = round((end - started).total_seconds(), 3)
    return PipelineRunSummary(
        id=row["lr_id"],
        status=status,
        triggered_by=row["lr_triggered_by"],
        started_at=started,
        finished_at=finished,
        created_at=row["lr_created_at"],
        documents_seen=stats.documents_seen,
        documents_upserted=stats.documents_upserted,
        documents_skipped=stats.documents_skipped,
        documents_failed=stats.documents_failed,
        estimated_total=stats.estimated_total,
        progress=progress,
        duration_seconds=duration,
        error=row["lr_error"],
    )
