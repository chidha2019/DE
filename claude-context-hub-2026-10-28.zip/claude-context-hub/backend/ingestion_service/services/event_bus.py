"""In-process pub/sub for pipeline progress events (feeds the SSE endpoint).

Single-process by design: for a horizontally scaled ingestion tier replace the
transport with Redis Pub/Sub or Postgres LISTEN/NOTIFY while keeping the
``publish`` / ``subscribe`` contract.
"""

from __future__ import annotations

import asyncio
import itertools
from collections import deque
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, Field

from ech_core.logging import get_logger

log = get_logger(__name__)


class RunEvent(BaseModel):
    seq: int = 0
    run_id: UUID
    level: str = "info"
    event_type: str
    message: str
    payload: dict[str, Any] = Field(default_factory=dict)
    stats: dict[str, Any] | None = None
    status: str | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))


class EventBus:
    def __init__(self, *, history: int = 500, queue_size: int = 1000) -> None:
        self._history: deque[RunEvent] = deque(maxlen=history)
        self._subscribers: dict[int, tuple[asyncio.Queue[RunEvent], UUID | None]] = {}
        self._ids = itertools.count(1)
        self._seq = itertools.count(1)
        self._queue_size = queue_size

    def publish(self, event: RunEvent) -> RunEvent:
        event.seq = next(self._seq)
        self._history.append(event)
        for queue, run_filter in list(self._subscribers.values()):
            if run_filter is not None and run_filter != event.run_id:
                continue
            try:
                queue.put_nowait(event)
            except asyncio.QueueFull:
                # Slow consumer: drop the oldest event rather than block the pipeline.
                try:
                    queue.get_nowait()
                except asyncio.QueueEmpty:
                    pass
                queue.put_nowait(event)
        return event

    @asynccontextmanager
    async def subscribe(
        self, *, run_id: UUID | None = None, replay: int = 0
    ) -> AsyncIterator[asyncio.Queue[RunEvent]]:
        """Register a subscriber queue; optionally replay the last ``replay`` events."""
        queue: asyncio.Queue[RunEvent] = asyncio.Queue(maxsize=self._queue_size)
        sub_id = next(self._ids)
        if replay:
            for event in self.recent(run_id=run_id, limit=replay):
                queue.put_nowait(event)
        self._subscribers[sub_id] = (queue, run_id)
        log.debug("eventbus.subscribed", subscriber=sub_id, run_id=str(run_id) if run_id else None)
        try:
            yield queue
        finally:
            self._subscribers.pop(sub_id, None)
            log.debug("eventbus.unsubscribed", subscriber=sub_id)

    def recent(self, *, run_id: UUID | None = None, limit: int = 100) -> list[RunEvent]:
        events = [e for e in self._history if run_id is None or e.run_id == run_id]
        return events[-limit:]

    @property
    def subscriber_count(self) -> int:
        return len(self._subscribers)
