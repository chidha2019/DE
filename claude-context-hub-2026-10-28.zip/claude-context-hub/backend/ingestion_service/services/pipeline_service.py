"""The ingestion pipeline: crawl -> normalise -> chunk -> extract -> embed -> persist -> graph.

Per-document flow (``process_document``)
-----------------------------------------
1. **Metadata upsert** (short Postgres tx, ``SELECT ... FOR UPDATE``): derive the
   deterministic ``document_id``, compare content hashes, bump ``version`` and
   reset ``graph_sync_status`` when content changed.
2. **Compute** outside any transaction: semantic chunking, entity extraction,
   embeddings (batched, bounded concurrency).
3. **Persist** (one Postgres tx): replace chunks, upsert embeddings, keep
   ``graph_sync_status = pending``. Entities are stored in
   ``chunks.metadata.entities`` so the graph can be rebuilt without re-running
   extraction.
4. **Graph sync** (one Neo4j managed tx): rewrite the document subgraph. On
   success mark ``synced``; on failure mark ``failed`` with the error. Search
   keeps working off Postgres in the meantime and ``reconcile_graph`` retries.

This is an outbox-style saga: Postgres is the system of record, Neo4j is
derived state, and ``graph_sync_status`` is the durable marker that tells us
exactly which documents still need to be reconciled.
"""

from __future__ import annotations

import asyncio
import re
import time
from collections import Counter, defaultdict
from collections.abc import Sequence
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from ech_core import ids
from ech_core.config import Settings
from ech_core.db.postgres import PostgresDatabase
from ech_core.domain.enums import (
    DocumentKind,
    EntityType,
    EventLevel,
    GraphSyncStatus,
    RunStatus,
    SourceSystem,
)
from ech_core.domain.models import (
    ChunkRecord,
    DocumentRecord,
    DocumentUpsert,
    EmbeddingRecord,
    EntityMention,
    GraphChunkPayload,
    GraphContributorPayload,
    GraphDependencyPayload,
    GraphDocumentPayload,
    GraphMentionPayload,
    GraphReferencePayload,
    IngestionRunRecord,
)
from ech_core.embeddings.base import EmbeddingProvider
from ech_core.exceptions import (
    ConflictError,
    InvalidRequestError,
    InvalidRunStateError,
    NotFoundError,
)
from ech_core.logging import get_logger
from ech_core.metrics import (
    GRAPH_SYNC_TOTAL,
    INGESTION_CHUNKS_TOTAL,
    INGESTION_DOCUMENTS_TOTAL,
    INGESTION_RUNS_ACTIVE,
)
from ech_core.repositories import (
    AuditRepository,
    ChunkRepository,
    DocumentRepository,
    EmbeddingRepository,
    GraphRepository,
    IngestionRunRepository,
    SemanticRepository,
)
from ech_core.repositories.lines_repository import LinesRepository
from ech_core.schemas.ingestion import (
    ReconcileResult,
    RunOptions,
    RunStats,
    ScopeItem,
    SourceOptions,
    TriggerRunRequest,
)
from ech_core.semantic.inference import infer_joins
from ech_core.semantic.lines import (
    LineEvidence,
    from_defaults,
    from_tags,
    from_values,
    inherit,
    line_columns,
)
from ech_core.semantic.models import SemanticAsset
from ech_core.text import content_hash, normalize_text, truncate
from ingestion_service.chunking import ChunkingConfig, SemanticChunker, TextChunk
from ingestion_service.connectors.base import BaseConnector, ConnectorOptions, SourceDocument
from ingestion_service.connectors.registry import ConnectorRegistry
from ingestion_service.extraction import EntityExtractor, RuleBasedEntityExtractor
from ingestion_service.services.event_bus import EventBus, RunEvent
from ingestion_service.services.run_manager import RunHandle, RunManager

log = get_logger(__name__)

_DEPENDS_RE = re.compile(r"([A-Z][\w ]+?) depends on ([^.:\n]+)")


@dataclass
class DocumentOutcome:
    document_id: UUID
    changed: bool
    skipped: bool
    chunks: int = 0
    embeddings: int = 0
    entities: int = 0
    graph_synced: bool = False
    graph_error: str | None = None
    graph_sync_status: GraphSyncStatus = GraphSyncStatus.PENDING


@dataclass
class RunContext:
    run_id: UUID
    connector: BaseConnector
    options: RunOptions
    scope: list[ScopeItem] = field(default_factory=list)
    source_options: SourceOptions = field(default_factory=SourceOptions)
    pipeline_id: UUID | None = None
    stats: RunStats = field(default_factory=RunStats)
    status: RunStatus = RunStatus.QUEUED
    last_flush: float = 0.0
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)


class PipelineService:
    def __init__(
        self,
        *,
        settings: Settings,
        pg: PostgresDatabase,
        documents: DocumentRepository,
        chunks: ChunkRepository,
        embeddings: EmbeddingRepository,
        runs: IngestionRunRepository,
        audit: AuditRepository,
        graph: GraphRepository,
        embedder: EmbeddingProvider,
        registry: ConnectorRegistry,
        event_bus: EventBus,
        run_manager: RunManager,
        extractor: EntityExtractor | None = None,
        semantic: SemanticRepository | None = None,
        lines: LinesRepository | None = None,
    ) -> None:
        self._settings = settings
        self._pg = pg
        self._semantic = semantic
        self._lines = lines
        self._documents = documents
        self._chunks = chunks
        self._embeddings = embeddings
        self._runs = runs
        self._audit = audit
        self._graph = graph
        self._embedder = embedder
        self._registry = registry
        self._bus = event_bus
        self._run_manager = run_manager
        self._extractor = extractor or self._default_extractor(registry)
        self._graph_gate = asyncio.Semaphore(settings.graph_sync_concurrency)

    @staticmethod
    def _default_extractor(registry: ConnectorRegistry) -> EntityExtractor:
        projects: set[str] = set()
        people: set[str] = set()
        for connector in registry:
            for ent in connector.known_entities():
                if ent.entity_type is EntityType.PROJECT:
                    projects.add(ent.name)
                elif ent.entity_type is EntityType.PERSON:
                    people.add(ent.name)
        return RuleBasedEntityExtractor(projects=sorted(projects), people=sorted(people))

    # ================================================================== run control
    async def trigger(self, request: TriggerRunRequest) -> IngestionRunRecord:
        connector = self._registry.get(request.connector)
        if self._run_manager.active_for_connector(connector.name) is not None:
            raise ConflictError(
                f"Connector '{connector.name}' already has an active run",
                details={"connector": connector.name},
            )
        config = request.options.model_dump(exclude_none=True)
        if request.scope:
            config["scope"] = [i.model_dump() for i in request.scope]
        source_options = request.source_options.model_dump(exclude_none=True)
        if source_options:
            config["source_options"] = source_options
        run = await self._runs.create(
            connector_name=connector.name,
            source_system=connector.source_system,
            config=config,
            triggered_by=request.triggered_by or "api",
            pipeline_id=request.pipeline_id,
        )
        handle = self._run_manager.register(run.id, connector.name)
        ctx = RunContext(
            run_id=run.id,
            connector=connector,
            options=request.options,
            scope=request.scope,
            source_options=request.source_options,
            pipeline_id=request.pipeline_id,
        )
        self._run_manager.start(handle, lambda: self._execute(ctx, handle))
        await self._audit.record(
            action="pipeline.trigger",
            resource_type="ingestion_run",
            resource_id=str(run.id),
            actor=request.triggered_by,
            details={
                "connector": connector.name,
                "options": request.options.model_dump(),
                "scope_items": len(request.scope),
                "pipeline_id": str(request.pipeline_id) if request.pipeline_id else None,
            },
        )
        return run

    async def pause(self, run_id: UUID) -> IngestionRunRecord:
        run = await self._require_run(run_id)
        if run.status is not RunStatus.RUNNING:
            raise InvalidRunStateError(f"Cannot pause a run in state '{run.status}'")
        self._run_manager.pause(run_id)
        updated = await self._runs.set_status(run_id, RunStatus.PAUSED)
        self._emit_simple(run_id, RunStatus.PAUSED, "run.paused", "Run paused by operator")
        return updated or run

    async def resume(self, run_id: UUID) -> IngestionRunRecord:
        run = await self._require_run(run_id)
        if run.status is not RunStatus.PAUSED:
            raise InvalidRunStateError(f"Cannot resume a run in state '{run.status}'")
        self._run_manager.resume(run_id)
        updated = await self._runs.set_status(run_id, RunStatus.RUNNING)
        self._emit_simple(run_id, RunStatus.RUNNING, "run.resumed", "Run resumed")
        return updated or run

    async def cancel(self, run_id: UUID) -> IngestionRunRecord:
        run = await self._require_run(run_id)
        if run.status.is_terminal:
            raise InvalidRunStateError(f"Run already finished with state '{run.status}'")
        self._run_manager.cancel(run_id)
        self._emit_simple(run_id, run.status, "run.cancelling", "Cancellation requested")
        return run

    async def _require_run(self, run_id: UUID) -> IngestionRunRecord:
        run = await self._runs.get(run_id)
        if run is None:
            raise NotFoundError("Run not found", details={"run_id": str(run_id)})
        return run

    # ================================================================== run execution
    async def _execute(self, ctx: RunContext, handle: RunHandle) -> None:
        INGESTION_RUNS_ACTIVE.inc()
        final_status = RunStatus.COMPLETED
        error: str | None = None
        started = time.perf_counter()
        connector_options = ConnectorOptions(
            limit=ctx.options.limit,
            full_refresh=ctx.options.full_refresh,
            simulate_failures=ctx.options.simulate_failures,
            scope=ctx.scope,
            source_options=ctx.source_options,
        )
        try:
            await self._set_status(ctx, RunStatus.RUNNING, mark_started=True)
            ctx.stats.estimated_total = await ctx.connector.estimate_count(connector_options)
            await self._emit(
                ctx,
                "run.started",
                f"Run started for connector '{ctx.connector.name}'",
                payload={"estimated_total": ctx.stats.estimated_total},
                persist=True,
            )

            queue: asyncio.Queue[SourceDocument | None] = asyncio.Queue(
                maxsize=self._settings.ingestion_concurrency * 2
            )
            workers = [
                asyncio.create_task(self._worker(ctx, handle, queue), name=f"worker-{i}")
                for i in range(self._settings.ingestion_concurrency)
            ]

            try:
                async for doc in ctx.connector.iter_documents(connector_options):
                    if handle.cancelling:
                        break
                    await self._wait_if_paused(handle)
                    if handle.cancelling:
                        break
                    await queue.put(doc)
            finally:
                for _ in workers:
                    await queue.put(None)
                await asyncio.gather(*workers)

            if handle.cancelling:
                final_status = RunStatus.CANCELLED
            else:
                await self._finalize_semantic(ctx)
                await self._finalize_lines(ctx)
        except asyncio.CancelledError:
            final_status = RunStatus.CANCELLED
            error = "Task cancelled during shutdown"
        except Exception as exc:  # noqa: BLE001 - any failure fails the run, with context
            final_status = RunStatus.FAILED
            error = f"{type(exc).__name__}: {exc}"
            log.exception("run.failed", run_id=str(ctx.run_id), connector=ctx.connector.name)
        finally:
            INGESTION_RUNS_ACTIVE.dec()
            await self._flush_stats(ctx, force=True)
            await self._set_status(ctx, final_status, error=error, mark_finished=True)
            duration = round(time.perf_counter() - started, 3)
            level = EventLevel.ERROR if final_status is RunStatus.FAILED else EventLevel.INFO
            await self._emit(
                ctx,
                f"run.{final_status.value}",
                f"Run {final_status.value} in {duration}s "
                f"({ctx.stats.documents_upserted} upserted, {ctx.stats.documents_skipped} skipped, "
                f"{ctx.stats.documents_failed} failed)",
                level=level,
                payload={"duration_seconds": duration, "error": error},
                persist=True,
            )
            await self._audit.record(
                action="pipeline.finished",
                status="ok" if final_status is RunStatus.COMPLETED else "error",
                resource_type="ingestion_run",
                resource_id=str(ctx.run_id),
                latency_ms=duration * 1000,
                details={
                    "status": final_status.value,
                    "stats": ctx.stats.model_dump(),
                    "error": error,
                },
            )

    async def _worker(
        self, ctx: RunContext, handle: RunHandle, queue: asyncio.Queue[SourceDocument | None]
    ) -> None:
        while True:
            item = await queue.get()
            if item is None:
                return
            if handle.cancelling:
                continue  # drain the queue without processing
            await self._wait_if_paused(handle)
            if handle.cancelling:
                continue
            try:
                outcome = await self.process_document(
                    item, ctx.connector.source_system, ctx=ctx, options=ctx.options
                )
            except Exception as exc:  # noqa: BLE001 - one bad document must not kill the run
                async with ctx.lock:
                    ctx.stats.documents_failed += 1
                    ctx.stats.documents_seen += 1
                INGESTION_DOCUMENTS_TOTAL.labels(ctx.connector.name, "failed").inc()
                log.warning(
                    "document.failed",
                    run_id=str(ctx.run_id),
                    external_id=item.external_id,
                    error=str(exc),
                )
                await self._emit(
                    ctx,
                    "document.failed",
                    f"Failed: {item.title}",
                    level=EventLevel.ERROR,
                    payload={
                        "external_id": item.external_id,
                        "error": f"{type(exc).__name__}: {exc}",
                    },
                    persist=True,
                )
            else:
                async with ctx.lock:
                    ctx.stats.documents_seen += 1
                    if outcome.skipped:
                        ctx.stats.documents_skipped += 1
                    else:
                        ctx.stats.documents_upserted += 1
                        ctx.stats.chunks_created += outcome.chunks
                        ctx.stats.embeddings_created += outcome.embeddings
                        ctx.stats.entities_linked += outcome.entities
                    if outcome.graph_synced:
                        ctx.stats.graph_synced += 1
                    elif not outcome.skipped:
                        ctx.stats.graph_failed += 1
                INGESTION_DOCUMENTS_TOTAL.labels(
                    ctx.connector.name, "skipped" if outcome.skipped else "upserted"
                ).inc()
                if outcome.skipped:
                    await self._emit(
                        ctx,
                        "document.skipped",
                        f"Unchanged: {item.title}",
                        level=EventLevel.DEBUG,
                        payload={"document_id": str(outcome.document_id)},
                    )
                else:
                    await self._emit(
                        ctx,
                        "document.upserted",
                        f"Indexed: {item.title}",
                        payload={
                            "document_id": str(outcome.document_id),
                            "chunks": outcome.chunks,
                            "entities": outcome.entities,
                            "graph_synced": outcome.graph_synced,
                        },
                    )
                if outcome.graph_error:
                    await self._emit(
                        ctx,
                        "graph.failed",
                        f"Graph sync failed: {item.title}",
                        level=EventLevel.WARNING,
                        payload={
                            "document_id": str(outcome.document_id),
                            "error": outcome.graph_error,
                        },
                        persist=True,
                    )
            finally:
                await self._flush_stats(ctx)

    @staticmethod
    async def _wait_if_paused(handle: RunHandle) -> None:
        if not handle.pause_event.is_set():
            await handle.pause_event.wait()

    # ================================================================== document processing
    async def process_document(
        self,
        src: SourceDocument,
        source_system: SourceSystem,
        *,
        ctx: RunContext | None = None,
        options: RunOptions | None = None,
    ) -> DocumentOutcome:
        """Process one document end-to-end. Safe to call outside a run (manual ingest)."""
        options = options or RunOptions()
        content = normalize_text(src.content)
        if not content:
            raise InvalidRequestError(
                "Document has no textual content", details={"external_id": src.external_id}
            )
        chash = content_hash(content)
        doc_id = ids.document_id(source_system.value, src.external_id)
        # The structured semantic payload lives in its own tables, not in documents.attributes.
        semantic_payload = src.attributes.get("semantic")
        attributes: dict[str, Any] = {
            **{k: v for k, v in src.attributes.items() if k != "semantic"},
            "contributors": list(dict.fromkeys(c for c in src.contributors if c)),
            "references": list(dict.fromkeys(r for r in src.references if r)),
        }
        upsert = DocumentUpsert(
            id=doc_id,
            source_system=source_system,
            # A document that carries a semantic asset is a dataset to its readers.
            kind=DocumentKind.DATASET if semantic_payload is not None else src.kind,
            external_id=src.external_id,
            title=src.title.strip() or src.external_id,
            uri=src.uri,
            author=src.author,
            mime_type=src.mime_type,
            language=src.language,
            content_hash=chash,
            content_length=len(content),
            attributes=attributes,
            source_created_at=src.source_created_at,
            source_updated_at=src.source_updated_at,
            last_run_id=ctx.run_id if ctx else None,
        )

        # 1. metadata upsert + change detection -----------------------------------
        async with self._pg.transaction() as conn:
            existing = await self._documents.get_for_update(conn, doc_id)
            changed = existing is None or existing.content_hash != chash or options.full_refresh
            record = await self._documents.upsert(conn, upsert, content_changed=changed)
            if semantic_payload is not None and self._semantic is not None:
                await self._semantic.upsert_asset(
                    conn,
                    document_id=doc_id,
                    source_system=source_system,
                    asset=SemanticAsset.model_validate(semantic_payload),
                )

        if not changed and record.graph_sync_status is GraphSyncStatus.SYNCED:
            return DocumentOutcome(
                document_id=doc_id,
                changed=False,
                skipped=True,
                graph_synced=True,
                graph_sync_status=GraphSyncStatus.SYNCED,
            )

        # 2./3. chunk, extract, embed, persist --------------------------------------
        connector_label = ctx.connector.name if ctx else source_system.value
        if changed:
            text_chunks = self._chunker(options).chunk(content)
            if not text_chunks:  # defensive: chunker returns [] only for whitespace input
                text_chunks = [TextChunk(0, content, max(1, len(content.split())), 0, len(content))]
            chunk_records, mentions = self._build_chunks(doc_id, text_chunks, src)
            vectors = await self._embedder.embed_texts(
                [self._embedding_text(c) for c in chunk_records]
            )
            embedding_records = [
                EmbeddingRecord(
                    chunk_id=c.id,
                    model=self._embedder.model_id,
                    dimensions=self._embedder.dimensions,
                    vector=v,
                )
                for c, v in zip(chunk_records, vectors, strict=True)
            ]
            async with self._pg.transaction() as conn:
                await self._chunks.replace_for_document(conn, doc_id, chunk_records)
                await self._embeddings.upsert_many(conn, embedding_records)
                await self._documents.set_graph_pending(conn, doc_id)
            INGESTION_CHUNKS_TOTAL.labels(connector_label).inc(len(chunk_records))
        else:
            chunk_records = await self._chunks.list_for_document(doc_id)
            mentions = self._mentions_from_metadata(chunk_records)
            embedding_records = []

        # 4. graph sync --------------------------------------------------------------
        payload = self._graph_payload(record, chunk_records, mentions)
        graph_synced, graph_error = await self._sync_graph(doc_id, payload)
        return DocumentOutcome(
            document_id=doc_id,
            changed=changed,
            skipped=False,
            chunks=len(chunk_records),
            embeddings=len(embedding_records),
            entities=sum(len(v) for v in mentions.values()),
            graph_synced=graph_synced,
            graph_error=graph_error,
            graph_sync_status=GraphSyncStatus.SYNCED if graph_synced else GraphSyncStatus.FAILED,
        )

    async def delete_document(self, document_id: UUID) -> None:
        record = await self._documents.get(document_id, include_counts=False)
        if record is None:
            raise NotFoundError("Document not found", details={"document_id": str(document_id)})
        # Graph first: if it fails the PG row stays and reconcile can retry; the
        # reverse order would leave orphaned graph nodes with no marker.
        await self._graph.delete_document(document_id)
        await self._documents.delete(document_id)
        # Entities only referenced by the deleted document would otherwise linger.
        await self._graph.delete_orphan_entities()
        await self._audit.record(
            action="document.delete",
            resource_type="document",
            resource_id=str(document_id),
            details={
                "external_id": record.external_id,
                "source_system": record.source_system.value,
            },
        )

    async def reconcile_graph(self, *, limit: int = 100) -> ReconcileResult:
        """Retry Neo4j sync for every document that is not ``synced``."""
        pending = await self._documents.list_graph_unsynced(limit=limit)
        synced = failed = 0
        for record in pending:
            chunk_records = await self._chunks.list_for_document(record.id)
            mentions = self._mentions_from_metadata(chunk_records)
            ok, _ = await self._sync_graph(
                record.id, self._graph_payload(record, chunk_records, mentions)
            )
            synced += int(ok)
            failed += int(not ok)
        pruned = await self._graph.prune_dangling_dependencies()
        if pruned:
            log.warning("graph.dangling_dependencies_pruned", edges=pruned)
        orphans = await self._graph.delete_orphan_entities()
        log.info(
            "graph.reconcile", scanned=len(pending), synced=synced, failed=failed, orphans=orphans
        )
        await self._audit.record(
            action="graph.reconcile",
            details={
                "scanned": len(pending),
                "synced": synced,
                "failed": failed,
                "orphans": orphans,
            },
        )
        return ReconcileResult(
            scanned=len(pending), synced=synced, failed=failed, orphan_entities_removed=orphans
        )

    # ================================================================== building blocks
    def _chunker(self, options: RunOptions) -> SemanticChunker:
        s = self._settings
        target = options.chunk_target_tokens or s.chunk_target_tokens
        return SemanticChunker(
            ChunkingConfig(
                target_tokens=target,
                max_tokens=max(s.chunk_max_tokens, target),
                min_tokens=min(s.chunk_min_tokens, target),
                overlap_tokens=(
                    options.chunk_overlap_tokens
                    if options.chunk_overlap_tokens is not None
                    else s.chunk_overlap_tokens
                ),
                overlap_strategy=s.chunk_overlap_strategy,
            )
        )

    def _build_chunks(
        self, doc_id: UUID, text_chunks: Sequence[TextChunk], src: SourceDocument
    ) -> tuple[list[ChunkRecord], dict[UUID, list[EntityMention]]]:
        explicit = [
            EntityMention(
                key=ids.entity_key(e.entity_type.value, e.name),
                name=e.name,
                entity_type=e.entity_type,
                normalized_name=ids.normalize_entity_name(e.name),
                confidence=e.confidence,
            )
            for e in src.explicit_entities
        ]
        records: list[ChunkRecord] = []
        mentions: dict[UUID, list[EntityMention]] = {}
        for tc in text_chunks:
            cid = ids.chunk_id(doc_id, tc.index)
            found: dict[str, EntityMention] = {}
            for e in self._extractor.extract(tc.content, section_path=tc.section_path):
                key = ids.entity_key(e.entity_type.value, e.name)
                found[key] = EntityMention(
                    key=key,
                    name=e.name,
                    entity_type=e.entity_type,
                    normalized_name=e.normalized_name,
                    confidence=e.confidence,
                )
            lowered = tc.content.casefold()
            for ex in explicit:
                # Explicit (metadata) entities attach where they appear textually and
                # always to the first chunk so the document is linked even if the
                # body never spells the name out.
                if tc.index == 0 or ex.normalized_name in lowered:
                    prev = found.get(ex.key)
                    if prev is None or prev.confidence < ex.confidence:
                        found[ex.key] = ex
            ordered = sorted(found.values(), key=lambda m: (-m.confidence, m.key))
            mentions[cid] = ordered
            records.append(
                ChunkRecord(
                    id=cid,
                    document_id=doc_id,
                    chunk_index=tc.index,
                    content=tc.content,
                    token_count=tc.token_count,
                    char_start=tc.char_start,
                    char_end=tc.char_end,
                    section_path=list(tc.section_path),
                    metadata={
                        "entities": [m.model_dump(mode="json") for m in ordered],
                        "overlap_tokens": tc.overlap_tokens,
                    },
                )
            )
        return records, mentions

    @staticmethod
    def _mentions_from_metadata(chunks: Sequence[ChunkRecord]) -> dict[UUID, list[EntityMention]]:
        out: dict[UUID, list[EntityMention]] = {}
        for c in chunks:
            out[c.id] = [EntityMention.model_validate(m) for m in c.metadata.get("entities", [])]
        return out

    @staticmethod
    def _embedding_text(chunk: ChunkRecord) -> str:
        """Prefix the heading path so embeddings carry document structure."""
        if chunk.section_path:
            return f"{' > '.join(chunk.section_path)}\n{chunk.content}"
        return chunk.content

    def _graph_payload(
        self,
        record: DocumentRecord,
        chunks: Sequence[ChunkRecord],
        mentions: dict[UUID, list[EntityMention]],
    ) -> GraphDocumentPayload:
        contributors: list[str] = list(record.attributes.get("contributors") or [])
        if record.author and record.author not in contributors:
            contributors.insert(0, record.author)
        references: list[str] = [
            r for r in (record.attributes.get("references") or []) if r != record.external_id
        ]
        # Semantic connectors label their references (foreign_key, lineage_upstream, ...).
        reference_kinds: dict[str, str] = record.attributes.get("reference_kinds") or {}
        return GraphDocumentPayload(
            document_id=record.id,
            external_id=record.external_id,
            source_system=record.source_system,
            title=record.title,
            uri=record.uri,
            author=record.author,
            version=record.version,
            mime_type=record.mime_type,
            chunks=[
                GraphChunkPayload(
                    chunk_id=c.id,
                    chunk_index=c.chunk_index,
                    token_count=c.token_count,
                    section_path=c.section_path,
                    preview=truncate(c.content, 160),
                )
                for c in chunks
            ],
            mentions=[
                GraphMentionPayload(
                    chunk_id=c.id,
                    key=m.key,
                    name=m.name,
                    entity_type=m.entity_type,
                    normalized_name=m.normalized_name,
                    confidence=m.confidence,
                )
                for c in chunks
                for m in mentions.get(c.id, [])
            ],
            contributors=[
                GraphContributorPayload(
                    key=ids.entity_key(EntityType.PERSON.value, name),
                    name=name,
                    normalized_name=ids.normalize_entity_name(name),
                    role="author" if name == record.author else "contributor",
                )
                for name in dict.fromkeys(contributors)
            ],
            references=[
                GraphReferencePayload(
                    document_id=ids.document_id(record.source_system.value, ext),
                    external_id=ext,
                    source_system=record.source_system,
                    kind=str(reference_kinds.get(ext, "link")),
                )
                for ext in dict.fromkeys(references)
            ],
            dependencies=self._derive_dependencies(chunks, mentions),
        )

    async def _finalize_semantic(self, ctx: RunContext) -> None:
        """After a semantic connector run: infer name-based joins across the whole scope."""
        if self._semantic is None:
            return
        source_system = ctx.connector.source_system
        if source_system not in (SourceSystem.SNOWFLAKE, SourceSystem.DATABRICKS):
            return
        try:
            await self._semantic.resolve_relationship_targets(source_system)
            if not self._settings.semantic_infer_joins:
                return
            loaded = await self._semantic.load_assets(source_system=source_system)
            joins = infer_joins(asset for _, asset in loaded)
            by_fqn = {asset.fqn: asset_id for asset_id, asset in loaded}
            stored = await self._semantic.replace_inferred_joins(
                source_system, {by_fqn[fqn]: rels for fqn, rels in joins.items() if fqn in by_fqn}
            )
            await self._semantic.resolve_relationship_targets(source_system)
        except Exception as exc:  # noqa: BLE001 - inference must never fail the run
            log.warning("semantic.join_inference_failed", run_id=str(ctx.run_id), error=str(exc))
            return
        await self._emit(
            ctx,
            "run.progress",
            f"Semantic layer: {stored} inferred joins across {len(loaded)} assets",
            payload={"semantic_assets": len(loaded), "inferred_joins": stored},
            persist=True,
        )

    async def _finalize_lines(self, ctx: RunContext) -> None:
        """After a semantic run: decide which lines of business each dataset of the source holds."""
        if self._lines is None or self._semantic is None:
            return
        source_system = ctx.connector.source_system
        if source_system not in (SourceSystem.SNOWFLAKE, SourceSystem.DATABRICKS):
            return
        try:
            summary = await self._decide_lines(ctx.connector, source_system.value)
        except Exception as exc:  # noqa: BLE001 - a facet must never fail the run
            log.warning("lines.failed", run_id=str(ctx.run_id), error=str(exc))
            return
        if summary:
            await self._emit(ctx, "run.progress", summary, persist=True)

    async def _decide_lines(self, connector: BaseConnector, source_system: str) -> str | None:
        """Tags, then a pipeline default, then a line-of-business column's values; the rest inherit or stay shared."""
        repo = self._lines
        assert repo is not None
        vocab = await repo.vocabulary()
        if not vocab.values:
            return None
        inputs = await repo.inputs(source_system)
        defaults = await repo.pipeline_defaults(source_system)
        fields_of: dict[UUID, list[dict[str, Any]]] = defaultdict(list)
        for f in inputs["fields"]:
            fields_of[f["asset_id"]].append(f)
        direct: dict[UUID, LineEvidence] = {}
        unknown: set[str] = set()
        for asset in inputs["assets"]:
            fields = fields_of[asset["id"]]
            found = from_tags([*asset["tags"], *(t for f in fields for t in f["tags"])], vocab) or from_defaults(asset["fqn"], defaults, vocab)
            for column in [] if found else line_columns(fields, vocab, inputs["linked"]):
                try:
                    values = await connector.distinct_values(asset["fqn"], column)
                except Exception as exc:  # noqa: BLE001 - one table's query must not stop the rest
                    log.warning("lines.values_failed", fqn=asset["fqn"], column=column, error=str(exc)[:200])
                    continue
                if values is None:
                    break
                found, rest = from_values(column, values, vocab)
                unknown.update(rest)
                if found:
                    break
            if found:
                direct[asset["id"]] = found
        parents: dict[UUID, list[UUID]] = defaultdict(list)
        for child, parent in inputs["edges"]:
            parents[child].append(parent)
        names = {a["id"]: a["fqn"].split(".", 1)[-1] for a in inputs["assets"]}
        inherited = inherit(direct, parents, names)
        await repo.replace(source_system, {**direct, **inherited})
        by_source = Counter(ev.source for ev in direct.values())
        total = len(inputs["assets"])
        summary = (
            f"Line of business: {len(direct) + len(inherited)} of {total} datasets "
            f"({by_source['tag']} from tags, {by_source['pipeline']} from a pipeline default, "
            f"{by_source['values']} from column values, {len(inherited)} inherited), "
            f"{total - len(direct) - len(inherited)} shared across lines"
        )
        if unknown:
            summary += f"; values no line matches: {', '.join(sorted(unknown)[:5])}"
        return summary

    @staticmethod
    def _derive_dependencies(
        chunks: Sequence[ChunkRecord], mentions: dict[UUID, list[EntityMention]]
    ) -> list[GraphDependencyPayload]:
        """Infer DEPENDS_ON edges from co-mentions and explicit "X depends on Y" phrases."""
        weights: dict[tuple[str, str], float] = defaultdict(float)
        for c in chunks:
            ments = mentions.get(c.id, [])
            projects = [m for m in ments if m.entity_type is EntityType.PROJECT]
            techs = [m for m in ments if m.entity_type is EntityType.TECHNOLOGY]
            if projects and techs:
                share = 1.0 / len(projects)
                for p in projects:
                    for t in techs:
                        weights[(p.key, t.key)] += share
            if len(projects) >= 2:
                by_norm = {p.normalized_name: p for p in projects}
                for m in _DEPENDS_RE.finditer(c.content):
                    subject = ids.normalize_entity_name(m.group(1))
                    obj = m.group(2).casefold()
                    src = by_norm.get(subject)
                    if src is None:
                        continue
                    for norm, target in by_norm.items():
                        if norm != subject and norm in obj:
                            weights[(src.key, target.key)] += 2.0
        return [
            GraphDependencyPayload(from_key=a, to_key=b, weight=round(w, 3))
            for (a, b), w in weights.items()
        ]

    async def _sync_graph(
        self, doc_id: UUID, payload: GraphDocumentPayload
    ) -> tuple[bool, str | None]:
        try:
            async with self._graph_gate:
                node_id = await self._graph.sync_document(payload)
        except Exception as exc:  # noqa: BLE001 - recorded, retried by reconcile
            error = f"{type(exc).__name__}: {exc}"
            log.warning("graph.sync_failed", document_id=str(doc_id), error=error)
            GRAPH_SYNC_TOTAL.labels("failed").inc()
            await self._documents.mark_graph_failed(doc_id, error)
            return False, error
        await self._documents.mark_graph_synced(doc_id, node_id)
        GRAPH_SYNC_TOTAL.labels("synced").inc()
        return True, None

    # ================================================================== status / events
    async def _set_status(
        self,
        ctx: RunContext,
        status: RunStatus,
        *,
        error: str | None = None,
        mark_started: bool = False,
        mark_finished: bool = False,
    ) -> None:
        ctx.status = status
        await self._runs.set_status(
            ctx.run_id, status, error=error, mark_started=mark_started, mark_finished=mark_finished
        )

    async def _flush_stats(self, ctx: RunContext, *, force: bool = False) -> None:
        now = time.monotonic()
        if (
            not force
            and now - ctx.last_flush < self._settings.ingestion_stats_flush_interval_seconds
        ):
            return
        ctx.last_flush = now
        async with ctx.lock:
            snapshot = ctx.stats.model_dump()
        await self._runs.merge_stats(ctx.run_id, snapshot)
        self._bus.publish(
            RunEvent(
                run_id=ctx.run_id,
                level="debug",
                event_type="run.progress",
                message=f"{snapshot['documents_seen']} documents processed",
                stats=snapshot,
                status=ctx.status.value,
            )
        )

    async def _emit(
        self,
        ctx: RunContext,
        event_type: str,
        message: str,
        *,
        level: EventLevel = EventLevel.INFO,
        payload: dict[str, Any] | None = None,
        persist: bool = False,
    ) -> None:
        event = RunEvent(
            run_id=ctx.run_id,
            level=level.value,
            event_type=event_type,
            message=message,
            payload=payload or {},
            stats=ctx.stats.model_dump(),
            status=ctx.status.value,
            created_at=datetime.now(tz=UTC),
        )
        self._bus.publish(event)
        if persist:
            await self._runs.append_event(
                ctx.run_id,
                level=level.value,
                event_type=event_type,
                message=message,
                payload=payload or {},
            )

    def _emit_simple(self, run_id: UUID, status: RunStatus, event_type: str, message: str) -> None:
        self._bus.publish(
            RunEvent(run_id=run_id, event_type=event_type, message=message, status=status.value)
        )
