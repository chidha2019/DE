"""Aggregates all v1 routers under ``/api/v1``."""

from fastapi import APIRouter

from ingestion_service.api import admin, connectors, documents, events, pipelines, repo_graph

api_router = APIRouter(prefix="/api/v1")
api_router.include_router(connectors.router)
api_router.include_router(pipelines.router)
api_router.include_router(documents.router)
api_router.include_router(events.router)
api_router.include_router(admin.router)
api_router.include_router(repo_graph.router)
