"""Ad-hoc document ingestion and deletion."""

from __future__ import annotations

import re
from uuid import UUID

from fastapi import APIRouter, Response, status

from ech_core.domain.enums import SourceSystem
from ech_core.schemas.documents import DocumentIngestResult, ManualDocumentIn
from ingestion_service.connectors.base import SourceDocument
from ingestion_service.dependencies import ContainerDep

router = APIRouter(prefix="/documents", tags=["documents"])

_SLUG_RE = re.compile(r"[^a-z0-9]+")


def _slug(title: str) -> str:
    return _SLUG_RE.sub("-", title.lower()).strip("-")[:120] or "untitled"


@router.post(
    "",
    status_code=status.HTTP_201_CREATED,
    response_model=DocumentIngestResult,
    summary="Ingest a document directly (source_system = manual)",
)
async def ingest_document(body: ManualDocumentIn, container: ContainerDep) -> DocumentIngestResult:
    src = SourceDocument(
        external_id=body.external_id or _slug(body.title),
        title=body.title,
        content=body.content,
        uri=body.uri,
        author=body.author,
        attributes={**body.attributes, "ingest": "manual"},
        contributors=body.contributors,
        references=body.references,
    )
    outcome = await container.pipeline.process_document(src, SourceSystem.MANUAL)
    await container.audit.record(
        action="document.ingest",
        resource_type="document",
        resource_id=str(outcome.document_id),
        details={"external_id": src.external_id, "changed": outcome.changed},
    )
    return DocumentIngestResult(
        document_id=outcome.document_id,
        changed=outcome.changed,
        chunks=outcome.chunks,
        embeddings=outcome.embeddings,
        entities=outcome.entities,
        graph_sync_status=outcome.graph_sync_status,
    )


@router.delete(
    "/{document_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete a document from Postgres and Neo4j",
)
async def delete_document(document_id: UUID, container: ContainerDep) -> Response:
    await container.pipeline.delete_document(document_id)
    return Response(status_code=status.HTTP_204_NO_CONTENT)
