"""Server-Sent Events feed of pipeline progress.

Protocol: standard ``text/event-stream``. Each message has ``id`` (monotonic
sequence), ``event`` (e.g. ``run.progress``) and a JSON ``data`` payload matching
``RunEvent``. A comment line is sent every 15 s as a heartbeat.
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from uuid import UUID

from fastapi import APIRouter, Query, Request
from fastapi.responses import StreamingResponse

from ingestion_service.dependencies import ContainerDep
from ingestion_service.services.event_bus import EventBus

router = APIRouter(prefix="/events", tags=["events"])

_HEARTBEAT_SECONDS = 15


async def _stream(
    request: Request, bus: EventBus, *, run_id: UUID | None, replay: int
) -> AsyncIterator[str]:
    async with bus.subscribe(run_id=run_id, replay=replay) as queue:
        yield "retry: 3000\n\n"
        while True:
            if await request.is_disconnected():
                return
            try:
                event = await asyncio.wait_for(queue.get(), timeout=_HEARTBEAT_SECONDS)
            except TimeoutError:
                yield ": keep-alive\n\n"
                continue
            yield f"id: {event.seq}\nevent: {event.event_type}\ndata: {event.model_dump_json()}\n\n"


@router.get(
    "/stream",
    summary="Live pipeline events (SSE)",
    response_class=StreamingResponse,
    responses={200: {"content": {"text/event-stream": {}}}},
)
async def stream_events(
    request: Request,
    container: ContainerDep,
    run_id: UUID | None = Query(default=None, description="Only events for this run"),
    replay: int = Query(default=25, ge=0, le=500, description="Recent events to replay first"),
) -> StreamingResponse:
    return StreamingResponse(
        _stream(request, container.event_bus, run_id=run_id, replay=replay),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache, no-transform",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",  # disable proxy buffering (nginx)
        },
    )
