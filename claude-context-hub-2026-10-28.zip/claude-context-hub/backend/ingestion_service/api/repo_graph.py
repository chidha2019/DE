"""Repository graphs for the Knowledge Hub: crawl a GitHub repository into a typed knowledge graph and explore it."""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Query, status

from ech_core.exceptions import NotFoundError
from ech_core.schemas.repo_graph import (
    RepoCrawlCreate,
    RepoCrawlOut,
    RepoGraphPayload,
    RepoGraphRepos,
    RepoNodeDetail,
)
from ingestion_service.dependencies import ContainerDep

router = APIRouter(prefix="/repo-graph", tags=["repo-graph"])

_REPO = Query(min_length=3, max_length=300, description="owner/name")


@router.get("/repos", response_model=RepoGraphRepos, summary="Crawled and configured repositories")
async def list_repos(container: ContainerDep) -> RepoGraphRepos:
    return await container.repo_crawler.repos()


@router.delete("/repos", summary="Remove a repository's subgraph")
async def delete_repo(container: ContainerDep, repo: str = _REPO) -> dict[str, int]:
    return {"deleted_nodes": await container.repo_crawler.delete_repo(repo)}


@router.post(
    "/crawls",
    status_code=status.HTTP_202_ACCEPTED,
    response_model=RepoCrawlOut,
    summary="Crawl a repository into the graph",
    responses={409: {"description": "Already being crawled"}, 422: {"description": "Invalid repository"}},
)
async def start_crawl(body: RepoCrawlCreate, container: ContainerDep) -> RepoCrawlOut:
    return await container.repo_crawler.start(body)


@router.get("/crawls", response_model=list[RepoCrawlOut], summary="Crawl history")
async def list_crawls(
    container: ContainerDep,
    repo: str | None = Query(default=None, max_length=300),
    limit: int = Query(default=20, ge=1, le=100),
) -> list[RepoCrawlOut]:
    return await container.repo_crawler.list(repo=repo, limit=limit)


@router.get("/crawls/{crawl_id}", response_model=RepoCrawlOut, summary="One crawl")
async def get_crawl(crawl_id: UUID, container: ContainerDep) -> RepoCrawlOut:
    return await container.repo_crawler.get(crawl_id)


@router.get("/graph", response_model=RepoGraphPayload, summary="Nodes and edges of a crawled repository")
async def get_graph(
    container: ContainerDep,
    repo: str = _REPO,
    view: str = Query(default="all", pattern="^(all|lineage)$"),
    kinds: str | None = Query(default=None, max_length=400, description="comma-separated node kinds"),
    limit: int = Query(default=2500, ge=1, le=5000),
) -> RepoGraphPayload:
    if view == "lineage":
        payload = await container.repo_graph.lineage(repo)
    else:
        chosen = [k.strip() for k in kinds.split(",") if k.strip()] if kinds else None
        payload = await container.repo_graph.graph(repo, kinds=chosen, limit=limit)
    return RepoGraphPayload.model_validate(payload)


@router.get("/node", response_model=RepoNodeDetail, summary="A node with its links, columns and lineage")
async def get_node(container: ContainerDep, key: str = Query(min_length=3, max_length=600)) -> RepoNodeDetail:
    detail = await container.repo_graph.node(key)
    if detail is None:
        raise NotFoundError(f"node {key} not found")
    return RepoNodeDetail.model_validate(detail)


@router.get("/search", response_model=list[dict], summary="Find nodes by name")
async def search(
    container: ContainerDep,
    repo: str = _REPO,
    q: str = Query(min_length=1, max_length=120),
    limit: int = Query(default=20, ge=1, le=100),
) -> list[dict]:
    return await container.repo_graph.search(repo, q, limit)
