"""Pipeline run management: trigger, list, inspect, pause/resume/cancel."""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Query, status

from ech_core.domain.enums import RunStatus
from ech_core.exceptions import NotFoundError
from ech_core.schemas.common import Page
from ech_core.schemas.ingestion import IngestionRunOut, RunEventOut, TriggerRunRequest
from ech_core.schemas.pipelines import (
    PipelineIn,
    PipelineOut,
    PipelineUpdate,
    PreviewRequest,
    PreviewResult,
    ScheduleToggle,
)
from ech_core.schemas.stats import RunActivityPoint
from ingestion_service.dependencies import ContainerDep

router = APIRouter(prefix="/pipelines", tags=["pipelines"])


@router.post(
    "/runs",
    status_code=status.HTTP_202_ACCEPTED,
    response_model=IngestionRunOut,
    summary="Trigger an ingestion run",
    responses={404: {"description": "Unknown connector"}, 409: {"description": "Connector busy"}},
)
async def trigger_run(body: TriggerRunRequest, container: ContainerDep) -> IngestionRunOut:
    run = await container.pipeline.trigger(body)
    return IngestionRunOut.from_record(run)


@router.get("/runs", response_model=Page[IngestionRunOut], summary="List runs")
async def list_runs(
    container: ContainerDep,
    run_status: RunStatus | None = Query(default=None, alias="status"),
    connector: str | None = Query(default=None, max_length=64),
    pipeline_id: UUID | None = Query(default=None),
    limit: int = Query(default=25, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
) -> Page[IngestionRunOut]:
    items, total = await container.runs.list(
        status=run_status, connector_name=connector, pipeline_id=pipeline_id, limit=limit, offset=offset
    )
    return Page(
        items=[IngestionRunOut.from_record(r) for r in items],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.get("/runs/{run_id}", response_model=IngestionRunOut, summary="Get a run")
async def get_run(run_id: UUID, container: ContainerDep) -> IngestionRunOut:
    run = await container.runs.get(run_id)
    if run is None:
        raise NotFoundError("Run not found", details={"run_id": str(run_id)})
    return IngestionRunOut.from_record(run)


@router.get(
    "/runs/{run_id}/events",
    response_model=list[RunEventOut],
    summary="Persisted run events (use /events/stream for live updates)",
)
async def run_events(
    run_id: UUID,
    container: ContainerDep,
    after_id: int = Query(default=0, ge=0),
    limit: int = Query(default=200, ge=1, le=1000),
) -> list[RunEventOut]:
    if await container.runs.get(run_id) is None:
        raise NotFoundError("Run not found", details={"run_id": str(run_id)})
    events = await container.runs.list_events(run_id, after_id=after_id, limit=limit)
    return [RunEventOut.from_record(e) for e in events]


@router.post("/runs/{run_id}/pause", response_model=IngestionRunOut, summary="Pause a run")
async def pause_run(run_id: UUID, container: ContainerDep) -> IngestionRunOut:
    return IngestionRunOut.from_record(await container.pipeline.pause(run_id))


@router.post("/runs/{run_id}/resume", response_model=IngestionRunOut, summary="Resume a run")
async def resume_run(run_id: UUID, container: ContainerDep) -> IngestionRunOut:
    return IngestionRunOut.from_record(await container.pipeline.resume(run_id))


@router.post("/runs/{run_id}/cancel", response_model=IngestionRunOut, summary="Cancel a run")
async def cancel_run(run_id: UUID, container: ContainerDep) -> IngestionRunOut:
    return IngestionRunOut.from_record(await container.pipeline.cancel(run_id))


@router.get(
    "/activity",
    response_model=list[RunActivityPoint],
    summary="Run outcomes bucketed over time (dashboard chart)",
)
async def activity(
    container: ContainerDep,
    hours: int = Query(default=24, ge=1, le=24 * 30),
    bucket_minutes: int = Query(default=60, ge=5, le=24 * 60),
) -> list[RunActivityPoint]:
    return await container.runs.activity(hours=hours, bucket_minutes=bucket_minutes)


# --------------------------------------------------------------------------- pipeline definitions
# Declared after the static /runs and /activity routes so those keep matching first.
@router.get("", response_model=list[PipelineOut], summary="List saved pipelines")
async def list_pipelines(
    container: ContainerDep,
    connector: str | None = Query(default=None, max_length=64),
    search: str | None = Query(default=None, max_length=200),
) -> list[PipelineOut]:
    return await container.pipeline_defs.list(connector=connector, search=search)


@router.post(
    "",
    status_code=status.HTTP_201_CREATED,
    response_model=PipelineOut,
    summary="Create a pipeline on a saved connection",
    responses={404: {"description": "Unknown connector"}, 409: {"description": "Name already used"}},
)
async def create_pipeline(body: PipelineIn, container: ContainerDep) -> PipelineOut:
    return await container.pipeline_defs.create(body, actor="admin-ui")


@router.post(
    "/preview",
    response_model=PreviewResult,
    summary="Estimate how many documents a scope would ingest",
)
async def preview_pipeline(body: PreviewRequest, container: ContainerDep) -> PreviewResult:
    return await container.pipeline_defs.preview(body)


@router.get("/{pipeline_id}", response_model=PipelineOut, summary="Get a pipeline")
async def get_pipeline(pipeline_id: UUID, container: ContainerDep) -> PipelineOut:
    return await container.pipeline_defs.get(pipeline_id)


@router.put("/{pipeline_id}", response_model=PipelineOut, summary="Change a pipeline")
async def update_pipeline(pipeline_id: UUID, body: PipelineUpdate, container: ContainerDep) -> PipelineOut:
    return await container.pipeline_defs.update(pipeline_id, body, actor="admin-ui")


@router.delete("/{pipeline_id}", status_code=status.HTTP_204_NO_CONTENT, summary="Delete a pipeline")
async def delete_pipeline(pipeline_id: UUID, container: ContainerDep) -> None:
    await container.pipeline_defs.delete(pipeline_id, actor="admin-ui")


@router.post(
    "/{pipeline_id}/run",
    status_code=status.HTTP_202_ACCEPTED,
    response_model=IngestionRunOut,
    summary="Run a pipeline now",
    responses={409: {"description": "The connection already has an active run"}},
)
async def run_pipeline(pipeline_id: UUID, container: ContainerDep) -> IngestionRunOut:
    run = await container.pipeline_defs.run(pipeline_id, actor="admin-ui")
    return IngestionRunOut.from_record(run)


@router.post("/{pipeline_id}/schedule", response_model=PipelineOut, summary="Turn the schedule on or off")
async def toggle_schedule(pipeline_id: UUID, body: ScheduleToggle, container: ContainerDep) -> PipelineOut:
    return await container.pipeline_defs.set_enabled(pipeline_id, body.enabled)
