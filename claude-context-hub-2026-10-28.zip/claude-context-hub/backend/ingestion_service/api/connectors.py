"""Connector catalogue."""

from __future__ import annotations

import asyncio
import time

from fastapi import APIRouter, Body, Query

from ech_core.exceptions import ConnectorError
from ech_core.schemas.connectors import (
    ConnectionDraft,
    ConnectionOut,
    ConnectionTestResult,
    ConnectorCatalog,
)
from ech_core.schemas.ingestion import ConnectorInfo
from ech_core.schemas.pipelines import DiscoveryResult
from ingestion_service.connectors.base import BaseConnector, ConnectorHealth, ConnectorOptions
from ingestion_service.connectors.catalog import describe_catalog
from ingestion_service.connectors.connections import CONNECTION_FIELDS
from ingestion_service.dependencies import ContainerDep

router = APIRouter(prefix="/connectors", tags=["connectors"])


async def _describe(connector: BaseConnector) -> ConnectorInfo:
    started = time.perf_counter()
    try:
        async with asyncio.timeout(5):
            health = await connector.health_check()
            estimate = await connector.estimate_count(ConnectorOptions())
    except Exception as exc:  # noqa: BLE001 - a broken connector is still listed
        health = ConnectorHealth(healthy=False, details={"error": str(exc)})
        estimate = None
    return ConnectorInfo(
        latency_ms=int((time.perf_counter() - started) * 1000),
        name=connector.name,
        source_system=connector.source_system,
        display_name=connector.display_name,
        description=connector.description,
        healthy=health.healthy,
        details=health.details,
        estimated_documents=estimate,
        discoverable=connector.discoverable,
        scope_levels=list(connector.scope_levels),
        option_keys=list(connector.option_keys),
    )


@router.get("", response_model=list[ConnectorInfo], summary="List registered connectors")
async def list_connectors(container: ContainerDep) -> list[ConnectorInfo]:
    return list(await asyncio.gather(*(_describe(c) for c in container.registry)))


@router.get(
    "/{name}/discover",
    response_model=DiscoveryResult,
    summary="Browse the schema of a connection: databases, schemas, tables and columns",
)
async def discover(
    name: str,
    container: ContainerDep,
    path: list[str] = Query(default_factory=list, max_length=8),
) -> DiscoveryResult:
    """Children of a node in the hierarchy of the source; no path lists the top level."""
    connector = container.registry.get(name)
    if not connector.discoverable:
        raise ConnectorError(f"{connector.display_name} does not support browsing its schema")
    try:
        async with asyncio.timeout(90):
            return await connector.discover(path)
    except TimeoutError as exc:
        raise ConnectorError(f"{connector.display_name} took too long to answer") from exc


@router.get("/catalog", response_model=ConnectorCatalog, summary="Every connector the hub knows, with live state")
async def connector_catalog(container: ContainerDep) -> ConnectorCatalog:
    """Static descriptors merged with what is registered, healthy and recently run.

    Planned connectors are listed too, so the UI can show the roadmap next to what is live.
    """
    described, freshness, documents_by_source = await asyncio.gather(
        asyncio.gather(*(_describe(c) for c in container.registry)),
        container.runs.connector_freshness(days=7),
        container.documents.counts_by_source(),
    )
    return describe_catalog(
        set(container.registry.names()),
        health={info.name: info for info in described},
        freshness=freshness,
        documents_by_source=documents_by_source,
        editable={name for name in CONNECTION_FIELDS},
        sources={name: source for name in CONNECTION_FIELDS if (source := container.connections.source(name))},
    )


@router.get("/{name}/connection", response_model=ConnectionOut, summary="A connection's settings; credentials only as set or not set")
async def get_connection(name: str, container: ContainerDep) -> ConnectionOut:
    return container.connections.describe(name)


@router.put("/{name}/connection", response_model=ConnectionOut, summary="Save connection settings from the hub and reload the connector")
async def save_connection(name: str, body: ConnectionDraft, container: ContainerDep) -> ConnectionOut:
    out = await container.connections.save(name, body)
    await container.audit.record(
        action="connection.save",
        resource_type="connector",
        resource_id=name,
        actor=body.updated_by or None,
        details={"fields": sorted(body.values), "credentials": sorted(body.secrets)},
    )
    return out


@router.delete("/{name}/connection", response_model=ConnectionOut, summary="Forget settings saved from the hub; the environment applies again")
async def reset_connection(name: str, container: ContainerDep) -> ConnectionOut:
    out = await container.connections.reset(name)
    await container.audit.record(action="connection.reset", resource_type="connector", resource_id=name)
    return out


@router.post("/{name}/test", response_model=ConnectionTestResult, summary="Test a connection, including unsaved changes when given")
async def test_connection(name: str, container: ContainerDep, body: ConnectionDraft | None = Body(default=None)) -> ConnectionTestResult:
    result = await container.connections.test(name, body)
    await container.audit.record(
        action="connection.test",
        status="ok" if result.ok else "error",
        resource_type="connector",
        resource_id=name,
        latency_ms=result.latency_ms,
        details={"draft": result.draft},
    )
    return result
