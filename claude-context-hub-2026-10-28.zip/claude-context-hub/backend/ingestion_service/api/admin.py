"""Operational endpoints: graph reconciliation, embedding provider status."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Query

from ech_core.schemas.ingestion import ReconcileResult
from ingestion_service.dependencies import ContainerDep

router = APIRouter(prefix="/admin", tags=["admin"])


@router.post(
    "/reconcile-graph",
    response_model=ReconcileResult,
    summary="Retry Neo4j sync for documents whose graph_sync_status is pending/failed",
)
async def reconcile_graph(
    container: ContainerDep, limit: int = Query(default=100, ge=1, le=5000)
) -> ReconcileResult:
    return await container.pipeline.reconcile_graph(limit=limit)


@router.get("/embeddings", summary="Embedding provider status")
async def embedding_status(container: ContainerDep) -> dict[str, Any]:
    emb = container.embedder
    return {
        "provider": emb.name,
        "model": emb.model,
        "model_id": emb.model_id,
        "dimensions": emb.dimensions,
        "healthy": await emb.health_check(),
    }


@router.get("/runtime", summary="In-process runtime state")
async def runtime_state(container: ContainerDep) -> dict[str, Any]:
    return {
        "active_runs": [
            {
                "run_id": str(h.run_id),
                "connector": h.connector_name,
                "paused": h.paused,
                "cancelling": h.cancelling,
                "started_at": h.started_at.isoformat(),
            }
            for h in container.run_manager.active()
        ],
        "sse_subscribers": container.event_bus.subscriber_count,
        "connectors": container.registry.names(),
    }
