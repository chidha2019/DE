"""HTTP routers for the ingestion service."""

from ingestion_service.api.router import api_router

__all__ = ["api_router"]
