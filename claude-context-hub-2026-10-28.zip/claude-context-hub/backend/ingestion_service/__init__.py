"""Ingestion & Processing Service.

Crawls enterprise repositories through pluggable connectors, chunks and embeds
content, extracts entities and writes the result to PostgreSQL (metadata,
vectors) and Neo4j (relationships). Exposes pipeline control + SSE progress.
"""
