"""ASGI entrypoint: ``uvicorn ingestion_service.main:app``."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager, suppress

from fastapi import FastAPI

from ech_core import __version__
from ech_core.app_factory import create_app
from ech_core.config import get_settings
from ech_core.connections import SecretBox
from ech_core.db import GraphDatabase, PostgresDatabase
from ech_core.embeddings import build_embedding_provider
from ech_core.logging import configure_logging, get_logger
from ech_core.observability import LatencyRecorder
from ech_core.repositories import (
    AuditRepository,
    ChunkRepository,
    DocumentRepository,
    EmbeddingRepository,
    GraphRepository,
    IngestionRunRepository,
    PipelineRepository,
    SemanticRepository,
)
from ech_core.repositories.connector_settings_repository import ConnectorSettingsRepository
from ech_core.repositories.lines_repository import LinesRepository
from ech_core.repositories.repo_graph_repository import RepoCrawlRepository, RepoGraphRepository
from ingestion_service.api import api_router
from ingestion_service.connectors.connections import ConnectionService
from ingestion_service.connectors.registry import build_default_registry
from ingestion_service.dependencies import Container
from ingestion_service.services.event_bus import EventBus
from ingestion_service.services.pipeline_definitions import PipelineDefinitionService
from ingestion_service.services.pipeline_service import PipelineService
from ingestion_service.services.repo_crawler import RepoCrawlService
from ingestion_service.services.run_manager import RunManager

SERVICE_NAME = "ingestion-service"

settings = get_settings()
if settings.service_name == "ech":  # not overridden by ECH_SERVICE_NAME
    settings = settings.model_copy(update={"service_name": SERVICE_NAME})

configure_logging(
    level=settings.log_level, json_output=settings.log_json, service_name=settings.service_name
)
log = get_logger(__name__)
latency_recorder = LatencyRecorder(settings.latency_buffer_size)


async def _pool_metrics_loop(pg: PostgresDatabase) -> None:
    while True:
        pg.record_pool_metrics()
        await asyncio.sleep(15)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    log.info("service.starting", service=settings.service_name, environment=settings.environment)
    pg = PostgresDatabase(settings)
    graph_db = GraphDatabase(settings)
    await pg.connect()
    await graph_db.connect()
    embedder = build_embedding_provider(settings)

    runs = IngestionRunRepository(pg)
    stale = await runs.fail_stale_runs("ingestion-service restarted while the run was active")
    if stale:
        log.warning("runs.failed_stale", count=stale)

    registry = build_default_registry(settings)
    connections = ConnectionService(settings=settings, repo=ConnectorSettingsRepository(pg), registry=registry, box=SecretBox(settings))
    await connections.load()
    event_bus = EventBus(history=settings.ingestion_event_history)
    run_manager = RunManager()
    documents = DocumentRepository(pg)
    chunks = ChunkRepository(pg)
    embeddings = EmbeddingRepository(pg)
    audit = AuditRepository(pg)
    graph = GraphRepository(graph_db)
    lines_repo = LinesRepository(pg)
    pipeline = PipelineService(
        settings=settings,
        pg=pg,
        documents=documents,
        chunks=chunks,
        embeddings=embeddings,
        runs=runs,
        audit=audit,
        graph=graph,
        embedder=embedder,
        registry=registry,
        event_bus=event_bus,
        run_manager=run_manager,
        semantic=SemanticRepository(pg),
        lines=lines_repo,
    )
    pipeline_defs = PipelineDefinitionService(
        repo=PipelineRepository(pg), registry=registry, pipeline=pipeline, audit=audit, lines=lines_repo
    )
    repo_graph = RepoGraphRepository(graph_db)
    repo_crawler = RepoCrawlService(
        settings=settings,
        crawls=RepoCrawlRepository(pg),
        graph=repo_graph,
        pipeline=pipeline,
        settings_for=lambda: connections.effective_settings("github-live"),
    )
    stale_crawls = await repo_crawler.fail_stale()
    if stale_crawls:
        log.warning("repo_crawls.failed_stale", count=stale_crawls)
    app.state.container = Container(
        settings=settings,
        pg=pg,
        graph_db=graph_db,
        embedder=embedder,
        documents=documents,
        chunks=chunks,
        embeddings=embeddings,
        runs=runs,
        audit=audit,
        graph=graph,
        registry=registry,
        event_bus=event_bus,
        run_manager=run_manager,
        pipeline=pipeline,
        pipeline_defs=pipeline_defs,
        latency=latency_recorder,
        repo_graph=repo_graph,
        repo_crawler=repo_crawler,
        connections=connections,
    )
    app.state.readiness_checks = {"postgres": pg.ping, "neo4j": graph_db.ping}
    metrics_task = asyncio.create_task(_pool_metrics_loop(pg), name="pool-metrics")
    scheduler_task = (
        asyncio.create_task(
            pipeline_defs.poll_loop(settings.pipeline_scheduler_interval_seconds), name="pipeline-scheduler"
        )
        if settings.pipeline_scheduler_enabled
        else None
    )
    log.info("service.ready", connectors=registry.names(), embedding_provider=embedder.model_id)
    try:
        yield
    finally:
        log.info("service.stopping")
        await run_manager.shutdown(timeout=20)
        await repo_crawler.shutdown()
        for task in (metrics_task, scheduler_task):
            if task is not None:
                task.cancel()
                with suppress(asyncio.CancelledError):
                    await task
        await connections.shutdown()
        await embedder.aclose()
        await graph_db.close()
        await pg.close()
        log.info("service.stopped")


app = create_app(
    settings=settings,
    title="ECH — Ingestion & Processing Service",
    description=(
        "Crawls enterprise repositories via connectors, chunks and embeds content, extracts "
        "entities, and keeps PostgreSQL (metadata + vectors) and Neo4j (graph) in sync."
    ),
    version=__version__,
    lifespan=lifespan,
    routers=[api_router],
    latency_recorder=latency_recorder,
)
