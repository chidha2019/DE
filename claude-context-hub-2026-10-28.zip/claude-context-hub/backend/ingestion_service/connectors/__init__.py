"""Source connectors: the contract plus the live GitHub, Databricks Unity Catalog and
Snowflake implementations (``registry.build_default_registry`` wires them from settings)."""

from ingestion_service.connectors.base import (
    BaseConnector,
    ConnectorHealth,
    ConnectorOptions,
    ExplicitEntity,
    SourceDocument,
)
from ingestion_service.connectors.registry import ConnectorRegistry, build_default_registry

__all__ = [
    "BaseConnector",
    "ConnectorHealth",
    "ConnectorOptions",
    "ConnectorRegistry",
    "ExplicitEntity",
    "SourceDocument",
    "build_default_registry",
]
