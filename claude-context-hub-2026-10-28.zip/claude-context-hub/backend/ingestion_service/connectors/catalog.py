"""The connector catalogue.

A static table of every source the hub knows how to read, or plans to, merged with what is
live right now: which adapters are registered (their settings are present), whether they are
healthy, when they last ran and how many documents they have contributed. The catalogue names
the settings a connector needs so the UI can say what to configure; it never carries values.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from ech_core.schemas.connectors import (
    CatalogAvailability,
    CatalogFeeds,
    ConnectorCatalog,
    ConnectorCatalogCategory,
    ConnectorCatalogEntry,
)
from ech_core.schemas.ingestion import ConnectorInfo


@dataclass(frozen=True)
class CategorySpec:
    key: str
    label: str
    tagline: str


CATEGORIES: tuple[CategorySpec, ...] = (
    CategorySpec("platforms", "Data platforms", "Lakehouses and warehouses: the backbone of the semantic layer."),
    CategorySpec("databases", "Databases", "Relational and federated engines, read through their information schema."),
    CategorySpec("sdlc", "SDLC & repositories", "Code, pipeline definitions and the engineering context around them."),
    CategorySpec("knowledge", "Knowledge & documents", "Pages, files and hand-written context."),
    CategorySpec("transformation", "Transformation & orchestration", "Models, tests, DAGs and the lineage between them."),
    CategorySpec("bi", "Dashboards & BI", "Where the governed metrics are consumed."),
    CategorySpec("observability", "Observability", "Dashboards, alerts and SLOs for the SRE workspace."),
)


@dataclass(frozen=True)
class ConnectorDescriptor:
    key: str
    name: str
    vendor: str
    category: str
    description: str
    feeds: CatalogFeeds
    capabilities: tuple[str, ...]
    env_vars: tuple[str, ...] = ()
    adapter: str | None = None
    """Registry name when an adapter exists; None for planned connectors."""
    source_system: str | None = None
    always_on: bool = False
    """True for sources that need no configuration (the manual ingest API)."""
    docs_url: str | None = None
    accent: str = "172 66% 45%"
    icon: str = "database"


DESCRIPTORS: tuple[ConnectorDescriptor, ...] = (
    ConnectorDescriptor(
        key="databricks",
        name="Databricks",
        vendor="Unity Catalog",
        category="platforms",
        description="Discover catalogs, schemas, tables, views and metric views across the lakehouse, with keys, lineage and ownership.",
        feeds="both",
        capabilities=("Catalog and schema hierarchy", "Tables, views and declared columns", "Primary and foreign keys", "Metric views and lineage", "Descriptions and ownership"),
        env_vars=("DATABRICKS_HOST", "DATABRICKS_TOKEN", "ECH_DATABRICKS_CATALOGS", "ECH_DATABRICKS_SCHEMAS"),
        adapter="databricks",
        source_system="databricks",
        docs_url="https://docs.databricks.com/api/workspace/tables",
        accent="14 88% 56%",
        icon="databricks",
    ),
    ConnectorDescriptor(
        key="snowflake",
        name="Snowflake",
        vendor="Cloud data platform",
        category="platforms",
        description="Discover warehouse databases, schemas, tables, columns, semantic views and tags, with native comments and ownership.",
        feeds="both",
        capabilities=("Database and schema hierarchy", "Tables, views and columns", "Semantic views and tags", "Lineage from access history", "Native comments and ownership"),
        env_vars=("ECH_SNOWFLAKE_ACCOUNT", "ECH_SNOWFLAKE_USER", "ECH_SNOWFLAKE_TOKEN", "ECH_SNOWFLAKE_DATABASES", "ECH_SNOWFLAKE_WAREHOUSE"),
        adapter="snowflake",
        source_system="snowflake",
        docs_url="https://docs.snowflake.com/en/developer-guide/sql-api/index",
        accent="199 90% 55%",
        icon="snowflake",
    ),
    ConnectorDescriptor(
        key="postgres",
        name="PostgreSQL",
        vendor="Relational database",
        category="databases",
        description="Read relational structure directly from the information schema: schemas, tables, views, columns and constraints.",
        feeds="semantic",
        capabilities=("Schemas, tables, views and columns", "Native types, nullability and comments", "Primary and foreign keys", "Read-only metadata collection"),
        env_vars=("ECH_SOURCE_POSTGRES_DSN", "ECH_SOURCE_POSTGRES_SCHEMAS"),
        docs_url="https://www.postgresql.org/docs/current/information-schema.html",
        accent="210 60% 52%",
        icon="postgres",
    ),
    ConnectorDescriptor(
        key="oracle",
        name="Oracle",
        vendor="Enterprise database",
        category="databases",
        description="Discover Oracle tables, views and column metadata through the native thin driver.",
        feeds="semantic",
        capabilities=("Schemas, tables, views and columns", "Native types and nullability", "Comments and schema owners"),
        env_vars=("ECH_SOURCE_ORACLE_DSN", "ECH_SOURCE_ORACLE_SCHEMAS"),
        accent="0 72% 52%",
        icon="oracle",
    ),
    ConnectorDescriptor(
        key="mssql",
        name="SQL Server",
        vendor="Microsoft SQL Server",
        category="databases",
        description="Collect databases, schemas, tables, views and columns with extended properties as descriptions.",
        feeds="semantic",
        capabilities=("Databases, schemas, tables and views", "Columns, types and constraints", "Extended properties as descriptions"),
        env_vars=("ECH_SOURCE_MSSQL_DSN", "ECH_SOURCE_MSSQL_SCHEMAS"),
        accent="0 0% 62%",
        icon="mssql",
    ),
    ConnectorDescriptor(
        key="trino",
        name="Trino",
        vendor="Distributed query engine",
        category="databases",
        description="Explore the catalogs behind a federated query layer: one connector for every source Trino can reach.",
        feeds="semantic",
        capabilities=("Federated catalogs and schemas", "Table and column metadata", "Native descriptions"),
        env_vars=("ECH_SOURCE_TRINO_URL", "ECH_SOURCE_TRINO_CATALOGS"),
        accent="266 60% 60%",
        icon="trino",
    ),
    ConnectorDescriptor(
        key="github-live",
        name="GitHub",
        vendor="Repositories via the live API",
        category="sdlc",
        description="Ingest the code, configuration, READMEs and pipeline definitions behind the data, repository by repository.",
        feeds="documents",
        capabilities=("Repository files and READMEs", "Code and configuration", "Pipeline and workflow definitions", "Commit history as freshness"),
        env_vars=("ECH_GITHUB_REPOS", "ECH_GITHUB_TOKEN"),
        adapter="github-live",
        source_system="github",
        docs_url="https://docs.github.com/en/rest",
        accent="262 60% 60%",
        icon="github",
    ),
    ConnectorDescriptor(
        key="gitlab",
        name="GitLab",
        vendor="Projects and pipelines",
        category="sdlc",
        description="The same repository ingestion for GitLab projects, including CI pipeline definitions.",
        feeds="documents",
        capabilities=("Project files and READMEs", "CI pipeline definitions", "Merge request context"),
        env_vars=("ECH_GITLAB_PROJECTS", "ECH_GITLAB_TOKEN"),
        accent="24 90% 55%",
        icon="gitlab",
    ),
    ConnectorDescriptor(
        key="manual",
        name="Manual ingestion API",
        vendor="POST /api/v1/documents",
        category="knowledge",
        description="Push any document straight into the hub: runbooks, decisions, notes and anything a connector does not cover.",
        feeds="documents",
        capabilities=("Any markdown or text document", "Explicit entities and references", "Idempotent by external id"),
        source_system="manual",
        always_on=True,
        docs_url="/playground",
        accent="172 66% 45%",
        icon="manual",
    ),
    ConnectorDescriptor(
        key="confluence",
        name="Confluence",
        vendor="Atlassian wiki",
        category="knowledge",
        description="Bring spaces and pages into the hub as documents, with authors, labels and page links as references.",
        feeds="documents",
        capabilities=("Spaces and pages", "Authors and labels", "Page links as references"),
        env_vars=("ECH_CONFLUENCE_URL", "ECH_CONFLUENCE_TOKEN", "ECH_CONFLUENCE_SPACES"),
        source_system="confluence",
        accent="212 90% 58%",
        icon="confluence",
    ),
    ConnectorDescriptor(
        key="jira",
        name="Jira",
        vendor="Atlassian issues",
        category="sdlc",
        description="Hand the hub tickets: it reads, reviews and plans intent tickets and posts its questions and plans back on the issue, and ingests issues as documents so Genie knows the work behind the data.",
        feeds="documents",
        capabilities=("Intent tickets read, reviewed and planned", "Questions and plans posted back as comments", "/approve, /reject and /answer replies", "Issues as documents"),
        env_vars=("JIRA_BASE_URL", "JIRA_EMAIL", "JIRA_API_TOKEN"),
        adapter="jira",
        source_system="jira",
        docs_url="https://developer.atlassian.com/cloud/jira/platform/rest/v3/intro/",
        accent="216 100% 45%",
        icon="jira",
    ),
    ConnectorDescriptor(
        key="sharepoint",
        name="SharePoint",
        vendor="Microsoft 365 sites",
        category="knowledge",
        description="Index site libraries and documents, with owners and folder structure preserved as context.",
        feeds="documents",
        capabilities=("Sites and document libraries", "Office documents and PDFs", "Owners and folder context"),
        env_vars=("ECH_SHAREPOINT_SITE", "ECH_SHAREPOINT_CLIENT_ID", "ECH_SHAREPOINT_CLIENT_SECRET"),
        source_system="sharepoint",
        accent="190 80% 42%",
        icon="sharepoint",
    ),
    ConnectorDescriptor(
        key="dbt",
        name="dbt",
        vendor="Core and Cloud projects",
        category="transformation",
        description="Read models, sources, tests and exposures from the manifest, so model lineage lands in the semantic layer.",
        feeds="both",
        capabilities=("Models, sources and seeds", "Tests and documentation", "Model-to-model lineage", "Exposures as consumers"),
        env_vars=("ECH_DBT_MANIFEST_URL", "ECH_DBT_TOKEN"),
        accent="18 90% 55%",
        icon="dbt",
    ),
    ConnectorDescriptor(
        key="airflow",
        name="Apache Airflow",
        vendor="DAGs and task lineage",
        category="transformation",
        description="Collect DAGs, tasks and their inlets and outlets to connect pipelines with the tables they touch.",
        feeds="both",
        capabilities=("DAGs and tasks", "Inlets and outlets as lineage", "Run history as freshness"),
        env_vars=("ECH_AIRFLOW_URL", "ECH_AIRFLOW_TOKEN"),
        accent="160 70% 42%",
        icon="airflow",
    ),
    ConnectorDescriptor(
        key="tableau",
        name="Tableau",
        vendor="Workbooks and data sources",
        category="bi",
        description="Map workbooks, sheets and published data sources to the tables and metrics they consume.",
        feeds="both",
        capabilities=("Workbooks and sheets", "Published data sources", "Field-to-column lineage"),
        env_vars=("ECH_TABLEAU_SERVER", "ECH_TABLEAU_TOKEN", "ECH_TABLEAU_SITE"),
        accent="210 80% 50%",
        icon="tableau",
    ),
    ConnectorDescriptor(
        key="powerbi",
        name="Power BI",
        vendor="Datasets and reports",
        category="bi",
        description="Read workspaces, datasets, measures and reports so the metrics people see trace back to governed definitions.",
        feeds="both",
        capabilities=("Workspaces, datasets and reports", "Measures and their DAX", "Dataset-to-source lineage"),
        env_vars=("ECH_POWERBI_TENANT", "ECH_POWERBI_CLIENT_ID", "ECH_POWERBI_CLIENT_SECRET"),
        accent="45 95% 52%",
        icon="powerbi",
    ),
    ConnectorDescriptor(
        key="grafana",
        name="Grafana",
        vendor="Dashboards, panels and alert rules",
        category="observability",
        description="Ingest dashboards, panel queries and alert rules from Grafana Cloud, so the SRE workspace sees firing alerts and Genie knows which dashboards use which tables.",
        feeds="both",
        capabilities=("Dashboards and panels", "Panel queries as lineage", "Alert rules and their state", "Folders and tags"),
        env_vars=("GRAFANA_URL", "GRAFANA_TOKEN"),
        adapter="grafana",
        source_system="grafana",
        docs_url="https://grafana.com/docs/grafana/latest/developers/http_api/",
        accent="28 95% 54%",
        icon="grafana",
    ),
)


def _availability(descriptor: ConnectorDescriptor, registered: set[str]) -> CatalogAvailability:
    if descriptor.always_on or (descriptor.adapter is not None and descriptor.adapter in registered):
        return "configured"
    return "available" if descriptor.adapter is not None else "planned"


def describe_catalog(
    registered: set[str],
    *,
    health: dict[str, ConnectorInfo] | None = None,
    freshness: list[dict[str, Any]] | None = None,
    documents_by_source: dict[str, int] | None = None,
    editable: set[str] | None = None,
    sources: dict[str, str] | None = None,
    now: datetime | None = None,
) -> ConnectorCatalog:
    """Pure merge of the descriptors with live state; the API gathers that state first.

    ``registered`` holds registry names; ``health`` is keyed by registry name; ``freshness`` is
    the per-connector rollup from the runs repository; ``documents_by_source`` is keyed by
    source system.
    """
    health = health or {}
    docs = documents_by_source or {}
    fresh = {row["connector_name"]: row for row in (freshness or [])}
    entries: list[ConnectorCatalogEntry] = []
    for d in DESCRIPTORS:
        availability = _availability(d, registered)
        info = health.get(d.adapter) if d.adapter else None
        row = fresh.get(d.adapter) if d.adapter else None
        entries.append(
            ConnectorCatalogEntry(
                key=d.key,
                name=d.name,
                vendor=d.vendor,
                category=d.category,
                description=d.description,
                feeds=d.feeds,
                capabilities=list(d.capabilities),
                env_vars=list(d.env_vars),
                availability=availability,
                adapter=d.adapter,
                source_system=d.source_system,
                healthy=True if d.always_on else (info.healthy if info else None),
                health_details=dict(info.details) if info else {},
                estimated_documents=info.estimated_documents if info else None,
                documents=int(docs.get(d.source_system, 0)) if d.source_system else 0,
                last_success_at=row.get("last_success_at") if row else None,
                last_status=row.get("last_status") if row else None,
                runs_7d=int(row.get("runs", 0)) if row else 0,
                failed_7d=int(row.get("failed", 0)) if row else 0,
                docs_url=d.docs_url,
                accent=d.accent,
                icon=d.icon,
                editable=d.adapter is not None and d.adapter in (editable or set()),
                settings_source=(sources or {}).get(d.adapter or ""),
                health_latency_ms=info.latency_ms if info else None,
            )
        )
    by_category = {c.key: 0 for c in CATEGORIES}
    for e in entries:
        by_category[e.category] = by_category.get(e.category, 0) + 1
    return ConnectorCatalog(
        generated_at=now or datetime.now(UTC),
        total=len(entries),
        configured=sum(e.availability == "configured" for e in entries),
        available=sum(e.availability == "available" for e in entries),
        planned=sum(e.availability == "planned" for e in entries),
        categories=[ConnectorCatalogCategory(key=c.key, label=c.label, tagline=c.tagline, count=by_category[c.key]) for c in CATEGORIES],
        entries=entries,
    )
