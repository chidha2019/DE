"""Databricks Unity Catalog connector - the semantic layer's metadata from Databricks.

Reads catalogs → schemas → tables through the Unity Catalog REST API
(``/api/2.1/unity-catalog``): one list call per schema, one GET per table (the list
call omits constraints and view definitions) and, when enabled, the lineage API for
upstream / downstream tables and consumers. Metric views contribute *declared*
dimensions and measures from their YAML definition; views contribute the tables their
SQL reads when lineage is silent. Every table-like object becomes one
:class:`SemanticAsset`, rendered as a markdown document for retrieval and carried in
``attributes["semantic"]`` for the structured store.

Authentication: a workspace personal access token (``DATABRICKS_HOST`` /
``DATABRICKS_TOKEN`` - the same pair Genie uses when Claude is served by Databricks).
"""

from __future__ import annotations

import asyncio
import re
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any, ClassVar

import httpx

from ech_core.config import Settings
from ech_core.domain.enums import EntityType, SourceSystem
from ech_core.exceptions import ConnectorError
from ech_core.logging import get_logger
from ech_core.schemas.pipelines import DiscoveryNode, DiscoveryResult
from ech_core.semantic.inference import infer_asset, referenced_fqns
from ech_core.semantic.models import (
    AssetType,
    FieldRole,
    MetricSource,
    Platform,
    RelationshipKind,
    SemanticAsset,
    SemanticField,
    SemanticMetric,
    SemanticRelationship,
)
from ech_core.semantic.render import owner_is_person, render_asset_markdown
from ingestion_service.connectors.base import (
    BaseConnector,
    ConnectorHealth,
    ConnectorOptions,
    ExplicitEntity,
    SourceDocument,
)
from ingestion_service.connectors.scope import ScopePlan, plan_scope

log = get_logger(__name__)

_SYSTEM_SCHEMAS = {"information_schema"}
_META_TTL_SECONDS = 600.0
_TABLE_TYPES = {
    "MANAGED": AssetType.TABLE,
    "MANAGED_SHALLOW_CLONE": AssetType.TABLE,
    "EXTERNAL": AssetType.EXTERNAL_TABLE,
    "EXTERNAL_SHALLOW_CLONE": AssetType.EXTERNAL_TABLE,
    "VIEW": AssetType.VIEW,
    "MATERIALIZED_VIEW": AssetType.MATERIALIZED_VIEW,
    "STREAMING_TABLE": AssetType.STREAMING_TABLE,
    "METRIC_VIEW": AssetType.METRIC_VIEW,
    "FOREIGN": AssetType.FOREIGN_TABLE,
}
_JOIN_ON = re.compile(r"source\.(\w+)\s*=\s*(\w+)\.(\w+)", re.I)
_AGGREGATION = re.compile(r"^\s*(COUNT|SUM|AVG|MIN|MAX)\s*\(", re.I)
_RETRYABLE = {429, 500, 502, 503, 504}
_CONSUMER_KEYS = (
    ("notebookInfos", "notebook"),
    ("jobInfos", "job"),
    ("dashboardV3Infos", "dashboard"),
    ("pipelineInfos", "pipeline"),
    ("queryInfos", "query"),
)


@dataclass(frozen=True)
class CatalogScope:
    catalog: str
    schema: str


def _epoch_ms(value: Any) -> datetime | None:
    try:
        return datetime.fromtimestamp(int(value) / 1000, tz=UTC) if value else None
    except (TypeError, ValueError, OSError):
        return None


def _humanize(name: str) -> str:
    return re.sub(r"[_\-]+", " ", name).strip().title()


def _int_or_none(value: Any) -> int | None:
    try:
        return int(value) if value not in (None, "") else None
    except (TypeError, ValueError):
        return None


class DatabricksCatalogConnector(BaseConnector):
    name: ClassVar[str] = "databricks"
    source_system: ClassVar[SourceSystem] = SourceSystem.DATABRICKS
    display_name: ClassVar[str] = "Databricks Unity Catalog"
    description: ClassVar[str] = (
        "Tables, views and metric views from Unity Catalog: columns, keys, lineage, "
        "declared metrics; the semantic layer's Databricks source."
    )
    discoverable: ClassVar[bool] = True
    scope_levels: ClassVar[tuple[str, ...]] = ("Catalog", "Schema", "Table")
    option_keys: ClassVar[tuple[str, ...]] = ("include_lineage",)

    def __init__(
        self,
        *,
        host: str,
        token: str,
        catalogs: list[str],
        schemas: list[str] | None = None,
        include_lineage: bool = True,
        max_tables: int = 2000,
        concurrency: int = 8,
        client: httpx.AsyncClient | None = None,
        timeout: float = 30.0,
    ) -> None:
        host = host.strip().rstrip("/")
        if "://" not in host:
            host = f"https://{host}"
        self._host = host
        self._token = token
        self._catalogs = [c.strip() for c in catalogs if c.strip()]
        self._schemas = {s.strip().lower() for s in (schemas or []) if s.strip()}
        for scoped in sorted(self._schemas):  # catalog.schema filters pull in their catalog
            catalog = scoped.split(".", 1)[0]
            if catalog not in [c.lower() for c in self._catalogs]:
                self._catalogs.append(catalog)
        self._include_lineage = include_lineage
        self._max_tables = max_tables
        self._concurrency = max(1, concurrency)
        self._timeout = timeout
        self._client = client
        self._own_client = client is None
        self._sem = asyncio.Semaphore(self._concurrency)
        self._scope_cache: tuple[float, list[CatalogScope]] | None = None
        self._count_cache: tuple[float, int] | None = None

    @classmethod
    def from_settings(cls, settings: Settings) -> DatabricksCatalogConnector:
        if not settings.databricks_host or settings.databricks_token is None:
            raise ConnectorError("Databricks connector needs DATABRICKS_HOST and DATABRICKS_TOKEN")
        return cls(
            host=settings.databricks_host,
            token=settings.databricks_token.get_secret_value(),
            catalogs=settings.databricks_catalog_list,
            schemas=settings.databricks_schema_list,
            include_lineage=settings.databricks_include_lineage,
            max_tables=settings.databricks_max_tables,
            concurrency=settings.databricks_fetch_concurrency,
        )

    # ------------------------------------------------------------------ http
    def _headers(self) -> dict[str, str]:
        # Sent per request so an injected client (tests, shared pools) is authenticated too.
        return {
            "Authorization": f"Bearer {self._token}",
            "Accept": "application/json",
            "User-Agent": "enterprise-context-hub/0.1",
        }

    def _http(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self._host,
                timeout=httpx.Timeout(self._timeout, read=max(self._timeout, 60.0)),
            )
        return self._client

    async def aclose(self) -> None:
        if self._own_client and self._client is not None:
            await self._client.aclose()
            self._client = None

    async def _get(self, path: str, **params: Any) -> Any:
        delay = 1.0
        query = {k: v for k, v in params.items() if v is not None}
        for attempt in range(5):
            async with self._sem:
                try:
                    response = await self._http().get(path, params=query, headers=self._headers())
                except httpx.HTTPError as exc:
                    if attempt == 4:
                        raise ConnectorError(f"Databricks request failed: {exc}") from exc
                    await asyncio.sleep(delay)
                    delay = min(delay * 2, 30)
                    continue
            if response.status_code in _RETRYABLE and attempt < 4:
                retry_after = response.headers.get("Retry-After")
                await asyncio.sleep(float(retry_after) if retry_after else delay)
                delay = min(delay * 2, 30)
                continue
            if response.status_code >= 400:
                raise ConnectorError(
                    f"Databricks {path} -> HTTP {response.status_code}: {response.text[:300]}",
                    details={"status": response.status_code, "path": path},
                )
            return response.json()
        raise ConnectorError("Databricks request retries exhausted")

    async def _paged(self, path: str, key: str, **params: Any) -> list[dict[str, Any]]:
        items: list[dict[str, Any]] = []
        token: str | None = None
        for _ in range(500):  # hard stop against a misbehaving pagination loop
            payload = await self._get(path, page_token=token, **params)
            items.extend(payload.get(key) or [])
            token = payload.get("next_page_token")
            if not token:
                break
        return items

    # ------------------------------------------------------------------ scopes
    async def _scopes(self, *, force: bool = False) -> list[CatalogScope]:
        now = time.monotonic()
        if not force and self._scope_cache and now - self._scope_cache[0] < _META_TTL_SECONDS:
            return self._scope_cache[1]
        scopes: list[CatalogScope] = []
        for catalog in self._catalogs:
            schemas = await self._paged(
                "/api/2.1/unity-catalog/schemas", "schemas", catalog_name=catalog
            )
            for schema in schemas:
                name = schema.get("name", "")
                if name.lower() in _SYSTEM_SCHEMAS:
                    continue
                if self._schemas and f"{catalog}.{name}".lower() not in self._schemas:
                    continue
                scopes.append(CatalogScope(catalog=catalog, schema=name))
        self._scope_cache = (now, scopes)
        return scopes

    async def _tables_in(self, scope: CatalogScope, plan: ScopePlan | None) -> list[dict[str, Any]]:
        tables = await self._paged(
            "/api/2.1/unity-catalog/tables",
            "tables",
            catalog_name=scope.catalog,
            schema_name=scope.schema,
            omit_columns="true",
            omit_properties="true",
        )
        if plan is None or plan.whole or scope.schema.lower() in plan.schemas:
            return tables
        return [t for t in tables if plan.allows(scope.schema.lower(), str(t.get("name", "")).lower())]

    async def _scoped(self, options: ConnectorOptions) -> list[tuple[CatalogScope, ScopePlan]]:
        """The schemas to read for the selected paths, with the plan that narrows their tables."""
        out: list[tuple[CatalogScope, ScopePlan]] = []
        for plan in plan_scope(options.scope, root=str.lower, rest=str.lower).values():
            if plan.whole:
                schemas = await self._paged(
                    "/api/2.1/unity-catalog/schemas", "schemas", catalog_name=plan.root
                )
                names = [
                    str(s.get("name", ""))
                    for s in schemas
                    if str(s.get("name", "")).lower() not in _SYSTEM_SCHEMAS
                ]
            else:
                names = sorted(plan.schemas | set(plan.tables))
            out += [(CatalogScope(catalog=plan.root, schema=n), plan) for n in names if n]
        return out

    # ------------------------------------------------------------------ schema browser
    async def discover(self, path: list[str]) -> DiscoveryResult:
        """Catalogs, then schemas, tables and columns, read live from Unity Catalog."""
        limit = 1000
        nodes: list[DiscoveryNode] = []
        if not path:
            for c in await self._paged("/api/2.1/unity-catalog/catalogs", "catalogs"):
                name = str(c.get("name", ""))
                if name and name.lower() not in ("system", "__databricks_internal"):
                    nodes.append(
                        DiscoveryNode(
                            name=name,
                            path=[name],
                            kind="catalog",
                            expandable=True,
                            description=str(c.get("comment") or ""),
                            detail=str(c.get("catalog_type") or "").replace("_", " ").title(),
                        )
                    )
        elif len(path) == 1:
            for s in await self._paged("/api/2.1/unity-catalog/schemas", "schemas", catalog_name=path[0]):
                name = str(s.get("name", ""))
                if name and name.lower() not in _SYSTEM_SCHEMAS:
                    nodes.append(
                        DiscoveryNode(
                            name=name,
                            path=[path[0], name],
                            kind="schema",
                            expandable=True,
                            description=str(s.get("comment") or ""),
                        )
                    )
        elif len(path) == 2:
            for t in await self._paged(
                "/api/2.1/unity-catalog/tables",
                "tables",
                catalog_name=path[0],
                schema_name=path[1],
                omit_columns="true",
                omit_properties="true",
            ):
                name = str(t.get("name", ""))
                nodes.append(
                    DiscoveryNode(
                        name=name,
                        path=[path[0], path[1], name],
                        kind="table",
                        expandable=True,
                        description=str(t.get("comment") or ""),
                        detail=str(t.get("table_type") or "").replace("_", " ").title(),
                    )
                )
        elif len(path) == 3:
            info = await self._get(f"/api/2.1/unity-catalog/tables/{'.'.join(path)}")
            for c in info.get("columns") or []:
                name = str(c.get("name", ""))
                null = "" if c.get("nullable", True) else " not null"
                nodes.append(
                    DiscoveryNode(
                        name=name,
                        path=[*path, name],
                        kind="column",
                        selectable=False,
                        description=str(c.get("comment") or ""),
                        detail=str(c.get("type_text") or c.get("type_name") or "") + null,
                    )
                )
        else:
            raise ConnectorError("Unity Catalog tables have no children below their columns")
        return DiscoveryResult(
            connector=self.name, path=path, nodes=nodes[:limit], truncated=len(nodes) > limit
        )

    async def health_check(self) -> ConnectorHealth:
        try:
            catalogs = await self._paged("/api/2.1/unity-catalog/catalogs", "catalogs")
        except ConnectorError as exc:
            return ConnectorHealth(healthy=False, details={"error": str(exc)})
        visible = {c.get("name", "").lower() for c in catalogs}
        missing = [c for c in self._catalogs if c.lower() not in visible]
        return ConnectorHealth(
            healthy=not missing,
            details={
                "host": self._host,
                "catalogs": self._catalogs,
                "schemas": sorted(self._schemas) or "all",
                "missing_catalogs": missing,
                "visible_catalogs": len(catalogs),
                "lineage": self._include_lineage,
            },
        )

    async def estimate_count(self, options: ConnectorOptions) -> int | None:
        if options.scope:
            total = 0
            for scope, plan in await self._scoped(options):
                total += len(await self._tables_in(scope, plan))
            total = min(total, self._max_tables)
            return min(total, options.limit) if options.limit else total
        now = time.monotonic()
        if self._count_cache and now - self._count_cache[0] < _META_TTL_SECONDS:
            total = self._count_cache[1]
        else:
            total = 0
            for scope in await self._scopes():
                tables = await self._paged(
                    "/api/2.1/unity-catalog/tables",
                    "tables",
                    catalog_name=scope.catalog,
                    schema_name=scope.schema,
                    omit_columns="true",
                    omit_properties="true",
                )
                total += len(tables)
            self._count_cache = (now, total)
        total = min(total, self._max_tables)
        return min(total, options.limit) if options.limit else total

    def known_entities(self) -> list[ExplicitEntity]:
        entities = [
            ExplicitEntity(name="Databricks", entity_type=EntityType.TECHNOLOGY, confidence=0.99),
            ExplicitEntity(
                name="Unity Catalog", entity_type=EntityType.TECHNOLOGY, confidence=0.95
            ),
        ]
        entities += [
            ExplicitEntity(name=_humanize(c), entity_type=EntityType.PROJECT, confidence=0.9)
            for c in self._catalogs
        ]
        return entities

    # ------------------------------------------------------------------ documents
    async def iter_documents(self, options: ConnectorOptions) -> AsyncIterator[SourceDocument]:
        yielded = 0
        if options.scope:
            targets = await self._scoped(options)
        else:
            targets = [(s, None) for s in await self._scopes(force=options.full_refresh)]
        for scope, plan in targets:
            tables = await self._tables_in(scope, plan)
            for start in range(0, len(tables), self._concurrency):
                batch = tables[start : start + self._concurrency]
                results = await asyncio.gather(
                    *(self._describe(t, options.source_options.include_lineage) for t in batch),
                    return_exceptions=True,
                )
                for table, asset in zip(batch, results, strict=True):
                    if isinstance(asset, BaseException):
                        log.warning(
                            "databricks.table_failed",
                            table=table.get("full_name"),
                            error=f"{type(asset).__name__}: {asset}",
                        )
                        continue
                    yield self._document(asset)
                    yielded += 1
                    if options.limit is not None and yielded >= options.limit:
                        return
                    if yielded >= self._max_tables:
                        log.warning("databricks.max_tables_reached", max_tables=self._max_tables)
                        return

    async def fetch_document(self, external_id: str) -> SourceDocument | None:
        try:
            info = await self._get(f"/api/2.1/unity-catalog/tables/{external_id}")
        except ConnectorError:
            return None
        lineage = await self._lineage(external_id) if self._include_lineage else {}
        return self._document(self._build_asset(info, lineage))

    async def _describe(self, table: dict[str, Any], lineage_on: bool | None = None) -> SemanticAsset:
        full_name = table["full_name"]
        info = await self._get(f"/api/2.1/unity-catalog/tables/{full_name}")
        wanted = self._include_lineage if lineage_on is None else lineage_on
        lineage = await self._lineage(full_name) if wanted else {}
        return self._build_asset(info, lineage)

    async def _lineage(self, full_name: str) -> dict[str, Any]:
        try:
            return await self._get(
                "/api/2.0/lineage-tracking/table-lineage",
                table_name=full_name,
                include_entity_lineage="true",
            )
        except ConnectorError as exc:
            log.debug("databricks.lineage_unavailable", table=full_name, error=str(exc))
            return {}

    # ------------------------------------------------------------------ mapping
    def _build_asset(self, info: dict[str, Any], lineage: dict[str, Any]) -> SemanticAsset:
        parts = str(info.get("full_name") or "").split(".")
        catalog = info.get("catalog_name") or (parts[0] if len(parts) == 3 else "")
        schema = info.get("schema_name") or (parts[1] if len(parts) == 3 else "")
        name = info["name"]
        fqn = info.get("full_name") or f"{catalog}.{schema}.{name}"
        asset_type = _TABLE_TYPES.get(info.get("table_type", ""), AssetType.OTHER)
        props = info.get("properties") or {}

        fields = [
            SemanticField(
                name=col["name"],
                ordinal=int(col.get("position", i)),
                data_type=col.get("type_text") or col.get("type_name") or "",
                description=col.get("comment") or "",
                nullable=col.get("nullable"),
                is_partition=col.get("partition_index") is not None,
            )
            for i, col in enumerate(info.get("columns") or [])
        ]
        by_name = {f.name.casefold(): f for f in fields}
        relationships: list[SemanticRelationship] = []
        for constraint in info.get("table_constraints") or []:
            pk = constraint.get("primary_key_constraint")
            if pk:
                for column in pk.get("child_columns") or []:
                    if column.casefold() in by_name:
                        by_name[column.casefold()].is_primary_key = True
            fk = constraint.get("foreign_key_constraint")
            if fk and fk.get("parent_table"):
                relationships.append(
                    SemanticRelationship(
                        target_fqn=fk["parent_table"],
                        kind=RelationshipKind.FOREIGN_KEY,
                        source_columns=list(fk.get("child_columns") or []),
                        target_columns=list(fk.get("parent_columns") or []),
                        evidence=f"constraint {fk.get('name', '')}".strip(),
                    )
                )

        definition = info.get("view_definition") or None
        metrics: list[SemanticMetric] = []
        if asset_type is AssetType.METRIC_VIEW and definition:
            metrics, declared = self._parse_metric_view(definition, by_name)
            relationships += declared
        elif definition and asset_type in (
            AssetType.VIEW,
            AssetType.MATERIALIZED_VIEW,
            AssetType.STREAMING_TABLE,
        ):
            relationships += [
                SemanticRelationship(
                    target_fqn=upstream,
                    kind=RelationshipKind.LINEAGE_UPSTREAM,
                    confidence=0.9,
                    evidence="referenced in the view definition",
                )
                for upstream in referenced_fqns(definition)
                if upstream.lower() != fqn.lower()
            ]

        consumers: list[str] = []
        for direction, kind in (
            ("upstreams", RelationshipKind.LINEAGE_UPSTREAM),
            ("downstreams", RelationshipKind.LINEAGE_DOWNSTREAM),
        ):
            for entry in lineage.get(direction) or []:
                table_info = entry.get("tableInfo")
                if table_info and table_info.get("name"):
                    target = ".".join(
                        p
                        for p in (
                            table_info.get("catalog_name"),
                            table_info.get("schema_name"),
                            table_info.get("name"),
                        )
                        if p
                    )
                    known = any(
                        r.target_fqn.lower() == target.lower() and r.kind is kind
                        for r in relationships
                    )
                    if target.lower() != fqn.lower() and not known:
                        relationships.append(
                            SemanticRelationship(
                                target_fqn=target, kind=kind, evidence="unity catalog lineage"
                            )
                        )
                for key, label in _CONSUMER_KEYS:
                    for item in entry.get(key) or []:
                        ident = (
                            item.get("name")
                            or item.get("dashboard_id")
                            or item.get("job_id")
                            or item.get("notebook_id")
                            or item.get("id")
                            or ""
                        )
                        consumers.append(f"{label} {ident}".strip())

        properties: dict[str, Any] = {
            k: v
            for k, v in {
                "format": info.get("data_source_format"),
                "table_type": info.get("table_type"),
                "storage_location": info.get("storage_location"),
                "created_by": info.get("created_by"),
                "updated_by": info.get("updated_by"),
                "consumers": sorted(set(consumers)) or None,
            }.items()
            if v
        }
        asset = SemanticAsset(
            platform=Platform.DATABRICKS,
            fqn=fqn,
            database=catalog,
            schema_name=schema,
            name=name,
            asset_type=asset_type,
            description=info.get("comment") or "",
            owner=info.get("owner"),
            properties=properties,
            definition=definition,
            row_count=_int_or_none(
                props.get("spark.sql.statistics.numRows") or props.get("delta.numRows")
            ),
            bytes=_int_or_none(props.get("spark.sql.statistics.totalSize")),
            source_created_at=_epoch_ms(info.get("created_at")),
            source_updated_at=_epoch_ms(
                props.get("delta.lastCommitTimestamp") or info.get("updated_at")
            ),
            uri=f"{self._host}/explore/data/{catalog}/{schema}/{name}",
            fields=fields,
            relationships=relationships,
            metrics=metrics,
        )
        return infer_asset(asset)

    @staticmethod
    def _parse_metric_view(
        definition: str, fields_by_name: dict[str, SemanticField]
    ) -> tuple[list[SemanticMetric], list[SemanticRelationship]]:
        try:
            import yaml

            spec = yaml.safe_load(definition) or {}
        except Exception as exc:  # noqa: BLE001 - a malformed spec is still a document
            log.warning("databricks.metric_view_unparsed", error=str(exc))
            return [], []
        if not isinstance(spec, dict):
            return [], []
        relationships: list[SemanticRelationship] = []
        source = spec.get("source")
        if isinstance(source, str) and source.strip():
            relationships.append(
                SemanticRelationship(
                    target_fqn=source.strip(),
                    kind=RelationshipKind.METRIC_SOURCE,
                    evidence="metric view source",
                )
            )
        for join in spec.get("joins") or []:
            if not isinstance(join, dict) or not join.get("source"):
                continue
            # YAML 1.1 reads the bare key `on` as the boolean True; metric-view specs use it.
            on_clause = join.get("on", join.get(True, ""))
            pairs = _JOIN_ON.findall(str(on_clause or ""))
            relationships.append(
                SemanticRelationship(
                    target_fqn=str(join["source"]),
                    kind=RelationshipKind.JOIN_DECLARED,
                    source_columns=[p[0] for p in pairs],
                    target_columns=[p[2] for p in pairs],
                    evidence=f"metric view join {join.get('name', '')}".strip(),
                )
            )
        dimension_names: list[str] = []
        for dim in spec.get("dimensions") or []:
            if not isinstance(dim, dict) or not dim.get("name"):
                continue
            dimension_names.append(str(dim["name"]))
            field = fields_by_name.get(str(dim["name"]).casefold())
            if field is not None:
                field.role, field.role_confidence = FieldRole.DIMENSION, 1.0
                if not field.description and dim.get("comment"):
                    field.description = str(dim["comment"])
        metrics: list[SemanticMetric] = []
        for measure in spec.get("measures") or []:
            if not isinstance(measure, dict) or not measure.get("name"):
                continue
            expr = str(measure.get("expr") or "")
            aggregation = _AGGREGATION.match(expr)
            field = fields_by_name.get(str(measure["name"]).casefold())
            if field is not None:
                field.role, field.role_confidence = FieldRole.MEASURE, 1.0
                field.aggregation = aggregation.group(1).lower() if aggregation else None
            used = sorted(
                {m for m in re.findall(r"\b([a-z_][\w]*)\b", expr.lower()) if m in fields_by_name}
            )
            metrics.append(
                SemanticMetric(
                    name=str(measure["name"]),
                    expression=expr,
                    aggregation=aggregation.group(1).lower() if aggregation else None,
                    description=str(measure.get("comment") or (field.description if field else "")),
                    source=MetricSource.DECLARED,
                    dimensions=dimension_names,
                    fields=used,
                )
            )
        return metrics, relationships

    def _document(self, asset: SemanticAsset) -> SourceDocument:
        references = list(dict.fromkeys(r.target_fqn for r in asset.relationships))
        reference_kinds = {r.target_fqn: r.kind.value for r in asset.relationships}
        entities = [
            ExplicitEntity(name="Databricks", entity_type=EntityType.TECHNOLOGY, confidence=0.99),
            ExplicitEntity(
                name=_humanize(asset.database), entity_type=EntityType.PROJECT, confidence=0.9
            ),
        ]
        fmt = str(asset.properties.get("format") or "").upper()
        if fmt == "DELTA":
            entities.append(ExplicitEntity(name="Delta Lake", entity_type=EntityType.TECHNOLOGY))
        elif fmt == "ICEBERG":
            entities.append(
                ExplicitEntity(name="Apache Iceberg", entity_type=EntityType.TECHNOLOGY)
            )
        entities += [
            ExplicitEntity(name=tag, entity_type=EntityType.CONCEPT, confidence=0.8)
            for tag in asset.tags[:10]
        ]
        person = asset.owner if owner_is_person(asset.owner) else None
        return SourceDocument(
            external_id=asset.fqn,
            title=asset.fqn,
            content=render_asset_markdown(asset),
            uri=asset.uri,
            author=person,
            attributes={
                "connector": self.name,
                "platform": asset.platform.value,
                "catalog": asset.database,
                "schema": asset.schema_name,
                "asset": {
                    "fqn": asset.fqn,
                    "asset_type": asset.asset_type.value,
                    "kind": asset.kind.value,
                    "database": asset.database,
                    "schema": asset.schema_name,
                },
                "reference_kinds": reference_kinds,
                "semantic": asset.model_dump(mode="json"),
            },
            contributors=[person] if person else [],
            references=references,
            explicit_entities=entities,
            source_created_at=asset.source_created_at,
            source_updated_at=asset.source_updated_at,
        )
