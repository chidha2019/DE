"""Turns the selected paths of a pipeline into what a connector must read.

A path is a position in the hierarchy of the source: [database], [database, schema] or
[database, schema, table] for Snowflake and Databricks; [repo] or [repo, folder, ...] for GitHub;
[folder] or [folder, dashboard uid] for Grafana. Selecting a node includes all of its descendants,
so a selection that already covers a node makes narrower ones redundant.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass, field

from ech_core.schemas.pipelines import ScopeItem


@dataclass
class ScopePlan:
    """What to read below one root (a Snowflake database, a Databricks catalog)."""

    root: str
    whole: bool = False
    schemas: set[str] = field(default_factory=set)
    tables: dict[str, set[str]] = field(default_factory=dict)

    def allows(self, schema: str, table: str | None = None) -> bool:
        if self.whole or schema in self.schemas:
            return True
        chosen = self.tables.get(schema)
        if chosen is None:
            return False
        return True if table is None else table in chosen


def plan_scope(
    scope: Sequence[ScopeItem],
    *,
    root: Callable[[str], str] = str,
    rest: Callable[[str], str] = str,
) -> dict[str, ScopePlan]:
    """Group a selection by root, in the order the roots were first selected.

    root and rest normalise identifiers: Snowflake upper-cases databases and keeps schemas and
    tables as the catalogue spells them; Unity Catalog lower-cases everything.
    """
    plans: dict[str, ScopePlan] = {}
    for item in scope:
        key = root(item.path[0])
        plan = plans.setdefault(key, ScopePlan(root=key))
        if len(item.path) == 1:
            plan.whole = True
        elif len(item.path) == 2:
            plan.schemas.add(rest(item.path[1]))
        else:
            plan.tables.setdefault(rest(item.path[1]), set()).add(rest(item.path[2]))
    for plan in plans.values():
        if plan.whole:
            plan.schemas.clear()
            plan.tables.clear()
        else:
            for schema in plan.schemas:
                plan.tables.pop(schema, None)
    return plans


def path_prefix_match(path: Sequence[str], selected: Sequence[Sequence[str]]) -> bool:
    """True when the path lies at or below any selected path (segment-wise prefix)."""
    return any(len(sel) <= len(path) and list(path[: len(sel)]) == list(sel) for sel in selected)
