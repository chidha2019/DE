"""Connector contract.

A connector turns a remote knowledge repository into a stream of
:class:`SourceDocument` objects. Implementations should be *lazy* (async
generators), *idempotent* (stable ``external_id`` per object) and *honest*
about failures (raise :class:`ConnectorError`, never return partial garbage).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from datetime import datetime
from typing import Any, ClassVar

from pydantic import BaseModel, Field

from ech_core.domain.enums import DocumentKind, EntityType, SourceSystem
from ech_core.exceptions import ConnectorError
from ech_core.schemas.ingestion import ScopeItem, SourceOptions
from ech_core.schemas.pipelines import DiscoveryResult


class ExplicitEntity(BaseModel):
    """An entity the source already knows about (owner field, labels, ...)."""

    name: str
    entity_type: EntityType
    confidence: float = Field(default=0.95, ge=0.0, le=1.0)


class SourceDocument(BaseModel):
    external_id: str = Field(min_length=1)
    title: str = Field(min_length=1)
    content: str
    uri: str | None = None
    author: str | None = None
    mime_type: str = "text/markdown"
    language: str = "en"
    kind: DocumentKind = Field(
        default=DocumentKind.DOCUMENT,
        description="dataset when the document describes a catalog asset; the pipeline also "
        "derives it from a semantic payload",
    )
    attributes: dict[str, Any] = Field(default_factory=dict)
    contributors: list[str] = Field(default_factory=list, description="Person names")
    references: list[str] = Field(
        default_factory=list, description="external_ids of referenced documents (same source)"
    )
    explicit_entities: list[ExplicitEntity] = Field(default_factory=list)
    source_created_at: datetime | None = None
    source_updated_at: datetime | None = None


class ConnectorHealth(BaseModel):
    healthy: bool
    details: dict[str, Any] = Field(default_factory=dict)


class ConnectorOptions(BaseModel):
    limit: int | None = None
    full_refresh: bool = False
    simulate_failures: bool = False
    since: datetime | None = None
    scope: list[ScopeItem] = Field(
        default_factory=list,
        description="selected paths of the pipeline; empty reads everything the connection exposes",
    )
    source_options: SourceOptions = Field(default_factory=SourceOptions)


class BaseConnector(ABC):
    """Subclass and set the class attributes; implement :meth:`iter_documents`."""

    name: ClassVar[str]
    source_system: ClassVar[SourceSystem]
    display_name: ClassVar[str]
    description: ClassVar[str] = ""
    #: True when discover() can list the hierarchy of the source for the pipeline wizard
    discoverable: ClassVar[bool] = False
    #: names of the levels of the hierarchy, top down: ("Database", "Schema", "Table")
    scope_levels: ClassVar[tuple[str, ...]] = ()
    #: the SourceOptions fields this connector honours
    option_keys: ClassVar[tuple[str, ...]] = ()

    async def health_check(self) -> ConnectorHealth:
        return ConnectorHealth(healthy=True)

    async def estimate_count(self, options: ConnectorOptions) -> int | None:
        """Best-effort total used for progress bars; ``None`` when unknown."""
        return None

    async def discover(self, path: list[str]) -> DiscoveryResult:
        """List the children of a node of the source hierarchy ([] is the root)."""
        raise ConnectorError(f"{self.display_name} does not support browsing its schema")

    async def distinct_values(self, fqn: str, column: str, *, limit: int = 50) -> list[str] | None:
        """Up to ``limit`` distinct non-null values of one column, for facets read from the data.

        ``None`` when the source cannot run queries; the caller then relies on metadata alone.
        """
        return None

    def known_entities(self) -> list[ExplicitEntity]:
        """Gazetteer seed (project names, people directory, ...) for the extractor.

        Real connectors can populate this from the source's own metadata
        (Confluence space names, a people directory, repository topics).
        """
        return []

    @abstractmethod
    def iter_documents(self, options: ConnectorOptions) -> AsyncIterator[SourceDocument]:
        """Yield documents lazily. Must be an ``async def`` generator."""

    async def fetch_document(self, external_id: str) -> SourceDocument | None:
        """Fetch a single document; default implementation scans the stream."""
        async for doc in self.iter_documents(ConnectorOptions()):
            if doc.external_id == external_id:
                return doc
        return None
