"""Connector registry — name -> connector instance."""

from __future__ import annotations

from collections.abc import Iterator

from ech_core.config import Settings
from ech_core.exceptions import NotFoundError
from ingestion_service.connectors.base import BaseConnector


class ConnectorRegistry:
    def __init__(self) -> None:
        self._connectors: dict[str, BaseConnector] = {}
        # Instances swapped out by an edited connection; a run may still hold one, so they close at shutdown.
        self._retired: list[BaseConnector] = []

    def register(self, connector: BaseConnector) -> None:
        if connector.name in self._connectors:
            raise ValueError(f"connector '{connector.name}' already registered")
        self._connectors[connector.name] = connector

    def replace(self, connector: BaseConnector) -> None:
        """Register the connector, retiring the instance it replaces."""
        old = self._connectors.get(connector.name)
        if old is not None and old is not connector:
            self._retired.append(old)
        self._connectors[connector.name] = connector

    def remove(self, name: str) -> None:
        old = self._connectors.pop(name, None)
        if old is not None:
            self._retired.append(old)

    async def aclose_all(self) -> None:
        for connector in [*self._connectors.values(), *self._retired]:
            close = getattr(connector, "aclose", None)
            if close is None:
                continue
            try:
                await close()
            except Exception:  # noqa: BLE001, S112 - shutting down; one failed close must not stop the rest
                continue
        self._retired.clear()

    def get(self, name: str) -> BaseConnector:
        try:
            return self._connectors[name]
        except KeyError:
            raise NotFoundError(
                f"Unknown connector '{name}'", details={"available": sorted(self._connectors)}
            ) from None

    def names(self) -> list[str]:
        return sorted(self._connectors)

    def __iter__(self) -> Iterator[BaseConnector]:
        return iter(self._connectors.values())

    def __len__(self) -> int:
        return len(self._connectors)


def build_default_registry(settings: Settings | None = None) -> ConnectorRegistry:
    """Real connectors only, each registered when its configuration is present.

    * ``github-live`` - ``ECH_GITHUB_REPOS`` names at least one repository;
    * ``databricks`` - ``DATABRICKS_HOST`` + ``DATABRICKS_TOKEN`` and ``ECH_DATABRICKS_CATALOGS``
      (or ``ECH_DATABRICKS_SCHEMAS``);
    * ``snowflake`` - ``ECH_SNOWFLAKE_ACCOUNT``, a token or private key and
      ``ECH_SNOWFLAKE_DATABASES``.
    A connector whose configuration is incomplete is skipped with a warning, never a
    crash: the other connectors and manual ingest keep working.
    """
    from ech_core.exceptions import ConnectorError
    from ech_core.logging import get_logger

    log = get_logger(__name__)
    registry = ConnectorRegistry()
    if settings is None:
        return registry
    if settings.github_repo_list:
        from ingestion_service.connectors.github_live import GitHubRepoConnector

        registry.register(GitHubRepoConnector.from_settings(settings))
    if settings.databricks_catalog_list or settings.databricks_schema_list:
        from ingestion_service.connectors.databricks_uc import DatabricksCatalogConnector

        try:
            registry.register(DatabricksCatalogConnector.from_settings(settings))
        except ConnectorError as exc:
            log.warning("connector.skipped", connector="databricks", reason=str(exc))
    if settings.snowflake_database_list:
        from ingestion_service.connectors.snowflake import SnowflakeConnector

        try:
            registry.register(SnowflakeConnector.from_settings(settings))
        except ConnectorError as exc:
            log.warning("connector.skipped", connector="snowflake", reason=str(exc))
    if settings.grafana_url and settings.grafana_token:
        from ingestion_service.connectors.grafana import GrafanaConnector

        try:
            registry.register(GrafanaConnector.from_settings(settings))
        except ConnectorError as exc:
            log.warning("connector.skipped", connector="grafana", reason=str(exc))
    if settings.jira_base_url and settings.jira_email and settings.jira_api_token:
        from ingestion_service.connectors.jira import JiraConnector

        try:
            registry.register(JiraConnector.from_settings(settings))
        except ConnectorError as exc:
            log.warning("connector.skipped", connector="jira", reason=str(exc))
    return registry
