"""Jira connector: issues as documents, on the same connection the intent service uses.

Each issue matching ``jira_ingest_jql`` becomes one document with its summary, type, status, priority,
project, people, labels and description, so Genie can answer "which tickets ask for claims data" and the
graph links tickets to the people and projects behind them. The site, email and API token (saved on the
Connectors page, or JIRA_BASE_URL / JIRA_EMAIL / JIRA_API_TOKEN) also let the intent service read tickets by
key, sweep the intent JQL and post its questions and plans back on the issue.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from datetime import datetime
from typing import Any, ClassVar

from ech_core.config import Settings
from ech_core.domain.enums import EntityType, SourceSystem
from ech_core.exceptions import ConnectorError
from ech_core.jira_client import JiraClient, jira_identity
from ingestion_service.connectors.base import (
    BaseConnector,
    ConnectorHealth,
    ConnectorOptions,
    ExplicitEntity,
    SourceDocument,
)


def _parse_time(value: Any) -> datetime | None:
    """Jira writes 2026-10-27T13:18:04.000+0000; fromisoformat wants the offset as +00:00."""
    if not isinstance(value, str) or not value:
        return None
    text = value.replace("Z", "+00:00")
    if len(text) > 5 and text[-5] in "+-" and text[-4:].isdigit():
        text = f"{text[:-2]}:{text[-2:]}"
    try:
        return datetime.fromisoformat(text)
    except ValueError:
        return None


def issue_document(issue: dict[str, Any]) -> SourceDocument:
    """One flattened issue (``JiraClient._flatten``) as a markdown document."""
    key = str(issue.get("key") or "")
    summary = str(issue.get("summary") or key)
    facts = [
        ("Type", issue.get("issue_type")),
        ("Status", issue.get("status")),
        ("Priority", issue.get("priority")),
        ("Project", f"{issue.get('project_name')} ({issue.get('project')})" if issue.get("project_name") else issue.get("project")),
        ("Reporter", issue.get("reporter")),
        ("Assignee", issue.get("assignee")),
        ("Labels", ", ".join(issue.get("labels") or [])),
    ]
    lines = [f"# {key}: {summary}", ""]
    lines += [f"- **{label}:** {value}" for label, value in facts if value]
    lines += ["", "## Description", "", str(issue.get("description") or "").strip() or "_No description._"]
    people = [p for p in dict.fromkeys([issue.get("reporter"), issue.get("assignee")]) if p]
    entities = [ExplicitEntity(name="Jira", entity_type=EntityType.TECHNOLOGY)]
    if issue.get("project_name"):
        entities.append(ExplicitEntity(name=str(issue["project_name"]), entity_type=EntityType.PROJECT))
    return SourceDocument(
        external_id=key,
        title=f"{key} · {summary}"[:300],
        content="\n".join(lines),
        uri=issue.get("url"),
        author=issue.get("reporter") or None,
        attributes={
            "status": issue.get("status") or None,
            "issue_type": issue.get("issue_type") or None,
            "priority": issue.get("priority") or None,
            "project": issue.get("project") or None,
            "labels": list(issue.get("labels") or []),
        },
        contributors=[str(p) for p in people],
        explicit_entities=entities,
        source_created_at=_parse_time(issue.get("created")),
        source_updated_at=_parse_time(issue.get("updated")),
    )


class JiraConnector(BaseConnector):
    name: ClassVar[str] = "jira"
    source_system: ClassVar[SourceSystem] = SourceSystem.JIRA
    display_name: ClassVar[str] = "Jira"
    description: ClassVar[str] = "Issues as documents (summary, status, people, labels, description); the same connection feeds Intents."

    def __init__(self, client: JiraClient, *, jql: str, max_issues: int, intent_jql: str) -> None:
        self._jira = client
        self._jql = jql
        self._max = max_issues
        self._intent_jql = intent_jql

    @classmethod
    def from_settings(cls, settings: Settings) -> JiraConnector:
        identity = jira_identity(settings)
        if identity is None or settings.jira_api_token is None:
            raise ConnectorError("Jira connector needs the site URL, email and API token")
        client = JiraClient(identity[0], identity[1], settings.jira_api_token.get_secret_value().strip())
        return cls(client, jql=settings.jira_ingest_jql, max_issues=settings.jira_max_issues, intent_jql=settings.jira_intent_jql)

    async def aclose(self) -> None:
        await self._jira.aclose()

    async def health_check(self) -> ConnectorHealth:
        try:
            me = await self._jira.health()
        except ConnectorError as exc:
            return ConnectorHealth(healthy=False, details={"site": self._jira.base_url, "error": exc.message})
        details: dict[str, Any] = {"site": self._jira.base_url, "account": me.get("account")}
        try:
            details["intent tickets"] = len(await self._jira.search(self._intent_jql, max_results=50))
        except ConnectorError as exc:
            # Signed in, but the intent JQL does not run: worth saying, not a failed connection.
            details["intent JQL"] = exc.message
        return ConnectorHealth(healthy=True, details=details)

    async def iter_documents(self, options: ConnectorOptions) -> AsyncIterator[SourceDocument]:
        limit = min(options.limit or self._max, self._max)
        for issue in await self._jira.search_all(self._jql, limit=limit):
            if issue.get("key"):
                yield issue_document(issue)

    async def fetch_document(self, external_id: str) -> SourceDocument | None:
        try:
            return issue_document(await self._jira.issue(external_id))
        except ConnectorError:
            return None
