"""Grafana connector: dashboards, panel queries and alert rules as documents.

Each dashboard becomes one document whose content lists its panels and the queries they run,
plus the tables and metrics those queries reference, so a question like "which dashboards use
the lapse experience fact" has something to retrieve. Each alert rule becomes one document
carrying its condition, labels, annotations and current state.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from datetime import datetime
from typing import Any, ClassVar

from ech_core.config import Settings
from ech_core.domain.enums import DocumentKind, EntityType, SourceSystem
from ech_core.exceptions import ConnectorError
from ech_core.grafana_client import (
    GrafanaClient,
    PanelQuery,
    panel_queries,
    references_of,
    rule_queries,
)
from ech_core.schemas.pipelines import DiscoveryNode, DiscoveryResult
from ingestion_service.connectors.base import (
    BaseConnector,
    ConnectorHealth,
    ConnectorOptions,
    ExplicitEntity,
    SourceDocument,
)
from ingestion_service.connectors.scope import path_prefix_match

ALERTS_KEY = "__alerts__"
_DATASOURCE_TECH = {
    "prometheus": "Prometheus",
    "loki": "Loki",
    "tempo": "Tempo",
    "postgres": "PostgreSQL",
    "grafana-postgresql-datasource": "PostgreSQL",
    "mysql": "MySQL",
    "mssql": "SQL Server",
    "grafana-snowflake-datasource": "Snowflake",
    "grafana-databricks-datasource": "Databricks",
    "grafana-bigquery-datasource": "BigQuery",
    "elasticsearch": "Elasticsearch",
    "cloudwatch": "CloudWatch",
    "influxdb": "InfluxDB",
}


def _parse_time(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def _technologies(queries: list[PanelQuery]) -> list[ExplicitEntity]:
    names = ["Grafana"]
    for q in queries:
        label = _DATASOURCE_TECH.get((q.datasource or "").lower())
        if label and label not in names:
            names.append(label)
    return [ExplicitEntity(name=n, entity_type=EntityType.TECHNOLOGY) for n in names]


def _query_lines(queries: list[PanelQuery]) -> list[str]:
    lines: list[str] = []
    for q in queries[:40]:
        expr = " ".join(q.expr.split())
        if len(expr) > 400:
            expr = expr[:399] + "…"
        source = f" · {q.datasource}" if q.datasource else ""
        lines.append(f"- **{q.panel}** ({q.panel_type}{source}): `{expr}`")
    if len(queries) > 40:
        lines.append(f"- … {len(queries) - 40} more queries")
    return lines


def dashboard_document(client_base: str, payload: dict[str, Any]) -> SourceDocument:
    """One document per dashboard from the ``/api/dashboards/uid/{uid}`` payload."""
    dash = payload.get("dashboard") or {}
    meta = payload.get("meta") or {}
    uid = str(dash.get("uid") or meta.get("uid") or "")
    title = str(dash.get("title") or uid or "Untitled dashboard")
    folder = meta.get("folderTitle") or None
    tags = [str(t) for t in (dash.get("tags") or []) if t]
    queries = panel_queries(dash)
    tables, metrics = references_of(queries)
    panels = [p for p in dash.get("panels") or [] if isinstance(p, dict) and p.get("type") != "row"]
    variables = [v for v in (dash.get("templating") or {}).get("list") or [] if isinstance(v, dict)]
    url_path = meta.get("url") or (f"/d/{uid}" if uid else "")
    url = f"{client_base}{url_path}" if url_path and not url_path.startswith("http") else url_path or None

    lines = [f"# {title}", ""]
    header = [f"Grafana dashboard `{uid}`"]
    if folder:
        header.append(f"folder **{folder}**")
    if tags:
        header.append("tags " + ", ".join(f"`{t}`" for t in tags))
    lines.append(" · ".join(header))
    if dash.get("description"):
        lines += ["", str(dash["description"])]
    lines += ["", f"## Panels ({len(panels)})"]
    lines += _query_lines(queries) or ["- no queries recorded on the panels"]
    if tables:
        lines += ["", "## Tables referenced", ", ".join(f"`{t}`" for t in tables)]
    if metrics:
        lines += ["", "## Metrics referenced", ", ".join(f"`{m}`" for m in metrics)]
    if variables:
        lines += ["", "## Variables"]
        lines += [f"- `{v.get('name')}` ({v.get('type', 'query')})" for v in variables]

    return SourceDocument(
        external_id=f"dashboard:{uid or title}",
        title=title,
        content="\n".join(lines),
        uri=url,
        kind=DocumentKind.DOCUMENT,
        attributes={
            "grafana_type": "dashboard",
            "uid": uid,
            "folder": folder,
            "tags": tags,
            "panels": len(panels),
            "queries": len(queries),
            "tables": tables,
            "metrics": metrics,
            "version": dash.get("version"),
        },
        explicit_entities=_technologies(queries) + ([ExplicitEntity(name=str(folder), entity_type=EntityType.PROJECT)] if folder else []),
        source_updated_at=_parse_time(meta.get("updated")),
        source_created_at=_parse_time(meta.get("created")),
    )


def alert_rule_document(rule: dict[str, Any]) -> SourceDocument:
    """One document per Grafana-managed alert rule (merged provisioning + state shape)."""
    uid = str(rule.get("uid") or "")
    title = str(rule.get("title") or uid or "Untitled rule")
    queries = rule_queries(rule)
    tables, metrics = references_of(queries)
    labels = rule.get("labels") or {}
    annotations = rule.get("annotations") or {}
    state = str(rule.get("state") or "unknown")

    lines = [f"# Alert rule: {title}", ""]
    lines.append(f"State **{state}**" + (f" · severity **{labels['severity']}**" if labels.get("severity") else "") + (f" · pending for {rule['for']}" if rule.get("for") else ""))
    if annotations.get("summary"):
        lines += ["", str(annotations["summary"])]
    if annotations.get("description") and annotations.get("description") != annotations.get("summary"):
        lines += ["", str(annotations["description"])]
    if annotations.get("runbook_url"):
        lines += ["", f"Runbook: {annotations['runbook_url']}"]
    lines += ["", "## Condition"]
    lines += _query_lines(queries) or ["- no query recorded"]
    if labels:
        lines += ["", "## Labels", ", ".join(f"`{k}={v}`" for k, v in labels.items())]
    if tables:
        lines += ["", "## Tables referenced", ", ".join(f"`{t}`" for t in tables)]
    if metrics:
        lines += ["", "## Metrics referenced", ", ".join(f"`{m}`" for m in metrics)]

    return SourceDocument(
        external_id=f"alert:{uid or title}",
        title=f"Alert: {title}",
        content="\n".join(lines),
        uri=rule.get("url"),
        kind=DocumentKind.DOCUMENT,
        attributes={
            "grafana_type": "alert_rule",
            "uid": uid,
            "state": state,
            "health": rule.get("health"),
            "severity": labels.get("severity"),
            "folder": rule.get("folder"),
            "group": rule.get("group"),
            "tables": tables,
            "metrics": metrics,
            "runbook_url": annotations.get("runbook_url"),
        },
        explicit_entities=_technologies(queries),
        source_updated_at=_parse_time(rule.get("updated")),
    )


class GrafanaConnector(BaseConnector):
    name: ClassVar[str] = "grafana"
    source_system: ClassVar[SourceSystem] = SourceSystem.GRAFANA
    display_name: ClassVar[str] = "Grafana"
    description: ClassVar[str] = "Dashboards, panel queries and alert rules, with the tables and metrics they reference."
    discoverable: ClassVar[bool] = True
    scope_levels: ClassVar[tuple[str, ...]] = ("Folder", "Dashboard")
    option_keys: ClassVar[tuple[str, ...]] = ("include_alert_rules",)

    def __init__(self, url: str, token: str | None, *, max_dashboards: int = 500, client: GrafanaClient | None = None) -> None:
        if not url:
            raise ConnectorError("Grafana connector needs GRAFANA_URL")
        self._url = url.rstrip("/")
        self._max_dashboards = max_dashboards
        self._grafana = client or GrafanaClient(self._url, token)

    @classmethod
    def from_settings(cls, settings: Settings) -> GrafanaConnector:
        if not settings.grafana_url or not settings.grafana_token:
            raise ConnectorError("Grafana connector needs GRAFANA_URL and GRAFANA_TOKEN")
        return cls(settings.grafana_url, settings.grafana_token.get_secret_value(), max_dashboards=settings.grafana_max_dashboards)

    async def aclose(self) -> None:
        await self._grafana.aclose()

    async def health_check(self) -> ConnectorHealth:
        try:
            health = await self._grafana.health()
            org = await self._grafana.org()
            dashboards = await self._grafana.search_dashboards(limit=self._max_dashboards)
        except ConnectorError as exc:
            return ConnectorHealth(healthy=False, details={"url": self._url, "error": exc.message, **exc.details})
        return ConnectorHealth(
            healthy=True,
            details={"url": self._url, "version": health.get("version"), "org": org.get("name"), "dashboards": len(dashboards)},
        )

    async def estimate_count(self, options: ConnectorOptions) -> int | None:
        try:
            snap = await self._grafana.snapshot(max_dashboards=self._max_dashboards)
        except ConnectorError:
            return None
        dashboards, rules = self._select(snap, options)
        total = len(dashboards) + len(rules)
        return min(total, options.limit) if options.limit else total

    @staticmethod
    def _folder(summary: dict[str, Any]) -> str:
        return str(summary.get("folderTitle") or "General")

    def _select(self, snap: Any, options: ConnectorOptions) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        """Dashboards and alert rules for the selected folders; no selection reads everything."""
        dashboards, rules = list(snap.dashboards), list(snap.rules)
        if options.scope:
            picked = [list(item.path) for item in options.scope]
            dashboards = [
                d for d in dashboards if path_prefix_match([self._folder(d), str(d.get("uid") or "")], picked)
            ]
            if not any(p[0] == ALERTS_KEY for p in picked):
                rules = []
        if options.source_options.include_alert_rules is False:
            rules = []
        return dashboards, rules

    # ------------------------------------------------------------------ schema browser
    async def discover(self, path: list[str]) -> DiscoveryResult:
        """Folders (with an Alert rules node), then the dashboards in a folder."""
        snap = await self._grafana.snapshot(max_dashboards=self._max_dashboards)
        nodes: list[DiscoveryNode] = []
        if not path:
            folders: dict[str, int] = {}
            for d in snap.dashboards:
                folders[self._folder(d)] = folders.get(self._folder(d), 0) + 1
            nodes += [
                DiscoveryNode(
                    name=name,
                    path=[name],
                    kind="folder",
                    expandable=True,
                    child_count=count,
                    detail=f"{count} dashboards",
                )
                for name, count in sorted(folders.items())
            ]
            nodes.append(
                DiscoveryNode(
                    name="Alert rules",
                    path=[ALERTS_KEY],
                    kind="alerts",
                    description="Grafana-managed alert rules with their current state",
                    detail=f"{len(snap.rules)} rules",
                    child_count=len(snap.rules),
                )
            )
        elif len(path) == 1 and path[0] != ALERTS_KEY:
            for d in snap.dashboards:
                if self._folder(d) != path[0]:
                    continue
                uid = str(d.get("uid") or "")
                nodes.append(
                    DiscoveryNode(
                        name=str(d.get("title") or uid),
                        path=[path[0], uid],
                        kind="dashboard",
                        detail=", ".join(str(t) for t in (d.get("tags") or [])[:4]),
                    )
                )
        else:
            raise ConnectorError("This Grafana node has no children")
        return DiscoveryResult(connector=self.name, path=path, nodes=nodes)

    def known_entities(self) -> list[ExplicitEntity]:
        return [ExplicitEntity(name="Grafana", entity_type=EntityType.TECHNOLOGY)]

    async def iter_documents(self, options: ConnectorOptions) -> AsyncIterator[SourceDocument]:
        snap = await self._grafana.snapshot(max_dashboards=self._max_dashboards)
        produced = 0
        dashboards, rules = self._select(snap, options)
        for summary in dashboards:
            if options.limit and produced >= options.limit:
                return
            uid = summary.get("uid")
            if not uid:
                continue
            payload = await self._grafana.dashboard(str(uid))
            doc = dashboard_document(self._grafana.base, payload)
            if options.since and doc.source_updated_at and doc.source_updated_at < options.since:
                continue
            produced += 1
            yield doc
        for rule in rules:
            if options.limit and produced >= options.limit:
                return
            produced += 1
            yield alert_rule_document(rule)
