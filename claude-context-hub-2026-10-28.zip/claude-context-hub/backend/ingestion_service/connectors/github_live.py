"""Live GitHub connector — crawls real repositories.

Uses the REST API only for cheap metadata (repository, tree, languages,
contributors) and fetches file bodies from ``raw.githubusercontent.com``, which
is not subject to the small unauthenticated API quota (60 requests/hour). With
``ECH_GITHUB_TOKEN`` set the quota is 5 000/hour. Repository metadata is cached
for a few minutes so the admin UI's connector health polling costs nothing.

Document model
--------------
* one document per text file (markdown as-is; code/config wrapped in a fenced
  block so the chunker keeps it atomic and hard-splits by tokens)
* ``external_id = owner/repo:path`` — the same scheme as the mock connector
* references: markdown links, Python imports and path-like tokens that resolve
  to other files in the tree (→ ``REFERENCES`` edges / lineage)
* explicit entities: the repository as a Project, detected languages as
  Technologies, contributors as Persons (→ ``CONTRIBUTED_BY`` edges)
"""

from __future__ import annotations

import asyncio
import fnmatch
import re
import time
from collections.abc import AsyncIterator, Iterable, Sequence
from dataclasses import dataclass
from datetime import datetime
from pathlib import PurePosixPath
from typing import Any, ClassVar

import httpx

from ech_core.config import Settings
from ech_core.domain.enums import EntityType, SourceSystem
from ech_core.exceptions import ConnectorError
from ech_core.logging import get_logger
from ech_core.schemas.pipelines import DiscoveryNode, DiscoveryResult
from ingestion_service.connectors.base import (
    BaseConnector,
    ConnectorHealth,
    ConnectorOptions,
    ExplicitEntity,
    SourceDocument,
)
from ingestion_service.connectors.scope import path_prefix_match

log = get_logger(__name__)

DEFAULT_INCLUDE_EXTENSIONS: tuple[str, ...] = (
    ".md",
    ".rst",
    ".txt",
    ".py",
    ".sql",
    ".yml",
    ".yaml",
    ".json",
    ".toml",
    ".cfg",
    ".ini",
    ".sh",
    ".in",
    ".example",
    ".env",
    ".tf",
    ".hcl",
    ".js",
    ".ts",
    ".tsx",
    ".go",
    ".java",
    ".kt",
    ".rb",
    ".cs",
    ".scala",
    ".graphql",
    ".proto",
    ".xml",
    ".properties",
)
DEFAULT_INCLUDE_FILENAMES: tuple[str, ...] = (
    "Dockerfile",
    "Jenkinsfile",
    "Makefile",
    "Procfile",
    "LICENSE",
    "CODEOWNERS",
)
DEFAULT_EXCLUDE_GLOBS: tuple[str, ...] = (
    "*.lock",
    "*package-lock.json",
    "*yarn.lock",
    "*node_modules/*",
    "*.git/*",
    "*dist/*",
    "*build/*",
    "*__pycache__/*",
    "*.min.js",
    "*.min.css",
    "*vendor/*",
    "*.ipynb",
)
_LANGUAGE_BY_EXT: dict[str, str] = {
    ".py": "python",
    ".sql": "sql",
    ".yml": "yaml",
    ".yaml": "yaml",
    ".json": "json",
    ".toml": "toml",
    ".md": "markdown",
    ".rst": "rst",
    ".sh": "bash",
    ".ini": "ini",
    ".cfg": "ini",
    ".example": "ini",
    ".env": "ini",
    ".in": "text",
    ".txt": "text",
    ".tf": "hcl",
    ".hcl": "hcl",
    ".js": "javascript",
    ".ts": "typescript",
    ".tsx": "tsx",
    ".go": "go",
    ".java": "java",
    ".kt": "kotlin",
    ".rb": "ruby",
    ".cs": "csharp",
    ".scala": "scala",
    ".graphql": "graphql",
    ".proto": "protobuf",
    ".xml": "xml",
    ".properties": "properties",
}
_LANGUAGE_BY_NAME: dict[str, str] = {
    "Dockerfile": "dockerfile",
    "Jenkinsfile": "groovy",
    "Makefile": "makefile",
    "Procfile": "text",
    "LICENSE": "text",
    "CODEOWNERS": "text",
}
# GitHub language names -> Technology entity names (gazetteer casing)
_TECH_BY_LANGUAGE: dict[str, str] = {
    "Python": "Python",
    "Dockerfile": "Docker",
    "TypeScript": "TypeScript",
    "JavaScript": "JavaScript",
    "Go": "Go",
    "Java": "Java",
    "Kotlin": "Kotlin",
    "Shell": "Bash",
    "HCL": "Terraform",
    "PLpgSQL": "PostgreSQL",
    "TSQL": "SQL",
    "Jupyter Notebook": "Jupyter",
    "Scala": "Scala",
    "Ruby": "Ruby",
    "C#": "C#",
    "Rust": "Rust",
}
_TECH_BY_FILE: dict[str, str] = {
    ".sql": "SQL",
    "Jenkinsfile": "Jenkins",
    "Dockerfile": "Docker",
    ".tf": "Terraform",
}

_MD_LINK_RE = re.compile(r"\[[^\]]*\]\(([^)\s#]+)(?:#[^)]*)?\)")
_PATH_TOKEN_RE = re.compile(
    r"(?<![\w/])((?:[\w.\-]+/)+[\w.\-]+\.(?:py|sql|ya?ml|json|md|toml|cfg|ini|sh|tf))(?![\w/])"
)
_PY_IMPORT_RE = re.compile(r"^\s*(?:from\s+([\w.]+)\s+import|import\s+([\w.]+))", re.MULTILINE)
_META_TTL_SECONDS = 600.0


@dataclass(frozen=True)
class RepoSpec:
    owner: str
    name: str
    ref: str | None = None

    @property
    def full_name(self) -> str:
        return f"{self.owner}/{self.name}"

    @classmethod
    def parse(cls, spec: str) -> RepoSpec:
        spec = spec.strip()
        if spec.startswith("https://github.com/"):
            spec = spec[len("https://github.com/") :].removesuffix(".git").strip("/")
        repo, _, ref = spec.partition("@")
        owner, _, name = repo.strip("/").partition("/")
        name = name.removesuffix(".git")
        if not owner or not name or "/" in name:
            raise ValueError(f"invalid GitHub repository spec {spec!r}; expected owner/name[@ref]")
        return cls(owner=owner, name=name, ref=ref or None)


@dataclass
class _RepoSnapshot:
    spec: RepoSpec
    ref: str
    meta: dict[str, Any]
    blobs: list[dict[str, Any]]
    languages: dict[str, int]
    contributors: list[str]
    fetched_at: float


class GitHubRepoConnector(BaseConnector):
    name: ClassVar[str] = "github-live"
    source_system: ClassVar[SourceSystem] = SourceSystem.GITHUB
    display_name: ClassVar[str] = "GitHub (live API)"
    description: ClassVar[str] = (
        "Markdown, code and configuration files from the repositories listed in ECH_GITHUB_REPOS."
    )
    discoverable: ClassVar[bool] = True
    scope_levels: ClassVar[tuple[str, ...]] = ("Repository", "Folder")
    option_keys: ClassVar[tuple[str, ...]] = ("include_extensions", "exclude_globs")

    def __init__(
        self,
        *,
        repos: Sequence[str],
        token: str | None = None,
        api_url: str = "https://api.github.com",
        raw_url: str = "https://raw.githubusercontent.com",
        max_file_bytes: int = 256 * 1024,
        include_extensions: Iterable[str] = DEFAULT_INCLUDE_EXTENSIONS,
        include_filenames: Iterable[str] = DEFAULT_INCLUDE_FILENAMES,
        exclude_globs: Iterable[str] = DEFAULT_EXCLUDE_GLOBS,
        fetch_concurrency: int = 8,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self._specs = [RepoSpec.parse(r) for r in repos]
        if not self._specs:
            raise ValueError("GitHubRepoConnector needs at least one repository")
        self._token = token
        self._api_url = api_url.rstrip("/")
        self._raw_url = raw_url.rstrip("/")
        self._max_file_bytes = max_file_bytes
        self._include_ext = {e.lower() for e in include_extensions}
        self._include_names = set(include_filenames)
        self._exclude_globs = list(exclude_globs)
        self._semaphore = asyncio.Semaphore(max(1, fetch_concurrency))
        self._client = client
        self._snapshots: dict[str, _RepoSnapshot] = {}
        self._rate_remaining: int | None = None

    @classmethod
    def from_settings(cls, settings: Settings) -> GitHubRepoConnector:
        token = settings.github_token.get_secret_value() if settings.github_token else None
        return cls(
            repos=settings.github_repo_list,
            token=token or None,
            api_url=settings.github_api_url,
            raw_url=settings.github_raw_url,
            max_file_bytes=settings.github_max_file_kb * 1024,
            fetch_concurrency=settings.github_fetch_concurrency,
        )

    # ------------------------------------------------------------------ HTTP
    def _http(self) -> httpx.AsyncClient:
        if self._client is None:
            headers = {
                "Accept": "application/vnd.github+json",
                "User-Agent": "enterprise-context-hub/0.1",
                "X-GitHub-Api-Version": "2022-11-28",
            }
            if self._token:
                headers["Authorization"] = f"Bearer {self._token}"
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(30.0, connect=10.0), headers=headers
            )
        return self._client

    async def aclose(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def _get(
        self, url: str, *, params: dict[str, Any] | None = None, attempts: int = 3
    ) -> httpx.Response:
        delay = 1.0
        last: str = ""
        for attempt in range(1, attempts + 1):
            try:
                response = await self._http().get(url, params=params)
            except httpx.HTTPError as exc:
                last = f"transport error: {exc}"
            else:
                remaining = response.headers.get("x-ratelimit-remaining")
                if remaining is not None and remaining.isdigit():
                    self._rate_remaining = int(remaining)
                if response.status_code < 400:
                    return response
                if response.status_code in (403, 429) and remaining == "0":
                    reset = response.headers.get("x-ratelimit-reset")
                    reset_at = (
                        datetime.fromtimestamp(int(reset)).isoformat()
                        if reset and reset.isdigit()
                        else None
                    )
                    raise ConnectorError(
                        "GitHub API rate limit exhausted",
                        details={"url": url, "resets_at": reset_at, "hint": "set ECH_GITHUB_TOKEN"},
                    )
                if response.status_code == 404:
                    raise ConnectorError(
                        "GitHub resource not found", details={"url": url, "status": 404}
                    )
                if response.status_code < 500 and response.status_code != 429:
                    raise ConnectorError(
                        "GitHub request failed",
                        details={
                            "url": url,
                            "status": response.status_code,
                            "body": response.text[:200],
                        },
                    )
                last = f"HTTP {response.status_code}"
            if attempt < attempts:
                await asyncio.sleep(delay)
                delay *= 2
        raise ConnectorError(
            "GitHub request failed after retries", details={"url": url, "error": last}
        )

    async def _api(self, path: str, **params: Any) -> Any:
        response = await self._get(f"{self._api_url}{path}", params=params or None)
        return response.json()

    # ------------------------------------------------------------------ repository snapshot
    async def _snapshot(self, spec: RepoSpec, *, force: bool = False) -> _RepoSnapshot:
        cached = self._snapshots.get(spec.full_name)
        if cached and not force and time.monotonic() - cached.fetched_at < _META_TTL_SECONDS:
            return cached
        meta = await self._api(f"/repos/{spec.owner}/{spec.name}")
        ref = spec.ref or str(meta.get("default_branch") or "main")
        tree = await self._api(f"/repos/{spec.owner}/{spec.name}/git/trees/{ref}", recursive=1)
        if tree.get("truncated"):
            log.warning("github.tree_truncated", repo=spec.full_name, ref=ref)
        blobs = [b for b in tree.get("tree", []) if b.get("type") == "blob"]
        languages: dict[str, int] = {}
        contributors: list[str] = []
        try:
            languages = dict(await self._api(f"/repos/{spec.owner}/{spec.name}/languages"))
        except ConnectorError as exc:
            log.warning("github.languages_unavailable", repo=spec.full_name, error=str(exc))
        try:
            rows = await self._api(f"/repos/{spec.owner}/{spec.name}/contributors", per_page=20)
            contributors = [str(r["login"]) for r in rows if isinstance(r, dict) and r.get("login")]
        except ConnectorError as exc:
            log.warning("github.contributors_unavailable", repo=spec.full_name, error=str(exc))
        snapshot = _RepoSnapshot(
            spec=spec,
            ref=ref,
            meta=meta,
            blobs=blobs,
            languages=languages,
            contributors=contributors,
            fetched_at=time.monotonic(),
        )
        self._snapshots[spec.full_name] = snapshot
        return snapshot

    def _selected(
        self,
        blobs: Iterable[dict[str, Any]],
        options: ConnectorOptions | None = None,
        subpaths: list[list[str]] | None = None,
    ) -> list[dict[str, Any]]:
        """Ingestible files: server defaults, narrowed by the pipeline options and selected folders."""
        extensions = set(self._include_ext)
        excludes = list(self._exclude_globs)
        if options is not None:
            chosen_ext = options.source_options.include_extensions
            if chosen_ext:
                extensions = {e if e.startswith(".") else f".{e}" for e in (x.lower() for x in chosen_ext)}
            excludes += options.source_options.exclude_globs or []
        chosen: list[dict[str, Any]] = []
        for blob in blobs:
            path = str(blob.get("path", ""))
            size = int(blob.get("size") or 0)
            name = PurePosixPath(path).name
            ext = PurePosixPath(path).suffix.lower()
            if subpaths is not None and not path_prefix_match(path.split("/"), subpaths):
                continue
            if any(fnmatch.fnmatch(path, pat) for pat in excludes):
                continue
            if name not in self._include_names and ext not in extensions:
                continue
            if size <= 0 or size > self._max_file_bytes:
                continue
            chosen.append(blob)
        chosen.sort(key=lambda b: str(b["path"]))
        return chosen

    def _picked(self, options: ConnectorOptions) -> list[tuple[RepoSpec, list[list[str]] | None]]:
        """The repositories to read, each with the folders selected in it (None = the whole repo)."""
        if not options.scope:
            return [(spec, None) for spec in self._specs]
        by_repo: dict[str, list[list[str]]] = {}
        for item in options.scope:
            by_repo.setdefault(item.path[0].lower(), []).append(list(item.path[1:]))
        picked: list[tuple[RepoSpec, list[list[str]] | None]] = []
        for spec in self._specs:
            chosen = by_repo.get(spec.full_name.lower())
            if chosen is not None:
                picked.append((spec, None if any(not c for c in chosen) else chosen))
        return picked

    # ------------------------------------------------------------------ whole-repository reads (repo graph crawler)
    async def repository_snapshot(self, spec: RepoSpec) -> dict[str, Any]:
        """Metadata, resolved ref, commit SHA and every blob of one repository (fresh, not cached)."""
        snap = await self._snapshot(spec, force=True)
        sha: str | None = None
        try:
            commit = await self._api(f"/repos/{spec.owner}/{spec.name}/commits/{snap.ref}")
            sha = str(commit.get("sha") or "") or None
        except ConnectorError as exc:
            log.warning("github.commit_unavailable", repo=spec.full_name, error=str(exc))
        return {"ref": snap.ref, "sha": sha, "meta": snap.meta, "blobs": snap.blobs, "languages": snap.languages, "snapshot": snap}

    async def read_blob_text(self, snapshot: Any, blob: dict[str, Any]) -> str | None:
        """One file's text (None for binary content), through the connector's concurrency limit."""
        return await self._fetch_text(snapshot, blob)

    # ------------------------------------------------------------------ connector API
    async def health_check(self) -> ConnectorHealth:
        details: dict[str, Any] = {"repositories": [], "authenticated": bool(self._token)}
        healthy = True
        for spec in self._specs:
            try:
                snap = await self._snapshot(spec)
                details["repositories"].append(
                    {
                        "repo": spec.full_name,
                        "ref": snap.ref,
                        "files": len(self._selected(snap.blobs)),
                        "pushed_at": snap.meta.get("pushed_at"),
                    }
                )
            except ConnectorError as exc:
                healthy = False
                details["repositories"].append(
                    {"repo": spec.full_name, "error": exc.message, **exc.details}
                )
        if self._rate_remaining is not None:
            details["api_rate_limit_remaining"] = self._rate_remaining
        return ConnectorHealth(healthy=healthy, details=details)

    async def estimate_count(self, options: ConnectorOptions) -> int | None:
        total = 0
        for spec, subpaths in self._picked(options):
            try:
                total += len(self._selected((await self._snapshot(spec)).blobs, options, subpaths))
            except ConnectorError:
                return None
        return min(total, options.limit) if options.limit else total

    # ------------------------------------------------------------------ schema browser
    async def discover(self, path: list[str]) -> DiscoveryResult:
        """The configured repositories, then the folders and files that would be ingested."""
        limit = 1000
        nodes: list[DiscoveryNode] = []
        if not path:
            for spec in self._specs:
                try:
                    snap = await self._snapshot(spec)
                except ConnectorError as exc:
                    nodes.append(
                        DiscoveryNode(
                            name=spec.full_name,
                            path=[spec.full_name],
                            kind="repo",
                            selectable=False,
                            description=f"unavailable: {exc.message}",
                        )
                    )
                    continue
                nodes.append(
                    DiscoveryNode(
                        name=spec.full_name,
                        path=[spec.full_name],
                        kind="repo",
                        expandable=True,
                        description=str(snap.meta.get("description") or ""),
                        detail=f"branch {snap.ref}",
                        child_count=len(self._selected(snap.blobs)),
                    )
                )
        else:
            spec = next((s for s in self._specs if s.full_name.lower() == path[0].lower()), None)
            if spec is None:
                raise ConnectorError(f"{path[0]} is not one of the configured repositories")
            prefix = path[1:]
            folders: dict[str, int] = {}
            files: list[dict[str, Any]] = []
            for blob in self._selected((await self._snapshot(spec)).blobs):
                parts = str(blob["path"]).split("/")
                if parts[: len(prefix)] != prefix or len(parts) <= len(prefix):
                    continue
                rest = parts[len(prefix) :]
                if len(rest) == 1:
                    files.append(blob)
                else:
                    folders[rest[0]] = folders.get(rest[0], 0) + 1
            nodes += [
                DiscoveryNode(
                    name=name,
                    path=[*path, name],
                    kind="folder",
                    expandable=True,
                    child_count=count,
                    detail=f"{count} files",
                )
                for name, count in sorted(folders.items())
            ]
            nodes += [
                DiscoveryNode(
                    name=PurePosixPath(str(b["path"])).name,
                    path=[*path, PurePosixPath(str(b["path"])).name],
                    kind="file",
                    detail=f"{int(b.get('size') or 0):,} bytes",
                )
                for b in files
            ]
        return DiscoveryResult(
            connector=self.name, path=path, nodes=nodes[:limit], truncated=len(nodes) > limit
        )

    def known_entities(self) -> list[ExplicitEntity]:
        return [
            ExplicitEntity(name=_humanize(spec.name), entity_type=EntityType.PROJECT)
            for spec in self._specs
        ]

    async def iter_documents(self, options: ConnectorOptions) -> AsyncIterator[SourceDocument]:
        emitted = 0
        for spec, subpaths in self._picked(options):
            snap = await self._snapshot(spec, force=True)
            blobs = self._selected(snap.blobs, options, subpaths)
            if options.limit:
                blobs = blobs[: max(0, options.limit - emitted)]
            tree_paths = {str(b["path"]) for b in snap.blobs}
            batch_size = max(1, self._semaphore._value)  # noqa: SLF001 - initial concurrency
            for start in range(0, len(blobs), batch_size):
                batch = blobs[start : start + batch_size]
                texts = await asyncio.gather(*(self._fetch_text(snap, b) for b in batch))
                for blob, text in zip(batch, texts, strict=True):
                    if text is None:
                        continue
                    yield self._build_document(snap, blob, text, tree_paths)
                    emitted += 1
            if options.limit and emitted >= options.limit:
                return

    async def fetch_document(self, external_id: str) -> SourceDocument | None:
        repo, _, path = external_id.partition(":")
        for spec in self._specs:
            if spec.full_name != repo:
                continue
            snap = await self._snapshot(spec)
            blob = next((b for b in snap.blobs if b.get("path") == path), None)
            if blob is None:
                return None
            text = await self._fetch_text(snap, blob)
            return (
                None
                if text is None
                else self._build_document(snap, blob, text, {b["path"] for b in snap.blobs})
            )
        return None

    # ------------------------------------------------------------------ documents
    async def _fetch_text(self, snap: _RepoSnapshot, blob: dict[str, Any]) -> str | None:
        path = str(blob["path"])
        url = f"{self._raw_url}/{snap.spec.owner}/{snap.spec.name}/{snap.ref}/{path}"
        async with self._semaphore:
            response = await self._get(url)
        if b"\x00" in response.content[:4096]:
            return None  # binary despite the extension
        try:
            return response.content.decode("utf-8")
        except UnicodeDecodeError:
            return response.content.decode("latin-1", errors="replace")

    def _build_document(
        self, snap: _RepoSnapshot, blob: dict[str, Any], text: str, tree_paths: set[str]
    ) -> SourceDocument:
        spec = snap.spec
        path = str(blob["path"])
        p = PurePosixPath(path)
        language = _LANGUAGE_BY_NAME.get(p.name) or _LANGUAGE_BY_EXT.get(p.suffix.lower(), "text")
        is_prose = language in {"markdown", "rst", "text"}
        if is_prose:
            content = text
            mime = "text/markdown" if language == "markdown" else "text/plain"
        else:
            fence_lang = language if language != "text" else ""
            content = f"# {spec.name}/{path}\n\nSource file `{path}` from repository {spec.full_name}.\n\n```{fence_lang}\n{text.rstrip()}\n```\n"
            mime = f"text/x-{language}"

        references = sorted(
            f"{spec.full_name}:{ref_path}"
            for ref_path in _find_references(path, text, tree_paths, language)
        )
        technologies = {
            _TECH_BY_LANGUAGE[lang] for lang in snap.languages if lang in _TECH_BY_LANGUAGE
        }
        for key, tech in _TECH_BY_FILE.items():
            if p.suffix.lower() == key or p.name == key:
                technologies.add(tech)
        entities = [ExplicitEntity(name=_humanize(spec.name), entity_type=EntityType.PROJECT)]
        entities += [
            ExplicitEntity(name=t, entity_type=EntityType.TECHNOLOGY, confidence=0.85)
            for t in sorted(technologies)
        ]
        entities += [
            ExplicitEntity(name=c, entity_type=EntityType.PERSON, confidence=0.8)
            for c in snap.contributors[:10]
        ]

        pushed = snap.meta.get("pushed_at")
        return SourceDocument(
            external_id=f"{spec.full_name}:{path}",
            title=f"{spec.name}/{path}",
            content=content,
            uri=f"https://github.com/{spec.full_name}/blob/{snap.ref}/{path}",
            author=snap.contributors[0] if snap.contributors else None,
            mime_type=mime,
            attributes={
                "repo": spec.full_name,
                "path": path,
                "directory": str(p.parent) if str(p.parent) != "." else "",
                "ref": snap.ref,
                "sha": blob.get("sha"),
                "size": blob.get("size"),
                "language": language,
                "kind": "prose" if is_prose else "code",
                "repo_description": snap.meta.get("description"),
                "project": _humanize(spec.name),
            },
            contributors=list(snap.contributors[:10]),
            references=references,
            explicit_entities=entities,
            source_created_at=_parse_dt(snap.meta.get("created_at")),
            source_updated_at=_parse_dt(pushed),
        )


# ---------------------------------------------------------------------------- helpers
def _humanize(repo_name: str) -> str:
    return " ".join(w.capitalize() for w in re.split(r"[-_.]+", repo_name) if w)


def _parse_dt(value: Any) -> datetime | None:
    if not value or not isinstance(value, str):
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def _resolve(base: str, target: str) -> str | None:
    """Resolve a relative link against the directory of ``base`` (posix, no escapes)."""
    if target.startswith(("http://", "https://", "mailto:", "/")):
        return None
    parts: list[str] = (
        [] if str(PurePosixPath(base).parent) == "." else list(PurePosixPath(base).parent.parts)
    )
    for piece in target.strip().split("/"):
        if piece in ("", "."):
            continue
        if piece == "..":
            if not parts:
                return None
            parts.pop()
        else:
            parts.append(piece)
    return "/".join(parts) or None


def _find_references(path: str, text: str, tree_paths: set[str], language: str) -> set[str]:
    refs: set[str] = set()
    if language in {"markdown", "rst", "text"}:
        for m in _MD_LINK_RE.finditer(text):
            resolved = _resolve(path, m.group(1))
            if resolved and resolved in tree_paths:
                refs.add(resolved)
    for m in _PATH_TOKEN_RE.finditer(text):
        candidate = m.group(1)
        if candidate in tree_paths:
            refs.add(candidate)
    if language == "python":
        for m in _PY_IMPORT_RE.finditer(text):
            module = (m.group(1) or m.group(2) or "").strip()
            for i in range(len(module.split(".")), 0, -1):
                base = "/".join(module.split(".")[:i])
                for candidate in (f"{base}.py", f"{base}/__init__.py"):
                    if candidate in tree_paths:
                        refs.add(candidate)
                        break
                else:
                    continue
                break
    refs.discard(path)
    return refs
