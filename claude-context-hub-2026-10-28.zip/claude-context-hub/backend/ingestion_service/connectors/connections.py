"""Connections the hub can edit and test from the Connectors page.

The environment stays the baseline. Settings saved from the page override it per connector: plain
values as JSON, credentials encrypted with Fernet. Credentials never leave the service; the API says
only whether one is set and where it comes from. Saving rebuilds the adapter and swaps it into the
registry, so the next run uses it without a restart.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any, Literal

from pydantic import SecretStr

from ech_core.config import Settings
from ech_core.connections import SecretBox, apply_saved
from ech_core.exceptions import ConnectorError, InvalidRequestError, NotFoundError
from ech_core.logging import get_logger
from ech_core.repositories.connector_settings_repository import ConnectorSettingsRepository
from ech_core.schemas.connectors import (
    ConnectionDraft,
    ConnectionField,
    ConnectionFieldKind,
    ConnectionOut,
    ConnectionTestResult,
)
from ingestion_service.connectors.base import BaseConnector
from ingestion_service.connectors.registry import ConnectorRegistry

log = get_logger(__name__)

TEST_TIMEOUT_SECONDS = 25


@dataclass(frozen=True)
class FieldSpec:
    name: str
    """The Settings attribute the field overrides."""
    label: str
    kind: ConnectionFieldKind
    group: str = "Connection"
    help: str = ""
    placeholder: str = ""
    required: bool = False
    options: tuple[str, ...] = ()


CONNECTION_FIELDS: dict[str, tuple[FieldSpec, ...]] = {
    "snowflake": (
        FieldSpec("snowflake_account", "Account identifier", "text", required=True, placeholder="orgname-account",
                  help="The account part of <account>.snowflakecomputing.com."),
        FieldSpec("snowflake_host", "Host", "text", placeholder="defaults to <account>.snowflakecomputing.com"),
        FieldSpec("snowflake_user", "User", "text", placeholder="INGEST_USER"),
        FieldSpec("snowflake_auth_scheme", "Authentication", "select", options=("PROGRAMMATIC_ACCESS_TOKEN", "OAUTH", "KEYPAIR_JWT")),
        FieldSpec("snowflake_token", "Access token", "secret", help="A programmatic access token or an OAuth token."),
        FieldSpec("snowflake_warehouse", "Warehouse", "text", group="Scope", placeholder="COMPUTE_WH"),
        FieldSpec("snowflake_role", "Role", "text", group="Scope", placeholder="CATALOG_READER"),
        FieldSpec("snowflake_databases", "Databases", "list", group="Scope", required=True, placeholder="SALES, FINANCE"),
        FieldSpec("snowflake_schemas", "Schemas", "list", group="Scope", placeholder="DATABASE.SCHEMA; empty reads every schema"),
        FieldSpec("snowflake_include_lineage", "Lineage from access history", "bool", group="Options"),
        FieldSpec("snowflake_include_tags", "Object tags", "bool", group="Options"),
        FieldSpec("snowflake_max_tables", "Most tables per run", "number", group="Options"),
    ),
    "databricks": (
        FieldSpec("databricks_host", "Workspace URL", "url", required=True, placeholder="https://adb-1234567890.12.azuredatabricks.net"),
        FieldSpec("databricks_token", "Personal access token", "secret", required=True),
        FieldSpec("databricks_catalogs", "Catalogs", "list", group="Scope", placeholder="main, finance",
                  help="Catalogs or schemas: at least one of the two."),
        FieldSpec("databricks_schemas", "Schemas", "list", group="Scope", placeholder="catalog.schema"),
        FieldSpec("databricks_include_lineage", "Lineage", "bool", group="Options"),
        FieldSpec("databricks_max_tables", "Most tables per run", "number", group="Options"),
    ),
    "github-live": (
        FieldSpec("github_repos", "Repositories", "list", required=True, placeholder="owner/name, owner/name@branch"),
        FieldSpec("github_token", "Access token", "secret", help="Needed for private repositories and a higher rate limit."),
        FieldSpec("github_api_url", "API URL", "url", group="Options", placeholder="https://api.github.com"),
        FieldSpec("github_max_file_kb", "Largest file (KB)", "number", group="Options"),
    ),
    "grafana": (
        FieldSpec("grafana_url", "Grafana URL", "url", required=True, placeholder="https://grafana.example.com"),
        FieldSpec("grafana_token", "Service account token", "secret", required=True),
        FieldSpec("grafana_max_dashboards", "Most dashboards per run", "number", group="Options"),
    ),
    "jira": (
        FieldSpec("jira_base_url", "Jira site URL", "url", required=True, placeholder="https://your-site.atlassian.net"),
        FieldSpec("jira_email", "Account email", "text", required=True, placeholder="you@company.com",
                  help="The Atlassian account the API token belongs to."),
        FieldSpec("jira_api_token", "API token", "secret", required=True,
                  help="Create one at id.atlassian.com under Security > API tokens."),
        FieldSpec("jira_intent_jql", "Intent tickets (JQL)", "text", group="Intents",
                  placeholder='labels = "ech-intent" AND statusCategory != Done',
                  help="Tickets the hub reads, reviews and plans; it posts its questions and the plan back on each."),
        FieldSpec("jira_poll_seconds", "Check imported tickets for replies every (seconds)", "number", group="Intents",
                  help="New tickets are never imported on their own: read one by key or link, or click Sync Jira."),
        FieldSpec("jira_ingest_jql", "Issues to ingest as documents (JQL)", "text", group="Ingestion",
                  placeholder="project = DATA AND updated >= -180d"),
        FieldSpec("jira_max_issues", "Most issues per run", "number", group="Ingestion"),
    ),
}

# The registry needs one of these to be set (on top of the fields marked required).
ONE_OF: dict[str, tuple[str, ...]] = {"databricks": ("databricks_catalogs", "databricks_schemas")}


def build_connector(adapter: str, settings: Settings) -> BaseConnector:
    """The adapter built from these settings; ConnectorError when they are incomplete."""
    if adapter == "snowflake":
        from ingestion_service.connectors.snowflake import SnowflakeConnector

        return SnowflakeConnector.from_settings(settings)
    if adapter == "databricks":
        from ingestion_service.connectors.databricks_uc import DatabricksCatalogConnector

        return DatabricksCatalogConnector.from_settings(settings)
    if adapter == "github-live":
        from ingestion_service.connectors.github_live import GitHubRepoConnector

        return GitHubRepoConnector.from_settings(settings)
    if adapter == "grafana":
        from ingestion_service.connectors.grafana import GrafanaConnector

        return GrafanaConnector.from_settings(settings)
    if adapter == "jira":
        from ingestion_service.connectors.jira import JiraConnector

        return JiraConnector.from_settings(settings)
    raise ConnectorError(f"The {adapter} connection cannot be edited from the hub")


def _specs(adapter: str) -> tuple[FieldSpec, ...]:
    specs = CONNECTION_FIELDS.get(adapter)
    if specs is None:
        raise NotFoundError(f"The {adapter} connection cannot be edited from the hub")
    return specs


def _empty(settings_default: Any) -> Any:
    return "" if isinstance(settings_default, str) else None


def coerce(spec: FieldSpec, raw: Any) -> Any:
    """A form value as the Settings attribute expects it."""
    default = Settings.model_fields[spec.name].default
    if spec.kind == "bool":
        return raw if isinstance(raw, bool) else str(raw).strip().lower() in {"1", "true", "yes", "on"}
    if spec.kind == "number":
        try:
            value = int(raw)
        except (TypeError, ValueError):
            raise InvalidRequestError(f"{spec.label} must be a whole number") from None
        if value < 1:
            raise InvalidRequestError(f"{spec.label} must be at least 1")
        return value
    if spec.kind == "list":
        items = raw if isinstance(raw, list) else str(raw or "").replace("\n", ",").split(",")
        return ", ".join(s for s in (str(i).strip() for i in items) if s)
    text = str(raw or "").strip()
    if spec.kind == "select" and text and text not in spec.options:
        raise InvalidRequestError(f"{spec.label} must be one of {', '.join(spec.options)}")
    if spec.kind == "url" and text and not text.startswith(("https://", "http://")):
        raise InvalidRequestError(f"{spec.label} must start with https://")
    return text or _empty(default)


def _present(value: Any) -> bool:
    if isinstance(value, SecretStr):
        return bool(value.get_secret_value())
    return value not in (None, "")


class ConnectionService:
    def __init__(self, *, settings: Settings, repo: ConnectorSettingsRepository, registry: ConnectorRegistry, box: SecretBox) -> None:
        self._base = settings
        self._repo = repo
        self._registry = registry
        self._box = box
        self._saved: dict[str, dict[str, Any]] = {}
        self._lock = asyncio.Lock()

    # ------------------------------------------------------------------ startup and reads
    async def load(self) -> None:
        """Apply what was saved from the hub on top of the environment; once, at startup."""
        for row in await self._repo.all():
            adapter = str(row["connector"])
            if adapter not in CONNECTION_FIELDS:
                continue
            self._saved[adapter] = {
                "settings": dict(row["settings"] or {}),
                "secrets": self._box.open(row["secrets"]),
                "updated_by": row["updated_by"],
                "updated_at": row["updated_at"],
            }
            try:
                self._install(adapter)
            except ConnectorError as exc:
                log.warning("connection.saved_settings_incomplete", connector=adapter, reason=exc.message)

    def editable(self, adapter: str | None) -> bool:
        return adapter in CONNECTION_FIELDS

    def source(self, adapter: str | None) -> Literal["env", "hub"] | None:
        if adapter in self._saved:
            return "hub"
        return "env" if adapter in self._registry.names() else None

    def effective_settings(self, adapter: str, draft: ConnectionDraft | None = None) -> Settings:
        saved = self._saved.get(adapter, {})
        values = dict(saved.get("settings", {}))
        secrets = dict(saved.get("secrets", {}))
        if draft is not None:
            values.update(self._coerce_values(adapter, draft.values))
            self._apply_secrets(adapter, secrets, draft.secrets)
        return apply_saved(self._base, values, secrets)

    def describe(self, adapter: str) -> ConnectionOut:
        specs = _specs(adapter)
        saved = self._saved.get(adapter, {})
        values = saved.get("settings", {})
        secrets = saved.get("secrets", {})
        effective = self.effective_settings(adapter)
        from_env = self._base.model_fields_set
        fields = []
        for spec in specs:
            hub = spec.name in (secrets if spec.kind == "secret" else values)
            source: Literal["hub", "env", "default"] = "hub" if hub else ("env" if spec.name in from_env else "default")
            current = getattr(effective, spec.name)
            fields.append(
                ConnectionField(
                    name=spec.name,
                    label=spec.label,
                    kind=spec.kind,
                    group=spec.group,
                    help=spec.help,
                    placeholder=spec.placeholder,
                    required=spec.required,
                    options=list(spec.options),
                    value=None if spec.kind == "secret" else current,
                    secret_set=spec.kind == "secret" and _present(current),
                    source=source if spec.kind != "secret" or _present(current) else "default",
                )
            )
        connector = self._registry.get(adapter) if adapter in self._registry.names() else None
        return ConnectionOut(
            connector=adapter,
            display_name=connector.display_name if connector else adapter,
            registered=connector is not None,
            fields=fields,
            updated_at=saved.get("updated_at"),
            updated_by=saved.get("updated_by"),
            can_store_secrets=self._box.available,
        )

    # ------------------------------------------------------------------ test, save, reset
    async def test(self, adapter: str, draft: ConnectionDraft | None = None) -> ConnectionTestResult:
        _specs(adapter)
        started = time.perf_counter()
        connector: BaseConnector | None = None
        ok, details, error = False, {}, None
        try:
            settings = self.effective_settings(adapter, draft)
            self._check_required(adapter, settings)
            connector = build_connector(adapter, settings)
            async with asyncio.timeout(TEST_TIMEOUT_SECONDS):
                health = await connector.health_check()
            ok, details = health.healthy, dict(health.details)
            if not ok:
                error = str(details.pop("error", "") or "the source answered but reported a problem")
        except (ConnectorError, InvalidRequestError) as exc:
            error = exc.message
        except TimeoutError:
            error = f"no answer within {TEST_TIMEOUT_SECONDS} seconds"
        except Exception as exc:  # noqa: BLE001 - any failure is the test's result, not a server error
            error = str(exc) or type(exc).__name__
        finally:
            if connector is not None:
                await _close(connector)
        return ConnectionTestResult(
            connector=adapter,
            ok=ok,
            latency_ms=int((time.perf_counter() - started) * 1000),
            details=details,
            error=error,
            tested_at=datetime.now(UTC),
            draft=draft is not None and bool(draft.values or draft.secrets),
        )

    async def save(self, adapter: str, draft: ConnectionDraft) -> ConnectionOut:
        _specs(adapter)
        async with self._lock:
            saved = self._saved.get(adapter, {})
            values = {**saved.get("settings", {}), **self._coerce_values(adapter, draft.values)}
            secrets = dict(saved.get("secrets", {}))
            self._apply_secrets(adapter, secrets, draft.secrets)
            # A value equal to the environment's is not stored, so the environment keeps governing it.
            values = {k: v for k, v in values.items() if v != getattr(self._base, k)}
            settings = apply_saved(self._base, values, secrets)
            self._check_required(adapter, settings)
            connector = build_connector(adapter, settings)
            if values or secrets:
                await self._repo.upsert(adapter, values, self._box.seal(secrets), draft.updated_by or None)
                self._saved[adapter] = {"settings": values, "secrets": secrets, "updated_by": draft.updated_by or None, "updated_at": datetime.now(UTC)}
            else:
                await self._repo.delete(adapter)
                self._saved.pop(adapter, None)
            self._registry.replace(connector)
            log.info("connection.saved", connector=adapter, fields=sorted(values), secrets=sorted(secrets))
        return self.describe(adapter)

    async def reset(self, adapter: str) -> ConnectionOut:
        _specs(adapter)
        async with self._lock:
            await self._repo.delete(adapter)
            self._saved.pop(adapter, None)
            try:
                self._install(adapter)
            except ConnectorError:
                self._registry.remove(adapter)
            log.info("connection.reset", connector=adapter)
        return self.describe(adapter)

    async def shutdown(self) -> None:
        await self._registry.aclose_all()

    # ------------------------------------------------------------------ helpers
    def _install(self, adapter: str) -> None:
        settings = self.effective_settings(adapter)
        self._check_required(adapter, settings)
        self._registry.replace(build_connector(adapter, settings))

    def _coerce_values(self, adapter: str, raw: dict[str, Any]) -> dict[str, Any]:
        specs = {s.name: s for s in _specs(adapter) if s.kind != "secret"}
        unknown = sorted(set(raw) - set(specs))
        if unknown:
            raise InvalidRequestError(f"Unknown {adapter} settings: {', '.join(unknown)}")
        return {name: coerce(specs[name], value) for name, value in raw.items()}

    def _apply_secrets(self, adapter: str, secrets: dict[str, str], changes: dict[str, str | None]) -> None:
        allowed = {s.name for s in _specs(adapter) if s.kind == "secret"}
        unknown = sorted(set(changes) - allowed)
        if unknown:
            raise InvalidRequestError(f"Unknown {adapter} credentials: {', '.join(unknown)}")
        for name, value in changes.items():
            if value is None:
                secrets.pop(name, None)
            elif value.strip():
                secrets[name] = value.strip()

    def _check_required(self, adapter: str, settings: Settings) -> None:
        missing = [s.label for s in _specs(adapter) if s.required and not _present(getattr(settings, s.name))]
        group = ONE_OF.get(adapter)
        if group and not any(_present(getattr(settings, name)) for name in group):
            labels = {s.name: s.label for s in _specs(adapter)}
            missing.append(" or ".join(labels[name] for name in group))
        if missing:
            raise ConnectorError(f"Missing {', '.join(missing)}")


async def _close(connector: BaseConnector) -> None:
    close = getattr(connector, "aclose", None)
    if close is None:
        return
    try:
        await close()
    except Exception as exc:  # noqa: BLE001 - closing a throwaway client must not fail the request
        log.debug("connection.close_failed", error=str(exc))
