"""Snowflake connector - catalog metadata over the SQL REST API (no driver dependency).

Per configured database it reads ``INFORMATION_SCHEMA`` (tables, columns, views),
``SHOW PRIMARY KEYS`` / ``SHOW IMPORTED KEYS`` and, where the role may see them,
``SNOWFLAKE.ACCOUNT_USAGE`` tag references and object dependencies (lineage) and
semantic views (declared dimensions, facts, metrics, relationships). Optional
sources degrade gracefully: a missing privilege logs a warning and the asset is
built from what is available.

Authentication - ``Authorization: Bearer`` with ``X-Snowflake-Authorization-Token-Type``:
* ``PROGRAMMATIC_ACCESS_TOKEN`` or ``OAUTH`` with ``ECH_SNOWFLAKE_TOKEN``;
* ``KEYPAIR_JWT`` from ``ECH_SNOWFLAKE_PRIVATE_KEY_PATH`` (needs the ``cryptography``
  package; the JWT is minted here, valid for 59 minutes, and refreshed as needed).
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import re
import time
from collections import defaultdict
from collections.abc import AsyncIterator, Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, ClassVar

import httpx

from ech_core.config import Settings
from ech_core.domain.enums import EntityType, SourceSystem
from ech_core.exceptions import ConnectorError
from ech_core.logging import get_logger
from ech_core.schemas.pipelines import DiscoveryNode, DiscoveryResult
from ech_core.semantic.inference import infer_asset
from ech_core.semantic.models import (
    AssetType,
    FieldRole,
    MetricSource,
    Platform,
    RelationshipKind,
    SemanticAsset,
    SemanticField,
    SemanticMetric,
    SemanticRelationship,
)
from ech_core.semantic.render import owner_is_person, render_asset_markdown
from ingestion_service.connectors.base import (
    BaseConnector,
    ConnectorHealth,
    ConnectorOptions,
    ExplicitEntity,
    SourceDocument,
)
from ingestion_service.connectors.scope import ScopePlan, plan_scope

log = get_logger(__name__)

_META_TTL_SECONDS = 600.0
_TABLE_TYPES = {
    "BASE TABLE": AssetType.TABLE,
    "VIEW": AssetType.VIEW,
    "MATERIALIZED VIEW": AssetType.MATERIALIZED_VIEW,
    "DYNAMIC TABLE": AssetType.DYNAMIC_TABLE,
    "EXTERNAL TABLE": AssetType.EXTERNAL_TABLE,
    "TEMPORARY TABLE": AssetType.TABLE,
    "EVENT TABLE": AssetType.TABLE,
}
_AGGREGATION = re.compile(r"^\s*(COUNT|SUM|AVG|MIN|MAX)\s*\(", re.I)


def normalize_account(account: str) -> str:
    """Account identifier as the JWT wants it: upper-case, no region / cloud suffix.

    ``xy12345.us-east-1`` → ``XY12345``; ``myorg-myaccount`` stays; ``myorg.myaccount``
    (a dotted org form) → ``MYORG-MYACCOUNT``.
    """
    parts = account.strip().split(".")
    if len(parts) >= 2 and "-" in parts[1]:
        return parts[0].upper()
    return "-".join(parts).upper()


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def build_keypair_jwt(
    *,
    account: str,
    user: str,
    private_key_pem: bytes,
    passphrase: bytes | None = None,
    lifetime_seconds: int = 3540,
    now: int | None = None,
) -> str:
    """RS256 JWT for Snowflake key-pair authentication (``iss`` carries the key fingerprint)."""
    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding
    except ImportError as exc:  # pragma: no cover - environment dependent
        raise ConnectorError(
            "Snowflake key-pair authentication needs the 'cryptography' package "
            "(pip install cryptography) or use a programmatic access token"
        ) from exc
    key = serialization.load_pem_private_key(private_key_pem, password=passphrase)
    public_der = key.public_key().public_bytes(
        encoding=serialization.Encoding.DER, format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    fingerprint = "SHA256:" + base64.b64encode(hashlib.sha256(public_der).digest()).decode()
    qualified = f"{normalize_account(account)}.{user.upper()}"
    issued = int(time.time()) if now is None else now
    header = {"alg": "RS256", "typ": "JWT"}
    payload = {
        "iss": f"{qualified}.{fingerprint}",
        "sub": qualified,
        "iat": issued,
        "exp": issued + lifetime_seconds,
    }
    segments = [
        _b64url(json.dumps(header, separators=(",", ":")).encode()),
        _b64url(json.dumps(payload, separators=(",", ":")).encode()),
    ]
    signature = key.sign(".".join(segments).encode(), padding.PKCS1v15(), hashes.SHA256())  # type: ignore[union-attr]
    return ".".join([*segments, _b64url(signature)])


class SnowflakeAuth:
    """Produces the authorization headers; mints and refreshes key-pair JWTs."""

    def __init__(
        self,
        *,
        scheme: str,
        token: str | None = None,
        account: str | None = None,
        user: str | None = None,
        private_key_pem: bytes | None = None,
        passphrase: bytes | None = None,
    ) -> None:
        self._scheme = scheme.upper()
        self._token = token
        self._account = account
        self._user = user
        self._pem = private_key_pem
        self._passphrase = passphrase
        self._jwt: tuple[float, str] | None = None
        if self._scheme == "KEYPAIR_JWT":
            if not (account and user and private_key_pem):
                raise ConnectorError("KEYPAIR_JWT needs account, user and a private key")
        elif not token:
            raise ConnectorError(f"{self._scheme} authentication needs ECH_SNOWFLAKE_TOKEN")

    def headers(self) -> dict[str, str]:
        if self._scheme == "KEYPAIR_JWT":
            now = time.time()
            if self._jwt is None or now > self._jwt[0]:
                token = build_keypair_jwt(
                    account=self._account or "",
                    user=self._user or "",
                    private_key_pem=self._pem or b"",
                    passphrase=self._passphrase,
                )
                self._jwt = (now + 50 * 60, token)
            bearer = self._jwt[1]
        else:
            bearer = self._token or ""
        return {
            "Authorization": f"Bearer {bearer}",
            "X-Snowflake-Authorization-Token-Type": self._scheme,
        }


class SnowflakeSqlClient:
    """Minimal async client for ``POST /api/v2/statements`` incl. polling and partitions."""

    def __init__(
        self,
        *,
        host: str,
        auth: SnowflakeAuth,
        warehouse: str | None = None,
        role: str | None = None,
        timeout_seconds: int = 120,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        host = host.strip().rstrip("/")
        if "://" not in host:
            host = f"https://{host}"
        self._host = host
        self._auth = auth
        self._warehouse = warehouse
        self._role = role
        self._timeout = timeout_seconds
        self._client = client
        self._own_client = client is None

    @property
    def warehouse(self) -> str | None:
        return self._warehouse

    def _http(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self._host,
                headers={
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "User-Agent": "enterprise-context-hub/0.1",
                },
                timeout=httpx.Timeout(30.0, read=float(self._timeout) + 15),
            )
        return self._client

    async def aclose(self) -> None:
        if self._own_client and self._client is not None:
            await self._client.aclose()
            self._client = None

    async def query(
        self, statement: str, *, database: str | None = None, schema: str | None = None
    ) -> list[dict[str, Any]]:
        body = {
            "statement": statement,
            "timeout": self._timeout,
            "warehouse": self._warehouse,
            "role": self._role,
            "database": database,
            "schema": schema,
        }
        response = await self._http().post(
            "/api/v2/statements",
            json={k: v for k, v in body.items() if v},
            headers=self._auth.headers(),
        )
        payload = await self._settle(response, statement)
        return await self._rows(payload)

    async def _settle(self, response: httpx.Response, statement: str) -> dict[str, Any]:
        deadline = time.monotonic() + self._timeout + 30
        delay = 1.0
        while True:
            if response.status_code == 200:
                return response.json()
            if response.status_code in (202, 429):
                handle = response.json().get("statementHandle")
                if not handle:
                    raise ConnectorError("Snowflake accepted the statement without a handle")
                if time.monotonic() > deadline:
                    raise ConnectorError(f"Snowflake statement timed out: {statement[:120]}")
                await asyncio.sleep(delay)
                delay = min(delay * 1.5, 5.0)
                response = await self._http().get(
                    f"/api/v2/statements/{handle}", headers=self._auth.headers()
                )
                continue
            detail = response.text[:400]
            try:
                detail = response.json().get("message", detail)
            except ValueError:
                pass
            raise ConnectorError(
                f"Snowflake SQL API HTTP {response.status_code}: {detail}",
                details={"status": response.status_code, "statement": statement[:200]},
            )

    async def _rows(self, payload: dict[str, Any]) -> list[dict[str, Any]]:
        meta = payload.get("resultSetMetaData") or {}
        row_types = meta.get("rowType") or []
        names = [c["name"].lower() for c in row_types]
        data: list[list[Any]] = list(payload.get("data") or [])
        partitions = meta.get("partitionInfo") or []
        handle = payload.get("statementHandle")
        for index in range(1, len(partitions)):
            response = await self._http().get(
                f"/api/v2/statements/{handle}",
                params={"partition": index},
                headers=self._auth.headers(),
            )
            if response.status_code != 200:
                raise ConnectorError(f"Snowflake partition {index} -> HTTP {response.status_code}")
            data.extend(response.json().get("data") or [])
        converters = [_converter(c) for c in row_types]
        return [
            {name: conv(value) for name, conv, value in zip(names, converters, row, strict=False)}
            for row in data
        ]


def _converter(column: dict[str, Any]) -> Callable[[Any], Any]:
    kind = str(column.get("type", "")).upper()
    scale = column.get("scale") or 0

    def convert(value: Any) -> Any:
        if value is None:
            return None
        try:
            if kind == "FIXED":
                return int(float(value)) if not scale else float(value)
            if kind == "REAL":
                return float(value)
            if kind == "BOOLEAN":
                return str(value).lower() == "true"
            if kind == "DATE":
                return datetime.fromtimestamp(int(float(value)) * 86400, tz=UTC).date().isoformat()
            if kind.startswith("TIMESTAMP"):
                return datetime.fromtimestamp(float(str(value).split(" ")[0]), tz=UTC)
        except (TypeError, ValueError, OSError):
            return value
        return value

    return convert


def _q(identifier: str) -> str:
    return '"' + identifier.replace('"', '""') + '"'


def _lit(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def _csv_list(value: str) -> list[str]:
    return [c.strip() for c in value.strip("()[]").split(",") if c.strip()]


def sql_client_from_settings(settings: Settings) -> SnowflakeSqlClient:
    """The SQL API client for the account in `settings` (the connector's, and the intent validator's)."""
    if not settings.snowflake_account:
        raise ConnectorError("Snowflake connector needs ECH_SNOWFLAKE_ACCOUNT")
    pem = passphrase = None
    if settings.snowflake_auth_scheme == "KEYPAIR_JWT" and settings.snowflake_private_key_path:
        path = Path(settings.snowflake_private_key_path)
        if not path.is_file():
            raise ConnectorError(f"Snowflake private key not found: {path}")
        pem = path.read_bytes()
        if settings.snowflake_private_key_passphrase:
            passphrase = settings.snowflake_private_key_passphrase.get_secret_value().encode()
    auth = SnowflakeAuth(
        scheme=settings.snowflake_auth_scheme,
        token=settings.snowflake_token.get_secret_value() if settings.snowflake_token else None,
        account=settings.snowflake_account,
        user=settings.snowflake_user,
        private_key_pem=pem,
        passphrase=passphrase,
    )
    return SnowflakeSqlClient(
        host=settings.snowflake_host or f"{settings.snowflake_account}.snowflakecomputing.com",
        auth=auth,
        warehouse=settings.snowflake_warehouse,
        role=settings.snowflake_role,
        timeout_seconds=settings.snowflake_statement_timeout_seconds,
    )


class SnowflakeConnector(BaseConnector):
    name: ClassVar[str] = "snowflake"
    source_system: ClassVar[SourceSystem] = SourceSystem.SNOWFLAKE
    display_name: ClassVar[str] = "Snowflake"
    description: ClassVar[str] = (
        "Tables, views, dynamic tables and semantic views from INFORMATION_SCHEMA with keys, "
        "tags and object dependencies; the semantic layer's Snowflake source."
    )
    discoverable: ClassVar[bool] = True
    scope_levels: ClassVar[tuple[str, ...]] = ("Database", "Schema", "Table")
    option_keys: ClassVar[tuple[str, ...]] = ("include_lineage", "include_tags")

    def __init__(
        self,
        *,
        sql: SnowflakeSqlClient,
        account: str,
        databases: list[str],
        schemas: list[str] | None = None,
        include_lineage: bool = True,
        include_tags: bool = True,
        max_tables: int = 2000,
    ) -> None:
        self._sql = sql
        self._account = account
        self._databases = [d.strip() for d in databases if d.strip()]
        self._schemas = {s.strip().upper() for s in (schemas or []) if s.strip()}
        self._include_lineage = include_lineage
        self._include_tags = include_tags
        self._max_tables = max_tables
        self._count_cache: tuple[float, int] | None = None

    @classmethod
    def from_settings(cls, settings: Settings) -> SnowflakeConnector:
        sql = sql_client_from_settings(settings)
        return cls(
            sql=sql,
            account=str(settings.snowflake_account),
            databases=settings.snowflake_database_list,
            schemas=settings.snowflake_schema_list,
            include_lineage=settings.snowflake_include_lineage,
            include_tags=settings.snowflake_include_tags,
            max_tables=settings.snowflake_max_tables,
        )

    # ------------------------------------------------------------------ contract
    async def health_check(self) -> ConnectorHealth:
        try:
            rows = await self._sql.query(
                "SELECT CURRENT_ACCOUNT() AS account, CURRENT_USER() AS user, "
                "CURRENT_ROLE() AS role, CURRENT_WAREHOUSE() AS warehouse"
            )
        except ConnectorError as exc:
            return ConnectorHealth(healthy=False, details={"error": str(exc)})
        details = dict(rows[0]) if rows else {}
        details.update({"databases": self._databases, "schemas": sorted(self._schemas) or "all"})
        wanted = self._sql.warehouse
        if wanted and not details.get("warehouse"):
            # Snowflake ignores a warehouse it cannot use instead of failing; the catalog queries would fail later.
            details["error"] = f"warehouse {wanted} does not exist or role {details.get('role') or '?'} cannot use it"
            return ConnectorHealth(healthy=False, details=details)
        return ConnectorHealth(healthy=True, details=details)

    async def estimate_count(self, options: ConnectorOptions) -> int | None:
        if options.scope:
            return await self._estimate_scope(options)
        now = time.monotonic()
        if self._count_cache and now - self._count_cache[0] < _META_TTL_SECONDS:
            total = self._count_cache[1]
        else:
            total = 0
            for database in self._databases:
                rows = await self._sql.query(
                    f"SELECT count(*) AS n FROM {_q(database.upper())}.INFORMATION_SCHEMA.TABLES "
                    f"WHERE TABLE_SCHEMA <> 'INFORMATION_SCHEMA'{self._schema_filter(database)}"
                )
                total += int(rows[0]["n"]) if rows else 0
            self._count_cache = (now, total)
        total = min(total, self._max_tables)
        return min(total, options.limit) if options.limit else total

    async def _estimate_scope(self, options: ConnectorOptions) -> int | None:
        total = 0
        for plan in plan_scope(options.scope, root=str.upper).values():
            rows = await self._sql.query(
                f"SELECT count(*) AS n FROM {_q(plan.root)}.INFORMATION_SCHEMA.TABLES "
                f"WHERE TABLE_SCHEMA <> 'INFORMATION_SCHEMA'{self._scope_filter(plan.root, plan)}"
            )
            total += int(rows[0]["n"]) if rows else 0
        total = min(total, self._max_tables)
        return min(total, options.limit) if options.limit else total

    def known_entities(self) -> list[ExplicitEntity]:
        return [
            ExplicitEntity(name="Snowflake", entity_type=EntityType.TECHNOLOGY, confidence=0.99),
            *[
                ExplicitEntity(
                    name=d.replace("_", " ").title(), entity_type=EntityType.PROJECT, confidence=0.9
                )
                for d in self._databases
            ],
        ]

    def _schema_filter(self, database: str) -> str:
        wanted = sorted(
            s.split(".", 1)[1] for s in self._schemas if s.split(".", 1)[0] == database.upper()
        )
        if not wanted:
            return ""
        quoted = ", ".join("'" + w.replace("'", "''") + "'" for w in wanted)
        return f" AND TABLE_SCHEMA IN ({quoted})"

    def _scope_filter(self, database: str, plan: ScopePlan | None) -> str:
        """The WHERE fragment for the selected schemas and tables; no plan keeps the server scope."""
        if plan is None:
            return self._schema_filter(database)
        if plan.whole:
            return ""
        parts: list[str] = []
        if plan.schemas:
            parts.append(f"TABLE_SCHEMA IN ({', '.join(_lit(s) for s in sorted(plan.schemas))})")
        for schema, names in sorted(plan.tables.items()):
            listed = ", ".join(_lit(n) for n in sorted(names))
            parts.append(f"(TABLE_SCHEMA = {_lit(schema)} AND TABLE_NAME IN ({listed}))")
        return f" AND ({' OR '.join(parts)})" if parts else " AND 1 = 0"

    async def distinct_values(self, fqn: str, column: str, *, limit: int = 50) -> list[str] | None:
        """One small query on the data: the values a column such as LINE_OF_BUSINESS takes."""
        table = ".".join(_q(part) for part in fqn.split("."))
        col = _q(column)
        rows = await self._sql.query(f"SELECT DISTINCT {col} AS value FROM {table} WHERE {col} IS NOT NULL LIMIT {int(limit)}")
        return [str(r["value"]) for r in rows if r.get("value") is not None]

    async def _safe(self, statement: str, *, what: str) -> list[dict[str, Any]]:
        try:
            return await self._sql.query(statement)
        except ConnectorError as exc:
            log.warning("snowflake.optional_unavailable", what=what, error=str(exc)[:200])
            return []

    # ------------------------------------------------------------------ schema browser
    async def discover(self, path: list[str]) -> DiscoveryResult:
        """Databases, then schemas, tables and columns, read live from the account."""
        limit = 1000
        nodes: list[DiscoveryNode] = []
        if not path:
            for r in await self._sql.query("SHOW DATABASES"):
                name = str(r.get("name") or "")
                if name:
                    nodes.append(
                        DiscoveryNode(
                            name=name,
                            path=[name],
                            kind="database",
                            expandable=True,
                            description=str(r.get("comment") or ""),
                            detail=str(r.get("kind") or "").title(),
                        )
                    )
        elif len(path) == 1:
            db = _q(path[0])
            counts = {
                str(r["table_schema"]): int(r["n"])
                for r in await self._sql.query(
                    f"SELECT TABLE_SCHEMA, count(*) AS n FROM {db}.INFORMATION_SCHEMA.TABLES "
                    "WHERE TABLE_SCHEMA <> 'INFORMATION_SCHEMA' GROUP BY TABLE_SCHEMA"
                )
            }
            for r in await self._sql.query(
                f"SELECT SCHEMA_NAME, COMMENT FROM {db}.INFORMATION_SCHEMA.SCHEMATA "
                "WHERE SCHEMA_NAME <> 'INFORMATION_SCHEMA' ORDER BY SCHEMA_NAME"
            ):
                name = str(r["schema_name"])
                nodes.append(
                    DiscoveryNode(
                        name=name,
                        path=[path[0], name],
                        kind="schema",
                        expandable=True,
                        description=str(r.get("comment") or ""),
                        child_count=counts.get(name, 0),
                    )
                )
        elif len(path) == 2:
            db = _q(path[0])
            for r in await self._sql.query(
                "SELECT TABLE_NAME, TABLE_TYPE, ROW_COUNT, COMMENT "
                f"FROM {db}.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = {_lit(path[1])} "
                f"ORDER BY TABLE_NAME LIMIT {limit + 1}"
            ):
                name = str(r["table_name"])
                kind = str(r.get("table_type") or "").title()
                nodes.append(
                    DiscoveryNode(
                        name=name,
                        path=[path[0], path[1], name],
                        kind="table",
                        expandable=True,
                        description=str(r.get("comment") or ""),
                        detail=kind,
                        row_count=_int_or_none(r.get("row_count")),
                    )
                )
        elif len(path) == 3:
            db = _q(path[0])
            for r in await self._sql.query(
                "SELECT COLUMN_NAME, ORDINAL_POSITION, DATA_TYPE, IS_NULLABLE, COMMENT, "
                f"NUMERIC_PRECISION, NUMERIC_SCALE FROM {db}.INFORMATION_SCHEMA.COLUMNS "
                f"WHERE TABLE_SCHEMA = {_lit(path[1])} AND TABLE_NAME = {_lit(path[2])} "
                "ORDER BY ORDINAL_POSITION"
            ):
                name = str(r["column_name"])
                nodes.append(
                    DiscoveryNode(
                        name=name,
                        path=[*path, name],
                        kind="column",
                        selectable=False,
                        description=str(r.get("comment") or ""),
                        detail=_snowflake_type(r) + ("" if str(r.get("is_nullable")).upper() == "YES" else " not null"),
                    )
                )
        else:
            raise ConnectorError("Snowflake tables have no children below their columns")
        truncated = len(nodes) > limit
        return DiscoveryResult(connector=self.name, path=path, nodes=nodes[:limit], truncated=truncated)

    # ------------------------------------------------------------------ documents
    async def iter_documents(self, options: ConnectorOptions) -> AsyncIterator[SourceDocument]:
        yielded = 0
        plans = plan_scope(options.scope, root=str.upper) if options.scope else {}
        for database in list(plans) if plans else self._databases:
            for asset in await self._assets_for_database(
                database,
                plans.get(database.upper()),
                lineage=options.source_options.include_lineage,
                tags=options.source_options.include_tags,
            ):
                yield self._document(asset)
                yielded += 1
                if options.limit is not None and yielded >= options.limit:
                    return
                if yielded >= self._max_tables:
                    log.warning("snowflake.max_tables_reached", max_tables=self._max_tables)
                    return

    async def _assets_for_database(
        self,
        database: str,
        plan: ScopePlan | None = None,
        *,
        lineage: bool | None = None,
        tags: bool | None = None,
    ) -> list[SemanticAsset]:
        db = _q(database.upper())
        upper = database.upper()
        want_lineage = self._include_lineage if lineage is None else lineage
        want_tags = self._include_tags if tags is None else tags
        where = f"WHERE TABLE_SCHEMA <> 'INFORMATION_SCHEMA'{self._scope_filter(database, plan)}"
        tables = await self._sql.query(
            "SELECT TABLE_SCHEMA, TABLE_NAME, TABLE_TYPE, COMMENT, ROW_COUNT, BYTES, CREATED, "
            f"LAST_ALTERED, TABLE_OWNER, CLUSTERING_KEY FROM {db}.INFORMATION_SCHEMA.TABLES {where} "
            "ORDER BY TABLE_SCHEMA, TABLE_NAME"
        )
        columns = await self._sql.query(
            "SELECT TABLE_SCHEMA, TABLE_NAME, COLUMN_NAME, ORDINAL_POSITION, DATA_TYPE, IS_NULLABLE, "
            f"COMMENT, NUMERIC_PRECISION, NUMERIC_SCALE FROM {db}.INFORMATION_SCHEMA.COLUMNS {where} "
            "ORDER BY TABLE_SCHEMA, TABLE_NAME, ORDINAL_POSITION"
        )
        views = await self._safe(
            f"SELECT TABLE_SCHEMA, TABLE_NAME, VIEW_DEFINITION FROM {db}.INFORMATION_SCHEMA.VIEWS {where}",
            what="view definitions",
        )
        primary_keys = await self._safe(f"SHOW PRIMARY KEYS IN DATABASE {db}", what="primary keys")
        foreign_keys = await self._safe(f"SHOW IMPORTED KEYS IN DATABASE {db}", what="foreign keys")
        tag_rows = (
            await self._safe(
                "SELECT OBJECT_SCHEMA, OBJECT_NAME, COLUMN_NAME, TAG_NAME, TAG_VALUE "
                "FROM SNOWFLAKE.ACCOUNT_USAGE.TAG_REFERENCES "
                f"WHERE OBJECT_DATABASE = '{upper}' AND DOMAIN IN ('TABLE', 'COLUMN', 'VIEW')",
                what="tag references",
            )
            if want_tags
            else []
        )
        dependencies = (
            await self._safe(
                "SELECT REFERENCED_DATABASE, REFERENCED_SCHEMA, REFERENCED_OBJECT_NAME, "
                "REFERENCING_DATABASE, REFERENCING_SCHEMA, REFERENCING_OBJECT_NAME "
                "FROM SNOWFLAKE.ACCOUNT_USAGE.OBJECT_DEPENDENCIES "
                f"WHERE REFERENCING_DATABASE = '{upper}' OR REFERENCED_DATABASE = '{upper}'",
                what="object dependencies",
            )
            if want_lineage
            else []
        )

        columns_by_table: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
        for c in columns:
            columns_by_table[(c["table_schema"], c["table_name"])].append(c)
        view_sql = {(v["table_schema"], v["table_name"]): v.get("view_definition") for v in views}
        pk_by_table: dict[tuple[str, str], list[str]] = defaultdict(list)
        for k in sorted(primary_keys, key=lambda r: r.get("key_sequence") or 0):
            pk_by_table[(k["schema_name"], k["table_name"])].append(k["column_name"])
        fk_by_table: dict[tuple[str, str], dict[str, dict[str, Any]]] = defaultdict(dict)
        for k in sorted(foreign_keys, key=lambda r: r.get("key_sequence") or 0):
            key = (k["fk_schema_name"], k["fk_table_name"])
            constraint = fk_by_table[key].setdefault(
                k.get("fk_name") or f"fk_{k['pk_table_name']}".lower(),
                {
                    "target": f"{k['pk_database_name']}.{k['pk_schema_name']}.{k['pk_table_name']}",
                    "source_columns": [],
                    "target_columns": [],
                },
            )
            constraint["source_columns"].append(k["fk_column_name"])
            constraint["target_columns"].append(k["pk_column_name"])
        table_tags: dict[tuple[str, str], list[str]] = defaultdict(list)
        column_tags: dict[tuple[str, str, str], list[str]] = defaultdict(list)
        for t in tag_rows:
            label = f"{t['tag_name']}={t['tag_value']}" if t.get("tag_value") else t["tag_name"]
            if t.get("column_name"):
                column_tags[(t["object_schema"], t["object_name"], t["column_name"])].append(label)
            else:
                table_tags[(t["object_schema"], t["object_name"])].append(label)
        upstream: dict[tuple[str, str], list[str]] = defaultdict(list)
        downstream: dict[tuple[str, str], list[str]] = defaultdict(list)
        for d in dependencies:
            referenced = ".".join(
                (d["referenced_database"], d["referenced_schema"], d["referenced_object_name"])
            )
            referencing = ".".join(
                (d["referencing_database"], d["referencing_schema"], d["referencing_object_name"])
            )
            if d["referencing_database"] == upper:
                upstream[(d["referencing_schema"], d["referencing_object_name"])].append(referenced)
            if d["referenced_database"] == upper:
                downstream[(d["referenced_schema"], d["referenced_object_name"])].append(
                    referencing
                )

        assets: list[SemanticAsset] = []
        for t in tables:
            key = (t["table_schema"], t["table_name"])
            fqn = f"{upper}.{key[0]}.{key[1]}"
            pks = {c.upper() for c in pk_by_table.get(key, [])}
            fields = [
                SemanticField(
                    name=c["column_name"],
                    ordinal=int(c.get("ordinal_position") or 0),
                    data_type=_snowflake_type(c),
                    description=c.get("comment") or "",
                    nullable=str(c.get("is_nullable", "")).upper() == "YES",
                    is_primary_key=c["column_name"].upper() in pks,
                    tags=column_tags.get((key[0], key[1], c["column_name"]), []),
                )
                for c in columns_by_table.get(key, [])
            ]
            relationships = [
                SemanticRelationship(
                    target_fqn=fk["target"],
                    kind=RelationshipKind.FOREIGN_KEY,
                    source_columns=fk["source_columns"],
                    target_columns=fk["target_columns"],
                    evidence=f"constraint {name}",
                )
                for name, fk in fk_by_table.get(key, {}).items()
            ]
            relationships += [
                SemanticRelationship(
                    target_fqn=u,
                    kind=RelationshipKind.LINEAGE_UPSTREAM,
                    evidence="object dependencies",
                )
                for u in dict.fromkeys(upstream.get(key, []))
                if u.upper() != fqn
            ]
            relationships += [
                SemanticRelationship(
                    target_fqn=d,
                    kind=RelationshipKind.LINEAGE_DOWNSTREAM,
                    evidence="object dependencies",
                )
                for d in dict.fromkeys(downstream.get(key, []))
                if d.upper() != fqn
            ]
            properties = {
                k: v
                for k, v in {
                    "table_type": t.get("table_type"),
                    "clustering_key": t.get("clustering_key"),
                }.items()
                if v
            }
            asset = SemanticAsset(
                platform=Platform.SNOWFLAKE,
                fqn=fqn,
                database=upper,
                schema_name=key[0],
                name=key[1],
                asset_type=_TABLE_TYPES.get(str(t.get("table_type", "")).upper(), AssetType.OTHER),
                description=t.get("comment") or "",
                owner=t.get("table_owner"),
                tags=table_tags.get(key, []),
                properties=properties,
                definition=view_sql.get(key) or None,
                row_count=_int_or_none(t.get("row_count")),
                bytes=_int_or_none(t.get("bytes")),
                source_created_at=_dt(t.get("created")),
                source_updated_at=_dt(t.get("last_altered")),
                uri=(
                    f"https://app.snowflake.com/#/data/databases/{upper}/schemas/{key[0]}"
                    f"/table/{key[1]}"
                ),
                fields=fields,
                relationships=relationships,
            )
            assets.append(infer_asset(asset))

        views = await self._semantic_views(database)
        assets += [a for a in views if plan is None or plan.allows(a.schema_name, a.name)]
        return assets

    async def _semantic_views(self, database: str) -> list[SemanticAsset]:
        """Snowflake semantic views: declared logical tables, dimensions, facts, metrics."""
        listed = await self._safe(
            f"SHOW SEMANTIC VIEWS IN DATABASE {_q(database.upper())}", what="semantic views"
        )
        assets: list[SemanticAsset] = []
        for sv in listed:
            schema, name = sv.get("schema_name"), sv.get("name")
            if not schema or not name:
                continue
            rows = await self._safe(
                f"DESCRIBE SEMANTIC VIEW {_q(database.upper())}.{_q(schema)}.{_q(name)}",
                what=f"semantic view {database}.{schema}.{name}",
            )
            if rows:
                assets.append(self._semantic_view_asset(database.upper(), schema, name, sv, rows))
        return assets

    @staticmethod
    def _semantic_view_asset(
        database: str, schema: str, name: str, listing: dict[str, Any], rows: list[dict[str, Any]]
    ) -> SemanticAsset:
        grouped: dict[tuple[str, str], dict[str, str]] = defaultdict(dict)
        for r in rows:
            kind = str(r.get("object_kind") or "").upper()
            obj = str(r.get("object_name") or "")
            prop = str(r.get("property") or "").upper()
            grouped[(kind, obj)][prop] = str(r.get("property_value") or "")
        fields: list[SemanticField] = []
        metrics: list[SemanticMetric] = []
        relationships: list[SemanticRelationship] = []
        logical: dict[str, str] = {}
        for (kind, obj), props in grouped.items():
            if kind == "TABLE":
                base = ".".join(
                    p
                    for p in (
                        props.get("BASE_TABLE_DATABASE_NAME"),
                        props.get("BASE_TABLE_SCHEMA_NAME"),
                        props.get("BASE_TABLE_NAME"),
                    )
                    if p
                )
                if base:
                    logical[obj] = base
                    relationships.append(
                        SemanticRelationship(
                            target_fqn=base,
                            kind=RelationshipKind.METRIC_SOURCE,
                            evidence=f"logical table {obj}",
                        )
                    )
            elif kind in ("DIMENSION", "FACT", "TIME DIMENSION"):
                role = {
                    "FACT": FieldRole.MEASURE,
                    "TIME DIMENSION": FieldRole.TIME,
                    "DIMENSION": FieldRole.DIMENSION,
                }[kind]
                fields.append(
                    SemanticField(
                        name=obj,
                        ordinal=len(fields),
                        data_type=props.get("DATA_TYPE", ""),
                        description=props.get("COMMENT", "") or props.get("EXPRESSION", ""),
                        role=role,
                        role_confidence=1.0,
                        synonyms=_csv_list(props.get("SYNONYMS", "")),
                    )
                )
            elif kind == "METRIC":
                expr = props.get("EXPRESSION", "")
                agg = _AGGREGATION.match(expr)
                metrics.append(
                    SemanticMetric(
                        name=obj,
                        expression=expr,
                        aggregation=agg.group(1).lower() if agg else None,
                        description=props.get("COMMENT", ""),
                        source=MetricSource.DECLARED,
                        synonyms=_csv_list(props.get("SYNONYMS", "")),
                    )
                )
            elif kind == "RELATIONSHIP":
                left = logical.get(props.get("TABLE", ""), props.get("TABLE", ""))
                right = logical.get(props.get("REF_TABLE", ""), props.get("REF_TABLE", ""))
                if right:
                    relationships.append(
                        SemanticRelationship(
                            target_fqn=right,
                            kind=RelationshipKind.JOIN_DECLARED,
                            source_columns=_csv_list(props.get("RELATIONSHIP_COLUMNS", "")),
                            target_columns=_csv_list(props.get("REF_COLUMNS", "")),
                            evidence=f"semantic view relationship {obj} ({left} -> {right})",
                        )
                    )
        return infer_asset(
            SemanticAsset(
                platform=Platform.SNOWFLAKE,
                fqn=f"{database}.{schema}.{name}",
                database=database,
                schema_name=schema,
                name=name,
                asset_type=AssetType.SEMANTIC_VIEW,
                description=listing.get("comment") or "",
                owner=listing.get("owner"),
                properties={"logical_tables": logical} if logical else {},
                uri=(
                    f"https://app.snowflake.com/#/data/databases/{database}/schemas/{schema}"
                    f"/semantic-view/{name}"
                ),
                fields=fields,
                relationships=relationships,
                metrics=metrics,
                source_created_at=_dt(listing.get("created_on")),
            )
        )

    def _document(self, asset: SemanticAsset) -> SourceDocument:
        references = list(dict.fromkeys(r.target_fqn for r in asset.relationships))
        reference_kinds = {r.target_fqn: r.kind.value for r in asset.relationships}
        entities = [
            ExplicitEntity(name="Snowflake", entity_type=EntityType.TECHNOLOGY, confidence=0.99),
            ExplicitEntity(
                name=asset.database.replace("_", " ").title(),
                entity_type=EntityType.PROJECT,
                confidence=0.9,
            ),
            *[
                ExplicitEntity(name=tag, entity_type=EntityType.CONCEPT, confidence=0.8)
                for tag in asset.tags[:10]
            ],
        ]
        person = asset.owner if owner_is_person(asset.owner) else None
        return SourceDocument(
            external_id=asset.fqn,
            title=asset.fqn,
            content=render_asset_markdown(asset),
            uri=asset.uri,
            author=person,
            attributes={
                "connector": self.name,
                "platform": asset.platform.value,
                "catalog": asset.database,
                "schema": asset.schema_name,
                "asset": {
                    "fqn": asset.fqn,
                    "asset_type": asset.asset_type.value,
                    "kind": asset.kind.value,
                    "database": asset.database,
                    "schema": asset.schema_name,
                },
                "reference_kinds": reference_kinds,
                "semantic": asset.model_dump(mode="json"),
            },
            contributors=[person] if person else [],
            references=references,
            explicit_entities=entities,
            source_created_at=asset.source_created_at,
            source_updated_at=asset.source_updated_at,
        )


def _snowflake_type(column: dict[str, Any]) -> str:
    base = str(column.get("data_type") or "")
    precision, scale = column.get("numeric_precision"), column.get("numeric_scale")
    if base.upper() == "NUMBER" and precision is not None:
        return f"NUMBER({precision},{scale or 0})"
    return base


def _int_or_none(value: Any) -> int | None:
    try:
        return int(value) if value not in (None, "") else None
    except (TypeError, ValueError):
        return None


def _dt(value: Any) -> datetime | None:
    if isinstance(value, datetime):
        return value
    if isinstance(value, int | float):
        return datetime.fromtimestamp(float(value), tz=UTC)
    if isinstance(value, str) and value:
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            try:
                return datetime.fromtimestamp(float(value.split(" ")[0]), tz=UTC)
            except ValueError:
                return None
    return None
