"""Structure-aware ("semantic") chunker for markdown-ish enterprise text.

Strategy
--------
1. Parse the document into *units*: a unit is a sentence, a list item, a table
   row or a whole fenced code block. Each unit knows the heading hierarchy
   (``section_path``) it lives under and its character span in the source.
2. Pack consecutive units into chunks up to ``target_tokens``. A heading change
   is a semantic boundary: the current chunk is flushed if it already has at
   least ``min_tokens``; tiny sections are merged into the following one.
3. Units longer than ``max_tokens`` (giant paragraphs, code dumps) are hard-split
   on token boundaries.
4. Overlap between consecutive chunks is configurable:
   ``sentence`` carries over trailing whole sentences up to ``overlap_tokens``;
   ``token`` carries over the trailing N tokens; ``none`` disables it.

``char_start``/``char_end`` always refer to the *non-overlap* content so spans
can be mapped back to the source document.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from ech_core.config import OverlapStrategy
from ech_core.text import count_tokens, split_sentences

_HEADING_RE = re.compile(r"^(#{1,6})\s+(.*\S)\s*$")
_FENCE_RE = re.compile(r"^\s*(```|~~~)")
_LIST_ITEM_RE = re.compile(r"^\s*(?:[-*+]|\d+[.)])\s+")
_TABLE_ROW_RE = re.compile(r"^\s*\|.*\|\s*$")
_WORD_SPLIT_RE = re.compile(r"\S+")


@dataclass(frozen=True)
class ChunkingConfig:
    target_tokens: int = 320
    max_tokens: int = 512
    min_tokens: int = 40
    overlap_tokens: int = 48
    overlap_strategy: OverlapStrategy = "sentence"

    def __post_init__(self) -> None:
        if self.max_tokens < self.target_tokens:
            raise ValueError("max_tokens must be >= target_tokens")
        if self.min_tokens > self.target_tokens:
            raise ValueError("min_tokens must be <= target_tokens")


@dataclass
class TextChunk:
    index: int
    content: str
    token_count: int
    char_start: int
    char_end: int
    section_path: list[str] = field(default_factory=list)
    overlap_tokens: int = 0


@dataclass
class _Unit:
    text: str
    start: int
    end: int
    section_path: tuple[str, ...]
    tokens: int
    atomic: bool = False  # code blocks / table rows are never split further


# ----------------------------------------------------------------------------- parsing
def _parse_units(text: str) -> list[_Unit]:
    """Split source text into sentence-level units with heading context."""
    units: list[_Unit] = []
    section: list[tuple[int, str]] = []  # (level, title)
    offset = 0
    paragraph: list[tuple[str, int]] = []  # (line, start_offset)
    in_fence = False
    fence_buf: list[tuple[str, int]] = []

    def section_path() -> tuple[str, ...]:
        return tuple(title for _, title in section)

    def flush_paragraph() -> None:
        nonlocal paragraph
        if not paragraph:
            return
        first_start = paragraph[0][1]
        block = "\n".join(line for line, _ in paragraph)
        # Lists / tables: one unit per line keeps items intact.
        if all(_LIST_ITEM_RE.match(line) or _TABLE_ROW_RE.match(line) for line, _ in paragraph):
            for line, start in paragraph:
                stripped = line.strip()
                if stripped:
                    units.append(
                        _Unit(
                            stripped,
                            start,
                            start + len(line),
                            section_path(),
                            count_tokens(stripped),
                            atomic=_TABLE_ROW_RE.match(line) is not None,
                        )
                    )
        else:
            cursor = first_start
            flat = " ".join(line.strip() for line, _ in paragraph)
            for sentence in split_sentences(flat):
                # Locate the sentence within the original block to keep offsets honest.
                idx = block.find(sentence[:40], max(0, cursor - first_start))
                start = first_start + idx if idx >= 0 else cursor
                end = start + len(sentence)
                units.append(_Unit(sentence, start, end, section_path(), count_tokens(sentence)))
                cursor = end
        paragraph = []

    for raw_line in text.split("\n"):
        line_start = offset
        offset += len(raw_line) + 1  # +1 for the newline we split on

        if in_fence:
            fence_buf.append((raw_line, line_start))
            if _FENCE_RE.match(raw_line):
                in_fence = False
                code = "\n".join(line for line, _ in fence_buf)
                units.append(
                    _Unit(
                        code,
                        fence_buf[0][1],
                        line_start + len(raw_line),
                        section_path(),
                        count_tokens(code),
                        atomic=True,
                    )
                )
                fence_buf = []
            continue

        if _FENCE_RE.match(raw_line):
            flush_paragraph()
            in_fence = True
            fence_buf = [(raw_line, line_start)]
            continue

        heading = _HEADING_RE.match(raw_line)
        if heading:
            flush_paragraph()
            level = len(heading.group(1))
            title = heading.group(2).strip()
            while section and section[-1][0] >= level:
                section.pop()
            section.append((level, title))
            continue

        if not raw_line.strip():
            flush_paragraph()
            continue

        paragraph.append((raw_line, line_start))

    if in_fence and fence_buf:  # unterminated fence: treat as code anyway
        code = "\n".join(line for line, _ in fence_buf)
        units.append(
            _Unit(
                code, fence_buf[0][1], offset - 1, section_path(), count_tokens(code), atomic=True
            )
        )
    flush_paragraph()
    return units


def _hard_split(unit: _Unit, max_tokens: int) -> list[_Unit]:
    """Split an oversized unit on whitespace into pieces of <= max_tokens."""
    words = list(_WORD_SPLIT_RE.finditer(unit.text))
    if not words:
        return [unit]
    pieces: list[_Unit] = []
    buf: list[re.Match[str]] = []
    buf_tokens = 0
    for w in words:
        t = count_tokens(w.group(0))
        if buf and buf_tokens + t > max_tokens:
            pieces.append(_piece(unit, buf))
            buf, buf_tokens = [], 0
        buf.append(w)
        buf_tokens += t
    if buf:
        pieces.append(_piece(unit, buf))
    return pieces


def _piece(unit: _Unit, matches: list[re.Match[str]]) -> _Unit:
    s, e = matches[0].start(), matches[-1].end()
    text = unit.text[s:e]
    return _Unit(
        text, unit.start + s, unit.start + e, unit.section_path, count_tokens(text), atomic=True
    )


# ----------------------------------------------------------------------------- packing
class SemanticChunker:
    def __init__(self, config: ChunkingConfig | None = None) -> None:
        self.config = config or ChunkingConfig()

    def chunk(self, text: str) -> list[TextChunk]:
        if not text or not text.strip():
            return []
        cfg = self.config
        units: list[_Unit] = []
        for u in _parse_units(text):
            units.extend(_hard_split(u, cfg.max_tokens) if u.tokens > cfg.max_tokens else [u])
        if not units:
            return []

        chunks: list[TextChunk] = []
        current: list[_Unit] = []
        current_tokens = 0
        carry: list[_Unit] = []  # overlap units from the previous chunk

        def flush() -> None:
            nonlocal current, current_tokens, carry
            if not current:
                return
            overlap_text, overlap_tokens = self._overlap_text(carry)
            body = self._join(current)
            content = f"{overlap_text}\n{body}".strip() if overlap_text else body
            chunks.append(
                TextChunk(
                    index=len(chunks),
                    content=content,
                    token_count=count_tokens(content),
                    char_start=current[0].start,
                    char_end=current[-1].end,
                    section_path=list(current[0].section_path),
                    overlap_tokens=overlap_tokens,
                )
            )
            carry = self._select_overlap(current)
            current, current_tokens = [], 0

        prev_section: tuple[str, ...] | None = None
        for unit in units:
            section_changed = prev_section is not None and unit.section_path != prev_section
            if section_changed and current_tokens >= cfg.min_tokens:
                flush()
            if current and current_tokens + unit.tokens > cfg.target_tokens:
                flush()
            current.append(unit)
            current_tokens += unit.tokens
            prev_section = unit.section_path
        flush()

        # Merge a trailing fragment into its predecessor when that stays within max_tokens.
        if len(chunks) >= 2 and chunks[-1].token_count < cfg.min_tokens:
            last, prev = chunks.pop(), chunks[-1]
            merged = f"{prev.content}\n{self._strip_overlap(last)}".strip()
            merged_tokens = count_tokens(merged)
            if merged_tokens <= cfg.max_tokens:
                prev.content, prev.token_count, prev.char_end = merged, merged_tokens, last.char_end
            else:
                chunks.append(last)
        return chunks

    # ------------------------------------------------------------------ helpers
    @staticmethod
    def _join(units: list[_Unit]) -> str:
        parts: list[str] = []
        for u in units:
            parts.append(u.text if (u.atomic or "\n" in u.text) else u.text)
        # Sentences within one paragraph are joined by spaces; atomic blocks by newlines.
        out: list[str] = []
        for i, u in enumerate(units):
            if i == 0:
                out.append(parts[i])
                continue
            sep = (
                "\n"
                if (u.atomic or units[i - 1].atomic or u.section_path != units[i - 1].section_path)
                else " "
            )
            out.append(sep + parts[i])
        return "".join(out)

    def _select_overlap(self, units: list[_Unit]) -> list[_Unit]:
        cfg = self.config
        if cfg.overlap_strategy == "none" or cfg.overlap_tokens <= 0:
            return []
        if cfg.overlap_strategy == "sentence":
            picked: list[_Unit] = []
            total = 0
            for u in reversed(units):
                if u.atomic or total + u.tokens > cfg.overlap_tokens:
                    break
                picked.insert(0, u)
                total += u.tokens
            return picked
        # token strategy: trailing words of the last non-atomic unit(s)
        words: list[str] = []
        for u in reversed(units):
            if u.atomic:
                break
            words = u.text.split() + words
            if count_tokens(" ".join(words)) >= cfg.overlap_tokens:
                break
        if not words:
            return []
        tail = " ".join(words)
        while count_tokens(tail) > cfg.overlap_tokens and " " in tail:
            tail = tail.split(" ", 1)[1]
        last = units[-1]
        return [_Unit(tail, last.end - len(tail), last.end, last.section_path, count_tokens(tail))]

    def _overlap_text(self, carry: list[_Unit]) -> tuple[str, int]:
        if not carry:
            return "", 0
        text = " ".join(u.text for u in carry)
        return text, count_tokens(text)

    @staticmethod
    def _strip_overlap(chunk: TextChunk) -> str:
        if chunk.overlap_tokens and "\n" in chunk.content:
            return chunk.content.split("\n", 1)[1]
        return chunk.content
