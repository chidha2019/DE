"""Composition root: every long-lived object the ingestion service needs."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Annotated

from fastapi import Depends, Request

from ech_core.config import Settings
from ech_core.db import GraphDatabase, PostgresDatabase
from ech_core.embeddings.base import EmbeddingProvider
from ech_core.observability import LatencyRecorder
from ech_core.repositories import (
    AuditRepository,
    ChunkRepository,
    DocumentRepository,
    EmbeddingRepository,
    GraphRepository,
    IngestionRunRepository,
)
from ech_core.repositories.repo_graph_repository import RepoGraphRepository
from ingestion_service.connectors.connections import ConnectionService
from ingestion_service.connectors.registry import ConnectorRegistry
from ingestion_service.services.event_bus import EventBus
from ingestion_service.services.pipeline_definitions import PipelineDefinitionService
from ingestion_service.services.pipeline_service import PipelineService
from ingestion_service.services.repo_crawler import RepoCrawlService
from ingestion_service.services.run_manager import RunManager


@dataclass
class Container:
    settings: Settings
    pg: PostgresDatabase
    graph_db: GraphDatabase
    embedder: EmbeddingProvider
    documents: DocumentRepository
    chunks: ChunkRepository
    embeddings: EmbeddingRepository
    runs: IngestionRunRepository
    audit: AuditRepository
    graph: GraphRepository
    registry: ConnectorRegistry
    event_bus: EventBus
    run_manager: RunManager
    pipeline: PipelineService
    pipeline_defs: PipelineDefinitionService
    latency: LatencyRecorder
    repo_graph: RepoGraphRepository
    repo_crawler: RepoCrawlService
    connections: ConnectionService


def get_container(request: Request) -> Container:
    container: Container | None = getattr(request.app.state, "container", None)
    if container is None:  # pragma: no cover - only before lifespan completes
        raise RuntimeError("application container is not initialised")
    return container


ContainerDep = Annotated[Container, Depends(get_container)]
