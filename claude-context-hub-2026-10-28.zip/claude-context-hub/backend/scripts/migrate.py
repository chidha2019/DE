"""Apply Postgres SQL migrations. Usage: ``python -m scripts.migrate``."""

from __future__ import annotations

import asyncio
import sys

from ech_core.config import get_settings
from ech_core.db.migrations import MigrationRunner
from ech_core.db.postgres import PostgresDatabase
from ech_core.logging import configure_logging, get_logger


async def main() -> int:
    settings = get_settings()
    configure_logging(
        level=settings.log_level, json_output=settings.log_json, service_name="migrate"
    )
    log = get_logger("scripts.migrate")
    db = PostgresDatabase(settings)
    await db.connect()
    try:
        applied = await MigrationRunner(db, settings.migrations_dir).run()
        log.info("migrate.done", applied=applied, directory=str(settings.migrations_dir))
        return 0
    except Exception as exc:  # noqa: BLE001 - surface as non-zero exit for compose
        log.exception("migrate.failed", error=str(exc))
        return 1
    finally:
        await db.close()


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
