"""Apply Neo4j constraints/indexes from ``infra/neo4j/schema/*.cypher``.

Usage: ``python -m scripts.neo4j_schema``. Each statement runs in its own
transaction (schema commands cannot share a transaction with other work) and
every statement uses ``IF NOT EXISTS`` so the script is idempotent.
"""

from __future__ import annotations

import asyncio
import re
import sys
from pathlib import Path

from ech_core.config import get_settings
from ech_core.db.neo4j import GraphDatabase
from ech_core.logging import configure_logging, get_logger

_COMMENT_RE = re.compile(r"//.*?$", re.MULTILINE)


def load_statements(directory: Path) -> list[tuple[str, str]]:
    statements: list[tuple[str, str]] = []
    for path in sorted(directory.glob("*.cypher")):
        text = _COMMENT_RE.sub("", path.read_text(encoding="utf-8"))
        for raw in text.split(";"):
            stmt = raw.strip()
            if stmt:
                statements.append((path.name, stmt))
    return statements


async def main() -> int:
    settings = get_settings()
    configure_logging(
        level=settings.log_level, json_output=settings.log_json, service_name="neo4j-schema"
    )
    log = get_logger("scripts.neo4j_schema")
    statements = load_statements(settings.neo4j_schema_dir)
    if not statements:
        log.error("neo4j_schema.no_statements", directory=str(settings.neo4j_schema_dir))
        return 1
    graph = GraphDatabase(settings)
    await graph.connect()
    try:
        for source, stmt in statements:
            first_line = stmt.splitlines()[0][:100]
            await graph.execute_write(stmt)
            log.info("neo4j_schema.applied", file=source, statement=first_line)
        log.info("neo4j_schema.done", count=len(statements))
        return 0
    except Exception as exc:  # noqa: BLE001
        log.exception("neo4j_schema.failed", error=str(exc))
        return 1
    finally:
        await graph.close()


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
