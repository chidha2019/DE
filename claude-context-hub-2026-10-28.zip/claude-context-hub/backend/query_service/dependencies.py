"""Composition root for the query service."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Annotated

from fastapi import Depends, Request

from ech_core.config import Settings
from ech_core.connections import SavedConnections
from ech_core.db import GraphDatabase, PostgresDatabase
from ech_core.embeddings.base import EmbeddingProvider
from ech_core.observability import LatencyRecorder
from ech_core.repositories import (
    AuditRepository,
    ChunkRepository,
    DocumentRepository,
    EmbeddingRepository,
    GraphRepository,
    IngestionRunRepository,
)
from query_service.genie.service import GenieService
from query_service.intents.service import IntentService
from query_service.retrieval.engine import HybridRetrievalEngine
from query_service.services.catalog_service import CatalogService
from query_service.services.enrichment_service import EnrichmentService
from query_service.services.glossary_service import GlossaryService
from query_service.services.graph_service import GraphService
from query_service.services.semantic_service import SemanticService
from query_service.services.stats_service import StatsService
from query_service.worker.service import DigitalWorker


@dataclass
class Container:
    settings: Settings
    pg: PostgresDatabase
    graph_db: GraphDatabase
    embedder: EmbeddingProvider
    documents: DocumentRepository
    chunks: ChunkRepository
    embeddings: EmbeddingRepository
    runs: IngestionRunRepository
    audit: AuditRepository
    graph_repo: GraphRepository
    engine: HybridRetrievalEngine
    graph: GraphService
    stats: StatsService
    latency: LatencyRecorder
    genie: GenieService
    semantic: SemanticService
    enrichment: EnrichmentService
    glossary: GlossaryService
    intents: IntentService
    saved_connections: SavedConnections
    catalog: CatalogService
    worker: DigitalWorker


def get_container(request: Request) -> Container:
    container: Container | None = getattr(request.app.state, "container", None)
    if container is None:  # pragma: no cover
        raise RuntimeError("application container is not initialised")
    return container


ContainerDep = Annotated[Container, Depends(get_container)]
