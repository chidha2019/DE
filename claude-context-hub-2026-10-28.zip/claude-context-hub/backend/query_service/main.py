"""ASGI entrypoint: ``uvicorn query_service.main:app``."""

from __future__ import annotations

import asyncio
import os
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager, suppress

from fastapi import FastAPI

from ech_core import __version__
from ech_core.app_factory import create_app
from ech_core.config import get_settings
from ech_core.connections import SavedConnections, SecretBox
from ech_core.db import GraphDatabase, PostgresDatabase
from ech_core.embeddings import build_embedding_provider
from ech_core.jira_client import JiraLink
from ech_core.logging import configure_logging, get_logger
from ech_core.observability import LatencyRecorder
from ech_core.repositories import (
    AuditRepository,
    ChunkRepository,
    DocumentRepository,
    EmbeddingRepository,
    GenieRepository,
    GraphRepository,
    IngestionRunRepository,
    PlatformRepository,
    SemanticRepository,
)
from ech_core.repositories.catalog_repository import CatalogRepository
from ech_core.repositories.connector_settings_repository import ConnectorSettingsRepository
from ech_core.repositories.glossary_repository import GlossaryRepository
from ech_core.repositories.intent_repository import IntentRepository
from ech_core.repositories.repo_graph_repository import RepoCrawlRepository, RepoGraphRepository
from ech_core.repositories.worker_repository import WorkerRepository
from query_service.api import api_router
from query_service.dependencies import Container
from query_service.genie import GenieService, build_model_client
from query_service.intents.mapping_modeler import MappingModeler
from query_service.intents.modeler import DataModeler
from query_service.intents.planner import Planner
from query_service.intents.runner import PipelineRunner, snowflake_probe
from query_service.intents.service import IntentService
from query_service.intents.validate import SnowflakeReader
from query_service.retrieval.engine import HybridRetrievalEngine
from query_service.retrieval.reranker import build_reranker
from query_service.services.catalog_service import CatalogService
from query_service.services.enrichment_service import EnrichmentService
from query_service.services.glossary_auto import GlossaryAutoMapper
from query_service.services.glossary_service import GlossaryService
from query_service.services.graph_service import GraphService
from query_service.services.semantic_service import SemanticService
from query_service.services.stats_service import StatsService
from query_service.worker.service import DigitalWorker

SERVICE_NAME = "query-service"

settings = get_settings()
if settings.service_name == "ech":
    settings = settings.model_copy(update={"service_name": SERVICE_NAME})

configure_logging(
    level=settings.log_level, json_output=settings.log_json, service_name=settings.service_name
)
log = get_logger(__name__)
latency_recorder = LatencyRecorder(settings.latency_buffer_size)


async def _pool_metrics_loop(pg: PostgresDatabase) -> None:
    while True:
        pg.record_pool_metrics()
        await asyncio.sleep(15)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    log.info("service.starting", service=settings.service_name, environment=settings.environment)
    pg = PostgresDatabase(settings)
    graph_db = GraphDatabase(settings)
    await pg.connect()
    await graph_db.connect()
    embedder = build_embedding_provider(settings)
    reranker = build_reranker(settings)

    documents = DocumentRepository(pg)
    chunks = ChunkRepository(pg)
    embeddings = EmbeddingRepository(pg)
    runs = IngestionRunRepository(pg)
    audit = AuditRepository(pg)
    graph_repo = GraphRepository(graph_db)

    engine = HybridRetrievalEngine(
        settings=settings,
        embedder=embedder,
        chunks=chunks,
        embeddings=embeddings,
        graph=graph_repo,
        reranker=reranker,
        audit=audit,
    )
    graph_service = GraphService(graph_repo)
    semantic_repo = SemanticRepository(pg)
    semantic = SemanticService(semantic_repo)
    genie_model, genie_reason = build_model_client(settings)
    if genie_model is not None:
        log.info("genie.model", model=genie_model.describe())
    else:
        log.warning("genie.unavailable", reason=genie_reason)
    enrichment = EnrichmentService(
        repo=semantic_repo, semantic=semantic, model=genie_model, unavailable_reason=genie_reason
    )
    glossary_repo = GlossaryRepository(pg)
    glossary = GlossaryService(glossary_repo, model=genie_model, unavailable_reason=genie_reason)
    # Connections saved on the Connectors page (the ingestion service writes them) laid over the environment.
    saved_connections = SavedConnections(settings, ConnectorSettingsRepository(pg), SecretBox(settings))
    await saved_connections.settings()
    # Jira from the environment or the Connectors page; the link rebuilds its client when the saved connection changes.
    jira_link = JiraLink(saved_connections.settings, saved_connections.current)
    # Intents are validated against Snowflake read-only (SELECT / SHOW / EXPLAIN) and routed by what is there.
    snowflake_reader = SnowflakeReader(saved_connections.settings)
    repo_graph = RepoGraphRepository(graph_db)
    intents = IntentService(
        repo=IntentRepository(pg),
        planner=Planner(
            semantic=semantic_repo,
            glossary=glossary_repo,
            data_dir=settings.intent_data_dir,
            repo_graph=repo_graph,
        ),
        model=genie_model,
        glossary=glossary_repo,
        workspace_dir=settings.intent_workspace_dir,
        data_dir=settings.intent_data_dir,
        jira_link=jira_link,
        snowflake_configured=lambda: bool(saved_connections.current().snowflake_account or saved_connections.current().snowflake_host),
        intent_repo=settings.intent_repo,
        snowflake_reader=snowflake_reader,
        modeler=DataModeler(model=genie_model, reader=snowflake_reader, repo_graph=repo_graph, glossary=glossary_repo),
        # A ticket whose design files (mapping, data model, DDL) are under the data directory is compiled from them instead.
        mapping_modeler=MappingModeler(reader=snowflake_reader, data_dir=settings.intent_data_dir),
        # Approval is the human gate; the runner then executes the generated pipeline with the ECH_RUN_* settings only.
        runner=PipelineRunner(lambda: os.environ, probe=snowflake_probe) if settings.intent_run_enabled else None,
        autorun=settings.intent_autorun,
        catalog_url=settings.intent_catalog_url,
    )
    log.info("intents.ready", jira=jira_link.configured(), workspace=str(settings.intent_workspace_dir), data_dir=str(settings.intent_data_dir))
    genie = GenieService(
        repo=GenieRepository(pg),
        engine=engine,
        documents=documents,
        chunks=chunks,
        graph=graph_service,
        graph_db=graph_db,
        audit=audit,
        settings=settings,
        model=genie_model,
        unavailable_reason=genie_reason,
        semantic=semantic,
    )
    # The Data Engineer's digital worker: it sweeps the hub's own signals and asks before anything that writes.
    worker = DigitalWorker(
        repo=WorkerRepository(pg),
        runs=runs,
        intent_rows=IntentRepository(pg),
        semantic=semantic_repo,
        crawls=RepoCrawlRepository(pg),
        skills_dir=settings.intent_data_dir / "digital-worker",
        ingestion_url=settings.intent_catalog_url,
        approve_intent=intents.decide,
        tick_seconds=settings.worker_tick_seconds,
        repo_graph=repo_graph,
        design_root=settings.intent_data_dir,
        intent_config=intents.config,  # which connections and tools the capabilities can count on
    )
    app.state.container = Container(
        settings=settings,
        pg=pg,
        graph_db=graph_db,
        embedder=embedder,
        documents=documents,
        chunks=chunks,
        embeddings=embeddings,
        runs=runs,
        audit=audit,
        graph_repo=graph_repo,
        engine=engine,
        graph=graph_service,
        stats=StatsService(
            semantic=SemanticRepository(pg),
            platform=PlatformRepository(pg),
            genie_log=GenieRepository(pg),
            intents=IntentRepository(pg),
            kpi_targets=settings.kpi_targets,
            documents=documents,
            chunks=chunks,
            embeddings=embeddings,
            runs=runs,
            audit=audit,
            graph=graph_repo,
            embedder=embedder,
            latency=latency_recorder,
        ),
        latency=latency_recorder,
        genie=genie,
        semantic=semantic,
        enrichment=enrichment,
        glossary=glossary,
        intents=intents,
        saved_connections=saved_connections,
        catalog=CatalogService(CatalogRepository(pg)),
        worker=worker,
    )
    app.state.readiness_checks = {"postgres": pg.ping, "neo4j": graph_db.ping}
    metrics_task = asyncio.create_task(_pool_metrics_loop(pg), name="pool-metrics")
    intents_task = asyncio.create_task(intents.poll_loop(), name="intents-poll") if intents.polling else None
    worker_task = asyncio.create_task(worker.loop("data_engineer"), name="worker-data-engineer") if settings.worker_enabled else None
    auto_map_task = (
        asyncio.create_task(
            GlossaryAutoMapper(glossary, glossary_repo, interval_seconds=settings.glossary_auto_map_seconds).loop(), name="glossary-auto-map"
        )
        if settings.glossary_auto_map
        else None
    )
    log.info(
        "service.ready",
        embedding_provider=embedder.model_id,
        reranker=reranker.name,
        vector_top_k=settings.retrieval_vector_top_k,
        keyword_top_k=settings.retrieval_keyword_top_k,
    )
    try:
        yield
    finally:
        log.info("service.stopping")
        metrics_task.cancel()
        with suppress(asyncio.CancelledError):
            await metrics_task
        for task in (intents_task, auto_map_task, worker_task):
            if task is not None:
                task.cancel()
                with suppress(asyncio.CancelledError):
                    await task
        await jira_link.aclose()
        await engine.drain()
        await embedder.aclose()
        await graph_db.close()
        await pg.close()
        log.info("service.stopped")


app = create_app(
    settings=settings,
    title="ECH — Query & Context API Service",
    description=(
        "Sub-second hybrid retrieval (pgvector + Postgres FTS), Neo4j GraphRAG expansion and "
        "reranking for AI agents, plus document, graph and statistics endpoints for the admin UI."
    ),
    version=__version__,
    lifespan=lifespan,
    routers=[api_router],
    latency_recorder=latency_recorder,
)
