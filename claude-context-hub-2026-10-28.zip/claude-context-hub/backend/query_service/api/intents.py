"""Intents: tickets (Jira or manual) → structured intent → pipeline spec → approval → generated pipeline."""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Query, status

from ech_core.schemas.common import Page
from ech_core.schemas.er import ErDiagram
from ech_core.schemas.intents import (
    IntentAnswer,
    IntentCreate,
    IntentDecision,
    IntentFile,
    IntentRecord,
    IntentsConfig,
    JiraImport,
    JiraSyncResult,
)
from query_service.dependencies import ContainerDep

router = APIRouter(prefix="/intents", tags=["intents"])


@router.get("/config", response_model=IntentsConfig, summary="What the intent service is wired to")
async def config(container: ContainerDep) -> IntentsConfig:
    await container.saved_connections.settings()  # a Snowflake connection saved on the Connectors page counts
    return container.intents.config()


@router.get("", response_model=Page[IntentRecord], summary="Intents, newest first")
async def list_intents(
    container: ContainerDep,
    status_filter: str | None = Query(default=None, alias="status"),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
) -> Page[IntentRecord]:
    items, total = await container.intents.list(status=status_filter, limit=limit, offset=offset)
    return Page(items=items, total=total, limit=limit, offset=offset)


@router.post("", response_model=IntentRecord, status_code=status.HTTP_201_CREATED, summary="Submit an intent without Jira")
async def create_intent(body: IntentCreate, container: ContainerDep) -> IntentRecord:
    return await container.intents.create(body)


@router.post(
    "/jira",
    response_model=IntentRecord,
    status_code=status.HTTP_201_CREATED,
    summary="Read one Jira issue by key or URL; the hub reads it, reviews it and plans it",
)
async def import_jira(body: JiraImport, container: ContainerDep) -> IntentRecord:
    return await container.intents.import_jira(body.issue)


@router.post("/sync", response_model=JiraSyncResult, summary="Pull intents and replies from Jira now")
async def sync(container: ContainerDep) -> JiraSyncResult:
    return await container.intents.sync_jira()


@router.get("/designs/er", response_model=list[ErDiagram], summary="ER diagrams of the design documents under the data folder")
async def design_diagrams(container: ContainerDep) -> list[ErDiagram]:
    return await container.intents.design_diagrams()


@router.get("/{intent_id}/er", response_model=ErDiagram, summary="The ER diagram of the layer an intent's plan models")
async def intent_diagram(intent_id: UUID, container: ContainerDep) -> ErDiagram:
    return await container.intents.diagram(intent_id)


@router.get("/{intent_id}", response_model=IntentRecord, summary="One intent with its structure, spec and generated files")
async def get_intent(intent_id: UUID, container: ContainerDep) -> IntentRecord:
    return await container.intents.get(intent_id)


@router.get("/{intent_id}/files", response_model=list[IntentFile], summary="The generated files")
async def intent_files(intent_id: UUID, container: ContainerDep) -> list[IntentFile]:
    return await container.intents.files(intent_id)


@router.post("/{intent_id}/answer", response_model=IntentRecord, summary="Answer the open questions; the intent is parsed and planned again")
async def answer(intent_id: UUID, body: IntentAnswer, container: ContainerDep) -> IntentRecord:
    return await container.intents.answer(intent_id, body.answers)


@router.post("/{intent_id}/decide", response_model=IntentRecord, summary="Approve the spec (generates the pipeline), reject it, or mark the change done")
async def decide(intent_id: UUID, body: IntentDecision, container: ContainerDep) -> IntentRecord:
    return await container.intents.decide(intent_id, body)


@router.post(
    "/{intent_id}/run",
    response_model=IntentRecord,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Run the generated pipeline in the hub (upload, create, load, check, refresh the catalog); it continues in the background",
)
async def run(intent_id: UUID, container: ContainerDep) -> IntentRecord:
    return await container.intents.run(intent_id)


@router.post(
    "/{intent_id}/validate",
    response_model=IntentRecord,
    summary="Look in Snowflake again (read-only); a waiting intent carries on once its upstream tables are there",
)
async def revalidate(intent_id: UUID, container: ContainerDep) -> IntentRecord:
    return await container.intents.revalidate(intent_id)


@router.post("/{intent_id}/replan", response_model=IntentRecord, summary="Parse and plan again from the ticket and its answers")
async def replan(intent_id: UUID, container: ContainerDep) -> IntentRecord:
    return await container.intents.process(intent_id)
