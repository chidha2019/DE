"""Entity search / browsing and graph statistics."""

from __future__ import annotations

from fastapi import APIRouter, Query

from ech_core.domain.enums import EntityType
from ech_core.exceptions import NotFoundError
from ech_core.schemas.graph import EntityListItem, EntitySearchHit, GraphPayload, GraphStats
from query_service.dependencies import ContainerDep

router = APIRouter(prefix="/graph", tags=["graph"])


@router.get("/entities", response_model=list[EntityListItem], summary="Browse entities")
async def list_entities(
    container: ContainerDep,
    entity_type: EntityType | None = Query(default=None),
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
) -> list[EntityListItem]:
    return await container.graph.list_entities(
        entity_type=entity_type.value if entity_type else None, limit=limit, offset=offset
    )


@router.get("/entities/search", response_model=list[EntitySearchHit], summary="Search entities")
async def search_entities(
    container: ContainerDep,
    q: str = Query(min_length=1, max_length=200),
    entity_type: EntityType | None = Query(default=None),
    limit: int = Query(default=20, ge=1, le=100),
) -> list[EntitySearchHit]:
    return await container.graph.search_entities(
        q, entity_type=entity_type.value if entity_type else None, limit=limit
    )


@router.get("/neighborhood", response_model=GraphPayload, summary="Entity neighbourhood")
async def entity_neighborhood(
    container: ContainerDep,
    entity_key: str = Query(
        min_length=3, max_length=300, description="e.g. Project:atlas platform"
    ),
    max_documents: int = Query(default=25, ge=1, le=200),
) -> GraphPayload:
    payload = await container.graph.entity_graph(entity_key, max_documents=max_documents)
    if payload is None:
        raise NotFoundError("Entity not found", details={"entity_key": entity_key})
    return payload


@router.get("/overview", response_model=GraphPayload, summary="Knowledge map: documents, entities and their links")
async def knowledge_map(
    container: ContainerDep,
    max_documents: int = Query(default=150, ge=1, le=500),
    max_entities: int = Query(default=80, ge=1, le=300),
) -> GraphPayload:
    return await container.graph.knowledge_map(max_documents=max_documents, max_entities=max_entities)


@router.get("/stats", response_model=GraphStats, summary="Graph node/edge statistics")
async def graph_stats(container: ContainerDep) -> GraphStats:
    return await container.graph.stats()
