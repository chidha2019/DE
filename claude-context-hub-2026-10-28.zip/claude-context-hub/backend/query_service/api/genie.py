"""``/api/v1/genie`` - spaces, conversations and the streamed ``ask``."""

from __future__ import annotations

import asyncio
import json
from collections.abc import AsyncIterator
from contextlib import suppress
from typing import Any
from uuid import UUID

from fastapi import APIRouter, Query, Request, Response, status
from fastapi.responses import StreamingResponse

from ech_core.schemas.common import Page
from ech_core.schemas.genie import (
    GenieAskRequest,
    GenieConversationDetail,
    GenieConversationOut,
    GenieFeedbackIn,
    GenieMessageOut,
    GenieSpaceIn,
    GenieSpaceOut,
    GenieSpaceUpdate,
    GenieStatus,
)
from query_service.dependencies import ContainerDep

router = APIRouter(prefix="/genie", tags=["genie"])

_KEEPALIVE_SECONDS = 15.0


@router.get("/status", response_model=GenieStatus, summary="Is a model configured?")
async def genie_status(container: ContainerDep) -> GenieStatus:
    return container.genie.status()


# ----------------------------------------------------------------------------- spaces
@router.get("/spaces", response_model=list[GenieSpaceOut], summary="List spaces")
async def list_spaces(container: ContainerDep) -> list[GenieSpaceOut]:
    return await container.genie.list_spaces()


@router.post(
    "/spaces",
    response_model=GenieSpaceOut,
    status_code=status.HTTP_201_CREATED,
    summary="Create a space",
)
async def create_space(body: GenieSpaceIn, container: ContainerDep) -> GenieSpaceOut:
    return await container.genie.create_space(body)


@router.get("/spaces/{space_id}", response_model=GenieSpaceOut, summary="Get a space")
async def get_space(space_id: UUID, container: ContainerDep) -> GenieSpaceOut:
    return await container.genie.get_space(space_id)


@router.patch("/spaces/{space_id}", response_model=GenieSpaceOut, summary="Update a space")
async def update_space(
    space_id: UUID, body: GenieSpaceUpdate, container: ContainerDep
) -> GenieSpaceOut:
    return await container.genie.update_space(space_id, body)


@router.delete(
    "/spaces/{space_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    response_class=Response,
    summary="Delete a space and its conversations",
)
async def delete_space(space_id: UUID, container: ContainerDep) -> Response:
    await container.genie.delete_space(space_id)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


# ----------------------------------------------------------------------------- conversations
@router.get(
    "/spaces/{space_id}/conversations",
    response_model=Page[GenieConversationOut],
    summary="Conversations of a space, most recent first",
)
async def list_conversations(
    space_id: UUID,
    container: ContainerDep,
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
) -> Page[GenieConversationOut]:
    return await container.genie.list_conversations(space_id, limit=limit, offset=offset)


@router.get(
    "/conversations/{conversation_id}",
    response_model=GenieConversationDetail,
    summary="A conversation with all its messages",
)
async def get_conversation(
    conversation_id: UUID, container: ContainerDep
) -> GenieConversationDetail:
    return await container.genie.get_conversation(conversation_id)


@router.delete(
    "/conversations/{conversation_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    response_class=Response,
    summary="Delete a conversation",
)
async def delete_conversation(conversation_id: UUID, container: ContainerDep) -> Response:
    await container.genie.delete_conversation(conversation_id)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post(
    "/messages/{message_id}/feedback",
    response_model=GenieMessageOut,
    summary="Thumbs up / down on an answer",
)
async def message_feedback(
    message_id: UUID, body: GenieFeedbackIn, container: ContainerDep
) -> GenieMessageOut:
    return await container.genie.set_feedback(message_id, body.value)


# ----------------------------------------------------------------------------- ask (SSE)
@router.post(
    "/spaces/{space_id}/ask",
    response_class=StreamingResponse,
    responses={200: {"content": {"text/event-stream": {}}}},
    summary="Ask Genie (Server-Sent Events)",
    description=(
        "Streams `event:` frames - `conversation`, `delta`, `turn_reset`, `step`, `step_done`, "
        "then `message` (or `error`) - see `GenieStreamEvent`. Comment frames keep the connection "
        "alive while the model thinks."
    ),
)
async def ask(
    space_id: UUID, body: GenieAskRequest, request: Request, container: ContainerDep
) -> StreamingResponse:
    events = container.genie.ask(
        space_id, body, request_id=getattr(request.state, "request_id", None)
    )
    first = await anext(events)  # unknown space / no model -> a normal error response
    return StreamingResponse(
        _sse(first, events),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


def _frame(event_type: str, data: dict[str, Any]) -> str:
    return f"event: {event_type}\ndata: {json.dumps(data, default=str)}\n\n"


async def _sse(
    first: tuple[str, dict[str, Any]], events: AsyncIterator[tuple[str, dict[str, Any]]]
) -> AsyncIterator[str]:
    """Pump the service generator through a queue so keep-alives can be sent while it waits."""
    yield _frame(*first)
    queue: asyncio.Queue[tuple[str, dict[str, Any]] | None] = asyncio.Queue()

    async def pump() -> None:
        try:
            async for item in events:
                await queue.put(item)
        except Exception as exc:  # noqa: BLE001 - surfaced to the client as an error frame
            await queue.put(("error", {"error": f"{type(exc).__name__}: {exc}", "message": None}))
        finally:
            await queue.put(None)

    task = asyncio.create_task(pump(), name="genie-ask")
    try:
        while True:
            try:
                item = await asyncio.wait_for(queue.get(), timeout=_KEEPALIVE_SECONDS)
            except TimeoutError:
                yield ": keep-alive\n\n"
                continue
            if item is None:
                break
            yield _frame(*item)
    finally:
        if not task.done():
            task.cancel()
            with suppress(asyncio.CancelledError, Exception):
                await task
