"""Business glossary: domains, terms, term links (review), KPIs and the mapping run."""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Query, status

from ech_core.exceptions import NotFoundError
from ech_core.schemas.common import Page
from ech_core.schemas.glossary import (
    AutoMapRun,
    AutoMapStatus,
    DomainNode,
    GlossaryCoverage,
    Kpi,
    KpiUpdate,
    LinkCreate,
    LinkDecision,
    LinksDecision,
    LinksDecisionResult,
    MapRequest,
    MapRun,
    ProposeTermsRequest,
    TermCreate,
    TermDecision,
    TermDecisionResult,
    TermDetail,
    TermLink,
    TermLinkGroup,
    TermRow,
    TermUpdate,
)
from query_service.dependencies import ContainerDep

router = APIRouter(prefix="/glossary", tags=["glossary"])


@router.get("/domains", response_model=list[DomainNode], summary="Domain taxonomy with counts")
async def domains(container: ContainerDep) -> list[DomainNode]:
    return await container.glossary.domains()


@router.get("/coverage", response_model=GlossaryCoverage, summary="How much of the catalog carries business meaning")
async def coverage(container: ContainerDep) -> GlossaryCoverage:
    return await container.glossary.coverage()


@router.get("/terms", response_model=Page[TermRow], summary="Browse terms")
async def terms(
    container: ContainerDep,
    search: str | None = None,
    domain: str | None = None,
    kind: str | None = None,
    standard: str | None = None,
    status_filter: str | None = Query(default=None, alias="status", description="seeded | curated | proposed"),
    include_proposed: bool = Query(default=True, description="false hides candidate terms awaiting review"),
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
) -> Page[TermRow]:
    items, total = await container.glossary.terms(
        search=search,
        domain=domain,
        kind=kind,
        standard=standard,
        status=status_filter,
        include_proposed=include_proposed,
        limit=limit,
        offset=offset,
    )
    return Page(items=items, total=total, limit=limit, offset=offset)


@router.post("/terms/{term_id}/decide", response_model=TermDecisionResult, summary="Accept or reject a proposed term")
async def decide_term(term_id: UUID, body: TermDecision, container: ContainerDep) -> TermDecisionResult:
    return await container.glossary.decide_term(term_id, body)


@router.post("/terms", response_model=TermRow, status_code=status.HTTP_201_CREATED, summary="Add a curated term")
async def create_term(body: TermCreate, container: ContainerDep) -> TermRow:
    return await container.glossary.create_term(body)


@router.get("/terms/{term_id}", response_model=TermDetail, summary="One term with its links")
async def term(term_id: UUID, container: ContainerDep) -> TermDetail:
    return await container.glossary.term(term_id)


@router.patch("/terms/{term_id}", response_model=TermRow, summary="Edit a term")
async def update_term(term_id: UUID, body: TermUpdate, container: ContainerDep) -> TermRow:
    return await container.glossary.update_term(term_id, body)


@router.get("/links", response_model=Page[TermLink], summary="Term links: the review queue and what is accepted")
async def links(
    container: ContainerDep,
    status_filter: str | None = Query(default=None, alias="status"),
    target_type: str | None = None,
    target_id: UUID | None = None,
    term_id: UUID | None = None,
    asset_id: UUID | None = None,
    term_status: str | None = Query(default=None, description="proposed: links of candidate terms; reviewed: links of accepted vocabulary"),
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
) -> Page[TermLink]:
    items, total = await container.glossary.links(
        status=status_filter,
        target_type=target_type,
        target_id=target_id,
        term_id=term_id,
        asset_id=asset_id,
        term_status=term_status,
        limit=limit,
        offset=offset,
    )
    return Page(items=items, total=total, limit=limit, offset=offset)


@router.get("/links/groups", response_model=Page[TermLinkGroup], summary="Proposals grouped by term and column name: one decision for every table")
async def link_groups(
    container: ContainerDep,
    status_filter: str | None = Query(default="suggested", alias="status"),
    target_type: str | None = None,
    term_status: str | None = Query(default="reviewed", description="reviewed: links of accepted vocabulary; proposed: of candidate terms"),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
) -> Page[TermLinkGroup]:
    items, total = await container.glossary.link_groups(status=status_filter, target_type=target_type, term_status=term_status, limit=limit, offset=offset)
    return Page(items=items, total=total, limit=limit, offset=offset)


@router.post("/links/decide-many", response_model=LinksDecisionResult, summary="Accept or reject several proposals at once")
async def decide_many(body: LinksDecision, container: ContainerDep) -> LinksDecisionResult:
    return await container.glossary.decide_many(body.ids, body.decision)


@router.post("/links", response_model=TermLink, status_code=status.HTTP_201_CREATED, summary="Link a term by hand (accepted at once)")
async def create_link(body: LinkCreate, container: ContainerDep) -> TermLink:
    return await container.glossary.create_link(body)


@router.post("/links/{link_id}/decide", response_model=TermLink, summary="Accept or reject a proposed link")
async def decide_link(link_id: UUID, body: LinkDecision, container: ContainerDep) -> TermLink:
    return await container.glossary.decide(link_id, body.decision)


@router.get("/kpis", response_model=list[Kpi], summary="KPI definitions")
async def kpis(container: ContainerDep, domain: str | None = None) -> list[Kpi]:
    return await container.glossary.kpis(domain=domain)


@router.patch("/kpis/{kpi_id}", response_model=Kpi, summary="Set a KPI's metric, targets or owner")
async def update_kpi(kpi_id: UUID, body: KpiUpdate, container: ContainerDep) -> Kpi:
    return await container.glossary.update_kpi(kpi_id, body)


@router.post("/map", response_model=MapRun, status_code=status.HTTP_202_ACCEPTED, summary="Map a scope to terms: name rules, then Claude")
async def start_map(body: MapRequest, container: ContainerDep) -> MapRun:
    return await container.glossary.start_map(body)


@router.post("/propose-terms", response_model=MapRun, status_code=status.HTTP_202_ACCEPTED, summary="Ask Claude for new terms covering unmapped columns and metrics")
async def propose_terms(body: ProposeTermsRequest, container: ContainerDep) -> MapRun:
    return await container.glossary.start_propose(body)


@router.get("/auto-map", response_model=AutoMapStatus, summary="Mapping after every successful sync: setting and recent passes")
async def auto_map_status(container: ContainerDep, limit: int = Query(default=10, ge=1, le=50)) -> AutoMapStatus:
    rows = await container.glossary.auto_runs(limit)
    return AutoMapStatus(
        enabled=container.settings.glossary_auto_map,
        interval_seconds=container.settings.glossary_auto_map_seconds,
        model_available=container.glossary.model_available,
        runs=[AutoMapRun(**r) for r in rows],
    )


@router.get("/map", response_model=list[MapRun], summary="Recent mapping and proposal runs")
async def list_maps(container: ContainerDep) -> list[MapRun]:
    return container.glossary.list_runs()


@router.get("/map/{run_id}", response_model=MapRun, summary="One mapping run")
async def get_map(run_id: UUID, container: ContainerDep) -> MapRun:
    run = container.glossary.get_run(run_id)
    if run is None:
        raise NotFoundError(f"mapping run {run_id} not found")
    return run
