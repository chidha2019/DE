"""``POST /api/v1/context/retrieve`` — the endpoint agents and orchestrators call."""

from __future__ import annotations

from fastapi import APIRouter, Request

from ech_core.schemas.context import ContextRetrieveRequest, ContextRetrieveResponse
from query_service.dependencies import ContainerDep

router = APIRouter(prefix="/context", tags=["context"])


@router.post(
    "/retrieve",
    response_model=ContextRetrieveResponse,
    summary="Hybrid + GraphRAG context retrieval",
    description=(
        "Accepts a natural-language `query` and/or an `agent_state`, runs dense (pgvector) and "
        "lexical (Postgres FTS) search, fuses them with reciprocal rank fusion, expands through "
        "the Neo4j entity graph (1st/2nd degree), reranks and returns the top-k context chunks "
        "with full score breakdowns and the graph neighbourhood."
    ),
)
async def retrieve_context(
    body: ContextRetrieveRequest, request: Request, container: ContainerDep
) -> ContextRetrieveResponse:
    request_id = getattr(request.state, "request_id", None)
    return await container.engine.retrieve(body, request_id=request_id)
