"""HTTP routers for the query service."""

from query_service.api.router import api_router

__all__ = ["api_router"]
