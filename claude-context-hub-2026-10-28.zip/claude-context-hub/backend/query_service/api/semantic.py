"""``/api/v1/semantic`` - browse, search, graph and export the semantic layer."""

from __future__ import annotations

from typing import Literal
from uuid import UUID

from fastapi import APIRouter, Query, Response, status

from ech_core.domain.enums import SourceSystem
from ech_core.exceptions import NotFoundError
from ech_core.schemas.catalog import CatalogObject, CatalogSort, ObjectType, SemanticCatalog
from ech_core.schemas.common import Page
from ech_core.schemas.semantic import (
    BusinessModel,
    EnrichmentDecision,
    EnrichmentSuggestion,
    EnrichRequest,
    EnrichRun,
    ExportFormat,
    GlossaryTerm,
    SemanticAssetDetail,
    SemanticAssetSummary,
    SemanticGraph,
    SemanticHealth,
    SemanticMetricRow,
    SemanticOverview,
    SemanticSearchResponse,
)
from query_service.dependencies import ContainerDep

router = APIRouter(prefix="/semantic", tags=["semantic"])


@router.get("/overview", response_model=SemanticOverview, summary="Counts and scopes")
async def overview(container: ContainerDep) -> SemanticOverview:
    return await container.semantic.overview()


@router.get("/assets", response_model=Page[SemanticAssetSummary], summary="Browse assets")
async def list_assets(
    container: ContainerDep,
    search: str | None = Query(default=None, max_length=200),
    source_system: SourceSystem | None = Query(default=None),
    database: str | None = Query(default=None, max_length=255),
    schema: str | None = Query(default=None, max_length=255),
    asset_type: str | None = Query(default=None, max_length=40),
    kind: str | None = Query(default=None, max_length=40),
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
) -> Page[SemanticAssetSummary]:
    return await container.semantic.list_assets(
        search=search,
        source_system=source_system,
        database=database,
        schema=schema,
        asset_type=asset_type,
        kind=kind,
        limit=limit,
        offset=offset,
    )


@router.get("/search", response_model=SemanticSearchResponse, summary="Assets, columns, metrics")
async def search(
    container: ContainerDep,
    q: str = Query(min_length=1, max_length=200),
    limit: int = Query(default=20, ge=1, le=100),
) -> SemanticSearchResponse:
    return await container.semantic.search(q, limit=limit)


@router.get(
    "/export",
    summary="Export a scope as a Cortex Analyst model, Databricks metric views or hub JSON",
    responses={200: {"content": {"application/yaml": {}, "application/json": {}}}},
)
async def export_scope(
    container: ContainerDep,
    format: ExportFormat = Query(default="cortex"),
    source_system: SourceSystem | None = Query(default=None),
    database: str | None = Query(default=None, max_length=255),
    schema: str | None = Query(default=None, max_length=255),
    asset_id: list[UUID] | None = Query(default=None),
) -> Response:
    content, media_type, filename = await container.semantic.export(
        fmt=format,
        source_system=source_system,
        database=database,
        schema=schema,
        asset_ids=asset_id,
    )
    return Response(
        content=content,
        media_type=media_type,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/metrics", response_model=Page[SemanticMetricRow], summary="Metrics catalog")
async def metrics_catalog(
    container: ContainerDep,
    search: str | None = Query(default=None, max_length=200),
    source: Literal["declared", "inferred"] | None = Query(default=None),
    database: str | None = Query(default=None, max_length=255),
    schema: str | None = Query(default=None, max_length=255),
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
) -> Page[SemanticMetricRow]:
    """Every metric across the semantic layer, declared (governed) ones first."""
    return await container.semantic.metrics_catalog(
        search=search, source=source, database=database, schema=schema, limit=limit, offset=offset
    )


@router.get("/glossary", response_model=Page[GlossaryTerm], summary="Business glossary")
async def glossary(
    container: ContainerDep,
    search: str | None = Query(default=None, max_length=200),
    role: str | None = Query(default=None, max_length=40),
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
) -> Page[GlossaryTerm]:
    """Column names grouped across datasets with their role, types and best description."""
    return await container.semantic.glossary(search=search, role=role, limit=limit, offset=offset)


@router.get("/health", response_model=SemanticHealth, summary="Catalog health")
async def health(container: ContainerDep) -> SemanticHealth:
    """Gaps a data engineer fixes first: documentation, ownership, keys, inferred joins."""
    return await container.semantic.health()


@router.get("/catalog", response_model=SemanticCatalog, summary="Semantic catalog by business domain")
async def semantic_catalog(container: ContainerDep) -> SemanticCatalog:
    """Entities, dimensions, measures, metrics, relationships and hierarchies counted per domain."""
    return await container.catalog.catalog()


@router.get(
    "/catalog/objects", response_model=Page[CatalogObject], summary="Semantic objects, filterable"
)
async def semantic_catalog_objects(
    container: ContainerDep,
    domain: str | None = Query(default=None, description="domain key; sub-domains included unless direct"),
    direct: bool = Query(default=False, description="only objects placed in the domain itself"),
    type: ObjectType | None = Query(default=None),
    model: str | None = Query(default=None, description="subject area: database.schema"),
    database: str | None = Query(default=None, max_length=255, description="every model of one database"),
    lob: str | None = Query(default=None, max_length=64, description="a line-of-business key, or '__shared__'"),
    owner: str | None = Query(default=None),
    search: str | None = Query(default=None, max_length=200),
    min_quality: int = Query(default=0, ge=0, le=100),
    sort: CatalogSort = Query(default="type"),
    order: Literal["asc", "desc"] = Query(default="asc"),
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
) -> Page[CatalogObject]:
    return await container.catalog.objects(
        direct=direct,
        database=database,
        lob=lob,
        sort=sort,
        descending=order == "desc",
        domain=domain,
        type=type,
        model=model,
        owner=owner,
        search=search,
        min_quality=min_quality,
        limit=limit,
        offset=offset,
    )


@router.get("/business-model", response_model=BusinessModel, summary="Subject areas and stars")
async def business_model(
    container: ContainerDep,
    source_system: SourceSystem | None = Query(default=None),
    database: str | None = Query(default=None, max_length=255),
    schema: str | None = Query(default=None, max_length=255),
) -> BusinessModel:
    """The semantic layer as a business reader sees it: fact stars, governed KPIs, dimensions."""
    model = await container.semantic.business_model(
        source_system=source_system, database=database, schema=schema
    )
    model.enrichment_available = container.enrichment.available
    return model


@router.post(
    "/enrich",
    response_model=EnrichRun,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Ask Claude to name and classify a scope",
)
async def enrich_scope(body: EnrichRequest, container: ContainerDep) -> EnrichRun:
    return await container.enrichment.start_run(body)


@router.get("/enrich", response_model=list[EnrichRun], summary="Recent enrichment runs")
async def list_enrich_runs(container: ContainerDep) -> list[EnrichRun]:
    return container.enrichment.list_runs()


@router.get("/enrich/{run_id}", response_model=EnrichRun, summary="One enrichment run")
async def get_enrich_run(run_id: UUID, container: ContainerDep) -> EnrichRun:
    run = container.enrichment.get_run(run_id)
    if run is None:
        raise NotFoundError(f"enrichment run {run_id} not found")
    return run


@router.post(
    "/assets/{asset_id}/enrich",
    response_model=EnrichmentSuggestion,
    summary="Ask Claude about one asset",
)
async def enrich_asset(asset_id: UUID, container: ContainerDep) -> EnrichmentSuggestion:
    return await container.enrichment.suggest(asset_id)


@router.post(
    "/assets/{asset_id}/enrichment",
    response_model=SemanticAssetDetail,
    summary="Accept (optionally edited) or reject the suggestion",
)
async def decide_enrichment(
    asset_id: UUID, body: EnrichmentDecision, container: ContainerDep
) -> SemanticAssetDetail:
    return await container.enrichment.decide(asset_id, body)


@router.get("/assets/{asset_id}", response_model=SemanticAssetDetail, summary="Asset detail")
async def get_asset(asset_id: UUID, container: ContainerDep) -> SemanticAssetDetail:
    return await container.semantic.get_asset(asset_id)


@router.get("/assets/{asset_id}/graph", response_model=SemanticGraph, summary="Relationship graph")
async def asset_graph(
    asset_id: UUID, container: ContainerDep, depth: int = Query(default=1, ge=1, le=3)
) -> SemanticGraph:
    return await container.semantic.graph(asset_id, depth=depth)
