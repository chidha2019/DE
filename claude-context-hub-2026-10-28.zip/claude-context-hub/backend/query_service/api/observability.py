"""Observability for the SRE workspace: a live read of Grafana, independent of ingestion."""

from __future__ import annotations

from datetime import UTC, datetime

from fastapi import APIRouter

from ech_core.config import Settings
from ech_core.exceptions import ConnectorError
from ech_core.grafana_client import GrafanaClient, GrafanaSnapshot
from ech_core.grafana_dashboard import HUB_DASHBOARD_UID, hub_dashboard
from ech_core.schemas.observability import (
    DashboardProvisionResult,
    GrafanaAlertRule,
    GrafanaDashboardSummary,
    GrafanaObservability,
)
from query_service.dependencies import ContainerDep

router = APIRouter(prefix="/observability", tags=["observability"])

_STATE_ORDER = {"firing": 0, "pending": 1, "error": 2, "nodata": 3, "inactive": 4, "normal": 4, "unknown": 5}


def build_observability(url: str, snapshot: GrafanaSnapshot, *, documents: int = 0, now: datetime | None = None) -> GrafanaObservability:
    """Pure projection of a snapshot: rules sorted firing-first, dashboards by title."""
    rules = [
        GrafanaAlertRule(
            uid=r.get("uid"),
            title=str(r.get("title") or r.get("uid") or "rule"),
            folder=r.get("folder"),
            group=r.get("group"),
            state=str(r.get("state") or "unknown"),
            health=r.get("health"),
            severity=r.get("severity"),
            summary=r.get("summary"),
            active_alerts=int(r.get("active_alerts") or 0),
            labels={str(k): str(v) for k, v in (r.get("labels") or {}).items()},
            url=r.get("url"),
        )
        for r in snapshot.rules
    ]
    rules.sort(key=lambda r: (_STATE_ORDER.get(r.state, 5), r.title.lower()))
    dashboards = sorted(
        (
            GrafanaDashboardSummary(
                uid=str(d.get("uid")),
                title=str(d.get("title") or d.get("uid")),
                url=d.get("url"),
                folder=d.get("folderTitle"),
                tags=[str(t) for t in (d.get("tags") or []) if t],
            )
            for d in snapshot.dashboards
            if d.get("uid")
        ),
        key=lambda d: d.title.lower(),
    )
    return GrafanaObservability(
        configured=True,
        healthy=True,
        url=url,
        org=snapshot.org,
        version=snapshot.version,
        dashboards=dashboards,
        alert_rules=rules,
        rules_total=len(rules),
        firing=snapshot.firing,
        pending=snapshot.pending,
        documents=documents,
        hub_dashboard_url=next((d.url for d in dashboards if d.uid == HUB_DASHBOARD_UID), None),
        generated_at=now or datetime.now(UTC),
    )


def _unconfigured(settings: Settings, documents: int) -> GrafanaObservability:
    missing = [name for name, value in (("GRAFANA_URL", settings.grafana_url), ("GRAFANA_TOKEN", settings.grafana_token)) if not value]
    return GrafanaObservability(
        configured=False,
        reason=f"Connect Grafana on the Connectors page, or set {' and '.join(missing)} for the query and ingestion services.",
        url=settings.grafana_url,
        documents=documents,
        generated_at=datetime.now(UTC),
    )


@router.get("/grafana", response_model=GrafanaObservability, summary="Grafana dashboards and alert rules, live")
async def grafana_observability(container: ContainerDep) -> GrafanaObservability:
    settings = await container.saved_connections.settings()
    documents = int((await container.documents.counts_by_source()).get("grafana", 0))
    if not settings.grafana_url or not settings.grafana_token:
        return _unconfigured(settings, documents)
    client = GrafanaClient(settings.grafana_url, settings.grafana_token.get_secret_value())
    try:
        snapshot = await client.snapshot(max_dashboards=settings.grafana_max_dashboards)
    except ConnectorError as exc:
        return GrafanaObservability(configured=True, healthy=False, reason=exc.message, url=settings.grafana_url, documents=documents, generated_at=datetime.now(UTC))
    finally:
        await client.aclose()
    return build_observability(settings.grafana_url, snapshot, documents=documents)


@router.post("/grafana/dashboard", response_model=DashboardProvisionResult, summary="Create or update the hub's dashboard on the Grafana stack")
async def provision_hub_dashboard(container: ContainerDep) -> DashboardProvisionResult:
    """Imports the hub dashboard by uid, overwriting an earlier version; needs an Editor token."""
    settings = await container.saved_connections.settings()
    if not settings.grafana_url or not settings.grafana_token:
        return DashboardProvisionResult(ok=False, reason="Set GRAFANA_URL and GRAFANA_TOKEN first.")
    client = GrafanaClient(settings.grafana_url, settings.grafana_token.get_secret_value())
    try:
        result = await client.import_dashboard(hub_dashboard())
    except ConnectorError as exc:
        hint = " The token needs the Editor role to create dashboards." if exc.details.get("status") in (401, 403) else ""
        return DashboardProvisionResult(ok=False, reason=f"{exc.message}.{hint}")
    finally:
        await client.aclose()
    return DashboardProvisionResult(ok=True, uid=result.get("uid"), url=client.dashboard_url(result.get("url")), version=result.get("version"))
