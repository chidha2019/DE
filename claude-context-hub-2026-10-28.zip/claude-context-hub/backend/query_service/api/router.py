"""Aggregates all v1 routers under ``/api/v1``."""

from fastapi import APIRouter

from query_service.api import (
    context,
    documents,
    genie,
    glossary,
    graph,
    intents,
    observability,
    semantic,
    stats,
    worker,
)

api_router = APIRouter(prefix="/api/v1")
api_router.include_router(context.router)
api_router.include_router(documents.router)
api_router.include_router(graph.router)
api_router.include_router(stats.router)
api_router.include_router(genie.router)
api_router.include_router(semantic.router)
api_router.include_router(observability.router)
api_router.include_router(glossary.router)
api_router.include_router(intents.router)
api_router.include_router(worker.router)
