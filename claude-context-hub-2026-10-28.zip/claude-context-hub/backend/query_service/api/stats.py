"""Dashboard statistics."""

from __future__ import annotations

from typing import Literal

from fastapi import APIRouter, Query

from ech_core.domain.models import AuditRecord
from ech_core.schemas.stats import (
    AnalystReport,
    ArchitectureReport,
    EngineeringKpis,
    LatencySeries,
    OverviewStats,
    PlatformReport,
    QualityReport,
    RunActivityPoint,
)
from query_service.dependencies import ContainerDep

router = APIRouter(prefix="/stats", tags=["stats"])


@router.get("/overview", response_model=OverviewStats, summary="Headline metrics")
async def overview(container: ContainerDep) -> OverviewStats:
    return await container.stats.overview()


@router.get("/engineering", response_model=EngineeringKpis, summary="Data Engineer KPIs")
async def engineering(
    container: ContainerDep, days: int = Query(default=7, ge=1, le=90)
) -> EngineeringKpis:
    """Pipeline reliability, graph consistency, catalog coverage and freshness with targets."""
    return await container.stats.engineering(days=days)


@router.get("/quality", response_model=QualityReport, summary="QA Engineer quality gates")
async def quality(
    container: ContainerDep, days: int = Query(default=7, ge=1, le=90)
) -> QualityReport:
    """Ingestion, catalog integrity, semantic review and serving gates with verdicts,
    plus failed runs, the enrichment review queue and recent request errors."""
    return await container.stats.quality(days=days)


@router.get("/analyst", response_model=AnalystReport, summary="Business Analyst scorecard")
async def analyst(
    container: ContainerDep, days: int = Query(default=7, ge=1, le=90)
) -> AnalystReport:
    """Questions answered self-serve in Genie, request-to-decision time for intents and the
    share of curated-layer metrics that are declared."""
    return await container.stats.analyst(days=days)


@router.get("/platform", response_model=PlatformReport, summary="SRE platform report")
async def platform(
    container: ContainerDep, hours: int = Query(default=24, ge=1, le=24 * 30)
) -> PlatformReport:
    """Serving SLOs with an error budget, pipeline state, storage and recent errors."""
    return await container.stats.platform(hours=hours)


@router.get("/architecture", response_model=ArchitectureReport, summary="Architect landscape")
async def architecture(container: ContainerDep) -> ArchitectureReport:
    """Platforms, model composition, conformed dimensions and every integration point."""
    return await container.stats.architecture(
        genie=container.genie.status(), settings=await container.saved_connections.settings()
    )


@router.get("/latency", response_model=LatencySeries, summary="API latency percentiles over time")
async def latency(
    container: ContainerDep,
    window_minutes: int = Query(default=30, ge=1, le=24 * 60),
    bucket_seconds: int = Query(default=60, ge=5, le=3600),
    path_prefix: str | None = Query(default=None, max_length=200),
    source: Literal["memory", "audit"] = Query(
        default="memory",
        description="memory = all requests of this process; audit = persisted retrieval calls",
    ),
) -> LatencySeries:
    if source == "audit":
        return await container.stats.retrieval_latency_persisted(
            window_minutes=window_minutes, bucket_seconds=bucket_seconds
        )
    return container.stats.latency(
        window_minutes=window_minutes, bucket_seconds=bucket_seconds, path_prefix=path_prefix
    )


@router.get("/activity", response_model=list[RunActivityPoint], summary="Ingestion activity")
async def activity(
    container: ContainerDep,
    hours: int = Query(default=24, ge=1, le=24 * 30),
    bucket_minutes: int = Query(default=60, ge=5, le=24 * 60),
) -> list[RunActivityPoint]:
    return await container.runs.activity(hours=hours, bucket_minutes=bucket_minutes)


@router.get("/audit", response_model=list[AuditRecord], summary="Recent audit entries")
async def audit(
    container: ContainerDep,
    limit: int = Query(default=50, ge=1, le=500),
    action: str | None = Query(default=None, max_length=64),
    status: str | None = Query(default=None, max_length=16, description="ok or error"),
) -> list[AuditRecord]:
    return await container.audit.recent(limit=limit, action=action, status=status)
