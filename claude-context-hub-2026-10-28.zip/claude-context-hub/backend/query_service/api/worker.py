"""A persona's digital worker: what it is doing, what it found, what waits for you, and its journal."""

from __future__ import annotations

from fastapi import APIRouter

from ech_core.schemas.worker import WorkerDecision, WorkerItem, WorkerPause, WorkerSnapshot
from query_service.dependencies import ContainerDep

router = APIRouter(prefix="/worker", tags=["worker"])


@router.get("/{worker}", response_model=WorkerSnapshot, summary="The worker's state, work items, skills and journal")
async def snapshot(worker: str, container: ContainerDep) -> WorkerSnapshot:
    return await container.worker.snapshot(worker)


@router.post("/{worker}/sweep", response_model=WorkerSnapshot, summary="Sweep the hub's signals now")
async def sweep(worker: str, container: ContainerDep) -> WorkerSnapshot:
    await container.worker.sweep(worker, force=True)
    return await container.worker.snapshot(worker)


@router.post("/{worker}/pause", response_model=WorkerSnapshot, summary="Pause or resume the worker")
async def pause(worker: str, body: WorkerPause, container: ContainerDep) -> WorkerSnapshot:
    return await container.worker.pause(worker, body.paused)


@router.post("/{worker}/items/{key:path}/decision", response_model=WorkerItem, summary="Approve, dismiss or close a work item")
async def decide(worker: str, key: str, body: WorkerDecision, container: ContainerDep) -> WorkerItem:
    return await container.worker.decide(worker, key, body)
