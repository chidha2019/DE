"""Read-only document browsing for the Knowledge Hub (Documents & entities)."""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Query

from ech_core.domain.enums import DocumentKind, GraphSyncStatus, SourceSystem
from ech_core.exceptions import NotFoundError
from ech_core.schemas.common import Page
from ech_core.schemas.documents import ChunkOut, DocumentDetail, DocumentSummary
from ech_core.schemas.graph import GraphPayload
from query_service.dependencies import ContainerDep

router = APIRouter(prefix="/documents", tags=["documents"])


@router.get("", response_model=Page[DocumentSummary], summary="List documents")
async def list_documents(
    container: ContainerDep,
    source_system: list[SourceSystem] | None = Query(default=None),
    search: str | None = Query(default=None, max_length=200),
    graph_sync_status: GraphSyncStatus | None = Query(default=None),
    kind: DocumentKind | None = Query(default=None),
    limit: int = Query(default=25, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
) -> Page[DocumentSummary]:
    items, total = await container.documents.list(
        source_systems=source_system,
        search=search,
        graph_sync_status=graph_sync_status,
        kind=kind,
        limit=limit,
        offset=offset,
    )
    return Page(
        items=[DocumentSummary.from_record(r) for r in items],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.get("/{document_id}", response_model=DocumentDetail, summary="Get a document")
async def get_document(document_id: UUID, container: ContainerDep) -> DocumentDetail:
    record = await container.documents.get(document_id)
    if record is None:
        raise NotFoundError("Document not found", details={"document_id": str(document_id)})
    return DocumentDetail.from_record(record)


@router.get("/{document_id}/chunks", response_model=list[ChunkOut], summary="Chunks of a document")
async def document_chunks(document_id: UUID, container: ContainerDep) -> list[ChunkOut]:
    if await container.documents.get(document_id, include_counts=False) is None:
        raise NotFoundError("Document not found", details={"document_id": str(document_id)})
    return [ChunkOut.from_record(c) for c in await container.chunks.list_for_document(document_id)]


@router.get(
    "/{document_id}/graph",
    response_model=GraphPayload,
    summary="Entity graph of a document (Knowledge Hub)",
)
async def document_graph(document_id: UUID, container: ContainerDep) -> GraphPayload:
    payload = await container.graph.document_graph(document_id)
    if payload is None:
        raise NotFoundError(
            "Document is not in the graph yet", details={"document_id": str(document_id)}
        )
    return payload


@router.get(
    "/{document_id}/lineage",
    response_model=GraphPayload,
    summary="Document lineage via REFERENCES / CONTRIBUTED_BY",
)
async def document_lineage(
    document_id: UUID, container: ContainerDep, depth: int = Query(default=3, ge=1, le=6)
) -> GraphPayload:
    payload = await container.graph.lineage(document_id, depth=depth)
    if payload is None:
        raise NotFoundError(
            "Document is not in the graph yet", details={"document_id": str(document_id)}
        )
    return payload
