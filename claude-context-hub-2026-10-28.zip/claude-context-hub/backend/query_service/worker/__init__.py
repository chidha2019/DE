"""Digital workers: a persona's work done by the hub in real time, within an autonomy ceiling, with a journal."""
