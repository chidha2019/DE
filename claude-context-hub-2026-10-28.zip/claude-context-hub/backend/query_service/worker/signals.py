"""What the Data Engineer worker sees: the hub's own state turned into work, one signal per thing to do.

Every function here is pure: it takes rows the service read and returns signals, so the rules can be tested without a
database. A signal carries what the worker found (detail, evidence), how far it may go (tier) and, when there is
something to do, the action it proposes.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from typing import Any

CATALOG_SOURCES = ("snowflake", "databricks")
_WORKING = {
    "received": "reading the ticket",
    "planning": "planning the pipeline",
    "modeling": "compiling the model and dry-running it",
    "approved": "generating the pipeline",
    "coding": "generating the pipeline",
    "running": "running the pipeline in the hub",
}


@dataclass
class Signal:
    key: str
    skill: str
    title: str
    detail: str
    status: str  # detected | diagnosed | waiting | running
    tier: str
    action: dict[str, Any] | None = None
    evidence: dict[str, Any] = field(default_factory=dict)
    diagnosis: str = ""


@dataclass(frozen=True)
class Diagnosis:
    cause: str
    fix: str
    retry: bool


_CAUSES: tuple[tuple[re.Pattern[str], Diagnosis], ...] = (
    (
        re.compile(r"access control|insufficient privileges|permission denied|does not exist or not authorized|not assigned to the executing user", re.I),
        Diagnosis("The connection's role lacks a grant it needs.", "Grant the missing privilege to the role, then re-run.", retry=False),
    ),
    (
        re.compile(r"\b40[13]\b|unauthori[sz]ed|forbidden|invalid (?:token|credentials|password)|token (?:has )?expired|authentication failed", re.I),
        Diagnosis("The source refused the connection's credentials.", "Renew the token or password on the Connectors page, then re-run.", retry=False),
    ),
    (
        re.compile(r"\b429\b|rate.?limit|too many requests", re.I),
        Diagnosis("The source rate-limited the run.", "Re-run a little later; it usually passes.", retry=True),
    ),
    (
        re.compile(r"timed? ?out|timeout|connection (?:reset|refused|aborted)|temporarily unavailable|name resolution|\b50[234]\b|network", re.I),
        Diagnosis("A network or availability problem cut the run short.", "Re-run; a transient failure usually passes.", retry=True),
    ),
    (
        re.compile(r"restart|interrupted|stale|abandoned|shut ?down", re.I),
        Diagnosis("The run was cut off when the service stopped.", "Re-run it.", retry=True),
    ),
    (
        re.compile(r"invalid identifier|syntax error|column|schema|could not parse|decode", re.I),
        Diagnosis("The source's shape changed, or a record did not parse.", "Check what changed at the source, then re-run.", retry=True),
    ),
)
_UNKNOWN = Diagnosis("The run failed for a reason the worker does not recognise yet.", "Read the run's events, then re-run.", retry=True)


def diagnose(error: str | None) -> Diagnosis:
    text = error or ""
    return next((d for pattern, d in _CAUSES if pattern.search(text)), _UNKNOWN)


def _ago(then: datetime, now: datetime) -> str:
    hours = (now - then).total_seconds() / 3600
    if hours < 48:
        return f"{max(1, round(hours))} h ago"
    return f"{round(hours / 24)} days ago"


def failed_runs(failures: list[dict[str, Any]], freshness: list[dict[str, Any]]) -> list[Signal]:
    """The latest failed run of each connector that has not succeeded since, diagnosed from its error."""
    last_ok = {f["connector_name"]: f.get("last_success_at") for f in freshness}
    seen: set[str] = set()
    out: list[Signal] = []
    for run in failures:  # newest first
        connector = str(run["connector_name"])
        if connector in seen:
            continue
        seen.add(connector)
        failed_at = run.get("finished_at") or run.get("started_at")
        ok = last_ok.get(connector)
        if ok is not None and failed_at is not None and ok > failed_at:
            continue  # a later run of the same connector succeeded
        d = diagnose(run.get("error"))
        evidence = {
            "run_id": str(run["id"]),
            "connector": connector,
            "error": str(run.get("error") or "")[:400],
            "failed_at": failed_at,
            "documents_failed": run.get("documents_failed") or 0,
            "cause": d.cause,
            "fix": d.fix,
        }
        if d.retry:
            action = {"kind": "rerun", "label": f"Re-run {connector}", "params": {"run_id": str(run["id"]), "connector": connector}, "link": "/pipelines?tab=history"}
            status, tier = "waiting", "T2"
        else:
            action = {"kind": "open", "label": "Fix the connection", "link": "/connectors"}
            status, tier = "diagnosed", "T1"
        out.append(Signal(f"run-failed:{run['id']}", "run-triage", f"{connector} run failed", f"{d.cause} {d.fix}", status, tier, action, evidence, diagnosis=d.cause))
    return out


def stalled_runs(count: int) -> list[Signal]:
    if count <= 0:
        return []
    return [
        Signal(
            "runs:stalled",
            "run-triage",
            f"{count} run{'s' if count != 1 else ''} look stuck",
            "They claim to be active but have not reported progress for two hours. The service fails them on its next restart; cancel them from Run history to free the connector now.",
            "diagnosed",
            "T1",
            {"kind": "open", "label": "Open Run history", "link": "/pipelines?tab=history"},
            {"count": count},
            diagnosis="Active runs stopped reporting progress.",
        )
    ]


def intents(rows: list[dict[str, Any]]) -> list[Signal]:
    """Each intent where it is: a plan to approve, questions to answer, a stop to look at, a run to watch."""
    out: list[Signal] = []
    for r in rows:
        status = str(r["status"])
        spec = r.get("spec") or {}
        source = spec.get("source") or {}
        skill = "silver-compiler" if spec.get("kind") == "model_layer" and source.get("mapping_files") else "pipeline-builder"
        name = f"{r.get('jira_key') or 'Intent'} · {r.get('title') or ''}".strip(" ·")[:140]
        link = f"/intents/{r['id']}"
        base = f"intent:{r['id']}"
        evidence = {"intent_id": str(r["id"]), "jira_key": r.get("jira_key"), "status": status}
        if status == "spec_proposed" and spec.get("blockers"):
            blockers = [str(b) for b in spec["blockers"]]
            out.append(
                Signal(
                    f"{base}:blocked",
                    skill,
                    f"Blocked: {name}",
                    f"The plan reads {len(blockers)} table{'s' if len(blockers) != 1 else ''} that hold no rows, so it cannot be approved. Load them, then re-plan.",
                    "diagnosed",
                    "T1",
                    {"kind": "open", "label": "Open the plan", "link": link},
                    {**evidence, "blockers": blockers[:6]},
                    diagnosis=blockers[0],
                )
            )
        elif status == "spec_proposed":
            tables = len(spec.get("tables") or spec.get("models") or []) or 1
            risks = len(spec.get("risks") or [])
            out.append(
                Signal(
                    f"{base}:approve",
                    skill,
                    f"Plan ready: {name}",
                    f"{tables} table{'s' if tables != 1 else ''} planned, {risks} risk{'s' if risks != 1 else ''} to read. Approving generates the pipeline and runs it.",
                    "waiting",
                    "T2",
                    {"kind": "approve_intent", "label": "Approve and run", "params": {"intent_id": str(r["id"])}, "link": link},
                    {**evidence, "tables": tables, "risks": risks},
                )
            )
        elif status == "clarifying":
            questions = [str(q) for q in r.get("questions") or []]
            out.append(
                Signal(
                    f"{base}:questions",
                    skill,
                    f"Questions on {name}",
                    " ".join(questions)[:300] or "The ticket needs answers before it can be planned.",
                    "waiting",
                    "T1",
                    {"kind": "open", "label": "Answer the questions", "link": link},
                    {**evidence, "questions": len(questions)},
                )
            )
        elif status == "failed":
            out.append(
                Signal(
                    f"{base}:failed",
                    skill,
                    f"Stopped: {name}",
                    str(r.get("error") or "The intent stopped.")[:300],
                    "diagnosed",
                    "T1",
                    {"kind": "open", "label": "Open the intent", "link": link},
                    evidence,
                    diagnosis=str(r.get("error") or "")[:160],
                )
            )
        elif status == "pr_open":
            out.append(
                Signal(
                    f"{base}:generated",
                    skill,
                    f"Generated: {name}",
                    "The pipeline is generated and tested; run it from the intent.",
                    "waiting",
                    "T2",
                    {"kind": "open", "label": "Run it", "link": link},
                    evidence,
                )
            )
        elif status == "loaded":
            out.append(
                Signal(
                    f"{base}:loaded",
                    skill,
                    f"Loaded: {name}",
                    "The pipeline ran and its checks passed. Check the numbers, then close the intent.",
                    "waiting",
                    "T1",
                    {"kind": "open", "label": "Review and close", "link": link},
                    evidence,
                )
            )
        elif status == "waiting":
            waits = (r.get("route") or {}).get("waits_on") or []
            out.append(
                Signal(
                    f"{base}:upstream",
                    skill,
                    f"Waiting for upstream: {name}",
                    f"Goes on once {', '.join(waits) or 'its source tables'} land; checked again every few minutes.",
                    "detected",
                    "T0",
                    {"kind": "open", "label": "Open the intent", "link": link},
                    evidence,
                )
            )
        elif status in _WORKING:
            out.append(Signal(f"{base}:working", skill, f"Working: {name}", f"The hub is {_WORKING[status]}.", "running", "T2", None, evidence))
    return out


def stale_syncs(freshness: list[dict[str, Any]], now: datetime, *, hours: int = 24) -> list[Signal]:
    """Catalog connectors whose last good sync is older than `hours`; a connector that never succeeded is left to run triage."""
    out: list[Signal] = []
    for f in freshness:
        if str(f.get("source_system")) not in CATALOG_SOURCES or f.get("last_status") in ("running", "queued", "paused"):
            continue
        last = f.get("last_success_at")
        if last is None or now - last <= timedelta(hours=hours):
            continue
        connector = str(f["connector_name"])
        out.append(
            Signal(
                f"sync:{connector}",
                "catalog-sync",
                f"{connector} catalog is {_ago(last, now).replace(' ago', '')} old",
                f"Last good sync {_ago(last, now)}. A sync with the scope that last worked brings it up to date.",
                "waiting",
                "T2",
                {"kind": "sync", "label": f"Sync {connector}", "params": {"connector": connector}, "link": "/connectors"},
                {"connector": connector, "last_success_at": last, "last_status": f.get("last_status")},
            )
        )
    return out


def catalog_gaps(health: dict[str, Any]) -> list[Signal]:
    """Tables without a description and facts without a key, the first few named."""
    out: list[Signal] = []
    assets, facts = int(health.get("assets") or 0), int(health.get("facts") or 0)

    def names(refs: list[dict[str, Any]]) -> list[str]:
        return [str(a.get("name") or a.get("fqn") or "") for a in refs[:3] if a]

    undocumented = assets - int(health.get("described") or 0)
    if undocumented > 0:
        first = names(health.get("undocumented") or [])
        out.append(
            Signal(
                "curate:undocumented",
                "catalog-curator",
                f"{undocumented} table{'s' if undocumented != 1 else ''} without a description",
                f"Of {assets} in the catalog." + (f" First up: {', '.join(first)}." if first else ""),
                "diagnosed",
                "T1",
                {"kind": "open", "label": "Review in Catalog health", "link": "/engineer/health"},
                {"count": undocumented, "assets": assets, "first": first},
                diagnosis=f"{undocumented} of {assets} tables have no description.",
            )
        )
    keyless = facts - int(health.get("keyed_facts") or 0)
    if keyless > 0:
        first = names(health.get("keyless_facts") or [])
        out.append(
            Signal(
                "curate:keyless",
                "catalog-curator",
                f"{keyless} fact{'s' if keyless != 1 else ''} without a key",
                f"Of {facts} facts; without a key their joins are guesses." + (f" First up: {', '.join(first)}." if first else ""),
                "diagnosed",
                "T1",
                {"kind": "open", "label": "Review in Catalog health", "link": "/engineer/health"},
                {"count": keyless, "facts": facts, "first": first},
                diagnosis=f"{keyless} of {facts} facts have no primary key.",
            )
        )
    return out


def _when(text: str | None) -> datetime | None:
    if not text:
        return None
    try:
        value = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None
    return value if value.tzinfo else value.replace(tzinfo=UTC)


def repos(payload: dict[str, Any], now: datetime, *, days: int = 7) -> list[Signal]:
    """Configured repositories never crawled, and crawled ones older than `days`."""
    crawled = {str(c["repo"]): c for c in payload.get("crawled") or []}
    out: list[Signal] = []
    for repo in sorted(set(payload.get("configured") or []) | set(crawled)):
        c = crawled.get(repo) or {}
        when = _when(c.get("crawled_at"))
        if when is not None and now - when < timedelta(days=days):
            continue
        out.append(
            Signal(
                f"crawl:{repo}",
                "repo-crawler",
                f"Crawl {repo}",
                f"Last crawled {_ago(when, now)}; the graph may miss newer pipelines." if when else "Never crawled into the knowledge graph.",
                "waiting",
                "T2",
                {"kind": "crawl", "label": f"Crawl {repo}", "params": {"repo": repo}, "link": "/knowledge"},
                {"repo": repo, "crawled_at": c.get("crawled_at"), "files": c.get("files")},
            )
        )
    return out
