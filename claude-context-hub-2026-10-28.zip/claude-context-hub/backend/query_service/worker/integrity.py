"""Declared against live: every table a repository or a design document declares, checked against what the catalog
observed in the warehouse.

The rule is the data-engineering-agent package's: a table with a declaration and no observation is a plan, not a
table. A join against it passes review and returns nothing, because the reviewer assumes a table named in a file
exists. Each declared table gets one status:

* ``live``          the warehouse holds it, with rows
* ``empty``         it exists and holds no rows: created, never loaded
* ``exists``        it exists; the catalog has no row count for it
* ``planned_only``  declared, never seen in the warehouse

A declared table matches an observed one by schema and name; failing that, by its bare name in the same schema
(``B_CITY`` and ``CITY_ICEBERG`` are both CITY), which is reported as loaded under another name. Readers are what an
empty or missing table takes down with it: models the repository derives from it, tables whose foreign keys point
at it, and intent plans that read it.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from query_service.intents import mapping
from query_service.worker.signals import Signal

STATUSES = ("live", "empty", "exists", "planned_only")


def bare(name: str) -> str:
    """A table name without a one-letter system prefix (A_, B_) or a load suffix (_ICEBERG): CITY."""
    short = name.rsplit(".", 1)[-1].upper()
    short = re.sub(r"_(ICEBERG|RAW|STG|BRONZE|SILVER|GOLD)$", "", short)
    return re.sub(r"[^A-Z0-9]", "", re.sub(r"^[A-Z]_", "", short))


@dataclass
class Declared:
    origin: str  # owner/repo, or the design folder under the data directory
    kind: str  # repo | design
    schema: str
    name: str
    database: str | None = None
    layer: str | None = None
    reads: list[str] = field(default_factory=list)  # SCHEMA.NAME of what it derives from


def from_repo(rows: list[dict[str, Any]]) -> list[Declared]:
    out: list[Declared] = []
    for r in rows:
        full = str(r.get("name") or "")
        schema = str(r.get("schema") or (full.split(".")[-2] if "." in full else "")).upper()
        name = str(r.get("table") or full.rsplit(".", 1)[-1]).upper()
        if not name:
            continue
        reads = [str(p).upper() for p in r.get("reads") or [] if p]
        out.append(Declared(str(r["repo"]), "repo", schema, name, str(r.get("catalog") or "").upper() or None, r.get("layer"), reads))
    return out


def from_designs(root: Path) -> list[Declared]:
    """Tables the design documents under the data directory declare (DDL, a mapping's targets), with their foreign keys
    as what each one reads. The digital workers' own packages are skipped: their worked examples declare nothing here."""
    out: list[Declared] = []
    for origin, texts in mapping.design_folders(root, ("ddl", "mapping")):
        design = mapping.load_design(texts)
        schemas = {m.target: m.schema for m in design.mapping}
        names = list(design.ddl) + [t for t in schemas if t not in design.ddl]
        for name in names:
            ddl = design.ddl.get(name)
            schema = (ddl.schema if ddl and ddl.schema else schemas.get(name, "")).upper()
            reads = sorted({f"{schema}.{fk.table}" for fk in (ddl.foreign_keys if ddl else []) if fk.table != name})
            out.append(Declared(origin, "design", schema, name.upper(), None, schema.lower() or None, reads))
    return out


def plan_readers(intent_rows: list[dict[str, Any]]) -> dict[str, list[str]]:
    """SCHEMA.NAME -> the open intent plans that read it."""
    out: dict[str, list[str]] = {}
    for r in intent_rows:
        if r.get("status") in ("done", "rejected"):
            continue
        spec = r.get("spec") or {}
        label = f"{r.get('jira_key') or 'intent'} plan"
        for m in spec.get("models") or []:
            for source in m.get("sources") or []:
                key = ".".join(str(source).upper().split(".")[-2:])
                out.setdefault(key, [])
                if label not in out[key]:
                    out[key].append(label)
    return out


def classify(declared: list[Declared], observed: list[dict[str, Any]], plans: dict[str, list[str]] | None = None) -> list[dict[str, Any]]:
    """One row per declared table: its status, the observed table it matched, its rows, and what reads it."""
    exact: dict[tuple[str, str], list[dict[str, Any]]] = {}
    loose: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for o in observed:
        schema, name = str(o["schema_name"]).upper(), str(o["name"]).upper()
        exact.setdefault((schema, name), []).append(o)
        loose.setdefault((schema, bare(name)), []).append(o)
    readers: dict[str, list[str]] = {}
    for d in declared:
        for parent in d.reads:
            readers.setdefault(parent, []).append(f"{d.schema}.{d.name} derives from it" if d.kind == "repo" else f"{d.schema}.{d.name} references it")
    for key, labels in (plans or {}).items():
        readers.setdefault(key, []).extend(f"{label} reads it" for label in labels)
    out: list[dict[str, Any]] = []
    for d in declared:
        alias = False
        hits = exact.get((d.schema, d.name), [])
        if not hits:
            hits, alias = loose.get((d.schema, bare(d.name)), []), True
        if d.database:
            hits = [h for h in hits if str(h["database_name"]).upper() == d.database] or hits
        hit = hits[0] if hits else None
        rows = hit.get("row_count") if hit else None
        status = "planned_only" if hit is None else "exists" if rows is None else "empty" if int(rows) == 0 else "live"
        key = f"{d.schema}.{d.name}"
        observed_key = f"{str(hit['schema_name']).upper()}.{str(hit['name']).upper()}" if hit else key
        out.append(
            {
                "origin": d.origin,
                "kind": d.kind,
                "layer": d.layer,
                "table": key,
                "status": status,
                "observed": hit["fqn"] if hit else None,
                "loaded_as": str(hit["name"]).upper() if hit and alias and str(hit["name"]).upper() != d.name else None,
                "rows": int(rows) if rows is not None else None,
                "synced_at": hit.get("synced_at") if hit else None,
                "readers": sorted(set(readers.get(key, []) + (readers.get(observed_key, []) if observed_key != key else []))),
            }
        )
    return out


def summary(rows: list[dict[str, Any]], observed: list[dict[str, Any]]) -> dict[str, Any]:
    origins: dict[str, dict[str, Any]] = {}
    for r in rows:
        o = origins.setdefault(r["origin"], {"origin": r["origin"], "kind": r["kind"], "declared": 0, **{s: 0 for s in STATUSES}, "aliases": 0})
        o["declared"] += 1
        o[r["status"]] += 1
        o["aliases"] += bool(r["loaded_as"])
    matched = {r["observed"] for r in rows if r["observed"]}
    return {"origins": list(origins.values()), "undeclared": sum(1 for o in observed if o["fqn"] not in matched), "observed": len(observed)}


def signals(rows: list[dict[str, Any]]) -> list[Signal]:
    """Per origin: the tables declared and never built, and those built and never loaded, with what reads them."""
    out: list[Signal] = []
    origins = sorted({r["origin"] for r in rows})
    for origin in origins:
        mine = [r for r in rows if r["origin"] == origin]
        for status, verb, why in (
            ("planned_only", "declared but not in the warehouse", "No run has ever written them: they are plans, not tables."),
            ("empty", "created but never loaded", "They exist and hold no rows, so anything reading them returns nothing."),
        ):
            hit = [r for r in mine if r["status"] == status]
            if not hit:
                continue
            readers = sorted({x for r in hit for x in r["readers"]})
            names = [r["table"] for r in hit]
            out.append(
                Signal(
                    f"integrity:{status}:{origin}",
                    "schema-integrity",
                    f"{len(hit)} table{'s' if len(hit) != 1 else ''} {verb}",
                    f"Declared in {origin}. {why}"
                    + (f" {len(readers)} reader{'s' if len(readers) != 1 else ''} would get nothing." if readers else "")
                    + " Plans that read them cannot be approved until they hold rows.",
                    "diagnosed",
                    "T1",
                    {"kind": "open", "label": "See planned vs live", "link": "/engineer#integrity"},
                    {"origin": origin, "count": len(hit), "first": names[:5], "readers": readers[:8]},
                    diagnosis=f"{len(hit)} of {len(mine)} tables declared in {origin} are {verb}: {', '.join(names[:4])}{'…' if len(names) > 4 else ''}.",
                )
            )
    return out
