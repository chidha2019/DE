"""A digital worker's skills: what it can do, how far it may go alone, and what gates its output.

The hub's own skills run on its services. A SKILL.md package (YAML front matter with ``name``, ``description`` and
``metadata.autonomy_ceiling`` / ``required_actions``, then ``## Gate`` and ``## Stop conditions`` sections) placed in
the worker's folder (``<data dir>/digital-worker/<worker>/<skill>/SKILL.md``) is listed as well. A package whose name
matches a hub skill, or that the folder's ``bindings.yml`` binds to one, governs it: its gate, stop conditions and
rules show on the skill and the hub runs it, under the stricter of the two autonomy ceilings. Any other package is
shown as reference only until the hub has an adapter for it.

A playbook package (``## Red Flags`` and ``## Verification`` sections, as in the open data-engineering-agent-skills
registry) does not govern: bound to a skill it adds its red flags and done-when checks, and leaves the tier and gate
to the skill and its governing package. Several playbooks may bind to one skill.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any

import yaml

from ech_core.logging import get_logger

log = get_logger(__name__)
TIERS = ("T0", "T1", "T2", "T3")
_FRONT = re.compile(r"\A---\s*\n(.*?)\n---\s*\n?(.*)\Z", re.S)
_SECTION = re.compile(r"^##\s+(.+?)\s*$", re.M)
_MAX_PACKAGES = 200
_BOILERPLATE = {"inputs", "outputs", "run", "evidence", "evals", "reference files", "context sources", "workflow", "gate", "stop conditions", "install"}
_BULLET = re.compile(r"^\s*(?:[-*]|\d+[.)])\s+(?:\[[ xX]\]\s*)?(.+?)\s*$")
BINDINGS = "bindings.yml"  # package name -> the hub skill it describes, when the names differ


@dataclass(frozen=True)
class Skill:
    key: str
    name: str
    description: str
    tier: str
    gate: str = ""
    stops: tuple[str, ...] = ()
    actions: tuple[str, ...] = ()
    rules: tuple[str, ...] = ()
    where: str = ""
    source: str = "hub"
    package: str | None = None
    runnable: bool = True
    red_flags: tuple[str, ...] = ()
    checks: tuple[str, ...] = ()  # what is true when the work is done
    playbooks: tuple[Skill, ...] = ()
    extra: dict[str, Any] = field(default_factory=dict, compare=False)

    @property
    def playbook(self) -> bool:
        return bool(self.red_flags or self.checks)


DATA_ENGINEER: tuple[Skill, ...] = (
    Skill(
        "run-triage",
        "Run triage",
        "Watches every ingestion run. When one fails it reads the error, names the cause and whether a re-run will fix it, and proposes the re-run.",
        "T2",
        gate="A re-run starts only once a person approves it, with the failed run's own scope and options.",
        stops=("The cause is credentials or a missing grant: a person fixes the connection first",),
        actions=("read runs", "start a run, once approved"),
        where="/pipelines?tab=history",
    ),
    Skill(
        "pipeline-builder",
        "Pipeline builder",
        "Takes a Jira ticket through the intent flow: reads it, checks Snowflake read-only, plans the pipeline, then generates and runs it once the plan is approved.",
        "T2",
        gate="Nothing is written before a person approves the plan, and the generated pipeline's tests must pass.",
        stops=("The ticket has open questions", "The tables it builds from are not loaded yet"),
        actions=("read Jira and Snowflake", "comment on the ticket", "run an approved pipeline"),
        where="/intents",
    ),
    Skill(
        "silver-compiler",
        "Silver compiler",
        "Compiles a source-to-target mapping, data model and DDL into a modelled layer, dry-running every table read-only before the plan is shown.",
        "T2",
        gate="Every table compiles and dry-runs in Snowflake; rows that break the DDL are rejected with a reason.",
        stops=("A logical source binds to no loaded table: that branch waits",),
        actions=("read Snowflake", "generate SQL"),
        where="/intents",
    ),
    Skill(
        "catalog-sync",
        "Catalog freshness",
        "Keeps the catalog no older than a day: finds connectors whose last good sync is stale and proposes a sync with the scope that last worked.",
        "T2",
        gate="A sync starts only once approved, and reuses the last successful run's scope.",
        stops=("A sync for that connector is already running",),
        actions=("read runs", "start a sync, once approved"),
        where="/connectors",
    ),
    Skill(
        "catalog-curator",
        "Catalog curator",
        "Finds what a data engineer fixes first: tables without a description and facts without a key, and lines them up for review.",
        "T1",
        gate="It lists and links only; a person accepts descriptions and keys in the Semantic Hub.",
        actions=("read the catalog",),
        where="/engineer/health",
    ),
    Skill(
        "schema-integrity",
        "Schema integrity",
        "Checks every table a repository or a design document declares against what the warehouse holds: live, empty (created, never loaded) or planned only (declared, never built), with what reads each one.",
        "T1",
        gate="A plan that reads a table holding no rows cannot be approved; load the table, then re-plan.",
        stops=("The repository graph or the catalog cannot be read: it says so and reports nothing",),
        actions=("read the repository graph", "read the catalog", "read the design documents"),
        where="/engineer#integrity",
    ),
    Skill(
        "repo-crawler",
        "Repo crawler",
        "Crawls the pipeline repositories into the knowledge graph as declared facts: which files and tasks read and write which datasets.",
        "T2",
        gate="Every node is declared, labels and relationship types come from an allow-list, and a crawl replaces the repository's subgraph whole.",
        stops=("A crawl fails: the previous graph stays",),
        actions=("read GitHub", "write the knowledge graph, once approved"),
        where="/knowledge",
    ),
)

WORKERS: dict[str, tuple[str, tuple[Skill, ...]]] = {"data_engineer": ("Data Engineer", DATA_ENGINEER)}


def _sections(body: str) -> dict[str, str]:
    marks = list(_SECTION.finditer(body))
    out: dict[str, str] = {}
    for i, m in enumerate(marks):
        end = marks[i + 1].start() if i + 1 < len(marks) else len(body)
        out[m.group(1).strip().lower()] = body[m.end() : end].strip()
    return out


def _bullets(sections: dict[str, str], prefix: str) -> tuple[str, ...]:
    """The list items of the first section whose heading starts with ``prefix``, checkboxes and backticks dropped."""
    text = next((v for k, v in sections.items() if k.startswith(prefix)), "")
    found = (_BULLET.match(line) for line in text.splitlines())
    return tuple(m.group(1).replace("`", "") for m in found if m)


def _loose_front(block: str) -> dict[str, Any]:
    """Front matter that is not strict YAML (an unquoted ': ' inside a description): top-level `key: value` lines,
    and the indented lines under a key with no value as that key's mapping."""
    out: dict[str, Any] = {}
    parent: str | None = None
    for line in block.splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        key, sep, value = line.strip().partition(":")
        if not sep:
            continue
        value = value.strip().strip("'\"")
        if line[:1].isspace() and parent is not None:
            out[parent][key.strip()] = value
        elif value:
            out[key.strip()], parent = value, None
        else:
            out[key.strip()], parent = {}, key.strip()
    return out


def read_package(text: str, *, where: str = "") -> Skill | None:
    """One SKILL.md as a skill; None when it has no front matter with a name."""
    m = _FRONT.match(text.lstrip("﻿"))
    if not m:
        return None
    try:
        front = yaml.safe_load(m.group(1)) or {}
    except yaml.YAMLError:
        front = _loose_front(m.group(1))
    if not isinstance(front, dict) or not front.get("name"):
        return None
    meta = front.get("metadata") if isinstance(front.get("metadata"), dict) else {}
    sections = _sections(m.group(2))
    ceiling = str(meta.get("autonomy_ceiling") or "").upper()
    gate = " ".join(line.strip() for line in sections.get("gate", "").splitlines() if line.strip())
    stops = tuple(re.sub(r"^[-*]\s*", "", line).strip() for line in sections.get("stop conditions", "").splitlines() if line.strip().startswith(("-", "*")))
    actions = tuple(a.strip() for a in str(meta.get("required_actions") or "").split(",") if a.strip())
    name = str(front["name"]).strip()
    red_flags, checks = _bullets(sections, "red flag"), _bullets(sections, "verification")
    # The package's own rules are its section headings, less the ones every package has. A playbook's headings are
    # its format's (Overview, When to Use, ...), so its rules are its red flags and checks instead.
    rules = () if red_flags or checks else tuple(h for h in (m2.group(1).strip() for m2 in _SECTION.finditer(m.group(2))) if h.lower() not in _BOILERPLATE)
    return Skill(
        key=name,
        name=name.replace("-", " ").capitalize(),
        description=str(front.get("description") or "").strip(),
        tier=ceiling if ceiling in TIERS else "",
        gate=gate,
        stops=stops,
        actions=actions,
        rules=rules,
        where=where,
        source="package",
        package=where,
        runnable=False,
        red_flags=red_flags,
        checks=checks,
        extra={"persona": meta.get("persona"), "version": meta.get("version"), "runtime_status": meta.get("runtime-status")},
    )


def load_bindings(folder: Path) -> dict[str, str]:
    """The worker folder's bindings.yml: which hub skill a package describes when its name is not the hub's."""
    path = folder / BINDINGS
    if not path.is_file():
        return {}
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except (OSError, yaml.YAMLError) as exc:
        log.warning("worker.bindings_unreadable", path=str(path), error=str(exc))
        return {}
    return {str(k): str(v) for k, v in data.items()} if isinstance(data, dict) else {}


def load_packages(folder: Path) -> list[Skill]:
    if not folder.is_dir():
        return []
    out: list[Skill] = []
    for path in sorted(folder.rglob("SKILL.md"))[:_MAX_PACKAGES]:
        try:
            skill = read_package(path.read_text(encoding="utf-8", errors="replace"), where=str(path.relative_to(folder)).replace("\\", "/"))
        except OSError as exc:
            log.warning("worker.package_unreadable", path=str(path), error=str(exc))
            continue
        if skill is not None:
            out.append(skill)
    return out


def skills_for(worker: str, packages: list[Skill], bindings: dict[str, str] | None = None) -> list[Skill]:
    """The worker's skills: the hub's own, each governed by its package when there is one (same name, or bound in
    bindings.yml) and carrying the playbooks bound to it, then the packages no hub skill runs, as reference only."""
    _, hub = WORKERS[worker]
    known = {s.key for s in hub}
    bound: dict[str, list[Skill]] = {}
    loose: list[Skill] = []
    for p in packages:
        target = (bindings or {}).get(p.key, p.key)
        if target in known:
            bound.setdefault(target, []).append(p)
        else:
            loose.append(p)
    out: list[Skill] = []
    for skill in hub:
        mine = bound.get(skill.key, [])
        pkg = next((p for p in mine if not p.playbook), None)  # the first package that is not a playbook governs
        skill = replace(skill, playbooks=tuple(p for p in mine if p is not pkg))
        if pkg is None:
            out.append(skill)
            continue
        # The stricter ceiling (T0 < T1 < T2 < T3); a package that names none keeps the hub's.
        tier = min(skill.tier, pkg.tier) if pkg.tier else skill.tier
        out.append(
            replace(
                skill,
                tier=tier,
                gate=pkg.gate or skill.gate,
                stops=pkg.stops or skill.stops,
                actions=pkg.actions or skill.actions,
                rules=pkg.rules,
                source="package",
                package=pkg.package,
                extra={**pkg.extra, "package_name": pkg.key},
            )
        )
    out += [replace(p, tier=p.tier or "T1") for p in loose]
    return out
