"""What a digital worker can deliver, and whether it can deliver it now.

A capability is an outcome a person asks for: understand a request, design a model, prepare a pipeline. It is
delivered through abilities, and an ability is ready only when everything it needs is in place: the connection it
reads, the rules it compiles from, the tool that does the work. An installed skill package is never enough on its
own, so preparing a pipeline's code and executing an approved pipeline are separate abilities with separate needs.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

# A missing need of each kind leaves the ability in this readiness state.
READINESS = {"connection": "missing_connection", "rules": "missing_rules", "tool": "tool_unavailable"}


@dataclass(frozen=True)
class Fact:
    """One thing the hub checked: whether it is in place, and what that means for the person."""

    ok: bool
    detail: str = ""


@dataclass(frozen=True)
class Need:
    key: str
    kind: str  # connection | rules | tool
    label: str


@dataclass(frozen=True)
class Ability:
    label: str
    needs: tuple[str, ...] = ()
    headline: bool = False  # one way to deliver the outcome: the capability is available when any headline ability is
    optional: bool = False  # shown, but never decides the capability's readiness


@dataclass(frozen=True)
class Capability:
    key: str
    title: str
    outcome: str
    action: str
    link: str
    needs_input: str
    skills: tuple[str, ...]
    tools: tuple[str, ...]
    abilities: tuple[Ability, ...]
    more: tuple[str, str] | None = None  # a second action: label, link


NEEDS: dict[str, Need] = {
    n.key: n
    for n in (
        Need("jira", "connection", "Jira connection"),
        Need("snowflake", "connection", "Snowflake, read-only"),
        Need("model", "tool", "Claude"),
        Need("runner", "tool", "Pipeline runner"),
        Need("run_settings", "connection", "Snowflake run settings"),
        Need("run_access", "connection", "The pipeline role's grants"),
        Need("designs", "rules", "Mapping, data model and DDL"),
        Need("catalog", "connection", "Warehouse catalog"),
        Need("ingestion", "tool", "Ingestion service"),
        Need("graph", "connection", "Repository graph"),
        Need("er_diagram", "tool", "ER diagram renderer"),
        Need("reconcile", "tool", "Source-to-target reconciliation"),
        Need("pr_impact", "tool", "Pull-request impact check"),
    )
}

DATA_ENGINEER: tuple[Capability, ...] = (
    Capability(
        "understand",
        "Understand a request",
        "Reads a Jira ticket, works out what it asks for and prepares a delivery plan for you to approve.",
        "Start from Jira",
        "/intents",
        "A Jira ticket key.",
        ("pipeline-builder",),
        ("Jira", "Snowflake, read-only", "Claude"),
        (
            Ability("Read the ticket and its replies", ("jira",), headline=True),
            Ability("Check what it names against Snowflake, read-only", ("snowflake",)),
            Ability("Ask in Jira what the ticket leaves open", ("jira",)),
            Ability("Prepare a delivery plan"),
        ),
    ),
    Capability(
        "design",
        "Design Silver & Gold",
        "Proposes entities, grains, keys and source mappings with Snowflake DDL, and dry-runs every table read-only.",
        "Start from Jira",
        "/intents",
        "A Bronze database and schema, or a mapping, data model and DDL.",
        ("silver-compiler",),
        ("Snowflake, read-only", "Claude", "SQL compiler", "ER diagram"),
        (
            Ability("Propose a model from the Bronze tables", ("model", "snowflake"), headline=True),
            Ability("Compile your mapping, data model and DDL into the layer", ("designs", "snowflake"), headline=True),
            Ability("Dry-run every table: rows, repeated keys, NULLs, orphans", ("snowflake",)),
            Ability("Draw the ER diagram", ("er_diagram",), optional=True),
        ),
        more=("View the ER diagram", "/engineer/datamodels"),
    ),
    Capability(
        "prepare",
        "Prepare pipelines",
        "Writes source-bound ingestion or transformation code with its tests from an approved plan.",
        "Prepare a pipeline",
        "/intents",
        "An approved plan.",
        ("pipeline-builder",),
        ("Pipeline generator", "Pipeline runner", "Snowflake"),
        (
            Ability("Prepare the code and its tests", headline=True),
            Ability("Execute an approved pipeline in Snowflake", ("runner", "run_settings", "run_access")),
        ),
    ),
    Capability(
        "validate",
        "Validate the work",
        "Checks what was built against its contract and lists what is still unresolved.",
        "See planned vs live",
        "#integrity",
        "A plan, a generated pipeline or a loaded table.",
        ("schema-integrity", "catalog-curator"),
        ("Snowflake, read-only", "Warehouse catalog", "Repository graph"),
        (
            Ability("Test the generated SQL before it runs", ("snowflake",), headline=True),
            Ability("Check keys, NULLs, references and freshness after each load", ("runner", "run_settings")),
            Ability("Compare declared tables with what the warehouse holds", ("catalog",), headline=True),
            Ability("Reconcile rows, keys and totals against the source after each load", ("reconcile", "runner", "run_settings")),
        ),
    ),
    Capability(
        "investigate",
        "Investigate failures",
        "Reads every failed run, names the cause from its evidence and proposes the correction.",
        "See failed runs",
        "/pipelines?tab=history",
        "Nothing: failed runs are picked up as they happen.",
        ("run-triage", "catalog-sync"),
        ("Run history", "Ingestion service"),
        (
            Ability("Diagnose failed and stuck runs", headline=True),
            Ability("Re-run with the failed run's scope once you approve", ("ingestion",)),
        ),
    ),
    Capability(
        "explain",
        "Explain dependencies",
        "Traces source-to-target lineage and shows what reads a table before you change it.",
        "Trace lineage",
        "/engineer/lineage",
        "A table or dataset name.",
        ("repo-crawler", "schema-integrity"),
        ("Repository graph", "Warehouse catalog"),
        (
            Ability("Trace lineage through the crawled repositories", ("graph",), headline=True),
            Ability("Show what reads each declared table", ("catalog",), headline=True),
            Ability("Check a pull request's impact", ("pr_impact",), optional=True),
        ),
    ),
)

CAPABILITIES: dict[str, tuple[Capability, ...]] = {"data_engineer": DATA_ENGINEER}


def evaluate(capabilities: tuple[Capability, ...], facts: dict[str, Fact]) -> list[dict[str, Any]]:
    """Each capability with every ability's readiness, from the facts the hub checked. A need nobody checked counts as
    missing: a capability is available once everything one of its headline abilities needs is in place, and otherwise
    takes the state of its first headline ability."""
    unknown = Fact(False, "not checked yet")
    out: list[dict[str, Any]] = []
    for cap in capabilities:
        abilities: list[dict[str, Any]] = []
        for ability in cap.abilities:
            missing = next((NEEDS[n] for n in ability.needs if not facts.get(n, unknown).ok), None)
            abilities.append(
                {
                    "label": ability.label,
                    "status": READINESS[missing.kind] if missing else "available",
                    "reason": f"{missing.label}: {facts.get(missing.key, unknown).detail}" if missing else "",
                    "headline": ability.headline,
                    "optional": ability.optional,
                }
            )
        heads = [a for a, ability in zip(abilities, cap.abilities, strict=True) if ability.headline] or abilities[:1]
        lead = next((a for a in heads if a["status"] == "available"), heads[0])
        keys = list(dict.fromkeys(n for a in cap.abilities for n in a.needs))
        out.append(
            {
                "key": cap.key,
                "title": cap.title,
                "outcome": cap.outcome,
                "readiness": lead["status"],
                "reason": lead["reason"],
                "action": cap.action,
                "link": cap.link,
                "more_action": cap.more[0] if cap.more else "",
                "more_link": cap.more[1] if cap.more else "",
                "needs_input": cap.needs_input,
                "skills": list(cap.skills),
                "tools": list(cap.tools),
                "abilities": abilities,
                "context": [
                    {"key": k, "kind": NEEDS[k].kind, "label": NEEDS[k].label, "ok": facts.get(k, unknown).ok, "detail": facts.get(k, unknown).detail}
                    for k in keys
                ],
            }
        )
    return out
