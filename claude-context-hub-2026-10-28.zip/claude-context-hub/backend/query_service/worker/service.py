"""The digital worker: sweeps the hub's signals on a timer, works each one as far as its tier allows, asks a person for
the rest, and writes every step to a hash-chained journal.

T0 watches, T1 diagnoses and proposes on its own, T2 acts only once a person approves, T3 (never granted here) would
act alone. Its actions are the hub's own: a run or a sync through the ingestion service, a repository crawl, an intent
approval through the intent service. A signal that goes away resolves its item; a dismissed one stays quiet.
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any
from uuid import UUID

import httpx

from ech_core.domain.enums import RunStatus
from ech_core.exceptions import DependencyUnavailableError, InvalidRequestError, NotFoundError
from ech_core.logging import get_logger
from ech_core.repositories.ingestion_run_repository import IngestionRunRepository
from ech_core.repositories.intent_repository import IntentRepository
from ech_core.repositories.repo_graph_repository import RepoCrawlRepository, RepoGraphRepository
from ech_core.repositories.semantic_repository import SemanticRepository
from ech_core.repositories.worker_repository import OPEN_STATUSES, WorkerRepository, chain_ok
from ech_core.schemas.intents import IntentDecision
from ech_core.schemas.worker import (
    WorkerCounts,
    WorkerDecision,
    WorkerIntegrity,
    WorkerItem,
    WorkerCapability,
    WorkerJournalEntry,
    WorkerPlaybook,
    WorkerSkill,
    WorkerSnapshot,
)
from query_service.worker import capabilities as caps
from query_service.worker import integrity as integ
from query_service.worker import signals as sig
from query_service.worker.skills import WORKERS, load_bindings, load_packages, skills_for

log = get_logger(__name__)
ACTOR = "worker:{worker}"
_REOPEN_AFTER = timedelta(hours=24)
_ONE_OFF = ("run-failed:",)  # a key tied to one failed run never reopens once closed; the rest may after a day
# Which source each kind of item comes from: an item resolves only when its own source was read in the sweep.
_SOURCE_OF = (("run-failed:", "runs"), ("runs:", "runs"), ("sync:", "runs"), ("intent:", "intents"), ("curate:", "catalog"), ("crawl:", "repos"), ("integrity:", "integrity"))


class DigitalWorker:
    def __init__(
        self,
        *,
        repo: WorkerRepository,
        runs: IngestionRunRepository,
        intent_rows: IntentRepository,
        semantic: SemanticRepository,
        crawls: RepoCrawlRepository,
        skills_dir: Path,
        ingestion_url: str | None,
        approve_intent: Callable[[UUID, IntentDecision], Any] | None = None,
        tick_seconds: int = 20,
        http: Callable[[], httpx.AsyncClient] | None = None,
        repo_graph: RepoGraphRepository | None = None,
        design_root: Path | None = None,
        integrity_seconds: int = 300,
        intent_config: Callable[[], Any] | None = None,
    ) -> None:
        self._repo = repo
        self._runs = runs
        self._intent_rows = intent_rows
        self._semantic = semantic
        self._crawls = crawls
        self._skills_dir = skills_dir
        self._ingestion = ingestion_url.rstrip("/") if ingestion_url else None
        self._approve_intent = approve_intent
        self.tick_seconds = max(5, tick_seconds)
        self._http = http
        self._lock = asyncio.Lock()
        self._signals: dict[str, int] = {}
        self._read_ok: set[str] = set()
        self._repo_graph = repo_graph
        self._design_root = design_root
        self._integrity_every = timedelta(seconds=integrity_seconds)
        self._integrity: WorkerIntegrity | None = None
        self._integrity_rows: list[dict[str, Any]] = []
        self._intent_config = intent_config
        self._intents_seen: list[dict[str, Any]] = []  # the last sweep's intents: their latest runs prove the grants

    # ------------------------------------------------------------------ reads
    @staticmethod
    def _known(worker: str) -> None:
        if worker not in WORKERS:
            raise NotFoundError(f"no digital worker for {worker}")

    def skills(self, worker: str) -> list[Any]:
        folder = self._skills_dir / worker
        return skills_for(worker, load_packages(folder), load_bindings(folder))

    def checklist(self, worker: str, skill: str) -> list[tuple[str, str]]:
        """The done-when checks of the playbooks bound to a skill, as (playbook, check)."""
        found = next((s for s in self.skills(worker) if s.key == skill), None)
        return [(p.key, c) for p in (found.playbooks if found else ()) for c in p.checks]

    async def snapshot(self, worker: str) -> WorkerSnapshot:
        self._known(worker)
        title, _ = WORKERS[worker]
        state = await self._repo.state(worker)
        today = datetime.now(UTC).replace(hour=0, minute=0, second=0, microsecond=0)
        items = [WorkerItem.model_validate(i) for i in await self._repo.items(worker, closed_since=today)]
        rows = await self._repo.journal(worker, limit=60)
        counts = await self._repo.counts(worker)
        per_skill = await self._repo.skill_counts(worker)
        skills = []
        for s in self.skills(worker):
            c = per_skill.get(s.key, {})
            skills.append(
                WorkerSkill(
                    key=s.key,
                    name=s.name,
                    description=s.description,
                    tier=s.tier,  # type: ignore[arg-type]
                    gate=s.gate,
                    stops=list(s.stops),
                    actions=list(s.actions),
                    rules=list(s.rules),
                    source=s.source,  # type: ignore[arg-type]
                    package=s.package,
                    red_flags=list(s.red_flags),
                    checks=list(s.checks),
                    playbooks=[
                        WorkerPlaybook(
                            name=p.key,
                            package=p.package or "",
                            description=p.description,
                            rules=list(p.rules),
                            red_flags=list(p.red_flags),
                            checks=list(p.checks),
                        )
                        for p in s.playbooks
                    ],
                    where=s.where if s.runnable else "",
                    handled=int(c.get("handled") or 0),
                    succeeded=int(c.get("succeeded") or 0),
                    open=int(c.get("open") or 0),
                    last_at=c.get("last_at"),
                )
            )
        waiting = [i for i in items if i.status == "waiting"]
        running = [i for i in items if i.status == "running"]
        if state["paused"]:
            now = "Paused: not sweeping until you resume it."
        elif running:
            now = f"Watching {running[0].title}" + (f" and {len(running) - 1} more" if len(running) > 1 else "")
        elif waiting:
            now = f"Waiting for you on {len(waiting)} item{'s' if len(waiting) != 1 else ''}"
        elif findings := [i for i in items if i.status in ("diagnosed", "detected")]:
            now = f"Lined up {len(findings)} finding{'s' if len(findings) != 1 else ''} for you; watching {sum(self._signals.values())} signals"
        else:
            now = f"All clear: watching {sum(self._signals.values())} signals"
        return WorkerSnapshot(
            worker=worker,
            title=f"{title} digital worker",
            autonomy="T2",
            paused=bool(state["paused"]),
            last_tick=state.get("last_tick"),
            tick_seconds=self.tick_seconds,
            now=now,
            counts=WorkerCounts(**counts, signals=sum(self._signals.values())),
            items=items,
            journal=[WorkerJournalEntry.model_validate(r) for r in rows],
            chain_ok=chain_ok(rows),
            skills=skills,
            integrity=self._integrity,
            capabilities=[WorkerCapability.model_validate(c) for c in caps.evaluate(caps.CAPABILITIES.get(worker, ()), self.facts())],
        )

    def facts(self) -> dict[str, caps.Fact]:
        """What the capabilities need, as the hub finds it now: presence only, never a secret's value."""
        F = caps.Fact
        config = self._intent_config() if self._intent_config is not None else None
        g = self._integrity
        seen = "not checked yet: the first sweep reads it" if g is None else g.problem
        readable = g is not None and g.available
        designs = [o.origin for o in g.origins if o.kind == "design"] if readable else []
        repos = [o.origin for o in g.origins if o.kind == "repo"] if readable else []
        run_enabled = bool(config and config.run_enabled)
        missing = list(config.run_missing or []) if config else []
        return {
            "jira": F(True, "connected") if config and config.jira_configured else F(False, "add the Jira connection on the Connectors page"),
            "snowflake": F(True, "connected") if config and config.snowflake_configured else F(False, "add the Snowflake connection on the Connectors page"),
            "model": F(True, "available") if config and config.model_available else F(False, "no Claude model is configured for the hub"),
            "runner": F(True, f"runs approved pipelines as {config.run_role}" if config and config.run_role else "runs approved pipelines")
            if run_enabled
            else F(False, "the hub does not run pipelines here: ECH_INTENT_RUN_ENABLED is off"),
            "run_settings": F(True, "set") if run_enabled and not missing else F(False, f"missing {', '.join(missing)}" if missing else "the runner is off"),
            "run_access": self._run_access(),
            "designs": F(True, f"found in {', '.join(designs)}") if designs else F(False, seen if not readable else "no mapping, data model or DDL under the data folder"),
            "catalog": F(True, f"{g.observed} tables catalogued") if readable and g.observed else F(False, seen if not readable else "the catalog holds no tables: sync a connector"),
            "ingestion": F(True, "connected") if self._ingestion else F(False, "no ingestion service URL is set"),
            "graph": F(True, f"{len(repos)} repositor{'y' if len(repos) == 1 else 'ies'} crawled")
            if repos
            else F(False, seen if not readable else "no repository crawled yet: crawl one on the Knowledge page"),
            "er_diagram": F(True, "draws entities, keys and relationships from the design documents or a model plan"),
            "reconcile": F(True, "every generated load reconciles rows, keys and amount totals against its source; an unexplained gap fails it"),
            "pr_impact": F(False, "not built yet"),
        }

    def _run_access(self) -> caps.Fact:
        """Whether the pipeline role's grants held on the latest run; a refused run is evidence they do not."""
        runs = [r["run"] for r in self._intents_seen if isinstance(r.get("run"), dict) and r["run"].get("started_at")]
        if not runs:
            return caps.Fact(True, "no run yet: the preflight checks the role before the first statement")
        last = max(runs, key=lambda run: str(run["started_at"]))
        if last.get("status") == "failed":
            cause = sig.diagnose(str(last.get("error") or ""))
            if not cause.retry:  # refused grants or credentials: a re-run would fail the same way
                return caps.Fact(False, f"the last run was refused. {cause.cause} {cause.fix}")
            return caps.Fact(True, "the last run failed, but not on the role's grants")
        return caps.Fact(True, f"the last run {last.get('status')}" + (f" as {last['role']}" if last.get("role") else ""))

    # ------------------------------------------------------------------ the sweep
    async def _check_integrity(self, now: datetime, intent_rows: list[dict[str, Any]], *, force: bool) -> None:
        """Declared against live, at most every few minutes. When the graph or the catalog cannot be read it says so and
        reports nothing: a check that silently skips a source looks the same as one that found nothing."""
        fresh = self._integrity is not None and self._integrity.checked_at is not None and now - self._integrity.checked_at < self._integrity_every
        if fresh and not force:
            return
        try:
            declared = integ.from_repo(await self._repo_graph.declared_tables()) if self._repo_graph is not None else []
            if self._design_root is not None:
                declared += await asyncio.to_thread(integ.from_designs, self._design_root)
            observed = await self._repo.catalog_tables()
        except Exception as exc:  # noqa: BLE001 - unavailable is reported, never guessed around
            log.warning("worker.integrity_failed", error=str(exc)[:200])
            self._integrity = WorkerIntegrity(available=False, problem=f"could not read the repository graph or the catalog: {str(exc)[:160]}", checked_at=now)
            self._integrity_rows = []
            return
        rows = integ.classify(declared, observed, integ.plan_readers(intent_rows))
        self._integrity_rows = rows
        self._integrity = WorkerIntegrity.model_validate({"checked_at": now, "tables": rows, **integ.summary(rows, observed)})

    async def _observe(self, now: datetime, *, force: bool = False) -> list[sig.Signal]:
        """Read every signal source; one that fails is skipped for this sweep, not fatal."""
        out: list[sig.Signal] = []
        read: dict[str, int] = {}
        intent_list: list[dict[str, Any]] = []

        async def source(name: str, work: Callable[[], Any]) -> None:
            try:
                found, count = await work()
                out.extend(found)
                read[name] = count
            except Exception as exc:  # noqa: BLE001 - a missing source must not stop the others
                log.warning("worker.source_failed", source=name, error=str(exc)[:200])

        async def runs() -> tuple[list[sig.Signal], int]:
            failures = await self._runs.recent_failures(days=2, limit=40)
            freshness = await self._runs.connector_freshness(days=7)
            stale = await self._runs.count_stale_active(hours=2)
            found = sig.failed_runs(failures, freshness) + sig.stalled_runs(stale) + sig.stale_syncs(freshness, now)
            return found, sum(int(f.get("runs") or 0) for f in freshness)

        async def intents() -> tuple[list[sig.Signal], int]:
            rows, total = await self._intent_rows.list(status=None, limit=100, offset=0)
            intent_list.extend(rows)
            self._intents_seen = rows
            return sig.intents(rows), total

        async def integrity() -> tuple[list[sig.Signal], int]:
            await self._check_integrity(now, intent_list, force=force)
            if self._integrity is None or not self._integrity.available:
                raise RuntimeError(self._integrity.problem if self._integrity else "not checked")
            return integ.signals(self._integrity_rows), len(self._integrity_rows)

        async def catalog() -> tuple[list[sig.Signal], int]:
            health = await self._semantic.health(list_limit=5)
            return sig.catalog_gaps(health), int(health.get("assets") or 0)

        async def repos() -> tuple[list[sig.Signal], int]:
            if not self._ingestion:
                return [], 0
            payload = await self._get("/api/v1/repo-graph/repos")
            return sig.repos(payload, now), len(payload.get("crawled") or []) + len(payload.get("configured") or [])

        for name, work in (("runs", runs), ("intents", intents), ("catalog", catalog), ("repos", repos), ("integrity", integrity)):
            await source(name, work)
        self._signals = read
        self._read_ok = set(read)
        return out

    async def sweep(self, worker: str = "data_engineer", *, force: bool = False) -> int:
        """One pass: follow what the worker started, take in every signal, resolve what went away."""
        self._known(worker)
        state = await self._repo.state(worker)
        if state["paused"]:
            return 0
        async with self._lock:
            now = datetime.now(UTC)
            found = await self._observe(now, force=force)
            await self._follow(worker)
            current = {s.key: s for s in found}
            open_items = await self._repo.open_keys(worker)
            for s in found:
                await self._take(worker, s, open_items.get(s.key), now)
            for key, item in open_items.items():
                if key in current or (item["status"] == "running" and (item.get("evidence") or {}).get("started")):
                    continue
                source = next((src for prefix, src in _SOURCE_OF if key.startswith(prefix)), None)
                if source is not None and source not in self._read_ok:
                    continue  # its source could not be read this time: not seeing it is not the same as it being fixed
                await self._repo.update(key, status="done")
                await self._repo.append(worker, "done", f"Resolved: {item['title']} no longer needs attention.", item_key=key, skill=item["skill"])
            await self._repo.touch(worker)
            return len(found)

    async def _take(self, worker: str, s: sig.Signal, existing: dict[str, Any] | None, now: datetime) -> None:
        if existing is not None:
            started = (existing.get("evidence") or {}).get("started")
            if existing["status"] == "running" and started:
                return  # the worker is following what it started
            if (existing["status"], existing["title"], existing["detail"]) == (s.status, s.title, s.detail):
                return
            await self._repo.upsert(
                key=s.key, worker=worker, skill=s.skill, title=s.title, detail=s.detail, status=s.status, tier=s.tier, action=s.action, evidence=s.evidence
            )
            if existing["status"] != s.status:
                await self._note_status(worker, s)
            return
        closed = await self._repo.item(s.key)
        if closed is not None:
            stale = now - closed["updated_at"] > _REOPEN_AFTER
            if s.key.startswith(_ONE_OFF) or not stale:
                return  # closed by a person or resolved; it does not come back for the same thing
        await self._repo.upsert(
            key=s.key, worker=worker, skill=s.skill, title=s.title, detail=s.detail, status=s.status, tier=s.tier, action=s.action, evidence=s.evidence
        )
        await self._repo.append(worker, "observed", f"Picked up: {s.title}", item_key=s.key, skill=s.skill, evidence=s.evidence)
        await self._note_status(worker, s)

    async def _note_status(self, worker: str, s: sig.Signal) -> None:
        if s.diagnosis:
            await self._repo.append(worker, "diagnosed", s.diagnosis, item_key=s.key, skill=s.skill)
        if s.status == "waiting" and s.action:
            if s.action.get("kind") == "open":
                await self._repo.append(worker, "proposed", f"Needs you: {s.action['label']}.", item_key=s.key, skill=s.skill)
            else:
                await self._repo.append(worker, "proposed", f"Proposed: {s.action['label']}. It waits for your approval.", item_key=s.key, skill=s.skill)

    async def _follow(self, worker: str) -> None:
        """Items the worker started: done when their run or crawl succeeds, failed when it fails."""
        for key, item in (await self._repo.open_keys(worker)).items():
            started = (item.get("evidence") or {}).get("started") or {}
            if item["status"] != "running" or not started.get("id"):
                continue
            try:
                outcome = await self._outcome(started)
            except Exception as exc:  # noqa: BLE001 - try again on the next sweep
                log.warning("worker.follow_failed", item=key, error=str(exc)[:200])
                continue
            if outcome is None:
                continue
            ok, message = outcome
            await self._repo.update(key, status="done" if ok else "failed")
            await self._repo.append(worker, "done" if ok else "failed", message, item_key=key, skill=item["skill"], evidence={"started": started})

    async def _outcome(self, started: dict[str, Any]) -> tuple[bool, str] | None:
        if started.get("kind") == "run":
            run = await self._runs.get(UUID(str(started["id"])))
            if run is None or not run.status.is_terminal:
                return None
            if run.status == RunStatus.COMPLETED:
                upserted = int((run.stats or {}).get("documents_upserted") or 0)
                return True, f"{run.connector_name} run completed: {upserted} document{'s' if upserted != 1 else ''} upserted."
            return False, f"{run.connector_name} run {run.status.value}: {(run.error or 'no error text')[:200]}"
        if started.get("kind") == "crawl":
            crawl = await self._crawls.get(UUID(str(started["id"])))
            if crawl is None or crawl.get("status") not in ("completed", "failed"):
                return None
            if crawl["status"] == "completed":
                return True, f"Crawled {crawl['repo']}: {crawl.get('files_read') or 0} files read into the knowledge graph."
            return False, f"Crawl of {crawl['repo']} failed: {(crawl.get('error') or '')[:200]}"
        return None

    # ------------------------------------------------------------------ decisions
    async def decide(self, worker: str, key: str, body: WorkerDecision, *, by: str = "you") -> WorkerItem:
        self._known(worker)
        item = await self._repo.item(key)
        if item is None or item["worker"] != worker:
            raise NotFoundError(f"no work item {key}")
        if item["status"] not in OPEN_STATUSES:
            raise InvalidRequestError(f"this item is already {item['status']}")
        note = f" ({body.note})" if body.note else ""
        decided = {"decided_by": by, "decided_at": datetime.now(UTC)}
        if body.decision == "dismiss":
            updated = await self._repo.update(key, status="dismissed", **decided)
            await self._repo.append(worker, "dismissed", f"Dismissed by {by}: {item['title']}{note}", item_key=key, skill=item["skill"])
        elif body.decision == "done":
            updated = await self._repo.update(key, status="done", **decided)
            await self._repo.append(worker, "done", f"Marked done by {by}: {item['title']}{note}", item_key=key, skill=item["skill"])
        else:
            action = item.get("action") or {}
            if action.get("kind") in (None, "open"):
                raise InvalidRequestError("nothing here for the worker to do; open it and act there, or mark it done")
            # The approval records each playbook check as confirmed or left open; unticked checks do not block it.
            listed = self.checklist(worker, item["skill"])
            unknown = sorted(set(body.checks) - {c for _, c in listed})
            if unknown:
                raise InvalidRequestError(f"not a check on this skill's playbooks: {unknown[0]}")
            checklist = [{"playbook": p, "check": c, "confirmed": c in body.checks} for p, c in listed]
            confirmed = sum(1 for row in checklist if row["confirmed"])
            tally = f"; {confirmed} of {len(checklist)} playbook checks confirmed" if checklist else ""
            await self._repo.append(
                worker,
                "approved",
                f"Approved by {by}: {action['label']}{note}{tally}",
                item_key=key,
                skill=item["skill"],
                evidence={"checklist": checklist} if checklist else None,
            )
            try:
                started = await self._execute(worker, action)
            except Exception as exc:  # noqa: BLE001 - the item carries the failure
                log.warning("worker.action_failed", item=key, error=str(exc)[:300])
                updated = await self._repo.update(key, status="failed", **decided)
                await self._repo.append(worker, "failed", f"{action['label']} could not start: {str(exc)[:200]}", item_key=key, skill=item["skill"])
                return WorkerItem.model_validate(updated)
            if started.get("kind") == "intent":
                updated = await self._repo.update(key, status="done", **decided)
                await self._repo.append(
                    worker, "acted", "Approved the plan; the hub generates the pipeline and runs it.", item_key=key, skill=item["skill"], evidence={"started": started}
                )
            else:
                updated = await self._repo.update(key, status="running", evidence={**(item.get("evidence") or {}), "started": started}, **decided)
                await self._repo.append(worker, "acted", f"Started: {action['label']}", item_key=key, skill=item["skill"], evidence={"started": started})
        assert updated is not None
        return WorkerItem.model_validate(updated)

    async def _execute(self, worker: str, action: dict[str, Any]) -> dict[str, Any]:
        params = action.get("params") or {}
        actor = ACTOR.format(worker=worker)
        kind = action.get("kind")
        if kind in ("rerun", "sync"):
            if kind == "rerun":
                run = await self._runs.get(UUID(str(params["run_id"])))
                if run is None:
                    raise NotFoundError("the failed run is gone")
                connector, config = run.connector_name, run.config or {}
            else:
                connector = str(params["connector"])
                last, _ = await self._runs.list(status=RunStatus.COMPLETED, connector_name=connector, limit=1)
                config = last[0].config if last else {}
            body = {
                "connector": connector,
                "options": {k: v for k, v in config.items() if k not in ("scope", "source_options")},
                "scope": config.get("scope") or [],
                "source_options": config.get("source_options") or {},
                "triggered_by": actor,
            }
            created = await self._post("/api/v1/pipelines/runs", body)
            return {"kind": "run", "id": str(created.get("id")), "connector": connector}
        if kind == "crawl":
            created = await self._post("/api/v1/repo-graph/crawls", {"repo": str(params["repo"]), "requested_by": actor})
            return {"kind": "crawl", "id": str(created.get("id")), "repo": params["repo"]}
        if kind == "approve_intent":
            if self._approve_intent is None:
                raise DependencyUnavailableError("the intent service is not available")
            intent_id = UUID(str(params["intent_id"]))
            await self._approve_intent(intent_id, IntentDecision(decision="approve", note="Approved from the Data Engineer digital worker."))
            return {"kind": "intent", "id": str(intent_id)}
        raise InvalidRequestError(f"the worker cannot {kind}")

    # ------------------------------------------------------------------ the ingestion service
    def _client(self) -> httpx.AsyncClient:
        if self._http is not None:
            return self._http()
        if not self._ingestion:
            raise DependencyUnavailableError("the ingestion service is not configured (ECH_INTENT_CATALOG_URL)")
        return httpx.AsyncClient(base_url=self._ingestion, timeout=30.0)

    async def _get(self, path: str) -> dict[str, Any]:
        async with self._client() as client:
            response = await client.get(path)
        response.raise_for_status()
        return response.json()

    async def _post(self, path: str, body: dict[str, Any]) -> dict[str, Any]:
        async with self._client() as client:
            response = await client.post(path, json=body)
        if response.status_code == 409:
            raise RuntimeError("it is already running")
        response.raise_for_status()
        return response.json()

    # ------------------------------------------------------------------ shift
    async def pause(self, worker: str, paused: bool, *, by: str = "you") -> WorkerSnapshot:
        self._known(worker)
        await self._repo.set_paused(worker, paused)
        await self._repo.append(worker, "shift", f"Paused by {by}." if paused else f"Back on shift, resumed by {by}.")
        return await self.snapshot(worker)

    async def loop(self, worker: str = "data_engineer") -> None:
        await self._repo.append(
            worker, "shift", f"On shift: sweeping runs, intents, the catalog and repositories every {self.tick_seconds} s. Anything that writes waits for approval."
        )
        while True:
            try:
                await self.sweep(worker)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001 - the next sweep tries again
                log.warning("worker.sweep_failed", worker=worker, error=str(exc)[:300])
            await asyncio.sleep(self.tick_seconds)
