"""Shapes Neo4j query results into ``GraphPayload`` objects for the UI."""

from __future__ import annotations

from collections import defaultdict
from typing import Any
from uuid import UUID

from ech_core.repositories import GraphRepository
from ech_core.schemas.graph import (
    EntityListItem,
    EntitySearchHit,
    GraphEdge,
    GraphNode,
    GraphPayload,
    GraphStats,
)


class _Builder:
    """Accumulates nodes/edges with de-duplication and weight aggregation."""

    def __init__(self) -> None:
        self.nodes: dict[str, GraphNode] = {}
        self.edges: dict[tuple[str, str, str], GraphEdge] = {}

    def node(self, nid: str, label: str, ntype: str, **props: Any) -> None:
        existing = self.nodes.get(nid)
        if existing is None:
            self.nodes[nid] = GraphNode(
                id=nid, label=label or nid, type=ntype, properties=dict(props)
            )
        else:
            existing.properties.update({k: v for k, v in props.items() if v is not None})

    def edge(
        self, src: str, dst: str, etype: str, *, weight: float | None = None, **props: Any
    ) -> None:
        key = (src, dst, etype)
        existing = self.edges.get(key)
        if existing is None:
            p = dict(props)
            if weight is not None:
                p["weight"] = round(weight, 3)
            self.edges[key] = GraphEdge(source=src, target=dst, type=etype, properties=p)
        elif weight is not None:
            existing.properties["weight"] = round(
                existing.properties.get("weight", 0.0) + weight, 3
            )

    def finish(
        self, *, center: str | None = None, chunk_entities: dict[str, list[str]] | None = None
    ) -> GraphPayload:
        degree: dict[str, int] = defaultdict(int)
        for e in self.edges.values():
            degree[e.source] += 1
            degree[e.target] += 1
        for nid, node in self.nodes.items():
            node.degree = degree.get(nid, 0)
        return GraphPayload(
            nodes=list(self.nodes.values()),
            edges=list(self.edges.values()),
            center_id=center,
            chunk_entities=chunk_entities,
        )


class GraphService:
    def __init__(self, repo: GraphRepository) -> None:
        self._repo = repo

    async def document_graph(self, document_id: UUID) -> GraphPayload | None:
        row = await self._repo.document_entity_graph(document_id)
        if row is None:
            return None
        b = _Builder()
        did = row["document_id"]
        b.node(
            did,
            row["title"],
            "Document",
            source_system=row.get("source_system"),
            uri=row.get("uri"),
            center=True,
        )
        for ent in row.get("entities") or []:
            b.node(ent["key"], ent["name"], ent["entity_type"])
        chunk_entities: dict[str, list[str]] = defaultdict(list)
        for m in row.get("mentions") or []:
            b.edge(did, m["key"], "MENTIONS", weight=float(m.get("confidence") or 1.0))
            chunk_entities[m["chunk_id"]].append(m["key"])
        for dep in row.get("deps") or []:
            b.edge(
                dep["source"], dep["target"], "DEPENDS_ON", weight=float(dep.get("weight") or 1.0)
            )
        self._add_links(b, did, row.get("links") or [])
        return b.finish(
            center=did, chunk_entities={k: sorted(set(v)) for k, v in chunk_entities.items()}
        )

    async def entity_graph(
        self, entity_key: str, *, max_documents: int = 25
    ) -> GraphPayload | None:
        row = await self._repo.entity_neighborhood(entity_key, max_documents=max_documents)
        if row is None:
            return None
        b = _Builder()
        b.node(row["key"], row["name"], row["entity_type"], center=True)
        for dep in row.get("deps") or []:
            b.node(dep["key"], dep["name"], dep["entity_type"])
            b.edge(
                dep["source"], dep["target"], "DEPENDS_ON", weight=float(dep.get("weight") or 1.0)
            )
        for doc in row.get("documents") or []:
            b.node(
                doc["document_id"],
                doc["title"],
                "Document",
                source_system=doc.get("source_system"),
                uri=doc.get("uri"),
            )
            b.edge(
                doc["document_id"],
                row["key"],
                "MENTIONS",
                weight=float(doc.get("mention_count") or 1),
            )
            for c in doc.get("contributors") or []:
                b.node(c["key"], c["name"], "Person")
                b.edge(doc["document_id"], c["key"], "CONTRIBUTED_BY", role=c.get("role"))
        return b.finish(center=row["key"])

    async def knowledge_map(self, *, max_documents: int = 150, max_entities: int = 80) -> GraphPayload:
        """The whole hub at a glance: documents, the entities most of them mention, references and dependencies."""
        row = await self._repo.knowledge_map(max_documents=max_documents)
        reach: dict[str, set[str]] = defaultdict(set)
        volume: dict[str, int] = defaultdict(int)
        for m in row["mentions"]:
            reach[m["key"]].add(m["document_id"])
            volume[m["key"]] += int(m.get("mentions") or 1)
        # The entities most documents share come first, then the most mentioned, so the map shows what ties the hub together.
        kept = set(sorted(reach, key=lambda k: (-len(reach[k]), -volume[k], k))[:max_entities])
        b = _Builder()
        for d in row["documents"]:
            b.node(d["id"], d["title"] or d["id"], "Document", source_system=d.get("source_system"), uri=d.get("uri"))
        for m in row["mentions"]:
            if m["key"] in kept:
                b.node(m["key"], m["name"], m["entity_type"], documents=len(reach[m["key"]]))
                b.edge(m["document_id"], m["key"], "MENTIONS", weight=float(m.get("mentions") or 1))
        for r in row["refs"]:
            b.node(r["target"], r.get("title") or r["target"], "Document", source_system=r.get("source_system"), stub=bool(r.get("stub")))
            b.edge(r["source"], r["target"], "REFERENCES", kind=r.get("kind"))
        for c in row["contributors"]:
            b.node(c["key"], c["name"], "Person")
            b.edge(c["source"], c["key"], "CONTRIBUTED_BY", role=c.get("role"))
        for dep in row["deps"]:
            if dep["source"] in kept and dep["target"] in kept:
                b.edge(dep["source"], dep["target"], "DEPENDS_ON", weight=float(dep.get("weight") or 1.0))
        return b.finish()

    async def lineage(self, document_id: UUID, *, depth: int = 3) -> GraphPayload | None:
        row = await self._repo.lineage(document_id, depth=depth)
        if row is None:
            return None
        b = _Builder()
        for d in row.get("documents") or []:
            b.node(
                d["id"],
                d["title"] or d["id"],
                "Document",
                source_system=d.get("source_system"),
                uri=d.get("uri"),
                stub=bool(d.get("stub")),
                version=d.get("version"),
            )
        for r in row.get("references") or []:
            b.edge(r["source"], r["target"], "REFERENCES", kind=r.get("kind"))
        for c in row.get("contributors") or []:
            b.node(c["target"], c["name"], "Person")
            b.edge(c["source"], c["target"], "CONTRIBUTED_BY", role=c.get("role"))
        return b.finish(center=str(document_id))

    async def search_entities(
        self, query: str, *, entity_type: str | None, limit: int
    ) -> list[EntitySearchHit]:
        rows = await self._repo.search_entities(query, entity_type=entity_type, limit=limit)
        return [
            EntitySearchHit(
                key=r["key"],
                name=r["name"],
                entity_type=r["entity_type"],
                score=float(r["score"]) if r.get("score") is not None else None,
                mention_count=int(r.get("mention_count") or 0),
            )
            for r in rows
        ]

    async def list_entities(
        self, *, entity_type: str | None, limit: int, offset: int
    ) -> list[EntityListItem]:
        rows = await self._repo.list_entities(entity_type=entity_type, limit=limit, offset=offset)
        return [
            EntityListItem(
                key=r["key"],
                name=r["name"],
                entity_type=r["entity_type"],
                mention_count=int(r.get("mention_count") or 0),
                document_count=int(r.get("document_count") or 0),
            )
            for r in rows
        ]

    async def stats(self) -> GraphStats:
        return GraphStats(**await self._repo.stats())

    @staticmethod
    def _add_links(b: _Builder, did: str, links: list[dict[str, Any]]) -> None:
        for link in links:
            if link["type"] == "REFERENCES":
                b.node(link["target_id"], link["name"], "Document", stub=bool(link.get("stub")))
                b.edge(did, link["target_id"], "REFERENCES", kind=link.get("kind"))
            elif link["type"] == "CONTRIBUTED_BY":
                b.node(link["target_id"], link["name"], "Person")
                b.edge(did, link["target_id"], "CONTRIBUTED_BY", role=link.get("role"))
