"""Builds the Semantic Catalog from a snapshot of the semantic layer and the glossary.

Everything here is a projection over rows the connectors ingested and the glossary review accepted.
The only vocabulary of its own is the one that recognises hierarchy levels in column names
(calendar, geography, product, parent-child keys), because the platforms do not declare hierarchies.
"""

from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from ech_core.repositories.catalog_repository import CatalogRepository, CatalogSnapshot
from ech_core.schemas.catalog import (
    OBJECT_TYPES,
    SHARED_LINE,
    SHARED_LINE_NAME,
    UNASSIGNED_KEY,
    UNASSIGNED_NAME,
    CatalogCounts,
    CatalogDomain,
    CatalogDomainModel,
    CatalogDomainNode,
    CatalogLine,
    CatalogLineDomain,
    CatalogObject,
    CatalogSort,
    CatalogSource,
    ObjectType,
    QualityCheck,
    SemanticCatalog,
)
from ech_core.schemas.common import Page
from ech_core.semantic.naming import business_name

COUNT_FIELD: dict[str, str] = {
    "entity": "entities",
    "dimension": "dimensions",
    "measure": "measures",
    "metric": "metrics",
    "relationship": "relationships",
    "hierarchy": "hierarchies",
}
TYPE_ORDER = {t: i for i, t in enumerate(OBJECT_TYPES)}
ENTITY_SUBTYPE = {
    "fact": "fact",
    "dimension": "dimension",
    "reference": "reference",
    "bridge": "bridge",
    "metric": "metric view",
    "unknown": "unclassified",
}
RELATIONSHIP_SUBTYPE = {
    "foreign_key": "foreign key",
    "join_declared": "declared join",
    "join_inferred": "inferred join",
    "lineage_upstream": "lineage",
    "lineage_downstream": "lineage",
    "metric_source": "metric source",
}
JOIN_KINDS = frozenset({"foreign_key", "join_declared", "join_inferred"})
GOVERNED = frozenset({"declared", "curated"})
CONFIDENT = 0.8

HIERARCHY_NOTE = (
    "Snowflake and Databricks do not declare hierarchies, so they are inferred from column patterns "
    "on one dataset: calendar (year, quarter, month, week, day), geography (country, state, county, "
    "city, postal code), product (line of business, family, product, plan, coverage) and "
    "parent-child keys. Two or more levels make a hierarchy; on facts a calendar needs two levels "
    "above day that share a prefix (calendar_year with calendar_month), and time columns never "
    "count as geography or product levels."
)

# A column belongs to a level when one of its name tokens is in the level's vocabulary.
LEVELS: dict[str, list[tuple[str, frozenset[str]]]] = {
    "calendar": [
        ("Year", frozenset({"year", "yr", "fy", "fiscalyear"})),
        ("Quarter", frozenset({"quarter", "qtr"})),
        ("Month", frozenset({"month", "mth", "mon"})),
        ("Week", frozenset({"week", "wk"})),
        ("Day", frozenset({"day", "date", "dt"})),
    ],
    "geography": [
        ("Country", frozenset({"country", "nation"})),
        ("State", frozenset({"state", "province"})),
        ("County", frozenset({"county", "district"})),
        ("City", frozenset({"city", "town"})),
        ("Postal code", frozenset({"zip", "zipcode", "postal", "postcode"})),
    ],
    "product": [
        ("Line of business", frozenset({"lob"})),
        ("Product family", frozenset({"family", "category"})),
        ("Product", frozenset({"product"})),
        ("Plan", frozenset({"plan"})),
        ("Coverage", frozenset({"coverage", "rider"})),
    ],
}
_CALENDAR_TOKENS: frozenset[str] = frozenset().union(*(vocab for _, vocab in LEVELS["calendar"]))
_TOKENS = re.compile(r"[^a-z0-9]+")
_PARENT = re.compile(r"^(?:parent_(?P<a>.+)|(?P<b>.+)_parent)$")


# --------------------------------------------------------------------------- small helpers
def _tokens(name: str) -> set[str]:
    return {t for t in _TOKENS.split(name.lower().replace("line_of_business", "lob")) if t}


def _as_list(value: Any) -> list[str]:
    return [str(v) for v in value] if isinstance(value, list) else []


def _label(row: dict[str, Any], key: str = "name") -> str:
    return (row.get("display_name") or "").strip() or business_name(str(row.get(key) or ""))


def _text(*values: Any) -> str:
    return next((str(v).strip() for v in values if v and str(v).strip()), "")


def _score(checks: list[tuple[str, bool]]) -> tuple[int, list[QualityCheck]]:
    passed = sum(1 for _, ok in checks if ok)
    score = round(100 * passed / len(checks)) if checks else 0
    return score, [QualityCheck(name=name, ok=ok) for name, ok in checks]


def _when(asset: dict[str, Any] | None) -> datetime | None:
    if not asset:
        return None
    return asset.get("updated_at") or asset.get("synced_at") or asset.get("source_updated_at")


# --------------------------------------------------------------------------- hierarchies
def _calendar_on_fact(names: list[str]) -> list[tuple[str, str]]:
    """A calendar on a fact only when its level columns share a prefix: calendar_year with
    calendar_month, or bare year with month; policy_year next to transaction_date is not one."""
    groups: dict[frozenset[str], list[tuple[str, str]]] = {}
    for level, vocab in LEVELS["calendar"]:
        for n in names:
            toks = _tokens(n)
            if toks & vocab:
                groups.setdefault(frozenset(toks - vocab), []).append((level, n))
    best = max(groups.values(), key=len, default=[])
    first: dict[str, str] = {}
    for level, n in best:
        first.setdefault(level, n)
    found = [(level, first[level]) for level, _ in LEVELS["calendar"] if level in first]
    return found if sum(1 for level, _ in found if level != "Day") >= 2 else []


def infer_hierarchies(asset: dict[str, Any], fields: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Calendar, geography, product and parent-child hierarchies read from one dataset's columns.

    Each result carries ``family`` and ``levels``: ``[(level label, column name), ...]`` top-down.
    """
    out: list[dict[str, Any]] = []
    names = [str(f["name"]) for f in fields]
    # Time columns and calendar-named columns only ever belong to the calendar family:
    # coverage_month is a month, not a coverage; plan_year is a year, not a plan.
    plain = [str(f["name"]) for f in fields if f.get("role") != "time" and not (_tokens(str(f["name"])) & _CALENDAR_TOKENS)]
    for family, levels in LEVELS.items():
        if family == "calendar" and asset.get("kind") not in ("dimension", "reference"):
            found = _calendar_on_fact(names)
        else:
            pool = names if family == "calendar" else plain
            found = []
            for level, vocab in levels:
                column = next((n for n in pool if _tokens(n) & vocab), None)
                if column:
                    found.append((level, column))
        if len(found) >= 2:
            out.append({"family": family, "levels": found})
    lower = {n.lower(): n for n in names}
    for name in names:
        m = _PARENT.match(name.lower())
        if not m:
            continue
        base = m.group("a") or m.group("b")
        candidates = (base, f"{base}_id", f"{base}_key", f"{base}_sk", "id", "key")
        child = next((lower[c] for c in candidates if c in lower), None)
        if child is None and base in ("id", "key", "sk", "node"):
            child = next((str(f["name"]) for f in fields if f.get("is_primary_key")), None)
        if child and child.lower() != name.lower():
            out.append({"family": "parent-child", "levels": [("Parent", name), ("Child", child)]})
            break
    return out


# --------------------------------------------------------------------------- the projection
@dataclass
class BuiltCatalog:
    objects: list[CatalogObject]
    catalog: SemanticCatalog
    top_of: dict[str, str] = field(default_factory=dict)


def build_catalog(snap: CatalogSnapshot, *, now: datetime | None = None) -> BuiltCatalog:
    now = now or datetime.now(tz=UTC)
    domains = {d["key"]: d for d in snap.domains}
    top_of = {k: (d.get("parent_key") or k) for k, d in domains.items()}
    names = {k: d["name"] for k, d in domains.items()}
    assets = {a["id"]: a for a in snap.assets}
    fields_of: dict[UUID, list[dict[str, Any]]] = {}
    for f in snap.fields:
        fields_of.setdefault(f["asset_id"], []).append(f)
    metrics_of: dict[UUID, list[dict[str, Any]]] = {}
    for m in snap.metrics:
        metrics_of.setdefault(m["asset_id"], []).append(m)
    metric_asset: dict[UUID, UUID] = {m["id"]: m["asset_id"] for m in snap.metrics}
    rel_count: Counter[UUID] = Counter()
    for r in snap.relationships:
        rel_count[r["source_asset_id"]] += 1
        if r.get("target_asset_id"):
            rel_count[r["target_asset_id"]] += 1
    link: dict[tuple[str, UUID], dict[str, Any]] = {}
    for row in snap.term_links:  # ordered most confident first
        link.setdefault((row["target_type"], row["target_id"]), row)

    # Where a dataset lives: its own domain, its term's domain, or what most of its columns say.
    placement: dict[UUID, tuple[str | None, str]] = {}
    for aid, a in assets.items():
        key, source = a.get("domain_key"), "dataset"
        if not key:
            asset_link = link.get(("asset", aid))
            if asset_link and asset_link.get("domain_key"):
                key, source = asset_link["domain_key"], "term"
        if not key:
            votes: Counter[str] = Counter()
            for kind, rows in (("field", fields_of.get(aid, [])), ("metric", metrics_of.get(aid, []))):
                for r in rows:
                    lk = link.get((kind, r["id"]))
                    if lk and lk.get("domain_key"):
                        votes[top_of.get(lk["domain_key"], lk["domain_key"])] += 1
            if votes:
                key, source = votes.most_common(1)[0][0], "columns"
        placement[aid] = (key, source if key else "none")

    lines_of: dict[Any, tuple[list[str], str]] = {}
    for row in snap.lines:
        keys, note = lines_of.get(row["asset_id"], ([], ""))
        lines_of[row["asset_id"]] = ([*keys, row["line_key"]], note or str(row.get("evidence") or ""))

    def base(a: dict[str, Any]) -> dict[str, Any]:
        lines, note = lines_of.get(a["id"], ([], ""))
        return {
            "lines": lines,
            "lines_note": note,
            "model": f"{a['database_name']}.{a['schema_name']}",
            "model_label": business_name(str(a["schema_name"])),
            "platform": a["platform"],
            "asset_id": a["id"],
            "asset_name": _label(a),
            "owner": _text(a.get("owner")) or None,
            "updated_at": _when(a),
        }

    def placed(key: str | None, source: str) -> dict[str, Any]:
        return {
            "domain_key": key,
            "domain_name": names.get(key, key) if key else None,
            "domain_source": source if key else "none",
        }

    def inherited(own: dict[str, Any] | None, key: str | None) -> tuple[str | None, str]:
        if own and own.get("domain_key"):
            return own["domain_key"], "term"
        return key, "dataset"

    objects: list[CatalogObject] = []
    for aid, a in assets.items():
        cols = fields_of.get(aid, [])
        mets = metrics_of.get(aid, [])
        asset_link = link.get(("asset", aid))
        key, source = placement[aid]
        described = bool(_text(a.get("description"), a.get("summary")))
        checks = [
            ("described", described),
            ("business name", a.get("name_source") != "derived" or asset_link is not None),
            ("owner", bool(_text(a.get("owner")))),
            ("keys", any(f.get("is_primary_key") or f.get("role") == "identifier" for f in cols)),
            ("connected", rel_count[aid] > 0),
            ("classified", a.get("kind") not in (None, "", "unknown")),
            ("term linked", asset_link is not None),
            ("domain", key is not None),
        ]
        score, outcome = _score(checks)
        kind_label = str(a.get("asset_type") or "table").replace("_", " ")
        objects.append(
            CatalogObject(
                id=f"entity:{aid}",
                type="entity",
                subtype=ENTITY_SUBTYPE.get(str(a.get("kind")), str(a.get("kind") or "")),
                name=_label(a),
                technical_name=a["fqn"],
                description=_text(a.get("description"), a.get("summary")),
                **placed(key, source),
                **base(a),
                quality=score,
                checks=outcome,
                term=asset_link["term_name"] if asset_link else None,
                detail=f"{kind_label} · {len(cols)} columns" + (f" · {len(mets)} metrics" if mets else ""),
            )
        )
        for f in cols:
            role = f.get("role")
            if role not in ("dimension", "time", "measure"):
                continue
            f_link = link.get(("field", f["id"]))
            f_key, f_source = inherited(f_link, key)
            checks = [
                ("described", bool(_text(f.get("description")))),
                ("business name", bool(_text(f.get("display_name"))) or f_link is not None),
                ("term linked", f_link is not None),
                ("typed", bool(_text(f.get("data_type")))),
                ("role confident", float(f.get("role_confidence") or 0) >= CONFIDENT),
                ("domain", f_key is not None),
            ]
            score, outcome = _score(checks)
            is_measure = role == "measure"
            if is_measure:
                subtype = _text(f.get("aggregation")) or "additive"
            else:
                subtype = "time" if role == "time" else "categorical"
            objects.append(
                CatalogObject(
                    id=f"{'measure' if is_measure else 'dimension'}:{f['id']}",
                    type="measure" if is_measure else "dimension",
                    subtype=subtype,
                    name=_label(f),
                    technical_name=f"{a['fqn']}.{f['name']}",
                    description=_text(f.get("description")),
                    **placed(f_key, f_source),
                    **base(a),
                    quality=score,
                    checks=outcome,
                    term=f_link["term_name"] if f_link else None,
                    detail=_text(f.get("data_type")),
                )
            )
        for m in mets:
            m_link = link.get(("metric", m["id"]))
            m_key, m_source = inherited(m_link, key)
            dims = _as_list(m.get("dimensions"))
            checks = [
                ("described", bool(_text(m.get("description")))),
                ("expression", bool(_text(m.get("expression")))),
                ("governed", m.get("source") in GOVERNED),
                ("term linked", m_link is not None),
                ("dimensions listed", bool(dims)),
                ("domain", m_key is not None),
            ]
            score, outcome = _score(checks)
            objects.append(
                CatalogObject(
                    id=f"metric:{m['id']}",
                    type="metric",
                    subtype=str(m.get("source") or "inferred"),
                    name=_label(m),
                    technical_name=f"{a['fqn']}.{m['name']}",
                    description=_text(m.get("description")),
                    **placed(m_key, m_source),
                    **base(a),
                    quality=score,
                    checks=outcome,
                    term=m_link["term_name"] if m_link else None,
                    detail=_text(m.get("expression")),
                )
            )
        for h in infer_hierarchies(a, cols):
            family, levels = h["family"], h["levels"]
            checks = [
                ("three or more levels", len(levels) >= 3),
                ("dataset described", described),
                ("domain", key is not None),
            ]
            score, outcome = _score(checks)
            objects.append(
                CatalogObject(
                    id=f"hierarchy:{aid}:{family}",
                    type="hierarchy",
                    subtype=family,
                    name=f"{family.capitalize()} hierarchy on {_label(a)}",
                    technical_name=",".join(c for _, c in levels),
                    description=f"{len(levels)} levels inferred from column names",
                    **placed(key, source),
                    **base(a),
                    quality=score,
                    checks=outcome,
                    term=None,
                    detail=" › ".join(f"{level}: {business_name(c)}" for level, c in levels),
                )
            )

    for r in snap.relationships:
        src = assets.get(r["source_asset_id"])
        if src is None:
            continue
        tgt = assets.get(r.get("target_asset_id"))
        key, source = placement[src["id"]]
        if key is None and tgt is not None:
            key, source = placement[tgt["id"]]
        kind = str(r.get("kind") or "")
        s_cols, t_cols = _as_list(r.get("source_columns")), _as_list(r.get("target_columns"))
        evidence = _text(r.get("evidence"))
        if kind in JOIN_KINDS and s_cols:
            pairs = zip(s_cols, t_cols or [""] * len(s_cols), strict=False)
            detail = ", ".join(f"{s} = {t}" if t else s for s, t in pairs)
        else:
            detail = evidence or RELATIONSHIP_SUBTYPE.get(kind, kind)
        checks = [
            ("confident", float(r.get("confidence") or 0) >= CONFIDENT),
            ("target in catalog", tgt is not None),
            ("join columns", bool(s_cols)) if kind in JOIN_KINDS else ("evidence", bool(evidence)),
            ("domain", key is not None),
        ]
        score, outcome = _score(checks)
        target_label = _label(tgt) if tgt else business_name(str(r["target_fqn"]).rsplit(".", 1)[-1])
        objects.append(
            CatalogObject(
                id=f"relationship:{r['id']}",
                type="relationship",
                subtype=RELATIONSHIP_SUBTYPE.get(kind, kind.replace("_", " ")),
                name=f"{_label(src)} → {target_label}",
                technical_name=f"{src['fqn']} → {r['target_fqn']}",
                description=evidence,
                **placed(key, source),
                **base(src),
                quality=score,
                checks=outcome,
                term=None,
                detail=detail,
            )
        )

    for k in snap.kpis:
        bound = assets.get(metric_asset.get(k["metric_id"])) if k.get("metric_id") else None
        key = k.get("domain_key")
        checks = [
            ("defined", bool(_text(k.get("definition")))),
            ("formula", bool(_text(k.get("formula")))),
            ("metric bound", k.get("metric_id") is not None),
            ("owner", bool(_text(k.get("owner")))),
            ("target", k.get("target_value") is not None),
            ("domain", key is not None),
        ]
        score, outcome = _score(checks)
        where = (
            base(bound)
            if bound
            else {
                "model": "glossary",
                "model_label": "Business Glossary",
                "platform": "hub",
                "asset_id": None,
                "asset_name": None,
                "owner": None,
                "updated_at": None,
            }
        )
        where["owner"] = _text(k.get("owner")) or where["owner"]
        where["updated_at"] = k.get("updated_at") or where["updated_at"]
        period = f"{k.get('period') or ''} · {k.get('unit') or ''}".strip(" ·")
        objects.append(
            CatalogObject(
                id=f"metric:kpi:{k['id']}",
                type="metric",
                subtype="kpi",
                name=str(k["name"]),
                technical_name=str(k["key"]),
                description=_text(k.get("definition")),
                **placed(key, "kpi"),
                **where,
                quality=score,
                checks=outcome,
                term=k.get("term_name"),
                detail=_text(k.get("formula")) or period,
            )
        )

    objects.sort(key=lambda o: (TYPE_ORDER[o.type], o.name.lower(), o.technical_name.lower()))
    qualities = [o.quality for o in objects]
    return BuiltCatalog(
        objects=objects,
        catalog=SemanticCatalog(
            domains=_domain_tree(snap.domains, objects, top_of),
            counts=_counts(objects),
            placed=sum(1 for o in objects if o.domain_key),
            entities_placed=sum(1 for o in objects if o.type == "entity" and o.domain_key),
            quality=round(sum(qualities) / len(qualities)) if qualities else None,
            models=sorted({o.model for o in objects if o.model != "glossary"}),
            sources=_sources(objects),
            domain_models=_domain_models(objects),
            lines=_lines(objects, snap.line_values, top_of),
            owners=sorted({o.owner for o in objects if o.owner}),
            hierarchy_note=HIERARCHY_NOTE,
            generated_at=now,
        ),
        top_of=top_of,
    )


def _counts(objects: list[CatalogObject]) -> CatalogCounts:
    counts = CatalogCounts(total=len(objects))
    for o in objects:
        attr = COUNT_FIELD[o.type]
        setattr(counts, attr, getattr(counts, attr) + 1)
    return counts


def _tally(objects: list[CatalogObject]) -> tuple[CatalogCounts, int | None]:
    return _counts(objects), round(sum(o.quality for o in objects) / len(objects)) if objects else None


def _sources(objects: list[CatalogObject]) -> list[CatalogSource]:
    """Objects per model, for the tree grouped by source; glossary KPIs bound to no dataset come last."""
    by_model: dict[str, list[CatalogObject]] = {}
    for o in objects:
        by_model.setdefault(o.model, []).append(o)
    out: list[CatalogSource] = []
    for model, rows in by_model.items():
        counts, quality = _tally(rows)
        database, _, schema = ("", "", "") if model == "glossary" else model.partition(".")
        first = rows[0]
        out.append(
            CatalogSource(
                model=model, model_label=first.model_label, platform=first.platform, database=database,
                schema_name=schema, counts=counts, quality=quality,
            )
        )
    out.sort(key=lambda s: (s.model == "glossary", s.database, s.schema_name))
    return out


def _domain_models(objects: list[CatalogObject]) -> list[CatalogDomainModel]:
    """Objects per (domain, model), placed directly: a parent domain's sub-domains are listed on their own."""
    pairs: dict[tuple[str, str], list[CatalogObject]] = {}
    for o in objects:
        pairs.setdefault((o.domain_key or UNASSIGNED_KEY, o.model), []).append(o)
    out: list[CatalogDomainModel] = []
    for (domain_key, model), rows in sorted(pairs.items()):
        counts, quality = _tally(rows)
        out.append(CatalogDomainModel(domain_key=domain_key, model=model, counts=counts, quality=quality))
    return out


SHARED_LINE_NOTE = "Datasets no tag, pipeline default, column or join ties to one line: party, reference and platform data."


def _lines(objects: list[CatalogObject], values: list[dict[str, Any]], top_of: dict[str, str]) -> list[CatalogLine]:
    """Every value of the Line of Business term, then what is shared across lines, with counts per top-level domain."""
    buckets: dict[str, list[CatalogObject]] = {v["key"]: [] for v in values}
    shared: list[CatalogObject] = []
    for o in objects:
        if not o.lines:
            shared.append(o)
        for key in o.lines:
            buckets.setdefault(key, []).append(o)
    about = {v["key"]: (v["name"], v.get("description") or "") for v in values}
    about[SHARED_LINE] = (SHARED_LINE_NAME, SHARED_LINE_NOTE)
    groups = [*buckets.items(), *([(SHARED_LINE, shared)] if shared else [])]
    out: list[CatalogLine] = []
    for key, rows in groups:
        counts, quality = _tally(rows)
        by_domain: dict[str, list[CatalogObject]] = {}
        for o in rows:
            top = top_of.get(o.domain_key, o.domain_key) if o.domain_key else UNASSIGNED_KEY
            by_domain.setdefault(top, []).append(o)
        name, description = about.get(key, (key, ""))
        domains = [CatalogLineDomain(domain_key=k, counts=_counts(v)) for k, v in sorted(by_domain.items())]
        out.append(CatalogLine(key=key, name=name, description=description, counts=counts, quality=quality, domains=domains))
    return out


def _domain_tree(
    domains: list[dict[str, Any]], objects: list[CatalogObject], top_of: dict[str, str]
) -> list[CatalogDomainNode]:
    """Every glossary domain with the objects placed in it or its sub-domains, plus Unassigned."""
    nodes: dict[str, CatalogDomain] = {
        d["key"]: CatalogDomain(
            key=d["key"],
            name=d["name"],
            parent_key=d.get("parent_key"),
            description=d.get("description") or "",
            standard=d.get("standard") or "hub",
            sort_order=int(d.get("sort_order") or 0),
        )
        for d in domains
    }
    nodes[UNASSIGNED_KEY] = CatalogDomain(
        key=UNASSIGNED_KEY,
        name=UNASSIGNED_NAME,
        sort_order=10_000,
        description="Objects that no accepted glossary term places in a domain yet.",
    )
    quality: dict[str, list[int]] = {}
    for o in objects:
        keys = [o.domain_key or UNASSIGNED_KEY]
        top = top_of.get(keys[0], keys[0])
        if top != keys[0]:
            keys.append(top)
        for k in keys:
            node = nodes.get(k)
            if node is None:
                continue
            attr = COUNT_FIELD[o.type]
            setattr(node.counts, attr, getattr(node.counts, attr) + 1)
            node.counts.total += 1
            quality.setdefault(k, []).append(o.quality)
    for k, scores in quality.items():
        nodes[k].quality = round(sum(scores) / len(scores))
    unassigned = nodes.pop(UNASSIGNED_KEY)
    roots = [
        CatalogDomainNode(**n.model_dump(), children=[])
        for n in nodes.values()
        if not n.parent_key or n.parent_key not in nodes
    ]
    by_key = {r.key: r for r in roots}
    for n in nodes.values():
        if n.parent_key and n.parent_key in by_key:
            by_key[n.parent_key].children.append(n)
    for r in roots:
        r.children.sort(key=lambda c: (c.sort_order, c.name))
    roots.sort(key=lambda r: (r.sort_order, r.name))
    if unassigned.counts.total:
        roots.append(CatalogDomainNode(**unassigned.model_dump(), children=[]))
    return roots


def filter_objects(
    built: BuiltCatalog,
    *,
    domain: str | None = None,
    type: ObjectType | None = None,
    model: str | None = None,
    owner: str | None = None,
    search: str | None = None,
    min_quality: int = 0,
    direct: bool = False,
    database: str | None = None,
    lob: str | None = None,
) -> list[CatalogObject]:
    """Objects of the catalog narrowed by domain (sub-domains included unless direct), type, model or database, owner, text."""
    tokens = [t for t in re.split(r"[\s,;/]+", (search or "").strip().lower()) if t]
    out: list[CatalogObject] = []
    for o in built.objects:
        if domain:
            if domain == UNASSIGNED_KEY:
                if o.domain_key:
                    continue
            elif o.domain_key != domain and (direct or built.top_of.get(o.domain_key or "") != domain):
                continue
        if type and o.type != type:
            continue
        if model and o.model != model:
            continue
        if database and not o.model.startswith(f"{database}."):
            continue
        if lob and (bool(o.lines) if lob == SHARED_LINE else lob not in o.lines):
            continue
        if owner and (o.owner or "") != owner:
            continue
        if o.quality < min_quality:
            continue
        if tokens:
            parts = [
                o.name,
                o.technical_name,
                o.description,
                o.term or "",
                o.detail,
                o.asset_name or "",
                o.model,
                o.subtype,
                o.domain_name or "",
            ]
            hay = " ".join(parts).lower()
            if not all(t in hay for t in tokens):
                continue
        out.append(o)
    return out


_LAST = datetime.min.replace(tzinfo=UTC)


def sort_objects(objects: list[CatalogObject], sort: CatalogSort = "type", descending: bool = False) -> list[CatalogObject]:
    """Order a filtered list for one page; the name breaks ties, and unplaced or ownerless objects sort last."""

    def key(o: CatalogObject) -> tuple[Any, ...]:
        name = (o.name.lower(), o.technical_name.lower())
        if sort == "name":
            return name
        if sort == "domain":
            return (o.domain_name is None, (o.domain_name or "").lower(), *name)
        if sort == "model":
            return (o.model.lower(), *name)
        if sort == "owner":
            return (o.owner is None, (o.owner or "").lower(), *name)
        if sort == "quality":
            return (o.quality, *name)
        if sort == "updated":
            return (o.updated_at or _LAST, *name)
        return (TYPE_ORDER[o.type], *name)

    return sorted(objects, key=key, reverse=descending)


class CatalogService:
    def __init__(self, repo: CatalogRepository) -> None:
        self._repo = repo

    async def catalog(self) -> SemanticCatalog:
        return build_catalog(await self._repo.snapshot()).catalog

    async def objects(
        self,
        *,
        domain: str | None,
        type: ObjectType | None,
        model: str | None,
        owner: str | None,
        search: str | None,
        min_quality: int,
        limit: int,
        offset: int,
        direct: bool = False,
        database: str | None = None,
        lob: str | None = None,
        sort: CatalogSort = "type",
        descending: bool = False,
    ) -> Page[CatalogObject]:
        built = build_catalog(await self._repo.snapshot())
        rows = filter_objects(
            built,
            domain=domain,
            type=type,
            model=model,
            owner=owner,
            search=search,
            min_quality=min_quality,
            direct=direct,
            database=database,
            lob=lob,
        )
        rows = sort_objects(rows, sort, descending)
        return Page(items=rows[offset : offset + limit], total=len(rows), limit=limit, offset=offset)
