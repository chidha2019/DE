"""Dashboard statistics aggregated from Postgres, Neo4j and the in-memory latency buffer."""

from __future__ import annotations

import asyncio
import json
from collections.abc import Mapping
from datetime import UTC, datetime
from typing import Any

from ech_core.config import KPI_TARGET_DEFAULTS, Settings
from ech_core.embeddings.base import EmbeddingProvider
from ech_core.logging import get_logger
from ech_core.observability import LatencyRecorder
from ech_core.repositories import (
    AuditRepository,
    ChunkRepository,
    DocumentRepository,
    EmbeddingRepository,
    GenieRepository,
    GraphRepository,
    IngestionRunRepository,
    PlatformRepository,
    SemanticRepository,
)
from ech_core.repositories.intent_repository import IntentRepository
from ech_core.schemas.genie import GenieStatus
from ech_core.schemas.stats import (
    AnalystReport,
    ArchitectureReport,
    ConnectorFreshness,
    EngineeringKpis,
    ErrorBudget,
    Integration,
    KpiGroup,
    KpiStatus,
    KpiTarget,
    KpiValue,
    LatencySeries,
    OverviewStats,
    PlatformReport,
    PlatformSummary,
    QualityReport,
    RequestRollup,
    ReviewItem,
    RunFailure,
    SharedDimension,
    TableSize,
)

log = get_logger(__name__)


class StatsService:
    def __init__(
        self,
        *,
        documents: DocumentRepository,
        chunks: ChunkRepository,
        embeddings: EmbeddingRepository,
        runs: IngestionRunRepository,
        audit: AuditRepository,
        graph: GraphRepository,
        embedder: EmbeddingProvider,
        latency: LatencyRecorder,
        semantic: SemanticRepository | None = None,
        platform: PlatformRepository | None = None,
        genie_log: GenieRepository | None = None,
        intents: IntentRepository | None = None,
        kpi_targets: Mapping[str, float] | None = None,
    ) -> None:
        self._semantic = semantic
        self._platform = platform
        self._genie_log = genie_log
        self._intents = intents
        self._targets: dict[str, float] = {**KPI_TARGET_DEFAULTS, **(kpi_targets or {})}
        self._documents = documents
        self._chunks = chunks
        self._embeddings = embeddings
        self._runs = runs
        self._audit = audit
        self._graph = graph
        self._embedder = embedder
        self._latency = latency

    async def engineering(self, *, days: int = 7) -> EngineeringKpis:
        """The Data Engineer scorecard; every KPI carries its target and verdict."""
        runs, connectors, graph = await asyncio.gather(
            self._runs.kpi_rollup(days=days),
            self._runs.connector_freshness(days=days),
            self._documents.graph_sync_breakdown(),
        )
        catalog = await self._semantic.coverage_kpis() if self._semantic is not None else {}
        now = datetime.now(tz=UTC)

        finished = runs.get("completed", 0) + runs.get("failed", 0) + runs.get("cancelled", 0)
        seen = runs.get("documents_seen", 0)
        busy_min = float(runs.get("busy_seconds") or 0) / 60
        avg_s = runs.get("avg_duration_s")
        pipelines = [
            _kpi(
                "run_success_rate",
                "Run success rate",
                _pct(runs.get("completed", 0), finished),
                unit="percent",
                target=self._targets["run_success_rate"],
                detail=f"{runs.get('completed', 0)} of {finished} finished runs completed",
            ),
            _kpi(
                "runs_failed",
                "Failed runs",
                float(runs.get("failed", 0)) if finished else None,
                target=self._targets["runs_failed"],
                direction="lower",
                detail=f"{runs.get('cancelled', 0)} cancelled",
            ),
            _kpi(
                "doc_failure_rate",
                "Document failure rate",
                _pct(runs.get("documents_failed", 0), seen),
                unit="percent",
                target=self._targets["doc_failure_rate"],
                direction="lower",
                detail=f"{runs.get('documents_failed', 0)} of {seen} documents seen failed",
            ),
            _kpi(
                "documents_upserted",
                "Documents upserted",
                float(runs.get("documents_upserted", 0)) if finished else None,
                detail="new or changed documents written in the window",
            ),
            _kpi(
                "avg_run_duration",
                "Average run duration",
                round(float(avg_s), 1) if avg_s is not None else None,
                unit="seconds",
                detail="completed runs only",
            ),
            _kpi(
                "throughput",
                "Throughput",
                round(runs.get("documents_upserted", 0) / busy_min, 1) if busy_min > 0 else None,
                unit="per_minute",
                detail="documents upserted per busy minute",
            ),
        ]

        total_docs = sum(graph.values())
        graph_kpis = [
            _kpi(
                "graph_sync_rate",
                "Graph sync rate",
                _pct(graph.get("synced", 0), total_docs),
                unit="percent",
                target=self._targets["graph_sync_rate"],
                detail=f"{graph.get('synced', 0)} of {total_docs} documents in Neo4j",
            ),
            _kpi(
                "graph_failed",
                "Graph sync failures",
                float(graph.get("failed", 0)) if total_docs else None,
                target=self._targets["graph_failed"],
                direction="lower",
                detail="documents whose last Neo4j write failed",
            ),
            _kpi(
                "graph_pending",
                "Graph sync pending",
                float(graph.get("pending", 0)) if total_docs else None,
                target=self._targets["graph_pending"],
                direction="lower",
                detail="documents waiting for reconciliation",
            ),
        ]

        assets = catalog.get("assets", 0)
        joins_total = catalog.get("joins_declared", 0) + catalog.get("joins_inferred", 0)
        catalog_kpis = [
            _kpi(
                "assets_described_pct",
                "Assets described",
                _pct(catalog.get("described", 0), assets),
                unit="percent",
                target=self._targets["assets_described_pct"],
                detail=f"{catalog.get('described', 0)} of {assets} assets have a description",
            ),
            _kpi(
                "assets_owned_pct",
                "Assets owned",
                _pct(catalog.get("owned", 0), assets),
                unit="percent",
                target=self._targets["assets_owned_pct"],
                detail=f"{catalog.get('owned', 0)} of {assets} assets have an owner",
            ),
            _kpi(
                "facts_keyed_pct",
                "Facts with a primary key",
                _pct(catalog.get("keyed_facts", 0), catalog.get("facts", 0)),
                unit="percent",
                target=self._targets["facts_keyed_pct"],
                detail=f"{catalog.get('keyed_facts', 0)} of {catalog.get('facts', 0)} fact tables",
            ),
            _kpi(
                "assets_connected_pct",
                "Assets connected",
                _pct(catalog.get("connected", 0), assets),
                unit="percent",
                target=self._targets["assets_connected_pct"],
                detail="assets with at least one key, join or lineage edge",
            ),
            _kpi(
                "joins_declared_pct",
                "Joins declared",
                _pct(catalog.get("joins_declared", 0), joins_total),
                unit="percent",
                target=self._targets["joins_declared_pct"],
                detail=f"{catalog.get('joins_declared', 0)} declared, "
                f"{catalog.get('joins_inferred', 0)} inferred",
            ),
            _kpi(
                "columns_described_pct",
                "Columns described",
                _pct(catalog.get("fields_described", 0), catalog.get("fields", 0)),
                unit="percent",
                target=self._targets["columns_described_pct"],
                detail=f"{catalog.get('fields_described', 0)} of {catalog.get('fields', 0)} columns",
            ),
            _kpi(
                "metrics_declared_pct",
                "Metrics declared",
                _pct(catalog.get("metrics_declared", 0), catalog.get("metrics", 0)),
                unit="percent",
                target=self._targets["metrics_declared_pct"],
                detail=f"{catalog.get('metrics_declared', 0)} declared of "
                f"{catalog.get('metrics', 0)} metrics",
            ),
        ]

        last_sync = catalog.get("last_synced_at")
        age_h = round((now - last_sync).total_seconds() / 3600, 1) if last_sync else None
        freshness = [
            _kpi(
                "assets_fresh_24h_pct",
                "Assets synced in 24h",
                _pct(catalog.get("fresh_24h", 0), assets),
                unit="percent",
                target=self._targets["assets_fresh_24h_pct"],
                detail=f"{catalog.get('fresh_24h', 0)} of {assets} assets",
            ),
            _kpi(
                "stale_assets_7d",
                "Assets stale for 7 days",
                float(catalog.get("stale_7d", 0)) if assets else None,
                target=self._targets["stale_assets_7d"],
                direction="lower",
                detail="not refreshed by any connector run in a week",
            ),
            _kpi(
                "catalog_sync_age_h",
                "Hours since last catalog sync",
                age_h,
                unit="hours",
                target=self._targets["catalog_sync_age_h"],
                direction="lower",
                detail=last_sync.isoformat() if last_sync else "no catalog sync yet",
            ),
        ]

        targets = [
            KpiTarget(
                key=k.key,
                label=k.label,
                env_var=f"ECH_KPI_TARGET_{k.key.upper()}",
                unit=k.unit,
                direction=k.direction,
                value=k.target,
                default=KPI_TARGET_DEFAULTS[k.key],
                overridden=k.target != KPI_TARGET_DEFAULTS[k.key],
            )
            for k in [*pipelines, *graph_kpis, *catalog_kpis, *freshness]
            if k.target is not None
        ]
        return EngineeringKpis(
            window_days=days,
            generated_at=now,
            targets=targets,
            groups=[
                KpiGroup(
                    key="pipelines",
                    label="Pipeline reliability",
                    description=f"Ingestion runs over the last {days} days.",
                    kpis=pipelines,
                ),
                KpiGroup(
                    key="graph",
                    label="Graph consistency",
                    description="Postgres documents versus their Neo4j subgraphs, right now.",
                    kpis=graph_kpis,
                ),
                KpiGroup(
                    key="catalog",
                    label="Catalog coverage",
                    description="How much of the semantic layer is documented, owned, keyed and declared.",
                    kpis=catalog_kpis,
                ),
                KpiGroup(
                    key="freshness",
                    label="Freshness",
                    description="How recently the catalog metadata was refreshed.",
                    kpis=freshness,
                ),
            ],
            connectors=[
                ConnectorFreshness(
                    connector=c["connector_name"],
                    source_system=c["source_system"],
                    last_success_at=c.get("last_success_at"),
                    age_hours=(
                        round((now - c["last_success_at"]).total_seconds() / 3600, 1)
                        if c.get("last_success_at")
                        else None
                    ),
                    last_status=c.get("last_status"),
                    runs=c.get("runs", 0),
                    failed=c.get("failed", 0),
                    documents_upserted=c.get("documents_upserted", 0),
                )
                for c in connectors
            ],
        )

    async def overview(self) -> OverviewStats:
        async def graph_stats() -> dict[str, Any]:
            try:
                return await self._graph.stats()
            except Exception as exc:  # noqa: BLE001 - the dashboard must render without Neo4j
                log.warning("stats.graph_unavailable", error=str(exc))
                return {
                    "nodes_total": 0,
                    "edges_total": 0,
                    "nodes_by_label": {},
                    "edges_by_type": {},
                    "density": 0.0,
                }

        (
            documents_total,
            by_source,
            by_kind,
            pending,
            chunks_total,
            embeddings_total,
            runs_total,
            runs_active,
            last_run_at,
            retrieval_24h,
            p95_24h,
            graph,
        ) = await asyncio.gather(
            self._documents.count(),
            self._documents.counts_by_source(),
            self._documents.counts_by_kind(),
            self._documents.count_graph_unsynced(),
            self._chunks.count(),
            self._embeddings.count(),
            self._runs.count(),
            self._runs.count_active(),
            self._runs.last_run_at(),
            self._audit.count_since(action="context.retrieve", hours=24),
            self._audit.p95_since(action="context.retrieve", hours=24),
            graph_stats(),
        )
        return OverviewStats(
            documents_total=documents_total,
            documents_by_source=by_source,
            documents_by_kind=by_kind,
            documents_graph_pending=pending,
            chunks_total=chunks_total,
            embeddings_total=embeddings_total,
            embedding_model=self._embedder.model_id,
            vector_dimensions=self._embedder.dimensions,
            graph_nodes_total=graph["nodes_total"],
            graph_edges_total=graph["edges_total"],
            graph_nodes_by_label=graph["nodes_by_label"],
            graph_edges_by_type=graph["edges_by_type"],
            graph_density=graph["density"],
            runs_total=runs_total,
            runs_active=runs_active,
            last_run_at=last_run_at,
            retrieval_requests_24h=retrieval_24h,
            retrieval_p95_ms_24h=p95_24h,
            generated_at=datetime.now(tz=UTC),
        )

    def latency(
        self, *, window_minutes: int, bucket_seconds: int, path_prefix: str | None
    ) -> LatencySeries:
        return self._latency.series(
            window_minutes=window_minutes, bucket_seconds=bucket_seconds, path_prefix=path_prefix
        )

    async def retrieval_latency_persisted(
        self, *, window_minutes: int, bucket_seconds: int
    ) -> LatencySeries:
        points = await self._audit.latency_series(
            action="context.retrieve", window_minutes=window_minutes, bucket_seconds=bucket_seconds
        )
        return LatencySeries(
            window_minutes=window_minutes,
            bucket_seconds=bucket_seconds,
            path_prefix="/api/v1/context/retrieve",
            points=points,
            overall=None,
        )

    # ------------------------------------------------------------------ shared helpers
    def _target_rows(self, kpis: list[KpiValue]) -> list[KpiTarget]:
        """One row per distinct target in ``kpis``: active value, default, env variable."""
        rows: dict[str, KpiTarget] = {}
        for k in kpis:
            if k.target is None or k.key not in KPI_TARGET_DEFAULTS or k.key in rows:
                continue
            rows[k.key] = KpiTarget(
                key=k.key,
                label=k.label,
                env_var=f"ECH_KPI_TARGET_{k.key.upper()}",
                unit=k.unit,
                direction=k.direction,
                value=k.target,
                default=KPI_TARGET_DEFAULTS[k.key],
                overridden=k.target != KPI_TARGET_DEFAULTS[k.key],
            )
        return list(rows.values())

    async def _graph_stats(self) -> dict[str, Any]:
        try:
            return await self._graph.stats()
        except Exception as exc:  # noqa: BLE001 - every report must render without Neo4j
            log.warning("stats.graph_unavailable", error=str(exc))
            return {
                "nodes_total": 0,
                "edges_total": 0,
                "nodes_by_label": {},
                "edges_by_type": {},
                "density": 0.0,
            }

    def _serving_kpis(self, rollup: list[dict[str, Any]]) -> list[KpiValue]:
        """Error rate and latency of the audited API calls (shared by QA and SRE)."""
        t = self._targets
        requests = sum(int(r.get("requests") or 0) for r in rollup)
        errors = sum(int(r.get("errors") or 0) for r in rollup)
        retrieve = next((r for r in rollup if r.get("action") == "context.retrieve"), None)
        genie = next((r for r in rollup if r.get("action") == "genie.ask"), None)
        p95 = retrieve.get("p95_ms") if retrieve else None
        return [
            _kpi(
                "request_error_rate",
                "Request error rate",
                _pct(errors, requests),
                unit="percent",
                target=t["request_error_rate"],
                direction="lower",
                detail=f"{errors} of {requests} audited requests errored",
            ),
            _kpi(
                "retrieval_p95_ms",
                "Retrieval p95 latency",
                round(float(p95), 1) if p95 is not None else None,
                unit="ms",
                target=t["retrieval_p95_ms"],
                direction="lower",
                detail=f"{int(retrieve['requests']) if retrieve else 0} context retrievals",
            ),
            _kpi(
                "genie_error_rate",
                "Genie error rate",
                _pct(int(genie["errors"]), int(genie["requests"])) if genie else None,
                unit="percent",
                target=t["request_error_rate"],
                direction="lower",
                detail=f"{int(genie['requests']) if genie else 0} questions asked",
            ),
        ]

    # ------------------------------------------------------------------ QA Engineer
    async def quality(self, *, days: int = 7) -> QualityReport:
        """Quality gates: ingestion, catalog integrity, semantic review and serving."""
        runs, failures, graph, rollup, errors = await asyncio.gather(
            self._runs.kpi_rollup(days=days),
            self._runs.recent_failures(days=days, limit=20),
            self._documents.graph_sync_breakdown(),
            self._audit.request_rollup(hours=days * 24),
            self._audit.recent(limit=20, status="error"),
        )
        catalog: dict[str, Any] = {}
        review: dict[str, Any] = {}
        queue: list[dict[str, Any]] = []
        if self._semantic is not None:
            catalog, review, queue = await asyncio.gather(
                self._semantic.coverage_kpis(),
                self._semantic.review_counts(),
                self._semantic.review_queue(limit=50),
            )
        t = self._targets
        finished = runs.get("completed", 0) + runs.get("failed", 0) + runs.get("cancelled", 0)
        seen = runs.get("documents_seen", 0)
        total_docs = sum(graph.values())
        ingestion = [
            _kpi(
                "run_success_rate",
                "Run success rate",
                _pct(runs.get("completed", 0), finished),
                unit="percent",
                target=t["run_success_rate"],
                detail=f"{runs.get('completed', 0)} of {finished} finished runs completed",
            ),
            _kpi(
                "doc_failure_rate",
                "Document failure rate",
                _pct(runs.get("documents_failed", 0), seen),
                unit="percent",
                target=t["doc_failure_rate"],
                direction="lower",
                detail=f"{runs.get('documents_failed', 0)} of {seen} documents seen failed",
            ),
            _kpi(
                "graph_failed",
                "Graph sync failures",
                float(graph.get("failed", 0)) if total_docs else None,
                target=t["graph_failed"],
                direction="lower",
                detail="documents that could not be written to Neo4j",
            ),
            _kpi(
                "graph_pending",
                "Graph sync pending",
                float(graph.get("pending", 0)) if total_docs else None,
                target=t["graph_pending"],
                direction="lower",
                detail="documents still waiting for their subgraph",
            ),
        ]
        assets = catalog.get("assets", 0)
        joins_total = catalog.get("joins_declared", 0) + catalog.get("joins_inferred", 0)
        integrity = [
            _kpi(
                "unclassified_assets",
                "Unclassified assets",
                float(review.get("unclassified", 0)) if assets else None,
                target=t["unclassified_assets"],
                direction="lower",
                detail="assets whose kind is still unknown",
            ),
            _kpi(
                "facts_keyed_pct",
                "Facts with a primary key",
                _pct(catalog.get("keyed_facts", 0), catalog.get("facts", 0)),
                unit="percent",
                target=t["facts_keyed_pct"],
                detail=f"{catalog.get('keyed_facts', 0)} of {catalog.get('facts', 0)} fact tables",
            ),
            _kpi(
                "assets_connected_pct",
                "Assets connected",
                _pct(catalog.get("connected", 0), assets),
                unit="percent",
                target=t["assets_connected_pct"],
                detail="a key, join or lineage edge reaches them",
            ),
            _kpi(
                "joins_declared_pct",
                "Joins declared",
                _pct(catalog.get("joins_declared", 0), joins_total),
                unit="percent",
                target=t["joins_declared_pct"],
                detail=f"{catalog.get('joins_inferred', 0)} joins are only inferred",
            ),
        ]
        semantic_review = [
            _kpi(
                "review_backlog",
                "Suggestions awaiting review",
                float(review.get("suggested", 0)) if assets else None,
                target=t["review_backlog"],
                direction="lower",
                detail=f"{review.get('accepted', 0)} accepted · {review.get('rejected', 0)} rejected",
            ),
            _kpi(
                "assets_described_pct",
                "Assets described",
                _pct(catalog.get("described", 0), assets),
                unit="percent",
                target=t["assets_described_pct"],
                detail=f"{catalog.get('described', 0)} of {assets} assets",
            ),
            _kpi(
                "columns_described_pct",
                "Columns described",
                _pct(catalog.get("fields_described", 0), catalog.get("fields", 0)),
                unit="percent",
                target=t["columns_described_pct"],
                detail=f"{catalog.get('fields_described', 0)} of {catalog.get('fields', 0)} columns",
            ),
            _kpi(
                "metrics_declared_pct",
                "Metrics declared",
                _pct(catalog.get("metrics_declared", 0), catalog.get("metrics", 0)),
                unit="percent",
                target=t["metrics_declared_pct"],
                detail=f"{catalog.get('metrics_declared', 0)} declared of "
                f"{catalog.get('metrics', 0)} metrics",
            ),
        ]
        groups = [
            KpiGroup(
                key="ingestion",
                label="Ingestion gates",
                description=f"Runs and documents over the last {days} days.",
                kpis=ingestion,
            ),
            KpiGroup(
                key="integrity",
                label="Catalog integrity",
                description="Structure the semantic layer can be trusted on: kinds, keys, joins.",
                kpis=integrity,
            ),
            KpiGroup(
                key="review",
                label="Semantic review",
                description="Names, meanings and metrics a person has signed off.",
                kpis=semantic_review,
            ),
            KpiGroup(
                key="serving",
                label="Serving",
                description=f"Audited API calls over the last {days} days.",
                kpis=self._serving_kpis(rollup),
            ),
        ]
        every = [k for g in groups for k in g.kpis]
        gated = [k for k in every if k.target is not None and k.value is not None]
        return QualityReport(
            window_days=days,
            generated_at=datetime.now(tz=UTC),
            gates_total=len(gated),
            gates_passed=sum(1 for k in gated if k.status == "ok"),
            targets=self._target_rows(every),
            groups=groups,
            failed_runs=[
                RunFailure(
                    id=r["id"],
                    connector=r["connector_name"],
                    source_system=r["source_system"],
                    status=r["status"],
                    error=r.get("error"),
                    started_at=r.get("started_at"),
                    finished_at=r.get("finished_at"),
                    documents_failed=int(r.get("documents_failed") or 0),
                )
                for r in failures
            ],
            review_queue=[_review_item(r) for r in queue],
            recent_errors=errors,
        )

    # ------------------------------------------------------------------ SRE
    async def analyst(self, *, days: int = 7) -> AnalystReport:
        """Business Analyst: questions answered without engineering, requests turned into decisions,
        and whether the metrics reports read from are declared."""

        async def empty() -> dict[str, Any]:
            return {}

        answers, requests, catalog = await asyncio.gather(
            self._genie_log.answer_counts(persona="business_analyst", days=days) if self._genie_log else empty(),
            self._intents.turnaround(days=days) if self._intents else empty(),
            self._semantic.coverage_kpis() if self._semantic else empty(),
        )
        t = self._targets
        asked = int(answers.get("asked") or 0)
        unhelpful = int(answers.get("unhelpful") or 0)
        decided = int(requests.get("decided") or 0)
        decision_h = requests.get("decision_h")
        questions = int(requests.get("questions") or 0)
        metrics = int(catalog.get("metrics") or 0)
        reporting = int(catalog.get("reporting_metrics") or 0)
        reporting_declared = int(catalog.get("reporting_metrics_declared") or 0)
        groups = [
            KpiGroup(
                key="answers",
                label="Self-serve answers",
                description=f"Questions in the Business Analyst Genie space over the last {days} days.",
                kpis=[
                    _kpi(
                        "genie_answered_pct",
                        "Questions answered self-serve",
                        _pct(int(answers.get("answered") or 0), asked),
                        unit="percent",
                        target=t["genie_answered_pct"],
                        detail=(
                            f"{answers.get('answered') or 0} of {asked} answered"
                            + (f" · {unhelpful} marked unhelpful" if unhelpful else "")
                            if asked
                            else f"no questions in the analyst's Genie space in the last {days} days"
                        ),
                    ),
                ],
            ),
            KpiGroup(
                key="requests",
                label="Requests to engineering",
                description="Jira and manual intents from question to decision.",
                kpis=[
                    _kpi(
                        "intent_decision_h",
                        "Request to decision",
                        round(float(decision_h), 1) if decision_h is not None else None,
                        unit="hours",
                        target=t["intent_decision_h"],
                        direction="lower",
                        detail=f"median of {decided} requests approved or rejected in the last {days} days"
                        if decided
                        else f"no request was approved or rejected in the last {days} days",
                    ),
                    _kpi(
                        "intents_clarifying",
                        "Requests waiting on answers",
                        float(requests.get("clarifying") or 0) if requests else None,
                        target=t["intents_clarifying"],
                        direction="lower",
                        detail=f"{questions} open questions from the planner",
                    ),
                ],
            ),
            KpiGroup(
                key="trust",
                label="Certified numbers",
                description="Metrics on curated layers, the ones a report should read from.",
                kpis=[
                    _kpi(
                        "reporting_metrics_declared_pct",
                        "Report metrics certified",
                        _pct(reporting_declared, reporting),
                        unit="percent",
                        target=t["reporting_metrics_declared_pct"],
                        detail=f"{reporting_declared} declared of {reporting} metrics on curated layers"
                        if reporting
                        else f"no curated-layer metrics yet; all {metrics} sit on raw schemas",
                    ),
                ],
            ),
        ]
        return AnalystReport(
            window_days=days,
            generated_at=datetime.now(tz=UTC),
            targets=self._target_rows([k for g in groups for k in g.kpis]),
            groups=groups,
        )

    async def platform(self, *, hours: int = 24) -> PlatformReport:
        """Service-level view: request health, error budget, pipeline state and storage."""
        days = max(1, -(-hours // 24))

        async def table_sizes() -> list[dict[str, Any]]:
            return await self._platform.table_sizes() if self._platform is not None else []

        async def database_bytes() -> int:
            return await self._platform.database_bytes() if self._platform is not None else 0

        (
            rollup,
            errors,
            tables,
            db_bytes,
            graph,
            runs_active,
            runs_stale,
            pending,
            embeddings_total,
            rows_per_day,
            runs,
        ) = await asyncio.gather(
            self._audit.request_rollup(hours=hours),
            self._audit.recent(limit=20, status="error"),
            table_sizes(),
            database_bytes(),
            self._graph_stats(),
            self._runs.count_active(),
            self._runs.count_stale_active(hours=1),
            self._documents.graph_sync_breakdown(),
            self._embeddings.count(),
            self._audit.rows_per_day(days=7),
            self._runs.kpi_rollup(days=days),
        )
        catalog = await self._semantic.coverage_kpis() if self._semantic is not None else {}
        now = datetime.now(tz=UTC)
        t = self._targets
        requests = sum(int(r.get("requests") or 0) for r in rollup)
        request_errors = sum(int(r.get("errors") or 0) for r in rollup)
        finished = runs.get("completed", 0) + runs.get("failed", 0) + runs.get("cancelled", 0)
        total_docs = sum(pending.values())
        serving = [
            *self._serving_kpis(rollup),
            _kpi(
                "audited_requests",
                "Audited requests",
                float(requests),
                detail=f"over the last {hours} hours",
            ),
        ]
        pipelines = [
            _kpi(
                "runs_failed",
                "Failed runs",
                float(runs.get("failed", 0)) if finished else None,
                target=t["runs_failed"],
                direction="lower",
                detail=f"{runs.get('completed', 0)} completed · {runs.get('cancelled', 0)} cancelled",
            ),
            _kpi(
                "runs_stale",
                "Stalled runs",
                float(runs_stale),
                target=t["runs_stale"],
                direction="lower",
                detail="active for an hour without progress",
            ),
            _kpi(
                "graph_pending",
                "Graph sync pending",
                float(pending.get("pending", 0)) if total_docs else None,
                target=t["graph_pending"],
                direction="lower",
                detail="documents waiting for Neo4j",
            ),
            _kpi(
                "graph_failed",
                "Graph sync failures",
                float(pending.get("failed", 0)) if total_docs else None,
                target=t["graph_failed"],
                direction="lower",
                detail="run graph reconciliation to retry",
            ),
        ]
        last_sync = catalog.get("last_synced_at")
        age_h = round((now - last_sync).total_seconds() / 3600, 1) if last_sync else None
        freshness = [
            _kpi(
                "catalog_sync_age_h",
                "Hours since last catalog sync",
                age_h,
                unit="hours",
                target=t["catalog_sync_age_h"],
                direction="lower",
                detail=last_sync.isoformat() if last_sync else "no catalog sync yet",
            ),
            _kpi(
                "stale_assets_7d",
                "Assets stale for 7 days",
                float(catalog.get("stale_7d", 0)) if catalog.get("assets") else None,
                target=t["stale_assets_7d"],
                direction="lower",
                detail=f"of {catalog.get('assets', 0)} assets",
            ),
        ]
        groups = [
            KpiGroup(
                key="serving",
                label="Serving SLOs",
                description=f"Audited API calls over the last {hours} hours.",
                kpis=serving,
            ),
            KpiGroup(
                key="pipelines",
                label="Pipelines",
                description=f"Ingestion runs over the last {days} day(s) and what is stuck now.",
                kpis=pipelines,
            ),
            KpiGroup(
                key="freshness",
                label="Freshness",
                description="How recently the catalog metadata was refreshed.",
                kpis=freshness,
            ),
        ]
        allowed = requests * t["request_error_rate"] / 100
        dims = int(self._embedder.dimensions)
        return PlatformReport(
            window_hours=hours,
            generated_at=now,
            targets=self._target_rows([k for g in groups for k in g.kpis]),
            groups=groups,
            requests=[
                RequestRollup(
                    action=r["action"],
                    requests=int(r.get("requests") or 0),
                    errors=int(r.get("errors") or 0),
                    error_rate=_pct(int(r.get("errors") or 0), int(r.get("requests") or 0)),
                    p50_ms=_ms(r.get("p50_ms")),
                    p95_ms=_ms(r.get("p95_ms")),
                    p99_ms=_ms(r.get("p99_ms")),
                    avg_ms=_ms(r.get("avg_ms")),
                )
                for r in rollup
            ],
            error_budget=ErrorBudget(
                target_error_rate=t["request_error_rate"],
                requests=requests,
                errors=request_errors,
                allowed_errors=round(allowed, 2),
                consumed_pct=round(request_errors / allowed * 100, 1) if allowed > 0 else None,
            ),
            storage=[
                TableSize(table=r["table"], rows=int(r["rows"]), bytes=int(r["bytes"]))
                for r in tables
            ],
            database_bytes=int(db_bytes),
            embeddings_total=int(embeddings_total),
            vector_dimensions=dims,
            embeddings_bytes_estimate=int(embeddings_total) * dims * 4,
            graph_nodes=int(graph.get("nodes_total", 0)),
            graph_edges=int(graph.get("edges_total", 0)),
            audit_rows_per_day=float(rows_per_day),
            runs_active=int(runs_active),
            runs_stale=int(runs_stale),
            recent_errors=errors,
        )

    # ------------------------------------------------------------------ Architect
    async def architecture(
        self, *, genie: GenieStatus | None, settings: Settings
    ) -> ArchitectureReport:
        """Platforms, model composition and every integration point, in one view."""
        by_source, by_kind, graph, documents_total, embeddings_total = await asyncio.gather(
            self._documents.counts_by_source(),
            self._documents.counts_by_kind(),
            self._graph_stats(),
            self._documents.count(),
            self._embeddings.count(),
        )
        overview: dict[str, Any] = {}
        platforms: list[dict[str, Any]] = []
        rel_kinds: dict[str, int] = {}
        metric_sources: dict[str, int] = {}
        shared: list[dict[str, Any]] = []
        cross = 0
        if self._semantic is not None:
            overview, platforms, rel_kinds, metric_sources, shared, cross = await asyncio.gather(
                self._semantic.overview(),
                self._semantic.platform_summary(),
                self._semantic.relationship_kinds(),
                self._semantic.metrics_by_source(),
                self._semantic.shared_dimensions(limit=12),
                self._semantic.cross_platform_links(),
            )
        kinds = overview.get("by_kind", {})
        types = overview.get("by_asset_type", {})
        return ArchitectureReport(
            generated_at=datetime.now(tz=UTC),
            platforms=[PlatformSummary.model_validate(p) for p in platforms],
            document_sources=by_source,
            documents_by_kind=by_kind,
            assets_by_kind=kinds,
            fields_by_role=overview.get("by_role", {}),
            relationships_by_kind=rel_kinds,
            metrics_by_source=metric_sources,
            graph_nodes_by_label=graph.get("nodes_by_label", {}),
            graph_edges_by_type=graph.get("edges_by_type", {}),
            graph_density=float(graph.get("density", 0.0)),
            subject_areas=len(overview.get("scopes", [])),
            facts=kinds.get("fact", 0),
            dimensions=kinds.get("dimension", 0),
            metric_views=types.get("metric_view", 0) + types.get("semantic_view", 0),
            governed_metrics=metric_sources.get("declared", 0) + metric_sources.get("curated", 0),
            cross_platform_links=int(cross),
            shared_dimensions=[SharedDimension.model_validate(r) for r in shared],
            integrations=_integrations(
                settings=settings,
                genie=genie,
                platforms=platforms,
                by_source=by_source,
                documents_total=documents_total,
                embeddings_total=embeddings_total,
                graph=graph,
                embedder=self._embedder,
            ),
            embedding_model=self._embedder.model_id,
            vector_dimensions=self._embedder.dimensions,
            genie_provider=genie.provider if genie else None,
            genie_model=genie.model if genie else None,
            reranker=settings.reranker_provider,
        )


# ----------------------------------------------------------------------------- KPI helpers
def _pct(part: int | float, whole: int | float) -> float | None:
    return round(part / whole * 100, 1) if whole else None


def kpi_status(value: float | None, *, target: float | None, direction: str) -> KpiStatus:
    """ok / warn / bad against a target; info when there is no target; na with no value.

    Higher-is-better: warn within ten points (or 10 %) under the target. Lower-is-better:
    a zero target tolerates up to two as a warning; a positive target warns up to double.
    """
    if value is None:
        return "na"
    if target is None:
        return "info"
    if direction == "higher":
        if value >= target:
            return "ok"
        slack = max(10.0, target * 0.1)
        return "warn" if value >= target - slack else "bad"
    if value <= target:
        return "ok"
    if target == 0:
        return "warn" if value <= 2 else "bad"
    return "warn" if value <= target * 2 else "bad"


def _kpi(
    key: str,
    label: str,
    value: float | None,
    *,
    unit: str = "count",
    target: float | None = None,
    direction: str = "higher",
    detail: str = "",
) -> KpiValue:
    return KpiValue(
        key=key,
        label=label,
        value=value,
        unit=unit,  # type: ignore[arg-type]
        target=target,
        direction=direction,  # type: ignore[arg-type]
        status=kpi_status(value, target=target, direction=direction),
        detail=detail,
    )


def _ms(value: Any) -> float | None:
    return round(float(value), 1) if value is not None else None


def _review_item(row: Mapping[str, Any]) -> ReviewItem:
    raw = row.get("enrichment") or {}
    if isinstance(raw, str):
        raw = json.loads(raw)
    fqn = str(row["fqn"])
    return ReviewItem(
        asset_id=row["id"],
        fqn=fqn,
        display_name=row.get("display_name") or fqn.rsplit(".", 1)[-1],
        kind=row.get("kind") or "unknown",
        proposed_name=str(raw.get("display_name") or ""),
        proposed_kind=str(raw.get("kind") or "unknown"),
        confidence=float(raw.get("confidence") or 0),
        metrics=len(raw.get("metrics") or []),
        generated_at=raw.get("generated_at"),
    )


def _integrations(
    *,
    settings: Settings,
    genie: GenieStatus | None,
    platforms: list[dict[str, Any]],
    by_source: Mapping[str, int],
    documents_total: int,
    embeddings_total: int,
    graph: Mapping[str, Any],
    embedder: EmbeddingProvider,
) -> list[Integration]:
    """Every way data enters, is stored, is modelled or leaves the hub, with its state."""
    per_platform = {p["platform"]: p for p in platforms}
    items: list[Integration] = []

    def source(key: str, label: str, configured: bool, extra: str = "") -> None:
        docs = int(by_source.get(key, 0))
        p = per_platform.get(key)
        parts: list[str] = []
        if p:
            parts.append(f"{p['assets']} assets in {p['databases']} catalog(s)")
        if docs:
            parts.append(f"{docs} documents")
        if extra:
            parts.append(extra)
        status = "configured" if configured else ("available" if (p or docs) else "missing")
        items.append(
            Integration(
                key=key,
                label=label,
                kind="source",
                status=status,  # type: ignore[arg-type]
                detail=" · ".join(parts) or "not configured",
                href="/pipelines",
            )
        )

    source(
        "databricks",
        "Databricks Unity Catalog",
        bool(settings.databricks_host and settings.databricks_catalog_list),
        ", ".join(settings.databricks_catalog_list),
    )
    source("snowflake", "Snowflake", bool(settings.snowflake_account or settings.snowflake_host))
    source(
        "github", "GitHub", bool(settings.github_repo_list), ", ".join(settings.github_repo_list)
    )
    source("confluence", "Confluence", False)
    source("sharepoint", "SharePoint", False)
    source("manual", "Manual ingestion API", True, "POST /api/v1/documents")

    items.append(
        Integration(
            key="postgres",
            label="PostgreSQL + pgvector",
            kind="store",
            status="configured",
            detail=f"{documents_total} documents · {embeddings_total} vectors · semantic layer",
            href="/knowledge/documents",
        )
    )
    nodes = int(graph.get("nodes_total", 0))
    items.append(
        Integration(
            key="neo4j",
            label="Neo4j knowledge graph",
            kind="store",
            status="configured" if nodes else "available",
            detail=f"{nodes} nodes · {int(graph.get('edges_total', 0))} edges",
            href="/knowledge/documents",
        )
    )
    items.append(
        Integration(
            key="embeddings",
            label="Embedding model",
            kind="model",
            status="configured",
            detail=f"{embedder.model_id} · {embedder.dimensions} dimensions "
            f"({settings.embedding_provider})",
        )
    )
    genie_ok = bool(genie and genie.configured)
    genie_detail = "no model configured"
    if genie and genie.configured:
        genie_detail = f"{genie.model}" + (f" via {genie.provider}" if genie.provider else "")
    elif genie and genie.reason:
        genie_detail = genie.reason
    items.append(
        Integration(
            key="genie_model",
            label="Genie model (Claude)",
            kind="model",
            status="configured" if genie_ok else "missing",
            detail=genie_detail,
            href="/genie",
        )
    )
    reranker = settings.reranker_provider
    if reranker != "heuristic":
        reranker = f"{reranker} · {settings.reranker_model}"
    items.append(
        Integration(
            key="reranker", label="Reranker", kind="model", status="configured", detail=reranker
        )
    )
    for key, label, detail in (
        ("cortex", "Snowflake Cortex Analyst model", "YAML semantic model of the selected scope"),
        ("databricks_metric_view", "Databricks metric views", "metric-view YAML per fact"),
        ("hub", "Hub JSON", "the full semantic scope as JSON"),
    ):
        items.append(
            Integration(
                key=f"export_{key}",
                label=label,
                kind="export",
                status="available",
                detail=detail,
                href="/semantic",
            )
        )
    items.append(
        Integration(
            key="context_retrieve",
            label="Context retrieval API",
            kind="api",
            status="available",
            detail="POST /api/v1/context/retrieve · hybrid search + GraphRAG",
            href="/playground",
        )
    )
    items.append(
        Integration(
            key="genie_ask",
            label="Genie (SSE)",
            kind="assistant",
            status="configured" if genie_ok else "missing",
            detail="POST /api/v1/genie/spaces/{id}/ask · persona spaces",
            href="/genie",
        )
    )
    return items
