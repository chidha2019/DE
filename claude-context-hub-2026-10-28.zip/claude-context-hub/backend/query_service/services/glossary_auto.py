"""Glossary mapping after every successful Snowflake or Databricks sync.

The ingestion service records each run in Postgres; this loop picks up the syncs that completed since its
last pass and maps their source system once, however many syncs finished in between: name rules on every
dataset, Claude only on datasets whose source metadata changed since it last mapped them. Proposals land
in the review queue; nothing applies until a person accepts it.
"""

from __future__ import annotations

import asyncio
from uuid import UUID

from ech_core.logging import get_logger
from ech_core.repositories.glossary_repository import GlossaryRepository
from query_service.services.glossary_service import GlossaryService

log = get_logger(__name__)


class GlossaryAutoMapper:
    def __init__(self, glossary: GlossaryService, repo: GlossaryRepository, *, interval_seconds: int) -> None:
        self._glossary = glossary
        self._repo = repo
        self._interval = interval_seconds

    async def loop(self) -> None:
        dropped = await self._repo.drop_unfinished_auto_runs()
        if dropped:
            log.info("glossary.auto_map.requeued", passes=dropped)
        while True:
            try:
                await self.tick()
            except Exception as exc:  # noqa: BLE001 - the next pass retries
                log.warning("glossary.auto_map.poll_failed", error=str(exc))
            await asyncio.sleep(self._interval)

    async def tick(self) -> int:
        """Map every source system with finished syncs waiting; returns how many passes ran."""
        by_system: dict[str, list[UUID]] = {}
        for sync in await self._repo.pending_syncs():
            by_system.setdefault(sync["source_system"], []).append(sync["id"])
        for system, run_ids in by_system.items():
            await self._map(system, run_ids)
        return len(by_system)

    async def _map(self, system: str, run_ids: list[UUID]) -> None:
        pass_id = await self._repo.start_auto_run(system, run_ids)
        log.info("glossary.auto_map.started", source_system=system, syncs=len(run_ids))
        try:
            run, datasets = await self._glossary.auto_map(system)
        except Exception as exc:  # noqa: BLE001 - recorded on the pass, the syncs are not retried
            await self._repo.finish_auto_run(pass_id, status="failed", counts={}, message=None, error=str(exc)[:300])
            log.warning("glossary.auto_map.failed", source_system=system, error=str(exc))
            return
        counts = {
            "datasets": datasets,
            "model_datasets": run.total,
            "unchanged": run.skipped,
            "model_failed": run.failed,
            "rule_links": run.rule_links,
            "model_links": run.model_links,
        }
        status = "failed" if run.status == "failed" else "completed"
        await self._repo.finish_auto_run(pass_id, status=status, counts=counts, message=run.message, error=run.error)
        log.info("glossary.auto_map.finished", source_system=system, status=status, **counts)
