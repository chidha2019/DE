"""Serves the semantic layer: browsing, search, relationship graphs, exports, Genie text."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any
from uuid import UUID

from ech_core.domain.enums import SourceSystem
from ech_core.exceptions import InvalidRequestError, NotFoundError
from ech_core.repositories.semantic_repository import SemanticRepository
from ech_core.schemas.common import Page
from ech_core.schemas.semantic import (
    BusinessModel,
    FactStar,
    GlossaryTerm,
    MetricViewCard,
    SemanticAssetDetail,
    SemanticAssetSummary,
    SemanticFieldHit,
    SemanticFieldOut,
    SemanticGraph,
    SemanticHealth,
    SemanticMetricHit,
    SemanticMetricOut,
    SemanticMetricRow,
    SemanticOverview,
    SemanticRelationshipOut,
    SemanticSearchResponse,
    StarDimension,
    SubjectArea,
)
from ech_core.semantic.exports import FORMATS, export
from ech_core.semantic.naming import business_name


@dataclass(frozen=True)
class SemanticSource:
    """What the Genie toolbox needs to register a semantic asset as a citable source."""

    asset_id: UUID
    fqn: str
    platform: str
    uri: str | None
    snippet: str


Citer = Callable[[SemanticSource], str]


class SemanticService:
    def __init__(self, repo: SemanticRepository) -> None:
        self._repo = repo

    async def overview(self) -> SemanticOverview:
        return SemanticOverview.model_validate(await self._repo.overview())

    async def list_assets(
        self,
        *,
        search: str | None,
        source_system: SourceSystem | None,
        database: str | None,
        schema: str | None,
        asset_type: str | None,
        kind: str | None,
        limit: int,
        offset: int,
    ) -> Page[SemanticAssetSummary]:
        rows, total = await self._repo.list_assets(
            search=search,
            source_system=source_system,
            database=database,
            schema=schema,
            asset_type=asset_type,
            kind=kind,
            limit=limit,
            offset=offset,
        )
        return Page(
            items=[SemanticAssetSummary.model_validate(r) for r in rows],
            total=total,
            limit=limit,
            offset=offset,
        )

    async def get_asset(self, asset_id: UUID) -> SemanticAssetDetail:
        row = await self._repo.get_asset_row(asset_id)
        if row is None:
            raise NotFoundError(f"semantic asset {asset_id} not found")
        return await self._detail(row)

    async def find_asset(self, fqn: str) -> SemanticAssetDetail | None:
        row = await self._repo.find_asset_row(fqn)
        return await self._detail(row) if row else None

    async def _detail(self, row: dict[str, Any]) -> SemanticAssetDetail:
        asset_id = row["id"]
        fields = await self._repo.fields(asset_id)
        relationships = await self._repo.relationships(asset_id)
        metrics = await self._repo.metrics(asset_id)
        return SemanticAssetDetail.model_validate(
            {
                **row,
                "fields": [SemanticFieldOut.model_validate(f) for f in fields],
                "relationships": [SemanticRelationshipOut.model_validate(r) for r in relationships],
                "metrics": [SemanticMetricOut.model_validate(m) for m in metrics],
            }
        )

    async def search(self, query: str, *, limit: int = 20) -> SemanticSearchResponse:
        hits = await self._repo.search(query, limit=limit)
        return SemanticSearchResponse(
            query=query,
            assets=[SemanticAssetSummary.model_validate(r) for r in hits["assets"]],
            fields=[SemanticFieldHit.model_validate(r) for r in hits["fields"]],
            metrics=[SemanticMetricHit.model_validate(r) for r in hits["metrics"]],
        )

    async def graph(self, asset_id: UUID, *, depth: int = 1) -> SemanticGraph:
        if await self._repo.get_asset_row(asset_id) is None:
            raise NotFoundError(f"semantic asset {asset_id} not found")
        payload = await self._repo.neighborhood(asset_id, depth=depth)
        return SemanticGraph(center_id=asset_id, **payload)

    # ------------------------------------------------------------------ business model
    async def business_model(
        self, *, source_system: SourceSystem | None, database: str | None, schema: str | None
    ) -> BusinessModel:
        """Subject areas with fact stars, governed metric views and dimensions."""
        rows, _ = await self._repo.list_assets(
            search=None,
            source_system=source_system,
            database=database,
            schema=schema,
            asset_type=None,
            kind=None,
            limit=2000,
            offset=0,
        )
        summaries = {r["id"]: SemanticAssetSummary.model_validate(r) for r in rows}
        ids = list(summaries)
        rels = await self._repo.scope_relationships(ids) if ids else []
        metric_rows = await self._repo.scope_metrics(ids) if ids else []
        role_rows = await self._repo.scope_role_fields(ids) if ids else []

        metrics: dict[UUID, list[SemanticMetricOut]] = {}
        for m in metric_rows:
            metrics.setdefault(m["asset_id"], []).append(SemanticMetricOut.model_validate(m))
        roles: dict[UUID, dict[str, int]] = {}
        measures: dict[UUID, list[str]] = {}
        times: dict[UUID, list[str]] = {}
        dims_of: dict[UUID, list[str]] = {}
        for f in role_rows:
            counts = roles.setdefault(f["asset_id"], {})
            counts[f["role"]] = counts.get(f["role"], 0) + 1
            label = f.get("display_name") or business_name(f["name"])
            if f["role"] == "measure":
                measures.setdefault(f["asset_id"], []).append(label)
            elif f["role"] == "time":
                times.setdefault(f["asset_id"], []).append(label)
            elif f["role"] == "dimension":
                dims_of.setdefault(f["asset_id"], []).append(label)

        join_kinds = {"foreign_key", "join_declared", "join_inferred"}
        joins: dict[UUID, list[StarDimension]] = {}
        sources: dict[UUID, str] = {}
        for r in rels:
            if r["kind"] in join_kinds:
                target = summaries.get(r.get("target_asset_id"))
                display = (
                    target.display_name
                    if target and target.display_name
                    else (
                        r.get("target_display_name")
                        or business_name(r.get("target_name") or r["target_fqn"])
                    )
                )
                joins.setdefault(r["source_asset_id"], []).append(
                    StarDimension(
                        asset=target,
                        fqn=r["target_fqn"],
                        display_name=display,
                        kind=target.kind if target else (r.get("target_kind") or "unknown"),
                        relationship=r["kind"],
                        join_columns=list(r.get("source_columns") or []),
                        confidence=float(r.get("confidence") or 1.0),
                    )
                )
            elif r["kind"] == "metric_source":
                sources.setdefault(r["source_asset_id"], r["target_fqn"])

        areas: dict[tuple[str, str, str], SubjectArea] = {}
        for asset in summaries.values():
            key = (asset.platform, asset.database_name, asset.schema_name)
            area = areas.get(key)
            if area is None:
                area = SubjectArea(
                    platform=asset.platform,
                    database_name=asset.database_name,
                    schema_name=asset.schema_name,
                    label=business_name(asset.schema_name),
                )
                areas[key] = area
            area.assets += 1
            area.described += 1 if asset.description.strip() else 0
            area.named += 1 if asset.name_source != "derived" else 0
            if asset.asset_type in ("metric_view", "semantic_view") or asset.kind == "metric":
                area.metric_views.append(
                    MetricViewCard(
                        asset=asset,
                        source_fqn=sources.get(asset.id),
                        dimensions=dims_of.get(asset.id, []),
                        metrics=metrics.get(asset.id, []),
                    )
                )
            elif asset.kind == "fact":
                area.facts.append(
                    FactStar(
                        asset=asset,
                        measures=measures.get(asset.id, [])[:12],
                        time=times.get(asset.id, [])[:6],
                        roles=roles.get(asset.id, {}),
                        dimensions=joins.get(asset.id, []),
                        metrics=metrics.get(asset.id, [])[:8],
                    )
                )
            elif asset.kind in ("dimension", "reference"):
                area.dimensions.append(asset)
            else:
                area.other.append(asset)
        ordered = sorted(areas.values(), key=lambda a: (a.platform, a.database_name, a.schema_name))
        for area in ordered:
            area.facts.sort(key=lambda s: (-len(s.metrics), s.asset.display_name or s.asset.name))
        return BusinessModel(
            subject_areas=ordered,
            assets=len(summaries),
            facts=sum(len(a.facts) for a in ordered),
            dimensions=sum(len(a.dimensions) for a in ordered),
            metric_views=sum(len(a.metric_views) for a in ordered),
            governed_metrics=sum(1 for m in metric_rows if m["source"] in ("declared", "curated")),
        )

    # ------------------------------------------------------------------ persona views
    async def metrics_catalog(
        self,
        *,
        search: str | None,
        source: str | None,
        database: str | None,
        schema: str | None,
        limit: int,
        offset: int,
    ) -> Page[SemanticMetricRow]:
        rows, total = await self._repo.metrics_catalog(
            search=search,
            source=source,
            database=database,
            schema=schema,
            limit=limit,
            offset=offset,
        )
        return Page(
            items=[SemanticMetricRow.model_validate(r) for r in rows],
            total=total,
            limit=limit,
            offset=offset,
        )

    async def glossary(
        self, *, search: str | None, role: str | None, limit: int, offset: int
    ) -> Page[GlossaryTerm]:
        rows, total = await self._repo.glossary(
            search=search, role=role, limit=limit, offset=offset
        )
        items = [
            GlossaryTerm.model_validate(
                {
                    **r,
                    "data_types": list(r.get("data_types") or []),
                    "assets": list(r.get("assets") or [])[:5],
                }
            )
            for r in rows
        ]
        return Page(items=items, total=total, limit=limit, offset=offset)

    async def health(self) -> SemanticHealth:
        return SemanticHealth.model_validate(await self._repo.health())

    async def export(
        self,
        *,
        fmt: str,
        source_system: SourceSystem | None,
        database: str | None,
        schema: str | None,
        asset_ids: list[UUID] | None,
    ) -> tuple[str, str, str]:
        """``(content, media_type, filename)`` for a scope of assets."""
        if fmt not in FORMATS:
            raise InvalidRequestError(
                f"unknown export format {fmt!r}", details={"formats": list(FORMATS)}
            )
        loaded = await self._repo.load_assets(
            source_system=source_system, database=database, schema=schema, asset_ids=asset_ids
        )
        if not loaded:
            raise NotFoundError("no semantic assets match that scope")
        assets = [asset for _, asset in loaded]
        name = "_".join(p for p in (database, schema) if p) or "context_hub"
        content, media_type = export(assets, fmt=fmt, name=name)
        extension = "json" if media_type.endswith("json") else "yaml"
        return content, media_type, f"{name}_{fmt}.{extension}"

    # ------------------------------------------------------------------ genie
    async def describe_for_genie(
        self, name: str, *, max_fields: int = 80, cite: Citer | None = None
    ) -> str | None:
        """Plain-text description of one asset for the Genie tool loop.

        ``cite`` registers the asset as a source and returns its ``S#`` marker, which prefixes
        the header line so the model can cite the asset the way it cites chunks.
        """
        detail = await self.find_asset(name)
        if detail is None:
            return None
        label = _label(cite, detail.id, detail.fqn, detail.platform, detail.uri, detail.description)
        lines = [
            f"{label.strip()}{' ' if label.strip() else ''}{detail.fqn}  "
            f"({detail.asset_type}, {detail.kind}, {detail.platform}; "
            f"asset_id={detail.id}, document_id={detail.document_id})"
        ]
        if detail.description:
            lines.append(detail.description)
        if detail.owner:
            lines.append(f"owner: {detail.owner}")
        if detail.row_count is not None:
            lines.append(f"rows: {detail.row_count:,}")
        lines += ["", "columns (name | type | role | key | description):"]
        for f in detail.fields[:max_fields]:
            role = f.role + (f" ({f.aggregation})" if f.aggregation else "")
            key = "PK" if f.is_primary_key else ""
            lines.append(f"  {f.name} | {f.data_type} | {role} | {key} | {f.description}")
        if len(detail.fields) > max_fields:
            lines.append(f"  ... {len(detail.fields) - max_fields} more columns")
        if detail.relationships:
            lines += ["", "relationships:"]
            for r in detail.relationships:
                cols = (
                    f" on {', '.join(r.source_columns)} -> {', '.join(r.target_columns)}"
                    if r.source_columns
                    else ""
                )
                arrow = "->" if r.direction == "out" else "<-"
                evidence = f", {r.evidence}" if r.evidence else ""
                lines.append(
                    f"  {r.kind} {arrow} {r.other_fqn}{cols} (confidence {r.confidence:.2f}{evidence})"
                )
        if detail.metrics:
            lines += ["", "metrics:"]
            for m in detail.metrics:
                dims = f" by {', '.join(m.dimensions)}" if m.dimensions else ""
                desc = f" - {m.description}" if m.description else ""
                lines.append(
                    f"  {m.name} = {m.expression or m.aggregation}{dims} [{m.source}]{desc}"
                )
        if detail.definition:
            lines += ["", "definition:", detail.definition.strip()[:3000]]
        return "\n".join(lines)

    async def search_for_genie(
        self, query: str, *, limit: int = 10, cite: Citer | None = None
    ) -> str:
        """Plain-text search hits for the Genie tool loop; every hit is labelled by its asset."""
        hits = await self.search(query, limit=limit)
        if not (hits.assets or hits.fields or hits.metrics):
            return f"nothing in the semantic layer matches {query!r}"
        lines: list[str] = []
        if hits.assets:
            lines.append("assets:")
            lines += [
                _label(cite, a.id, a.fqn, a.platform, a.uri, a.description)
                + f"{a.fqn} ({a.asset_type}, {a.kind}, {a.field_count} columns, "
                f"{a.metric_count} metrics)" + (f": {a.description[:160]}" if a.description else "")
                for a in hits.assets
            ]
        if hits.fields:
            lines.append("columns:")
            lines += [
                _label(cite, f.asset_id, f.asset_fqn, f.platform, f.uri, "")
                + f"{f.asset_fqn}.{f.name} ({f.data_type}, {f.role}{', PK' if f.is_primary_key else ''})"
                + (f": {f.description[:120]}" if f.description else "")
                for f in hits.fields
            ]
        if hits.metrics:
            lines.append("metrics:")
            lines += [
                _label(cite, m.asset_id, m.asset_fqn, m.platform, m.uri, m.description)
                + f"{m.name} on {m.asset_fqn} = {m.expression or m.aggregation} [{m.source}]"
                + (f": {m.description[:120]}" if m.description else "")
                for m in hits.metrics
            ]
        return "\n".join(lines)


def _label(
    cite: Citer | None, asset_id: UUID, fqn: str, platform: str, uri: str | None, snippet: str
) -> str:
    """``"  [S3] "`` when a citer is given, else the plain two-space indent of a hit line."""
    if cite is None:
        return "  "
    marker = cite(
        SemanticSource(asset_id=asset_id, fqn=fqn, platform=platform, uri=uri, snippet=snippet)
    )
    return f"  [{marker}] " if marker else "  "
