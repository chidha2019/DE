"""Model-assisted enrichment of the semantic layer.

Claude reads an asset's columns, keys, joins and lineage and proposes a business name, a
one-line meaning, a kind and the metrics it supports. Proposals are stored as *suggestions*
with provenance and never applied until someone accepts them (optionally edited), so what the
platform declares and what a person curated always stay distinguishable from what a model said.
"""

from __future__ import annotations

import asyncio
import json
import re
from datetime import UTC, datetime
from typing import Any
from uuid import UUID, uuid4

from ech_core.exceptions import DependencyUnavailableError, InvalidRequestError, NotFoundError
from ech_core.llm.client import ModelClient
from ech_core.logging import get_logger
from ech_core.repositories.semantic_repository import SemanticRepository
from ech_core.schemas.semantic import (
    EnrichmentDecision,
    EnrichmentMetric,
    EnrichmentSuggestion,
    EnrichRequest,
    EnrichRun,
    SemanticAssetDetail,
)
from ech_core.semantic.models import AssetKind
from ech_core.semantic.naming import business_name
from query_service.services.semantic_service import SemanticService

log = get_logger(__name__)

SYSTEM_PROMPT = """You are a data steward naming datasets for business users of an insurance and
banking data platform. You read one dataset's technical metadata and answer with JSON only:
no prose, no markdown fences.

Rules:
- display_name: a short business name (2-5 words, Title Case), never the technical name.
- summary: at most 200 characters of plain business language saying what one row represents and
  what the dataset is used for. Do not restate column names.
- kind: one of fact, dimension, bridge, reference, metric, unknown. A fact records events or
  transactions with measures; a dimension describes an entity; a bridge links two entities;
  a reference is a small code/lookup list; a metric is a governed metric definition.
- metrics: up to 5 business metrics this dataset can answer, each with a snake_case name, a
  Title Case display_name, a SQL aggregate expression that uses only the listed columns, a one
  sentence description and the columns it can be broken down by. Leave the list empty for
  dimensions, bridges and references.
- confidence: 0 to 1 for the naming and kind together.
- rationale: at most 200 characters on what the evidence was.
Output shape:
{"display_name": "...", "summary": "...", "kind": "...", "metrics": [{"name": "...",
 "display_name": "...", "expression": "...", "description": "...", "dimensions": ["..."]}],
 "confidence": 0.0, "rationale": "..."}"""

_JSON_BLOCK = re.compile(r"\{.*\}", re.S)
_KINDS = {k.value for k in AssetKind}


def build_prompt(detail: SemanticAssetDetail) -> str:
    """What the model sees: the technical facts, nothing it could not verify."""
    columns = [
        {
            "name": f.name,
            "type": f.data_type,
            "role": f.role,
            "key": f.is_primary_key,
            "description": f.description[:160],
        }
        for f in detail.fields[:80]
    ]
    relationships = [
        {
            "kind": r.kind,
            "direction": r.direction,
            "other": r.other_fqn,
            "columns": r.source_columns,
            "confidence": round(r.confidence, 2),
        }
        for r in detail.relationships[:30]
    ]
    payload = {
        "fqn": detail.fqn,
        "platform": detail.platform,
        "asset_type": detail.asset_type,
        "current_kind": detail.kind,
        "catalog_description": detail.description[:600],
        "owner": detail.owner,
        "tags": detail.tags,
        "row_count": detail.row_count,
        "columns": columns,
        "relationships": relationships,
        "existing_metrics": [m.name for m in detail.metrics[:20]],
        "definition_excerpt": (detail.definition or "")[:800],
    }
    return "Dataset metadata:\n" + json.dumps(payload, ensure_ascii=False, indent=1)


def parse_suggestion(
    text: str, detail: SemanticAssetDetail, *, model: str | None
) -> EnrichmentSuggestion:
    """Turn the model's answer into a validated suggestion; metrics must use real columns."""
    match = _JSON_BLOCK.search(text or "")
    if not match:
        raise InvalidRequestError("the model did not return JSON")
    try:
        raw = json.loads(match.group(0))
    except json.JSONDecodeError as exc:
        raise InvalidRequestError(f"the model returned invalid JSON: {exc}") from exc
    if not isinstance(raw, dict):
        raise InvalidRequestError("the model returned JSON that is not an object")
    columns = {f.name.casefold() for f in detail.fields}
    metrics: list[EnrichmentMetric] = []
    for item in raw.get("metrics") or []:
        if not isinstance(item, dict) or not item.get("name"):
            continue
        expression = str(item.get("expression") or "").strip()
        used = {m.casefold() for m in re.findall(r"[A-Za-z_][A-Za-z0-9_]*", expression)}
        if expression and not (used & columns) and "count(*)" not in expression.casefold():
            continue  # an expression over columns this dataset does not have
        dimensions = [d for d in (item.get("dimensions") or []) if str(d).casefold() in columns]
        name = re.sub(r"[^a-z0-9_]+", "_", str(item["name"]).strip().lower()).strip("_")
        if not name:
            continue
        metrics.append(
            EnrichmentMetric(
                name=name,
                display_name=str(item.get("display_name") or business_name(name)),
                expression=expression,
                description=str(item.get("description") or "")[:400],
                dimensions=[str(d) for d in dimensions][:12],
            )
        )
    kind = str(raw.get("kind") or detail.kind).strip().lower()
    if kind not in _KINDS:
        kind = detail.kind
    try:
        confidence = max(0.0, min(1.0, float(raw.get("confidence") or 0.0)))
    except (TypeError, ValueError):
        confidence = 0.0
    display_name = str(raw.get("display_name") or "").strip()[:120] or business_name(detail.name)
    summary = " ".join(str(raw.get("summary") or "").split())[:300]
    return EnrichmentSuggestion(
        status="suggested",
        display_name=display_name,
        summary=summary,
        kind=kind,
        metrics=metrics[:5],
        confidence=confidence,
        rationale=str(raw.get("rationale") or "")[:300],
        model=model,
        generated_at=datetime.now(tz=UTC),
    )


class EnrichmentService:
    def __init__(
        self,
        *,
        repo: SemanticRepository,
        semantic: SemanticService,
        model: ModelClient | None,
        unavailable_reason: str | None = None,
        concurrency: int = 3,
        keep_runs: int = 20,
    ) -> None:
        self._repo = repo
        self._semantic = semantic
        self._model = model
        self._reason = unavailable_reason
        self._concurrency = max(1, concurrency)
        self._keep_runs = keep_runs
        self._runs: dict[UUID, EnrichRun] = {}
        self._tasks: dict[UUID, asyncio.Task[None]] = {}

    @property
    def available(self) -> bool:
        return self._model is not None

    def _require_model(self) -> ModelClient:
        if self._model is None:
            raise DependencyUnavailableError(
                self._reason or "no Claude model is configured for enrichment"
            )
        return self._model

    # ------------------------------------------------------------------ one asset
    async def suggest(self, asset_id: UUID) -> EnrichmentSuggestion:
        """Ask the model about one asset and store the suggestion on it."""
        model = self._require_model()
        detail = await self._semantic.get_asset(asset_id)
        turn = await model.complete(
            system=SYSTEM_PROMPT,
            tools=[],
            messages=[{"role": "user", "content": build_prompt(detail)}],
        )
        suggestion = parse_suggestion(turn.text, detail, model=turn.model)
        await self._repo.set_enrichment(asset_id, suggestion.model_dump(mode="json"))
        log.info(
            "semantic.enrichment.suggested",
            asset=detail.fqn,
            display_name=suggestion.display_name,
            kind=suggestion.kind,
            metrics=len(suggestion.metrics),
        )
        return suggestion

    async def decide(self, asset_id: UUID, decision: EnrichmentDecision) -> SemanticAssetDetail:
        """Accept (optionally edited) or reject the stored suggestion."""
        detail = await self._semantic.get_asset(asset_id)
        stored = detail.enrichment
        if not stored or stored.get("status") not in ("suggested", "accepted", "rejected"):
            raise NotFoundError(f"asset {asset_id} has no enrichment suggestion to decide on")
        suggestion = EnrichmentSuggestion.model_validate(stored)
        now = datetime.now(tz=UTC)
        if decision.action == "reject":
            suggestion.status = "rejected"
            suggestion.decided_at = now
            await self._repo.set_enrichment(asset_id, suggestion.model_dump(mode="json"))
            return await self._semantic.get_asset(asset_id)

        display_name = (decision.display_name or suggestion.display_name).strip()
        summary = (decision.summary or suggestion.summary).strip()
        kind = (decision.kind or suggestion.kind).strip().lower()
        if kind not in _KINDS:
            raise InvalidRequestError(f"unknown kind {kind!r}")
        edited = (
            display_name != suggestion.display_name
            or summary != suggestion.summary
            or kind != suggestion.kind
        )
        await self._repo.apply_enrichment(
            asset_id,
            display_name=display_name,
            summary=summary,
            kind=kind,
            name_source="curated" if edited else "model",
            kind_source="curated" if (kind != detail.kind and edited) else "model",
        )
        wanted = (
            {n.casefold() for n in decision.metric_names}
            if decision.metric_names is not None
            else {m.name.casefold() for m in suggestion.metrics}
        )
        existing = {m.name.casefold() for m in detail.metrics}
        for metric in suggestion.metrics:
            if metric.name.casefold() in wanted and metric.name.casefold() not in existing:
                await self._repo.add_metric(
                    asset_id,
                    name=metric.name,
                    display_name=metric.display_name,
                    expression=metric.expression,
                    description=metric.description,
                    dimensions=metric.dimensions,
                    source="curated",
                )
        suggestion.status = "accepted"
        suggestion.decided_at = now
        await self._repo.set_enrichment(asset_id, suggestion.model_dump(mode="json"))
        return await self._semantic.get_asset(asset_id)

    # ------------------------------------------------------------------ a scope
    async def start_run(self, request: EnrichRequest) -> EnrichRun:
        """Enrich every asset in a scope in the background; returns the run to poll."""
        self._require_model()
        asset_ids, proposed, documented = await self._select(request)
        run = EnrichRun(
            id=uuid4(),
            status="running" if asset_ids else "completed",
            total=len(asset_ids),
            skipped_proposed=proposed,
            skipped_documented=documented,
            message=None if asset_ids else self._nothing_to_do(proposed, documented),
            started_at=datetime.now(tz=UTC),
            finished_at=None if asset_ids else datetime.now(tz=UTC),
        )
        self._remember(run)
        if asset_ids:
            self._tasks[run.id] = asyncio.create_task(self._execute(run, asset_ids))
        return run

    def get_run(self, run_id: UUID) -> EnrichRun | None:
        return self._runs.get(run_id)

    def list_runs(self) -> list[EnrichRun]:
        return sorted(self._runs.values(), key=lambda r: r.started_at, reverse=True)

    async def _select(self, request: EnrichRequest) -> tuple[list[UUID], int, int]:
        """(chosen ids, skipped because already proposed, skipped because already documented)."""
        if request.asset_ids:
            return list(dict.fromkeys(request.asset_ids))[: request.limit], 0, 0
        rows, _ = await self._repo.list_assets(
            search=None,
            source_system=request.source_system,
            database=request.database,
            schema=request.schema_name,
            asset_type=None,
            kind=None,
            limit=2000,
            offset=0,
        )
        chosen: list[UUID] = []
        proposed = documented = 0
        for row in rows:
            enrichment = row.get("enrichment") or {}
            if enrichment.get("status") in ("suggested", "accepted") and not request.redo:
                proposed += 1
                continue
            if request.only_undocumented and not (
                not (row.get("description") or "").strip()
                or row.get("kind") == "unknown"
                or row.get("name_source") == "derived"
            ):
                documented += 1
                continue
            if len(chosen) < request.limit:
                chosen.append(row["id"])
        return chosen, proposed, documented

    @staticmethod
    def _nothing_to_do(proposed: int, documented: int) -> str:
        parts: list[str] = []
        if proposed:
            parts.append(f"{proposed} already {'have' if proposed > 1 else 'has'} a Claude proposal awaiting review or accepted")
        if documented:
            parts.append(f"{documented} {'are' if documented > 1 else 'is'} already described, classified and named")
        if not parts:
            return "Nothing to name: the scope has no datasets."
        return "Nothing new to name: " + "; ".join(parts) + "."

    async def _execute(self, run: EnrichRun, asset_ids: list[UUID]) -> None:
        semaphore = asyncio.Semaphore(self._concurrency)

        async def one(asset_id: UUID) -> None:
            async with semaphore:
                run.current = str(asset_id)
                try:
                    await self.suggest(asset_id)
                    run.done += 1
                except Exception as exc:  # noqa: BLE001 - one asset must not stop the run
                    run.failed += 1
                    run.error = f"{asset_id}: {exc}"[:300]
                    log.warning(
                        "semantic.enrichment.failed", asset_id=str(asset_id), error=str(exc)
                    )

        try:
            await asyncio.gather(*(one(a) for a in asset_ids))
            run.status = "completed" if run.done > 0 or not asset_ids else "failed"
        except asyncio.CancelledError:
            run.status = "cancelled"
            raise
        finally:
            run.current = None
            run.finished_at = datetime.now(tz=UTC)
            self._tasks.pop(run.id, None)

    def _remember(self, run: EnrichRun) -> None:
        self._runs[run.id] = run
        if len(self._runs) > self._keep_runs:
            oldest = sorted(self._runs.values(), key=lambda r: r.started_at)[: -self._keep_runs]
            for stale in oldest:
                if stale.status != "running":
                    self._runs.pop(stale.id, None)

    def describe(self) -> dict[str, Any]:
        return {"available": self.available, "reason": self._reason, "runs": len(self._runs)}
