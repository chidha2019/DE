"""Business glossary: name rules and Claude map datasets, columns and metrics to canonical terms.

Two mappers feed the same review queue. The *rule* mapper is deterministic: a column named
``policy_number`` matches the term "Policy Number" by its normalised name or a synonym, and a
dataset called ``fct_lapse_experience`` matches "Lapse" by token overlap. The *model* mapper
shows Claude the whole term catalogue and one dataset at a time and asks which terms apply, to
the dataset, each column and each metric, plus the business domain. Every proposal is a link
with a confidence and provenance, and nothing takes effect until a person accepts it: accepting
copies the term's synonyms onto the column or metric and gives the dataset its domain.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import re
from datetime import UTC, datetime
from typing import Any
from uuid import UUID, uuid4

from ech_core.exceptions import DependencyUnavailableError, InvalidRequestError, NotFoundError
from ech_core.llm.client import ModelClient
from ech_core.logging import get_logger
from ech_core.repositories.glossary_repository import GlossaryRepository
from ech_core.schemas.glossary import (
    Domain,
    DomainNode,
    GlossaryCoverage,
    Kpi,
    KpiUpdate,
    LinkCreate,
    LinksDecisionResult,
    MapRequest,
    MapRun,
    ProposeTermsRequest,
    TermCreate,
    TermDecision,
    TermDecisionResult,
    TermDetail,
    TermLink,
    TermLinkGroup,
    TermRow,
    TermUpdate,
)

log = get_logger(__name__)

SYSTEM_PROMPT = """You map insurance data to a controlled business glossary. You receive the glossary
(term keys with names, domains and synonyms) and one dataset with its columns and metrics. Answer
with JSON only: no prose, no markdown fences.

Rules:
- Use only term keys from the glossary. Never invent a key. Leave something unmapped rather than
  guess: a technical column such as a surrogate key maps to the data-platform terms or to nothing.
- domain_key: the business domain the dataset belongs to, chosen from the domains listed.
- asset_terms: up to 3 terms that name what one row of the dataset is about.
- field_terms: one term per column that clearly carries a business meaning; skip the rest.
- metric_terms: one term per metric that is a known business measure.
- confidence: 0 to 1; rationale at most 120 characters.
Output shape:
{"domain_key": "...", "asset_terms": [{"term_key": "...", "confidence": 0.0, "rationale": "..."}],
 "field_terms": [{"field": "column_name", "term_key": "...", "confidence": 0.0}],
 "metric_terms": [{"metric": "metric_name", "term_key": "...", "confidence": 0.0}]}"""

PROPOSE_SYSTEM_PROMPT = """You extend an insurance business glossary. You receive the names of the existing terms (never
propose these again, nor near-duplicates), the business domains, and columns and metrics from several datasets that no
existing term covers. Propose new canonical business terms only where a column or metric clearly carries a business
meaning an insurer would name. Skip technical columns (surrogate keys, load timestamps, hashes, flags with no business
meaning) and anything too vague to define. Answer with JSON only: no prose, no markdown fences.

Each term: a short canonical name in Title Case; kind (entity | attribute | measure | event | code); domain_key from
the domains listed, or null; a one-sentence definition; 2 to 6 synonyms people would say or type (lower case, including
the words of the column); the columns and metrics it covers, with dataset and name exactly as given; confidence 0 to 1;
a rationale of at most 120 characters. One term may cover several columns across datasets.
Output shape:
{"terms": [{"name": "...", "kind": "...", "domain_key": "...", "definition": "...", "synonyms": ["..."],
            "columns": [{"dataset": "...", "column": "..."}], "metrics": [{"dataset": "...", "metric": "..."}],
            "confidence": 0.0, "rationale": "..."}]}"""

# Links read to build the grouped review; the queue holds hundreds, not tens of thousands.
GROUP_SCAN = 5000
# Datasets one automatic pass looks at; the name rules are cheap, Claude only sees new or changed ones.
AUTO_MAP_LIMIT = 5000

_JSON_BLOCK = re.compile(r"\{.*\}", re.S)
_KINDS = {"entity", "attribute", "measure", "event", "code"}
_CAMEL = re.compile(r"(?<=[a-z0-9])(?=[A-Z])")
_NON_WORD = re.compile(r"[^a-z0-9]+")
_PREFIXES = {
    "fct", "fact", "dim", "dims", "dimension", "mv", "bridge", "brg", "ref", "lkp", "lookup",
    "stg", "raw", "src", "tbl", "vw", "v", "bronze", "silver", "gold",
    # aggregate prefixes on measures and metrics: total_premium, avg_claim_payment
    "total", "sum", "avg", "average", "cnt", "count", "num",
}
_ID_SUFFIXES = {"id", "key", "code", "cd", "num", "no", "number", "sk", "pk", "fk"}


def normalize(text: str) -> str:
    """``PolicyNumber`` / ``policy_number`` / ``Policy-Number`` -> ``policy number``."""
    return _NON_WORD.sub(" ", _CAMEL.sub(" ", text or "").lower()).strip()


def _strip_prefix(words: list[str]) -> list[str]:
    while len(words) > 1 and words[0] in _PREFIXES:
        words = words[1:]
    return words


def _conf(value: Any) -> float:
    try:
        return max(0.0, min(1.0, float(value)))
    except (TypeError, ValueError):
        return 0.5


Hit = tuple[dict[str, Any], float, str]


class TermIndex:
    """Normalised names and synonyms -> term, for the rule mapper."""

    def __init__(self, catalog: list[dict[str, Any]]) -> None:
        self.by_key = {t["key"]: t for t in catalog}
        self.exact: dict[str, tuple[dict[str, Any], str]] = {}
        for term in catalog:
            self.exact.setdefault(normalize(term["name"]), (term, "name"))
            for syn in term.get("synonyms") or []:
                self.exact.setdefault(normalize(str(syn)), (term, "synonym"))
        # Longest phrases first so "policy number" wins over "policy" in token matching.
        self.phrases = sorted(self.exact.items(), key=lambda kv: -len(kv[0].split()))

    def add(self, term: dict[str, Any]) -> None:
        """Index a term created during a run so later proposals de-duplicate against it."""
        self.by_key[term["key"]] = term
        self.exact.setdefault(normalize(term["name"]), (term, "name"))
        for syn in term.get("synonyms") or []:
            self.exact.setdefault(normalize(str(syn)), (term, "synonym"))
        self.phrases = sorted(self.exact.items(), key=lambda kv: -len(kv[0].split()))

    def lookup(self, name: str, synonyms: list[str]) -> dict[str, Any] | None:
        """The existing term a proposal already names: by its name or synonyms, or a proposed synonym equal to a term name."""
        hit = self.exact.get(normalize(name))
        if hit:
            return hit[0]
        for syn in synonyms:
            hit = self.exact.get(normalize(str(syn)))
            if hit and hit[1] == "name":
                return hit[0]
        return None

    def match(self, name: str, display_name: str = "") -> Hit | None:
        """(term, confidence, rationale) for a column, metric or dataset name, or None."""
        for candidate, label in ((normalize(name), "name"), (normalize(display_name), "display name")):
            if not candidate:
                continue
            hit = self.exact.get(candidate)
            if hit:
                term, how = hit
                return term, 0.92 if how == "name" else 0.86, f"{label} equals the term {how}"
            words = _strip_prefix(candidate.split())
            stripped = " ".join(words)
            if stripped != candidate and (hit := self.exact.get(stripped)):
                term, how = hit
                return term, 0.85, f"{label} without its prefix equals the term {how}"
            if len(words) > 1 and words[-1] in _ID_SUFFIXES and (hit := self.exact.get(" ".join(words[:-1]))):
                term, how = hit
                return term, 0.8, f"{label} is the term {how} plus an identifier suffix"
        return None

    def contains(self, name: str) -> Hit | None:
        """Token-overlap match for dataset names: the longest term phrase fully inside the name."""
        words = _strip_prefix(normalize(name).split())
        if not words:
            return None
        bag = set(words)
        for phrase, (term, how) in self.phrases:
            tokens = phrase.split()
            if tokens and set(tokens) <= bag and (len(tokens) > 1 or len(tokens[0]) > 3):
                return term, 0.7 if len(tokens) > 1 else 0.62, f"dataset name contains the term {how} '{phrase}'"
        return None


def build_prompt(
    catalog: list[dict[str, Any]],
    domains: list[dict[str, Any]],
    asset: dict[str, Any],
    fields: list[dict[str, Any]],
    metrics: list[dict[str, Any]],
) -> str:
    lines = ["GLOSSARY (key | name | domain | synonyms):"]
    for t in catalog:
        syns = ", ".join(str(s) for s in (t.get("synonyms") or [])[:5])
        lines.append(f"- {t['key']} | {t['name']} | {t.get('domain_key') or '-'} | {syns}")
    lines.append("")
    lines.append("DOMAINS (key | name): " + "; ".join(f"{d['key']} | {d['name']}" for d in domains))
    lines.append("")
    lines.append(f"DATASET: {asset['fqn']}")
    lines.append(f"business name: {asset.get('display_name') or asset['name']} / kind: {asset.get('kind')}")
    meaning = asset.get("summary") or asset.get("description") or ""
    if meaning:
        lines.append(f"meaning: {meaning[:300]}")
    lines.append("COLUMNS (name | role | type | description):")
    for f in fields[:80]:
        lines.append(f"- {f['name']} | {f.get('role')} | {f.get('data_type') or '-'} | {(f.get('description') or '')[:80]}")
    if len(fields) > 80:
        lines.append(f"- ... {len(fields) - 80} more columns")
    if metrics:
        lines.append("METRICS (name | expression):")
        for m in metrics[:30]:
            lines.append(f"- {m['name']} | {(m.get('expression') or '')[:100]}")
    return "\n".join(lines)


def parse_mapping(
    text: str,
    *,
    known_terms: set[str],
    known_domains: set[str],
    fields: list[dict[str, Any]],
    metrics: list[dict[str, Any]],
) -> dict[str, Any]:
    """Validate the model's answer: unknown keys, columns and metrics are dropped, confidences clamped."""
    match = _JSON_BLOCK.search(text or "")
    if not match:
        raise InvalidRequestError("model answer carried no JSON object")
    raw = json.loads(match.group(0))
    if not isinstance(raw, dict):
        raise InvalidRequestError("model answer was not a JSON object")
    conf = _conf
    field_ids = {f["name"].lower(): f["id"] for f in fields}
    metric_ids = {m["name"].lower(): m["id"] for m in metrics}
    for m in metrics:
        metric_ids.setdefault((m.get("display_name") or "").lower(), m["id"])
    domain = raw.get("domain_key")
    out: dict[str, Any] = {
        "domain_key": domain if isinstance(domain, str) and domain in known_domains else None,
        "asset_terms": [],
        "field_terms": [],
        "metric_terms": [],
    }
    for item in raw.get("asset_terms") or []:
        if isinstance(item, dict) and item.get("term_key") in known_terms:
            out["asset_terms"].append(
                {"term_key": item["term_key"], "confidence": conf(item.get("confidence")), "rationale": str(item.get("rationale") or "")[:200]}
            )
    for item in raw.get("field_terms") or []:
        if isinstance(item, dict) and item.get("term_key") in known_terms:
            fid = field_ids.get(str(item.get("field") or "").lower())
            if fid:
                out["field_terms"].append({"field_id": fid, "term_key": item["term_key"], "confidence": conf(item.get("confidence"))})
    for item in raw.get("metric_terms") or []:
        if isinstance(item, dict) and item.get("term_key") in known_terms:
            mid = metric_ids.get(str(item.get("metric") or "").lower())
            if mid:
                out["metric_terms"].append({"metric_id": mid, "term_key": item["term_key"], "confidence": conf(item.get("confidence"))})
    return out


def batch_targets(targets: dict[str, list[dict[str, Any]]], size: int) -> list[list[dict[str, Any]]]:
    """Group unmapped columns and metrics by dataset into batches of about `size` rows; big datasets are split."""
    by_asset: dict[UUID, dict[str, Any]] = {a["id"]: {"asset": a, "fields": [], "metrics": []} for a in targets["assets"]}
    for f in targets["fields"]:
        if f["asset_id"] in by_asset:
            by_asset[f["asset_id"]]["fields"].append(f)
    for m in targets["metrics"]:
        if m["asset_id"] in by_asset:
            by_asset[m["asset_id"]]["metrics"].append(m)
    batches: list[list[dict[str, Any]]] = []
    current: list[dict[str, Any]] = []
    count = 0
    for item in by_asset.values():
        rows = [("f", x) for x in item["fields"]] + [("m", x) for x in item["metrics"]]
        if not rows:
            continue
        if len(rows) <= size:
            chunks = [item]
        else:
            chunks = [
                {"asset": item["asset"], "fields": [x for k, x in part if k == "f"], "metrics": [x for k, x in part if k == "m"]}
                for part in (rows[i : i + size] for i in range(0, len(rows), size))
            ]
        for chunk in chunks:
            n = len(chunk["fields"]) + len(chunk["metrics"])
            if current and count + n > size:
                batches.append(current)
                current, count = [], 0
            current.append(chunk)
            count += n
    if current:
        batches.append(current)
    return batches


def split_batch(batch: list[dict[str, Any]]) -> list[list[dict[str, Any]]]:
    """Two halves of a batch (by dataset, or by rows inside a lone dataset); the batch itself when it cannot be split."""
    if len(batch) >= 2:
        middle = len(batch) // 2
        return [batch[:middle], batch[middle:]]
    chunk = batch[0]
    rows = [("f", x) for x in chunk["fields"]] + [("m", x) for x in chunk["metrics"]]
    if len(rows) < 2:
        return [batch]
    middle = len(rows) // 2
    return [
        [{"asset": chunk["asset"], "fields": [x for k, x in part if k == "f"], "metrics": [x for k, x in part if k == "m"]}]
        for part in (rows[:middle], rows[middle:])
    ]


def build_propose_prompt(existing_names: list[str], domains: list[dict[str, Any]], batch: list[dict[str, Any]]) -> str:
    lines = ["EXISTING TERMS (do not propose these or near-duplicates): " + "; ".join(existing_names), ""]
    lines.append("DOMAINS (key | name): " + "; ".join(f"{d['key']} | {d['name']}" for d in domains))
    for item in batch:
        asset = item["asset"]
        lines.append("")
        lines.append(f"DATASET: {asset['fqn']} / {asset.get('display_name') or asset['name']} / kind: {asset.get('kind')}")
        meaning = asset.get("summary") or asset.get("description") or ""
        if meaning:
            lines.append(f"meaning: {meaning[:200]}")
        if item["fields"]:
            lines.append("UNMAPPED COLUMNS (name | role | type | description):")
            for f in item["fields"]:
                lines.append(f"- {f['name']} | {f.get('role')} | {f.get('data_type') or '-'} | {(f.get('description') or '')[:80]}")
        if item["metrics"]:
            lines.append("UNMAPPED METRICS (name | expression):")
            for m in item["metrics"]:
                lines.append(f"- {m['name']} | {(m.get('expression') or '')[:100]}")
    return "\n".join(lines)


def parse_term_proposals(text: str, *, known_domains: set[str], batch: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Validate proposed terms: a name, a known kind and domain, and at least one column or metric from the batch."""
    match = _JSON_BLOCK.search(text or "")
    if not match:
        raise InvalidRequestError("model answer carried no JSON object")
    raw = json.loads(match.group(0))
    if not isinstance(raw, dict) or not isinstance(raw.get("terms"), list):
        raise InvalidRequestError("model answer carried no terms list")
    field_ids: dict[tuple[str, str], UUID] = {}
    metric_ids: dict[tuple[str, str], UUID] = {}
    for item in batch:
        fqn = item["asset"]["fqn"].lower()
        for f in item["fields"]:
            field_ids[(fqn, f["name"].lower())] = f["id"]
        for m in item["metrics"]:
            metric_ids[(fqn, m["name"].lower())] = m["id"]
            metric_ids.setdefault((fqn, (m.get("display_name") or "").lower()), m["id"])
    out: list[dict[str, Any]] = []
    for t in raw["terms"]:
        if not isinstance(t, dict):
            continue
        name = str(t.get("name") or "").strip()
        if not name or len(name) > 120:
            continue
        kind = t.get("kind") if t.get("kind") in _KINDS else "attribute"
        domain = t.get("domain_key") if isinstance(t.get("domain_key"), str) and t.get("domain_key") in known_domains else None
        raw_synonyms = t.get("synonyms") if isinstance(t.get("synonyms"), list) else []
        synonyms = [str(s).strip() for s in raw_synonyms if str(s).strip()][:8]
        fids: list[UUID] = []
        for ref in t.get("columns") or []:
            if isinstance(ref, dict):
                fid = field_ids.get((str(ref.get("dataset") or "").lower(), str(ref.get("column") or "").lower()))
                if fid and fid not in fids:
                    fids.append(fid)
        mids: list[UUID] = []
        for ref in t.get("metrics") or []:
            if isinstance(ref, dict):
                mid = metric_ids.get((str(ref.get("dataset") or "").lower(), str(ref.get("metric") or "").lower()))
                if mid and mid not in mids:
                    mids.append(mid)
        if not fids and not mids:
            continue
        out.append(
            {
                "name": name,
                "kind": kind,
                "domain_key": domain,
                "definition": str(t.get("definition") or "").strip()[:2000],
                "synonyms": synonyms,
                "field_ids": fids,
                "metric_ids": mids,
                "confidence": _conf(t.get("confidence")),
                "rationale": str(t.get("rationale") or "")[:200],
            }
        )
    return out


def mapping_fingerprint(asset: dict[str, Any], fields: list[dict[str, Any]], metrics: list[dict[str, Any]]) -> str:
    """A hash of what the source says about a dataset: a sync that changes it sends the dataset to Claude again.

    Only source-owned metadata counts. Display names, synonyms and the domain change when someone accepts a
    suggestion, and that must not cost another Claude call.
    """
    payload = {
        "fqn": asset["fqn"],
        "description": asset.get("description") or "",
        "fields": sorted([f["name"], f.get("data_type") or "", f.get("description") or ""] for f in fields),
        "metrics": sorted([m["name"], m.get("expression") or "", m.get("description") or ""] for m in metrics),
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()


def _by_asset(rows: list[dict[str, Any]]) -> dict[UUID, list[dict[str, Any]]]:
    out: dict[UUID, list[dict[str, Any]]] = {}
    for row in rows:
        out.setdefault(row["asset_id"], []).append(row)
    return out


class GlossaryService:
    def __init__(
        self,
        repo: GlossaryRepository,
        *,
        model: ModelClient | None,
        unavailable_reason: str | None = None,
        concurrency: int = 3,
    ) -> None:
        self._repo = repo
        self._model = model
        self._reason = unavailable_reason
        self._concurrency = concurrency
        self._runs: dict[UUID, MapRun] = {}
        self._tasks: dict[UUID, asyncio.Task[None]] = {}

    @property
    def model_available(self) -> bool:
        return self._model is not None

    # ------------------------------------------------------------------ reads
    async def domains(self) -> list[DomainNode]:
        rows = await self._repo.domains()
        parents = [DomainNode(**r) for r in rows if not r["parent_key"]]
        by_key = {p.key: p for p in parents}
        for r in rows:
            if r["parent_key"] and r["parent_key"] in by_key:
                by_key[r["parent_key"]].children.append(Domain(**r))
        for p in parents:
            p.children.sort(key=lambda c: (c.sort_order, c.name))
            p.term_count += sum(c.term_count for c in p.children)
            p.kpi_count += sum(c.kpi_count for c in p.children)
        parents.sort(key=lambda p: (p.sort_order, p.name))
        return parents

    async def terms(self, **kw: Any) -> tuple[list[TermRow], int]:
        rows, total = await self._repo.terms(**kw)
        return [TermRow(**r) for r in rows], total

    async def term(self, term_id: UUID) -> TermDetail:
        row = await self._repo.term(term_id)
        if row is None:
            raise NotFoundError(f"term {term_id} not found")
        links, _ = await self._repo.links(status=None, target_type=None, target_id=None, term_id=term_id, limit=500, offset=0)
        return TermDetail(**row, links=[TermLink(**link) for link in links])

    async def create_term(self, body: TermCreate) -> TermRow:
        key = normalize(body.name).replace(" ", "_") or f"term_{uuid4().hex[:8]}"
        row = await self._repo.create_term(
            key=key,
            name=body.name.strip(),
            definition=body.definition.strip(),
            domain_key=body.domain_key,
            kind=body.kind,
            synonyms=[s.strip() for s in body.synonyms if s.strip()],
        )
        return TermRow(**row)

    async def update_term(self, term_id: UUID, body: TermUpdate) -> TermRow:
        fields = body.model_dump(exclude_unset=True)
        if fields.get("synonyms") is not None:
            fields["synonyms"] = [s.strip() for s in fields["synonyms"] if s.strip()]
        row = await self._repo.update_term(term_id, **fields)
        if row is None:
            raise NotFoundError(f"term {term_id} not found")
        return TermRow(**row)

    async def links(self, **kw: Any) -> tuple[list[TermLink], int]:
        rows, total = await self._repo.links(**kw)
        return [TermLink(**r) for r in rows], total

    async def decide(self, link_id: UUID, decision: str) -> TermLink:
        row = await self._repo.decide_link(link_id, "accepted" if decision == "accept" else "rejected")
        if row is None:
            raise NotFoundError(f"link {link_id} not found")
        return TermLink(**row)

    async def link_groups(
        self, *, status: str | None, target_type: str | None, term_status: str | None, limit: int, offset: int
    ) -> tuple[list[TermLinkGroup], int]:
        """Proposals grouped by term and target name, biggest first, so one decision can cover a column in every table."""
        rows, _ = await self._repo.links(
            status=status, target_type=target_type, target_id=None, term_id=None, term_status=term_status, limit=GROUP_SCAN, offset=0
        )
        groups: dict[str, list[TermLink]] = {}
        for row in rows:
            link = TermLink(**row)
            label = (link.target_label or "").strip()
            groups.setdefault(f"{link.term_id}:{link.target_type}:{label.lower()}", []).append(link)
        out: list[TermLinkGroup] = []
        for key, links in groups.items():
            first = links[0]
            confidences = [link.confidence for link in links]
            out.append(
                TermLinkGroup(
                    key=key,
                    term_id=first.term_id,
                    term_key=first.term_key,
                    term_name=first.term_name,
                    domain_key=first.domain_key,
                    target_type=first.target_type,
                    target_label=(first.target_label or "").strip(),
                    count=len(links),
                    min_confidence=min(confidences),
                    max_confidence=max(confidences),
                    sources=sorted({link.source for link in links}),
                    links=sorted(links, key=lambda link: (link.target_context or "", -link.confidence)),
                )
            )
        out.sort(key=lambda grp: (-grp.count, -grp.max_confidence, grp.target_label.lower(), grp.term_name))
        return out[offset : offset + limit], len(out)

    async def decide_many(self, ids: list[UUID], decision: str) -> LinksDecisionResult:
        """One decision for a group of proposals; each is applied as if decided alone (synonyms, domains)."""
        status = "accepted" if decision == "accept" else "rejected"
        decided = missing = 0
        for link_id in dict.fromkeys(ids):
            if await self._repo.decide_link(link_id, status) is None:
                missing += 1
            else:
                decided += 1
        return LinksDecisionResult(decision="accept" if decision == "accept" else "reject", decided=decided, missing=missing)

    async def create_link(self, body: LinkCreate) -> TermLink:
        row = await self._repo.create_curated_link(term_id=body.term_id, target_type=body.target_type, target_id=body.target_id)
        if row is None:
            raise NotFoundError("link could not be created")
        return TermLink(**row)

    async def kpis(self, *, domain: str | None) -> list[Kpi]:
        return [Kpi(**r) for r in await self._repo.kpis(domain=domain)]

    async def update_kpi(self, kpi_id: UUID, body: KpiUpdate) -> Kpi:
        fields = body.model_dump(exclude_unset=True, exclude={"clear_metric"})
        if body.clear_metric:
            fields["metric_id"] = None
        row = await self._repo.update_kpi(kpi_id, **fields)
        if row is None:
            raise NotFoundError(f"kpi {kpi_id} not found")
        return Kpi(**row)

    async def decide_term(self, term_id: UUID, body: TermDecision) -> TermDecisionResult:
        """Accept a proposed term (it becomes curated; optionally its pending links too) or reject it (deleted with its links)."""
        accept = body.decision == "accept"
        if not await self._repo.decide_term(term_id, accept=accept):
            raise NotFoundError(f"term {term_id} is not a proposed term")
        links_accepted = 0
        if accept and body.accept_links:
            for link_id in await self._repo.suggested_link_ids(term_id):
                await self._repo.decide_link(link_id, "accepted")
                links_accepted += 1
        return TermDecisionResult(id=term_id, decision=body.decision, links_accepted=links_accepted)

    async def coverage(self) -> GlossaryCoverage:
        return GlossaryCoverage(**await self._repo.coverage(), model_available=self.model_available)

    # ------------------------------------------------------------------ mapping
    async def auto_runs(self, limit: int) -> list[dict[str, Any]]:
        return await self._repo.auto_runs(limit)

    def get_run(self, run_id: UUID) -> MapRun | None:
        return self._runs.get(run_id)

    def list_runs(self) -> list[MapRun]:
        return sorted(self._runs.values(), key=lambda r: r.started_at, reverse=True)

    def require_model(self) -> None:
        if self._model is None:
            raise DependencyUnavailableError(self._reason or "no model configured")

    async def start_map(self, request: MapRequest) -> MapRun:
        """Rules first (synchronously, they are cheap), then Claude per dataset in the background."""
        if request.asset_ids:
            asset_ids = list(dict.fromkeys(request.asset_ids))
        else:
            asset_ids = await self._repo.scope_asset_ids(
                source_system=request.source_system, database=request.database, schema=request.schema_name, limit=request.limit
            )
        run = MapRun(id=uuid4(), status="running", total=0, started_at=datetime.now(tz=UTC))
        self._remember(run)
        if not asset_ids:
            run.status = "completed"
            run.message = "Nothing to map: the scope has no datasets."
            run.finished_at = datetime.now(tz=UTC)
            return run
        catalog = await self._repo.catalog()
        targets = await self._repo.mapping_targets(asset_ids)
        run.rule_links = await self._rule_map(catalog, targets)
        if request.use_model and self._model is not None:
            run.total = len(targets["assets"])
            self._tasks[run.id] = asyncio.create_task(self._model_map(run, catalog, targets))
            return run
        run.status = "completed"
        run.finished_at = datetime.now(tz=UTC)
        if request.use_model:
            run.message = f"Name rules proposed {run.rule_links} links; Claude is not configured ({self._reason or 'no model'})."
        else:
            run.message = f"Name rules proposed {run.rule_links} links."
        return run

    async def auto_map(self, source_system: str) -> tuple[MapRun, int]:
        """After a sync: name rules on every dataset of the source, Claude only on new or changed ones.

        Awaited rather than backgrounded, so the caller can record the outcome. Returns the run and how many
        datasets the name rules looked at.
        """
        run = MapRun(id=uuid4(), status="running", trigger="sync", started_at=datetime.now(tz=UTC))
        self._remember(run)
        try:
            asset_ids = await self._repo.scope_asset_ids(source_system=source_system, database=None, schema=None, limit=AUTO_MAP_LIMIT)
            if not asset_ids:
                return self._finish(run, f"Nothing to map: no {source_system} datasets."), 0
            catalog = await self._repo.catalog()
            targets = await self._repo.mapping_targets(asset_ids)
            datasets = len(targets["assets"])
            run.rule_links = await self._rule_map(catalog, targets)
            if self._model is None:
                note = f"Name rules proposed {run.rule_links} links across {datasets} datasets; Claude is not configured ({self._reason or 'no model'})."
                return self._finish(run, note), datasets
            changed = await self._changed(targets)
            run.skipped = datasets - len(changed["assets"])
            run.total = len(changed["assets"])
            if not changed["assets"]:
                note = f"Name rules proposed {run.rule_links} links; all {datasets} datasets are unchanged since Claude last mapped them."
                return self._finish(run, note), datasets
            await self._model_map(run, catalog, changed)
            return run, datasets
        except Exception as exc:
            run.status = "failed"
            run.error = str(exc)[:300]
            run.finished_at = datetime.now(tz=UTC)
            raise

    async def _changed(self, targets: dict[str, list[dict[str, Any]]]) -> dict[str, list[dict[str, Any]]]:
        """The datasets, with their columns and metrics, whose source metadata differs from what Claude last saw."""
        fields = _by_asset(targets["fields"])
        metrics = _by_asset(targets["metrics"])
        seen = await self._repo.map_fingerprints([a["id"] for a in targets["assets"]])
        assets = [
            a for a in targets["assets"] if seen.get(a["id"]) != mapping_fingerprint(a, fields.get(a["id"], []), metrics.get(a["id"], []))
        ]
        keep = {a["id"] for a in assets}
        return {
            "assets": assets,
            "fields": [f for f in targets["fields"] if f["asset_id"] in keep],
            "metrics": [m for m in targets["metrics"] if m["asset_id"] in keep],
        }

    @staticmethod
    def _finish(run: MapRun, message: str) -> MapRun:
        run.status = "completed"
        run.message = message
        run.finished_at = datetime.now(tz=UTC)
        return run

    def _remember(self, run: MapRun) -> None:
        self._runs[run.id] = run
        if len(self._runs) > 20:
            for old in sorted(self._runs.values(), key=lambda r: r.started_at)[: len(self._runs) - 20]:
                self._runs.pop(old.id, None)

    # ------------------------------------------------------------------ proposing new terms
    async def start_propose(self, request: ProposeTermsRequest) -> MapRun:
        """Claude proposes new terms for the columns and metrics no term covers; they wait for review like links do."""
        self.require_model()
        if request.asset_ids:
            asset_ids = list(dict.fromkeys(request.asset_ids))
        else:
            asset_ids = await self._repo.scope_asset_ids(
                source_system=request.source_system, database=request.database, schema=request.schema_name, limit=request.limit
            )
        run = MapRun(id=uuid4(), mode="propose", status="running", started_at=datetime.now(tz=UTC))
        self._remember(run)
        targets = await self._repo.unmapped_targets(asset_ids) if asset_ids else {"assets": [], "fields": [], "metrics": []}
        batches = batch_targets(targets, request.batch_size)
        if not batches:
            run.status = "completed"
            run.message = "Nothing to propose: every column and metric in the scope already carries or awaits a term."
            run.finished_at = datetime.now(tz=UTC)
            return run
        run.total = len(batches)
        self._tasks[run.id] = asyncio.create_task(self._propose_terms(run, batches, len(targets["fields"]), len(targets["metrics"])))
        return run

    async def _propose_terms(self, run: MapRun, batches: list[list[dict[str, Any]]], n_fields: int, n_metrics: int) -> None:
        model = self._model
        assert model is not None
        domains = await self._repo.domains()
        known_domains = {d["key"] for d in domains}
        index = TermIndex(await self._repo.catalog(include_proposed=True))
        existing_names = sorted(t["name"] for t in index.by_key.values())
        semaphore = asyncio.Semaphore(self._concurrency)
        lock = asyncio.Lock()  # de-duplication must see every term the run has already created

        async def attempt(batch: list[dict[str, Any]]) -> None:
            first = batch[0]["asset"]["fqn"]
            async with semaphore:
                run.current = first if len(batch) == 1 else f"{first} +{len(batch) - 1}"
                turn = await model.complete(
                    system=PROPOSE_SYSTEM_PROMPT,
                    tools=[],
                    messages=[{"role": "user", "content": build_propose_prompt(existing_names, domains, batch)}],
                )
            proposals = parse_term_proposals(turn.text, known_domains=known_domains, batch=batch)
            for proposal in proposals:
                async with lock:
                    await self._file_proposal(proposal, index, turn.model, run)

        async def one(batch: list[dict[str, Any]], depth: int = 0) -> bool:
            """True when the batch, or every half it was split into, went through."""
            first = batch[0]["asset"]["fqn"]
            try:
                await attempt(batch)
                return True
            except Exception as exc:  # noqa: BLE001 - a gateway timeout or a cut-off answer: halve and retry
                halves = split_batch(batch)
                if depth < 2 and len(halves) == 2:
                    log.warning("glossary.propose.split", asset=first, depth=depth, error=str(exc)[:160])
                    results = await asyncio.gather(*(one(h, depth + 1) for h in halves))
                    return all(results)
                run.error = f"{first}: {exc}"[:300]
                log.warning("glossary.propose.failed", asset=first, error=str(exc))
                return False

        async def top(batch: list[dict[str, Any]]) -> None:
            if await one(batch):
                run.done += 1
            else:
                run.failed += 1

        try:
            await asyncio.gather(*(top(b) for b in batches))
            run.status = "completed" if run.done > 0 else "failed"
            run.message = (
                f"Claude proposed {run.terms_proposed} new terms and {run.model_links} links "
                f"from {n_fields} unmapped columns and {n_metrics} unmapped metrics."
            )
        except asyncio.CancelledError:
            run.status = "cancelled"
            raise
        finally:
            run.current = None
            run.finished_at = datetime.now(tz=UTC)

    async def _file_proposal(self, proposal: dict[str, Any], index: TermIndex, model_name: str | None, run: MapRun) -> None:
        """A proposed term becomes a 'proposed' row, or links to the existing term it duplicates; evidence becomes pending links."""
        term = index.lookup(proposal["name"], proposal["synonyms"])
        why = proposal["rationale"]
        if term is None:
            key = normalize(proposal["name"]).replace(" ", "_") or f"term_{uuid4().hex[:8]}"
            created = await self._repo.create_proposed_term(
                key=key,
                name=proposal["name"],
                definition=proposal["definition"],
                domain_key=proposal["domain_key"],
                kind=proposal["kind"],
                synonyms=proposal["synonyms"],
                proposed_by=model_name,
                rationale=proposal["rationale"],
            )
            if created is None:
                term = await self._repo.term_by_key(key)
            else:
                term = created
                index.add(created)
                run.terms_proposed += 1
        else:
            why = f"Claude proposed '{proposal['name']}', which the term {term['name']} already covers"
        if term is None:
            return
        for fid in proposal["field_ids"]:
            run.model_links += await self._propose(term, "field", fid, proposal["confidence"], "model", why, model_name)
        for mid in proposal["metric_ids"]:
            run.model_links += await self._propose(term, "metric", mid, proposal["confidence"], "model", why, model_name)

    async def _propose(self, term: dict[str, Any], target_type: str, target_id: UUID, hit_or_conf: Any, source: str, why: str, model: str | None = None) -> int:
        _, new = await self._repo.upsert_link(
            term_id=term["id"], target_type=target_type, target_id=target_id, confidence=float(hit_or_conf), source=source, rationale=why, model=model
        )
        return int(new)

    async def _rule_map(self, catalog: list[dict[str, Any]], targets: dict[str, list[dict[str, Any]]]) -> int:
        index = TermIndex(catalog)
        created = 0
        for asset in targets["assets"]:
            hit = index.match(asset["name"], asset.get("display_name") or "") or index.contains(asset["name"])
            if hit:
                term, confidence, why = hit
                created += await self._propose(term, "asset", asset["id"], confidence, "rule", why)
        for field in targets["fields"]:
            hit = index.match(field["name"], field.get("display_name") or "")
            if hit:
                term, confidence, why = hit
                created += await self._propose(term, "field", field["id"], confidence, "rule", why)
        for metric in targets["metrics"]:
            hit = index.match(metric["name"], metric.get("display_name") or "")
            if hit:
                term, confidence, why = hit
                created += await self._propose(term, "metric", metric["id"], confidence, "rule", why)
        return created

    async def _model_map(self, run: MapRun, catalog: list[dict[str, Any]], targets: dict[str, list[dict[str, Any]]]) -> None:
        model = self._model
        assert model is not None
        domains = await self._repo.domains()
        known_terms = {t["key"] for t in catalog}
        known_domains = {d["key"] for d in domains}
        by_key = {t["key"]: t for t in catalog}
        fields_by_asset: dict[UUID, list[dict[str, Any]]] = {}
        for f in targets["fields"]:
            fields_by_asset.setdefault(f["asset_id"], []).append(f)
        metrics_by_asset: dict[UUID, list[dict[str, Any]]] = {}
        for m in targets["metrics"]:
            metrics_by_asset.setdefault(m["asset_id"], []).append(m)
        semaphore = asyncio.Semaphore(self._concurrency)

        async def one(asset: dict[str, Any]) -> None:
            async with semaphore:
                run.current = asset["fqn"]
                fields = fields_by_asset.get(asset["id"], [])
                metrics = metrics_by_asset.get(asset["id"], [])
                try:
                    prompt = build_prompt(catalog, domains, asset, fields, metrics)
                    for attempt in range(2):  # one retry: gateway timeouts come in bursts
                        try:
                            turn = await model.complete(system=SYSTEM_PROMPT, tools=[], messages=[{"role": "user", "content": prompt}])
                            break
                        except Exception:  # noqa: BLE001
                            if attempt == 1:
                                raise
                            await asyncio.sleep(1)
                    mapping = parse_mapping(turn.text, known_terms=known_terms, known_domains=known_domains, fields=fields, metrics=metrics)
                    created = 0
                    for item in mapping["asset_terms"]:
                        created += await self._propose(by_key[item["term_key"]], "asset", asset["id"], item["confidence"], "model", item["rationale"], turn.model)
                    for item in mapping["field_terms"]:
                        created += await self._propose(
                            by_key[item["term_key"]], "field", item["field_id"], item["confidence"], "model",
                            "proposed by Claude from the column name, role and description", turn.model,
                        )
                    for item in mapping["metric_terms"]:
                        created += await self._propose(
                            by_key[item["term_key"]], "metric", item["metric_id"], item["confidence"], "model",
                            "proposed by Claude from the metric name and expression", turn.model,
                        )
                    await self._repo.save_map_fingerprint(asset["id"], mapping_fingerprint(asset, fields, metrics), turn.model)
                    run.model_links += created
                    run.done += 1
                except Exception as exc:  # noqa: BLE001 - one dataset must not stop the run
                    run.failed += 1
                    run.error = f"{asset['fqn']}: {exc}"[:300]
                    log.warning("glossary.map.failed", asset=asset["fqn"], error=str(exc))

        try:
            await asyncio.gather(*(one(a) for a in targets["assets"]))
            run.status = "completed" if run.done > 0 or not targets["assets"] else "failed"
            run.message = f"Name rules proposed {run.rule_links} links; Claude proposed {run.model_links} across {run.done} datasets" + (
                f"; {run.skipped} unchanged datasets skipped." if run.skipped else "."
            )
        except asyncio.CancelledError:
            run.status = "cancelled"
            raise
        finally:
            run.current = None
            run.finished_at = datetime.now(tz=UTC)
