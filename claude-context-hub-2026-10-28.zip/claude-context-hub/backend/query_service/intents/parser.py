"""Turn a ticket (title + description, plus any answers) into a StructuredIntent.

Rules extract what is unambiguous (paths, S3 locations, database.schema.table, keywords); Claude fills in
the rest and names open questions. Without a model the rule pass alone decides, and anything it could not
find becomes a question for the reporter.
"""

from __future__ import annotations

import json
import re
from typing import Any

from ech_core.exceptions import InvalidRequestError
from ech_core.llm.client import ModelClient
from ech_core.schemas.intents import IntentSource, IntentTarget, StructuredIntent

SYSTEM_PROMPT = """You turn a data engineering request into a structured intent for an insurance data platform.
Answer with JSON only, no prose, no markdown fences. Never invent names: a database, schema, table, folder,
bucket or external volume the ticket does not state is null and becomes an open question. Keep questions
concrete and few (at most 4). Business terms are the insurance concepts the data is about (policy, premium,
claim, customer, producer ...), using the glossary names given when they fit. Acceptance criteria are the
checks the ticket states or plainly implies for "done" (row counts match, keys unique, no nulls in a column,
loaded by 6am), each one short and testable, at most 6; none when the ticket gives none.

Kinds: "ingest_csv_to_iceberg" loads files into tables; "model_layer" builds a silver or gold layer from tables
already in Snowflake (the source database and schema go in "source", the target database and schema in "target",
the target table stays null); "gold_fact" is one gold fact or KPI table; "other" is anything else. For
model_layer a data modeler designs the tables, columns and keys, so never ask about them. "layer" is the
medallion layer the work builds (bronze for raw loads). "depends_on" lists the tickets (e.g. KAN-3) the
ticket says must land first. Files land in S3 (s3_bucket, s3_prefix) or in Azure Blob Storage (azure_account,
azure_container, azure_prefix); "storage_provider" says which. A folder is copied as the ticket writes it, whole
path included. When the ticket loads one table per file and names them with a pattern (<FILE>_ICEBERG), put the
pattern in "table_pattern" and leave "table" null. An existing stage or file format the ticket names goes in
"stage" / "file_format" (as DATABASE.SCHEMA.NAME), never in "table". The planner chooses each table's
BASE_LOCATION on the external volume, the stage and file format names and the task schedule, so never ask about them.

Output shape:
{"kind": "ingest_csv_to_iceberg" | "model_layer" | "gold_fact" | "other",
 "layer": "bronze" | "silver" | "gold" | null, "depends_on": ["..."],
 "summary": "one sentence",
 "source": {"folder": "...|null", "file_pattern": "*.csv", "storage_provider": "s3" | "azure",
            "s3_bucket": "...|null", "s3_prefix": "...|null",
            "azure_account": "...|null", "azure_container": "...|null", "azure_prefix": "...|null",
            "storage_integration": "...|null", "stage": "...|null", "file_format": "...|null",
            "delimiter": ",", "header": true, "encoding": "utf-8", "database": "...|null", "schema": "...|null"},
 "target": {"platform": "snowflake", "database": "...|null", "schema": "...|null", "table": "...|null", "table_pattern": "...|null",
            "table_format": "iceberg", "external_volume": "...|null", "base_location": "...|null",
            "load_mode": "append" | "full_refresh" | "merge", "merge_keys": ["..."]},
 "grain": "what one row is", "business_terms": ["..."], "columns_hint": ["..."],
 "freshness": "daily" | "hourly" | "weekly" | "on demand", "owner": "...",
 "acceptance_criteria": ["..."], "open_questions": ["..."], "confidence": 0.0}"""

_JSON_BLOCK = re.compile(r"\{.*\}", re.S)
_S3 = re.compile(r"s3://([a-z0-9.\-]+)/?([\w\-./]*)", re.I)
_PATH = re.compile(r"(?<![\w/])((?:\./|/|[A-Za-z]:\\)?(?:[\w.\-]+[\\/])+[\w.\-]*)")
_TRIPLE = re.compile(r"\b([A-Za-z_][\w$]*)\.([A-Za-z_][\w$]*)\.([A-Za-z_][\w$]*)\b")
_VOLUME = re.compile(r"external\s+volume\s+[\"'`]?([\w$]+)", re.I)
_INTEGRATION = re.compile(r"storage\s+integration\s+[\"'`]?([\w$]+)", re.I)
# "Table names: <FILE>_ICEBERG" (or {file}_iceberg, RAW_<FILE>): one table per file, named by the pattern.
_TABLE_PATTERN = re.compile(r"([A-Za-z0-9_]*)[<{]\s*file(?:\s*name)?\s*[>}]([A-Za-z0-9_]*)", re.I)
_STAGE_BEFORE = re.compile(r"\bstage\s*[\"'`]?\s*$", re.I)
_FORMAT_BEFORE = re.compile(r"\bfile\s+format\s*[\"'`]?\s*$", re.I)
_EXAMPLE_BEFORE = re.compile(r"(?:→|->|=>)\s*[\"'`]?\s*$")
_PROSE = {"on", "in", "at", "to", "for", "the", "a", "an", "and", "or", "of", "is", "name", "named", "called", "that", "which", "with", "tbc", "tbd"}


def _object_names(pattern: re.Pattern[str], text: str) -> list[str]:
    """Names after 'external volume' / 'storage integration' that look like Snowflake objects, not the next word of a sentence."""
    return [n for n in pattern.findall(text) if n.lower() not in _PROSE and (n.isupper() or "_" in n or any(ch.isdigit() for ch in n))]


# Azure Blob Storage: a URL names account, container and folder at once; phrases name them one by one.
_AZURE_URL = re.compile(r"(?:azure|https?)://([a-z0-9]{3,24})\.blob\.core\.windows\.net/([a-z0-9](?:[a-z0-9-]{1,61}[a-z0-9])?)(?:/([\w\-./]*))?", re.I)
_AZURE_WORDS = re.compile(r"\bazure\b|\bblob\s+storage\b|\.blob\.core\.windows\.net", re.I)
_S3_WORDS = re.compile(r"s3://|\bS3\b")
_NAMED = r"\s*([:=]|\b(?:is|named|called)\b)?\s*([\"'`])?"
_AZ_ACCOUNT = re.compile(r"storage\s+account(?:\s+name)?" + _NAMED + r"([A-Za-z0-9]{3,24})\b", re.I)
_AZ_CONTAINER = re.compile(r"\bcontainer(?:\s+name)?" + _NAMED + r"([A-Za-z0-9][A-Za-z0-9-]{1,61}[A-Za-z0-9])\b", re.I)
_AZ_PREFIX = re.compile(r"\b(?:blob\s+)?prefix" + _NAMED + r"([\w\-.]+(?:/[\w\-.]+)*)/?", re.I)
_AZ_PROSE = _PROSE | {
    "account", "and", "are", "be", "been", "will", "through", "via", "where", "names", "from", "into", "landing", "should",
    "must", "has", "have", "was", "were", "confirmed", "not", "yet", "it", "its", "container", "this", "these", "they", "per",
}


_FILLER = {"to", "be", "tbc", "tbd", "the", "a", "an", "and", "not", "yet", "confirmed", "unknown", "pending"}


def _named(pattern: re.Pattern[str], text: str) -> list[tuple[int, str]]:
    """(position, name) of each name the pattern finds. A quoted name counts as is; one introduced by 'named', 'is' or
    ':' unless it is filler ('is to be confirmed'); a bare one only when it is not the next word of a sentence."""
    out: list[tuple[int, str]] = []
    for m in pattern.finditer(text):
        marker, quote, name = m.group(1), m.group(2), m.group(3)
        word = name.lower()
        if quote or (marker and word not in _FILLER) or (not marker and word not in _AZ_PROSE):
            out.append((m.start(), name))
    return out


def _azure(body: str, source: IntentSource) -> None:
    """Provider (whichever of S3 and Azure the text names last), then account, container and prefix: the latest mention wins."""
    s3_at = max((m.start() for m in _S3_WORDS.finditer(body)), default=-1)
    azure_at = max((m.start() for m in _AZURE_WORDS.finditer(body)), default=-1)
    if azure_at > s3_at:
        source.storage_provider = "azure"
    urls = list(_AZURE_URL.finditer(body))
    picks: dict[str, list[tuple[int, str]]] = {
        "azure_account": [(m.start(), m.group(1)) for m in urls] + _named(_AZ_ACCOUNT, body),
        "azure_container": [(m.start(), m.group(2)) for m in urls] + _named(_AZ_CONTAINER, body),
        "azure_prefix": [(m.start(), (m.group(3) or "").strip("/")) for m in urls if (m.group(3) or "").strip("/")] + _named(_AZ_PREFIX, body),
    }
    for name, found in picks.items():
        if found:
            value = max(found)[1].strip("/")
            setattr(source, name, value if name == "azure_prefix" else value.lower())
    if urls:
        source.storage_provider = "azure"
_FRESH = re.compile(r"\b(hourly|daily|weekly|monthly|every\s+\w+|on demand|once)\b", re.I)
_CRITERIA_HEADING = re.compile(r"^\s*(?:acceptance criteria|definition of done|done when)\s*:?\s*$", re.I)
_BULLET = re.compile(r"^\s*(?:[-*•]|\d+[.)])\s+(.+)$")
_LAYER = re.compile(r"\b(bronze|silver|gold|curated)\b", re.I)
_LAYER_PAIR = re.compile(r"\b([A-Za-z_][\w$]*)\.(BRONZE|SILVER|GOLD)\b", re.I)
_ISSUE = re.compile(r"\b([A-Z][A-Z0-9_]+-\d+)\b")
_UPSTREAM = {"silver": "bronze", "gold": "silver"}


def _layers(text: str) -> list[str]:
    """Layers in the order the text names them; 'curated' is gold."""
    return [("gold" if m.group(1).lower() == "curated" else m.group(1).lower()) for m in _LAYER.finditer(text)]


_TITLE_LAYER = re.compile(r"^\s*\W*(bronze|silver|gold|curated)\b", re.I)
_BUILT = re.compile(r"\b(?:into|build|builds|building|create|creates|load|loads)\s+(?:the\s+|a\s+|an\s+)?(?:[a-z-]+\s+)?(bronze|silver|gold|curated)\b", re.I)
_URL = re.compile(r"\b[a-z][a-z0-9+.-]*://\S+", re.I)


def _target_layer(text: str, title: str = "") -> str | None:
    """The layer the work builds: the one a title starts with ("Silver: ..."), else the last one named after a
    building verb ("build the conformed silver layer"; "reconcile to bronze" names a layer it only reads), else
    the deepest one named."""
    lead = _TITLE_LAYER.match(title or "")
    if lead:
        return "gold" if lead.group(1).lower() == "curated" else lead.group(1).lower()
    named = _layers(text)
    if not named:
        return None
    built = _BUILT.findall(text)
    if built:
        last = built[-1].lower()
        return "gold" if last == "curated" else last
    order = ["bronze", "silver", "gold"]
    return max(named, key=order.index)


def acceptance_criteria(text: str) -> list[str]:
    """The bullets under an 'Acceptance criteria' (or 'Definition of done') heading, as Jira tickets write them."""
    found: list[str] = []
    inside = False
    for line in (text or "").splitlines():
        if _CRITERIA_HEADING.match(line):
            inside = True
            continue
        if not inside:
            continue
        bullet = _BULLET.match(line)
        if bullet:
            found.append(bullet.group(1).strip())
        elif line.strip():
            inside = False  # the list ended at the first line that is not a bullet
    return found[:6]


def rule_parse(title: str, text: str) -> StructuredIntent:
    """What the wording states outright; the model refines it and the rest becomes questions."""
    body = f"{title}\n{text}"
    low = body.lower()
    layer = _target_layer(body, title)
    kind = "other"
    if "csv" in low or ("ingest" in low and ("file" in low or "folder" in low)):
        kind = "ingest_csv_to_iceberg"
    elif layer in ("silver", "gold"):
        kind = "model_layer"
    elif "fact" in low or "kpi" in low or "metric" in low:
        kind = "gold_fact"
    source = IntentSource()
    mentions = list(_S3.finditer(body))
    if mentions:
        s3 = mentions[-1]  # answers come after the ticket text, so the latest mention is the current one
        source.s3_bucket = s3.group(1).rstrip(".")
        source.s3_prefix = s3.group(2).strip("/").rstrip(".") or None
    _azure(body, source)
    plain = _URL.sub(" ", body)  # a storage URL's host (account.blob.core) is neither a folder nor DATABASE.SCHEMA.TABLE
    folders = [
        m.group(1).rstrip("/\\")
        for m in _PATH.finditer(plain)
        if not m.group(1).lower().endswith(".csv") and ("/" in m.group(1) or "\\" in m.group(1))
    ]
    if folders:
        # A ticket can name the code's folder too; the files' folder is the one that says csv, data or files.
        source.folder = next((f for f in folders if re.search(r"csv|data|files|extract", f.rsplit("\\", 1)[-1].rsplit("/", 1)[-1], re.I)), folders[0])
    target = IntentTarget()
    pattern = _TABLE_PATTERN.search(plain)
    if pattern:
        target.table_pattern = f"{pattern.group(1)}<FILE>{pattern.group(2)}".upper()
    triples: list[re.Match[str]] = []
    for m in _TRIPLE.finditer(plain):
        if m.group(1).lower() in ("s3", "e", "i", "www") or (source.folder and m.group(0) in source.folder):
            continue
        before = plain[max(0, m.start() - 40) : m.start()]
        name = m.group(0).upper()
        if _STAGE_BEFORE.search(before):
            source.stage = source.stage or name  # an existing stage to load through, not a table to load into
        elif _FORMAT_BEFORE.search(before):
            source.file_format = source.file_format or name
        elif not (target.table_pattern and _EXAMPLE_BEFORE.search(before)):  # "city.csv → DB.BRONZE.CITY_ICEBERG" is an example
            triples.append(m)
    # DATABASE.<LAYER>.TABLE before any other triple.
    triple = next((m for m in triples if m.group(2).upper() in ("BRONZE", "SILVER", "GOLD", "RAW", "CURATED")), triples[0] if triples else None)
    if triple:
        target.database, target.schema_name, target.table = triple.group(1).upper(), triple.group(2).upper(), triple.group(3).upper()
    elif target.table_pattern or source.stage:
        # One table per file into the schema of the stage the ticket names ("existing stage DB.BRONZE.X").
        known = next((n for n in (source.stage, source.file_format) if n), None)
        if known:
            target.database, target.schema_name = known.split(".")[0], known.split(".")[1]
    if target.table_pattern:
        target.table = None
    # The latest mention wins: answers come after the ticket text and override it.
    volumes = _object_names(_VOLUME, body)
    if volumes:
        target.external_volume = volumes[-1]
    integrations = _object_names(_INTEGRATION, body)
    if integrations:
        source.storage_integration = integrations[-1]
    if "iceberg" in low:
        target.table_format = "iceberg"
    if "merge" in low or "upsert" in low:
        target.load_mode = "merge"
    elif "full refresh" in low or "truncate" in low or "replace" in low:
        target.load_mode = "full_refresh"
    if kind == "ingest_csv_to_iceberg" and not target.database:
        # "into OMNICLAIM.BRONZE" without a table: a set of tables, one per file.
        pair = next((m for m in _LAYER_PAIR.finditer(body) if not (source.folder and m.group(0) in source.folder)), None)
        if pair:
            target.database, target.schema_name = pair.group(1).upper(), pair.group(2).upper()
    if kind == "model_layer" and layer:
        pairs = [(m.group(1).upper(), m.group(2).upper()) for m in _LAYER_PAIR.finditer(body)]
        database = next((db for db, _ in pairs), target.database)
        target.database = target.database or database
        target.schema_name = layer.upper()
        target.table = None
        source.database = database
        source.schema_name = _UPSTREAM[layer].upper()
        source.folder = None
    fresh = _FRESH.search(body)
    questions: list[str] = []
    if kind == "model_layer" and not target.database:
        questions.append(f"Which Snowflake database holds the {_UPSTREAM.get(layer or 'silver', 'bronze')} tables to build the {layer} layer from?")
    if kind == "ingest_csv_to_iceberg":
        if not source.folder and not source.s3_bucket and not source.azure_container:
            questions.append("Where are the CSV files: a folder under the data directory, an S3 bucket and prefix, or an Azure Blob container?")
        if source.storage_provider == "azure" and not (source.azure_account and source.azure_container):
            questions.append("Which Azure storage account and container do the files land in?")
        if not target.table and not (target.table_pattern and target.database and target.schema_name):
            questions.append("Which Snowflake database, schema and table should the data land in (DATABASE.SCHEMA.TABLE)?")
        if target.table_format == "iceberg" and not target.external_volume:
            questions.append("Which Snowflake external volume should the Iceberg tables use?")
    return StructuredIntent(
        kind=kind,  # type: ignore[arg-type]
        summary=title.strip(),
        source=source,
        target=target,
        freshness=fresh.group(1).lower() if fresh else "daily",
        acceptance_criteria=acceptance_criteria(text),
        layer=layer or ("bronze" if kind == "ingest_csv_to_iceberg" and "bronze" in low else None),  # type: ignore[arg-type]
        depends_on=list(dict.fromkeys(_ISSUE.findall(body))),
        open_questions=questions,
        confidence=0.4 if questions else 0.6,
    )


def _merge(rules: StructuredIntent, model: StructuredIntent) -> StructuredIntent:
    """The model's view, with anything it left null filled from the rules."""
    out = model.model_copy(deep=True)
    if out.kind == "other" and rules.kind != "other":
        out.kind = rules.kind
    if rules.source.storage_provider == "azure":
        out.source.storage_provider = "azure"  # the rules see the words "Azure" / "blob storage"; a model that kept the default is overruled
    ruled, modelled = (rules.source.folder or "").replace("\\", "/").rstrip("/"), (out.source.folder or "").replace("\\", "/").strip("/")
    if ruled and modelled and ruled.lower().endswith("/" + modelled.lower()):
        out.source.folder = rules.source.folder  # the model kept only the tail ("csv") of the path the ticket writes out
    for name in ("folder", "s3_bucket", "s3_prefix", "storage_integration", "stage", "file_format", "azure_account", "azure_container", "azure_prefix"):
        if getattr(out.source, name) is None:
            setattr(out.source, name, getattr(rules.source, name))
    for name in ("database", "schema_name", "table", "table_pattern", "external_volume"):
        if getattr(out.target, name) is None:
            setattr(out.target, name, getattr(rules.target, name))
    named = {n.upper().rsplit(".", 1)[-1] for n in (out.source.stage, out.source.file_format) if n}
    if out.target.table_pattern or (out.target.table and out.target.table.upper().rsplit(".", 1)[-1] in named):
        out.target.table = None  # a table set named by its pattern, or a stage / file format read as the target table
    if out.kind == "model_layer" or rules.kind == "model_layer":
        # The rules know which layers the words name; a model that still sees a file load is overruled only when no files are named.
        if out.kind != "ingest_csv_to_iceberg":
            out.kind = "model_layer"
            out.layer = out.layer or rules.layer
            for name in ("database", "schema_name"):
                if getattr(out.source, name) is None:
                    setattr(out.source, name, getattr(rules.source, name))
            out.target.schema_name = out.target.schema_name or rules.target.schema_name
            out.target.table = None
    out.layer = out.layer or rules.layer
    out.depends_on = list(dict.fromkeys([*out.depends_on, *rules.depends_on]))
    if not out.summary:
        out.summary = rules.summary
    if not out.acceptance_criteria:
        out.acceptance_criteria = rules.acceptance_criteria
    return out


def parse_model_answer(text: str) -> StructuredIntent:
    match = _JSON_BLOCK.search(text or "")
    if not match:
        raise InvalidRequestError("model answer carried no JSON object")
    raw: Any = json.loads(match.group(0))
    if not isinstance(raw, dict):
        raise InvalidRequestError("model answer was not a JSON object")
    # The model may answer null where the schema wants a string or a default: drop nulls so defaults apply.
    for key in ("summary", "grain", "owner", "freshness"):
        if raw.get(key) is None:
            raw.pop(key, None)
    for key in ("source", "target"):
        nested = raw.get(key)
        raw[key] = {k: v for k, v in nested.items() if v is not None} if isinstance(nested, dict) else {}
    if raw["source"].get("storage_provider") not in ("s3", "azure"):
        raw["source"].pop("storage_provider", None)
    for name in ("azure_account", "azure_container"):
        if isinstance(raw["source"].get(name), str):
            raw["source"][name] = raw["source"][name].strip().lower() or None
    if raw.get("kind") not in ("ingest_csv_to_iceberg", "model_layer", "gold_fact", "other"):
        raw["kind"] = "other"
    if raw.get("layer") not in ("bronze", "silver", "gold"):
        raw["layer"] = None
    raw["depends_on"] = [str(k).upper() for k in (raw.get("depends_on") or []) if _ISSUE.fullmatch(str(k).upper())][:6]
    raw["open_questions"] = [str(q) for q in (raw.get("open_questions") or []) if str(q).strip()][:4]
    raw["business_terms"] = [str(t) for t in (raw.get("business_terms") or [])][:12]
    raw["columns_hint"] = [str(c) for c in (raw.get("columns_hint") or [])][:60]
    raw["acceptance_criteria"] = [str(c).strip() for c in (raw.get("acceptance_criteria") or []) if str(c).strip()][:6]
    try:
        raw["confidence"] = max(0.0, min(1.0, float(raw.get("confidence") or 0)))
    except (TypeError, ValueError):
        raw["confidence"] = 0.5
    return StructuredIntent.model_validate(raw)


def build_prompt(title: str, text: str, answers: list[str], glossary_names: list[str], data_dir: str) -> str:
    lines = [f"TICKET TITLE: {title.strip()}", "TICKET BODY:", text.strip() or "(empty)"]
    if answers:
        lines += ["", "ANSWERS THE REPORTER GAVE TO EARLIER QUESTIONS (they override the ticket where they differ):"] + [f"- {a}" for a in answers]
    lines += ["", f"Local CSV folders are relative to the data directory '{data_dir}'."]
    if glossary_names:
        lines += ["", "GLOSSARY TERM NAMES: " + "; ".join(glossary_names[:150])]
    return "\n".join(lines)


def _answered(question: str, intent: StructuredIntent) -> bool:
    q = question.lower()
    if intent.kind == "model_layer" and any(w in q for w in ("column", "key", "grain", "table", "identifier", "dimension", "fact", "model")):
        return True  # the data modeler proposes the tables, columns and keys; the reporter reviews them in the spec
    if "owner" in q or "who " in q:
        return True  # the reporter is the owner until someone says otherwise; never worth blocking on
    if "append" in q or "merge" in q or "upsert" in q or "full refresh" in q:
        return True  # the load mode defaults to append and the spec says so; a reporter can change it with an answer
    if ("csv" in q or "folder" in q or "bucket" in q or "where" in q) and (intent.source.folder or intent.source.s3_bucket):
        return True
    if ("table" in q or "schema" in q or "database" in q) and intent.target.table and intent.target.database:
        return True
    if "external volume" in q and intent.target.external_volume:
        return True
    if "storage integration" in q and intent.source.storage_integration:
        return True
    if ("storage account" in q or "container" in q) and "integration" not in q and intent.source.azure_account and intent.source.azure_container:
        return True
    return False


async def parse_intent(
    model: ModelClient | None, *, title: str, text: str, answers: list[str], glossary_names: list[str], data_dir: str
) -> StructuredIntent:
    rules = rule_parse(title, "\n".join([text, *answers]))
    if model is None:
        return rules
    turn = await model.complete(
        system=SYSTEM_PROMPT, tools=[], messages=[{"role": "user", "content": build_prompt(title, text, answers, glossary_names, data_dir)}]
    )
    merged = _merge(rules, parse_model_answer(turn.text))
    if any("s3://" in a for a in answers):
        # A location given in an answer overrides whatever the ticket said; the rules keep the latest mention.
        merged.source.s3_bucket, merged.source.s3_prefix = rules.source.s3_bucket, rules.source.s3_prefix
    if any(_AZURE_URL.search(a) or _named(_AZ_ACCOUNT, a) or _named(_AZ_CONTAINER, a) or _named(_AZ_PREFIX, a) for a in answers):
        # Azure names given in an answer override the ticket's (and anything the model kept from it).
        for name in ("storage_provider", "azure_account", "azure_container", "azure_prefix"):
            value = getattr(rules.source, name)
            if value:
                setattr(merged.source, name, value)
    if any(_object_names(_VOLUME, a) for a in answers):
        merged.target.external_volume = rules.target.external_volume
    if any(_object_names(_INTEGRATION, a) for a in answers):
        merged.source.storage_integration = rules.source.storage_integration
    for name, value in (("external_volume", merged.target.external_volume), ("storage_integration", merged.source.storage_integration)):
        if value and value.lower() in _PROSE:
            # The model read the next word of a sentence ("an external volume on Azure") as the name.
            setattr(merged.target if name == "external_volume" else merged.source, name, None)
    merged.open_questions = [q for q in merged.open_questions if not _answered(q, merged)]
    if not merged.open_questions and merged.kind == "ingest_csv_to_iceberg":
        merged.open_questions = [q for q in rules.open_questions if not _answered(q, merged)]
    return merged
