"""The approved-to-be spec as the steps the pipeline runs: read, land, stage, table, load, validate, schedule,
govern and, when the table feeds models, downstream. Derived on read; a step needing attention says why.
"""

from __future__ import annotations

from ech_core.schemas.intents import PipelineSpec, WorkflowMetric, WorkflowStep
from query_service.intents.generator import REJECTS
from query_service.intents.landing import landing_of

_DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]


def describe_cron(expr: str) -> str:
    """Five-field cron in words for the common shapes; anything else is quoted."""
    if not expr or expr == "manual":
        return "on demand"
    parts = expr.split()
    if len(parts) != 5:
        return f"on cron {expr}"
    minute, hour, dom, month, dow = parts
    if not (minute.isdigit() and dom == "*" and month == "*"):
        return f"on cron {expr} UTC"
    if hour == "*" and dow == "*":
        return f"hourly at minute {int(minute)}"
    if not hour.isdigit():
        return f"on cron {expr} UTC"
    at = f"{int(hour):02d}:{int(minute):02d} UTC"
    if dow == "*":
        return f"daily at {at}"
    if dow.isdigit() and int(dow) < 7:
        return f"every {_DAYS[int(dow)]} at {at}"
    return f"on cron {expr} UTC"


def _land_step(spec: PipelineSpec, what: str) -> WorkflowStep:
    """Upload to S3 or Azure Blob Storage; the parts the ticket leaves open come from the environment."""
    landing = landing_of(spec.source)
    tool = "the Azure SDK" if landing.provider == "azure" else "boto3"
    unset = [name for name in landing.env if "${" + name + "}" in landing.url]
    return WorkflowStep(
        key="land",
        kind="land",
        title=f"Land in {landing.label}",
        summary=f"The runner uploads {what} to {landing.url} with {tool}",
        items=["pipeline.py upload <folder>", *([f"{', '.join(unset)} from the environment"] if unset else [])],
        metrics=[WorkflowMetric(label="provider", value=landing.label)],
        status="attention" if unset else "ready",
        note=f"The ticket leaves {', '.join(unset)} open; the deploy settings decide it." if unset else "",
    )


def _ingest_steps(spec: PipelineSpec) -> list[WorkflowStep]:
    s, t = spec.source, spec.target
    where = f"s3://{s.s3_bucket}/{(s.s3_prefix or '').strip('/')}" if s.s3_bucket and not s.folder else (s.folder or "?")
    steps = [
        WorkflowStep(
            key="source",
            kind="source",
            title="Read the files",
            summary=f"{s.file_pattern} from {where}",
            items=spec.sampled_files[:4],
            metrics=[
                WorkflowMetric(label="files sampled", value=str(len(spec.sampled_files))),
                WorkflowMetric(label="rows sampled", value=str(spec.sampled_rows)),
                WorkflowMetric(label="columns", value=str(len(spec.columns))),
            ],
            status="ready" if spec.sampled_files else "attention",
            note="" if spec.sampled_files else "No CSV files were found to sample yet; the columns come from the ticket.",
        )
    ]
    steps.append(_land_step(spec, "each file"))
    steps.append(
        WorkflowStep(
            key="stage",
            kind="stage",
            title="Stage and file format",
            summary=f"External stage {spec.stage_name or '?'} reads the landing prefix through {spec.file_format_name or '?'}",
            metrics=[
                WorkflowMetric(label="delimiter", value=repr(s.delimiter)),
                WorkflowMetric(label="header", value="yes" if s.header else "no"),
                WorkflowMetric(label="encoding", value=s.encoding),
            ],
        )
    )
    table = ".".join(p or "?" for p in (t.database, t.schema_name, t.table))
    required = sum(1 for c in spec.columns if not c.nullable)
    iceberg = t.table_format == "iceberg"
    steps.append(
        WorkflowStep(
            key="table",
            kind="table",
            title="Create the Iceberg table" if iceberg else "Create the table",
            summary=table,
            items=[f"{c.name} {c.type}{'' if c.nullable else ' NOT NULL'}" for c in spec.columns[:6]] + ([f"… {len(spec.columns) - 6} more"] if len(spec.columns) > 6 else []),
            metrics=[
                WorkflowMetric(label="columns", value=str(len(spec.columns))),
                WorkflowMetric(label="required", value=str(required)),
                *([WorkflowMetric(label="volume", value=t.external_volume or "not set")] if iceberg else []),
                *([WorkflowMetric(label="location", value=t.base_location)] if iceberg and t.base_location else []),
                *([WorkflowMetric(label="types from catalog", value=str(spec.catalog_match.types_adopted))] if spec.catalog_match and spec.catalog_match.types_adopted else []),
            ],
            status="attention" if iceberg and not t.external_volume else "ready",
            note="No external volume yet; the generated SQL leaves a placeholder." if iceberg and not t.external_volume else "",
        )
    )
    if t.load_mode == "merge":
        keys = ", ".join(t.merge_keys)
        load = WorkflowStep(
            key="load",
            kind="load",
            title=f"Merge on {keys}" if keys else "Merge",
            summary=f"Copy into a staging table, then MERGE INTO {table}; the latest row per key wins",
            items=spec.transformations,
            status="ready" if keys else "attention",
            note="" if keys else "Merge needs a key; name one or the load appends.",
        )
    elif t.load_mode == "full_refresh":
        load = WorkflowStep(key="load", kind="load", title="Replace the table", summary=f"Truncate {table}, then COPY INTO it from the stage", items=spec.transformations)
    else:
        load = WorkflowStep(key="load", kind="load", title="Copy new files in", summary=f"COPY INTO {table} from the stage; files already loaded are skipped", items=spec.transformations)
    steps.append(load)
    return steps


def _more(items: list[str], shown: int) -> list[str]:
    return items[:shown] + ([f"… {len(items) - shown} more"] if len(items) > shown else [])


def _prepare_step(spec: PipelineSpec) -> list[WorkflowStep]:
    if not spec.create:
        return []
    t = spec.target
    names = [f"database {t.database}"] * ("database" in spec.create) + [f"schema {t.database}.{t.schema_name}"]
    return [WorkflowStep(key="prepare", kind="prepare", title="Create what is missing", summary="Validation found these missing in Snowflake; the setup creates them", items=names)]


def _set_steps(spec: PipelineSpec) -> list[WorkflowStep]:
    """A table set: one table per file, each with its contract's columns, key and checks."""
    s, t = spec.source, spec.target
    columns = sum(len(x.columns) for x in spec.tables)
    steps = [
        *_prepare_step(spec),
        WorkflowStep(
            key="source",
            kind="source",
            title=f"Read {len(spec.tables)} files",
            summary=f"{s.folder or '?'}: one table per file",
            items=_more([x.source_file for x in spec.tables], 4),
            metrics=[
                WorkflowMetric(label="files", value=str(len(spec.tables))),
                WorkflowMetric(label="rows", value=str(spec.sampled_rows)),
                WorkflowMetric(label="systems", value=str(len({x.source_system for x in spec.tables if x.source_system}) or 1)),
            ],
        ),
        _land_step(spec, "every file, keeping its folder,"),
        WorkflowStep(
            key="stage",
            kind="stage",
            title="Stage and file format",
            summary=f"One stage {spec.stage_name} over the landing prefix, read through {spec.file_format_name}",
            metrics=[WorkflowMetric(label="delimiter", value=repr(s.delimiter)), WorkflowMetric(label="header", value="yes" if s.header else "no")],
        ),
    ]
    present = sum(1 for x in spec.tables if x.exists)
    lacking = [x.name for x in spec.tables if x.missing_columns]
    steps.append(
        WorkflowStep(
            key="table",
            kind="table",
            title=f"Create {len(spec.tables)} Iceberg tables",
            summary=f"{t.database}.{t.schema_name}, each shaped by its repository contract",
            items=_more([f"{x.name} · {len(x.columns)} columns · key {', '.join(x.keys) or '-'}" for x in spec.tables], 6),
            metrics=[
                WorkflowMetric(label="tables", value=str(len(spec.tables))),
                WorkflowMetric(label="columns", value=str(columns)),
                WorkflowMetric(label="volume", value=t.external_volume or "not set"),
                *([WorkflowMetric(label="already exist", value=str(present))] if present else []),
                *([WorkflowMetric(label="lack contract columns", value=str(len(lacking)))] if lacking else []),
            ],
            status="attention" if not t.external_volume or lacking else "ready",
            note=(
                "No external volume yet; the generated SQL leaves a placeholder."
                if not t.external_volume
                else f"{', '.join(lacking)} lack columns their contracts declare." if lacking else ""
            ),
        )
    )
    verb = "Replace each table" if t.load_mode == "full_refresh" else "Merge each table on its key" if t.load_mode == "merge" else "Copy new files into each table"
    steps.append(WorkflowStep(key="load", kind="load", title=verb, summary="Each table's COPY reads only its own file from the stage", items=spec.transformations))
    return steps


def _designed_steps(spec: PipelineSpec) -> list[WorkflowStep]:
    """A modelled layer compiled from the team's design files: bind the sources, create as the DDL says, merge with rejects.
    Item lists go out whole: the page shows the first few and opens the rest."""
    t, src = spec.target, spec.source
    sources = sorted({s for m in spec.models for s in m.sources})
    waiting = sorted({w for m in spec.models for w in m.waiting_on})
    built = [m for m in spec.models if m.sql.strip()]
    rejected = sum((m.duplicates or 0) + sum(m.nulls.values()) for m in spec.models)
    rows = sum(m.rows or 0 for m in spec.models)
    hashed = sum(1 for m in spec.models if m.hash_column)
    return [
        WorkflowStep(
            key="source",
            kind="source",
            title=f"Bind {len(sources)} {(src.schema_name or 'source').lower()} tables",
            summary=f"Each logical source of the mapping, matched in {src.database or t.database}.{src.schema_name or '?'} by name and by the columns it reads",
            items=[s.rsplit('.', 1)[-1] for s in sources],
            metrics=[WorkflowMetric(label="bound", value=str(len(sources))), *([WorkflowMetric(label="not loaded yet", value=str(len(waiting)))] if waiting else [])],
            status="attention" if waiting else "ready",
            note=f"{len(waiting)} logical source(s) are not in the layer below yet; their branches wait." if waiting else "",
        ),
        WorkflowStep(
            key="model",
            kind="model",
            title=f"Compile {len(spec.models)} tables from the design",
            summary=f"From {', '.join(f.rsplit('/', 1)[-1] for f in src.mapping_files)}; each SELECT dry-run read-only in Snowflake",
            items=[f"{m.name} · {m.rows:,} rows" if m.rows is not None else f"{m.name} · waits" for m in spec.models],
            metrics=[
                WorkflowMetric(label="built now", value=f"{len(built)} of {len(spec.models)}"),
                WorkflowMetric(label="rows in the dry run", value=f"{rows:,}"),
                *([WorkflowMetric(label="to reject", value=f"{rejected:,}")] if rejected else []),
            ],
            status="attention" if rejected or len(built) < len(spec.models) else "ready",
            note=f"About {rejected:,} rows break a NOT NULL column or repeat a key; they go to {REJECTS} with the reason." if rejected else "",
        ),
        WorkflowStep(
            key="table",
            kind="table",
            title=f"Create {len(spec.models)} tables as the DDL writes them",
            summary=f"{t.database}.{t.schema_name}, {'native Snowflake tables' if t.table_format == 'native' else 'Iceberg tables'} with the design's comments, plus {REJECTS}",
            metrics=[WorkflowMetric(label="columns", value=str(sum(len(m.columns) for m in spec.models))), WorkflowMetric(label="keys", value=str(sum(1 for m in spec.models if m.keys)))],
        ),
        WorkflowStep(
            key="load",
            kind="load",
            title="Merge in dependency order",
            summary="Stage each SELECT, reject what breaks the DDL with a reason, merge the rest on the key"
            + (f"; {hashed} table(s) update only when the change hash differs" if hashed else ""),
            items=[f"{m.name} ← {', '.join(s.rsplit('.', 1)[-1] for s in m.sources) or 'waits'}" for m in spec.models],
        ),
    ]


def _model_steps(spec: PipelineSpec) -> list[WorkflowStep]:
    """A modelled layer: the data modeler's tables, built from the layer below."""
    if spec.source.mapping_files:
        return _designed_steps(spec)
    t, src = spec.target, spec.source
    sources = sorted({s for m in spec.models for s in m.sources})
    problems = [f for m in spec.models for f in m.findings if not f.startswith("compiles")]
    kinds: dict[str, int] = {}
    for m in spec.models:
        kinds[m.kind] = kinds.get(m.kind, 0) + 1
    return [
        WorkflowStep(
            key="source",
            kind="source",
            title=f"Read {len(sources)} {(src.schema_name or 'source').lower()} tables",
            summary=f"{src.database or t.database}.{src.schema_name or '?'}, as loaded in Snowflake",
            items=_more([s.rsplit('.', 1)[-1] for s in sources], 6),
            metrics=[WorkflowMetric(label="tables", value=str(len(sources)))],
        ),
        WorkflowStep(
            key="model",
            kind="model",
            title=f"Model {len(spec.models)} tables",
            summary="Proposed by the data modeler from the repository's models, the ticket and the data",
            items=_more([f"{m.name} ({m.kind}) · {m.grain}" for m in spec.models], 6),
            metrics=[
                *[WorkflowMetric(label=k + ("s" if n != 1 else ""), value=str(n)) for k, n in sorted(kinds.items())],
                WorkflowMetric(label="follow the repository", value=str(sum(1 for m in spec.models if m.exemplar))),
                *([WorkflowMetric(label="findings", value=str(len(problems)))] if problems else []),
            ],
            status="attention" if problems else "ready",
            note=problems[0] if problems else "",
        ),
        WorkflowStep(
            key="table",
            kind="table",
            title=f"Create {len(spec.models)} Iceberg tables",
            summary=f"{t.database}.{t.schema_name}",
            metrics=[WorkflowMetric(label="columns", value=str(sum(len(m.columns) for m in spec.models))), WorkflowMetric(label="volume", value=t.external_volume or "not set")],
            status="ready" if t.external_volume else "attention",
            note="" if t.external_volume else "No external volume yet; the generated SQL leaves a placeholder.",
        ),
        WorkflowStep(
            key="load",
            kind="load",
            title="Build in dependency order",
            summary="Each table from its SELECT; full refresh rebuilds, merge upserts on the key",
            items=_more([f"{m.name} ← {', '.join(s.rsplit('.', 1)[-1] for s in m.sources)}" for m in spec.models], 6),
        ),
    ]


def build_workflow(spec: PipelineSpec | None) -> list[WorkflowStep]:
    """The steps, in run order; empty until the planner has written a spec."""
    if spec is None:
        return []
    if spec.kind == "ingest_csv_to_iceberg":
        steps = _set_steps(spec) if spec.tables else _ingest_steps(spec)
    elif spec.kind == "model_layer" and spec.models:
        steps = _model_steps(spec)
    else:
        steps = []
    tests = spec.tests or [x for table in spec.tables for x in table.tests] or [x for m in spec.models for x in m.tests]
    columns = spec.columns or [c for table in spec.tables for c in table.columns]
    if not steps:
        t = spec.target
        steps.append(
            WorkflowStep(
                key="table",
                kind="table",
                title="Build the table",
                summary=".".join(p or "?" for p in (t.database, t.schema_name, t.table)),
                items=spec.transformations,
                status="attention",
                note="No generator template for this kind yet; a person builds it from the spec.",
            )
        )

    failing = [x for x in tests if x.sample_failures]
    copied = sum(1 for x in tests if x.origin)
    # The generated pipeline reconciles each table it loads: source against target by rows, keys and amount totals.
    reconciled = (len(spec.tables) or 1) if spec.kind == "ingest_csv_to_iceberg" else sum(1 for m in spec.models if m.sql.strip())
    steps.append(
        WorkflowStep(
            key="validate",
            kind="validate",
            title="Validate",
            summary=f"{len(tests)} check(s) run after every load; a failure stops the task"
            + (f". Then {reconciled} table(s) are reconciled against their source; a gap rejected rows do not explain fails the load" if reconciled else ""),
            items=[f"{x.name} ({x.kind.replace('_', ' ')})" for x in tests[:8]] + ([f"… {len(tests) - 8} more"] if len(tests) > 8 else []),
            metrics=[
                WorkflowMetric(label="checks", value=str(len(tests))),
                *([WorkflowMetric(label="reconciled", value=str(reconciled))] if reconciled else []),
                *([WorkflowMetric(label="from the exemplar", value=str(copied))] if copied else []),
                *([WorkflowMetric(label="failing on samples", value=str(len(failing)))] if failing else []),
            ],
            status="attention" if failing else "ready",
            note=f"{len(failing)} check(s) already fail on the sampled rows." if failing else "",
        )
    )
    steps.append(
        WorkflowStep(
            key="schedule",
            kind="schedule",
            title="Schedule",
            summary=f"A Snowflake task runs it {describe_cron(spec.schedule)}",
            metrics=[WorkflowMetric(label="cron", value=spec.schedule)],
        )
    )
    terms = sorted({c.term_name for c in columns if c.term_name})
    mapped = sum(1 for c in columns if c.term_key)
    steps.append(
        WorkflowStep(
            key="govern",
            kind="govern",
            title="Govern",
            summary=f"{mapped} of {len(columns)} column(s) carry a glossary term",
            items=terms[:8],
            metrics=[WorkflowMetric(label="terms", value=str(len(terms)))],
            status="attention" if columns and not mapped else "ready",
            note="No column maps to a glossary term yet." if columns and not mapped else "",
        )
    )
    match = spec.catalog_match
    if match is not None or spec.joins:
        joins = [f"{', '.join(j.columns)} → {j.to_table}.{', '.join(j.to_columns)} ({j.kind.replace('_', ' ')})" for j in spec.joins]
        summary = f"Resembles {match.fqn}: {len(match.matched_columns)} of {match.feed_columns} columns" if match else "Joins the catalog"
        if spec.joins:
            summary += f"; joins {len({j.to_table for j in spec.joins})} catalog table(s)"
        steps.append(
            WorkflowStep(
                key="relate",
                kind="relate",
                title="Relate",
                summary=summary,
                items=joins[:8] + ([f"… {len(joins) - 8} more"] if len(joins) > 8 else []),
                metrics=[
                    *([WorkflowMetric(label="column match", value=f"{round(match.coverage * 100)}%")] if match else []),
                    WorkflowMetric(label="joins", value=str(len(spec.joins))),
                    *([WorkflowMetric(label="declared key", value=", ".join(match.key))] if match and match.key else []),
                ],
                status="attention" if match is not None and match.duplicate else "ready",
                note=f"Possible duplicate: {match.duplicate_reason}." if match is not None and match.duplicate else "",
            )
        )
    if spec.downstream:
        gaps = sum(1 for d in spec.downstream for c in d.columns if c.status in ("needs", "missing"))
        steps.append(
            WorkflowStep(
                key="downstream",
                kind="downstream",
                title="Feed downstream",
                summary=(
                    f"{len(spec.downstream)} model(s) in the repository read these tables; the next intents build them"
                    if spec.tables
                    else f"{len(spec.downstream)} model(s) read the table this one resembles and would read it too"
                ),
                items=[f"{d.table} · {d.repo}" for d in spec.downstream[:6]],
                metrics=[WorkflowMetric(label="models", value=str(len(spec.downstream))), *([WorkflowMetric(label="columns to supply", value=str(gaps))] if gaps else [])],
                status="attention" if gaps else "ready",
                note=f"{gaps} downstream column(s) have no source in the new feed yet." if gaps else "",
            )
        )
    return steps
