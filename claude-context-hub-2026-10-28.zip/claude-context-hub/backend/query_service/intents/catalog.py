"""Ground a new feed in the semantic layer: the catalog table it most resembles, that table's declared key,
column types and joins, and whether the target would duplicate a table the catalog already holds.

A candidate is any table or view the semantic search finds for the target name, the business terms or the
feed's identifier columns. The best is the one holding the largest share of the feed's columns (at least
three, and at least 40%): a wide catalog table that carries half of a narrow feed is still the right one.
Base tables come before views, since only tables declare the keys and joins the plan takes.
Near-identical column sets (Jaccard >= 0.8), or a target that already exists, are flagged as duplicates.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any
from uuid import UUID

from ech_core.logging import get_logger
from ech_core.schemas.intents import SpecCatalogMatch, SpecColumn, SpecJoin

log = get_logger(__name__)

_MIN_MATCHED = 3
_MIN_COVERAGE = 0.4
_DUPLICATE_JACCARD = 0.8
_MAX_CANDIDATES = 10
_JOIN_KINDS = ("foreign_key", "join_declared", "join_inferred")
_IDENTIFIER = re.compile(r"(_ID|_NUMBER|_NO|_KEY|_CODE)$")
_DECIMAL = re.compile(r"^(?:NUMBER|DECIMAL|NUMERIC)\s*\(\s*(\d+)\s*(?:,\s*(\d+)\s*)?\)$")


def _norm(name: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", name.upper())


def type_family(data_type: str) -> str:
    t = (data_type or "").strip().upper()
    if t.startswith(("NUMBER", "DECIMAL", "NUMERIC", "INT", "BIGINT", "SMALLINT", "TINYINT", "LONG", "FLOAT", "DOUBLE", "REAL")):
        return "numeric"
    if t.startswith(("VARCHAR", "TEXT", "STRING", "CHAR", "NVARCHAR")):
        return "text"
    if t == "DATE":
        return "date"
    if t.startswith(("TIMESTAMP", "DATETIME")):
        return "timestamp"
    if t.startswith("BOOL"):
        return "boolean"
    return "other"


def _scale(data_type: str) -> int | None:
    """Decimal places a numeric type keeps; None for floating point."""
    t = data_type.strip().upper()
    match = _DECIMAL.match(t)
    if match:
        return int(match.group(2) or 0)
    if t.startswith(("FLOAT", "DOUBLE", "REAL")):
        return None
    return 0


def snowflake_type(data_type: str) -> str:
    """The catalog's type in the form the generated Snowflake DDL uses (Databricks names included)."""
    t = data_type.strip().upper()
    family = type_family(t)
    if family == "numeric":
        match = _DECIMAL.match(t)
        if match:
            return f"NUMBER({match.group(1)},{match.group(2) or 0})"
        if t.startswith(("FLOAT", "DOUBLE", "REAL")):
            return "FLOAT"
        return "NUMBER(38,0)"
    if family == "timestamp":
        return t if t in ("TIMESTAMP_NTZ", "TIMESTAMP_LTZ", "TIMESTAMP_TZ") else "TIMESTAMP_NTZ"
    if family == "text":
        return "VARCHAR"
    return t


def reconcile(column: SpecColumn, catalog_type: str) -> tuple[str, bool, str | None]:
    """(type to use, whether it came from the catalog, conflict to report). Text keeps the size sampled from the files."""
    inferred, catalog = column.type, catalog_type
    fi, fc = type_family(inferred), type_family(catalog)
    if column.sample is None and inferred == "VARCHAR" and fc != "other":
        return snowflake_type(catalog), True, None  # nothing sampled to contradict the catalog
    if fc == "text":
        return (inferred, False, None) if fi == "text" else ("VARCHAR", True, None)  # keeps codes such as 00123 intact
    if fi == fc == "numeric":
        ci, cc = _scale(inferred), _scale(catalog)
        if cc is None or (ci is not None and cc >= ci):
            return snowflake_type(catalog), snowflake_type(catalog) != inferred, None
        return inferred, False, f"{catalog} in the catalog would drop decimals the files carry (e.g. {column.sample})"
    if fi == fc and fc in ("date", "timestamp", "boolean"):
        return snowflake_type(catalog), snowflake_type(catalog) != inferred, None
    if fi == "date" and fc == "timestamp":
        return snowflake_type(catalog), True, None
    if fc == "other":
        return inferred, False, None
    example = f" such as '{column.sample}'" if column.sample else ""
    return inferred, False, f"{catalog} in the catalog, but the files hold {inferred} values{example}; kept {inferred}"


@dataclass
class CatalogGrounding:
    match: SpecCatalogMatch | None = None
    key: list[str] = field(default_factory=list)
    joins: list[SpecJoin] = field(default_factory=list)
    assumptions: list[str] = field(default_factory=list)
    risks: list[str] = field(default_factory=list)


def _words(items: list[str]) -> str:
    return items[0] if len(items) == 1 else ", ".join(items[:-1]) + f" and {items[-1]}"


async def _candidates(semantic: Any, table: str, terms: list[str], columns: list[SpecColumn]) -> list[dict[str, Any]]:
    """Tables and views the search finds, most column hits first."""
    found: dict[str, dict[str, Any]] = {}
    hits: dict[str, int] = {}
    for query in [table.replace("_", " "), *terms[:4]]:
        result = await semantic.search(query, limit=5)
        for asset in (result or {}).get("assets", []):
            if asset.get("asset_type") in ("table", "view") and asset.get("id"):
                found.setdefault(str(asset["id"]), {"id": asset["id"], "fqn": asset.get("fqn"), "asset_type": asset.get("asset_type"), "kind": asset.get("kind")})
    identifiers = sorted(columns, key=lambda c: not _IDENTIFIER.search(c.name))[:6]
    for column in identifiers:
        result = await semantic.search(column.name, limit=10)
        for f in (result or {}).get("fields", []):
            if _norm(str(f.get("name") or "")) != _norm(column.name) or f.get("asset_type") not in ("table", "view"):
                continue
            key = str(f["asset_id"])
            found.setdefault(key, {"id": f["asset_id"], "fqn": f.get("asset_fqn"), "asset_type": f.get("asset_type")})
            hits[key] = hits.get(key, 0) + 1
    ranked = sorted(found.values(), key=lambda a: (-hits.get(str(a["id"]), 0), str(a.get("fqn"))))
    return ranked[:_MAX_CANDIDATES]


def _overlap(columns: list[SpecColumn], fields: list[dict[str, Any]]) -> tuple[list[tuple[SpecColumn, dict[str, Any]]], float, float]:
    by_name = {_norm(str(f["name"])): f for f in fields}
    pairs = [(c, by_name[_norm(c.name)]) for c in columns if _norm(c.name) in by_name]
    union = len({_norm(c.name) for c in columns} | set(by_name))
    coverage = len(pairs) / len(columns) if columns else 0.0
    return pairs, coverage, (len(pairs) / union if union else 0.0)


def _asset_id(value: Any) -> UUID:
    return value if isinstance(value, UUID) else UUID(str(value))


async def ground_in_catalog(semantic: Any, *, target_fqn: str | None, table: str, business_terms: list[str], columns: list[SpecColumn]) -> CatalogGrounding:
    """The catalog table the feed resembles, with its key, types and joins applied; context only, so a failure loses it."""
    if semantic is None or not columns:
        return CatalogGrounding()
    try:
        return await _ground(semantic, target_fqn=target_fqn, table=table, business_terms=business_terms, columns=columns)
    except Exception as exc:  # noqa: BLE001 - the semantic layer is optional context for the plan
        log.warning("intent.plan.catalog_failed", error=str(exc))
        return CatalogGrounding()


async def _ground(semantic: Any, *, target_fqn: str | None, table: str, business_terms: list[str], columns: list[SpecColumn]) -> CatalogGrounding:
    out = CatalogGrounding()
    existing = await semantic.find_asset_row(target_fqn) if target_fqn else None
    if existing is not None and str(existing.get("fqn", "")).lower() != (target_fqn or "").lower():
        existing = None  # find_asset_row also matches on a suffix; only the exact table counts
    best: tuple[float, float, dict[str, Any], list[dict[str, Any]], list[tuple[SpecColumn, dict[str, Any]]]] | None = None
    if existing is not None:
        fields = await semantic.fields(_asset_id(existing["id"]))
        pairs, coverage, jaccard = _overlap(columns, fields)
        best = (coverage, jaccard, existing, fields, pairs)
    else:
        for candidate in await _candidates(semantic, table, business_terms, columns):
            fields = await semantic.fields(_asset_id(candidate["id"]))
            pairs, coverage, jaccard = _overlap(columns, fields)
            if len(pairs) < _MIN_MATCHED or coverage < _MIN_COVERAGE:
                continue
            rank = (candidate.get("asset_type") == "table", coverage, jaccard)
            if best is None or rank > (best[2].get("asset_type") == "table", best[0], best[1]):
                best = (coverage, jaccard, candidate, fields, pairs)
    if best is None:
        return out
    coverage, jaccard, asset, fields, pairs = best
    fqn = str(asset.get("fqn") or "")
    asset_id = str(asset["id"])

    # Column types: the catalog's where the files agree with it.
    adopted, conflicts = 0, []
    for column, f in pairs:
        catalog_type = str(f.get("data_type") or "")
        if not catalog_type:
            continue
        column.catalog_type = catalog_type
        chosen, from_catalog, conflict = reconcile(column, catalog_type)
        if from_catalog:
            column.type = chosen
            adopted += 1
        if conflict:
            conflicts.append(f"{column.name}: {conflict}")
    if adopted:
        out.assumptions.append(f"{adopted} column type(s) follow {fqn} in the catalog.")
    out.risks += [f"Type differs from {fqn}: {c}" for c in conflicts[:4]]

    # The declared key, when the feed carries all of it.
    declared = [str(f["name"]) for f in fields if f.get("is_primary_key")]
    feed_by_norm = {_norm(c.name): c.name for c in columns}
    key: list[str] = []
    if declared and all(_norm(k) in feed_by_norm for k in declared):
        key = [feed_by_norm[_norm(k)] for k in declared]
        out.key = key
        out.assumptions.append(f"Key {_words(key)} is {fqn}'s declared primary key.")
    elif declared:
        shared = [c.name for c, f in pairs if f.get("role") == "identifier" and _IDENTIFIER.search(c.name)]
        tail = f"; rows match it on {_words(shared)} instead" if shared else ""
        out.risks.append(f"{fqn} is keyed on {_words(declared)}, which these files do not carry{tail}.")

    # Joins: shared identifiers to the table itself, then the joins it declares on columns the feed has.
    seen: set[tuple[str, str]] = set()
    for column, f in pairs:
        if (f.get("is_primary_key") or f.get("role") == "identifier") and _IDENTIFIER.search(column.name):
            out.joins.append(
                SpecJoin(
                    columns=[column.name],
                    to_table=fqn,
                    to_columns=[str(f["name"])],
                    kind="shared_key",
                    confidence=1.0,
                    via=f"the same identifier in {fqn}",
                    link=f"/semantic/{asset_id}",
                )
            )
            seen.add((column.name, fqn))
    for r in await semantic.relationships(_asset_id(asset["id"])):
        if r.get("kind") not in _JOIN_KINDS:
            continue
        outgoing = r.get("direction") == "out"
        mine = [str(c) for c in (r.get("source_columns") if outgoing else r.get("target_columns")) or []]
        theirs = [str(c) for c in (r.get("target_columns") if outgoing else r.get("source_columns")) or []]
        other = str(r.get("other_fqn") or "")
        if not mine or not other or not all(_norm(c) in feed_by_norm for c in mine):
            continue
        cols = [feed_by_norm[_norm(c)] for c in mine]
        if (",".join(cols), other) in seen:
            continue
        seen.add((",".join(cols), other))
        out.joins.append(
            SpecJoin(
                columns=cols,
                to_table=other,
                to_columns=theirs,
                kind=str(r["kind"]),
                confidence=round(float(r.get("confidence") or 1.0), 2),
                via=f"{fqn} {'is inferred to have' if r.get('kind') == 'join_inferred' else 'declares'} it",
                link=f"/semantic/{r['other_asset_id']}" if r.get("other_asset_id") else None,
            )
        )

    duplicate, reason = False, ""
    if existing is not None:
        duplicate, reason = True, f"{fqn} already exists in the catalog"
        out.risks.append(f"{fqn} already exists in the catalog: load into it or extend its pipeline instead of creating a second table.")
    elif jaccard >= _DUPLICATE_JACCARD:
        duplicate, reason = True, f"{len(pairs)} of {len(fields)} columns are the same as {fqn}"
        out.risks.append(f"The target looks like a duplicate of {fqn}: {len(pairs)} of its {len(fields)} columns are the same. Load into it, or say why a second copy is needed.")

    out.match = SpecCatalogMatch(
        fqn=fqn,
        asset_id=asset_id,
        link=f"/semantic/{asset_id}",
        kind=asset.get("kind"),
        asset_type=asset.get("asset_type"),
        coverage=round(coverage, 2),
        similarity=round(jaccard, 2),
        matched_columns=[c.name for c, _ in pairs],
        feed_columns=len(columns),
        table_columns=len(fields),
        key=declared,
        key_in_feed=bool(key),
        types_adopted=adopted,
        type_conflicts=len(conflicts),
        duplicate=duplicate,
        duplicate_reason=reason,
    )
    return out
