"""Intent service: ticket → structured intent → pipeline spec → human gate → generated pipeline."""
