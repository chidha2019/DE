"""What stops a plan from being approved: it reads a table that holds no rows.

A source table missing from the warehouse is a plan, not a table; one that exists with no rows was created and never
loaded. Either way a pipeline built on it compiles, passes review and returns nothing, because the reviewer assumes a
table named in a plan exists. Tables of the plan's own target schema are left out: the plan builds them, in order.
"""

from __future__ import annotations

from ech_core.schemas.intents import IntentValidation, PipelineSpec


def plan_blockers(spec: PipelineSpec, validation: IntentValidation | None) -> list[str]:
    """One line per source table the plan may not be approved on, from what validation saw (read-only)."""
    if not spec.models or validation is None or not validation.reachable:
        return []
    own = f"{spec.target.database}.{spec.target.schema_name}.".upper()
    seen = {o.name.upper(): o for o in validation.objects if o.kind == "table"}
    out: list[str] = []
    for fqn in sorted({s.upper() for m in spec.models for s in m.sources}):
        if fqn.startswith(own) or fqn.count(".") != 2:
            continue
        obj = seen.get(fqn)
        if obj is None or not obj.exists:
            out.append(f"{fqn} is not in the warehouse: it is declared, not built.")
        elif obj.rows == 0:
            out.append(f"{fqn} exists but holds no rows: it was created and never loaded.")
    return out
