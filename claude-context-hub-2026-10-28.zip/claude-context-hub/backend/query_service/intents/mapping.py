"""Compile a source-to-target mapping, with the data model and DDL beside it, into the SQL of a modelled layer.

Nothing here knows the tables of any one mapping. The three documents are recognised by their content:

* the **mapping** (``models: - target_table, sources, transformations``): per target column a ``logic`` that is one
  expression for every source or one per ``source_id`` (with an optional ``default``), an optional ``filter``, and
  per source a logical ``location`` with optional ``join`` / ``left_join``;
* the **data model** (``models: - name, type, primary_key, columns, foreign_keys``): column order, types and keys;
* the **DDL** (``CREATE TABLE`` and ``COMMENT ON`` statements): created as written, in the target database.

Each logical location is bound to a physical table of the layer below by its name (a suffix every table of a schema
shares, such as ``_ICEBERG``, is ignored) **and** by the columns the logic reads from it, so a same-named table of
another system is not taken. Every identifier is then resolved against the physical columns by its normalised name
(``clientType_id`` reads ``CLIENT_TYPE_ID``), and the expression language is translated:

* ``HASH(a, b)`` → a SHA-256 hex digest of the values joined with ``|``. In a key column a NULL argument gives a
  NULL key (an optional foreign key stays NULL); elsewhere NULLs hash as a marker, so a change hash is never NULL.
* ``LOOKUP(key) FROM table RETURNING expr`` → a LEFT JOIN on a derived table with one row per key (``ANY_VALUE``,
  or the aggregate the expression already is, such as ``SUM(...)``), so a lookup never multiplies rows.
* ``TRY_TO_DATE(x, ...)`` reads ``x`` as text, so it works whether the column was loaded as text or as a date.
* A column whose logic reads other target columns (a surrogate key over ``SOURCE_SYSTEM, SOURCE_RECORD_ID``, a change
  hash, an address built from its parts) is computed in a later stage, after the columns it reads.

A source whose tables are not in the layer below, or whose columns are not all found, is left out with the reason;
the target is built from the sources that are there and says what it waits on.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import sqlglot
import yaml
from sqlglot import exp

DIALECT = "snowflake"
_IDENT_RE = r"[A-Za-z_][A-Za-z0-9_$]*"
_TOKEN = re.compile(rf"'(?:[^']|'')*'|{_IDENT_RE}(?:\.{_IDENT_RE})*|\d+(?:\.\d+)?|\s+|.", re.S)
_LOOKUP = re.compile(rf"LOOKUP\s*\(\s*({_IDENT_RE}(?:\.{_IDENT_RE})*)\s*\)\s*FROM\s+({_IDENT_RE}(?:\.{_IDENT_RE})*)\s+RETURNING\s+", re.I)
_AGGREGATES = {"SUM", "COUNT", "MIN", "MAX", "AVG", "LISTAGG", "ARRAY_AGG", "MEDIAN"}
KEYWORDS = {
    "NULL", "TRUE", "FALSE", "CASE", "WHEN", "THEN", "ELSE", "END", "AND", "OR", "NOT", "IS", "IN", "BETWEEN", "AS", "LIKE",
    "ILIKE", "DISTINCT", "VARCHAR", "CHAR", "STRING", "TEXT", "NUMBER", "NUMERIC", "DECIMAL", "INT", "INTEGER", "BIGINT",
    "FLOAT", "DOUBLE", "REAL", "DATE", "TIME", "TIMESTAMP", "TIMESTAMP_NTZ", "TIMESTAMP_LTZ", "TIMESTAMP_TZ", "BOOLEAN",
    "VARIANT", "ARRAY", "OBJECT", "INTERVAL", "ESCAPE",
}
_NULL_MARK = "'~'"


def norm(text: str) -> str:
    """Names compared without case, underscores or punctuation: clientType_id == CLIENT_TYPE_ID."""
    return re.sub(r"[^a-z0-9]", "", text.lower())


def short(name: str) -> str:
    return name.rsplit(".", 1)[-1].upper()


def ident(name: str) -> str:
    return name if re.fullmatch(r"[A-Z_][A-Z0-9_$]*", name) else '"' + name.replace('"', '""') + '"'


# --------------------------------------------------------------------------- the three documents
@dataclass
class ColumnDef:
    name: str
    type: str = "VARCHAR"
    description: str = ""
    nullable: bool = True
    default: str | None = None


@dataclass
class ForeignKey:
    column: str
    table: str
    to_column: str


@dataclass
class ModelDef:
    name: str
    kind: str = "dimension"
    primary_key: list[str] = field(default_factory=list)
    description: str = ""
    columns: list[ColumnDef] = field(default_factory=list)
    foreign_keys: list[ForeignKey] = field(default_factory=list)
    grain: str = ""
    concept: str = ""  # the ontology concept the model names (acord_concept)


@dataclass
class SourceDef:
    source_id: str
    location: str
    kind: str = ""
    joins: list[tuple[str, str, str]] = field(default_factory=list)  # (JOIN | LEFT JOIN, location, condition)


@dataclass
class Transform:
    column: str
    logic: str | dict[str, str]
    filter: str | None = None


@dataclass
class MappedModel:
    target: str
    sources: list[SourceDef]
    transforms: list[Transform]
    ontology: str = ""
    schema: str = ""  # the target's schema in the mapping (SILVER of SILVER.DIM_PARTY)


@dataclass
class DdlTable:
    name: str
    columns: list[ColumnDef]
    primary_key: list[str]
    foreign_keys: list[ForeignKey]
    statements: list[exp.Expression]
    schema: str = ""  # SILVER of CREATE TABLE SILVER.DIM_PARTY


@dataclass
class Design:
    mapping: list[MappedModel] = field(default_factory=list)
    models: dict[str, ModelDef] = field(default_factory=dict)
    ddl: dict[str, DdlTable] = field(default_factory=dict)
    header: dict[str, Any] = field(default_factory=dict)
    files: dict[str, str] = field(default_factory=dict)  # role -> file name
    problems: list[str] = field(default_factory=list)


def classify(text: str) -> str | None:
    """'mapping', 'model' or 'ddl' by what the document holds; None for anything else."""
    if re.search(r"\bCREATE\s+(?:OR\s+REPLACE\s+)?(?:TRANSIENT\s+|ICEBERG\s+)?TABLE\b", text, re.I) and not text.lstrip().startswith(("version:", "models:")):
        return "ddl"
    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError:
        return None
    if not isinstance(data, dict) or not isinstance(data.get("models"), list):
        return None
    items = [m for m in data["models"] if isinstance(m, dict)]
    if any("target_table" in m and "transformations" in m for m in items):
        return "mapping"
    if any("name" in m and "columns" in m for m in items):
        return "model"
    return None


def _fk(item: dict[str, Any]) -> ForeignKey | None:
    ref = str(item.get("references") or "")
    if "column" not in item or "." not in ref:
        return None
    table, _, col = ref.rpartition(".")
    return ForeignKey(column=str(item["column"]).upper(), table=short(table), to_column=col.upper())


def read_model(data: dict[str, Any]) -> dict[str, ModelDef]:
    out: dict[str, ModelDef] = {}
    for m in data.get("models") or []:
        if not isinstance(m, dict) or "name" not in m:
            continue
        pk = m.get("primary_key")
        keys = [str(k).upper() for k in (pk if isinstance(pk, list) else [pk] if pk else [])]
        out[short(str(m["name"]))] = ModelDef(
            name=short(str(m["name"])),
            kind=str(m.get("type") or "dimension").lower(),
            primary_key=keys,
            description=str(m.get("description") or ""),
            columns=[
                ColumnDef(name=str(c["name"]).upper(), type=str(c.get("type") or "VARCHAR").upper(), description=str(c.get("description") or ""))
                for c in m.get("columns") or []
                if isinstance(c, dict) and c.get("name")
            ],
            foreign_keys=[fk for fk in (_fk(f) for f in m.get("foreign_keys") or [] if isinstance(f, dict)) if fk],
            grain=str(m.get("grain") or ""),
            concept=str(m.get("acord_concept") or m.get("concept") or ""),
        )
    return out


def read_mapping(data: dict[str, Any]) -> list[MappedModel]:
    out: list[MappedModel] = []
    for m in data.get("models") or []:
        if not isinstance(m, dict) or "target_table" not in m:
            continue
        sources: list[SourceDef] = []
        for s in m.get("sources") or []:
            if not isinstance(s, dict) or "source_id" not in s:
                continue
            joins = []
            for key, how in (("join", "JOIN"), ("left_join", "LEFT JOIN")):
                spec = s.get(key)
                for j in spec if isinstance(spec, list) else [spec] if isinstance(spec, dict) else []:
                    if isinstance(j, dict) and j.get("table") and j.get("condition"):
                        joins.append((how, str(j["table"]), str(j["condition"])))
            sources.append(SourceDef(source_id=str(s["source_id"]), location=str(s.get("location") or ""), kind=str(s.get("type") or ""), joins=joins))
        transforms = []
        for t in m.get("transformations") or []:
            if not isinstance(t, dict) or "target_column" not in t:
                continue
            logic = t.get("logic")
            value: str | dict[str, str] = (
                {str(k): "NULL" if v is None else str(v) for k, v in logic.items()} if isinstance(logic, dict) else "NULL" if logic is None else str(logic)
            )
            transforms.append(Transform(column=str(t["target_column"]).upper(), logic=value, filter=str(t["filter"]) if t.get("filter") else None))
        target = str(m["target_table"])
        out.append(
            MappedModel(
                target=short(target),
                sources=sources,
                transforms=transforms,
                ontology=str(m.get("ontology_reference") or ""),
                schema=target.rpartition(".")[0].rsplit(".", 1)[-1].upper(),
            )
        )
    return out


def read_ddl(text: str) -> dict[str, DdlTable]:
    out: dict[str, DdlTable] = {}
    for stmt in sqlglot.parse(text, read=DIALECT):
        if stmt is None:
            continue
        if isinstance(stmt, exp.Create) and isinstance(stmt.this, exp.Schema):
            name = short(stmt.this.this.sql(dialect=DIALECT))
            columns: list[ColumnDef] = []
            pk: list[str] = []
            fks: list[ForeignKey] = []
            for e in stmt.this.expressions:
                if isinstance(e, exp.ColumnDef):
                    kinds = [c.kind for c in e.constraints]
                    default = next((k.this.sql(dialect=DIALECT) for k in kinds if isinstance(k, exp.DefaultColumnConstraint)), None)
                    columns.append(
                        ColumnDef(
                            name=e.name.upper(),
                            type=e.args["kind"].sql(dialect=DIALECT).upper() if e.args.get("kind") else "VARCHAR",
                            nullable=not any(isinstance(k, exp.NotNullColumnConstraint) and not k.args.get("allow_null") for k in kinds),
                            default=default,
                        )
                    )
                elif isinstance(e, exp.PrimaryKey):
                    pk = [c.name.upper() for c in e.expressions]
                elif isinstance(e, exp.ForeignKey):
                    ref = e.args.get("reference")
                    target = ref.this if ref is not None else None
                    if isinstance(target, exp.Schema):
                        to_cols = [c.name.upper() for c in target.expressions]
                        for a, b in zip([c.name.upper() for c in e.expressions], to_cols, strict=False):
                            fks.append(ForeignKey(column=a, table=short(target.this.sql(dialect=DIALECT)), to_column=b))
            schema = stmt.this.this.db.upper() if isinstance(stmt.this.this, exp.Table) else ""
            out[name] = DdlTable(name=name, columns=columns, primary_key=pk, foreign_keys=fks, statements=[stmt], schema=schema)
        elif isinstance(stmt, exp.Comment):
            target = stmt.this.sql(dialect=DIALECT)
            parts = target.split(".")
            kind = str(stmt.args.get("kind") or "").upper()
            table = short(".".join(parts[:-1])) if kind == "COLUMN" else short(target)
            if table in out:
                out[table].statements.append(stmt)
    return out


def load_design(texts: dict[str, str]) -> Design:
    """The documents (file name -> text) sorted into mapping, model and DDL."""
    design = Design()
    for name, text in texts.items():
        role = classify(text)
        if role is None:
            design.problems.append(f"{name} is not a mapping, a data model or DDL the hub can read")
            continue
        design.files[role] = name
        if role == "ddl":
            design.ddl.update(read_ddl(text))
            continue
        data = yaml.safe_load(text)
        if role == "mapping":
            design.mapping += read_mapping(data)
            design.header = {k: v for k, v in data.items() if k != "models" and not isinstance(v, (list, dict))}
        else:
            design.models.update(read_model(data))
    if not design.mapping:
        design.problems.append("no source-to-target mapping among the files")
    return design


def qualify_ddl(table: DdlTable, database: str, schema: str) -> str:
    """The table's DDL in the target database, CREATE ... IF NOT EXISTS, foreign keys pointing at the same schema."""
    out: list[str] = []
    for stmt in table.statements:
        tree = stmt.copy()
        for t in tree.find_all(exp.Table):
            if not t.args.get("catalog"):
                t.set("catalog", exp.to_identifier(database))
                t.set("db", exp.to_identifier(t.db or schema))
        if isinstance(tree, exp.Comment) and str(tree.args.get("kind") or "").upper() == "COLUMN":
            col = tree.this
            if isinstance(col, exp.Column) and not col.args.get("catalog"):
                col.set("catalog", exp.to_identifier(database))
                if not col.args.get("db"):
                    col.set("db", exp.to_identifier(schema))
        if isinstance(tree, exp.Create):
            tree.set("exists", True)
        out.append(tree.sql(dialect=DIALECT, pretty=isinstance(tree, exp.Create), comments=False) + ";")
    return "\n".join(out)


# --------------------------------------------------------------------------- finding the design documents
_DESIGN_SUFFIXES = (".yaml", ".yml", ".sql")
_FILE_REF = re.compile(r"[\w./\\:-]+\.(?:ya?ml|sql)\b", re.I)
_MAX_SCAN = 400


def referenced_files(text: str) -> list[str]:
    """Design file paths a ticket or an answer names (``models/silver_mapping.yaml``)."""
    return list(dict.fromkeys(m.group(0) for m in _FILE_REF.finditer(text or "")))


def _under(root: Path, ref: str) -> Path | None:
    """A path from the reporter's machine as the longest tail of it under the data directory, else by file name."""
    raw = ref.replace("\\", "/").strip().strip("/")
    parts = [p for p in raw.split("/") if p and p not in (".", "..") and ":" not in p]
    for start in range(len(parts)):
        candidate = (root / "/".join(parts[start:])).resolve()
        if root in candidate.parents and candidate.is_file():
            return candidate
    if parts:
        found = sorted(root.rglob(parts[-1]), key=lambda p: len(p.parts))
        return next((p.resolve() for p in found if p.is_file()), None)
    return None


def resolve_files(root: Path, refs: list[str]) -> list[Path]:
    """The design files a ticket names, confined to the data directory; a folder stands for the design files in it."""
    root = root.resolve()
    out: list[Path] = []
    for ref in refs:
        folder = (root / ref.replace("\\", "/").strip("/")).resolve()
        if (folder == root or root in folder.parents) and folder.is_dir():
            out += sorted(p for p in folder.iterdir() if p.suffix.lower() in _DESIGN_SUFFIXES)
            continue
        hit = _under(root, ref)
        if hit is not None:
            out.append(hit)
    return list(dict.fromkeys(out))


def discover(root: Path, text: str) -> tuple[list[Path], list[str]]:
    """When a ticket names no files: the mapping under the data directory whose targets the ticket names most (at
    least two, or all of a smaller mapping), with the data model and DDL beside it. Returns the files and the targets
    the ticket names."""
    words = {w.upper() for w in re.findall(r"[A-Za-z_][A-Za-z0-9_]*", text or "")}
    best: tuple[int, Path, list[str]] | None = None
    scanned = 0
    for path in sorted(root.rglob("*")):
        if path.suffix.lower() not in (".yaml", ".yml") or not path.is_file():
            continue
        scanned += 1
        if scanned > _MAX_SCAN:
            break
        try:
            text_of = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if classify(text_of) != "mapping":
            continue
        targets = [m.target for m in read_mapping(yaml.safe_load(text_of))]
        named = [t for t in targets if t in words]
        if len(named) >= min(2, len(targets)) and (best is None or len(named) > best[0]):
            best = (len(named), path, named)
    if best is None:
        return [], []
    _, mapping_path, named = best
    files = [mapping_path]
    for sibling in sorted(mapping_path.parent.iterdir()):
        if sibling != mapping_path and sibling.suffix.lower() in _DESIGN_SUFFIXES and sibling.is_file():
            if classify(sibling.read_text(encoding="utf-8", errors="replace")) in ("model", "ddl"):
                files.append(sibling)
    return files, named


def read_design(files: list[Path], root: Path) -> Design:
    texts = {str(p.relative_to(root.resolve())) if root.resolve() in p.parents else p.name: p.read_text(encoding="utf-8", errors="replace") for p in files}
    return load_design(texts)


DESIGN_SUFFIXES = (".sql", ".yaml", ".yml")
SKIP_PARTS = {"digital-worker", "node_modules", ".git", "__pycache__", ".pytest_cache"}  # packages' worked examples declare nothing
MAX_DESIGN_FILES = 400


def design_folders(root: Path, roles: tuple[str, ...] = ("ddl", "mapping", "model")) -> list[tuple[str, dict[str, str]]]:
    """Each folder under the data directory that holds design documents: its path from the root, and its
    documents of those roles (file name -> text)."""
    by_folder: dict[Path, dict[str, str]] = {}
    seen = 0
    for path in sorted(root.rglob("*")):
        if seen >= MAX_DESIGN_FILES:
            break
        if path.suffix.lower() not in DESIGN_SUFFIXES or SKIP_PARTS & set(path.parts) or not path.is_file():
            continue
        seen += 1
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if classify(text) in roles:
            by_folder.setdefault(path.parent, {})[path.name] = text
    return [(str(folder.relative_to(root)).replace("\\", "/") if root in folder.parents else folder.name, texts) for folder, texts in by_folder.items()]


# --------------------------------------------------------------------------- binding logical sources to tables
@dataclass
class Binding:
    location: str
    table: str | None  # DB.SCHEMA.TABLE
    reason: str = ""
    coverage: float = 0.0


def _suffixes(catalog: dict[str, list[str]]) -> dict[str, str]:
    """Per schema, a suffix most of its tables share (``_ICEBERG``); names match without it."""
    by_schema: dict[str, list[str]] = {}
    for fqn in catalog:
        db, schema, name = fqn.split(".")
        by_schema.setdefault(f"{db}.{schema}", []).append(name)
    out: dict[str, str] = {}
    for schema, names in by_schema.items():
        tails: dict[str, int] = {}
        for n in names:
            if "_" in n:
                tail = n[n.rindex("_") :]
                tails[tail] = tails.get(tail, 0) + 1
        best = max(tails.items(), key=lambda kv: kv[1], default=("", 0))
        if best[1] >= max(2, len(names) // 2):
            out[schema] = best[0]
    return out


def bind(location: str, wanted: set[str], catalog: dict[str, list[str]], *, prefer_schema: str | None = None) -> Binding:
    """The physical table a logical location reads: same name (with or without the schema's shared suffix), and the
    columns the logic reads from it there; the best covered wins, and below half covered nothing is bound."""
    logical = norm(short(location))
    suffixes = _suffixes(catalog)
    best: Binding | None = None
    for fqn, columns in catalog.items():
        db, schema, name = fqn.split(".")
        suffix = suffixes.get(f"{db}.{schema}", "")
        bare = name[: -len(suffix)] if suffix and name.endswith(suffix) else name
        if norm(bare) != logical and norm(name) != logical:
            continue
        have = {norm(c) for c in columns}
        found = sum(1 for w in wanted if norm(w) in have)
        coverage = found / len(wanted) if wanted else 1.0
        score = coverage + (0.01 if prefer_schema and schema == prefer_schema.upper() else 0)
        if best is None or score > best.coverage:
            missing = sorted(w for w in wanted if norm(w) not in have)
            best = Binding(location=location, table=fqn, coverage=score, reason=", ".join(missing[:6]))
    if best is None:
        return Binding(location=location, table=None, reason="no table of that name in the layer below")
    if best.coverage < 0.5:
        return Binding(location=location, table=None, reason=f"{best.table} lacks {best.reason}; it is another system's table", coverage=best.coverage)
    return best


# --------------------------------------------------------------------------- expressions
def _tokens(text: str) -> list[str]:
    return _TOKEN.findall(text)


def _is_ident(tok: str) -> bool:
    return bool(re.fullmatch(rf"{_IDENT_RE}(?:\.{_IDENT_RE})*", tok))


def _next(tokens: list[str], i: int) -> str:
    return next((t for t in tokens[i + 1 :] if not t.isspace()), "")


def _balanced(text: str, start: int) -> int:
    """Index just past the parenthesis group opening at text[start] == '('."""
    depth = 0
    i = start
    while i < len(text):
        ch = text[i]
        if ch == "'":
            i += 1
            while i < len(text):
                if text[i] == "'" and i + 1 < len(text) and text[i + 1] == "'":
                    i += 2
                    continue
                if text[i] == "'":
                    break
                i += 1
            i += 1
            continue
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth == 0:
                return i + 1
        i += 1
    return len(text)


def split_args(text: str) -> list[str]:
    """Top-level comma-separated arguments of an argument list (without its parentheses)."""
    out: list[str] = []
    depth, start, i = 0, 0, 0
    while i < len(text):
        ch = text[i]
        if ch == "'":
            i += 1
            while i < len(text):
                if text[i] == "'" and i + 1 < len(text) and text[i + 1] == "'":
                    i += 2
                    continue
                if text[i] == "'":
                    break
                i += 1
        elif ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif ch == "," and depth == 0:
            out.append(text[start:i].strip())
            start = i + 1
        i += 1
    if text[start:].strip():
        out.append(text[start:].strip())
    return out


@dataclass
class Lookup:
    alias: str
    table: str  # logical location
    key: str
    expr: str


def extract_lookups(text: str, found: list[Lookup]) -> str:
    """Replace each LOOKUP(...) FROM ... RETURNING expr with a reference to its join; equal lookups share one join."""
    while True:
        m = _LOOKUP.search(text)
        if not m:
            return text
        rest = text[m.end() :]
        first = re.match(rf"{_IDENT_RE}(?:\.{_IDENT_RE})*", rest)
        if not first:
            return text
        end = first.end()
        after = rest[end:]
        if after.lstrip().startswith("("):
            end = _balanced(rest, end + (len(after) - len(after.lstrip())))
        expr = rest[:end].strip()
        key, table = m.group(1), m.group(2)
        hit = next((lk for lk in found if lk.table.upper() == table.upper() and norm(lk.key) == norm(key) and lk.expr == expr), None)
        if hit is None:
            hit = Lookup(alias=f"LK{len(found) + 1}", table=table, key=key, expr=expr)
            found.append(hit)
        text = text[: m.start()] + f"{hit.alias}.V" + rest[end:]


class Resolver:
    """Finds the physical column an identifier names, in the tables of one source branch."""

    def __init__(self, tables: dict[str, tuple[str, list[str]]], targets: set[str]) -> None:
        self.tables = tables  # alias -> (fqn, physical columns); the first entry is the base table
        self.targets = targets
        self.unresolved: list[str] = []
        self.target_refs: set[str] = set()

    def column(self, alias: str, name: str) -> str | None:
        _, columns = self.tables[alias]
        return next((c for c in columns if norm(c) == norm(name)), None)

    def source(self, name: str) -> str | None:
        for alias in self.tables:
            hit = self.column(alias, name)
            if hit is not None:
                return f"{alias}.{ident(hit)}"
        return None


def compile_expr(text: str, res: Resolver, *, targets_first: bool, key_column: bool, own: str | None = None) -> str:
    """One mapping expression as Snowflake SQL over the branch's aliases (and earlier target columns); a column's own
    name in its expression is the source column it comes from, never itself."""
    out: list[str] = []
    tokens = _tokens(text)
    for i, tok in enumerate(tokens):
        if not _is_ident(tok):
            out.append(tok)
            continue
        nxt = _next(tokens, i)
        upper = tok.upper()
        if nxt == "(":
            out.append(upper)
            continue
        if upper in KEYWORDS or re.fullmatch(r"LK\d+\.V", tok):
            out.append(tok)
            continue
        if "." in tok:
            head, _, col = tok.rpartition(".")
            alias = next((a for a in res.tables if a.upper() == short(head)), None)
            hit = res.column(alias, col) if alias else None
            if hit is None:
                res.unresolved.append(tok)
                out.append(tok)
            else:
                out.append(f"{alias}.{ident(hit)}")
            continue
        if targets_first and upper in res.targets and upper != own:
            res.target_refs.add(upper)
            out.append(ident(upper))
            continue
        hit = res.source(tok)
        if hit is not None:
            out.append(hit)
        elif upper in res.targets and upper != own:
            res.target_refs.add(upper)
            out.append(ident(upper))
        else:
            res.unresolved.append(tok)
            out.append(tok)
    return _functions("".join(out), key_column=key_column)


def _functions(sql: str, *, key_column: bool) -> str:
    """HASH(...) to a SHA-256 hex digest; TRY_TO_DATE / TRY_TO_NUMBER read their first argument as text."""
    out = ""
    i = 0
    pattern = re.compile(r"\b(HASH|TRY_TO_DATE|TRY_TO_NUMBER|TRY_TO_TIMESTAMP)\s*\(", re.I)
    while True:
        m = pattern.search(sql, i)
        if not m:
            return out + sql[i:]
        open_at = m.end() - 1
        close = _balanced(sql, open_at)
        args = [_functions(a, key_column=key_column) for a in split_args(sql[open_at + 1 : close - 1])]
        name = m.group(1).upper()
        if name == "HASH":
            parts = [f"TO_VARCHAR({a})" if key_column else f"COALESCE(TO_VARCHAR({a}), {_NULL_MARK})" for a in args]
            replacement = f"SHA2(CONCAT_WS('|', {', '.join(parts)}), 256)"
        else:
            if args:
                args[0] = f"TO_VARCHAR({args[0]})"
            replacement = f"{name}({', '.join(args)})"
        out += sql[i : m.start()] + replacement
        i = close


# --------------------------------------------------------------------------- compiling a target table
@dataclass
class CompiledModel:
    name: str
    sql: str
    columns: list[ColumnDef]
    keys: list[str]
    kind: str
    description: str
    foreign_keys: list[ForeignKey]
    ddl: DdlTable | None
    sources: list[str] = field(default_factory=list)  # physical tables read
    branches: list[str] = field(default_factory=list)  # source ids compiled
    skipped: list[str] = field(default_factory=list)  # "SOURCE_ID: reason"
    waiting_on: list[str] = field(default_factory=list)  # logical locations not loaded
    findings: list[str] = field(default_factory=list)
    hash_column: str | None = None
    created_column: str | None = None
    updated_column: str | None = None


def _logic_for(t: Transform | None, source_id: str) -> tuple[str, bool]:
    """The expression for one source, and whether it is the same for every source (then target names come first)."""
    if t is None:
        return "NULL", True
    if isinstance(t.logic, dict):
        if source_id in t.logic:
            return t.logic[source_id], False
        return t.logic.get("default", "NULL"), True
    return t.logic, True


def _wanted(m: MappedModel, s: SourceDef) -> dict[str, set[str]]:
    """Per logical table of a source (the base under its own location, each join and each lookup), the columns its
    logic reads there; what a binding has to cover."""
    base = s.location.upper()
    wanted: dict[str, set[str]] = {base: set()}
    for _, loc, _ in s.joins:
        wanted.setdefault(loc.upper(), set())
    by_short = {short(k): k for k in wanted}
    targets = {t.column for t in m.transforms}
    texts = [(_logic_for(t, s.source_id)[0], t.column) for t in m.transforms] + [(c, None) for _, _, c in s.joins]
    texts += [(t.filter, None) for t in m.transforms if t.filter]
    for text, own in texts:
        lookups: list[Lookup] = []
        body = extract_lookups(text, lookups)
        for lk in lookups:
            wanted[base].add(lk.key)
            wanted.setdefault(lk.table.upper(), set()).add(lk.key)
            tokens = _tokens(lk.expr)
            for i, tok in enumerate(tokens):
                if re.fullmatch(_IDENT_RE, tok) and tok.upper() not in KEYWORDS and _next(tokens, i) != "(":
                    wanted[lk.table.upper()].add(tok)
        tokens = _tokens(body)
        for i, tok in enumerate(tokens):
            if not _is_ident(tok) or tok.upper() in KEYWORDS or re.fullmatch(r"LK\d+\.V", tok) or _next(tokens, i) == "(":
                continue
            if "." in tok:
                head, _, col = tok.rpartition(".")
                loc = by_short.get(short(head))
                if loc:
                    wanted[loc].add(col)
                continue
            if tok.upper() in targets and tok.upper() != own:
                continue  # read from the base when it has it, else from an earlier stage; never required of the table
            wanted[base].add(tok)
    return wanted


def compile_model(m: MappedModel, design: Design, catalog: dict[str, list[str]], *, prefer_schema: str | None = None) -> CompiledModel:
    model = design.models.get(m.target)
    ddl = design.ddl.get(m.target)
    by_name = {t.column: t for t in m.transforms}
    ddl_cols = {c.name: c for c in ddl.columns} if ddl else {}
    if model and model.columns:
        names = [c.name for c in model.columns]
    elif ddl:
        names = [c.name for c in ddl.columns if c.name in by_name]
    else:
        names = [t.column for t in m.transforms]
    # A column the DDL fills by default (SYS_CREATED_TS) and the mapping does not compute is left to the load.
    names = [n for n in names if n in by_name or not (n in ddl_cols and ddl_cols[n].default)]
    model_cols = {c.name: c for c in model.columns} if model else {}
    columns = [
        ColumnDef(
            name=n,
            type=(ddl_cols[n].type if n in ddl_cols else model_cols[n].type if n in model_cols else "VARCHAR"),
            description=model_cols[n].description if n in model_cols else "",
            nullable=ddl_cols[n].nullable if n in ddl_cols else True,
        )
        for n in names
    ]
    keys = (model.primary_key if model and model.primary_key else ddl.primary_key if ddl else []) or names[:1]
    out = CompiledModel(
        name=m.target,
        sql="",
        columns=columns,
        keys=keys,
        kind="fact" if (model and model.kind == "fact") or m.target.startswith("FACT") else "dimension",
        description=model.description if model else "",
        foreign_keys=(model.foreign_keys if model and model.foreign_keys else ddl.foreign_keys if ddl else []),
        ddl=ddl,
    )
    missing = [n for n in names if n not in by_name]
    if missing:
        out.findings.append(f"No transformation for {', '.join(missing)}: loaded as NULL.")
    targets = set(names)
    # The change hash: a non-key column whose single logic hashes other target columns.
    for t in m.transforms:
        if isinstance(t.logic, str) and t.column in targets and t.column not in keys and not t.column.endswith("_SK") and t.logic.strip().upper().startswith("HASH("):
            out.hash_column = t.column
    for c in ddl.columns if ddl else []:
        if c.default and "TIMESTAMP" in c.type and "CREAT" in c.name:
            out.created_column = c.name
        elif c.default and "TIMESTAMP" in c.type and "UPDAT" in c.name:
            out.updated_column = c.name

    ctes: list[str] = []
    finals: list[str] = []
    for bi, s in enumerate(m.sources, start=1):
        base_loc = s.location.upper()
        join_locs = {loc.upper() for _, loc, _ in s.joins}
        tables: dict[str, tuple[str, list[str]]] = {}
        lookup_bindings: dict[str, Binding] = {}
        reasons: list[str] = []
        for loc, cols in _wanted(m, s).items():
            b = bind(loc, cols, catalog, prefer_schema=prefer_schema)
            if b.table is None:
                reasons.append(f"{loc} ({b.reason})")
                out.waiting_on.append(loc)
            elif loc == base_loc or loc in join_locs:
                tables[short(loc)] = (b.table, catalog[b.table])
            else:
                lookup_bindings[loc] = b
        if reasons:
            out.skipped.append(f"{s.source_id}: {'; '.join(reasons)}")
            continue
        # The base table first: unqualified names are looked up there before the joins.
        base_alias = short(s.location)
        tables = {base_alias: tables[base_alias], **{a: v for a, v in tables.items() if a != base_alias}}
        res = Resolver(tables, targets)
        lookups: list[Lookup] = []
        exprs: dict[str, str] = {}
        refs: dict[str, set[str]] = {}
        for n in names:
            text, shared = _logic_for(by_name.get(n), s.source_id)
            body = extract_lookups(text, lookups)
            res.target_refs = set()
            exprs[n] = compile_expr(body, res, targets_first=shared, key_column=n.endswith("_SK") or n in keys, own=n)
            refs[n] = {r for r in res.target_refs if r != n}
        filters: list[str] = []
        for n in names:
            t = by_name.get(n)
            if t and t.filter:
                res.target_refs = set()
                filters.append(compile_expr(t.filter, res, targets_first=True, key_column=False))
        joins_sql: list[str] = []
        for how, loc, cond in s.joins:
            res.target_refs = set()
            on = compile_expr(cond, res, targets_first=False, key_column=False)
            joins_sql.append(f"  {how} {tables[short(loc)][0]} AS {short(loc)} ON {on}")
        for lk in lookups:
            b = lookup_bindings[lk.table.upper()]
            lk_cols = catalog[str(b.table)]
            key_phys = next((c for c in lk_cols if norm(c) == norm(lk.key)), None)
            inner = Resolver({"L": (str(b.table), lk_cols)}, set())
            expr = compile_expr(lk.expr, inner, targets_first=False, key_column=True)
            outer_key = res.source(lk.key)
            if key_phys is None or outer_key is None or inner.unresolved:
                res.unresolved += [f"LOOKUP({lk.key}) FROM {lk.table}", *inner.unresolved]
                continue
            head = re.match(r"\s*([A-Za-z_]+)\s*\(", lk.expr)
            value = expr if head and head.group(1).upper() in _AGGREGATES else f"ANY_VALUE({expr})"
            joins_sql.append(
                f"  LEFT JOIN (SELECT L.{ident(key_phys)} AS K, {value} AS V FROM {b.table} AS L GROUP BY L.{ident(key_phys)}) AS {lk.alias}"
                f" ON {lk.alias}.K = {outer_key}"
            )
        if res.unresolved:
            out.skipped.append(f"{s.source_id}: columns not found: {', '.join(sorted(set(res.unresolved))[:6])}")
            continue
        # Stage the columns: those reading only the tables first, then each that reads earlier target columns.
        level: dict[str, int] = {}
        pending = list(names)
        while pending:
            ready = [n for n in pending if all(r in level for r in refs[n])]
            if not ready:
                out.findings.append(f"{s.source_id}: {', '.join(pending)} read each other in a cycle; they load as NULL.")
                for n in pending:
                    exprs[n], level[n] = "NULL", 0
                break
            for n in ready:
                level[n] = 1 + max((level[r] for r in refs[n]), default=-1)
                pending.remove(n)
        top = max(level.values(), default=0)
        cte = f"B{bi}"
        first = [f"    {exprs[n]} AS {ident(n)}" for n in names if level[n] == 0]
        ctes.append(f"{cte}_0 AS (\n  SELECT\n" + ",\n".join(first) + f"\n  FROM {tables[base_alias][0]} AS {base_alias}\n" + "\n".join(joins_sql) + "\n)")
        for lv in range(1, top + 1):
            more = [f"    {exprs[n]} AS {ident(n)}" for n in names if level[n] == lv]
            ctes.append(f"{cte}_{lv} AS (\n  SELECT {cte}_{lv - 1}.*,\n" + ",\n".join(more) + f"\n  FROM {cte}_{lv - 1}\n)")
        cols = ",\n".join(f"    CAST({ident(c.name)} AS {c.type}) AS {ident(c.name)}" for c in columns)
        where = f"\n  WHERE {' AND '.join(f'({f})' for f in filters)}" if filters else ""
        ctes.append(f"{cte} AS (\n  SELECT\n{cols}\n  FROM {cte}_{top}{where}\n)")
        finals.append(f"SELECT * FROM {cte}")
        out.branches.append(s.source_id)
        out.sources += [fqn for fqn, _ in tables.values()] + [str(b.table) for b in lookup_bindings.values()]
    out.sources = sorted(set(out.sources))
    out.waiting_on = sorted(set(out.waiting_on))
    if finals:
        out.sql = "WITH\n" + ",\n".join(ctes) + "\n" + "\nUNION ALL\n".join(finals)
    return out


def compile_design(design: Design, catalog: dict[str, list[str]], *, prefer_schema: str | None = None) -> list[CompiledModel]:
    """Every target of the mapping, ordered so a table comes after the tables its foreign keys point at."""
    compiled = [compile_model(m, design, catalog, prefer_schema=prefer_schema) for m in design.mapping]
    names = {c.name for c in compiled}
    ordered: list[CompiledModel] = []
    pending = list(compiled)
    while pending:
        done = {c.name for c in ordered}
        ready = [c for c in pending if all(fk.table in done or fk.table not in names or fk.table == c.name for fk in c.foreign_keys)] or pending[:1]
        ordered += ready
        pending = [c for c in pending if c not in ready]
    return ordered
