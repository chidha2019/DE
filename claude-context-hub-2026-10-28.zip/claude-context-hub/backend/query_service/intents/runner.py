"""Run an approved, generated pipeline in the hub: upload the files, create the objects, load and check.

The steps are the generated runner's own commands (``python pipeline.py upload | apply | load``; a modelled layer
reads tables already in Snowflake, so it has no upload), so what runs is
exactly what was reviewed and tested. The pipeline's environment is built from an allow-list: each runtime setting
reaches the subprocess only as ``ECH_RUN_<NAME>`` in the hub's environment, passed on as ``<NAME>``, and nothing
else of the hub's environment (its own database or model credentials) goes with it. Secret values are masked in
everything a step prints before it is stored.
"""

from __future__ import annotations

import asyncio
import re
import sys
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

from ech_core.schemas.intents import (
    PipelineRun,
    PipelineSpec,
    RunCheck,
    RunModel,
    RunReconciliation,
    RunStep,
    WorkflowMetric,
)
from query_service.intents.landing import landing_of

PREFIX = "ECH_RUN_"
SNOWFLAKE_ENV = ("SNOWFLAKE_HOST", "SNOWFLAKE_TOKEN", "SNOWFLAKE_WAREHOUSE", "SNOWFLAKE_ROLE", "SNOWFLAKE_AUTH_SCHEME")
OBJECT_ENV = ("STORAGE_INTEGRATION", "ECH_EXTERNAL_VOLUME")
AZURE_ENV = ("AZURE_STORAGE_CONNECTION_STRING", "AZURE_STORAGE_ACCOUNT", "AZURE_CONTAINER", "AZURE_PREFIX")
S3_ENV = ("S3_BUCKET", "S3_PREFIX", "AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_SESSION_TOKEN", "AWS_REGION", "AWS_DEFAULT_REGION")
RUN_ENV = (*SNOWFLAKE_ENV, *OBJECT_ENV, *AZURE_ENV, *S3_ENV)
SECRETS = ("SNOWFLAKE_TOKEN", "AZURE_STORAGE_CONNECTION_STRING", "AWS_SECRET_ACCESS_KEY", "AWS_SESSION_TOKEN", "AWS_ACCESS_KEY_ID")
ADMIN_ROLES = {"ACCOUNTADMIN", "SECURITYADMIN", "ORGADMIN"}
_INHERITED = ("PATH", "HOME", "LANG", "LC_ALL", "TZ", "SSL_CERT_FILE", "REQUESTS_CA_BUNDLE")
_CHECK = re.compile(r"^(pass|FAIL|WARN) (\S+) \((\d+)\)\s*$")
_MODEL = re.compile(r"^model (\S+) (.*)$")
_RECON = re.compile(r"^recon (\S+) (\S+) source=(\S+) target=(\S+) explained=(\S+) gap=(\S+) (match|explained|WARN|GAP)\s*$")
_PLACEHOLDER = re.compile(r"^<.*>$")
_LOG_TAIL = 6000

STEPS: tuple[tuple[str, str], ...] = (
    ("preflight", "Check the runtime settings"),
    ("upload", "Upload the files"),
    ("apply", "Create stage and tables"),
    ("load", "Load and check"),
    ("catalog", "Refresh the catalog"),
)
_TIMEOUT = {"upload": 900, "apply": 600, "load": 3600}


def runtime_env(source: Mapping[str, str]) -> dict[str, str]:
    """The pipeline's environment: ECH_RUN_<NAME> as <NAME> for the allow-listed names, a placeholder value
    ("<name of the ...>") left out, plus the few process variables a Python subprocess needs."""
    env = {k: source[k] for k in _INHERITED if source.get(k)}
    for name in RUN_ENV:
        value = (source.get(PREFIX + name) or "").strip()
        if value and not _PLACEHOLDER.match(value):
            env[name] = value
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONUNBUFFERED"] = "1"
    return env


def missing_settings(spec: PipelineSpec | None, env: Mapping[str, str]) -> list[str]:
    """Runtime settings a run of this spec cannot do without (names only, prefixed as the hub reads them)."""
    need = ["SNOWFLAKE_HOST", "SNOWFLAKE_TOKEN", "SNOWFLAKE_WAREHOUSE"]
    if spec is not None and spec.kind == "model_layer":
        # It reads the layer below inside Snowflake: no landing storage and no integration, a volume only for Iceberg tables.
        if spec.target.table_format == "iceberg" and not spec.target.external_volume and any(not m.ddl for m in spec.models):
            need.append("ECH_EXTERNAL_VOLUME")
    elif spec is not None:
        landing = landing_of(spec.source)
        if landing.provider == "azure":
            need.append("AZURE_STORAGE_CONNECTION_STRING")  # no `az login` inside the service: the upload signs in with it
            need += [n for n, have in (("AZURE_STORAGE_ACCOUNT", landing.account), ("AZURE_CONTAINER", landing.container)) if not have]
        else:
            need += [] if landing.container else ["S3_BUCKET"]
        if not spec.source.stage and not spec.source.storage_integration:
            need.append("STORAGE_INTEGRATION")  # the setup creates its own stage, which reads through the integration
        if spec.target.table_format == "iceberg" and not spec.target.external_volume:
            need.append("ECH_EXTERNAL_VOLUME")
    return [PREFIX + n for n in need if not env.get(n)]


def mask(text: str, env: Mapping[str, str]) -> str:
    """Every secret value (and the account key inside a connection string) replaced by •••."""
    values = [env[k] for k in SECRETS if env.get(k)]
    connection = env.get("AZURE_STORAGE_CONNECTION_STRING", "")
    values += [m.group(1) for m in re.finditer(r"(?:AccountKey|SharedAccessSignature)=([^;]+)", connection)]
    for value in sorted({v for v in values if len(v) >= 6}, key=len, reverse=True):
        text = text.replace(value, "•••")
    return text


def checks_in(output: str) -> list[RunCheck]:
    out: list[RunCheck] = []
    for line in output.splitlines():
        m = _CHECK.match(line.strip())
        if m:
            failures = int(m.group(3))
            warn = m.group(1) == "WARN"
            out.append(RunCheck(name=m.group(2), failures=failures, passed=m.group(1) == "pass" or (warn and failures == 0), severity="warn" if warn else "error"))
    return out


def models_in(output: str) -> list[RunModel]:
    """What the load did to each table of a modelled layer: ``model DIM_PARTY staged=11000 rejected=1000 ...``."""
    out: list[RunModel] = []
    for line in output.splitlines():
        m = _MODEL.match(line.strip())
        if m:
            counts = {k: int(v) for k, v in re.findall(r"(\w+)=(\d+)", m.group(2))}
            out.append(RunModel(name=m.group(1), **{k: v for k, v in counts.items() if k in RunModel.model_fields}))
    return out


def reconciliation_in(output: str) -> list[RunReconciliation]:
    """Each table's source against its target: ``recon DIM_PARTY rows source=11000 target=10000 explained=1000 gap=0 explained``."""
    out: list[RunReconciliation] = []
    for line in output.splitlines():
        m = _RECON.match(line.strip())
        if m:
            table, measure, source, target, explained, gap, status = m.groups()
            out.append(
                RunReconciliation(
                    table=table, measure=measure, source=float(source), target=float(target), explained=float(explained), gap=float(gap), status=status.lower()  # type: ignore[arg-type]
                )
            )
    return out


def _paths_problem(folder: Path, data_folder: Path | None, *, reads_files: bool = True) -> str | None:
    if not (folder / "pipeline.py").is_file():
        return f"no generated pipeline in {folder.name}"
    if reads_files and (data_folder is None or not data_folder.is_dir()):
        return "the source folder is not under the data directory"
    return None


@dataclass
class StepResult:
    code: int | None
    output: str


Progress = Callable[[PipelineRun], Awaitable[None]]
Probe = Callable[[dict[str, str]], Awaitable[str | None]]


async def snowflake_probe(env: dict[str, str]) -> str | None:
    """Open a session with the pipeline's own credentials and role (``SELECT CURRENT_ROLE()``) before anything is
    uploaded: a token whose user lacks the role fails here, not halfway through the run. The problem, or None."""
    import httpx  # noqa: PLC0415

    host = env.get("SNOWFLAKE_HOST", "").rstrip("/")
    host = host if "://" in host else f"https://{host}"
    body = {"statement": "SELECT CURRENT_ROLE()", "timeout": 30, "warehouse": env.get("SNOWFLAKE_WAREHOUSE"), "role": env.get("SNOWFLAKE_ROLE")}
    headers = {
        "Authorization": f"Bearer {env.get('SNOWFLAKE_TOKEN', '')}",
        "X-Snowflake-Authorization-Token-Type": env.get("SNOWFLAKE_AUTH_SCHEME") or "PROGRAMMATIC_ACCESS_TOKEN",
        "Accept": "application/json",
    }
    try:
        async with httpx.AsyncClient(base_url=host, headers=headers, timeout=40.0) as client:
            response = await client.post("/api/v2/statements", json={k: v for k, v in body.items() if v})
    except httpx.HTTPError as exc:
        return f"Snowflake could not be reached with the pipeline's settings: {exc}"
    if response.status_code < 400:
        return None
    try:
        message = str(response.json().get("message") or response.text)
    except ValueError:
        message = response.text
    return f"Snowflake refused the pipeline's credentials: {message[:300]}"


class PipelineRunner:
    """Runs the generated runner's commands one after another and reports the run as it goes."""

    def __init__(self, source_env: Callable[[], Mapping[str, str]], *, python: str = sys.executable, probe: Probe | None = None) -> None:
        self._source_env = source_env
        self._python = python
        self._probe = probe

    def env(self) -> dict[str, str]:
        return runtime_env(self._source_env())

    def role(self) -> str | None:
        return self.env().get("SNOWFLAKE_ROLE") or None

    def missing(self, spec: PipelineSpec | None) -> list[str]:
        return missing_settings(spec, self.env())

    async def _step(self, folder: Path, args: list[str], env: dict[str, str], timeout: int) -> StepResult:
        try:
            proc = await asyncio.create_subprocess_exec(
                self._python, "pipeline.py", *args, cwd=str(folder), stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT, env=env
            )
        except OSError as exc:
            return StepResult(None, f"could not start the pipeline: {exc}")
        try:
            out, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except TimeoutError:
            proc.kill()
            await proc.wait()
            return StepResult(None, f"stopped after {timeout} s")
        return StepResult(proc.returncode, out.decode(errors="replace"))

    async def execute(
        self,
        spec: PipelineSpec,
        folder: Path,
        data_folder: Path | None,
        *,
        triggered_by: str,
        progress: Progress,
        catalog: Callable[[], Awaitable[str]] | None = None,
    ) -> PipelineRun:
        env = self.env()
        role = env.get("SNOWFLAKE_ROLE") or None
        run = PipelineRun(
            status="running",
            triggered_by=triggered_by,  # type: ignore[arg-type]
            started_at=datetime.now(tz=UTC),
            role=role,
            steps=[RunStep(key=key, label=label) for key, label in STEPS],  # type: ignore[arg-type]
        )
        if role and role.upper() in ADMIN_ROLES:
            run.warnings.append(f"Statements run as {role.upper()}; a loader role with only the grants this pipeline needs is safer.")
        steps = {s.key: s for s in run.steps}

        async def begin(key: str) -> RunStep:
            step = steps[key]
            step.status, step.started_at = "running", datetime.now(tz=UTC)
            await progress(run)
            return step

        async def fail(step: RunStep, detail: str) -> PipelineRun:
            step.status, step.finished_at, step.detail = "failed", datetime.now(tz=UTC), detail
            for later in run.steps:
                if later.status == "pending":
                    later.status = "skipped"
            run.status, run.finished_at, run.error = "failed", datetime.now(tz=UTC), f"{step.label}: {detail}"
            await progress(run)
            return run

        step = await begin("preflight")
        modelled = spec.kind == "model_layer"
        lacking = missing_settings(spec, env)
        problem = await asyncio.to_thread(lambda: _paths_problem(folder, data_folder, reads_files=not modelled))
        if problem:
            return await fail(step, problem)
        if lacking:
            return await fail(step, f"set {', '.join(lacking)} in .env and restart the query service")
        if self._probe is not None:
            refused = await self._probe(env)
            if refused:
                return await fail(step, mask(refused, env))
        step.status, step.finished_at = "ok", datetime.now(tz=UTC)
        reads = f"reads {spec.source.database}.{spec.source.schema_name}" if modelled else f"files from {data_folder.name if data_folder else '?'}"
        step.detail = f"runs as {role or 'the token user’s default role'}; {reads}"

        warned: list[RunCheck] = []
        for key, args in (("upload", ["upload", str(data_folder)]), ("apply", ["apply"]), ("load", ["load"])):
            if key == "upload" and modelled:
                steps[key].status, steps[key].detail = "skipped", f"nothing to upload: the {spec.target.schema_name} layer is built from tables already in Snowflake"
                continue
            step = await begin(key)
            result = await self._step(folder, args, env, _TIMEOUT[key])
            text = mask(result.output, env)
            step.log = text[-_LOG_TAIL:]
            if key == "upload":
                run.files_uploaded = sum(1 for line in text.splitlines() if line.startswith("uploaded "))
                step.metrics = [WorkflowMetric(label="files", value=str(run.files_uploaded))]
            else:
                done = sum(1 for line in text.splitlines() if line.startswith("ok  "))
                run.statements += done
                step.metrics = [WorkflowMetric(label="statements", value=str(done))]
            if key == "load":
                run.checks = checks_in(text)
                run.models = models_in(text)
                run.reconciliation = reconciliation_in(text)
                failed = [c for c in run.checks if not c.passed and c.severity == "error"]
                warned = [c for c in run.checks if not c.passed and c.severity == "warn"]
                gaps = [r for r in run.reconciliation if r.status == "gap"]
                step.metrics.append(WorkflowMetric(label="checks passed", value=f"{sum(1 for c in run.checks if c.passed)} of {len(run.checks)}"))
                if run.reconciliation:
                    tables = {r.table for r in run.reconciliation}
                    clean = tables - {r.table for r in run.reconciliation if r.status in ("gap", "warn")}
                    step.metrics.append(WorkflowMetric(label="reconciled", value=f"{len(clean)} of {len(tables)}"))
                    run.warnings += [f"{r.table} {r.measure}: source {r.source:,.6g}, target {r.target:,.6g}" for r in run.reconciliation if r.status == "warn"]
                if warned:
                    step.metrics.append(WorkflowMetric(label="warnings", value=str(len(warned))))
                    run.warnings += [f"{c.name}: {c.failures:,} row(s)" for c in warned]
                if result.code == 1 and gaps and not failed:
                    first = gaps[0]
                    return await fail(
                        step,
                        f"{len(gaps)} reconciliation gap(s): {first.table} {first.measure} source {first.source:,.0f}, target {first.target:,.0f}"
                        + (f", {first.explained:,.0f} rejected" if first.explained else ""),
                    )
                if run.models:
                    step.metrics += [
                        WorkflowMetric(label="rows merged", value=f"{sum(m.inserted + m.updated for m in run.models):,}"),
                        WorkflowMetric(label="rejected", value=f"{sum(m.rejected for m in run.models):,}"),
                    ]
                if result.code == 1 and run.checks and failed:
                    return await fail(step, f"{len(failed)} check(s) failed: {', '.join(c.name for c in failed[:5])}")
            if result.code != 0:
                last = next((line for line in reversed(text.strip().splitlines()) if line.strip()), "no output")
                return await fail(step, last[:300])
            if key == "upload" and run.files_uploaded == 0:
                return await fail(step, "no files matched the pipeline's file pattern")
            step.status, step.finished_at = "ok", datetime.now(tz=UTC)
            step.detail = {
                "upload": f"{run.files_uploaded} file(s) to {landing_of(spec.source).label}",
                "apply": f"schema, {len(spec.models)} tables and the rejects table in place" if modelled else "stage, file format and tables in place",
                "load": (
                    f"{len(run.models) or len(spec.models)} table(s) merged; every check passed" + (f", {len(warned)} warning(s)" if warned else "")
                    if modelled
                    else f"{len(spec.tables) or 1} table(s) loaded; every check passed"
                )
                + ("; source and target reconcile" if run.reconciliation and all(r.status in ("match", "explained") for r in run.reconciliation) else ""),
            }[key]
            await progress(run)

        step = await begin("catalog")
        if catalog is None:
            step.status, step.detail = "skipped", "the ingestion service is not configured"
        else:
            try:
                run.catalog_run_id = await catalog()
                step.status, step.detail = "ok", "a Snowflake sync of the target schema started"
            except Exception as exc:  # noqa: BLE001 - the data is loaded; a catalog refresh can be started from Pipelines
                step.status, step.detail = "failed", f"{str(exc)[:200]}; start a Snowflake run on the Pipelines page"
        step.finished_at = datetime.now(tz=UTC)
        run.status, run.finished_at = "succeeded", datetime.now(tz=UTC)
        await progress(run)
        return run
