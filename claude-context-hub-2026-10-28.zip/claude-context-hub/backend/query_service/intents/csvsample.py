"""Sample CSV files from a folder and infer Snowflake column types from the values seen."""

from __future__ import annotations

import csv
import re
from dataclasses import dataclass, field
from pathlib import Path

_INT = re.compile(r"^[+-]?\d{1,38}$")
_FLOAT = re.compile(r"^[+-]?(\d+\.\d*|\.\d+|\d+)([eE][+-]?\d+)?$")
_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$|^\d{2}/\d{2}/\d{4}$|^\d{2}-\d{2}-\d{4}$")
_TIMESTAMP = re.compile(r"^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:?\d{2})?$")
_BOOL = {"true", "false", "yes", "no", "y", "n", "t", "f"}
_NULLS = {"", "null", "none", "n/a", "na", "nan", "\\n"}
_IDENT = re.compile(r"[^A-Za-z0-9]+")
MAX_RECORDS = 1000  # sampled rows kept whole, to run copied checks against before anything is loaded


def snowflake_identifier(header: str) -> str:
    """``Policy Number`` / ``policy-number`` / ``policyNumber`` → ``POLICY_NUMBER``."""
    spaced = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", "_", header.strip())
    ident = _IDENT.sub("_", spaced).strip("_").upper()
    if not ident:
        ident = "COLUMN"
    if ident[0].isdigit():
        ident = f"C_{ident}"
    return ident


@dataclass
class SampledColumn:
    header: str
    name: str
    values: list[str] = field(default_factory=list)
    nulls: int = 0
    seen: int = 0

    @property
    def nullable(self) -> bool:
        return self.nulls > 0

    @property
    def sample(self) -> str | None:
        return next((v for v in self.values if v.strip().lower() not in _NULLS), None)

    def inferred_type(self) -> str:
        values = [v.strip() for v in self.values if v.strip().lower() not in _NULLS]
        if not values:
            return "VARCHAR"
        if all(v.lower() in _BOOL for v in values):
            return "BOOLEAN"
        if all(_INT.match(v) for v in values):
            width = max(len(v.lstrip("+-")) for v in values)
            return "NUMBER(38,0)" if width > 18 else "NUMBER(18,0)"
        if all(_FLOAT.match(v) for v in values):
            scale = max((len(v.split(".")[1].split("e")[0].split("E")[0]) if "." in v else 0) for v in values)
            return f"NUMBER(18,{min(max(scale, 2), 9)})"
        if all(_TIMESTAMP.match(v) for v in values):
            return "TIMESTAMP_NTZ"
        if all(_DATE.match(v) for v in values):
            return "DATE"
        longest = max(len(v) for v in values)
        if longest <= 16:
            return "VARCHAR(64)"
        if longest <= 128:
            return "VARCHAR(256)"
        return "VARCHAR"


@dataclass
class CsvSample:
    folder: str
    files: list[str]
    columns: list[SampledColumn]
    rows: int
    delimiter: str
    problems: list[str] = field(default_factory=list)
    records: list[dict[str, str | None]] = field(default_factory=list)
    record_files: list[str] = field(default_factory=list)


def sample_folder(
    folder: Path,
    *,
    pattern: str = "*.csv",
    max_files: int = 5,
    max_rows: int = 200,
    delimiter: str | None = None,
    encoding: str = "utf-8",
    keep: int = MAX_RECORDS,
) -> CsvSample:
    """Read the headers and the first rows of up to `max_files` files; columns are the union in first-seen order.

    Up to `keep` rows are kept whole (as records) for checks to run against before anything is loaded.
    """
    files = sorted(p for p in folder.glob(pattern) if p.is_file())[:max_files]
    columns: dict[str, SampledColumn] = {}
    raw_records: list[list[tuple[SampledColumn, str]]] = []
    record_files: list[str] = []
    rows = 0
    problems: list[str] = []
    chosen = delimiter
    for path in files:
        try:
            with path.open("r", encoding=encoding, newline="") as handle:
                head = handle.read(8192)
                handle.seek(0)
                if chosen is None:
                    try:
                        chosen = csv.Sniffer().sniff(head, delimiters=",;|\t").delimiter
                    except csv.Error:
                        chosen = ","
                reader = csv.reader(handle, delimiter=chosen)
                header = next(reader, None)
                if not header:
                    problems.append(f"{path.name}: empty file")
                    continue
                cols = []
                for raw in header:
                    key = raw.strip()
                    if key not in columns:
                        columns[key] = SampledColumn(header=key, name=snowflake_identifier(key))
                    cols.append(columns[key])
                for i, row in enumerate(reader):
                    if i >= max_rows:
                        break
                    rows += 1
                    if len(raw_records) < keep:
                        raw_records.append(list(zip(cols, row, strict=False)))
                        record_files.append(path.name)
                    for col, value in zip(cols, row, strict=False):
                        col.seen += 1
                        if value.strip().lower() in _NULLS:
                            col.nulls += 1
                        elif len(col.values) < 50:
                            col.values.append(value)
                    if len(row) != len(cols):
                        problems.append(f"{path.name}: row {i + 2} has {len(row)} fields, header has {len(cols)}")
        except (OSError, UnicodeDecodeError) as exc:
            problems.append(f"{path.name}: {exc}")
    # Names must be unique after normalisation.
    seen: dict[str, int] = {}
    for col in columns.values():
        n = seen.get(col.name, 0)
        seen[col.name] = n + 1
        if n:
            col.name = f"{col.name}_{n + 1}"
    records = [{col.name: (None if value.strip().lower() in _NULLS else value) for col, value in raw} for raw in raw_records]
    return CsvSample(
        folder=str(folder),
        files=[p.name for p in files],
        columns=list(columns.values()),
        rows=rows,
        delimiter=chosen or ",",
        problems=problems[:20],
        records=records,
        record_files=record_files,
    )


def repeated_keys(sample: CsvSample, keys: list[str]) -> dict[tuple[str | None, ...], list[str]]:
    """Key values that occur on more than one sampled row, with the files of those rows in order."""
    seen: dict[tuple[str | None, ...], list[str]] = {}
    for record, name in zip(sample.records, sample.record_files, strict=False):
        value = tuple(record.get(k) for k in keys)
        if all(v is not None for v in value):
            seen.setdefault(value, []).append(name)
    return {value: files for value, files in seen.items() if len(files) > 1}
