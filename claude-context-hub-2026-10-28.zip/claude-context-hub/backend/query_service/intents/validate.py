"""Validate an intent against Snowflake, read-only: which objects it reads, writes or needs already exist.

Only SELECT, SHOW and DESCRIBE statements reach Snowflake (``ReadOnlySql`` refuses anything else), so
validation runs on every parse without creating, loading or altering anything. Without a Snowflake
connection, or when Snowflake cannot be reached, the validation says so and the route falls back to
what the ticket, the files and the repository graph say.
"""

from __future__ import annotations

import json
import re
from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any, Protocol

from ech_core.config import Settings
from ech_core.exceptions import InvalidRequestError
from ech_core.logging import get_logger
from ech_core.schemas.intents import IntentValidation, ValidatedObject

log = get_logger(__name__)
_READ_ONLY = re.compile(r"^\s*(SELECT|SHOW|DESCRIBE|DESC|EXPLAIN|WITH)\b", re.I)
_WRITE = re.compile(r"\b(INSERT|UPDATE|DELETE|MERGE|CREATE|ALTER|DROP|TRUNCATE|COPY|PUT|GRANT|REVOKE|CALL|EXECUTE|USE)\b", re.I)


class SqlRunner(Protocol):
    async def query(self, statement: str) -> list[dict[str, Any]]: ...


class ReadOnlySql:
    """Passes SELECT / SHOW / DESCRIBE through, one statement at a time; anything else is refused before it is sent."""

    def __init__(self, inner: SqlRunner) -> None:
        self._inner = inner
        self.sent: list[str] = []

    async def query(self, statement: str) -> list[dict[str, Any]]:
        body = statement.strip().rstrip(";")
        if not _READ_ONLY.match(body) or ";" in body or _WRITE.search(_without_literals(body)):
            raise InvalidRequestError("intent validation sends one read-only statement at a time (SELECT, SHOW, DESCRIBE or EXPLAIN)")
        self.sent.append(body)
        return await self._inner.query(body)


def _without_literals(sql: str) -> str:
    """The statement with its quoted strings and identifiers blanked, so a word inside them is not taken for a command."""
    return re.sub(r"'(?:[^']|'')*'|\"(?:[^\"]|\"\")*\"", "''", sql)


class SnowflakeReader:
    """Opens a read-only session on whichever Snowflake connection is current (environment or Connectors page)."""

    def __init__(self, settings: Callable[[], Awaitable[Settings]]) -> None:
        self._settings = settings

    @asynccontextmanager
    async def session(self) -> AsyncIterator[ReadOnlySql | None]:
        settings = await self._settings()
        if not settings.snowflake_account:
            yield None
            return
        # The ingestion service owns the SQL API client; the intent service only ever reads through it.
        from ingestion_service.connectors.snowflake import sql_client_from_settings  # noqa: PLC0415

        client = sql_client_from_settings(settings)
        try:
            yield ReadOnlySql(client)
        finally:
            await client.aclose()


@dataclass
class Expectation:
    """What the intent will read and write, as far as the ticket, the files and the repository graph tell."""

    target_database: str | None = None
    target_schema: str | None = None
    target_tables: list[str] = field(default_factory=list)  # empty: whatever the schema holds
    source_database: str | None = None
    source_schema: str | None = None
    source_tables: list[str] = field(default_factory=list)
    external_volume: str | None = None
    integration: str | None = None
    identifiers_known: bool = False  # every target table's key comes from a repository contract or its own <file>_id column
    files_read: bool = False  # the source files were found and read: their encoding, delimiter and header are known
    stage: str | None = None  # an existing stage the ticket names: it already reads the landing folder through its integration
    designed: bool = False  # design documents (a mapping, a data model, DDL) give the tables, columns, keys and transformations
    design_names: list[str] = field(default_factory=list)  # the tables and columns those documents define
    notes: list[str] = field(default_factory=list)


def _lit(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def _q(identifier: str) -> str:
    return '"' + identifier.replace('"', '""') + '"'


def _up(value: str | None) -> str | None:
    return value.strip().upper() if value and value.strip() else None


async def validate(sql: SqlRunner | None, expect: Expectation) -> IntentValidation:
    """Look up every object of `expect` in Snowflake; a statement that fails marks the validation unreachable."""
    now = datetime.now(UTC)
    if sql is None:
        return IntentValidation(checked_at=now, reachable=False, error="Snowflake is not connected", summary="Not validated: Snowflake is not connected.")
    try:
        objects = await _objects(sql, expect)
    except Exception as exc:  # noqa: BLE001 - an unreachable warehouse leaves the intent unvalidated, not failed
        log.warning("intent.validate.failed", error=str(exc)[:300])
        return IntentValidation(checked_at=now, reachable=False, error=str(exc)[:300], summary="Not validated: Snowflake could not be queried.")
    validation = IntentValidation(checked_at=now, reachable=True, objects=objects)
    validation.summary = summarize(validation, expect)
    return validation


async def _objects(sql: SqlRunner, expect: Expectation) -> list[ValidatedObject]:
    out: list[ValidatedObject] = []
    wanted: dict[str, dict[str, tuple[str, list[str]]]] = {}  # database -> schema -> (role, tables)
    for role, db, schema, tables in (
        ("source", _up(expect.source_database), _up(expect.source_schema), expect.source_tables),
        ("target", _up(expect.target_database), _up(expect.target_schema), expect.target_tables),
    ):
        if db:
            wanted.setdefault(db, {})
            if schema:
                wanted[db][schema] = (role, [t.upper() for t in tables])
    for db, schemas in wanted.items():
        roles = {r for r, _ in schemas.values()} or {"target"}
        exists = bool(await sql.query(f"SHOW DATABASES LIKE {_lit(db)}"))
        out.append(ValidatedObject(kind="database", name=db, role="source" if roles == {"source"} else "target", exists=exists))
        if not schemas:
            continue
        found_schemas: set[str] = set()
        tables: dict[tuple[str, str], dict[str, Any]] = {}
        columns: dict[tuple[str, str], list[str]] = {}
        if exists:
            names = ", ".join(_lit(s) for s in schemas)
            found_schemas = {
                str(r.get("schema_name")).upper() for r in await sql.query(f"SELECT SCHEMA_NAME FROM {_q(db)}.INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME IN ({names})")
            }
            if found_schemas:
                inside = ", ".join(_lit(s) for s in sorted(found_schemas))
                for r in await sql.query(
                    f"SELECT TABLE_SCHEMA, TABLE_NAME, TABLE_TYPE, ROW_COUNT FROM {_q(db)}.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA IN ({inside})"
                ):
                    tables[(str(r.get("table_schema")).upper(), str(r.get("table_name")).upper())] = r
                for r in await sql.query(
                    f"SELECT TABLE_SCHEMA, TABLE_NAME, COLUMN_NAME FROM {_q(db)}.INFORMATION_SCHEMA.COLUMNS "
                    f"WHERE TABLE_SCHEMA IN ({inside}) ORDER BY TABLE_SCHEMA, TABLE_NAME, ORDINAL_POSITION"
                ):
                    columns.setdefault((str(r.get("table_schema")).upper(), str(r.get("table_name")).upper()), []).append(str(r.get("column_name")))
        for schema, (role, expected) in schemas.items():
            out.append(ValidatedObject(kind="schema", name=f"{db}.{schema}", role=role, exists=schema in found_schemas))
            present = sorted(t for s, t in tables if s == schema)
            # A layer is built from what its source schema really holds (CITY_ICEBERG as much as the repository's B_CITY);
            # the expected names stand in only while that schema is empty, to say what is awaited.
            names = present if role == "source" and present else (expected or present)
            for table in names:
                row = tables.get((schema, table))
                out.append(
                    ValidatedObject(
                        kind="table",
                        name=f"{db}.{schema}.{table}",
                        role=role,
                        exists=row is not None,
                        rows=_int(row.get("row_count")) if row else None,
                        columns=columns.get((schema, table), []),
                        detail=str(row.get("table_type") or "") if row else "",
                    )
                )
    if expect.external_volume:
        name = expect.external_volume.upper()
        rows = await sql.query(f"SHOW EXTERNAL VOLUMES LIKE {_lit(name)}")
        props = await _describe(sql, f"DESCRIBE EXTERNAL VOLUME {_q(name)}", volume=True) if rows else {}
        detail = ""
        if not rows and _up(expect.target_database) and _up(expect.target_schema):
            # Without USAGE on the volume the hub's role does not see it, but it does see the Iceberg tables stored on it.
            where = f"{_q(_up(expect.target_database) or '')}.{_q(_up(expect.target_schema) or '')}"
            try:
                on_it = [r for r in await sql.query(f"SHOW ICEBERG TABLES IN SCHEMA {where}") if str(r.get("external_volume_name") or "").upper() == name]
            except Exception:  # noqa: BLE001 - a schema that does not exist yet has no tables on the volume
                on_it = []
            if on_it:
                rows = on_it
                detail = f"in use by {len(on_it)} Iceberg table(s) here; the hub's role cannot describe it (no USAGE)"
        out.append(ValidatedObject(kind="external_volume", name=name, role="prerequisite", exists=bool(rows), detail=detail, properties=props))
    if expect.integration:
        name = expect.integration.upper()
        rows = await sql.query(f"SHOW INTEGRATIONS LIKE {_lit(name)}")
        enabled = next((str(r.get("enabled")) for r in rows), "")
        props = await _describe(sql, f"DESCRIBE INTEGRATION {_q(name)}", volume=False) if rows else {}
        out.append(
            ValidatedObject(
                kind="integration", name=name, role="prerequisite", exists=bool(rows), detail="disabled" if enabled.lower() == "false" else "", properties=props
            )
        )
    if expect.stage and expect.stage.count(".") == 2:
        db, schema, name = (p.upper() for p in expect.stage.split("."))
        detail, props = "", {}
        try:
            rows = await sql.query(f"SHOW STAGES LIKE {_lit(name)} IN SCHEMA {_q(db)}.{_q(schema)}")
        except Exception:  # noqa: BLE001 - the schema is gone (dropped and recreated), or the hub's role has no USAGE on it
            rows, detail = [], f"schema {db}.{schema} does not exist or is not visible to the hub's role"
        if rows:
            props = {k.upper(): str(rows[0][k]) for k in ("url", "storage_integration") if rows[0].get(k)}
            detail = f"reads {props.get('URL', 'an unknown location')} through {props.get('STORAGE_INTEGRATION', 'its own credentials')}"
        out.append(ValidatedObject(kind="stage", name=f"{db}.{schema}.{name}", role="prerequisite", exists=bool(rows), detail=detail, properties=props))
    return out


_DESCRIBED = ("STORAGE_PROVIDER", "STORAGE_ALLOWED_LOCATIONS", "STORAGE_BASE_URL", "AZURE_CONSENT_URL", "AZURE_MULTI_TENANT_APP_NAME")


async def _describe(sql: SqlRunner, statement: str, *, volume: bool) -> dict[str, str]:
    """Where an integration or volume points (provider, locations, Azure consent): read-only, and empty when the role may not see it."""
    try:
        rows = await sql.query(statement)
    except Exception as exc:  # noqa: BLE001 - DESCRIBE needs more than USAGE on some objects; the object still exists
        log.info("intent.validate.describe_failed", statement=statement[:80], error=str(exc)[:200])
        return {}
    props: dict[str, str] = {}
    for r in rows:
        key, value = str(r.get("property") or "").upper(), r.get("property_value")
        if volume and key.startswith("STORAGE_LOCATION_") and isinstance(value, str) and not props:
            try:
                location = json.loads(value)
            except ValueError:
                continue
            props = {k: str(v) for k, v in location.items() if k in _DESCRIBED and v not in (None, "")}
        elif not volume and key in _DESCRIBED and value not in (None, ""):
            props[key] = str(value)
    return props


def _int(value: Any) -> int | None:
    try:
        return int(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def tables_of(validation: IntentValidation | None, role: str) -> tuple[list[ValidatedObject], list[ValidatedObject]]:
    """The tables of one role, split into those that exist and those that do not."""
    if validation is None:
        return [], []
    tables = [o for o in validation.objects if o.kind == "table" and o.role == role]
    return [o for o in tables if o.exists], [o for o in tables if not o.exists]


def summarize(validation: IntentValidation, expect: Expectation) -> str:
    parts: list[str] = []
    for obj in validation.objects:
        if obj.kind in ("database", "schema") and not obj.exists:
            parts.append(f"{obj.kind} {obj.name} does not exist yet")
    for role, label in (("source", "source"), ("target", "target")):
        have, missing = tables_of(validation, role)
        total = len(have) + len(missing)
        if total:
            parts.append(f"{len(have)} of {total} {label} table{'s' if total != 1 else ''} exist")
        elif role == "source" and expect.source_schema:
            parts.append(f"no tables in {expect.source_database}.{expect.source_schema}")
    for obj in validation.objects:
        if obj.kind in ("external_volume", "integration", "stage"):
            label = {"external_volume": "external volume", "integration": "storage integration"}.get(obj.kind, obj.kind)
            if not obj.exists:
                parts.append(f"{label} {obj.name} is missing")
            elif obj.detail == "disabled":
                parts.append(f"{label} {obj.name} is disabled")
    if not parts:
        return "Everything the intent needs is in place."
    text = "; ".join(parts) + "."
    return text[0].upper() + text[1:]
