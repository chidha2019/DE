"""The data modeler: proposes the tables of a silver or gold layer from the layer below it.

Claude designs the model with read-only tools: it profiles the loaded source tables, reads the models the
crawled repository already defines for the layer (grain, keys, column lineage, checks), and tries its SQL
against Snowflake (EXPLAIN, then a count of rows and distinct keys). Its answer is then checked without it:
the SQL must parse, read only known tables and columns, produce the columns it declares, compile in
Snowflake and keep its key unique. What fails is written on the model as a finding and on the spec as a
risk, for the person who approves it. Nothing is created or loaded here; that waits for approval.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import quote

import sqlglot
from pydantic import BaseModel, Field, ValidationError
from sqlglot import exp
from sqlglot.errors import SqlglotError

from ech_core.llm.client import ModelClient
from ech_core.llm.schema import strict_tool_schema
from ech_core.logging import get_logger
from ech_core.repositories.glossary_repository import GlossaryRepository
from ech_core.repositories.repo_graph_repository import RepoGraphRepository
from ech_core.schemas.intents import (
    IntentValidation,
    ModelColumn,
    ModelTable,
    PipelineSpec,
    SpecMatch,
    SpecTest,
    StructuredIntent,
)
from query_service.intents.planner import cron_for
from query_service.intents.validate import Expectation, SnowflakeReader, SqlRunner

log = get_logger(__name__)
DIALECT = "snowflake"
MAX_STEPS = 24
_RESULT_LIMIT = 6000
_JSON_BLOCK = re.compile(r"\{.*\}", re.S)
_UPSTREAM = {"silver": "bronze", "gold": "silver"}
_KIND = {"DIM": "dimension", "FACT": "fact", "BRIDGE": "bridge", "REF": "reference", "AGG": "aggregate"}

SYSTEM_PROMPT = """You are the data modeler of an insurance lakehouse on Snowflake. You design the {layer} layer
of {database} from the {upstream} tables listed below, for the request in the ticket.

{repo_note}

Work like this:
1. Read the ticket and the source tables. Use profile_columns to see values, blanks and candidate keys.
2. Use repo_model to read a repository model in full before you adopt or change it.
3. Write one SELECT per table and try it with test_sql, giving the key: it must compile against the real
   tables and the key must be unique and never null. Fix and retry until it is.
4. Answer with JSON only (no prose, no fences):
{{"models": [{{"name": "DIM_PARTY", "kind": "dimension|fact|bridge|reference|aggregate",
  "grain": "one row per ...", "description": "...", "keys": ["PARTY_SK"], "load_mode": "full_refresh|merge",
  "sources": ["{database}.{upstream_upper}.A_CUSTOMER"], "sql": "SELECT ...",
  "columns": [{{"name": "PARTY_SK", "type": "VARCHAR", "expression": "...", "nullable": false,
    "description": "...", "sources": ["{upstream_upper}.A_CUSTOMER.CUST_ID"]}}],
  "relationships": [{{"columns": ["PARTY_SK"], "to_table": "DIM_PARTY", "to_columns": ["PARTY_SK"]}}],
  "exemplar": "{layer_upper}.DIM_PARTY or null", "deviations": ["what differs from the exemplar, and why"]}}],
 "notes": ["anything the reviewer must know"]}}

SQL rules: Snowflake dialect; fully qualified source names ({database}.{upstream_upper}.TABLE); the SELECT's
output columns are exactly the model's columns, in order; the {upstream} columns are VARCHAR, so cast with
TRY_TO_DATE, TRY_TO_TIMESTAMP and TRY_TO_DECIMAL(x, 18, 2); a table that combines source systems adds a
SOURCE_SYSTEM column and a surrogate key that keeps the systems apart (as the repository does). A model may
read another model of this layer by its name ({database}.{layer_upper}.NAME). Never write DDL or DML."""


# --------------------------------------------------------------------------- tools
class ProfileColumnsInput(BaseModel):
    table: str = Field(description="a source table, e.g. A_CLAIM or OMNICLAIM.BRONZE.A_CLAIM")
    columns: list[str] = Field(description="up to 12 of its columns; empty profiles the first 12", max_length=12)


class RepoModelInput(BaseModel):
    name: str = Field(description="a repository model, e.g. SILVER.FACT_LOSS_EVENT")


class TestSqlInput(BaseModel):
    sql: str = Field(description="one SELECT statement, no semicolon")
    key: list[str] = Field(description="the key columns of its output, to check uniqueness and blanks")


TOOLS: list[dict[str, Any]] = [
    {
        "name": "profile_columns",
        "description": "Row count, distinct and non-blank counts, min and max of columns of a source table, plus 5 sample rows (read-only).",
        "input_schema": strict_tool_schema(ProfileColumnsInput),
    },
    {
        "name": "repo_model",
        "description": "A model the crawled repository defines: grain, key, columns with type and the source columns each derives from, the tables it reads and its checks.",
        "input_schema": strict_tool_schema(RepoModelInput),
    },
    {
        "name": "test_sql",
        "description": "Compile a SELECT in Snowflake (EXPLAIN), then count its rows, distinct keys and blank keys, and show 3 rows. Read-only.",
        "input_schema": strict_tool_schema(TestSqlInput),
    },
]


class Proposal(BaseModel):
    models: list[ModelTable]
    notes: list[str] = Field(default_factory=list)


@dataclass
class ModelContext:
    layer: str
    upstream: str
    database: str
    target_schema: str
    source_schema: str
    sources: dict[str, list[str]] = field(default_factory=dict)  # FQN -> columns
    rows: dict[str, int | None] = field(default_factory=dict)
    repo: str | None = None
    repo_models: list[dict[str, Any]] = field(default_factory=list)
    loaded_as: dict[str, str] = field(default_factory=dict)  # repository table (BRONZE.B_CITY) -> loaded table FQN

    def resolve(self, upstream: str) -> str:
        """A repository column (BRONZE.B_CITY.CITY_ID) as the loaded one (LIFE_INSURANCE_DB.BRONZE.CITY_ICEBERG.CITY_ID)."""
        table, _, column = upstream.upper().rpartition(".")
        loaded = self.loaded_as.get(table)
        if loaded is None:
            return upstream
        by_norm = {_norm(c): c.upper() for c in self.sources.get(loaded, [])}
        return f"{loaded}.{by_norm.get(_norm(column), column)}"


def _norm(text: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (text or "").lower())


def _bare(name: str) -> str:
    """A table name without its schema, a source-system prefix (A_, B_) or a load suffix (_ICEBERG): CITY."""
    short = name.rsplit(".", 1)[-1].upper()
    short = re.sub(r"_(ICEBERG|RAW|STG|BRONZE|SILVER)$", "", short)
    return _norm(re.sub(r"^[A-Z]_", "", short))


def match_loaded(repo: dict[str, Any], layer: str, schema: str, loaded: dict[str, list[str]]) -> dict[str, str]:
    """Which loaded table each repository table of a layer became: same bare name with some shared columns, or most
    columns shared. A same-named table with other columns (a different claim file) is not a match."""
    headers = {str(s.get("table") or "").upper(): {_norm(h) for h in s.get("headers") or []} for s in repo.get("sources") or []}
    candidates = [str(t["name"]).upper() for t in repo.get("tables") or [] if t.get("layer") == layer and str(t["name"]).upper().startswith(schema.upper() + ".")]
    scored: list[tuple[float, str, str]] = []
    for name in candidates:
        theirs = headers.get(name)
        for fqn, columns in loaded.items():
            mine = {_norm(c) for c in columns}
            overlap = len(mine & theirs) / len(mine | theirs) if theirs and mine else None
            if _bare(name) == _bare(fqn) and (overlap is None or overlap >= 0.3):
                scored.append((1 + (overlap or 0), name, fqn))
            elif overlap is not None and overlap >= 0.6:
                scored.append((overlap, name, fqn))
    out: dict[str, str] = {}
    for _, name, fqn in sorted(scored, reverse=True):
        if name not in out and fqn not in out.values():
            out[name] = fqn
    return out


def _fqn(ctx: ModelContext, name: str) -> str | None:
    """A source table's fully qualified name from a short or qualified one, if it is a known source."""
    wanted = name.strip().strip('"').upper()
    for full in ctx.sources:
        if full == wanted or full.endswith("." + wanted):
            return full
    return None


def _q(identifier: str) -> str:
    return '"' + identifier.replace('"', '""') + '"'


class DataModeler:
    def __init__(
        self,
        *,
        model: ModelClient | None,
        reader: SnowflakeReader | None,
        repo_graph: RepoGraphRepository | None,
        glossary: GlossaryRepository | None = None,
        max_steps: int = MAX_STEPS,
    ) -> None:
        self._model = model
        self._reader = reader
        self._repo_graph = repo_graph
        self._glossary = glossary
        self._max_steps = max_steps

    async def model(self, intent: StructuredIntent, title: str, expect: Expectation, validation: IntentValidation | None) -> PipelineSpec:
        ctx = await self._context(intent, expect, validation)
        notes: list[str] = []
        risks: list[str] = []
        reachable = validation is not None and validation.reachable
        if self._reader is not None and reachable:
            async with self._reader.session() as sql:
                models, notes, risks = await self._design(intent, title, ctx, sql)
                await self._check(models, ctx, sql, risks)
        else:
            models, notes, risks = await self._design(intent, title, ctx, None)
            await self._check(models, ctx, None, risks)
            risks.append("Snowflake was not checked: the SQL is parsed but not compiled, and keys are not checked against the data.")
        return self._spec(intent, title, ctx, models, notes, risks, validation)

    # ------------------------------------------------------------------ context
    async def _context(self, intent: StructuredIntent, expect: Expectation, validation: IntentValidation | None) -> ModelContext:
        layer = intent.layer or ("gold" if intent.kind == "gold_fact" else "silver")
        upstream = _UPSTREAM.get(layer, "bronze")
        ctx = ModelContext(
            layer=layer,
            upstream=upstream,
            database=(expect.target_database or expect.source_database or "").upper(),
            target_schema=(expect.target_schema or layer).upper(),
            source_schema=(expect.source_schema or upstream).upper(),
        )
        if validation is not None and validation.reachable:
            for obj in validation.objects:
                if obj.kind == "table" and obj.role == "source" and obj.exists:
                    ctx.sources[obj.name.upper()] = obj.columns
                    ctx.rows[obj.name.upper()] = obj.rows
        if self._repo_graph is not None:
            try:
                repos = await self._repo_graph.conventions()
                repo = max(repos, key=lambda r: sum(1 for t in r["tables"] if t.get("layer") == layer), default=None)
                if repo is not None:
                    ctx.repo = repo["repo"]
                    for table in sorted((t for t in repo["tables"] if t.get("layer") == layer), key=lambda t: str(t["name"])):
                        found = await self._repo_graph.exemplar(repo["repo"], str(table["name"]))
                        if found is not None:
                            ctx.repo_models.append(found)
                    if ctx.sources:
                        ctx.loaded_as = match_loaded(repo, upstream, ctx.source_schema, ctx.sources)
                    else:
                        # Without Snowflake the contracts of the layer below stand in for the loaded tables.
                        for table in (t for t in repo["tables"] if t.get("layer") == upstream):
                            found = await self._repo_graph.exemplar(repo["repo"], str(table["name"]))
                            if found is not None:
                                name = f"{ctx.database}.{str(table['name']).upper()}"
                                ctx.sources[name] = [str(c.get("column") or "") for c in found["columns"]]
            except Exception as exc:  # noqa: BLE001 - the repository graph is optional context
                log.warning("intent.modeler.repo_graph_failed", error=str(exc))
        return ctx

    def _repo_summary(self, model: dict[str, Any], ctx: ModelContext, *, full: bool) -> dict[str, Any]:
        """A repository model, with the source columns it derives from named as they were loaded."""
        table = model["table"]
        columns = []
        for c in model["columns"]:
            item: dict[str, Any] = {"name": c.get("column"), "type": c.get("type")}
            if c.get("derivation"):
                item["derivation"] = c["derivation"]
            if c.get("upstream"):
                item["from"] = [ctx.resolve(str(u)) for u in c["upstream"]]
            columns.append(item)
        out: dict[str, Any] = {"name": table.get("name"), "grain": table.get("grain") or table.get("key"), "key": table.get("key")}
        if full:
            out["columns"] = columns
            out["checks"] = [k.get("name") for k in model.get("checks") or []]
            out["definition"] = table.get("definition")
        else:
            out["columns"] = [c["name"] for c in columns]
        return out

    # ------------------------------------------------------------------ design
    async def _design(self, intent: StructuredIntent, title: str, ctx: ModelContext, sql: SqlRunner | None) -> tuple[list[ModelTable], list[str], list[str]]:
        if self._model is None:
            models = self._from_repository(ctx)
            return models, ["No model client is configured, so the repository's models were taken as they are."], []
        repo_note = (
            f"The repository {ctx.repo} already defines {len(ctx.repo_models)} {ctx.layer} models (below); start from them, keep "
            "their names, grain and keys unless the ticket or the loaded data says otherwise, and record every difference in deviations."
            if ctx.repo_models
            else f"No repository defines {ctx.layer} models for these tables; design them from the ticket and the data."
        )
        if ctx.loaded_as:
            repo_note += (
                f" The {ctx.upstream} tables were loaded under other names than the repository's: repository_tables_loaded_as maps "
                "them, and the repository models' source columns are already given under the loaded names. A repository table "
                "missing from that map was not loaded; leave out what only it could feed."
            )
        system = SYSTEM_PROMPT.format(
            layer=ctx.layer,
            layer_upper=ctx.target_schema,
            upstream=ctx.upstream,
            upstream_upper=ctx.source_schema,
            database=ctx.database or "DB",
            repo_note=repo_note,
        )
        brief = {
            "ticket": {"title": title, "summary": intent.summary, "acceptance_criteria": intent.acceptance_criteria, "business_terms": intent.business_terms},
            "target": f"{ctx.database}.{ctx.target_schema}",
            "source_tables": [{"name": name, "rows": ctx.rows.get(name), "columns": cols} for name, cols in sorted(ctx.sources.items())],
            "repository_models": [self._repo_summary(m, ctx, full=False) for m in ctx.repo_models],
        }
        if ctx.loaded_as:
            brief["repository_tables_loaded_as"] = ctx.loaded_as
        messages: list[dict[str, Any]] = [{"role": "user", "content": json.dumps(brief, indent=1)}]
        answer = ""
        for _ in range(self._max_steps):
            turn = await self._model.complete(system=system, tools=TOOLS, messages=messages)
            messages.append({"role": "assistant", "content": turn.content})
            if not turn.tool_uses:
                answer = turn.text
                break
            results = []
            for use in turn.tool_uses:
                content, failed = await self._tool(use["name"], use.get("input") or {}, ctx, sql)
                block: dict[str, Any] = {"type": "tool_result", "tool_use_id": use["id"], "content": content[:_RESULT_LIMIT]}
                if failed:
                    block["is_error"] = True
                results.append(block)
            messages.append({"role": "user", "content": results})
        else:
            messages.append({"role": "user", "content": "You have used your tool budget. Answer now with the JSON only."})
            answer = (await self._model.complete(system=system, tools=TOOLS, messages=messages)).text
        for attempt in range(2):
            try:
                proposal = _parse(answer)
                return proposal.models, proposal.notes, []
            except (ValueError, ValidationError) as exc:
                if attempt:
                    raise ValueError(f"the data modeler's answer could not be read: {str(exc)[:300]}") from exc
                messages.append({"role": "assistant", "content": answer or "(empty)"})
                messages.append({"role": "user", "content": f"That was not valid JSON in the required shape ({str(exc)[:400]}). Answer again with the JSON only."})
                answer = (await self._model.complete(system=system, tools=TOOLS, messages=messages)).text
        return [], [], []

    async def _tool(self, name: str, raw: dict[str, Any], ctx: ModelContext, sql: SqlRunner | None) -> tuple[str, bool]:
        try:
            if name == "profile_columns":
                return await self._profile(ProfileColumnsInput.model_validate(raw), ctx, sql), False
            if name == "repo_model":
                args = RepoModelInput.model_validate(raw)
                wanted = args.name.strip().upper()
                found = next((m for m in ctx.repo_models if str(m["table"].get("name", "")).upper() in (wanted, f"{ctx.target_schema}.{wanted}")), None)
                if found is None:
                    return f"No repository model {args.name}; known: {', '.join(str(m['table'].get('name')) for m in ctx.repo_models)}", True
                return json.dumps(self._repo_summary(found, ctx, full=True)), False
            if name == "test_sql":
                return await self._test_sql(TestSqlInput.model_validate(raw), ctx, sql), False
            return f"unknown tool {name}", True
        except ValidationError as exc:
            return f"invalid input: {str(exc)[:300]}", True
        except Exception as exc:  # noqa: BLE001 - the model sees the failure and can correct itself
            return f"{type(exc).__name__}: {str(exc)[:500]}", True

    async def _profile(self, args: ProfileColumnsInput, ctx: ModelContext, sql: SqlRunner | None) -> str:
        table = _fqn(ctx, args.table)
        if table is None:
            return f"{args.table} is not a source table; use one of {', '.join(sorted(ctx.sources))}"
        if sql is None:
            return "Snowflake is not reachable; design from the columns listed and the repository models."
        known = ctx.sources[table]
        columns = [c for c in (args.columns or known) if c.upper() in {k.upper() for k in known}][:12] or known[:12]
        parts = ["COUNT(*) AS ROWS"]
        for c in columns:
            parts += [f"COUNT(DISTINCT {_q(c)}) AS {_q(c + ':distinct')}", f"COUNT({_q(c)}) AS {_q(c + ':filled')}", f"MIN({_q(c)}) AS {_q(c + ':min')}", f"MAX({_q(c)}) AS {_q(c + ':max')}"]
        name = ".".join(_q(p) for p in table.split("."))
        stats = await sql.query(f"SELECT {', '.join(parts)} FROM {name}")
        sample = await sql.query(f"SELECT {', '.join(_q(c) for c in columns)} FROM {name} LIMIT 5")
        return json.dumps({"table": table, "profile": stats[0] if stats else {}, "sample": sample}, default=str)

    async def _test_sql(self, args: TestSqlInput, ctx: ModelContext, sql: SqlRunner | None) -> str:
        statement = args.sql.strip().rstrip(";")
        problem = _parse_problem(statement)
        if problem:
            return f"does not parse as one SELECT: {problem}"
        if sql is None:
            return "parses; Snowflake is not reachable, so it was not compiled or run."
        try:
            await sql.query(f"EXPLAIN USING TEXT {statement}")
        except Exception as exc:  # noqa: BLE001 - the compile error is the answer
            return f"does not compile: {str(exc)[:600]}"
        out: dict[str, Any] = {"compiles": True}
        if args.key:
            key = ", ".join(_q(k.upper()) for k in args.key)
            blanks = " OR ".join(f"{_q(k.upper())} IS NULL" for k in args.key)
            counts = await sql.query(f"SELECT COUNT(*) AS N, COUNT(DISTINCT {key}) AS KEYS, COUNT_IF({blanks}) AS BLANK_KEYS FROM ({statement})")
            out["counts"] = counts[0] if counts else {}
        out["rows"] = await sql.query(f"SELECT * FROM ({statement}) LIMIT 3")
        return json.dumps(out, default=str)

    def _from_repository(self, ctx: ModelContext) -> list[ModelTable]:
        """Without a model client: the repository's models as they are, with SQL only where one source table feeds every column."""
        out: list[ModelTable] = []
        for m in ctx.repo_models:
            table = m["table"]
            name = str(table.get("table") or str(table.get("name")).rsplit(".", 1)[-1])
            columns = []
            feeds: set[str] = set()
            for c in m["columns"]:
                upstream = [ctx.resolve(str(u)) for u in c.get("upstream") or []]
                feeds |= {u.rsplit(".", 1)[0] for u in upstream}
                expression = upstream[0].rsplit(".", 1)[-1] if len(upstream) == 1 else "NULL"
                columns.append(ModelColumn(name=str(c.get("column")), type="VARCHAR" if str(c.get("type")).upper() == "STRING" else str(c.get("type")), expression=expression, sources=upstream))
            # A source still under its repository name (BRONZE.B_CITY) gets the database; a loaded one is already qualified.
            tables = sorted(f if f.count(".") >= 2 else f"{ctx.database}.{f}" for f in feeds)
            sql_text = ""
            findings = []
            if len(tables) == 1:
                sql_text = f"SELECT {', '.join(f'{c.expression} AS {c.name}' for c in columns)} FROM {tables[0]}"
            else:
                findings.append(f"reads {len(tables)} tables; its SQL needs the data modeler (no model client is configured)")
            out.append(
                ModelTable(
                    name=name,
                    kind=_KIND.get(name.split("_", 1)[0], "reference"),  # type: ignore[arg-type]
                    grain=f"one row per {', '.join(table.get('grain') or table.get('key') or ['?'])}",
                    keys=list(table.get("key") or []),
                    sources=tables,
                    sql=sql_text,
                    columns=columns,
                    exemplar=str(table.get("name")),
                    findings=findings,
                )
            )
        return out

    # ------------------------------------------------------------------ deterministic checks
    async def _check(self, models: list[ModelTable], ctx: ModelContext, sql: SqlRunner | None, risks: list[str]) -> None:
        names = {f"{ctx.database}.{ctx.target_schema}.{m.name}".upper(): m for m in models}
        for m in models:
            findings: list[str] = []
            problem = _parse_problem(m.sql) if m.sql else "no SQL"
            if problem:
                findings.append(f"SQL does not parse: {problem}")
            else:
                tree = sqlglot.parse_one(m.sql, read=DIALECT)
                read = sorted({".".join(p for p in (t.catalog, t.db, t.name) if p).upper() for t in tree.find_all(exp.Table)} - _cte_names(tree))
                unknown = [t for t in read if t not in ctx.sources and t not in names and _fqn(ctx, t) is None]
                if unknown:
                    findings.append(f"reads tables that are neither loaded sources nor models of this layer: {', '.join(unknown)}")
                out_names = [s.alias_or_name.upper() for s in getattr(tree, "selects", [])]
                declared = [c.name.upper() for c in m.columns]
                if out_names and "*" not in out_names and out_names != declared:
                    differ = sorted(set(out_names) ^ set(declared))[:6]
                    findings.append(
                        f"the SELECT returns {len(out_names)} columns, the model declares {len(declared)}"
                        + (f" ({', '.join(differ)})" if differ else " in another order")
                    )
                missing = sorted({f"{s}" for s in _missing_columns(tree, ctx)})
                if missing:
                    findings.append(f"uses columns the sources do not have: {', '.join(missing[:6])}")
                if sql is not None and not findings:
                    try:
                        await sql.query(f"EXPLAIN USING TEXT {m.sql.strip().rstrip(';')}")
                        if m.keys:
                            key = ", ".join(_q(k.upper()) for k in m.keys)
                            blanks = " OR ".join(f"{_q(k.upper())} IS NULL" for k in m.keys)
                            rows = await sql.query(f"SELECT COUNT(*) AS N, COUNT(DISTINCT {key}) AS KEYS, COUNT_IF({blanks}) AS BLANK_KEYS FROM ({m.sql.strip().rstrip(';')})")
                            counts = {k.lower(): v for k, v in (rows[0] if rows else {}).items()}
                            n, keys, blank = int(counts.get("n") or 0), int(counts.get("keys") or 0), int(counts.get("blank_keys") or 0)
                            if keys != n or blank:
                                findings.append(f"key {', '.join(m.keys)} is not unique: {n} rows, {keys} distinct keys, {blank} blank")
                            else:
                                m.findings.append(f"compiles in Snowflake; key {', '.join(m.keys)} unique over {n} rows")
                    except Exception as exc:  # noqa: BLE001 - the error is the finding
                        findings.append(f"does not compile in Snowflake: {str(exc)[:200]}")
            if not m.keys:
                findings.append("no key declared")
            m.findings = [*findings, *m.findings]
            risks += [f"{m.name}: {f}" for f in findings]
            if m.keys and not any(t.kind == "unique" for t in m.tests):
                m.tests.append(SpecTest(name=f"{m.name.lower()}_key_unique", kind="unique", columns=list(m.keys), detail="one row per key"))
                m.tests.append(SpecTest(name=f"{m.name.lower()}_key_not_null", kind="not_null", columns=list(m.keys)))
            if not any(t.kind == "row_count" for t in m.tests):
                m.tests.insert(0, SpecTest(name=f"{m.name.lower()}_rows", kind="row_count", detail="the table holds rows after the load"))

    # ------------------------------------------------------------------ spec
    def _spec(
        self, intent: StructuredIntent, title: str, ctx: ModelContext, models: list[ModelTable], notes: list[str], risks: list[str], validation: IntentValidation | None
    ) -> PipelineSpec:
        target = intent.target.model_copy(update={"database": ctx.database or None, "schema_name": ctx.target_schema, "table": None, "base_location": ctx.target_schema.lower()})
        if not target.external_volume and ctx.repo_models:
            target.external_volume = ctx.repo_models[0]["table"].get("external_volume")
        existing = {o.name.upper() for o in (validation.objects if validation else []) if o.kind == "table" and o.role == "target" and o.exists}
        for m in models:
            m.exists = f"{ctx.database}.{ctx.target_schema}.{m.name}".upper() in existing
        adopted = [m for m in models if m.exemplar]
        assumptions = list(notes)
        if ctx.repo_models:
            assumptions.append(
                f"{len(adopted)} of {len(models)} tables follow models {ctx.repo} defines; "
                f"{sum(1 for m in models if m.deviations)} of them differ from it, each with the reason."
            )
        assumptions.append(f"Built from {len(ctx.sources)} {ctx.upstream} table(s) in {ctx.database}.{ctx.source_schema}; the tables are Snowflake-managed Iceberg tables on {target.external_volume or '(volume to be set)'}.")
        if any(m.load_mode == "full_refresh" for m in models):
            assumptions.append("Full-refresh tables are rebuilt on every run from the current source rows.")
        if not target.external_volume:
            risks.append("No external volume named: the table DDL carries a placeholder (ECH_EXTERNAL_VOLUME) that must be set before apply.")
        layer_word = ctx.layer
        return PipelineSpec(
            name=f"model_{(ctx.database or 'db').lower()}_{layer_word}",
            kind="model_layer",
            summary=intent.summary or title,
            source=intent.source.model_copy(update={"database": ctx.database or None, "schema_name": ctx.source_schema, "folder": None}),
            target=target,
            transformations=[f"{m.name}: {m.grain}" for m in models],
            schedule=cron_for(intent.freshness),
            matches=(
                [SpecMatch(kind="exemplar", name=ctx.repo, detail=f"{len(ctx.repo_models)} {layer_word} models in the repository", link=f"/knowledge?repo={quote(ctx.repo, safe='')}")]
                if ctx.repo
                else []
            ),
            risks=risks,
            assumptions=assumptions,
            models=models,
        )


def _parse(text: str) -> Proposal:
    match = _JSON_BLOCK.search(text or "")
    if not match:
        raise ValueError("no JSON object in the answer")
    raw = json.loads(match.group(0))
    if not isinstance(raw, dict):
        raise ValueError("the answer is not a JSON object")
    for m in raw.get("models") or []:
        if isinstance(m, dict):
            for key in ("exemplar", "description"):
                if m.get(key) in (None, "null"):
                    m.pop(key, None)
            m["tests"] = []
            m["findings"] = []
    return Proposal.model_validate(raw)


def _parse_problem(statement: str) -> str | None:
    try:
        trees = sqlglot.parse(statement, read=DIALECT)
    except SqlglotError as exc:
        return str(exc).splitlines()[0][:200]
    if len(trees) != 1 or trees[0] is None:
        return "more than one statement"
    tree = trees[0]
    if not isinstance(tree, exp.Select | exp.Union | exp.Intersect | exp.Except):
        return f"a {tree.key.upper()} statement, not a SELECT"
    return None


def _cte_names(tree: exp.Expression) -> set[str]:
    return {c.alias_or_name.upper() for c in tree.find_all(exp.CTE)}


def _missing_columns(tree: exp.Expression, ctx: ModelContext) -> list[str]:
    """Qualified column references whose table is a known source and whose column that source lacks."""
    aliases: dict[str, str] = {}
    for t in tree.find_all(exp.Table):
        full = _fqn(ctx, ".".join(p for p in (t.catalog, t.db, t.name) if p))
        if full is not None:
            aliases[t.alias_or_name.upper()] = full
    out: list[str] = []
    for col in tree.find_all(exp.Column):
        if not col.table:
            continue
        source = aliases.get(col.table.upper())
        if source is None:
            continue
        known = {c.upper() for c in ctx.sources.get(source, [])}
        if known and col.name.upper() not in known:
            out.append(f"{source.rsplit('.', 1)[-1]}.{col.name.upper()}")
    return out
