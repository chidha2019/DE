"""A folder whose CSV files are different tables: one table per file, named and shaped by the repository graph.

Each file is matched to a crawled source by its path (``vantage_core/claim.csv``), then by its headers; the
source names the table (``BRONZE.A_CLAIM`` → ``A_CLAIM``) whose contract and checks the plan follows. A
file no repository knows gets a name from its folder and file name.
"""

from __future__ import annotations

import csv
import io
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from query_service.intents.csvsample import snowflake_identifier


@dataclass
class SourceFile:
    path: Path
    rel: str
    system: str
    header: list[str]
    rows: int = 0
    encoding: str = "utf-8"
    readable_as: frozenset[str] = frozenset({"utf-8"})  # encodings that read the file exactly as `encoding` does


@dataclass
class TableSource:
    file: SourceFile
    table: str
    repo: str | None = None
    qualified: str | None = None
    load_mode: str | None = None
    volume: str | None = None
    matched_by: str = "name"


_SAME_FILE = 0.5  # header overlap (Jaccard) a same-named file needs to take that source's contract
_CENTRAL_EUROPEAN = set("ąćęłńśźżĄĆĘŁŃŚŹŻőűŐŰřšžťďňŘŠŽŤĎŇ")
# How Snowflake names each encoding in a CSV file format.
SNOWFLAKE_ENCODING = {"ascii": "UTF8", "utf-8": "UTF8", "cp1250": "WINDOWS1250", "latin-1": "ISO88591"}


_SINGLE_BYTE = ("cp1250", "latin-1")


def _readable_as(data: bytes, encoding: str) -> frozenset[str]:
    if encoding == "ascii":
        return frozenset({"utf-8", *_SINGLE_BYTE})
    if encoding == "utf-8":
        return frozenset({"utf-8"})
    text = data.decode(encoding)
    out = {encoding}
    for other in _SINGLE_BYTE:
        try:
            if other != encoding and data.decode(other) == text:
                out.add(other)
        except UnicodeDecodeError:
            continue
    return frozenset(out)


def set_encoding(files: list[SourceFile]) -> tuple[str, list[str]]:
    """The one encoding a shared file format reads the most files with (UTF-8 first on a tie), and the files it misreads."""
    chosen = max(("utf-8", *_SINGLE_BYTE), key=lambda enc: sum(1 for f in files if enc in f.readable_as))
    return chosen, [f.rel for f in files if chosen not in f.readable_as]


def _norm(text: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (text or "").lower())


def detect_encoding(data: bytes) -> str:
    """ascii, utf-8, or the single-byte code page whose letters the bytes spell: cp1250 for Central European
    text (ł, ś, ż …), latin-1 otherwise. ASCII files read the same under every one of them."""
    if all(b < 128 for b in data):
        return "ascii"
    try:
        data.decode("utf-8-sig")
        return "utf-8"
    except UnicodeDecodeError:
        pass
    try:
        text = data.decode("cp1250")
    except UnicodeDecodeError:
        return "latin-1"
    return "cp1250" if any(ch in _CENTRAL_EUROPEAN for ch in text) else "latin-1"


def find_files(folder: Path) -> list[SourceFile]:
    """Every CSV under the folder, with its path relative to it, its encoding, header row and row count."""
    out: list[SourceFile] = []
    for path in sorted(p for p in folder.rglob("*.csv") if p.is_file()):
        rel = path.relative_to(folder).as_posix()
        rows = 0
        encoding = "utf-8"
        readable: frozenset[str] = frozenset({"utf-8"})
        try:
            data = path.read_bytes()
            encoding = detect_encoding(data)
            readable = _readable_as(data, encoding)
            reader = csv.reader(io.StringIO(data.decode("utf-8-sig" if encoding in ("ascii", "utf-8") else encoding), newline=""))
            header = [h.strip() for h in next(reader, [])]
            rows = sum(1 for _ in reader)
        except (OSError, UnicodeDecodeError, csv.Error):
            header = []
        out.append(
            SourceFile(path=path, rel=rel, system=rel.split("/")[0] if "/" in rel else "", header=header, rows=rows, encoding=encoding, readable_as=readable)
        )
    return out


def pattern_name(pattern: str, stem: str) -> str:
    """The table a naming pattern gives a file: ``<FILE>_ICEBERG`` and ``claimStatus.csv`` → ``CLAIMSTATUS_ICEBERG``
    (the file name upper-cased, as the ticket's example reads, not split at its capitals)."""
    file = re.sub(r"[^A-Za-z0-9]+", "_", stem).strip("_").upper() or "FILE"
    return re.sub(r"<FILE>", file, pattern.upper())


def own_identifier(f: SourceFile) -> str | None:
    """The header that names the file's own identifier: ``branch_id`` in branch.csv, ``houseNr_id`` in houseNr.csv."""
    stem = _norm(Path(f.rel).stem)
    return next((h for h in f.header if _norm(h) in (f"{stem}id", "id")), None)


def is_table_set(files: list[SourceFile]) -> bool:
    """More than one file, and not all with the same columns: each is its own table."""
    return len(files) > 1 and len({tuple(_norm(h) for h in f.header) for f in files}) > 1


def match_sources(files: list[SourceFile], repos: list[dict[str, Any]]) -> list[TableSource]:
    candidates = [(repo, src) for repo in repos for src in repo.get("sources") or []]
    taken: set[int] = set()
    out: list[TableSource] = []
    stems: dict[str, int] = {}
    for f in files:
        stem = _norm(Path(f.rel).stem)
        stems[stem] = stems.get(stem, 0) + 1
    for f in files:
        hit: tuple[int, str] | None = None
        rel = f.rel.lower()
        mine = {_norm(h) for h in f.header}
        for i, (_, src) in enumerate(candidates):
            path = str(src.get("path") or "").lower().lstrip("./")
            if i not in taken and path and (path == rel or path.endswith("/" + rel) or rel.endswith("/" + path)):
                # Same path, or the same file name in another folder: only a match when the columns agree too
                # (a flat claim.csv with other columns is not the repository's vantage_core/claim.csv).
                theirs = {_norm(h) for h in src.get("headers") or []}
                if path == rel or not theirs or not mine or len(mine & theirs) / len(mine | theirs) >= _SAME_FILE:
                    hit = (i, "path")
                    break
        if hit is None:
            best: tuple[float, int] | None = None
            for i, (_, src) in enumerate(candidates):
                theirs = {_norm(h) for h in src.get("headers") or []}
                if i in taken or not theirs or not mine:
                    continue
                score = len(mine & theirs) / len(mine | theirs)
                if score >= 0.6 and (best is None or score > best[0]):
                    best = (score, i)
            if best is not None:
                hit = (best[1], "headers")
        if hit is not None:
            taken.add(hit[0])
            repo, src = candidates[hit[0]]
            qualified = str(src.get("table") or "")
            out.append(
                TableSource(
                    file=f,
                    table=qualified.rsplit(".", 1)[-1].upper(),
                    repo=str(repo.get("repo")),
                    qualified=qualified,
                    load_mode=src.get("load_mode"),
                    volume=src.get("volume"),
                    matched_by=hit[1],
                )
            )
            continue
        stem = Path(f.rel).stem
        name = snowflake_identifier(f"{f.system}_{stem}" if f.system and stems[_norm(stem)] > 1 else stem)
        out.append(TableSource(file=f, table=name))
    return out
