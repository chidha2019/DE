"""Choose the path an intent takes from what it asks for and what validation found in Snowflake.

ingest_new       files to load, the target tables do not exist yet: plan them from the repository's contracts
ingest_existing  files to load into tables that already exist: plan the load against their columns
model_new        the source layer is loaded, the target tables do not exist: the data modeler proposes them
model_existing   the target tables exist: plan the changes to them
wait_upstream    the tables it builds from are not loaded yet: wait for them (and the ticket that loads them)
manual           nothing here builds it: the spec goes to a person

The stages a route shows are derived on every read from the route and the intent's status.
"""

from __future__ import annotations

from ech_core.schemas.intents import (
    IntentRoute,
    IntentValidation,
    RouteKey,
    RouteStage,
    StructuredIntent,
)
from query_service.intents.validate import Expectation, tables_of


def _model_kind(intent: StructuredIntent) -> bool:
    return intent.kind in ("model_layer", "gold_fact")


def choose_route(intent: StructuredIntent, expect: Expectation, validation: IntentValidation | None) -> IntentRoute:
    reachable = validation is not None and validation.reachable
    unchecked = "" if reachable else " Snowflake was not checked, so this follows the ticket and the repository graph."
    if intent.kind == "ingest_csv_to_iceberg":
        have, missing = tables_of(validation, "target")
        total = len(have) + len(missing)
        if reachable and total and not missing:
            return IntentRoute(
                key="ingest_existing",
                title=f"Load into {total} existing table{'s' if total != 1 else ''}",
                reason=f"All {total} target table{'s' if total != 1 else ''} already exist in Snowflake; the plan loads into them as they are.",
            )
        if have:
            reason = f"{len(have)} of {total} target tables exist; the plan creates the other {len(missing)} and keeps the rest."
        elif total:
            reason = f"None of the {total} target tables exist yet; the plan creates them from the repository's contracts."
        else:
            reason = "The target table does not exist yet; the plan creates it from the files."
        return IntentRoute(key="ingest_new", title=_ingest_title(total), reason=reason + unchecked)
    if _model_kind(intent):
        layer = intent.layer or ("gold" if intent.kind == "gold_fact" else "silver")
        source = ".".join(p for p in (expect.source_database, expect.source_schema) if p) or "the source layer"
        if reachable:
            have, missing = tables_of(validation, "source")
            if not have:
                waits = list(intent.depends_on) or [source]
                return IntentRoute(
                    key="wait_upstream",
                    title=f"Wait for {source}",
                    reason=f"{source} has none of the tables the {layer} layer is built from"
                    + (f" ({len(missing)} expected)" if missing else "")
                    + "; the intent goes on once they are loaded"
                    + (f" by {', '.join(intent.depends_on)}." if intent.depends_on else "."),
                    waits_on=waits,
                )
            targets, absent = tables_of(validation, "target")
            if targets and not absent:
                return IntentRoute(
                    key="model_existing",
                    title=f"Change {len(targets)} existing {layer} table{'s' if len(targets) != 1 else ''}",
                    reason=f"The {layer} tables already exist; the plan compares them with the ask and changes what differs.",
                )
            note = f" {len(missing)} expected source table{'s are' if len(missing) != 1 else ' is'} missing and will be left out." if missing else ""
            return IntentRoute(
                key="model_new",
                title=f"Model the {layer} layer",
                reason=f"{len(have)} source table{'s' if len(have) != 1 else ''} in {source} are loaded and the {layer} tables do not exist yet; the data modeler proposes them.{note}",
            )
        return IntentRoute(key="model_new", title=f"Model the {layer} layer", reason=f"The data modeler proposes the {layer} tables from {source}.{unchecked}")
    return IntentRoute(key="manual", title="Hand to a person", reason="No route here builds this kind of work; the spec goes to a person or the reference agent.")


def _ingest_title(total: int) -> str:
    return f"Load files into {total} new tables" if total > 1 else "Load files into a new table"


_STAGES: dict[RouteKey, list[tuple[str, str]]] = {
    "ingest_new": [("read", "Read"), ("review", "Review"), ("validate", "Validate"), ("plan", "Plan tables"), ("approve", "Approve"), ("generate", "Generate"), ("run", "Run"), ("catalog", "Catalog")],
    "ingest_existing": [("read", "Read"), ("review", "Review"), ("validate", "Validate"), ("plan", "Plan load"), ("approve", "Approve"), ("generate", "Generate"), ("run", "Run")],
    "model_new": [("read", "Read"), ("review", "Review"), ("validate", "Validate"), ("model", "Model"), ("approve", "Approve"), ("generate", "Generate"), ("run", "Run"), ("catalog", "Catalog")],
    "model_existing": [("read", "Read"), ("review", "Review"), ("validate", "Validate"), ("plan", "Plan changes"), ("approve", "Approve"), ("generate", "Generate"), ("run", "Run")],
    "wait_upstream": [("read", "Read"), ("review", "Review"), ("validate", "Validate"), ("wait", "Wait"), ("model", "Model"), ("approve", "Approve"), ("generate", "Generate"), ("run", "Run")],
    "manual": [("read", "Read"), ("review", "Review"), ("validate", "Validate"), ("plan", "Spec"), ("approve", "Approve"), ("generate", "Hand over")],
}

# The stage an intent is at, by status; the stages before it are done.
_AT = {
    "received": "read",
    "clarifying": "review",
    "planning": "plan",
    "modeling": "model",
    "waiting": "wait",
    "spec_proposed": "approve",
    "approved": "generate",
    "coding": "generate",
    "pr_open": "run",
    "running": "run",
    "loaded": "catalog",
    "rejected": "approve",
}


def route_stages(route: IntentRoute, status: str, validated: bool) -> list[RouteStage]:
    """The route's stages with done / current / pending / blocked / skipped for an intent in `status`."""
    keys = _STAGES[route.key]
    names = [k for k, _ in keys]
    if status == "done":
        current = len(names)
    else:
        at = _AT.get(status, "plan" if "plan" in names else "model")
        if at in ("plan", "model") and at not in names:
            at = "model" if "model" in names else "plan"
        if at == "run" and "run" not in names:
            at = names[-1]
        current = names.index(at) if at in names else 0
    stages: list[RouteStage] = []
    for i, (key, label) in enumerate(keys):
        if i < current:
            state = "done"
        elif i == current:
            state = "blocked" if status in ("waiting", "failed", "rejected") else "current"
        else:
            state = "skipped" if status == "rejected" else "pending"
        detail = ""
        if key == "validate":
            # Validation runs before questions are asked, so it is done (or skipped) even while the review is current.
            detail = "checked in Snowflake" if validated else "not checked"
            if validated and state in ("pending", "current"):
                state = "done"
            elif not validated and i <= current:
                state = "skipped"
        if key == "wait" and route.waits_on:
            detail = ", ".join(route.waits_on)
        if key == "approve" and status == "rejected":
            detail = "rejected"
        stages.append(RouteStage(key=key, label=label, status=state, detail=detail))
    return stages
