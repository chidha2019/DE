"""Where the files land before Snowflake reads them: an S3 prefix or an Azure Blob Storage container.

One description serves the stage URL in the setup SQL, the runner's upload command and the environment it reads,
and the words of the plan. A part the ticket does not name stays a ``${VAR}`` placeholder the runner fills from
the environment at deploy time.
"""

from __future__ import annotations

from dataclasses import dataclass

from ech_core.schemas.intents import IntentSource


@dataclass(frozen=True)
class Landing:
    provider: str
    label: str
    url: str
    env: tuple[str, ...]
    requirements: tuple[str, ...]
    account: str = ""
    container: str = ""
    prefix: str = ""

    @property
    def known(self) -> bool:
        return "${" not in self.url


def landing_of(source: IntentSource) -> Landing:
    if source.storage_provider == "azure":
        account = source.azure_account or "${AZURE_STORAGE_ACCOUNT}"
        container = source.azure_container or "${AZURE_CONTAINER}"
        prefix = (source.azure_prefix or "${AZURE_PREFIX}").strip("/")
        return Landing(
            provider="azure",
            label="Azure Blob Storage",
            url=f"azure://{account}.blob.core.windows.net/{container}/{prefix}/",
            env=("AZURE_STORAGE_ACCOUNT", "AZURE_CONTAINER", "AZURE_PREFIX"),
            requirements=("azure-storage-blob>=12.19", "azure-identity>=1.15"),
            account=source.azure_account or "",
            container=source.azure_container or "",
            prefix=(source.azure_prefix or "").strip("/"),
        )
    bucket = source.s3_bucket or "${S3_BUCKET}"
    prefix = (source.s3_prefix or "${S3_PREFIX}").strip("/")
    return Landing(
        provider="s3",
        label="S3",
        url=f"s3://{bucket}/{prefix}/",
        env=("S3_BUCKET", "S3_PREFIX"),
        requirements=("boto3>=1.34",),
        container=source.s3_bucket or "",
        prefix=(source.s3_prefix or "").strip("/"),
    )


def covers(allowed_locations: str, url: str) -> bool | None:
    """Whether a storage integration's allowed locations include the landing URL; None while either is unknown."""
    if not allowed_locations or "${" in url:
        return None
    locations = [x.strip().strip("'\"") for x in allowed_locations.strip("[]()").split(",") if x.strip()]
    if "*" in locations:
        return True
    target = url.lower().rstrip("/") + "/"
    return any(target.startswith(x.lower().rstrip("/") + "/") for x in locations)


# The runner's upload command for each provider. Files keep their path under the folder (vantage_core/claim.csv),
# because each table's COPY picks its file by that path. FILE_PATTERN and LANDING_* are constants of the runner.
UPLOAD = {
    "s3": '''def upload(folder: str) -> int:
    import boto3  # noqa: PLC0415 - only needed for upload

    bucket = os.environ.get("S3_BUCKET", "") or LANDING_CONTAINER
    prefix = (os.environ.get("S3_PREFIX", "") or LANDING_PREFIX).strip("/")
    if not bucket:
        raise SystemExit("set S3_BUCKET (and S3_PREFIX)")
    s3 = boto3.client("s3")
    count = 0
    root = Path(folder)
    for path in sorted(p for p in root.glob(FILE_PATTERN) if p.is_file()):
        rel = path.relative_to(root).as_posix()
        key = f"{prefix}/{rel}" if prefix else rel
        s3.upload_file(str(path), bucket, key)
        print(f"uploaded {rel} -> s3://{bucket}/{key}")
        count += 1
    return count
''',
    "azure": '''def upload(folder: str) -> int:
    """Copy the files into the landing container, signed in with AZURE_STORAGE_CONNECTION_STRING when it is set and
    with your Azure login (DefaultAzureCredential: az login, managed identity, environment) otherwise."""
    from azure.storage.blob import BlobServiceClient  # noqa: PLC0415 - only needed for upload

    account = os.environ.get("AZURE_STORAGE_ACCOUNT", "") or LANDING_ACCOUNT
    container = os.environ.get("AZURE_CONTAINER", "") or LANDING_CONTAINER
    prefix = (os.environ.get("AZURE_PREFIX", "") or LANDING_PREFIX).strip("/")
    if not account or not container:
        raise SystemExit("set AZURE_STORAGE_ACCOUNT and AZURE_CONTAINER (and AZURE_PREFIX)")
    connection = os.environ.get("AZURE_STORAGE_CONNECTION_STRING")
    if connection:
        service = BlobServiceClient.from_connection_string(connection)
    else:
        from azure.identity import DefaultAzureCredential  # noqa: PLC0415

        service = BlobServiceClient(f"https://{account}.blob.core.windows.net", credential=DefaultAzureCredential())
    client = service.get_container_client(container)
    count = 0
    root = Path(folder)
    for path in sorted(p for p in root.glob(FILE_PATTERN) if p.is_file()):
        rel = path.relative_to(root).as_posix()
        name = f"{prefix}/{rel}" if prefix else rel
        with path.open("rb") as data:
            client.upload_blob(name=name, data=data, overwrite=True)
        print(f"uploaded {rel} -> azure://{account}.blob.core.windows.net/{container}/{name}")
        count += 1
    return count
''',
}
