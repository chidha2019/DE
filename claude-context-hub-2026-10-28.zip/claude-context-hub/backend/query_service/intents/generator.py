"""Template generator: a CSV → Snowflake-managed Iceberg spec becomes a runnable pipeline folder.

The output is deterministic and self-contained (SQL files, a small Python runner over the Snowflake SQL
REST API with an upload to S3 or Azure Blob Storage, offline tests, a README and the spec), so a reviewer can read it
in one sitting and CI can run its tests without credentials.
"""

from __future__ import annotations

import json
import re

from ech_core.schemas.intents import ModelColumn, ModelTable, PipelineSpec, SpecColumn, SpecTable
from query_service.intents.landing import UPLOAD, landing_of
from query_service.intents.tableset import SNOWFLAKE_ENCODING

META_COLUMNS = [("_SOURCE_FILE", "VARCHAR"), ("_LOADED_AT", "TIMESTAMP_NTZ")]
REJECTS = "LOAD_REJECTS"  # a designed layer's rows that break a NOT NULL column or repeat a key, with the reason
ORDER_COLUMNS = [("_FILE_LAST_MODIFIED", "TIMESTAMP_NTZ"), ("_FILE_ROW_NUMBER", "NUMBER")]


def _ident(name: str) -> str:
    return name if name.isidentifier() and name.isupper() else f'"{name}"'


def _fqn(spec: PipelineSpec, obj: str) -> str:
    """The object in the target schema; a name that is already qualified (an existing stage) stays as it is."""
    if "." in obj:
        return obj
    t = spec.target
    return ".".join(x for x in (t.database, t.schema_name, obj) if x)


def generate(spec: PipelineSpec) -> dict[str, str]:
    """path (relative to the pipeline folder) → content."""
    if spec.kind == "model_layer" and spec.models:
        return _model_layer(spec)
    if spec.kind != "ingest_csv_to_iceberg":
        return {"README.md": _generic_readme(spec), "spec.json": spec.model_dump_json(indent=2, by_alias=True)}
    if spec.tables:
        return _table_set(spec)
    return {
        "README.md": _readme(spec),
        "spec.json": spec.model_dump_json(indent=2, by_alias=True),
        "sql/010_setup.sql": _setup_sql(spec),
        "sql/020_table.sql": _table_sql(spec),
        "sql/030_load.sql": _load_sql(spec),
        "sql/040_checks.sql": _checks_sql(spec),
        "sql/045_reconcile.sql": _reconcile_header(spec) + _reconcile_ingest(spec),
        "sql/050_task.sql": _task_sql(spec),
        "pipeline.py": _runner(spec),
        "requirements.txt": _requirements(spec),
        "tests/test_pipeline.py": _tests(spec),
    }


# --------------------------------------------------------------------------- SQL
def _requirements(spec: PipelineSpec) -> str:
    return "\n".join(["httpx>=0.27", *landing_of(spec.source).requirements, "pytest>=8"]) + "\n"


def _setup_sql(spec: PipelineSpec) -> str:
    t, s = spec.target, spec.source
    fmt = _fqn(spec, spec.file_format_name)
    stage = _fqn(spec, spec.stage_name)
    landing = landing_of(s)
    lines = [
        f"-- {spec.name}: file format and landing stage",
        f"CREATE FILE FORMAT IF NOT EXISTS {fmt}",
        "  TYPE = CSV",
        f"  FIELD_DELIMITER = '{s.delimiter}'",
        f"  SKIP_HEADER = {1 if s.header else 0}",
        "  FIELD_OPTIONALLY_ENCLOSED_BY = '\"'",
        "  NULL_IF = ('', 'NULL', 'null', 'N/A')",
        "  EMPTY_FIELD_AS_NULL = TRUE",
        "  TRIM_SPACE = TRUE",
        f"  ENCODING = '{SNOWFLAKE_ENCODING.get(s.encoding.lower(), s.encoding.upper().replace('-', ''))}';",
        "",
    ]
    if s.stage:
        lines.append(f"-- The load reads {landing.url} through the existing stage {stage} and the storage integration it already uses.")
    else:
        lines += [
            f"-- External stage on the {landing.label} landing location; the storage integration grants Snowflake read access.",
            f"CREATE STAGE IF NOT EXISTS {stage}",
            f"  URL = '{landing.url}'",
            f"  STORAGE_INTEGRATION = {s.storage_integration or '${STORAGE_INTEGRATION}'}",
            f"  FILE_FORMAT = {fmt};",
        ]
    if t.external_volume is None:
        lines += ["", "-- Set ECH_EXTERNAL_VOLUME before apply: the Iceberg tables store their data in that external volume."]
    return "\n".join(lines) + "\n"


def _table_sql(spec: PipelineSpec) -> str:
    t = spec.target
    defs = [(f"  {_ident(c.name)} {c.type}{'' if c.nullable else ' NOT NULL'}", c.term_name) for c in spec.columns]
    defs += [(f"  {name} {typ}", None) for name, typ in META_COLUMNS]
    # The comma goes before the comment, or the comment would swallow it.
    lines = [f"{definition}{',' if i < len(defs) - 1 else ''}{f'  -- {term}' if term else ''}" for i, (definition, term) in enumerate(defs)]
    volume = t.external_volume or "${ECH_EXTERNAL_VOLUME}"
    return (
        f"-- {spec.name}: Snowflake-managed Iceberg table (data lives in the external volume)\n"
        f"CREATE ICEBERG TABLE IF NOT EXISTS {_fqn(spec, t.table or 'TARGET')} (\n" + "\n".join(lines) + "\n)\n"
        "  CATALOG = 'SNOWFLAKE'\n"
        f"  EXTERNAL_VOLUME = '{volume}'\n"
        f"  BASE_LOCATION = '{t.base_location or (t.table or 'target').lower()}';\n"
    )


def _select_list(spec: PipelineSpec, ordering: bool = False) -> str:
    parts = [f"    ${i + 1}::{c.type} AS {_ident(c.name)}" for i, c in enumerate(spec.columns)]
    parts += ["    METADATA$FILENAME AS _SOURCE_FILE", "    CURRENT_TIMESTAMP() AS _LOADED_AT"]
    if ordering:
        parts += ["    METADATA$FILE_LAST_MODIFIED AS _FILE_LAST_MODIFIED", "    METADATA$FILE_ROW_NUMBER AS _FILE_ROW_NUMBER"]
    return ",\n".join(parts)


def _pattern(spec: PipelineSpec) -> str:
    pattern = spec.source.file_pattern.replace(".", r"\.").replace("*", ".*")
    return pattern if pattern.startswith(".*") else f".*{pattern}"  # Snowflake matches the whole path under the stage


def _copy(spec: PipelineSpec, target: str, ordering: bool = False) -> str:
    """One COPY statement without its semicolon; `ordering` also loads when each file changed and where each row sits in it."""
    stage = _fqn(spec, spec.stage_name)
    fmt = _fqn(spec, spec.file_format_name)
    pattern = _pattern(spec)
    extra = [m[0] for m in META_COLUMNS] + ([m[0] for m in ORDER_COLUMNS] if ordering else [])
    column_list = ", ".join([_ident(c.name) for c in spec.columns] + extra)
    return (
        f"COPY INTO {target} ({column_list})\n"
        f"FROM (\n  SELECT\n{_select_list(spec, ordering)}\n  FROM @{stage}\n)\n"
        f"FILE_FORMAT = (FORMAT_NAME = {fmt})\n"
        f"PATTERN = '{pattern}'\n"
        "ON_ERROR = 'ABORT_STATEMENT'"
    )


def _load_statements(spec: PipelineSpec) -> tuple[str, list[str]]:
    """What the load does, and its statements without semicolons; sql/030_load.sql and the task share them."""
    t = spec.target
    target = _fqn(spec, t.table or "TARGET")
    if t.load_mode == "full_refresh":
        return "full refresh", [f"TRUNCATE TABLE IF EXISTS {target}", _copy(spec, target)]
    if t.load_mode == "merge" and t.merge_keys:
        staging = _fqn(spec, f"{t.table}_STAGING")
        keys = [_ident(k) for k in t.merge_keys]
        on = " AND ".join(f"t.{k} = s.{k}" for k in keys)
        sets = ", ".join(f"t.{_ident(c.name)} = s.{_ident(c.name)}" for c in spec.columns if c.name not in t.merge_keys)
        cols = ", ".join([_ident(c.name) for c in spec.columns] + [m[0] for m in META_COLUMNS])
        vals = ", ".join([f"s.{_ident(c.name)}" for c in spec.columns] + [f"s.{m[0]}" for m in META_COLUMNS])
        defs = [f"  {_ident(c.name)} {c.type}{'' if c.nullable else ' NOT NULL'}" for c in spec.columns]
        defs += [f"  {name} {typ}" for name, typ in META_COLUMNS + ORDER_COLUMNS]
        # The staging table is re-created on every run, so every staged file is loaded again; a key must reach the
        # MERGE once, or the first run inserts it twice and the next run fails on a nondeterministic update.
        latest = f"ROW_NUMBER() OVER (PARTITION BY {', '.join(keys)} ORDER BY _FILE_LAST_MODIFIED DESC, _SOURCE_FILE DESC, _FILE_ROW_NUMBER DESC) = 1"
        merge = (
            f"MERGE INTO {target} t USING (\n  SELECT * FROM {staging}\n  QUALIFY {latest}\n) s ON {on}\n"
            f"  WHEN MATCHED THEN UPDATE SET {sets}, t._SOURCE_FILE = s._SOURCE_FILE, t._LOADED_AT = s._LOADED_AT\n"
            f"  WHEN NOT MATCHED THEN INSERT ({cols}) VALUES ({vals})"
        )
        what = (
            f"load into a transient staging table, then merge on {', '.join(t.merge_keys)}; a key that arrives more than once "
            "keeps the row from the most recently modified file (then the later file name, then the later row)"
        )
        create = f"CREATE OR REPLACE TRANSIENT TABLE {staging} (\n" + ",\n".join(defs) + "\n)"
        return what, [create, _copy(spec, staging, ordering=True), merge, f"DROP TABLE IF EXISTS {staging}"]
    return "append load (Snowflake load history skips files already loaded)", [_copy(spec, target)]


def _load_sql(spec: PipelineSpec) -> str:
    what, statements = _load_statements(spec)
    return f"-- {spec.name}: {what}\n" + "".join(f"{s};\n" for s in statements)


def _checks_sql(spec: PipelineSpec) -> str:
    target = _fqn(spec, spec.target.table or "TARGET")
    out = [f"-- {spec.name}: post-load checks; every statement must return 0 failures"]
    for test in spec.tests:
        if test.kind == "row_count":
            out.append(f"SELECT '{test.name}' AS check_name, IFF(COUNT(*) > 0, 0, 1) AS failures FROM {target};")
        elif test.kind == "not_null" and test.columns:
            conds = " OR ".join(f"{_ident(c)} IS NULL" for c in test.columns)
            out.append(f"SELECT '{test.name}' AS check_name, COUNT(*) AS failures FROM {target} WHERE {conds};")
        elif test.kind == "unique" and test.columns:
            cols = ", ".join(_ident(c) for c in test.columns)
            scope = cols if spec.target.load_mode == "merge" else f"{cols}, _SOURCE_FILE"
            out.append(f"SELECT '{test.name}' AS check_name, COUNT(*) AS failures FROM (SELECT {scope} FROM {target} GROUP BY ALL HAVING COUNT(*) > 1);")
        elif test.kind == "condition" and test.condition:
            if test.origin:
                out.append(f"-- copied from {test.origin}")
            out.append(f"SELECT '{test.name}' AS check_name, COUNT(*) AS failures FROM {target} WHERE {test.condition};")
        elif test.kind == "query" and test.condition:
            if test.origin:
                out.append(f"-- copied from {test.origin} (reads other tables of this load)")
            out.append(f"SELECT '{test.name}' AS check_name, COUNT(*) AS failures FROM ({test.condition});")
        elif test.kind == "freshness":
            out.append(f"SELECT '{test.name}' AS check_name, IFF(MAX(_LOADED_AT) >= DATEADD(day, -1, CURRENT_TIMESTAMP()), 0, 1) AS failures FROM {target};")
        elif test.kind == "file_count":
            out.append(f"SELECT '{test.name}' AS check_name, IFF(COUNT(DISTINCT _SOURCE_FILE) > 0, 0, 1) AS failures FROM {target};")
    return "\n".join(out) + "\n"


# --------------------------------------------------------------------------- reconciliation
# Each statement returns rows of RECON_TABLE, MEASURE (rows, keys or sum:<COLUMN>), SOURCE_VALUE, TARGET_VALUE,
# EXPLAINED (what the load rejected with a reason) and SEVERITY. A rows or keys gap nothing explains fails the load;
# a total only warns, since a cast or a rounding can move it without losing a row.
_MEASURE = re.compile(r"AMT|AMOUNT|PREMIUM|PRICE|COST|TOTAL|BALANCE|VALUE|QTY|QUANTITY|LIMIT|DEDUCTIBLE|FEE|PAID|RESERVE", re.I)
_NUMERIC = re.compile(r"^\s*(NUMBER|NUMERIC|DECIMAL|INT|INTEGER|BIGINT|SMALLINT|FLOAT|DOUBLE|REAL)", re.I)
_MAX_MEASURES = 3


def _measures(columns: list[SpecColumn] | list[ModelColumn], keys: list[str]) -> list[str]:
    """The money and quantity columns whose totals are worth reconciling: numeric, named like an amount, not a key."""
    skip = {k.upper() for k in keys}
    return [c.name for c in columns if _NUMERIC.match(c.type or "") and _MEASURE.search(c.name) and c.name.upper() not in skip][:_MAX_MEASURES]


def _recon_row(table: str, measure: str, source: str, target: str, explained: str = "0", severity: str = "error") -> str:
    return f"SELECT '{table}' AS RECON_TABLE, '{measure}' AS MEASURE, {source} AS SOURCE_VALUE, {target} AS TARGET_VALUE, {explained} AS EXPLAINED, '{severity}' AS SEVERITY"


def _reconcile_ingest(spec: PipelineSpec) -> str:
    """One table loaded from staged files: the rows in the files against the rows loaded from them (a merge
    deduplicates, so it is reconciled by distinct key instead), and the totals of its amount columns."""
    t = spec.target
    target = _fqn(spec, t.table or "TARGET")
    position = {c.name: (i + 1, c.type) for i, c in enumerate(spec.columns)}
    keys = [k for k in t.merge_keys if k in position] if t.load_mode == "merge" else []
    measures = [] if keys else _measures(spec.columns, [])
    picked = ["METADATA$FILENAME AS _F"] + [f"${position[c][0]}::{position[c][1]} AS {_ident(c)}" for c in [*keys, *measures]]
    src = f"SELECT {', '.join(picked)}\n  FROM @{_fqn(spec, spec.stage_name)} (FILE_FORMAT => '{_fqn(spec, spec.file_format_name)}', PATTERN => '{_pattern(spec)}')"
    name = t.table or "TARGET"
    if keys:
        cols = ", ".join(_ident(k) for k in keys)
        present = " AND ".join(f"{_ident(k)} IS NOT NULL" for k in keys)  # a NULL key is the not_null check's to report
        on = " AND ".join(f"t.{_ident(k)} = s.{_ident(k)}" for k in keys)
        distinct = f"(SELECT DISTINCT {cols} FROM src WHERE {present})"
        rows = [_recon_row(name, "keys", f"(SELECT COUNT(*) FROM {distinct})", f"(SELECT COUNT(*) FROM {distinct} s JOIN {target} t ON {on})")]
    else:
        mine = f"{target} WHERE _SOURCE_FILE IN (SELECT _F FROM src)"  # this load's files only: older ones may have left the stage
        rows = [_recon_row(name, "rows", "(SELECT COUNT(*) FROM src)", f"(SELECT COUNT(*) FROM {mine})")]
        rows += [
            _recon_row(name, f"sum:{m}", f"(SELECT COALESCE(SUM({_ident(m)}), 0) FROM src)", f"(SELECT COALESCE(SUM({_ident(m)}), 0) FROM {mine})", severity="warn")
            for m in measures
        ]
    return f"WITH src AS (\n  {src}\n)\n" + "\nUNION ALL\n".join(rows) + ";\n"


def _reconcile_model(spec: PipelineSpec, m: ModelTable) -> str:
    """One modelled table: the rows its compiled SELECT returns now against the target. Rows the load rejects (a NULL
    in a NOT NULL column, a repeated key) explain a difference; anything else is a gap."""
    if not m.sql.strip():
        return ""
    target = _fqn(spec, m.name)
    body = m.sql.strip().rstrip(";")
    keys = [_ident(k) for k in m.keys]
    if m.ddl:  # the same rules as the staged load: the row number per key and what makes a row rejected
        required = [c.name for c in m.columns if not c.nullable]
        order = ", ".join([_ident(m.hash_column)] if m.hash_column else keys)
        rn = f"ROW_NUMBER() OVER (PARTITION BY {', '.join(keys)} ORDER BY {order})" if keys else "1"
        bad = " OR ".join([f"{_ident(c)} IS NULL" for c in required] + (["_RN > 1"] if keys else [])) or "FALSE"
        ctes = f"WITH src AS (\n  SELECT x.*, {rn} AS _RN FROM (\n{body}\n  ) x\n), kept AS (\n  SELECT * FROM src WHERE NOT ({bad})\n)\n"
        rejected = f"(SELECT COUNT(*) FROM src WHERE {bad})"
    else:
        ctes = f"WITH src AS (\n  SELECT * FROM (\n{body}\n  ) x\n), kept AS (\n  SELECT * FROM src\n)\n"
        rejected = "0"
    measures = _measures(m.columns, m.keys)
    if keys:
        on = " AND ".join(f"t.{k} = k.{k}" for k in keys)
        found = f"kept k JOIN {target} t ON {on}"
        present = " AND ".join(f"{k} IS NOT NULL" for k in keys)
        cols = ", ".join(keys)
        source_keys = f"(SELECT COUNT(*) FROM (SELECT DISTINCT {cols} FROM src WHERE {present}))"
        kept_keys = f"(SELECT COUNT(*) FROM (SELECT DISTINCT {cols} FROM kept WHERE {present}))"
        found_keys = f"(SELECT COUNT(*) FROM (SELECT DISTINCT {', '.join(f'k.{c}' for c in keys)} FROM {found}))"
        rows = [
            _recon_row(m.name, "rows", "(SELECT COUNT(*) FROM src)", f"(SELECT COUNT(*) FROM {found})", rejected),
            _recon_row(m.name, "keys", source_keys, found_keys, f"{source_keys} - {kept_keys}"),
        ]
        rows += [
            _recon_row(m.name, f"sum:{c}", f"(SELECT COALESCE(SUM(k.{_ident(c)}), 0) FROM kept k)", f"(SELECT COALESCE(SUM(t.{_ident(c)}), 0) FROM {found})", severity="warn")
            for c in measures
        ]
    else:
        rows = [_recon_row(m.name, "rows", "(SELECT COUNT(*) FROM src)", f"(SELECT COUNT(*) FROM {target})", rejected)]
        rows += [
            _recon_row(m.name, f"sum:{c}", f"(SELECT COALESCE(SUM({_ident(c)}), 0) FROM kept)", f"(SELECT COALESCE(SUM({_ident(c)}), 0) FROM {target})", severity="warn")
            for c in measures
        ]
    return f"-- {m.name}\n{ctes}" + "\nUNION ALL\n".join(rows) + ";\n"


def _reconcile_header(spec: PipelineSpec) -> str:
    return (
        f"-- {spec.name}: source against target after the load. Each row is a table's rows, keys or a total; a rows or keys\n"
        "-- difference that rejected rows do not explain fails the load, a total that differs is reported as a warning.\n"
    )


def _task_sql(spec: PipelineSpec) -> str:
    task = _fqn(spec, f"{spec.target.table}_LOAD_TASK")
    if spec.schedule == "manual":
        return f"-- {spec.name}: on demand; no scheduled task. Run `python pipeline.py load` when files arrive.\n"
    _, statements = _load_statements(spec)
    if len(statements) == 1:
        body = statements[0]
    else:
        # A task runs one statement: several become one Snowflake Scripting block, $$-quoted so the runner keeps it whole.
        inner = "".join("  " + s.replace("\n", "\n  ") + ";\n" for s in statements)
        body = f"EXECUTE IMMEDIATE $$\nBEGIN\n{inner}END;\n$$"
    return (
        f"-- {spec.name}: scheduled load (cron in UTC); the task body mirrors sql/030_load.sql\n"
        f"CREATE OR REPLACE TASK {task}\n  WAREHOUSE = ${{SNOWFLAKE_WAREHOUSE}}\n  SCHEDULE = 'USING CRON {spec.schedule} UTC'\nAS\n{body};\n"
        f"ALTER TASK {task} RESUME;\n"
    )


# --------------------------------------------------------------------------- Python runner and tests
def _runner(spec: PipelineSpec) -> str:
    folder = spec.source.folder or "data/<folder>"
    landing = landing_of(spec.source)
    signed_in = "AWS credentials" if landing.provider == "s3" else "AZURE_STORAGE_CONNECTION_STRING or an Azure login"
    plan_env = (*landing.env, "STORAGE_INTEGRATION", "ECH_EXTERNAL_VOLUME", "SNOWFLAKE_WAREHOUSE")
    if spec.kind == "model_layer":
        plan_env = ("ECH_EXTERNAL_VOLUME", "SNOWFLAKE_WAREHOUSE")
        doc = (
            f"{spec.name}: build the {spec.target.schema_name} layer of {spec.target.database} from {spec.source.database}.{spec.source.schema_name}.\n\n"
            "Generated by the Enterprise Context Hub from an approved spec (spec.json). Commands:\n"
            "  python pipeline.py plan              render every statement with the environment substituted (no connection)\n"
            "  python pipeline.py apply             run sql/010_setup.sql and sql/020_table.sql\n"
            "  python pipeline.py load              run sql/030_load.sql, then sql/040_checks.sql and sql/045_reconcile.sql\n"
            "  python pipeline.py schedule          run sql/050_task.sql\n"
            "Environment: SNOWFLAKE_HOST, SNOWFLAKE_TOKEN (programmatic access token), SNOWFLAKE_WAREHOUSE, SNOWFLAKE_ROLE.\n"
        )
    else:
        doc = (
            f"{spec.name}: upload CSV files to {landing.label} and load them into Snowflake-managed Iceberg tables.\n\n"
            "Generated by the Enterprise Context Hub from an approved spec (spec.json). Commands:\n"
            "  python pipeline.py plan              render every statement with the environment substituted (no connection)\n"
            f"  python pipeline.py upload <folder>   copy the CSV files from a folder to {landing.url}\n"
            "  python pipeline.py apply             run sql/010_setup.sql and sql/020_table.sql\n"
            "  python pipeline.py load              run sql/030_load.sql, then sql/040_checks.sql and sql/045_reconcile.sql\n"
            "  python pipeline.py schedule          run sql/050_task.sql\n"
            "Environment: SNOWFLAKE_HOST, SNOWFLAKE_TOKEN (programmatic access token), SNOWFLAKE_WAREHOUSE, SNOWFLAKE_ROLE,\n"
            f"{', '.join(landing.env)}, STORAGE_INTEGRATION, ECH_EXTERNAL_VOLUME (and {signed_in} for upload).\n"
        )
    return f'''"""{doc}"""

from __future__ import annotations

import os
import re
import sys
from decimal import Decimal
from pathlib import Path

HERE = Path(__file__).resolve().parent
SQL_DIR = HERE / "sql"
PLACEHOLDER = re.compile(r"\\$\\{{([A-Z0-9_]+)\\}}")
PLAN_ENV = {plan_env!r}
FILE_PATTERN = {spec.source.file_pattern!r}
LANDING_ACCOUNT = {landing.account!r}
LANDING_CONTAINER = {landing.container!r}
LANDING_PREFIX = {landing.prefix!r}


def render(path: Path, env: dict[str, str] | None = None) -> list[str]:
    """Statements of a SQL file with ${{VAR}} placeholders substituted; comments and blank lines dropped."""
    env = dict(os.environ if env is None else env)
    text = path.read_text(encoding="utf-8")
    missing = sorted({{m.group(1) for m in PLACEHOLDER.finditer(text) if not env.get(m.group(1))}})
    if missing:
        raise SystemExit(f"{{path.name}}: set {{', '.join(missing)}} in the environment")
    text = PLACEHOLDER.sub(lambda m: env[m.group(1)], text)
    body = "\\n".join(line for line in text.splitlines() if not line.strip().startswith("--"))
    return split_statements(body)


def split_statements(body: str) -> list[str]:
    """Split on semicolons outside quoted text ('a; b') and $$-quoted blocks (a scheduled load of several statements)."""
    statements: list[str] = []
    current: list[str] = []
    quoted = False
    i = 0
    while i < len(body):
        if not quoted and body.startswith("$$", i):
            end = body.find("$$", i + 2)
            end = len(body) if end < 0 else end + 2
            current.append(body[i:end])
            i = end
            continue
        ch = body[i]
        if ch == "'":
            quoted = not quoted  # '' inside a string flips twice and stays inside
        if ch == ";" and not quoted:
            statements.append("".join(current))
            current = []
        else:
            current.append(ch)
        i += 1
    statements.append("".join(current))
    return [s.strip() for s in statements if s.strip()]


def _snowflake():
    import httpx  # noqa: PLC0415 - optional until a connection is needed

    host = os.environ.get("SNOWFLAKE_HOST", "").rstrip("/")
    token = os.environ.get("SNOWFLAKE_TOKEN", "")
    if not host or not token:
        raise SystemExit("set SNOWFLAKE_HOST and SNOWFLAKE_TOKEN")
    if "://" not in host:
        host = f"https://{{host}}"
    return httpx.Client(
        base_url=host,
        headers={{
            "Authorization": f"Bearer {{token}}",
            "X-Snowflake-Authorization-Token-Type": os.environ.get("SNOWFLAKE_AUTH_SCHEME", "PROGRAMMATIC_ACCESS_TOKEN"),
            "Accept": "application/json",
        }},
        timeout=180.0,
    )


def execute(statements: list[str]) -> list[dict]:
    """Run statements one by one through the Snowflake SQL REST API; returns the row sets."""
    results = []
    with _snowflake() as client:
        for statement in statements:
            body = {{
                "statement": statement,
                "timeout": 170,
                "warehouse": os.environ.get("SNOWFLAKE_WAREHOUSE"),
                "role": os.environ.get("SNOWFLAKE_ROLE"),
            }}
            response = client.post("/api/v2/statements", json={{k: v for k, v in body.items() if v}})
            if response.status_code >= 400:
                raise SystemExit(f"Snowflake rejected a statement: HTTP {{response.status_code}} {{response.text[:300]}}\\n{{statement[:200]}}")
            payload = response.json()
            rows = payload.get("data") or []
            cols = [c["name"] for c in (payload.get("resultSetMetaData") or {{}}).get("rowType", [])]
            results.append({{"statement": statement[:80], "rows": [dict(zip(cols, r)) for r in rows]}})
            print(f"ok  {{statement.splitlines()[0][:100]}}")
    return results


{UPLOAD[landing.provider]}

def checks(results: list[dict]) -> int:
    """Print each check; a failing check of severity 'warn' is reported (WARN) but does not fail the load."""
    failures = 0
    for result in results:
        for row in result["rows"]:
            name = row.get("CHECK_NAME") or row.get("check_name")
            failed = int(row.get("FAILURES") or row.get("failures") or 0)
            warn = str(row.get("SEVERITY") or row.get("severity") or "").lower() == "warn"
            print(f"{{'pass' if not failed else 'WARN' if warn else 'FAIL'}} {{name}} ({{failed}})")
            failures += 0 if warn else failed
    return failures


def _number(value) -> Decimal:
    return Decimal(str(value)) if value not in (None, "") else Decimal(0)


def reconcile(results: list[dict]) -> int:
    """Print each table's source against its target; a rows or keys gap that rejected rows do not explain counts as a
    failure, a total that differs only warns."""
    gaps = 0
    for result in results:
        for row in result["rows"]:
            got = {{k.lower(): v for k, v in row.items()}}
            if "recon_table" not in got:
                continue
            source, target, explained = (_number(got.get(k)) for k in ("source_value", "target_value", "explained"))
            gap = source - target - explained
            warn = str(got.get("severity") or "").lower() == "warn"
            status = ("explained" if explained else "match") if gap == 0 else "WARN" if warn else "GAP"
            print(f"recon {{got['recon_table']}} {{got['measure']}} source={{source}} target={{target}} explained={{explained}} gap={{gap}} {{status}}")
            gaps += 1 if status == "GAP" else 0
    return gaps


def report(results: list[dict]) -> None:
    """Per table of a modelled layer: rows staged, rejected and merged (the MERGE's counts, then its summary row)."""
    merged: dict = {{}}
    for result in results:
        for row in result["rows"]:
            got = {{k.lower(): v for k, v in row.items()}}
            if "number of rows inserted" in got and "number of rows updated" in got:
                merged = {{"inserted": got["number of rows inserted"], "updated": got["number of rows updated"]}}
            elif "model_name" in got:
                counts = {{"staged": got.get("staged"), "rejected": got.get("rejected"), **merged, "rows": got.get("table_rows")}}
                print(f"model {{got['model_name']}} " + " ".join(f"{{k}}={{int(v or 0)}}" for k, v in counts.items()))
                merged = {{}}


def main(argv: list[str]) -> int:
    command = argv[0] if argv else "plan"
    if command == "plan":
        env = {{**{{k: f"<{{k}}>" for k in PLAN_ENV}}, **os.environ}}
        for path in sorted(SQL_DIR.glob("*.sql")):
            print(f"-- {{path.name}}")
            for statement in render(path, env):
                print(statement + ";\\n")
        return 0
    if command == "upload":
        return 0 if upload(argv[1] if len(argv) > 1 else {folder!r}) else 1
    if command == "apply":
        execute(render(SQL_DIR / "010_setup.sql") + render(SQL_DIR / "020_table.sql"))
        return 0
    if command == "load":
        report(execute(render(SQL_DIR / "030_load.sql")))
        failed = checks(execute(render(SQL_DIR / "040_checks.sql")))
        reconciliation = SQL_DIR / "045_reconcile.sql"
        if reconciliation.is_file():
            failed += reconcile(execute(render(reconciliation)))
        return 1 if failed else 0
    if command == "schedule":
        execute(render(SQL_DIR / "050_task.sql"))
        return 0
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
'''


def _tests(spec: PipelineSpec) -> str:
    table = spec.target.table or "TARGET"
    column_names = [c.name for c in spec.columns]
    return f'''"""Offline tests for {spec.name}: the generated SQL matches the approved spec; no Snowflake connection."""

from __future__ import annotations

import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(HERE))

import pipeline  # noqa: E402

ENV = {{name: name.lower() for name in pipeline.PLAN_ENV}}
COLUMNS = {json.dumps(column_names)}


def test_spec_matches_sql():
    spec = json.loads((HERE / "spec.json").read_text(encoding="utf-8"))
    assert spec["target"]["table"] == {table!r}
    table_sql = (HERE / "sql" / "020_table.sql").read_text(encoding="utf-8")
    assert "CREATE ICEBERG TABLE" in table_sql and "CATALOG = 'SNOWFLAKE'" in table_sql
    for column in COLUMNS:
        assert column in table_sql
    assert "_SOURCE_FILE" in table_sql and "_LOADED_AT" in table_sql


def test_every_sql_file_renders_with_placeholders_filled():
    for path in sorted((HERE / "sql").glob("*.sql")):
        statements = pipeline.render(path, ENV)
        assert all(s and "${{" not in s for s in statements), path.name


def test_the_task_is_one_statement_then_resume():
    statements = pipeline.render(HERE / "sql" / "050_task.sql", ENV)
    assert len(statements) <= 2
    assert all(s.startswith(("CREATE OR REPLACE TASK", "ALTER TASK")) for s in statements)


def test_load_copies_every_column_in_order():
    statements = pipeline.render(HERE / "sql" / "030_load.sql", ENV)
    copy = next(s for s in statements if s.startswith("COPY INTO"))
    positions = [copy.index(c) for c in COLUMNS]
    assert positions == sorted(positions)
    assert "METADATA$FILENAME" in copy
'''


# --------------------------------------------------------------------------- docs
def _readme(spec: PipelineSpec) -> str:
    t = spec.target
    cols = "\n".join(f"| {c.name} | {c.type} | {'yes' if c.nullable else 'no'} | {c.term_name or ''} | {c.source_header or ''} |" for c in spec.columns)
    tests = "\n".join(
        f"- {x.name}: {x.kind}" + (f" on {', '.join(x.columns)}" if x.columns else "") + (f" (copied from {x.origin})" if x.origin else "") for x in spec.tests
    )
    out = (
        f"# {spec.name}\n\n{spec.summary}\n\n"
        "Generated by the Enterprise Context Hub from an approved intent. The approved spec is `spec.json`; the SQL and the\n"
        "runner implement it and nothing more.\n\n"
        f"## Flow\n\n1. `python pipeline.py upload <folder>` copies the CSV files to `{landing_of(spec.source).url}`.\n"
        "2. `python pipeline.py apply` creates the file format, the external stage and the Snowflake-managed Iceberg table\n"
        f"   `{t.database}.{t.schema_name}.{t.table}` (data stored in external volume `{t.external_volume or '$ECH_EXTERNAL_VOLUME'}`, base location `{t.base_location}`).\n"
        f"3. `python pipeline.py load` runs the {t.load_mode} load and the post-load checks.\n"
        f"4. `python pipeline.py schedule` creates the Snowflake task (`{spec.schedule}`).\n\n"
        f"## Columns\n\n| column | type | nullable | business term | source header |\n|---|---|---|---|---|\n{cols}\n\n"
        f"## Tests\n\n{tests}\n\nOffline: `pytest -q tests`.\n\n"
    )
    if spec.assumptions:
        out += "## Assumptions\n\n" + "\n".join(f"- {x}" for x in spec.assumptions) + "\n\n"
    if spec.downstream:
        out += "## Downstream models to update\n\nThese models read the exemplar this source was modelled on; they do not read this table yet.\n\n"
        for d in spec.downstream:
            where = f" ([{d.files[0]}]({d.file_url}))" if d.files and d.file_url else (f" ({d.files[0]})" if d.files else "")
            out += f"- `{d.table}` in {d.repo}{where}" + (f", feeding {', '.join(d.affects)}" if d.affects else "") + "\n"
            for c in d.columns:
                via = f" <- {', '.join(c.provided_by)}" if c.provided_by else ""
                out += f"  - {c.column}: {c.status}{via}" + (f" (today: {', '.join(c.sources)})" if c.sources else "") + "\n"
        out += "\n"
    if spec.risks:
        out += "## Risks\n\n" + "\n".join(f"- {x}" for x in spec.risks) + "\n"
    return out


# --------------------------------------------------------------------------- a table set: one table per file
def _table_spec(spec: PipelineSpec, table: SpecTable) -> PipelineSpec:
    """One table of the set as a single-table spec, so every per-table renderer above applies unchanged."""
    return spec.model_copy(
        update={
            "target": spec.target.model_copy(
                update={"table": table.name, "base_location": table.base_location, "merge_keys": table.keys if spec.target.load_mode == "merge" else []}
            ),
            "source": spec.source.model_copy(update={"file_pattern": table.source_file}),
            "columns": table.columns,
            "tests": [t.model_copy(update={"name": f"{table.name}.{t.name}"}) for t in table.tests],
            "tables": [],
        }
    )


def _prepare_sql(spec: PipelineSpec) -> str:
    """Create the database and schema validation found missing; IF NOT EXISTS keeps a rerun harmless."""
    t = spec.target
    lines: list[str] = []
    if "database" in spec.create and t.database:
        lines.append(f"CREATE DATABASE IF NOT EXISTS {t.database};")
    if spec.create and t.database and t.schema_name:
        lines.append(f"CREATE SCHEMA IF NOT EXISTS {t.database}.{t.schema_name};")
    return ("-- objects the read-only validation found missing\n" + "\n".join(lines) + "\n\n") if lines else ""


def _table_set(spec: PipelineSpec) -> dict[str, str]:
    subs = [_table_spec(spec, table) for table in spec.tables]
    t = spec.target
    tables_sql = f"-- {spec.name}: {len(subs)} Snowflake-managed Iceberg tables in {t.database}.{t.schema_name}\n\n" + "\n".join(_table_sql(s) for s in subs)
    load = [f"-- {spec.name}: {_load_statements(subs[0])[0]} of {len(subs)} tables, each from its own file"]
    for sub, table in zip(subs, spec.tables, strict=True):
        load.append(f"\n-- {table.name} <- {table.source_file}")
        load += [f"{s};" for s in _load_statements(sub)[1]]
    checks = [f"-- {spec.name}: post-load checks of {len(subs)} tables; every statement must return 0 failures"]
    for sub, table in zip(subs, spec.tables, strict=True):
        body = _checks_sql(sub).split("\n", 1)[1]
        checks.append(f"\n-- {table.name}\n{body.rstrip()}")
    return {
        "README.md": _set_readme(spec),
        "spec.json": spec.model_dump_json(indent=2, by_alias=True),
        "sql/010_setup.sql": _prepare_sql(spec) + _setup_sql(spec),
        "sql/020_table.sql": tables_sql,
        "sql/030_load.sql": "\n".join(load) + "\n",
        "sql/040_checks.sql": "\n".join(checks) + "\n",
        "sql/045_reconcile.sql": _reconcile_header(spec) + "".join(f"\n-- {table.name}\n{_reconcile_ingest(sub)}" for sub, table in zip(subs, spec.tables, strict=True)),
        "sql/050_task.sql": _set_task_sql(spec, [s for sub in subs for s in _load_statements(sub)[1]]),
        "pipeline.py": _runner(spec),
        "requirements.txt": _requirements(spec),
        "tests/test_pipeline.py": _set_tests(spec),
    }


def _set_task_sql(spec: PipelineSpec, statements: list[str]) -> str:
    """One task for the whole set: its loads in one Snowflake Scripting block, $$-quoted so the runner keeps it whole."""
    task = _fqn(spec, f"{spec.name.upper()}_TASK")
    if spec.schedule == "manual" or not statements:
        return f"-- {spec.name}: on demand; no scheduled task. Run `python pipeline.py load` when files arrive.\n"
    inner = "".join("  " + s.replace("\n", "\n  ") + ";\n" for s in statements)
    return (
        f"-- {spec.name}: scheduled load of every table (cron in UTC); the task body mirrors sql/030_load.sql\n"
        f"CREATE OR REPLACE TASK {task}\n  WAREHOUSE = ${{SNOWFLAKE_WAREHOUSE}}\n  SCHEDULE = 'USING CRON {spec.schedule} UTC'\nAS\n"
        f"EXECUTE IMMEDIATE $$\nBEGIN\n{inner}END;\n$$;\n"
        f"ALTER TASK {task} RESUME;\n"
    )


def _set_tests(spec: PipelineSpec) -> str:
    tables = {t.name: {"file": t.source_file, "columns": [c.name for c in t.columns]} for t in spec.tables}
    return f'''"""Offline tests for {spec.name}: the generated SQL matches the approved spec ({len(tables)} tables); no Snowflake connection."""

from __future__ import annotations

import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(HERE))

import pipeline  # noqa: E402

ENV = {{name: name.lower() for name in pipeline.PLAN_ENV}}
TABLES = json.loads({json.dumps(json.dumps(tables))})


def test_every_table_is_created_once():
    statements = pipeline.render(HERE / "sql" / "020_table.sql", ENV)
    created = [s for s in statements if s.startswith("CREATE ICEBERG TABLE")]
    assert len(created) == len(TABLES)
    for name, table in TABLES.items():
        ddl = next(s for s in created if f".{{name}} (" in s)
        for column in table["columns"]:
            assert column in ddl, (name, column)


def test_each_copy_reads_only_its_own_file_with_columns_in_order():
    statements = pipeline.render(HERE / "sql" / "030_load.sql", ENV)
    copies = [s for s in statements if s.startswith("COPY INTO")]
    assert len(copies) == len(TABLES)
    for name, table in TABLES.items():
        copy = next(s for s in copies if s.split("(")[0].rstrip().endswith("." + name))
        assert table["file"].replace(".", "\\\\.") in copy
        positions = [copy.index(c) for c in table["columns"]]
        assert positions == sorted(positions)


def test_every_sql_file_renders_with_placeholders_filled():
    for path in sorted((HERE / "sql").glob("*.sql")):
        statements = pipeline.render(path, ENV)
        assert all(s and "${{" not in s for s in statements), path.name


def test_the_task_is_one_statement_then_resume():
    statements = pipeline.render(HERE / "sql" / "050_task.sql", ENV)
    assert len(statements) <= 2
    assert all(s.startswith(("CREATE OR REPLACE TASK", "ALTER TASK")) for s in statements)


def test_every_check_is_named_after_its_table():
    statements = pipeline.render(HERE / "sql" / "040_checks.sql", ENV)
    assert statements and all(any(f"'{{name}}." in s for name in TABLES) for s in statements)
'''


def _set_readme(spec: PipelineSpec) -> str:
    t = spec.target
    rows = "\n".join(
        f"| {x.name} | `{x.source_file}` | {len(x.columns)} | {x.rows} | {', '.join(x.keys) or '-'} | {len(x.tests)} | {x.exemplar or '-'} |" for x in spec.tables
    )
    out = (
        f"# {spec.name}\n\n{spec.summary}\n\n"
        "Generated by the Enterprise Context Hub from an approved intent. The approved spec is `spec.json`; the SQL and the\n"
        "runner implement it and nothing more.\n\n"
        f"## Flow\n\n1. `python pipeline.py upload <folder>` copies the {len(spec.tables)} CSV files to `{landing_of(spec.source).url}`, keeping their folders.\n"
        f"2. `python pipeline.py apply` creates {'the ' + ' and '.join(spec.create) + ', ' if spec.create else ''}the file format, the landing stage and "
        f"{len(spec.tables)} Snowflake-managed Iceberg tables in `{t.database}.{t.schema_name}` (external volume `{t.external_volume or '$ECH_EXTERNAL_VOLUME'}`).\n"
        f"3. `python pipeline.py load` runs the {t.load_mode} load of every table from its own file, then the checks.\n"
        f"4. `python pipeline.py schedule` creates one Snowflake task for all of them (`{spec.schedule}`).\n\n"
        f"## Tables\n\n| table | file | columns | rows | key | checks | contract |\n|---|---|---|---|---|---|---|\n{rows}\n\n"
        "Offline: `pytest -q tests`.\n\n"
    )
    if spec.assumptions:
        out += "## Assumptions\n\n" + "\n".join(f"- {x}" for x in spec.assumptions) + "\n\n"
    if spec.risks:
        out += "## Risks\n\n" + "\n".join(f"- {x}" for x in spec.risks) + "\n"
    return out


# --------------------------------------------------------------------------- a modelled layer (silver / gold)
def _model_order(spec: PipelineSpec) -> list[ModelTable]:
    """Models after the models they read, so one load builds the layer in a single pass."""
    prefix = f"{spec.target.database}.{spec.target.schema_name}.".upper()
    names = {m.name.upper() for m in spec.models}

    def reads(m: ModelTable) -> set[str]:
        return {s.upper()[len(prefix) :] for s in m.sources if s.upper().startswith(prefix)} & names - {m.name.upper()}

    done: list[ModelTable] = []
    pending = list(spec.models)
    while pending:
        built = {d.name.upper() for d in done}
        ready = [m for m in pending if reads(m) <= built] or pending  # a cycle keeps the proposed order for the rest
        done += ready
        pending = [m for m in pending if m not in ready]
    return done


def _model_table_sql(spec: PipelineSpec, m: ModelTable) -> str:
    t = spec.target
    defs = [f"  {_ident(c.name)} {c.type}{'' if c.nullable else ' NOT NULL'}" for c in m.columns] + ["  _LOADED_AT TIMESTAMP_NTZ"]
    volume = t.external_volume or "${ECH_EXTERNAL_VOLUME}"
    return (
        f"-- {m.name} ({m.kind}): {m.grain}\n"
        f"CREATE ICEBERG TABLE IF NOT EXISTS {_fqn(spec, m.name)} (\n" + ",\n".join(defs) + "\n)\n"
        f"  CATALOG = 'SNOWFLAKE'\n  EXTERNAL_VOLUME = '{volume}'\n  BASE_LOCATION = '{(t.schema_name or 'model').lower()}/{m.name.lower()}';\n"
    )


def _staged_load(spec: PipelineSpec, m: ModelTable) -> list[str]:
    """A designed table: stage the compiled SELECT with a row number per key, record the rows that break a NOT NULL
    column or repeat a key in the rejects table with the reason, merge the rest (an update only when the change hash
    differs, when the table has one), report what happened, then drop the stage."""
    target = _fqn(spec, m.name)
    stage = _fqn(spec, f"_STG_{m.name}")
    rejects = _fqn(spec, REJECTS)
    body = m.sql.strip().rstrip(";")
    cols = [_ident(c.name) for c in m.columns]
    keys = [_ident(k) for k in m.keys]
    required = [c.name for c in m.columns if not c.nullable]
    order = ", ".join([_ident(m.hash_column)] if m.hash_column else keys)
    rn = f"ROW_NUMBER() OVER (PARTITION BY {', '.join(keys)} ORDER BY {order})" if keys else "1"
    bad = " OR ".join([f"{_ident(c)} IS NULL" for c in required] + (["_RN > 1"] if keys else [])) or "FALSE"
    reasons = [f"WHEN {_ident(c)} IS NULL THEN '{c} is null'" for c in required]
    if keys:
        reasons.append(f"WHEN _RN > 1 THEN 'repeats a {', '.join(m.keys)} already loaded in this run'")
    record_key = f"TO_VARCHAR({keys[0]})" if len(keys) == 1 else f"ARRAY_TO_STRING(ARRAY_CONSTRUCT({', '.join(keys)}), '|')" if keys else "NULL"
    stamps = [c for c in (m.created_column, m.updated_column) if c and c not in {x.name for x in m.columns}]
    statements = [
        f"CREATE OR REPLACE TRANSIENT TABLE {stage} AS\nSELECT s.*, {rn} AS _RN FROM (\n{body}\n) s",
        f"INSERT INTO {rejects} (TARGET_TABLE, RECORD_KEY, REASON, RECORD, REJECTED_AT)\n"
        f"SELECT '{m.name}', {record_key}, CASE {' '.join(reasons)} END, OBJECT_CONSTRUCT_KEEP_NULL(*), CURRENT_TIMESTAMP()\nFROM {stage} WHERE {bad}",
    ]
    source = f"SELECT {', '.join(cols)} FROM {stage} WHERE NOT ({bad})"
    if keys:
        on = " AND ".join(f"t.{k} = s.{k}" for k in keys)
        sets = [f"t.{c} = s.{c}" for c in cols if c not in keys]
        if m.updated_column:
            sets.append(f"t.{_ident(m.updated_column)} = CURRENT_TIMESTAMP()")
        changed = f" AND t.{_ident(m.hash_column)} IS DISTINCT FROM s.{_ident(m.hash_column)}" if m.hash_column else ""
        inserted = cols + [_ident(c) for c in stamps]
        values = [f"s.{c}" for c in cols] + ["CURRENT_TIMESTAMP()" for _ in stamps]
        statements.append(
            f"MERGE INTO {target} t USING (\n{source}\n) s ON {on}\n"
            + (f"  WHEN MATCHED{changed} THEN UPDATE SET {', '.join(sets)}\n" if sets else "")
            + f"  WHEN NOT MATCHED THEN INSERT ({', '.join(inserted)}) VALUES ({', '.join(values)})"
        )
    else:
        statements.append(f"INSERT OVERWRITE INTO {target} ({', '.join(cols)})\n{source}")
    statements += [
        f"SELECT '{m.name}' AS MODEL_NAME, (SELECT COUNT(*) FROM {stage}) AS STAGED, (SELECT COUNT(*) FROM {stage} WHERE {bad}) AS REJECTED, "
        f"(SELECT COUNT(*) FROM {target}) AS TABLE_ROWS",
        f"DROP TABLE IF EXISTS {stage}",
    ]
    return statements


def _model_load(spec: PipelineSpec, m: ModelTable) -> list[str]:
    if m.ddl:
        return _staged_load(spec, m) if m.sql.strip() else []
    target = _fqn(spec, m.name)
    cols = [_ident(c.name) for c in m.columns]
    body = m.sql.strip().rstrip(";")
    if m.load_mode == "merge" and m.keys:
        on = " AND ".join(f"t.{_ident(k)} = s.{_ident(k)}" for k in m.keys)
        sets = ", ".join(f"t.{c} = s.{c}" for c in cols if c not in {_ident(k) for k in m.keys})
        return [
            f"MERGE INTO {target} t USING (\n{body}\n) s ON {on}\n"
            f"  WHEN MATCHED THEN UPDATE SET {sets + ', ' if sets else ''}t._LOADED_AT = CURRENT_TIMESTAMP()\n"
            f"  WHEN NOT MATCHED THEN INSERT ({', '.join(cols)}, _LOADED_AT) VALUES ({', '.join('s.' + c for c in cols)}, CURRENT_TIMESTAMP())"
        ]
    return [f"TRUNCATE TABLE IF EXISTS {target}", f"INSERT INTO {target} ({', '.join(cols)}, _LOADED_AT)\nSELECT s.*, CURRENT_TIMESTAMP() FROM (\n{body}\n) s"]


def _model_checks(spec: PipelineSpec, m: ModelTable) -> list[str]:
    target = _fqn(spec, m.name)
    out = [f"-- {m.name}"]
    for test in m.tests:
        name = f"{m.name}.{test.name}"
        if test.kind == "row_count":
            out.append(f"SELECT '{name}' AS check_name, IFF(COUNT(*) > 0, 0, 1) AS failures FROM {target};")
        elif test.kind == "not_null" and test.columns:
            out.append(f"SELECT '{name}' AS check_name, COUNT(*) AS failures FROM {target} WHERE {' OR '.join(f'{_ident(c)} IS NULL' for c in test.columns)};")
        elif test.kind == "unique" and test.columns:
            cols = ", ".join(_ident(c) for c in test.columns)
            out.append(f"SELECT '{name}' AS check_name, COUNT(*) AS failures FROM (SELECT {cols} FROM {target} GROUP BY ALL HAVING COUNT(*) > 1);")
        elif test.kind == "condition" and test.condition:
            out.append(f"SELECT '{name}' AS check_name, COUNT(*) AS failures FROM {target} WHERE {test.condition};")
    names = {x.name.upper() for x in spec.models}
    for rel in m.relationships:
        other = rel.to_table.rsplit(".", 1)[-1].upper()
        if other not in names or len(rel.columns) != len(rel.to_columns or rel.columns):
            continue
        to_cols = rel.to_columns or rel.columns
        on = " AND ".join(f"a.{_ident(a)} = b.{_ident(b)}" for a, b in zip(rel.columns, to_cols, strict=True))
        present = " AND ".join(f"a.{_ident(a)} IS NOT NULL" for a in rel.columns)
        # Snowflake does not enforce foreign keys; a value without its parent is reported, not fatal.
        out.append(
            f"SELECT '{m.name}.{'_'.join(c.lower() for c in rel.columns)}_in_{other.lower()}' AS check_name, COUNT(*) AS failures, 'warn' AS severity "
            f"FROM {target} a LEFT JOIN {_fqn(spec, other)} b ON {on} WHERE {present} AND b.{_ident(to_cols[0])} IS NULL;"
        )
    return out


def _rejects_sql(spec: PipelineSpec) -> str:
    rejects = _fqn(spec, REJECTS)
    return (
        f"\n-- Rows a load could not take (a NULL in a NOT NULL column, a repeated key), with the reason and the whole row\n"
        f"CREATE TABLE IF NOT EXISTS {rejects} (\n  TARGET_TABLE VARCHAR NOT NULL,\n  RECORD_KEY VARCHAR,\n  REASON VARCHAR NOT NULL,\n"
        f"  RECORD VARIANT,\n  REJECTED_AT TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()\n);\n"
        f"COMMENT ON TABLE {rejects} IS 'Rows the {spec.name} load rejected, with the reason and the rejected row';\n"
    )


def _model_layer(spec: PipelineSpec) -> dict[str, str]:
    t = spec.target
    ordered = _model_order(spec)
    designed = any(m.ddl for m in ordered)
    statements = [s for m in ordered for s in _model_load(spec, m)]
    setup = f"-- {spec.name}: the {t.schema_name} schema (kept if it exists)\nCREATE SCHEMA IF NOT EXISTS {t.database}.{t.schema_name};\n"
    if designed and "schema" not in spec.create:
        # The schema was there when the plan was made: the pipeline's role needs no CREATE SCHEMA on the database.
        setup = f"-- {spec.name}: the {t.schema_name} schema exists; the tables and the rejects table go into it\n"
    if designed:
        setup += _rejects_sql(spec)
    load = [f"-- {spec.name}: build {len(ordered)} tables in dependency order"]
    for m in ordered:
        if not m.sql.strip():
            load.append(f"\n-- {m.name}: no source is loaded yet ({', '.join(m.waiting_on) or 'see the spec'}); created empty, filled once they land")
            continue
        load.append(f"\n-- {m.name} <- {', '.join(m.sources)}")
        load += [f"{s};" for s in _model_load(spec, m)]
    checks = [f"-- {spec.name}: post-load checks; every statement must return 0 failures"]
    for m in ordered:
        checks += ["", *_model_checks(spec, m)]
    model_spec = spec.model_copy(update={"source": spec.source.model_copy(update={"folder": None})})
    return {
        "README.md": _model_readme(spec, ordered),
        "spec.json": spec.model_dump_json(indent=2, by_alias=True),
        "sql/010_setup.sql": setup,
        "sql/020_table.sql": f"-- {spec.name}: {len(ordered)} {'tables, as the design DDL writes them,' if designed else 'Snowflake-managed Iceberg tables'} "
        f"in {t.database}.{t.schema_name}\n\n" + "\n".join(f"-- {m.name} ({m.kind}): {m.grain}\n{m.ddl}\n" if m.ddl else _model_table_sql(spec, m) for m in ordered),
        "sql/030_load.sql": "\n".join(load) + "\n",
        "sql/040_checks.sql": "\n".join(checks) + "\n",
        "sql/045_reconcile.sql": _reconcile_header(spec) + "".join(f"\n{_reconcile_model(spec, m)}" for m in ordered if m.sql.strip()),
        "sql/050_task.sql": _set_task_sql(spec, statements),
        "pipeline.py": _runner(model_spec),
        "requirements.txt": _requirements(spec),
        "tests/test_pipeline.py": _model_tests(spec, ordered),
    }


def _model_tests(spec: PipelineSpec, ordered: list[ModelTable]) -> str:
    models = {m.name: [c.name for c in m.columns] for m in ordered}
    loaded = [m.name for m in ordered if m.sql.strip()]
    return f'''"""Offline tests for {spec.name}: the generated SQL matches the approved model ({len(models)} tables); no Snowflake connection."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(HERE))

import pipeline  # noqa: E402

ENV = {{name: name.lower() for name in pipeline.PLAN_ENV}}
MODELS = json.loads({json.dumps(json.dumps(models))})
LOADED = json.loads({json.dumps(json.dumps(loaded))})


def test_every_model_is_created_with_its_columns():
    statements = pipeline.render(HERE / "sql" / "020_table.sql", ENV)
    created = [s for s in statements if s.startswith(("CREATE ICEBERG TABLE", "CREATE TABLE"))]
    assert len(created) == len(MODELS)
    for name, columns in MODELS.items():
        ddl = next(s for s in created if re.search(rf"\\.{{name}}\\s*\\(", s))
        assert all(c in ddl for c in columns), name


def test_every_model_is_loaded():
    statements = pipeline.render(HERE / "sql" / "030_load.sql", ENV)
    for name in LOADED:
        assert any(s.startswith(("INSERT INTO", "MERGE INTO")) and f".{{name}} " in s.split("\\n")[0] + " " for s in statements), name


def test_every_sql_file_renders_with_placeholders_filled():
    for path in sorted((HERE / "sql").glob("*.sql")):
        statements = pipeline.render(path, ENV)
        assert all(s and "${{" not in s for s in statements), path.name


def test_the_task_is_one_statement_then_resume():
    statements = pipeline.render(HERE / "sql" / "050_task.sql", ENV)
    assert len(statements) <= 2
'''


def _model_readme(spec: PipelineSpec, ordered: list[ModelTable]) -> str:
    t = spec.target
    out = (
        f"# {spec.name}\n\n{spec.summary}\n\n"
        + (
            f"Generated by the Enterprise Context Hub from the design files {', '.join(f'`{f}`' for f in spec.source.mapping_files)}, compiled into\n"
            "the SQL below and dry-run against Snowflake (read-only) before approval. The approved spec is `spec.json`.\n\n"
            f"## Flow\n\n1. `python pipeline.py apply` creates the schema, {len(ordered)} tables as the design DDL writes them and `{REJECTS}` in `{t.database}.{t.schema_name}`.\n"
            "2. `python pipeline.py load` builds each table in dependency order: it stages the compiled SELECT, records rows that break a NOT NULL\n"
            f"   column or repeat a key in `{REJECTS}` with the reason, merges the rest (updating a row only when its change hash differs), then runs the checks.\n"
            if spec.source.mapping_files
            else f"Generated by the Enterprise Context Hub from an approved model of the {t.schema_name} layer, proposed by the data modeler\n"
            "and checked against Snowflake (read-only) before approval. The approved spec is `spec.json`.\n\n"
            f"## Flow\n\n1. `python pipeline.py apply` creates the schema and {len(ordered)} Snowflake-managed Iceberg tables in `{t.database}.{t.schema_name}`.\n"
            "2. `python pipeline.py load` builds them in dependency order, then runs the checks.\n"
        )
        +
        f"3. `python pipeline.py schedule` creates one Snowflake task for the layer (`{spec.schedule}`).\n\n## Tables\n\n"
    )
    for m in ordered:
        out += f"### {m.name} ({m.kind})\n\n{m.description or m.grain}\n\n- grain: {m.grain}\n- key: {', '.join(m.keys) or '-'}\n- reads: {', '.join(m.sources)}\n"
        if m.exemplar:
            out += f"- follows: {m.exemplar}" + (f"; differs: {'; '.join(m.deviations)}" if m.deviations else "") + "\n"
        out += "\n| column | type | from |\n|---|---|---|\n" + "\n".join(f"| {c.name} | {c.type} | `{c.expression}` |" for c in m.columns) + "\n\n"
    if spec.assumptions:
        out += "## Assumptions\n\n" + "\n".join(f"- {x}" for x in spec.assumptions) + "\n\n"
    if spec.risks:
        out += "## Risks\n\n" + "\n".join(f"- {x}" for x in spec.risks) + "\n"
    return out


def _generic_readme(spec: PipelineSpec) -> str:
    return (
        f"# {spec.name}\n\n{spec.summary}\n\nThis intent kind ({spec.kind}) has no template; the spec is in `spec.json` "
        "for the reference agent or a person to implement.\n"
    )
