"""The mapping modeler: a modelled layer compiled from the design documents a ticket points at.

Where the data modeler designs a layer with Claude, this one takes the team's own design as the contract: the
source-to-target mapping, the data model and the DDL, compiled by ``mapping`` without knowing any table. Every logical
source is bound to a table loaded in the layer below, and each compiled SELECT is dry-run read-only in Snowflake:
rows, repeated keys, NULLs in NOT NULL columns, and foreign keys that find no parent. What the dry run finds is
written on the table and the spec for the approver; the load rejects such rows with their reason instead of failing.
Nothing is created or loaded here.
"""

from __future__ import annotations

import asyncio
import re
from pathlib import Path

from ech_core.logging import get_logger
from ech_core.schemas.intents import (
    IntentValidation,
    ModelColumn,
    ModelRelationship,
    ModelTable,
    PipelineSpec,
    SpecMatch,
    SpecTest,
    StructuredIntent,
)
from query_service.intents import mapping
from query_service.intents.planner import cron_for
from query_service.intents.validate import Expectation, SnowflakeReader, SqlRunner

log = get_logger(__name__)
REJECTS = "LOAD_REJECTS"
_KINDS = {"dimension", "fact", "bridge", "reference", "aggregate"}
_PREFIX_KIND = {"DIM": "dimension", "FACT": "fact", "BRIDGE": "bridge", "REF": "reference", "AGG": "aggregate"}


def _n(value: object) -> int:
    try:
        return int(value or 0)  # type: ignore[call-overload]
    except (TypeError, ValueError):
        return 0


def _kind(c: mapping.CompiledModel) -> str:
    if c.kind in _KINDS and not c.name.startswith(("BRIDGE", "REF", "AGG")):
        return c.kind
    return _PREFIX_KIND.get(c.name.split("_", 1)[0], c.kind if c.kind in _KINDS else "reference")


def _logic(t: mapping.Transform | None, branches: list[str]) -> str:
    """The mapping's expression for a column, as the approver reads it: per source that is built, or the shared one."""
    if t is None:
        return "NULL"
    if isinstance(t.logic, str):
        return t.logic
    parts = [f"{s}: {t.logic[s]}" for s in branches if s in t.logic]
    if "default" in t.logic and len(parts) < len(branches):
        parts.append(f"otherwise: {t.logic['default']}")
    return " | ".join(parts) or "NULL"


def design_label(files: list[str]) -> str:
    return ", ".join(Path(f).name for f in files)


class MappingModeler:
    def __init__(self, *, reader: SnowflakeReader | None, data_dir: Path) -> None:
        self._reader = reader
        self._data_dir = data_dir

    async def model(
        self, intent: StructuredIntent, title: str, expect: Expectation, validation: IntentValidation | None, *, ticket: str = ""
    ) -> PipelineSpec:
        files = await asyncio.to_thread(mapping.resolve_files, self._data_dir, intent.source.mapping_files)
        if not files:
            raise ValueError(f"the design files {', '.join(intent.source.mapping_files) or '(none named)'} are not under the data directory")
        design = await asyncio.to_thread(mapping.read_design, files, self._data_dir)
        if not design.mapping:
            raise ValueError("; ".join(design.problems) or "no source-to-target mapping among the design files")
        reachable = validation is not None and validation.reachable
        database = (expect.target_database or expect.source_database or "").upper()
        schema = (expect.target_schema or next((m.schema for m in design.mapping if m.schema), "") or intent.layer or "SILVER").upper()
        catalog = {o.name.upper(): o.columns for o in (validation.objects if validation else []) if o.kind == "table" and o.role == "source" and o.exists}
        compiled = mapping.compile_design(design, catalog, prefer_schema=expect.source_schema)
        tables = [self._table(c, design, database, schema) for c in compiled]
        risks: list[str] = []
        if self._reader is not None and reachable:
            async with self._reader.session() as sql:
                for c, t in zip(compiled, tables, strict=True):
                    await self._dry_run(sql, c, t)
                await self._orphans(sql, compiled, tables)
        else:
            risks.append("Snowflake was not checked: the SQL is compiled from the mapping but not run, so rows, repeated keys and NULLs are not known.")
        risks += self._risks(compiled, tables, database, schema)
        risks += self._ticket_risks(ticket or title, intent, design, tables)
        if reachable and validation is not None and any(o.kind == "schema" and o.role == "target" and not o.exists for o in validation.objects):
            risks.append(
                f"{database}.{schema} does not exist yet: the setup creates it, so the pipeline's role needs CREATE SCHEMA on {database}. "
                "Or create the schema, grant the role USAGE and CREATE TABLE on it, and re-plan."
            )
        return self._spec(intent, title, expect, design, files, compiled, tables, database, schema, risks, validation)

    # ------------------------------------------------------------------ one table
    def _table(self, c: mapping.CompiledModel, design: mapping.Design, database: str, schema: str) -> ModelTable:
        transforms = {t.column: t for m in design.mapping if m.target == c.name for t in m.transforms}
        tests: list[SpecTest] = []
        if c.sql:
            tests.append(SpecTest(name=f"{c.name.lower()}_rows", kind="row_count", detail="the table holds rows after the load"))
        if c.keys:
            tests.append(SpecTest(name=f"{c.name.lower()}_key_unique", kind="unique", columns=list(c.keys), detail="one row per key"))
            tests.append(SpecTest(name=f"{c.name.lower()}_key_not_null", kind="not_null", columns=list(c.keys)))
        required = [col.name for col in c.columns if not col.nullable and col.name not in c.keys]
        if required:
            tests.append(SpecTest(name=f"{c.name.lower()}_required", kind="not_null", columns=required, detail="the DDL's NOT NULL columns"))
        findings = list(c.findings) + [f"left out: {s}" for s in c.skipped]
        if not c.sql:
            findings.insert(0, "none of its sources are loaded: the table is created and stays empty until they land")
        return ModelTable(
            name=c.name,
            kind=_kind(c),  # type: ignore[arg-type]
            grain=f"one row per {', '.join(c.keys)}" if c.keys else "no key declared",
            description=c.description,
            keys=list(c.keys),
            load_mode="merge",
            sources=list(c.sources),
            sql=c.sql,
            columns=[
                ModelColumn(
                    name=col.name,
                    type=col.type,
                    expression=_logic(transforms.get(col.name), c.branches),
                    nullable=col.nullable,
                    description=col.description,
                )
                for col in c.columns
            ],
            relationships=[ModelRelationship(columns=[fk.column], to_table=fk.table, to_columns=[fk.to_column]) for fk in c.foreign_keys],
            tests=tests,
            exemplar=None,
            findings=findings,
            ddl=mapping.qualify_ddl(c.ddl, database, schema) if c.ddl else "",
            hash_column=c.hash_column,
            created_column=c.created_column,
            updated_column=c.updated_column,
            waiting_on=list(c.waiting_on),
        )

    async def _dry_run(self, sql: SqlRunner, c: mapping.CompiledModel, t: ModelTable) -> None:
        """Rows, distinct keys, blank keys and NULLs per NOT NULL column of the compiled SELECT (read-only)."""
        if not c.sql:
            return
        required = [col.name for col in c.columns if not col.nullable]
        keys = [mapping.ident(k) for k in c.keys]
        parts = ["COUNT(*) AS N"]
        if keys:
            parts += [f"COUNT(DISTINCT {', '.join(keys)}) AS K", f"COUNT_IF({' OR '.join(f'{k} IS NULL' for k in keys)}) AS BK"]
        parts += [f"COUNT_IF({mapping.ident(name)} IS NULL) AS NN_{i}" for i, name in enumerate(required)]
        try:
            rows = await sql.query(f"SELECT {', '.join(parts)} FROM (\n{c.sql}\n)")
        except Exception as exc:  # noqa: BLE001 - the error is the finding
            t.findings.insert(0, f"does not compile in Snowflake: {str(exc)[:240]}")
            return
        got = {k.lower(): v for k, v in (rows[0] if rows else {}).items()}
        n, k, bk = _n(got.get("n")), _n(got.get("k")), _n(got.get("bk"))
        t.rows = n
        t.duplicates = max(0, n - bk - k) if keys else None
        t.nulls = {name: _n(got.get(f"nn_{i}")) for i, name in enumerate(required) if _n(got.get(f"nn_{i}"))}
        summary = f"compiles in Snowflake; {n:,} rows from {', '.join(c.branches)}"
        if keys:
            summary += f", {k:,} distinct {', '.join(c.keys)}"
        t.findings.insert(0, summary)

    async def _orphans(self, sql: SqlRunner, compiled: list[mapping.CompiledModel], tables: list[ModelTable]) -> None:
        """Foreign keys whose value finds no parent row, child and parent both as compiled (read-only)."""
        by_name = {c.name: c for c in compiled}
        for c, t in zip(compiled, tables, strict=True):
            if not c.sql:
                continue
            for fk in c.foreign_keys:
                parent = by_name.get(fk.table)
                if parent is None or parent.name == c.name:
                    continue
                if not parent.sql:
                    t.findings.append(f"{fk.column} points at {fk.table}, which has no loaded sources yet: its values find no parent")
                    continue
                col, to = mapping.ident(fk.column), mapping.ident(fk.to_column)
                statement = (
                    f"SELECT COUNT(*) AS N FROM (\n{c.sql}\n) C WHERE C.{col} IS NOT NULL AND NOT EXISTS "
                    f"(SELECT 1 FROM (\n{parent.sql}\n) P WHERE P.{to} = C.{col})"
                )
                try:
                    rows = await sql.query(statement)
                except Exception as exc:  # noqa: BLE001 - a check that cannot run is said, not hidden
                    t.findings.append(f"{fk.column} → {fk.table} could not be checked: {str(exc)[:160]}")
                    continue
                orphans = _n({k.lower(): v for k, v in (rows[0] if rows else {}).items()}.get("n"))
                if orphans:
                    t.findings.append(f"{orphans:,} rows have a {fk.column} that {fk.table} does not hold")
                else:
                    t.findings.append(f"every {fk.column} resolves to {fk.table}")

    # ------------------------------------------------------------------ what the approver must know
    def _risks(self, compiled: list[mapping.CompiledModel], tables: list[ModelTable], database: str, schema: str) -> list[str]:
        rejects = f"{database}.{schema}.{REJECTS}"
        out: list[str] = []
        for c, t in zip(compiled, tables, strict=True):
            total = len(c.branches) + len(c.skipped)
            if not c.sql:
                out.append(f"{c.name}: none of its {total} source(s) are loaded ({', '.join(c.waiting_on) or 'see findings'}); it is created empty and filled when they land.")
                continue
            if c.skipped:
                left = ", ".join(s.split(":", 1)[0] for s in c.skipped)
                verb = "waits" if len(c.skipped) == 1 else "wait"
                out.append(f"{c.name}: built from {len(c.branches)} of {total} sources; {left} {verb} for {', '.join(c.waiting_on) or 'columns the loaded tables lack'}.")
            if t.duplicates:
                out.append(
                    f"{c.name}: {t.duplicates:,} of {t.rows or 0:,} rows repeat a {', '.join(c.keys)} already taken; "
                    f"the load keeps one per key and records the rest in {rejects}."
                )
            for name, count in t.nulls.items():
                out.append(f"{c.name}: {count:,} rows have no {name}, a NOT NULL column; they are rejected into {rejects} with that reason.")
            out += [f"{c.name}: {f}" for f in t.findings if " does not hold" in f or "no loaded sources" in f or "does not compile" in f]
        return out

    def _ticket_risks(self, text: str, intent: StructuredIntent, design: mapping.Design, tables: list[ModelTable]) -> list[str]:
        out: list[str] = []
        built = {t.name for t in tables}
        named = {w.upper() for w in re.findall(r"\b(?:DIM|FACT|BRIDGE|REF|AGG)_[A-Za-z0-9_]+\b", text or "", re.I)}
        for extra in sorted(named - built):
            out.append(f"The ticket names {extra}, which the mapping does not define; it is not built.")
        if design.ddl and ("ICEBERG" in (text or "").upper() or intent.target.external_volume):
            volume = f" on {intent.target.external_volume}" if intent.target.external_volume else ""
            out.append(f"The ticket asks for Iceberg tables{volume}; the DDL creates native Snowflake tables, so they are built as the DDL says.")
        return out

    def _spec(
        self,
        intent: StructuredIntent,
        title: str,
        expect: Expectation,
        design: mapping.Design,
        files: list[Path],
        compiled: list[mapping.CompiledModel],
        tables: list[ModelTable],
        database: str,
        schema: str,
        risks: list[str],
        validation: IntentValidation | None,
    ) -> PipelineSpec:
        root = self._data_dir.resolve()
        rel = [str(p.relative_to(root)).replace("\\", "/") if root in p.parents else p.name for p in files]
        native = all(t.ddl for t in tables)
        existing = {o.name.upper() for o in (validation.objects if validation else []) if o.kind == "table" and o.role == "target" and o.exists}
        for t in tables:
            t.exists = f"{database}.{schema}.{t.name}" in existing
        target = intent.target.model_copy(
            update={
                "database": database or None,
                "schema_name": schema,
                "table": None,
                "table_format": "native" if native else intent.target.table_format,
                "external_volume": None if native else intent.target.external_volume,
                "base_location": None if native else schema.lower(),
                "load_mode": "merge",
            }
        )
        source_schema = (expect.source_schema or "").upper()
        bound = sorted({s for c in compiled for s in c.sources})
        domain = re.sub(r"[^a-z0-9]+", "_", str(design.header.get("domain") or database or "model").lower()).strip("_")
        hashed = sorted({t.hash_column for t in tables if t.hash_column})
        stamps = sorted({x for t in tables for x in (t.created_column, t.updated_column) if x})
        assumptions = [
            f"Compiled from {design_label(rel)}: {len(tables)} targets, {sum(len(c.branches) for c in compiled)} source branches bound to "
            f"{len(bound)} tables loaded in {(expect.source_database or database).upper()}.{source_schema} by name and by the columns each branch reads.",
            f"Each table is merged on its key{'; ' + ', '.join(hashed) + ' decides whether a matched row changed (CDC)' if hashed else ''}"
            f"{'; ' + ' and '.join(stamps) + ' are set by the load' if stamps else ''}.",
            f"Rows that would break a NOT NULL column or repeat a key are written to {database}.{schema}.{REJECTS} with the reason, so every source row lands or is rejected.",
            "Foreign keys are checked after the load and reported as warnings: Snowflake does not enforce them.",
            f"Tables are created as the DDL writes them ({'native Snowflake tables' if native else 'Snowflake-managed Iceberg tables'}), with its comments; an existing table is kept.",
        ]
        return PipelineSpec(
            name=f"model_{domain}_{schema.lower()}",
            kind="model_layer",
            summary=intent.summary or title,
            source=intent.source.model_copy(
                update={"database": (expect.source_database or database).upper() or None, "schema_name": source_schema or None, "folder": None, "mapping_files": rel}
            ),
            target=target,
            transformations=[
                f"{t.name}: {', '.join(c.branches) or 'waits'}" + (f" → {t.rows:,} rows" if t.rows is not None else "") for c, t in zip(compiled, tables, strict=True)
            ],
            schedule=cron_for(intent.freshness),
            matches=[SpecMatch(kind="exemplar", name=Path(rel[0]).name, detail=f"design: {design_label(rel)}")],
            risks=risks,
            assumptions=assumptions,
            models=tables,
            create=["schema"] if validation is not None and any(o.kind == "schema" and o.role == "target" and not o.exists for o in validation.objects) else [],
        )
