"""Copy an exemplar's quality checks onto a new CSV source, and find the models that should read it.

The exemplar is a table in a crawled repository whose CSV source looks like the new one (the planner
picks it by header overlap). Its checks are translated rather than pasted: the repository's raw layer
holds strings, while the generated pipeline casts every column to its type on load and stops on a
value that does not fit, so a format check on a typed column is already enforced and a safe cast
around one is dropped. Checks that join other tables wait until the new source has its own
counterparts of those tables.
"""

from __future__ import annotations

import datetime as dt
import decimal
import re
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import quote

import sqlglot
from sqlglot import exp
from sqlglot.errors import SqlglotError
from sqlglot.executor.python import PythonExecutor
from sqlglot.executor.table import ensure_tables
from sqlglot.optimizer import optimize
from sqlglot.planner import Plan
from sqlglot.schema import ensure_schema

from ech_core.schemas.intents import (
    SpecColumn,
    SpecDownstream,
    SpecDownstreamColumn,
    SpecExemplarCheck,
    SpecTest,
)

DIALECT = "snowflake"
_DATE_PARAM = re.compile(r"as_of|date|day|snapshot|run", re.I)
_TEXT_TYPES = ("VARCHAR", "STRING", "TEXT", "CHAR")


def norm(text: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (text or "").lower())


def short_name(qualified: str) -> str:
    return qualified.rsplit(".", 1)[-1]


def join_words(items: list[str]) -> str:
    items = list(items)
    if len(items) <= 1:
        return "".join(items)
    return ", ".join(items[:-1]) + f" and {items[-1]}"


def _exemplar_column(ec: dict[str, Any]) -> str:
    return str(ec.get("column") or short_name(str(ec.get("name") or ""))).upper()


def column_map(exemplar_columns: list[dict[str, Any]], columns: list[SpecColumn]) -> dict[str, str]:
    """Exemplar column -> the new feed's column, matched on name or CSV header."""
    by_norm: dict[str, str] = {}
    for c in columns:
        by_norm.setdefault(norm(c.name), c.name)
        if c.source_header:
            by_norm.setdefault(norm(c.source_header), c.name)
    out: dict[str, str] = {}
    for ec in exemplar_columns:
        name = _exemplar_column(ec)
        hit = by_norm.get(norm(name)) or by_norm.get(norm(str(ec.get("source_header") or "")))
        if hit:
            out[name] = hit
    return out


def adopt_contract(exemplar: dict[str, Any], columns: list[SpecColumn], colmap: dict[str, str]) -> tuple[list[str], list[str]]:
    """Nullability from the exemplar's contract, where the sample does not contradict it.

    A column the contract leaves optional stays nullable even when the sample had no blanks, so a
    later blank does not stop the load; a column it requires but the sample leaves blank stays
    nullable too, and the copied not-null check reports those rows instead.
    """
    table = str(exemplar["table"]["name"])
    by_name = {c.name: c for c in columns}
    relaxed: list[str] = []
    blank: list[str] = []
    for ec in exemplar["columns"]:
        col = by_name.get(colmap.get(_exemplar_column(ec), ""))
        if col is None:
            continue
        if ec.get("required"):
            if col.nullable:
                blank.append(col.name)
        elif not col.nullable:
            col.nullable = True
            relaxed.append(col.name)
    assumptions: list[str] = []
    risks: list[str] = []
    if relaxed:
        verb = "stays" if len(relaxed) == 1 else "stay"
        assumptions.append(f"{join_words(relaxed)} {verb} nullable, as in {table}'s contract; the sample just had no blanks.")
    if blank:
        verb = "is" if len(blank) == 1 else "are"
        risks.append(f"{join_words(blank)} {verb} required in {table}'s contract, but the sample has blank values; the copied not-null check will report those rows.")
    return assumptions, risks


# --------------------------------------------------------------------------- checks
@dataclass
class CopiedChecks:
    conditions: list[SpecTest] = field(default_factory=list)
    not_null: list[str] = field(default_factory=list)
    not_null_origin: str | None = None
    unique: SpecTest | None = None
    accounting: list[SpecExemplarCheck] = field(default_factory=list)


Siblings = dict[str, tuple[str, dict[str, str]]]


def translate_checks(
    checks: list[dict[str, Any]],
    exemplar_table: str,
    colmap: dict[str, str],
    types: dict[str, str],
    *,
    target: str | None = None,
    siblings: Siblings | None = None,
) -> CopiedChecks:
    """Each exemplar check becomes a test, is covered by the typed load, or is skipped with the reason.

    With `siblings` (exemplar table → the new table and its column map, for every table loaded alongside),
    a check that joins other tables is copied too when they are all loaded alongside: it reads `target`
    and the siblings' new tables instead.
    """
    out = CopiedChecks()
    typed = {name for name, typ in types.items() if not typ.upper().startswith(_TEXT_TYPES)}
    labels: set[str] = set()
    for check in checks:
        name = str(check["name"])
        others = sorted({str(o).upper() for o in check.get("others") or [] if str(o).upper() != exemplar_table.upper()})
        if others and target and siblings and all(o in siblings for o in others):
            reason = _translate_query(check, exemplar_table.upper(), target, colmap, siblings, labels, out)
        else:
            reason = _translate(check, exemplar_table.upper(), colmap, types, typed, labels, out)
        if reason:
            out.accounting.append(SpecExemplarCheck(name=name, outcome="skipped", detail=reason))
    required = [a.name for a in out.accounting if a.test == "required_columns_not_null"]
    if required:
        out.not_null_origin = required[0] if len(required) == 1 else f"{len(required)} not-null checks of {short_name(exemplar_table)}"
    return out


def _translate(
    check: dict[str, Any], table: str, colmap: dict[str, str], types: dict[str, str], typed: set[str], labels: set[str], out: CopiedChecks
) -> str | None:
    """Record the copied or covered check on `out`; return why it was skipped otherwise."""
    name = str(check["name"])
    others = sorted({str(o) for o in check.get("others") or [] if str(o).upper() != table})
    if others:
        return f"joins {join_words(others)}; add it once this source has its own counterpart"
    sql = check.get("sql")
    if not sql:
        return "the crawl kept no SQL for it; crawl the repository again to copy it"
    try:
        tree = sqlglot.parse_one(str(sql), read=DIALECT)
    except SqlglotError:
        return "its SQL could not be parsed"
    tables = sorted({".".join(p for p in (t.db, t.name) if p).upper() for t in tree.find_all(exp.Table)})
    foreign = [t for t in tables if t != table]
    if foreign:
        return f"joins {join_words(foreign)}; add it once this source has its own counterpart"
    select = next((s for s in tree.find_all(exp.Select) if _reads_table(s)), None)
    if select is None:
        return "it has no query over the table to copy"
    group = select.args.get("group")
    if group is not None:
        cols = [c.name.upper() for c in group.find_all(exp.Column)]
        missing = [c for c in cols if c not in colmap]
        if missing:
            return f"uses {join_words(missing)}, which this feed does not have"
        if not cols or select.args.get("having") is None:
            return "a grouped check other than key uniqueness"
        key = [colmap[c] for c in cols]
        label = "_".join(k.lower() for k in key) + "_unique"
        out.unique = SpecTest(name=label, kind="unique", columns=key, detail="per source file", origin=name)
        out.accounting.append(SpecExemplarCheck(name=name, outcome="copied", test=label, detail=f"unique on {join_words(key)}"))
        return None
    where = select.args.get("where")
    if where is None:
        return "it has no condition to copy"
    pred = where.this.copy()
    used = sorted({c.name.upper() for c in pred.find_all(exp.Column)})
    missing = [c for c in used if c not in colmap]
    if missing:
        return f"uses {join_words(missing)}, which this feed does not have"
    for col in list(pred.find_all(exp.Column)):
        col.set("table", None)
        col.set("this", exp.to_identifier(colmap[col.name.upper()]))
    if isinstance(pred, exp.Is) and isinstance(pred.this, exp.Column) and isinstance(pred.expression, exp.Null):
        out.not_null.append(pred.this.name)
        out.accounting.append(SpecExemplarCheck(name=name, outcome="copied", test="required_columns_not_null", detail=f"not null on {pred.this.name}"))
        return None
    safe_casts = [n for n in pred.find_all(exp.Func) if n.args.get("safe") and isinstance(n.this, exp.Column) and n.this.name in typed]
    formats = [r.this.name for r in pred.find_all(exp.RegexpLike) if isinstance(r.this, exp.Column) and r.this.name in typed]
    formats += [n.this.name for n in safe_casts if isinstance(n.parent, exp.Is) and isinstance(n.parent.expression, exp.Null)]
    if formats:
        col = formats[0]
        detail = f"a format check; the load casts {col} to {types[col]} and stops on a value that does not fit"
        out.accounting.append(SpecExemplarCheck(name=name, outcome="covered", detail=detail))
        return None
    notes: list[str] = []
    for node in safe_casts:
        node.replace(node.this.copy())
    if safe_casts:
        notes.append("safe casts dropped: " + join_words(sorted({n.this.name for n in safe_casts})) + " already typed")
    for param in check.get("params") or []:
        literals = [lit for lit in pred.find_all(exp.Literal) if lit.is_string and lit.this == param]
        if not literals:
            continue
        if not _DATE_PARAM.search(str(param)):
            return f"it needs the run-time parameter {param}"
        for lit in literals:
            lit.replace(exp.CurrentDate())
        notes.append(f"{param} read as CURRENT_DATE")
    label = _label(name, table, labels)
    condition = pred.sql(dialect=DIALECT)
    detail = f"copied from {name}" + (f" ({'; '.join(notes)})" if notes else "")
    out.conditions.append(SpecTest(name=label, kind="condition", columns=[colmap[c] for c in used], condition=condition, origin=name, detail=detail))
    out.accounting.append(SpecExemplarCheck(name=name, outcome="copied", test=label, detail=condition))
    return None


def _translate_query(
    check: dict[str, Any], table: str, target: str, colmap: dict[str, str], siblings: Siblings, labels: set[str], out: CopiedChecks
) -> str | None:
    """A check across tables loaded together: its query over the exemplar tables, re-pointed at the new ones."""
    name = str(check["name"])
    sql = check.get("sql")
    if not sql:
        return "the crawl kept no SQL for it; crawl the repository again to copy it"
    try:
        tree = sqlglot.parse_one(str(sql), read=DIALECT)
    except SqlglotError:
        return "its SQL could not be parsed"
    select = next((s for s in tree.find_all(exp.Select) if _reads_table(s)), None)
    if select is None:
        return "it has no query over the tables to copy"
    if select.args.get("group") is not None:
        return "a grouped check across tables"
    tables = {table: (target, colmap), **siblings}
    aliases: dict[str, str] = {}
    for t in select.find_all(exp.Table):
        full = ".".join(p for p in (t.db, t.name) if p).upper()
        if full not in tables:
            return f"reads {full}, which is not loaded alongside"
        aliases[t.alias_or_name.upper()] = full
    used: list[str] = []
    for col in list(select.find_all(exp.Column)):
        owner = aliases.get(col.table.upper(), table) if col.table else table
        mapping = tables[owner][1]
        if col.name.upper() not in mapping:
            return f"uses {short_name(owner)}.{col.name.upper()}, which that file does not have"
        new = mapping[col.name.upper()]
        if owner == table and new not in used:
            used.append(new)
        col.set("this", exp.to_identifier(new))
    for t in list(select.find_all(exp.Table)):
        parts = tables[".".join(p for p in (t.db, t.name) if p).upper()][0].split(".")
        t.set("this", exp.to_identifier(parts[-1]))
        t.set("db", exp.to_identifier(parts[-2]) if len(parts) > 1 else None)
        t.set("catalog", exp.to_identifier(parts[-3]) if len(parts) > 2 else None)
    inner = select.copy()
    inner.set("expressions", [exp.Literal.number(1)])
    for arg in ("group", "having", "order", "limit"):
        inner.set(arg, None)
    notes: list[str] = []
    for param in check.get("params") or []:
        literals = [lit for lit in inner.find_all(exp.Literal) if lit.is_string and lit.this == param]
        if not literals:
            continue
        if not _DATE_PARAM.search(str(param)):
            return f"it needs the run-time parameter {param}"
        for lit in literals:
            lit.replace(exp.CurrentDate())
        notes.append(f"{param} read as CURRENT_DATE")
    label = _label(name, table, labels)
    others = sorted({short_name(o) for o in aliases.values() if o != table})
    query = inner.sql(dialect=DIALECT)
    detail = f"copied from {name}; reads {join_words(others)}" + (f" ({'; '.join(notes)})" if notes else "")
    out.conditions.append(SpecTest(name=label, kind="query", columns=used, condition=query, origin=name, detail=detail))
    out.accounting.append(SpecExemplarCheck(name=name, outcome="copied", test=label, detail=f"across {join_words([short_name(table), *others])}"))
    return None


def _reads_table(select: exp.Select) -> bool:
    source = select.args.get("from_") or select.args.get("from")
    return isinstance(source, exp.From) and isinstance(source.this, exp.Table)


def _label(check: str, table: str, taken: set[str]) -> str:
    prefix = short_name(table) + "."
    rest = check[len(prefix) :] if check.upper().startswith(prefix) else check
    base = re.sub(r"[^a-z0-9]+", "_", rest.lower()).strip("_") or "check"
    label, n = base, 1
    while label in taken:
        n += 1
        label = f"{base}_{n}"
    taken.add(label)
    return label


# --------------------------------------------------------------------------- sample pre-check
def _regexp_like(value: Any, pattern: Any, flags: Any = None) -> bool | None:
    if value is None or pattern is None:
        return None
    return re.fullmatch(str(pattern), str(value), re.I if flags and "i" in str(flags) else 0) is not None


def _replace(value: Any, old: Any, new: Any = "") -> str | None:
    if value is None or old is None:
        return None
    return str(value).replace(str(old), "" if new is None else str(new))


# Snowflake functions the copied checks use that sqlglot's Python executor does not ship.
_ENV = {"REGEXPLIKE": _regexp_like, "REPLACE": _replace}


def _typed(raw: str | None, typ: str) -> Any:
    if raw is None:
        return None
    text, upper = raw.strip(), typ.upper()
    try:
        if upper.startswith(("NUMBER", "DECIMAL", "NUMERIC", "INT")):
            return decimal.Decimal(text)
        if upper.startswith("DATE"):
            return dt.date.fromisoformat(text)
        if upper.startswith("TIMESTAMP"):
            return dt.datetime.fromisoformat(text.replace("Z", "+00:00"))
        if upper.startswith("BOOLEAN"):
            return text.lower() in {"true", "yes", "y", "t", "1"}
    except (ValueError, decimal.InvalidOperation):
        return None
    return raw


def precheck(tests: list[SpecTest], columns: list[SpecColumn], records: list[dict[str, str | None]]) -> None:
    """Run the not-null and copied condition tests against the sampled rows, before anything is loaded."""
    if not records or not columns:
        return
    rows = [{c.name: _typed(r.get(c.name), c.type) for c in columns} for r in records]
    schema = {"t": {c.name: c.type for c in columns}}
    for test in tests:
        if test.kind == "not_null" and test.columns:
            blanks = sorted({c for r in rows for c in test.columns if r.get(c) is None})
            test.sample_failures = sum(1 for r in rows if any(r.get(c) is None for c in test.columns))
            test.sample_examples = [f"{c} blank" for c in blanks[:3]]
        elif test.kind == "condition" and test.condition:
            try:
                failing = _select(rows, schema, test.columns, test.condition)
            except Exception:  # noqa: BLE001, S112 - not every Snowflake function runs in the Python executor; the check still runs after the load
                continue
            test.sample_failures = len(failing)
            seen: list[str] = []
            for row in failing:
                text = ", ".join(f"{c}={'blank' if v is None else v}" for c, v in zip(test.columns, row, strict=False))
                if text not in seen:
                    seen.append(text)
            test.sample_examples = seen[:3]


def precheck_queries(tests: list[SpecTest], tables: dict[str, tuple[list[SpecColumn], list[dict[str, str | None]]]]) -> None:
    """Run the copied cross-table checks against the sampled rows of every table they read (fully qualified names)."""
    rows: dict[str, Any] = {}
    schema: dict[str, Any] = {}
    for fqn, (columns, records) in tables.items():
        *path, name = fqn.split(".")
        node_rows, node_schema = rows, schema
        for part in path:
            node_rows = node_rows.setdefault(part, {})
            node_schema = node_schema.setdefault(part, {})
        node_rows[name] = [{c.name: _typed(r.get(c.name), c.type) for c in columns} for r in records]
        node_schema[name] = {c.name: c.type for c in columns}
    for test in tests:
        if test.kind != "query" or not test.condition:
            continue
        try:
            sql = f"SELECT COUNT(*) AS failures FROM ({test.condition}) AS v"
            expression = optimize(sqlglot.parse_one(sql, read=DIALECT), ensure_schema(schema, dialect=DIALECT), leave_tables_isolated=True, dialect=DIALECT)
            result = PythonExecutor(env=_ENV, tables=ensure_tables(rows, dialect=DIALECT)).execute(Plan(expression))
            test.sample_failures = int(result.rows[0][0]) if result.rows else 0
        except Exception:  # noqa: BLE001, S112 - not every Snowflake function runs in the Python executor; the check still runs after the load
            continue


def _select(rows: list[dict[str, Any]], schema: dict[str, Any], columns: list[str], condition: str) -> list[tuple[Any, ...]]:
    sql = f"SELECT {', '.join(columns) or '1 AS one'} FROM t WHERE {condition}"
    expression = optimize(sqlglot.parse_one(sql, read=DIALECT), ensure_schema(schema, dialect=DIALECT), leave_tables_isolated=True, dialect=DIALECT)
    result = PythonExecutor(env=_ENV, tables=ensure_tables({"t": rows}, dialect=DIALECT)).execute(Plan(expression))
    return [tuple(row) for row in result.rows]


# --------------------------------------------------------------------------- downstream
def downstream_models(exemplar: dict[str, Any], colmap: dict[str, str], new_table: str) -> tuple[list[SpecDownstream], list[str]]:
    """The models that read the exemplar directly, with how far the new feed covers their columns."""
    repo, table = str(exemplar["repo"]), str(exemplar["table"]["name"])
    url, sha = exemplar.get("url"), exemplar.get("sha")
    models: list[SpecDownstream] = []
    risks: list[str] = []
    for d in exemplar.get("downstream") or []:
        sql_files = [f for f in d.get("files") or [] if f.endswith(".sql")] or list(d.get("files") or [])
        model = SpecDownstream(
            table=str(d["name"]),
            layer=d.get("layer"),
            repo=repo,
            files=sql_files,
            file_url=f"{str(url).rstrip('/')}/blob/{sha or 'HEAD'}/{sql_files[0]}" if url and sql_files else None,
            link=f"/knowledge?repo={quote(repo, safe='')}&node={quote(str(d['key']), safe='')}",
            reads=list(d.get("reads") or []),
            affects=list(d.get("affects") or []),
            columns=[_downstream_column(c, table, colmap) for c in d.get("columns") or []],
        )
        models.append(model)
        risks.append(_downstream_risk(model, table, new_table))
    return models, risks


def _downstream_column(column: dict[str, Any], table: str, colmap: dict[str, str]) -> SpecDownstreamColumn:
    sources = [str(u) for u in column.get("upstream") or []]
    mine = [u for u in sources if u.rsplit(".", 1)[0].upper() == table.upper()]
    provided = [colmap[short_name(u).upper()] for u in mine if short_name(u).upper() in colmap]
    if column.get("derivation") == "constant":
        status = "constant"
    elif not sources:
        status = "untraced"
    elif len(provided) < len(mine):
        status = "missing"
    elif len(mine) < len(sources):
        status = "needs"
    else:
        status = "mapped"
    name = str(column.get("column") or short_name(str(column.get("name") or "")))
    return SpecDownstreamColumn(column=name, status=status, sources=sources, provided_by=provided)


def _downstream_risk(model: SpecDownstream, table: str, new_table: str) -> str:
    where = f" ({model.files[0]})" if model.files else ""
    text = f"Nothing reads {new_table} yet. In {model.repo}, {model.table}{where} reads {table}; add {new_table} to it"
    text += f", or the new rows never reach {join_words(model.affects)}." if model.affects else "."
    if model.columns:
        mapped = sum(1 for c in model.columns if c.status == "mapped")
        text += f" This feed supplies {mapped} of its {len(model.columns)} columns"
        needs = [c for c in model.columns if c.status == "needs"]
        if needs:
            tables = sorted({u.rsplit(".", 1)[0] for c in needs for u in c.sources if u.rsplit(".", 1)[0].upper() != table.upper()})
            verb = "comes" if len(needs) == 1 else "come"
            text += f"; {join_words([c.column for c in needs])} {verb} from {join_words(tables)}, which this source has no counterpart for yet"
        missing = [c.column for c in model.columns if c.status == "missing"]
        if missing:
            text += f"; {join_words(missing)} need{'s' if len(missing) == 1 else ''} exemplar columns this feed lacks"
        text += "."
        constants = [c.column for c in model.columns if c.status == "constant"]
        if constants:
            text += f" {join_words(constants)} {'is a constant' if len(constants) == 1 else 'are constants'} there; give the new rows their own value."
    return text
