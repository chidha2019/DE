"""Review a parsed ticket: does it say enough to plan a pipeline? A scored checklist, derived on every read.

Each check is ok, warn (the plan falls back to a default) or missing; a missing blocking check means the
planner cannot write the spec yet. The score weighs blocking checks double; the verdict is "needs_answers"
while anything blocks, "ready" from 75 up, and "thin" below that.
"""

from __future__ import annotations

from collections.abc import Iterable

from ech_core.schemas.intents import IntentReview, PipelineSpec, ReviewCheck, StructuredIntent

_POINTS = {"ok": 1.0, "warn": 0.5, "missing": 0.0}
_KIND_LABEL = {
    "ingest_csv_to_iceberg": "CSV files to Snowflake Iceberg tables",
    "model_layer": "a modelled layer built from the one below",
    "gold_fact": "a gold fact table",
    "other": "something without a template",
}


def _location(intent: StructuredIntent) -> str | None:
    """Where the files are read from: the folder when there is one (S3 is then only where they land)."""
    s = intent.source
    if s.folder:
        return s.folder
    if s.s3_bucket:
        return f"s3://{s.s3_bucket}/{s.s3_prefix or ''}".rstrip("/")
    return None


def _source(intent: StructuredIntent, spec: PipelineSpec | None) -> ReviewCheck:
    where = _location(intent)
    if not where:
        return ReviewCheck(key="source", label="Source files", status="missing", blocking=True, detail="no folder or S3 location named")
    if spec is not None and not spec.sampled_files:
        return ReviewCheck(key="source", label="Source files", status="warn", detail=f"{where} is named, but no CSV files were found there to sample")
    sampled = f" · {len(spec.sampled_files)} file(s), {spec.sampled_rows} rows {'read' if spec.tables else 'sampled'}" if spec else ""
    return ReviewCheck(key="source", label="Source files", status="ok", detail=f"{intent.source.file_pattern} in {where}{sampled}")


def _target(intent: StructuredIntent, spec: PipelineSpec | None = None) -> ReviewCheck:
    t = intent.target
    many = len(spec.tables) if spec and spec.tables else len(spec.models) if spec and spec.models else 0
    if t.database and t.schema_name and (many or intent.kind == "model_layer"):
        what = f"{many} tables" if many else "tables the data modeler proposes"
        return ReviewCheck(key="target", label="Target tables", status="ok", detail=f"{t.database}.{t.schema_name}: {what}")
    parts = [t.database, t.schema_name, t.table]
    if all(parts):
        return ReviewCheck(key="target", label="Target table", status="ok", detail=".".join(p for p in parts if p))
    named = ".".join(p or "?" for p in parts)
    return ReviewCheck(key="target", label="Target table", status="missing", blocking=True, detail=f"needs DATABASE.SCHEMA.TABLE, has {named}")


def _storage(intent: StructuredIntent) -> ReviewCheck:
    t = intent.target
    if t.table_format != "iceberg":
        return ReviewCheck(key="storage", label="Table storage", status="ok", detail="native Snowflake table")
    if t.external_volume:
        return ReviewCheck(key="storage", label="Table storage", status="ok", detail=f"Iceberg on external volume {t.external_volume}")
    return ReviewCheck(key="storage", label="Table storage", status="missing", blocking=True, detail="an Iceberg table needs a Snowflake external volume")


def _load(intent: StructuredIntent) -> ReviewCheck:
    t = intent.target
    if t.load_mode == "merge" and not t.merge_keys:
        return ReviewCheck(key="load", label="Load mode", status="warn", detail="merge is asked for, but no key to merge on is named")
    keys = f" on {', '.join(t.merge_keys)}" if t.merge_keys else ""
    return ReviewCheck(key="load", label="Load mode", status="ok", detail=f"{t.load_mode.replace('_', ' ')}{keys}")


def _terms(intent: StructuredIntent, spec: PipelineSpec | None, names: set[str]) -> ReviewCheck:
    known = [t for t in intent.business_terms if t.lower() in names]
    columns = (spec.columns or [c for x in spec.tables for c in x.columns]) if spec else []
    mapped = sum(1 for c in columns if c.term_key) + (sum(1 for m in spec.models for c in m.columns if c.term_key) if spec else 0)
    if known or mapped:
        detail = ", ".join(known[:4]) if known else ""
        if mapped:
            detail = f"{detail} · {mapped} column(s) carry a glossary term" if detail else f"{mapped} column(s) carry a glossary term"
        return ReviewCheck(key="terms", label="Business meaning", status="ok", detail=detail)
    if intent.business_terms:
        return ReviewCheck(key="terms", label="Business meaning", status="warn", detail=f"{', '.join(intent.business_terms[:4])}: not in the glossary yet")
    return ReviewCheck(key="terms", label="Business meaning", status="warn", detail="no business terms recognised")


def _acceptance(intent: StructuredIntent, spec: PipelineSpec | None) -> ReviewCheck:
    if intent.acceptance_criteria:
        n = len(intent.acceptance_criteria)
        return ReviewCheck(key="acceptance", label="Acceptance criteria", status="ok", detail=f"{n} stated: {intent.acceptance_criteria[0]}{' …' if n > 1 else ''}")
    tests = (spec.tests or [x for t in spec.tables for x in t.tests] or [x for m in spec.models for x in m.tests]) if spec else []
    proposed = f"; the planner proposes {len(tests)} tests" if tests else ""
    return ReviewCheck(key="acceptance", label="Acceptance criteria", status="warn", detail=f"the ticket states none{proposed}")


def _duplicate(spec: PipelineSpec) -> ReviewCheck:
    m = spec.catalog_match
    if m is not None and m.duplicate:
        return ReviewCheck(key="duplicate", label="Not a duplicate", status="warn", detail=f"{m.duplicate_reason}; load into it, or say why a second copy is needed")
    if m is not None:
        return ReviewCheck(key="duplicate", label="Not a duplicate", status="ok", detail=f"closest catalog table {m.fqn} shares {len(m.matched_columns)} of {m.feed_columns} columns")
    return ReviewCheck(key="duplicate", label="Not a duplicate", status="ok", detail="no catalog table carries these columns")


def _grain(intent: StructuredIntent, spec: PipelineSpec | None) -> ReviewCheck:
    if spec is not None and spec.models:
        return ReviewCheck(key="grain", label="Grain", status="ok", detail=f"set per table by the data modeler ({len(spec.models)} tables)")
    if intent.grain:
        return ReviewCheck(key="grain", label="Grain", status="ok", detail=intent.grain)
    if intent.kind == "model_layer":
        return ReviewCheck(key="grain", label="Grain", status="ok", detail="the data modeler sets each table's grain")
    return ReviewCheck(key="grain", label="Grain", status="warn", detail="say what one row is (one claim, one policy per day …)")


def review_intent(
    intent: StructuredIntent | None, *, questions: list[str], spec: PipelineSpec | None, glossary_names: Iterable[str]
) -> IntentReview | None:
    """The checklist for one ticket; None until it has been parsed."""
    if intent is None:
        return None
    if spec is not None:
        # Once planned, judge where the data comes from and goes by the plan: the planner fills gaps (a volume, a location).
        intent = intent.model_copy(update={"source": spec.source, "target": spec.target})
    names = {n.lower() for n in glossary_names}
    ingest = intent.kind == "ingest_csv_to_iceberg"
    checks = [
        ReviewCheck(
            key="goal",
            label="Clear goal",
            status="ok" if intent.kind != "other" and intent.summary else "warn",
            detail=_KIND_LABEL[intent.kind] if intent.summary else f"{_KIND_LABEL[intent.kind]}, with no summary",
        )
    ]
    if ingest:
        s = intent.source
        checks += [
            _source(intent, spec),
            ReviewCheck(key="format", label="File format", status="ok", detail=f"{s.file_pattern}, '{s.delimiter}' delimited, header {'yes' if s.header else 'no'}, {s.encoding}"),
        ]
    checks.append(_target(intent, spec))
    if ingest:
        checks += [_storage(intent), _load(intent)]
    checks += [
        _grain(intent, spec),
        ReviewCheck(
            key="schedule",
            label="Freshness",
            status="ok",
            detail=intent.freshness + (f" · cron {spec.schedule} UTC" if spec and spec.schedule and spec.schedule != "manual" else ""),
        ),
        ReviewCheck(key="owner", label="Owner", status="ok" if intent.owner else "warn", detail=intent.owner or "no owner named; the reporter owns it"),
        _terms(intent, spec, names),
        *([_duplicate(spec)] if spec is not None else []),
        _acceptance(intent, spec),
        ReviewCheck(
            key="questions",
            label="Open questions",
            status="missing" if questions else "ok",
            blocking=bool(questions),
            detail=f"{len(questions)} waiting: {questions[0]}" if questions else "none",
        ),
    ]

    weight = {c.key: 2.0 if c.key in ("source", "target", "storage", "questions") else 1.0 for c in checks}
    score = round(100 * sum(_POINTS[c.status] * weight[c.key] for c in checks) / sum(weight.values()))
    blockers = [c for c in checks if c.blocking and c.status == "missing"]
    defaults = [c for c in checks if c.status == "warn" and c.key != "duplicate"]
    duplicate = spec.catalog_match if spec is not None and spec.catalog_match is not None and spec.catalog_match.duplicate else None
    if blockers:
        n = len(blockers)
        verdict, headline = "needs_answers", f"{n} {'thing' if n == 1 else 'things'} to settle before the plan: {', '.join(c.label.lower() for c in blockers)}."
    elif score >= 75:
        verdict = "ready"
        headline = "Ready to plan: the ticket names the files, the target table and how it loads." if ingest else "Ready to plan."
        if defaults:
            headline += f" {len(defaults)} detail(s) fall back to defaults."
    else:
        verdict = "thin"
        headline = f"Plannable, but {len(defaults)} item(s) are left to defaults: {', '.join(c.label.lower() for c in defaults[:4])}."
    if duplicate is not None:
        headline += f" It may duplicate {duplicate.fqn}."
    return IntentReview(score=score, verdict=verdict, headline=headline, checks=checks)
