"""Entity-relationship diagrams of a modelled layer: its tables, their keys, and how they reference each other.

Built only from what the hub already holds: a model plan's tables (an intent's spec) or the design documents under
the data folder (DDL, the data model, the mapping). Each foreign key is one relationship, so a fact that references
the same dimension twice (an insured party and a producer) shows both. A table that is referenced but not in the
model is drawn as external, so a missing dimension shows instead of silently dropping the line.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from sqlglot import exp

from ech_core.schemas.er import ErColumn, ErDiagram, ErEntity, ErRelationship
from ech_core.schemas.intents import ModelTable
from query_service.intents import mapping

_KINDS = {"dimension", "fact", "bridge", "reference", "aggregate"}
_PREFIXES = (("DIM_", "dimension"), ("FACT_", "fact"), ("FCT_", "fact"), ("BRIDGE_", "bridge"), ("BRG_", "bridge"), ("REF_", "reference"), ("AGG_", "aggregate"))


@dataclass
class _Table:
    name: str
    schema: str = ""
    kind: str = ""
    description: str = ""
    grain: str = ""
    concept: str = ""
    columns: list[tuple[str, str, bool, str]] = field(default_factory=list)  # name, type, nullable, description
    pk: list[str] = field(default_factory=list)
    fks: list[tuple[list[str], str, list[str]]] = field(default_factory=list)  # columns, to table, to columns
    rows: int | None = None
    findings: list[str] = field(default_factory=list)


def _kind(name: str, declared: str) -> str:
    if declared.lower() in _KINDS:
        return declared.lower()
    return next((k for prefix, k in _PREFIXES if name.upper().startswith(prefix)), "table")


def _comments(table: mapping.DdlTable) -> tuple[str, dict[str, str]]:
    """The table's own COMMENT and its columns' COMMENTs, from the DDL."""
    own, columns = "", {}
    for stmt in table.statements:
        if not isinstance(stmt, exp.Comment) or stmt.expression is None:
            continue
        text = stmt.expression.name
        if str(stmt.args.get("kind") or "").upper() == "COLUMN":
            columns[stmt.this.sql(dialect=mapping.DIALECT).rsplit(".", 1)[-1].upper()] = text
        else:
            own = text
    return own, columns


def from_design(design: mapping.Design, *, origin: str, files: list[str]) -> ErDiagram:
    """The layer a folder's design documents declare: the DDL's tables and keys, described by the data model."""
    schemas = {m.target: m.schema for m in design.mapping}
    names = list(dict.fromkeys([*design.ddl, *design.models, *(m.target for m in design.mapping)]))
    tables: list[_Table] = []
    for name in names:
        ddl, model = design.ddl.get(name), design.models.get(name)
        own, commented = _comments(ddl) if ddl else ("", {})
        described = {c.name: c.description for c in (model.columns if model else [])}
        if ddl and ddl.columns:
            columns = [(c.name, c.type, c.nullable, described.get(c.name) or commented.get(c.name, "")) for c in ddl.columns]
        elif model:
            columns = [(c.name, c.type, c.nullable, c.description) for c in model.columns]
        else:  # only the mapping names it: its target columns, types unknown
            target = next(m for m in design.mapping if m.target == name)
            columns = [(t.column.upper(), "", True, "") for t in target.transforms]
        keys = {(fk.column, fk.table, fk.to_column) for fk in [*(ddl.foreign_keys if ddl else []), *(model.foreign_keys if model else [])]}
        tables.append(
            _Table(
                name=name,
                schema=(ddl.schema if ddl and ddl.schema else schemas.get(name, "")).upper(),
                kind=_kind(name, model.kind if model else ""),
                description=(model.description if model else "") or own,
                grain=model.grain if model else "",
                concept=model.concept if model else "",
                columns=columns,
                pk=(ddl.primary_key if ddl and ddl.primary_key else model.primary_key if model else []),
                fks=[([c], t, [to]) for c, t, to in sorted(keys)],
            )
        )
    problems = [p for p in design.problems if not p.startswith("no source-to-target mapping")]  # a diagram needs no mapping
    return _diagram(tables, key=f"design:{origin}", title=f"Design documents · {origin}", source="design", origin=origin, files=files, problems=problems)


def from_models(models: list[ModelTable], *, key: str, title: str, origin: str) -> ErDiagram:
    """The layer a model plan proposes or compiled, with what its dry run found."""
    tables = [
        _Table(
            name=mapping.short(m.name),
            kind=_kind(mapping.short(m.name), m.kind),
            description=m.description,
            grain=m.grain,
            columns=[(c.name.upper(), c.type, c.nullable, c.description) for c in m.columns],
            pk=[k.upper() for k in m.keys],
            fks=[([c.upper() for c in r.columns], mapping.short(r.to_table), [c.upper() for c in r.to_columns]) for r in m.relationships],
            rows=m.rows,
            findings=list(m.findings),
        )
        for m in models
    ]
    return _diagram(tables, key=key, title=title, source="plan", origin=origin, files=[], problems=[])


def _diagram(tables: list[_Table], *, key: str, title: str, source: str, origin: str, files: list[str], problems: list[str]) -> ErDiagram:
    known = {t.name.upper() for t in tables}
    references: dict[tuple[str, str], str] = {}
    relationships: list[ErRelationship] = []
    external: dict[str, set[str]] = {}
    for t in tables:
        nullable = {c[0]: c[2] for c in t.columns}
        for cols, to, to_cols in t.fks:
            to = to.upper()
            for a, b in zip(cols, to_cols, strict=False):
                references[(t.name.upper(), a)] = f"{to}.{b}"
            if to not in known:
                external.setdefault(to, set()).update(to_cols)
            one_to_one = bool(t.pk) and set(cols) == {k.upper() for k in t.pk}
            relationships.append(
                ErRelationship(
                    from_table=t.name.upper(),
                    from_columns=cols,
                    to_table=to,
                    to_columns=to_cols,
                    cardinality="one_to_one" if one_to_one else "many_to_one",
                    required=all(c in nullable and not nullable[c] for c in cols),
                )
            )
    entities = [
        ErEntity(
            name=t.name.upper(),
            schema_name=t.schema,
            kind=t.kind,  # type: ignore[arg-type]
            description=t.description,
            grain=t.grain,
            concept=t.concept,
            columns=[
                ErColumn(name=n, type=typ, pk=n in {k.upper() for k in t.pk}, fk=references.get((t.name.upper(), n)), nullable=null, description=d)
                for n, typ, null, d in t.columns
            ],
            rows=t.rows,
            findings=t.findings,
        )
        for t in tables
    ]
    entities += [
        ErEntity(name=name, kind="external", description="Referenced, but not part of this model.", columns=[ErColumn(name=c, pk=True) for c in sorted(cols)])
        for name, cols in sorted(external.items())
    ]
    return ErDiagram(
        key=key,
        title=title,
        source=source,  # type: ignore[arg-type]
        origin=origin,
        files=files,
        entities=entities,
        relationships=relationships,
        problems=problems,
        mermaid=mermaid(entities, relationships),
    )


def _mermaid_type(text: str) -> str:
    # Mermaid attribute types are one word: NUMBER(38,0) is drawn as NUMBER.
    return re.sub(r"[^A-Za-z0-9_]", "", text.split("(", 1)[0]) or "UNKNOWN"


def mermaid(entities: list[ErEntity], relationships: list[ErRelationship]) -> str:
    """The diagram as Mermaid ``erDiagram`` text, to paste into a document or a pull request."""
    lines = ["erDiagram"]
    for e in entities:
        if not e.columns:
            lines.append(f"    {e.name}")
            continue
        lines.append(f"    {e.name} {{")
        for c in e.columns:
            marks = ", ".join(m for m, on in (("PK", c.pk), ("FK", bool(c.fk))) if on)
            lines.append(f"        {_mermaid_type(c.type)} {c.name}{' ' + marks if marks else ''}")
        lines.append("    }")
    for r in relationships:
        parent = "||" if r.required else "|o"
        child = "o|" if r.cardinality == "one_to_one" else "o{"
        lines.append(f'    {r.to_table} {parent}--{child} {r.from_table} : "{", ".join(r.from_columns)}"')
    return "\n".join(lines) + "\n"
