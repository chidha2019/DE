"""The planner: a structured intent becomes a pipeline spec grounded in the hub.

For a CSV → Snowflake-managed Iceberg ingestion it samples the files, infers Snowflake types, names the
columns with glossary terms, finds related datasets in the semantic layer, and lays out stage, table,
load, tests and schedule. The spec is what a person reviews; the coder implements it verbatim.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any
from urllib.parse import quote

from ech_core.logging import get_logger
from ech_core.repositories.glossary_repository import GlossaryRepository
from ech_core.repositories.repo_graph_repository import RepoGraphRepository
from ech_core.repositories.semantic_repository import SemanticRepository
from ech_core.schemas.intents import (
    IntentSource,
    IntentValidation,
    PipelineSpec,
    SpecColumn,
    SpecDownstream,
    SpecMatch,
    SpecTable,
    SpecTest,
    StructuredIntent,
)
from query_service.intents.catalog import CatalogGrounding, ground_in_catalog
from query_service.intents.csvsample import (
    CsvSample,
    repeated_keys,
    sample_folder,
    snowflake_identifier,
)
from query_service.intents.exemplar import (
    CopiedChecks,
    adopt_contract,
    column_map,
    downstream_models,
    join_words,
    norm,
    precheck,
    precheck_queries,
    short_name,
    translate_checks,
)
from query_service.intents.landing import covers, landing_of
from query_service.intents.mapping import Design, read_design, resolve_files
from query_service.intents.tableset import (
    SNOWFLAKE_ENCODING,
    TableSource,
    find_files,
    is_table_set,
    match_sources,
    own_identifier,
    pattern_name,
    set_encoding,
)
from query_service.intents.validate import Expectation
from query_service.services.glossary_service import TermIndex

log = get_logger(__name__)
TABLE_SET_ROWS = 20_000  # rows read per file of a table set, so checks across files see whole tables
_KEY_SUFFIX = re.compile(r"(_ID|_NUMBER|_NO|_KEY|_CODE)$")
_CRON = {"hourly": "0 * * * *", "daily": "0 2 * * *", "weekly": "0 3 * * 1", "monthly": "0 4 1 * *"}
_LOAD_NOTE = {
    "append": "Append-only load; files already loaded are skipped by Snowflake's load history",
    "full_refresh": "Table truncated before each load",
    "merge": (
        "Loaded into a transient staging table, then MERGE on the key; a key that arrives more than once keeps "
        "the row from the most recently modified file (then the later file name, then the later row)"
    ),
}


def slugify(text: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_")
    return slug[:60] or "pipeline"


def cron_for(freshness: str) -> str:
    key = (freshness or "daily").lower()
    for name, cron in _CRON.items():
        if name in key:
            return cron
    return "manual" if "demand" in key or "once" in key else "0 2 * * *"


class Planner:
    def __init__(
        self,
        *,
        semantic: SemanticRepository | None,
        glossary: GlossaryRepository | None,
        data_dir: Path,
        repo_graph: RepoGraphRepository | None = None,
    ) -> None:
        self._semantic = semantic
        self._glossary = glossary
        self._data_dir = data_dir
        self._repo_graph = repo_graph

    # ------------------------------------------------------------------ public
    async def plan(self, intent: StructuredIntent, title: str, validation: IntentValidation | None = None) -> PipelineSpec:
        if intent.kind == "ingest_csv_to_iceberg":
            repos = await self._conventions()
            folder, sources = self.table_sources(intent, repos)
            if folder is not None and sources:
                return await self._plan_table_set(intent, title, sources, repos, validation)
            return await self._plan_csv_iceberg(intent, title, validation)
        return await self._plan_generic(intent, title)

    async def _conventions(self) -> list[dict[str, Any]]:
        if self._repo_graph is None:
            return []
        try:
            return await self._repo_graph.conventions()
        except Exception as exc:  # noqa: BLE001 - the repo graph is optional context
            log.warning("intent.plan.repo_graph_failed", error=str(exc))
            return []

    def table_sources(self, intent: StructuredIntent, repos: list[dict[str, Any]]) -> tuple[Path | None, list[TableSource]]:
        """The folder's files as a table set (one table per file), or no sources when they are one table."""
        folder = self.resolve_folder(intent.source.folder)
        if folder is None:
            return None, []
        files = find_files(folder)
        sources = match_sources(files, repos) if is_table_set(files) else []
        if intent.target.table_pattern:
            # The ticket's naming wins over the repository's: <FILE>_ICEBERG names every table of the set.
            for src in sources:
                src.table = pattern_name(intent.target.table_pattern, Path(src.file.rel).stem)
        return folder, sources

    async def expectations(self, intent: StructuredIntent) -> Expectation:
        """What the intent will read and write, for validation to look up in Snowflake."""
        repos = await self._conventions()
        t = intent.target
        if intent.kind in ("model_layer", "gold_fact"):
            layer = intent.layer or ("gold" if intent.kind == "gold_fact" else "silver")
            upstream = {"silver": "bronze", "gold": "silver"}.get(layer, "bronze")
            source_schema = (intent.source.schema_name or upstream).upper()
            design = self.design(intent)
            if design is not None:
                # The design names the tables it builds; the layer below is taken as Snowflake holds it.
                database = t.database or intent.source.database
                native = all(m.target in design.ddl for m in design.mapping)
                return Expectation(
                    target_database=database,
                    target_schema=(t.schema_name or next((m.schema for m in design.mapping if m.schema), "") or layer).upper(),
                    target_tables=[m.target for m in design.mapping],
                    source_database=intent.source.database or database,
                    source_schema=source_schema,
                    external_volume=None if native else t.external_volume,
                    identifiers_known=True,
                    designed=True,
                    design_names=sorted({m.target for m in design.mapping} | {t.column for m in design.mapping for t in m.transforms}),
                )
            repo = max(repos, key=lambda r: sum(1 for x in r["tables"] if x.get("layer") == upstream), default=None)

            def names(layer_name: str, schema: str) -> list[str]:
                tables = repo["tables"] if repo else []
                return sorted({str(x["name"]).rsplit(".", 1)[-1] for x in tables if x.get("layer") == layer_name and str(x["name"]).upper().startswith(f"{schema}.")})

            database = t.database or intent.source.database
            target_schema = (t.schema_name or layer).upper()
            return Expectation(
                target_database=database,
                target_schema=target_schema,
                target_tables=names(layer, target_schema),
                source_database=intent.source.database or database,
                source_schema=source_schema,
                source_tables=names(upstream, source_schema),
                external_volume=t.external_volume or (repo["volumes"][0]["name"] if repo and repo["volumes"] else None),
            )
        if intent.kind == "ingest_csv_to_iceberg":
            _, sources = self.table_sources(intent, repos)
            repo = next((r for r in repos if any(s.repo == r["repo"] for s in sources)), repos[0] if len(repos) == 1 else None)
            layers = {str(x.get("layer") or "") for x in repo["tables"]} if repo else set()
            schema = t.schema_name or ("BRONZE" if "bronze" in layers else None)
            if sources:
                targets = [s.table for s in sources]
            else:
                targets = [t.table.upper()] if t.table and re.fullmatch(r"[A-Za-z_][\w$]*", t.table) else []
            volume = t.external_volume or next((s.volume for s in sources if s.volume), None) or (repo["volumes"][0]["name"] if repo and repo["volumes"] else None)
            return Expectation(
                target_database=t.database,
                target_schema=schema,
                target_tables=targets,
                external_volume=volume if t.table_format == "iceberg" else None,
                # An existing stage already reads the landing folder through its own integration: nothing to look up.
                integration=None
                if intent.source.stage
                else intent.source.storage_integration
                or (next((s.get("integration") for s in repo["stages"] if s.get("integration")), None) if repo else None),
                identifiers_known=bool(sources) and (all(s.repo for s in sources) or all(own_identifier(s.file) for s in sources)),
                files_read=bool(sources) or bool(self.resolve_folder(intent.source.folder)),
                stage=intent.source.stage,
            )
        return Expectation(target_database=t.database, target_schema=t.schema_name, target_tables=[t.table.upper()] if t.table else [])

    def design(self, intent: StructuredIntent) -> Design | None:
        """The design documents (mapping, data model, DDL) a modelled-layer ticket points at, when they hold a mapping."""
        if not intent.source.mapping_files:
            return None
        files = resolve_files(self._data_dir, intent.source.mapping_files)
        design = read_design(files, self._data_dir) if files else None
        return design if design is not None and design.mapping else None

    def resolve_folder(self, folder: str | None) -> Path | None:
        """A folder named in the ticket, confined to the data directory.

        A path from the reporter's machine (``massmutual_local_csv_files/local_csv_files``) resolves to the
        longest tail of it that exists under the data directory (``local_csv_files``).
        """
        if not folder:
            return None
        raw = folder.replace("\\", "/").strip().strip("/")
        for prefix in ("./", "data/", "/app/data/"):
            if raw.startswith(prefix):
                raw = raw[len(prefix) :]
        root = self._data_dir.resolve()
        parts = [p for p in raw.split("/") if p and p not in (".", "..") and ":" not in p]
        for start in range(len(parts)):
            candidate = (root / "/".join(parts[start:])).resolve()
            if (root == candidate or root in candidate.parents) and candidate.is_dir():
                return candidate
        return None

    # ------------------------------------------------------------------ CSV → Iceberg
    async def _plan_csv_iceberg(self, intent: StructuredIntent, title: str, validation: IntentValidation | None = None) -> PipelineSpec:
        target = intent.target
        table = (target.table or slugify(title)).upper()
        name = f"ingest_{table.lower()}"
        assumptions: list[str] = []
        risks: list[str] = []
        folder = self.resolve_folder(intent.source.folder)
        sample: CsvSample | None = None
        if folder is not None:
            sample = sample_folder(
                folder, pattern=intent.source.file_pattern or "*.csv", delimiter=None if intent.source.delimiter == "," else intent.source.delimiter
            )
            if not sample.files:
                risks.append(f"No files matching {intent.source.file_pattern} in {intent.source.folder}; the schema below comes from the ticket only.")
            risks.extend(sample.problems[:5])
        elif intent.source.folder:
            risks.append(f"Folder '{intent.source.folder}' is not under the data directory or does not exist; the schema below comes from the ticket only.")
        index = TermIndex(await self._glossary.catalog()) if self._glossary else None
        columns = self._columns(sample, intent, index)
        if not columns:
            risks.append("No columns could be determined: name the columns in the ticket or point at the CSV folder.")
        repo_ctx = await self._repo_context(intent, table, columns)
        if repo_ctx["external_volume"]:
            target = target.model_copy(update={"external_volume": repo_ctx["external_volume"]})
        if repo_ctx["schema"]:
            target = target.model_copy(update={"schema_name": repo_ctx["schema"]})
        assumptions += repo_ctx["assumptions"]
        risks += repo_ctx["risks"]
        # The catalog table the feed resembles: its types are applied to the columns before any check is built on them.
        target_fqn = f"{target.database}.{target.schema_name}.{table}" if target.database and target.schema_name else None
        grounding = await ground_in_catalog(self._semantic, target_fqn=target_fqn, table=table, business_terms=intent.business_terms, columns=columns)
        assumptions += grounding.assumptions
        risks += grounding.risks
        copied: CopiedChecks | None = None
        downstream: list[SpecDownstream] = []
        exemplar = await self._exemplar(repo_ctx["exemplar"])
        if exemplar is not None:
            colmap = column_map(exemplar["columns"], columns)
            contract_assumptions, contract_risks = adopt_contract(exemplar, columns, colmap)
            assumptions += contract_assumptions
            risks += contract_risks
            copied = translate_checks(exemplar["checks"], str(exemplar["table"]["name"]), colmap, {c.name: c.type for c in columns})
            downstream, downstream_risks = downstream_models(exemplar, colmap, f"{(target.schema_name or 'BRONZE').upper()}.{table}")
            risks += downstream_risks
        keys = [c.name for c in columns if _KEY_SUFFIX.search(c.name)]
        exemplar_key = copied.unique if copied else None
        if exemplar_key is not None:
            keys = [*exemplar_key.columns, *(k for k in keys if k not in exemplar_key.columns)]
        elif grounding.key:
            keys = [*grounding.key, *(k for k in keys if k not in grounding.key)]
        if target.merge_keys and columns:
            named = {norm(c.name): c.name for c in columns}
            fixed = [named.get(norm(k), k) for k in target.merge_keys]
            unknown = [k for k in fixed if k not in named.values()]
            if unknown:
                risks.append(f"Merge key {join_words(unknown)} is not a column of the feed.")
            target = target.model_copy(update={"merge_keys": fixed})
        if target.load_mode == "merge" and not target.merge_keys:
            if exemplar_key is not None:
                target = target.model_copy(update={"merge_keys": exemplar_key.columns})
                assumptions.append(f"Merge key {join_words(exemplar_key.columns)}, the key {exemplar_key.origin} checks.")
            elif grounding.key and grounding.match is not None:
                target = target.model_copy(update={"merge_keys": grounding.key})
                assumptions.append(f"Merge key {join_words(grounding.key)}, the primary key {grounding.match.fqn} declares.")
            else:
                target = target.model_copy(update={"merge_keys": keys[:1]})
                if keys:
                    assumptions.append(f"Merge key assumed to be {keys[0]} (first identifier-like column).")
                else:
                    risks.append("Merge load needs a key column; none looks like an identifier.")
        if target.load_mode == "merge" and target.merge_keys and sample is not None:
            repeats = repeated_keys(sample, target.merge_keys)
            if repeats:
                value, files = next(iter(repeats.items()))
                where = ", ".join(dict.fromkeys(files))
                more = f" ({len(repeats) - 1} more key{'s' if len(repeats) > 2 else ''} repeat too)" if len(repeats) > 1 else ""
                assumptions.append(
                    f"{join_words(target.merge_keys)} {', '.join(str(v) for v in value)} appears on {len(files)} sampled rows ({where}){more}; "
                    "the merge keeps one row per key, the one from the most recently modified file."
                )
        if not target.external_volume:
            risks.append("No external volume named: the table DDL carries a placeholder (ECH_EXTERNAL_VOLUME) that must be set before apply.")
        source = default_prefix(intent.source, name, assumptions)
        found, flagged = landing_findings(source, validation)
        assumptions += found
        risks += flagged
        if sample and sample.delimiter != ",":
            assumptions.append(f"Delimiter detected as '{sample.delimiter}'.")
        base_location = target.base_location or f"{(target.schema_name or 'bronze').lower()}/{table.lower()}"
        tests = self._tests(columns, keys, intent, copied, grounding)
        records = sample.records if sample else []
        precheck(tests, columns, records)
        for test in tests:
            if test.sample_failures:
                origin = f" (copied from {test.origin})" if test.origin else ""
                examples = f": {'; '.join(test.sample_examples)}" if test.sample_examples else ""
                risks.append(
                    f"{test.name}{origin} fails on {test.sample_failures} of {len(records)} sampled rows{examples}. "
                    "Fix the data or adjust the check before approving."
                )
        return PipelineSpec(
            name=name,
            kind="ingest_csv_to_iceberg",
            summary=intent.summary or title,
            source=source,
            target=target.model_copy(update={"table": table, "base_location": base_location}),
            columns=columns,
            sampled_files=sample.files if sample else [],
            sampled_rows=sample.rows if sample else 0,
            stage_name=f"{table}_STAGE",
            file_format_name=f"{table}_CSV_FORMAT",
            transformations=[
                "Headers normalised to UPPER_SNAKE_CASE identifiers",
                "Values cast to the inferred Snowflake types; empty strings load as NULL",
                "Load metadata added: _SOURCE_FILE (METADATA$FILENAME) and _LOADED_AT (CURRENT_TIMESTAMP)",
                _LOAD_NOTE[target.load_mode],
            ],
            tests=tests,
            schedule=cron_for(intent.freshness),
            matches=[*repo_ctx["matches"], *await self._matches(intent, table)],
            risks=risks,
            assumptions=assumptions,
            exemplar_checks=copied.accounting if copied else [],
            downstream=downstream,
            catalog_match=grounding.match,
            joins=grounding.joins,
        )

    # ------------------------------------------------------------------ a table set: one table per file
    async def _plan_table_set(
        self, intent: StructuredIntent, title: str, sources: list[TableSource], repos: list[dict[str, Any]], validation: IntentValidation | None
    ) -> PipelineSpec:
        """Every file its own table, named, typed, keyed and checked as the repository contract for it says."""
        t = intent.target
        schema = (t.schema_name or "BRONZE").upper()
        database = t.database.upper() if t.database else None

        def fqn(name: str) -> str:
            return ".".join(p for p in (database, schema, name) if p)

        index = TermIndex(await self._glossary.catalog()) if self._glossary else None
        assumptions: list[str] = []
        risks: list[str] = []
        delimiter = None if intent.source.delimiter == "," else intent.source.delimiter
        encoding, unreadable = set_encoding([s.file for s in sources])
        built: list[tuple[TableSource, CsvSample, list[SpecColumn], dict[str, Any] | None, dict[str, str]]] = []
        partial: list[str] = []
        relaxed = 0
        for src in sources:
            read_as = "utf-8-sig" if src.file.encoding in ("ascii", "utf-8") else src.file.encoding
            sample = sample_folder(
                src.file.path.parent, pattern=src.file.path.name, max_files=1, max_rows=TABLE_SET_ROWS, delimiter=delimiter, encoding=read_as, keep=TABLE_SET_ROWS
            )
            risks += [f"{src.table}: {p}" for p in sample.problems[:2]]
            columns = self._columns(sample, intent, index)
            exemplar = await self._exemplar({"repo": src.repo, "table": src.qualified}) if src.repo and src.qualified else None
            colmap: dict[str, str] = {}
            if exemplar is not None:
                colmap = column_map(exemplar["columns"], columns)
                contract = {str(ec.get("column") or short_name(str(ec.get("name") or ""))).upper(): ec for ec in exemplar["columns"]}
                by_name = {c.name: c for c in columns}
                for name, feed in colmap.items():
                    declared = str(contract[name].get("type") or "").upper()
                    if declared:
                        by_name[feed].type = "VARCHAR" if declared in ("STRING", "TEXT") else declared
                found, blank = adopt_contract(exemplar, columns, colmap)
                relaxed += 1 if found else 0
                risks += blank
            built.append((src, sample, columns, exemplar, colmap))

        siblings = {str(src.qualified).upper(): (fqn(src.table), colmap) for src, _, _, exemplar, colmap in built if exemplar is not None}
        tables: list[SpecTable] = []
        downstream: dict[str, SpecDownstream] = {}
        sampled: dict[str, tuple[list[SpecColumn], list[dict[str, str | None]]]] = {}
        unkeyed: list[str] = []
        own_keyed: list[str] = []
        incompatible: list[str] = []
        no_load_columns: list[str] = []
        holding: list[str] = []
        for src, sample, columns, exemplar, colmap in built:
            copied: CopiedChecks | None = None
            keys: list[str] = []
            missing: list[str] = []
            if exemplar is not None:
                own = str(src.qualified).upper()
                copied = translate_checks(
                    exemplar["checks"],
                    own,
                    colmap,
                    {c.name: c.type for c in columns},
                    target=fqn(src.table),
                    siblings={k: v for k, v in siblings.items() if k != own},
                )
                declared = [str(k).upper() for k in exemplar["table"].get("key") or []]
                if declared and all(k in colmap for k in declared):
                    keys = [colmap[k] for k in declared]
                contract_names = [str(ec.get("column") or short_name(str(ec.get("name") or ""))).upper() for ec in exemplar["columns"]]
                missing = [n for n in contract_names if n not in colmap]
                for model in downstream_models(exemplar, colmap, fqn(src.table))[0]:
                    seen = downstream.get(model.table)
                    if seen is None:
                        downstream[model.table] = model.model_copy(update={"columns": [], "reads": sorted(set(model.reads))})
                    else:
                        seen.reads = sorted({*seen.reads, *model.reads})
            if not keys and copied is not None and copied.unique is not None:
                keys = list(copied.unique.columns)
            own = own_identifier(src.file)
            if not keys and own:
                keys = [c.name for c in columns if c.source_header == own][:1]
                if keys:
                    own_keyed.append(f"{keys[0]} in {Path(src.file.rel).name}")
            if not keys:
                keys = [c.name for c in columns if _KEY_SUFFIX.search(c.name)][:1]
                unkeyed.append(src.table)
            found = validation.find("table", fqn(src.table)) if validation is not None and validation.reachable else None
            if found is not None and found.exists and found.columns:
                # Load into the table as it is: the file's columns take the existing names (HOUSE_NR_ID → HOUSENR_ID).
                existing = {_norm(c): c.upper() for c in found.columns}
                renames = {c.name: existing[_norm(c.name)] for c in columns if _norm(c.name) in existing and existing[_norm(c.name)] != c.name}
                for column in columns:
                    column.name = renames.get(column.name, column.name)
                for record in sample.records:  # the pre-load checks read the sampled rows by column name
                    for old, new in renames.items():
                        if old in record:
                            record[new] = record.pop(old)
                keys = [renames.get(k, k) for k in keys]
                unmatched_cols = [c.name for c in columns if _norm(c.name) not in existing]
                if unmatched_cols:
                    incompatible.append(f"{src.table} (no column for {', '.join(unmatched_cols[:4])})")
                elif not {"_SOURCE_FILE", "_LOADED_AT"} <= {c.upper() for c in found.columns}:
                    no_load_columns.append(src.table)
                if found.rows:
                    holding.append(f"{src.table} {found.rows}")
            tests = self._tests(columns, keys, intent, copied)
            precheck(tests, columns, sample.records)
            if len(sample.records) >= src.file.rows:
                sampled[fqn(src.table)] = (columns, sample.records)
            else:
                # A check across tables needs every row of every table it reads, or a missing parent looks like an orphan.
                partial.append(src.table)
            tables.append(
                SpecTable(
                    name=src.table,
                    source_file=src.file.rel,
                    source_system=src.file.system,
                    columns=columns,
                    keys=keys,
                    tests=tests,
                    rows=src.file.rows or sample.rows,
                    base_location=f"{schema.lower()}/{src.table.lower()}",
                    exemplar=src.qualified,
                    exemplar_checks=copied.accounting if copied else [],
                    missing_columns=missing,
                    extra_columns=[c.name for c in columns if exemplar is not None and c.name not in colmap.values()],
                    exists=bool(found and found.exists),
                )
            )
        precheck_queries([x for table in tables for x in table.tests], sampled)

        matched = [s for s in sources if s.repo]
        repo_names = sorted({str(s.repo) for s in matched})
        keyed = [x for x in tables if x.name not in unkeyed]
        if matched:
            examples = "; ".join(f"{x.name}: {', '.join(x.keys)}" for x in keyed[:2])
            assumptions.append(
                f"{len(matched)} of {len(sources)} files match the sources of {join_words(repo_names)} by "
                f"{'path' if all(s.matched_by == 'path' for s in matched) else 'path or headers'}; each table takes its name, column types, identifier and checks from that contract."
            )
            if keyed:
                assumptions.append(f"Identifiers come from the contracts for {len(keyed)} of {len(tables)} tables (e.g. {examples}).")
            assumptions.append(
                "Columns are typed as the contracts declare them (STRING loads as VARCHAR): the bronze tables keep the values as delivered, "
                "and the copied format checks report a bad value instead of stopping the load."
            )
        if relaxed:
            assumptions.append(f"In {relaxed} table(s), columns the contract leaves optional stay nullable even where the sample had no blanks.")
        if own_keyed:
            assumptions.append(
                f"Each table's identifier is the file's own id column ({join_words(own_keyed[:3])}{'…' if len(own_keyed) > 3 else ''}); "
                "the checks hold it unique and never null."
            )
        if unkeyed:
            risks.append(f"No contract key for {join_words(unkeyed)}; the plan assumes the first identifier-like column.")
        if incompatible:
            risks.append(f"{len(incompatible)} existing table(s) have other columns than their files: {'; '.join(incompatible[:4])}. The load would fail on them.")
        if no_load_columns:
            risks.append(
                f"{len(no_load_columns)} existing table(s) lack the load columns _SOURCE_FILE and _LOADED_AT, so the generated COPY cannot load them as they are "
                f"({join_words(no_load_columns[:4])}{'…' if len(no_load_columns) > 4 else ''}): drop them and run again, and the setup creates them with those columns."
            )
        if holding and t.load_mode == "append":
            risks.append(
                f"{len(holding)} target table(s) already hold rows ({join_words(holding[:3])}{'…' if len(holding) > 3 else ''}): an append load of files "
                "uploaded again adds their rows a second time. Empty or drop them first, or answer 'full refresh'."
            )
        unmatched = [s.table for s in sources if not s.repo]
        if unmatched:
            risks.append(f"{len(unmatched)} file(s) match no crawled source ({join_words(unmatched[:6])}): names come from the file names, types are inferred and only the basic checks apply.")
        lacking = [f"{x.name} ({', '.join(x.missing_columns)})" for x in tables if x.missing_columns]
        if lacking:
            risks.append(f"{len(lacking)} file(s) lack columns their contracts declare: {'; '.join(lacking)}. Checks on those columns are skipped.")
        extra = [f"{x.name} ({', '.join(x.extra_columns)})" for x in tables if x.extra_columns]
        if extra:
            assumptions.append(f"Columns the contracts do not declare are loaded as delivered: {'; '.join(extra)}.")
        failing = [(x, test) for x in tables for test in x.tests if test.sample_failures]
        for table, test in failing[:12]:
            origin = f" (copied from {test.origin})" if test.origin else ""
            examples = f": {'; '.join(test.sample_examples)}" if test.sample_examples else ""
            risks.append(f"{table.name}.{test.name}{origin} fails on {test.sample_failures} of {table.rows} rows in the file{examples}.")
        if len(failing) > 12:
            risks.append(f"{len(failing) - 12} more checks fail on the files; see each table's checks.")
        across = sum(1 for x in tables for test in x.tests if test.kind == "query")
        if across:
            assumptions.append(f"{across} check(s) across tables are copied (references between the files), since every table they read is loaded here too.")
        if partial:
            assumptions.append(
                f"{len(partial)} file(s) have more than {TABLE_SET_ROWS} rows ({join_words(partial[:5])}{'…' if len(partial) > 5 else ''}): their checks ran on the first "
                f"{TABLE_SET_ROWS} rows, and checks across tables that read them run after the load."
            )
        odd = [s.file.rel for s in sources if "utf-8" not in s.file.readable_as]
        if odd:
            assumptions.append(
                f"{len(odd)} file(s) are encoded {encoding.upper()} rather than UTF-8 ({join_words(odd[:6])}{'…' if len(odd) > 6 else ''}); "
                f"the file format reads them as {SNOWFLAKE_ENCODING.get(encoding, 'UTF8')}."
            )
        if unreadable:
            risks.append(f"Files in more than one encoding: {join_words(unreadable[:6])} would be misread as {encoding.upper()}; convert them to it before loading.")
        assumptions.append("ON_ERROR = ABORT_STATEMENT: each table gets every row of its file or its load stops, so row counts match the files.")

        volume = t.external_volume or next((s.volume for s in sources if s.volume), None)
        if volume and not t.external_volume:
            assumptions.append(f"External volume {volume}, where {join_words(repo_names)} stores these tables.")
        repo_volume = next((s.volume for s in sources if s.volume), None)
        if t.external_volume and repo_volume and t.external_volume.upper() != repo_volume.upper():
            assumptions.append(f"External volume {t.external_volume} as the ticket says, instead of {repo_volume}, which {join_words(repo_names)} uses.")
        integration = intent.source.storage_integration
        repo_integration = next((s.get("integration") for r in repos if r["repo"] in repo_names for s in r["stages"] if s.get("integration")), None)
        stage_name = f"{schema}_LANDING_STAGE"
        named_stage = validation.find("stage", intent.source.stage) if intent.source.stage and validation is not None and validation.reachable else None
        keep_stage = bool(intent.source.stage) and not (named_stage is not None and not named_stage.exists)
        if intent.source.stage and not keep_stage:
            risks.append(
                f"The ticket's stage {intent.source.stage.upper()} is not in Snowflake ({(named_stage.detail if named_stage else '') or 'not found'}); "
                f"the setup creates {stage_name} on the landing folder instead, through the storage integration STORAGE_INTEGRATION names at run time."
            )
        elif keep_stage:
            stage_name = str(intent.source.stage).upper()
            where = f" ({named_stage.detail})" if named_stage is not None and named_stage.detail else ""
            assumptions.append(
                f"Loads through the existing stage {stage_name}{where}, which already reads the landing folder through its storage integration; "
                "the setup creates no stage, and the hub's role needs no USAGE on the integration."
            )
        if intent.source.file_format:
            assumptions.append(
                f"The ticket's file format {intent.source.file_format.upper()} is left as it is: the load uses its own {schema}_CSV_FORMAT "
                f"({SNOWFLAKE_ENCODING.get(encoding, 'UTF8')}, header row skipped), because its COPY reads the columns by position."
            )
        if not keep_stage and integration and repo_integration and integration.upper() != repo_integration.upper():
            assumptions.append(f"Storage integration {integration} as the ticket says, instead of {repo_integration}, which {join_words(repo_names)} lands files through.")
        elif not keep_stage and not integration and repo_integration:
            assumptions.append(f"No storage integration named: set STORAGE_INTEGRATION at deploy time ({join_words(repo_names)} uses {repo_integration}).")
        create: list[str] = []
        if validation is not None and validation.reachable:
            db = validation.find("database", database or "")
            sch = validation.find("schema", fqn("").rstrip("."))
            if db is not None and not db.exists:
                create = ["database", "schema"]
                assumptions.append(f"Database {database} and schema {schema} do not exist yet; the setup creates them.")
            elif sch is not None and not sch.exists:
                create = ["schema"]
                assumptions.append(f"Schema {database}.{schema} does not exist yet; the setup creates it.")
            for obj in validation.objects:
                if obj.kind == "external_volume" and not obj.exists:
                    risks.append(
                        f"External volume {obj.name} is not visible to the hub's Snowflake role: it does not exist, or the role lacks USAGE on it. "
                        "Create it on the Iceberg bucket (with its IAM role) or grant USAGE before apply."
                    )
                elif obj.kind == "external_volume" and obj.exists:
                    assumptions.append(f"External volume {obj.name} exists in Snowflake (the read-only check found it).")
                if obj.kind == "integration" and not obj.exists:
                    risks.append(
                        f"Storage integration {obj.name} is not visible to the hub's Snowflake role: it does not exist, or the role lacks USAGE on it. "
                        "The landing stage reads S3 through it."
                    )
                elif obj.kind == "integration" and obj.exists:
                    state = " but is disabled" if obj.detail == "disabled" else ""
                    assumptions.append(f"Storage integration {obj.name} exists in Snowflake{state}; the landing stage reads S3 through it.")
            present = [x.name for x in tables if x.exists]
            if present:
                assumptions.append(f"{len(present)} table(s) already exist and are kept as they are (CREATE ... IF NOT EXISTS): {join_words(present[:6])}.")
        elif validation is not None:
            risks.append(f"Snowflake was not checked ({validation.error or 'not connected'}); the plan assumes none of the tables exist.")
        else:
            risks.append("Snowflake was not checked; the plan assumes none of the tables exist.")
        if downstream:
            assumptions.append(
                f"{len(downstream)} model(s) in {join_words(repo_names)} read these tables ({join_words(sorted(downstream)[:5])}{'…' if len(downstream) > 5 else ''}); "
                "the silver and gold intents build them once this load has run."
            )
        prefix = intent.source.s3_prefix
        if prefix and ("|" in prefix or " " in prefix.strip()):
            prefix = None
        name = f"ingest_{slugify('_'.join(p for p in (database, schema) if p))}"
        source = default_prefix(
            intent.source.model_copy(update={"file_pattern": "**/*.csv", "s3_prefix": prefix, "encoding": encoding, "stage": intent.source.stage if keep_stage else None}),
            name,
            assumptions,
        )
        found, flagged = landing_findings(source, validation)
        assumptions += found
        risks += flagged
        return PipelineSpec(
            name=name,
            kind="ingest_csv_to_iceberg",
            summary=intent.summary or title,
            source=source,
            target=t.model_copy(update={"database": database, "schema_name": schema, "table": None, "external_volume": volume, "base_location": schema.lower(), "merge_keys": []}),
            sampled_files=[x.source_file for x in tables],
            sampled_rows=sum(x.rows for x in tables),
            stage_name=stage_name,
            file_format_name=f"{schema}_CSV_FORMAT",
            transformations=[
                "One table per file; each table's COPY reads only its own file, by its path under the landing prefix",
                "Headers normalised to UPPER_SNAKE_CASE identifiers; empty strings load as NULL",
                "Load metadata added: _SOURCE_FILE (METADATA$FILENAME) and _LOADED_AT (CURRENT_TIMESTAMP)",
                _LOAD_NOTE[t.load_mode] if t.load_mode != "merge" else "Merged on each table's contract key",
            ],
            schedule=cron_for(intent.freshness),
            matches=[
                SpecMatch(
                    kind="exemplar",
                    name=repo,
                    detail=f"{sum(1 for s in matched if s.repo == repo)} of {len(sources)} files match its sources",
                    link=f"/knowledge?repo={quote(repo, safe='')}",
                )
                for repo in repo_names
            ],
            risks=risks,
            assumptions=assumptions,
            downstream=sorted(downstream.values(), key=lambda d: d.table),
            tables=tables,
            create=create,  # type: ignore[arg-type]
        )

    async def _exemplar(self, ref: dict[str, str] | None) -> dict[str, Any] | None:
        """The exemplar's checks, contract and readers; optional context, so a failure only loses them."""
        if ref is None or self._repo_graph is None:
            return None
        try:
            return await self._repo_graph.exemplar(ref["repo"], ref["table"])
        except Exception as exc:  # noqa: BLE001 - the repo graph is optional context
            log.warning("intent.plan.exemplar_failed", error=str(exc))
            return None

    def _columns(self, sample: CsvSample | None, intent: StructuredIntent, index: TermIndex | None) -> list[SpecColumn]:
        columns: list[SpecColumn] = []
        if sample and sample.columns:
            for col in sample.columns:
                columns.append(
                    SpecColumn(
                        name=col.name,
                        type=col.inferred_type(),
                        nullable=col.nullable or col.seen == 0,
                        source_header=col.header,
                        sample=(col.sample or "")[:40] or None,
                    )
                )
        else:
            for hint in intent.columns_hint:
                columns.append(SpecColumn(name=snowflake_identifier(hint), type="VARCHAR", nullable=True, source_header=hint))
        if index is not None:
            for column in columns:
                hit = index.match(column.name, column.source_header or "")
                if hit:
                    term, _, _ = hit
                    column.term_key = term["key"]
                    column.term_name = term["name"]
                    column.description = str(term.get("definition") or "")[:200]
        return columns

    def _tests(
        self, columns: list[SpecColumn], keys: list[str], intent: StructuredIntent, copied: CopiedChecks | None = None, grounding: CatalogGrounding | None = None
    ) -> list[SpecTest]:
        tests = [
            SpecTest(name="files_landed", kind="file_count", detail="at least one file matched the pattern in the landing prefix"),
            SpecTest(name="rows_loaded", kind="row_count", detail="the target holds at least one row after the load"),
        ]
        from_exemplar = set(copied.not_null) if copied else set()
        required = [c.name for c in columns if not c.nullable or c.name in from_exemplar]
        if required:
            origin = copied.not_null_origin if copied else None
            detail = f"{len(from_exemplar)} of them required by the exemplar" if from_exemplar else ""
            tests.append(SpecTest(name="required_columns_not_null", kind="not_null", columns=required, detail=detail, origin=origin))
        scope = "across the table (merge load)" if intent.target.load_mode == "merge" else "per source file"
        if copied and copied.unique:
            tests.append(copied.unique.model_copy(update={"detail": scope}))
        elif grounding is not None and grounding.key and grounding.match is not None:
            key = grounding.key
            tests.append(SpecTest(name=f"{'_'.join(k.lower() for k in key)}_unique", kind="unique", columns=key, detail=scope, origin=f"{grounding.match.fqn} primary key"))
        elif keys:
            tests.append(SpecTest(name=f"{keys[0].lower()}_unique", kind="unique", columns=[keys[0]], detail=scope))
        if copied:
            tests += copied.conditions
        tests.append(SpecTest(name="freshness", kind="freshness", detail=f"_LOADED_AT within the last {intent.freshness or 'daily'} window"))
        return tests

    async def _repo_context(self, intent: StructuredIntent, table: str, columns: list[SpecColumn]) -> dict[str, Any]:
        """What the crawled repositories say this pipeline should reuse, imitate or avoid duplicating."""
        out: dict[str, Any] = {"matches": [], "assumptions": [], "risks": [], "external_volume": None, "schema": None, "exemplar": None}
        if self._repo_graph is None:
            return out
        try:
            repos = await self._repo_graph.conventions()
        except Exception as exc:  # noqa: BLE001 - the repo graph is optional context
            log.warning("intent.plan.repo_graph_failed", error=str(exc))
            return out
        if not repos:
            return out
        wanted = {_norm(c.source_header or c.name) for c in columns} | {_norm(c.name) for c in columns}
        best: tuple[float, dict[str, Any], dict[str, Any], int, int] | None = None
        for repo in repos:
            for src in repo["sources"]:
                headers = {_norm(h) for h in src.get("headers") or []}
                overlap = len(headers & wanted)
                if not overlap:
                    continue
                score = overlap / len(headers | wanted)
                if best is None or score > best[0]:
                    best = (score, repo, src, overlap, len(headers))
        exemplar = best is not None and best[0] >= 0.2
        chosen = best[1] if best is not None and exemplar else (repos[0] if len(repos) == 1 else None)
        if best is not None and exemplar:
            score, repo, src, overlap, size = best
            out["exemplar"] = {"repo": repo["repo"], "table": str(src["table"])}
            key = quote(f"{repo['repo']}|table|{src['table']}", safe="")
            out["matches"].append(
                SpecMatch(
                    kind="exemplar",
                    name=str(src["table"]),
                    detail=f"{repo['repo']}: {overlap} of {size} CSV headers match {src.get('path') or src['source']}",
                    link=f"/knowledge?repo={quote(repo['repo'], safe='')}&node={key}",
                    score=round(score, 2),
                )
            )
        if chosen is None:
            return out
        name = chosen["repo"]
        if not intent.target.external_volume and chosen["volumes"]:
            volume = chosen["volumes"][0]["name"]
            out["external_volume"] = volume
            out["assumptions"].append(f"External volume {volume} reused from {name}, where its Iceberg tables are stored (repo graph).")
        if chosen["stages"] and not intent.source.storage_integration:
            stage = chosen["stages"][0]
            out["assumptions"].append(
                f"{name} lands CSV files through stage {stage['stage']} with storage integration {stage.get('integration') or 'unknown'}; "
                f"set STORAGE_INTEGRATION to {stage.get('integration') or 'that integration'} so this pipeline reads the same landing bucket."
            )
        layers = {str(t.get("layer") or "") for t in chosen["tables"]}
        if not intent.target.schema_name and "bronze" in layers:
            out["schema"] = "BRONZE"
            out["assumptions"].append(f"Target schema BRONZE follows {name}'s layer convention for raw CSV loads.")
        schema = (intent.target.schema_name or out["schema"] or "").upper()
        if schema and f"{schema}.{table}" in {str(t.get("name")) for t in chosen["tables"]}:
            out["risks"].append(f"{schema}.{table} already exists in {name}; extend that pipeline instead of adding a second loader.")
        return out

    async def _matches(self, intent: StructuredIntent, table: str) -> list[SpecMatch]:
        matches: list[SpecMatch] = []
        if self._semantic is None:
            return matches
        seen: set[str] = set()
        for query in [table.replace("_", " "), *intent.business_terms[:4]]:
            try:
                found = await self._semantic.search(query, limit=3)
            except Exception as exc:  # noqa: BLE001 - a search failure must not block the plan
                log.warning("intent.plan.search_failed", query=query, error=str(exc))
                continue
            for asset in _assets_of(found):
                fqn = str(asset.get("fqn") or asset.get("name") or "")
                if not fqn or fqn in seen:
                    continue
                seen.add(fqn)
                matches.append(
                    SpecMatch(
                        kind="dataset",
                        name=fqn,
                        detail=f"{asset.get('kind') or 'dataset'} · matched '{query}'",
                        link=f"/semantic/{asset.get('id')}" if asset.get("id") else None,
                    )
                )
        return matches[:8]

    # ------------------------------------------------------------------ other kinds
    async def _plan_generic(self, intent: StructuredIntent, title: str) -> PipelineSpec:
        return PipelineSpec(
            name=slugify(intent.target.table or title),
            kind=intent.kind,
            summary=intent.summary or title,
            source=intent.source,
            target=intent.target,
            matches=await self._matches(intent, intent.target.table or title),
            schedule=cron_for(intent.freshness),
            assumptions=["No template covers this kind: the reference agent implements the spec in the pipeline repository when ECH_INTENT_REPO is set."],
            risks=[] if intent.target.table else ["No target named."],
        )


def _assets_of(found: Any) -> list[dict[str, Any]]:
    if isinstance(found, dict):
        for key in ("assets", "items", "results"):
            if isinstance(found.get(key), list):
                return [a for a in found[key] if isinstance(a, dict)]
        return []
    return [a for a in found if isinstance(a, dict)] if isinstance(found, list) else []


# --------------------------------------------------------------------------- landing
def default_prefix(source: IntentSource, name: str, assumptions: list[str]) -> IntentSource:
    """An Azure container with no folder named gets one per pipeline, so two pipelines never read each other's files."""
    if source.storage_provider == "azure" and source.azure_container and not source.azure_prefix:
        assumptions.append(f"No folder in the container is named: the files land under {name}/ in {source.azure_container}.")
        return source.model_copy(update={"azure_prefix": name})
    return source


def landing_findings(source: IntentSource, validation: IntentValidation | None) -> tuple[list[str], list[str]]:
    """Where the files land, and what the read-only look at the storage integration and the volume says about it."""
    landing = landing_of(source)
    where = landing.url if landing.known else f"{landing.url} (the ${{...}} parts come from the pipeline environment)"
    tool = "the Azure SDK (a connection string or your Azure login)" if landing.provider == "azure" else "boto3"
    assumptions = [f"Files land in {landing.label} at {where}, uploaded with {tool}, keeping their folders."]
    risks: list[str] = []
    for obj in validation.objects if validation is not None and validation.reachable else []:
        provider = obj.properties.get("STORAGE_PROVIDER", "").upper()
        if obj.kind == "integration" and obj.exists and provider:
            wanted = "AZURE" if landing.provider == "azure" else "S3"
            if not provider.startswith(wanted):
                risks.append(f"Storage integration {obj.name} reads {provider}, but the files land in {landing.label}: name a storage integration for {landing.label}.")
            elif covers(obj.properties.get("STORAGE_ALLOWED_LOCATIONS", ""), landing.url) is False:
                risks.append(f"Storage integration {obj.name} may not read {landing.url}: its allowed locations are {obj.properties['STORAGE_ALLOWED_LOCATIONS']}.")
            if provider == "AZURE":
                app = obj.properties.get("AZURE_MULTI_TENANT_APP_NAME", "its Snowflake app")
                assumptions.append(
                    f"Snowflake reads the container through {obj.name}: an Azure admin opens its consent URL once (DESCRIBE INTEGRATION {obj.name}) "
                    f"and gives {app} the Storage Blob Data Reader role on the storage account."
                )
        if obj.kind == "external_volume" and obj.exists and obj.properties.get("STORAGE_BASE_URL"):
            assumptions.append(f"External volume {obj.name} keeps the table data at {obj.properties['STORAGE_BASE_URL']}.")
            if provider == "AZURE":
                app = obj.properties.get("AZURE_MULTI_TENANT_APP_NAME", "its Snowflake app")
                assumptions.append(
                    f"The volume writes through {app}: after its consent URL (DESCRIBE EXTERNAL VOLUME {obj.name}) it needs the Storage Blob Data Contributor role."
                )
    return assumptions, risks


# --------------------------------------------------------------------------- markdown for Jira / UI
def _norm(text: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", text.upper())


def render_spec_markdown(spec: PipelineSpec, validation: IntentValidation | None = None) -> str:
    t, src = spec.target, spec.source
    lines = [f"Pipeline spec: {spec.name}", "", spec.summary]
    if validation is not None:
        lines += ["", f"Snowflake (read-only check): {validation.summary}"]
    if spec.models:
        return "\n".join([*lines, *_models_markdown(spec)])
    where = src.folder or (f"s3://{src.s3_bucket}/{src.s3_prefix or ''}" if src.s3_bucket else "(not named)")
    lines += ["", "Source"]
    lines.append(f"- files: {where} matching {src.file_pattern}, delimiter '{src.delimiter}', header {'yes' if src.header else 'no'}")
    if spec.sampled_files:
        shown = ", ".join(spec.sampled_files[:3]) + ("…" if len(spec.sampled_files) > 3 else "")
        lines.append(f"- sampled: {len(spec.sampled_files)} file(s), {spec.sampled_rows} rows ({shown})")
    if spec.tables:
        lines += ["", "Target", f"- {len(spec.tables)} {t.platform} {t.table_format} tables in {t.database or '?'}.{t.schema_name or '?'}"]
        lines.append(f"- external volume {t.external_volume or '(to be set)'} · base location {t.base_location or '-'}/<table> · load {t.load_mode}")
        if spec.create:
            lines.append(f"- the setup creates the {' and '.join(spec.create)} first")
        lines += ["", f"Tables ({len(spec.tables)})"]
        for x in spec.tables:
            checks = sum(1 for k in x.tests if k.origin)
            failing = sum(1 for k in x.tests if k.sample_failures)
            note = f" · {failing} failing on the file" if failing else ""
            lack = f" · lacks {', '.join(x.missing_columns)}" if x.missing_columns else ""
            lines.append(
                f"- {x.name} ← {x.source_file}: {len(x.columns)} columns, {x.rows} rows, key {', '.join(x.keys) or '(none)'}, "
                f"{len(x.tests)} checks ({checks} from {x.exemplar or 'the contract'}){note}{lack}"
            )
        return "\n".join([*lines, *_tail(spec)])
    lines += ["", "Target", f"- {t.platform} {t.table_format} table {t.database or '?'}.{t.schema_name or '?'}.{t.table or '?'}"]
    keys = f" on {', '.join(t.merge_keys)}" if t.merge_keys else ""
    lines.append(f"- external volume {t.external_volume or '(to be set)'} · base location {t.base_location or '-'} · load {t.load_mode}{keys}")
    if spec.columns:
        lines += ["", f"Columns ({len(spec.columns)})"]
        for c in spec.columns:
            term = f" → {c.term_name}" if c.term_name else ""
            catalog = f" [catalog: {c.catalog_type}]" if c.catalog_type and c.catalog_type.upper() != c.type.upper() else ""
            lines.append(f"- {c.name} {c.type}{'' if c.nullable else ' NOT NULL'}{term}{catalog}" + (f" (e.g. {c.sample})" if c.sample else ""))
    if spec.transformations:
        lines += ["", "Transformations"] + [f"- {x}" for x in spec.transformations]
    if spec.tests:
        lines += ["", "Tests"] + [
            f"- {x.name}: {x.kind}"
            + (f" on {', '.join(x.columns)}" if x.columns else "")
            + (f" · {x.detail}" if x.detail else "")
            + (f" · fails on {x.sample_failures} sampled rows" if x.sample_failures else "")
            for x in spec.tests
        ]
    if spec.exemplar_checks:
        counts = {o: sum(1 for c in spec.exemplar_checks if c.outcome == o) for o in ("copied", "covered", "skipped")}
        lines += ["", f"Exemplar checks: {counts['copied']} copied, {counts['covered']} covered by the typed load, {counts['skipped']} skipped"]
        lines += [f"- {c.name}: {c.detail}" for c in spec.exemplar_checks if c.outcome == "skipped"]
    if spec.downstream:
        lines += ["", "Downstream models to update"]
        for d in spec.downstream:
            mapped = sum(1 for c in d.columns if c.status == "mapped")
            where = f", {d.files[0]}" if d.files else ""
            lines.append(f"- {d.table} ({d.repo}{where}): this feed supplies {mapped} of {len(d.columns)} columns")
    if spec.catalog_match is not None:
        m = spec.catalog_match
        key = f"; declared key {', '.join(m.key)}{'' if m.key_in_feed else ' (not in the files)'}" if m.key else ""
        lines += ["", "Catalog match", f"- {m.fqn}: {len(m.matched_columns)} of the feed's {m.feed_columns} columns{key}; {m.types_adopted} column type(s) adopted"]
        if m.duplicate:
            lines.append(f"- possible duplicate: {m.duplicate_reason}")
    if spec.joins:
        lines += ["", "Joins"] + [
            f"- {', '.join(j.columns)} → {j.to_table} ({', '.join(j.to_columns)}) · {j.kind.replace('_', ' ')}" + (f" {j.confidence:.0%}" if j.confidence < 1 else "")
            for j in spec.joins
        ]
    return "\n".join([*lines, *_tail(spec)])


def _models_markdown(spec: PipelineSpec) -> list[str]:
    t = spec.target
    by = f"compiled from {', '.join(f.rsplit('/', 1)[-1] for f in spec.source.mapping_files)}" if spec.source.mapping_files else "built by the data modeler"
    lines = ["", f"Proposed {t.schema_name or 'target'} model ({len(spec.models)} tables in {t.database or '?'}.{t.schema_name or '?'}, {by})"]
    for m in spec.models:
        rels = f" · joins {', '.join(r.to_table for r in m.relationships)}" if m.relationships else ""
        reads = ", ".join(s.rsplit(".", 1)[-1] for s in m.sources) or f"nothing yet (waits for {', '.join(m.waiting_on)})"
        dry = f" Dry run: {m.rows:,} rows" + (f", {m.duplicates:,} repeated keys" if m.duplicates else "") + "." if m.rows is not None else ""
        lines.append(f"- {m.name} ({m.kind}): {m.grain}. Key {', '.join(m.keys) or '(none)'}; {len(m.columns)} columns from {reads}{rels}.{dry}")
        for d in m.deviations[:2]:
            lines.append(f"  - differs from {m.exemplar}: {d}")
        for f in m.findings[:2]:
            lines.append(f"  - check: {f}")
    return [*lines, *_tail(spec)]


def _tail(spec: PipelineSpec) -> list[str]:
    lines = ["", f"Schedule: {spec.schedule}"]
    if spec.blockers:
        lines += ["", "Blocked: it reads tables that hold no rows, so it cannot be approved until they are loaded"] + [f"- {x}" for x in spec.blockers]
    if spec.matches:
        lines += ["", "Related in the hub"] + [f"- {m.kind}: {m.name} · {m.detail}" for m in spec.matches]
    if spec.assumptions:
        lines += ["", "Assumptions"] + [f"- {x}" for x in spec.assumptions]
    if spec.risks:
        lines += ["", "Risks"] + [f"- {x}" for x in spec.risks]
    lines += ["", "Reply /approve to generate the pipeline, /reject <reason>, or /answer <text> to change the spec."]
    return lines
