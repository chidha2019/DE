"""The intent service: the state machine from ticket to generated pipeline, with Jira as one of its doors.

received → (clarifying ↔ answers) → validated in Snowflake (read-only) → routed:
    planning (files to load) | modeling (a layer to design) | waiting (upstream tables not loaded yet)
→ spec_proposed → approved → coding → pr_open → running → loaded → done          (↘ rejected, ↘ failed)

Approval is the human gate: with a runner configured, an approved ingest is generated, tested and then run by the
hub (upload, create, load, check, refresh the catalog); a person closes it once the numbers look right.
"""

from __future__ import annotations

import asyncio
import os
import re
import shutil
import sys
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from uuid import UUID

from ech_core.exceptions import DependencyUnavailableError, InvalidRequestError, NotFoundError
from ech_core.jira_client import JiraClient, JiraLink, parse_command
from ech_core.llm.client import ModelClient
from ech_core.logging import get_logger
from ech_core.repositories.glossary_repository import GlossaryRepository
from ech_core.repositories.intent_repository import IntentRepository
from ech_core.schemas.intents import (
    CoderResult,
    GeneratedFile,
    IntentCreate,
    IntentDecision,
    IntentFile,
    IntentRecord,
    IntentsConfig,
    IntentValidation,
    JiraSyncResult,
    PipelineRun,
    PipelineSpec,
    StructuredIntent,
)
from ech_core.schemas.er import ErDiagram
from query_service.intents import er, generator
from query_service.intents.blockers import plan_blockers
from query_service.intents.mapping import design_folders, discover, load_design, referenced_files, resolve_files
from query_service.intents.mapping_modeler import MappingModeler
from query_service.intents.modeler import DataModeler
from query_service.intents.parser import parse_intent
from query_service.intents.planner import Planner, render_spec_markdown
from query_service.intents.review import review_intent
from query_service.intents.route import choose_route, route_stages
from query_service.intents.runner import PipelineRunner
from query_service.intents.validate import Expectation, SnowflakeReader, validate
from query_service.intents.workflow import build_workflow

log = get_logger(__name__)
_TEXT_LIMIT = 200_000
_SECRET = re.compile(r"TOKEN|KEY|SECRET|PASSWORD|PASSPHRASE|CREDENTIAL|CONNECTION_STRING|^ECH_RUN_", re.I)
_ISSUE_KEY = re.compile(r"\b([A-Z][A-Z0-9_]+-\d+)\b")
_IDENTIFIER_QUESTION = re.compile(r"identifier|primary key|unique|\bkeys?\b", re.I)
_FILE_FORMAT_QUESTION = re.compile(r"encod|utf-?8|windows-?125|delimit|header row", re.I)
_INTEGRATION_QUESTION = re.compile(r"storage integration", re.I)
_PLANNER_DECIDES = re.compile(r"base.?location|stage name|file format name|schedule|cron|cadence|how often|frequen", re.I)
_DESIGN_ANSWERS = re.compile(
    r"column|\bkeys?\b|identifier|grain|tables?\b|types?\b|mapping|transform|surrogate|iceberg|native|volume|dimension|fact|model|join|lookup|history|scd",
    re.I,
)
_RUNNABLE = ("pr_open", "loaded", "failed")
_HUB_RUNS = ("ingest_csv_to_iceberg", "model_layer")
_RECHECK_SECONDS = 300


def issue_key(text: str | None) -> str | None:
    """DATA-123 from a key or a browse URL (…/browse/DATA-123, ?selectedIssue=DATA-123); the last one wins."""
    found = _ISSUE_KEY.findall((text or "").strip().upper())
    return found[-1] if found else None


def _settled(question: str, expect: Expectation) -> bool:
    """A question the hub answers itself: identifiers, when every table has a contract with its key or every file
    its own <file>_id column; a file's encoding, delimiter or header, once the files have been read; the storage
    integration, when the ticket names an existing stage (the stage already reads through one)."""
    if _PLANNER_DECIDES.search(question):
        return True  # each table's base location, the stage and file format names and the schedule are the planner's to choose
    if expect.identifiers_known and _IDENTIFIER_QUESTION.search(question):
        return True
    if expect.stage and _INTEGRATION_QUESTION.search(question):
        return True
    if expect.designed and (_DESIGN_ANSWERS.search(question) or any(re.search(rf"\b{re.escape(n)}\b", question, re.I) for n in expect.design_names)):
        return True  # the mapping, data model and DDL answer what to build, and how each of their columns is filled
    return expect.files_read and bool(_FILE_FORMAT_QUESTION.search(question))


def _read_files(workspace: Path, paths: list[str]) -> list[IntentFile]:
    root = workspace.resolve()
    out: list[IntentFile] = []
    for rel in paths:
        path = (root / rel).resolve()
        if root not in path.parents or not path.is_file():
            continue
        out.append(IntentFile(path=rel, content=path.read_text(encoding="utf-8", errors="replace")[:_TEXT_LIMIT]))
    return out


def _write_files(workspace: Path, name: str, files: dict[str, str]) -> tuple[Path, list[GeneratedFile]]:
    """Render the pipeline folder afresh inside the workspace; paths that escape it are skipped."""
    root = workspace.resolve()
    folder = (root / name).resolve()
    if root not in folder.parents:
        raise InvalidRequestError("pipeline name escapes the workspace")
    if folder.exists():
        shutil.rmtree(folder)
    written: list[GeneratedFile] = []
    for rel, content in files.items():
        path = (folder / rel).resolve()
        if folder not in path.parents:
            continue
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        written.append(GeneratedFile(path=rel, bytes=len(content.encode("utf-8")), reason="rendered from the approved spec"))
    return folder, written


class IntentService:
    def __init__(
        self,
        *,
        repo: IntentRepository,
        planner: Planner,
        model: ModelClient | None,
        glossary: GlossaryRepository | None,
        workspace_dir: Path,
        data_dir: Path,
        jira: JiraClient | None = None,
        jira_jql: str = "",
        poll_seconds: int = 0,
        jira_link: JiraLink | None = None,
        snowflake_configured: bool | Callable[[], bool] = False,
        intent_repo: str | None = None,
        run_tests: bool = True,
        snowflake_reader: SnowflakeReader | None = None,
        modeler: DataModeler | None = None,
        mapping_modeler: MappingModeler | None = None,
        background_modeling: bool = True,
        runner: PipelineRunner | None = None,
        autorun: bool = False,
        catalog_url: str | None = None,
    ) -> None:
        self._repo = repo
        self._planner = planner
        self._model = model
        self._glossary = glossary
        self._workspace = workspace_dir
        self._data_dir = data_dir
        # A fixed client (tests) wins; otherwise the link follows the connection saved on the Connectors page.
        self._jira = jira
        self._jql = jira_jql
        self._poll_seconds = poll_seconds
        self._link = jira_link
        self._snowflake = snowflake_configured
        self._intent_repo = intent_repo
        self._run_tests = run_tests
        self._snowflake_reader = snowflake_reader
        self._modeler = modeler
        self._mapping_modeler = mapping_modeler
        self._background = background_modeling
        self._runner = runner
        self._autorun = autorun and runner is not None
        self._catalog_url = catalog_url.rstrip("/") if catalog_url else None
        self._tasks: set[asyncio.Task[None]] = set()
        self._lock = asyncio.Lock()

    # ------------------------------------------------------------------ the Jira connection
    def _jira_configured(self) -> bool:
        return self._jira is not None or (self._link is not None and self._link.configured())

    def _jira_jql(self) -> str:
        return self._link.jql() if self._jira is None and self._link is not None else self._jql

    def _jira_poll(self) -> int:
        return self._link.poll_seconds() if self._jira is None and self._link is not None else self._poll_seconds

    async def _jira_client(self) -> JiraClient | None:
        if self._jira is not None:
            return self._jira
        return await self._link.client() if self._link is not None else None

    # ------------------------------------------------------------------ reads
    @property
    def polling(self) -> bool:
        """Whether to run the poll loop: always with a link, since Jira may be connected later; it idles until then."""
        return self._link is not None or (self._jira is not None and self._poll_seconds > 0)

    def config(self) -> IntentsConfig:
        configured = self._jira_configured()
        return IntentsConfig(
            jira_configured=configured,
            jira_jql=self._jira_jql() if configured else None,
            poll_seconds=self._jira_poll() if configured else 0,
            workspace=str(self._workspace),
            data_dir=str(self._data_dir),
            snowflake_configured=self._snowflake() if callable(self._snowflake) else self._snowflake,
            model_available=self._model is not None,
            run_enabled=self._runner is not None,
            autorun=self._autorun,
            run_role=self._runner.role() if self._runner else None,
            run_missing=self._runner.missing(None) if self._runner else [],
        )

    async def list(self, *, status: str | None, limit: int, offset: int) -> tuple[list[IntentRecord], int]:
        rows, total = await self._repo.list(status=status, limit=limit, offset=offset)
        names = await self._glossary_names()
        return [self._record(r, names) for r in rows], total

    async def get(self, intent_id: UUID) -> IntentRecord:
        row = await self._repo.get(intent_id)
        if row is None:
            raise NotFoundError(f"intent {intent_id} not found")
        return self._record(row, await self._glossary_names())

    def _record(self, row: dict[str, Any], glossary_names: list[str]) -> IntentRecord:
        """The stored record plus what is derived from it on read: the review of the ticket and the plan as steps."""
        record = IntentRecord.model_validate(row)
        record.review = review_intent(record.intent, questions=record.questions, spec=record.spec, glossary_names=glossary_names)
        record.workflow = build_workflow(record.spec)
        if self._runner is not None and record.spec is not None and record.spec.kind in _HUB_RUNS:
            record.run_missing = self._runner.missing(record.spec)
        if record.route is not None:
            record.route.stages = route_stages(record.route, record.status, validated=record.validation is not None and record.validation.reachable)
        return record

    async def _glossary_names(self) -> list[str]:
        if self._glossary is None:
            return []
        try:
            return [t["name"] for t in await self._glossary.catalog()]
        except Exception as exc:  # noqa: BLE001 - a review without glossary matches still reads
            log.warning("intent.glossary_names.failed", error=str(exc))
            return []

    async def files(self, intent_id: UUID) -> list[IntentFile]:
        record = await self.get(intent_id)
        if record.coder is None:
            return []
        return await asyncio.to_thread(_read_files, Path(record.coder.workspace), [f.path for f in record.coder.files])

    async def diagram(self, intent_id: UUID) -> ErDiagram:
        """The ER diagram of the layer an intent's plan models."""
        record = await self.get(intent_id)
        if record.spec is None or not record.spec.models:
            raise NotFoundError("this intent's plan models no tables")
        label = record.jira_key or record.title
        return er.from_models(record.spec.models, key=f"intent:{record.id}", title=f"{label} · {record.spec.name}", origin=label)

    async def design_diagrams(self) -> list[ErDiagram]:
        """An ER diagram for each folder of design documents under the data directory."""

        def build() -> list[ErDiagram]:
            return [er.from_design(load_design(texts), origin=origin, files=sorted(texts)) for origin, texts in design_folders(self._data_dir)]

        return await asyncio.to_thread(build)

    # ------------------------------------------------------------------ the flow
    async def create(self, body: IntentCreate) -> IntentRecord:
        """A ticket typed or pasted in; with a Jira key it is recorded as that ticket (once: the same key returns the same intent)."""
        key = issue_key(body.jira_key)
        if key:
            existing = await self._repo.by_jira_key(key)
            if existing is not None:
                return await self.get(existing["id"])
        client = await self._jira_client() if key else None
        url = body.jira_url or (client.issue_url(key) if key and client else None)
        row = await self._repo.create(
            source="jira" if key else "manual", title=body.title.strip(), text=body.text.strip(), reporter=body.reporter.strip(), jira_key=key, jira_url=url
        )
        return await self.process(row["id"])

    async def import_jira(self, issue: str) -> IntentRecord:
        """Read one Jira issue by key or URL and run it through the flow; an issue already imported is returned as is."""
        key = issue_key(issue)
        if key is None:
            raise InvalidRequestError("give an issue key such as DATA-123, or the issue's browse URL")
        existing = await self._repo.by_jira_key(key)
        if existing is not None:
            return await self.get(existing["id"])
        client = await self._jira_client()
        if client is None:
            raise DependencyUnavailableError(
                "Jira is not connected, so the issue cannot be read: connect Jira on the Connectors page, or paste its summary and description instead"
            )
        found = await client.issue(key)
        row = await self._repo.create(
            source="jira", title=(found["summary"] or key)[:200], text=found["description"][:20_000], reporter=found["reporter"], jira_key=key, jira_url=found["url"]
        )
        return await self.process(row["id"])

    async def process(self, intent_id: UUID) -> IntentRecord:
        """Parse (with any answers so far); ask questions, or plan and propose the spec."""
        row = await self._require(intent_id)
        try:
            names = [t["name"] for t in await self._glossary.catalog()] if self._glossary else []
            intent = await parse_intent(
                self._model,
                title=row["title"],
                text=row["text"],
                answers=list(row.get("answers") or []),
                glossary_names=names,
                data_dir=str(self._data_dir),
            )
            if not intent.owner:
                intent.owner = str(row.get("reporter") or "")
            if row.get("jira_key"):
                intent.depends_on = [k for k in intent.depends_on if k != row["jira_key"]]
            await self._advance(intent_id, row, intent)
        except Exception as exc:  # noqa: BLE001 - the record carries the failure
            log.warning("intent.process.failed", intent=str(intent_id), error=str(exc))
            await self._repo.update(intent_id, status="failed", error=str(exc)[:500])
        return await self.get(intent_id)

    async def _advance(self, intent_id: UUID, row: dict[str, Any], intent: StructuredIntent) -> None:
        """Validate in Snowflake (read-only), choose the route, then ask, wait, plan or model as the route says."""
        await self._find_design(intent, row)
        expect = await self._planner.expectations(intent)
        validation = await self._validate(expect)
        route = choose_route(intent, expect, validation)
        intent.open_questions = [q for q in intent.open_questions if not _settled(q, expect)]
        stored: dict[str, Any] = {
            "intent": intent.model_dump(by_alias=True),
            "validation": validation.model_dump(mode="json"),
            "route": route.model_dump(mode="json", exclude={"stages"}),
            "error": None,
        }
        if intent.open_questions:
            await self._repo.update(intent_id, status="clarifying", questions=intent.open_questions, **stored)
            questions = "\n".join(f"- {q}" for q in intent.open_questions)
            await self._post(intent_id, row, "questions", f"Before I can plan this I need to know:\n{questions}\n\nReply with /answer <your answers>.")
            return
        if route.key == "wait_upstream":
            await self._repo.update(intent_id, status="waiting", questions=[], **stored)
            if row["status"] != "waiting":
                await self._post(
                    intent_id,
                    row,
                    "waiting",
                    f"{route.title}. {route.reason}\n\nSnowflake (read-only check): {validation.summary}\n\n"
                    "I check again every few minutes and carry on as soon as the tables are there.",
                )
            return
        modeler: DataModeler | MappingModeler | None = None
        if route.key in ("model_new", "model_existing"):
            # The team's own design, when the ticket points at one, is the contract; otherwise the data modeler designs it.
            modeler = self._mapping_modeler if intent.source.mapping_files and self._mapping_modeler is not None else self._modeler
        await self._repo.update(intent_id, status="modeling" if modeler else "planning", questions=[], **stored)
        if modeler is None:
            spec = await self._planner.plan(intent, row["title"], validation)
            await self._propose(intent_id, row, spec, validation)
            return
        # The modeler works for minutes (it profiles tables and tries its SQL), so it runs after the request returns.
        job = self._model_and_propose(intent_id, row, intent, expect, validation, modeler)
        if not self._background:
            await job
            return
        task = asyncio.create_task(job, name=f"intent-model-{intent_id}")
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    async def _model_and_propose(
        self,
        intent_id: UUID,
        row: dict[str, Any],
        intent: StructuredIntent,
        expect: Expectation,
        validation: IntentValidation,
        modeler: DataModeler | MappingModeler,
    ) -> None:
        who = "mapping modeler" if isinstance(modeler, MappingModeler) else "data modeler"
        try:
            if isinstance(modeler, MappingModeler):
                spec = await modeler.model(intent, row["title"], expect, validation, ticket=f"{row['title']}\n{row.get('text') or ''}")
            else:
                spec = await modeler.model(intent, row["title"], expect, validation)
            await self._propose(intent_id, row, spec, validation)
        except Exception as exc:  # noqa: BLE001 - the record carries the failure
            log.warning("intent.model.failed", intent=str(intent_id), error=str(exc))
            await self._repo.update(intent_id, status="failed", error=f"{who}: {exc}"[:500])

    async def _find_design(self, intent: StructuredIntent, row: dict[str, Any]) -> None:
        """For a modelled layer: the design files the ticket or its answers name, or else the mapping under the data
        directory whose targets the ticket names; recorded on the intent as source.mapping_files."""
        if intent.kind not in ("model_layer", "gold_fact"):
            return
        root = self._data_dir.resolve()
        text = "\n".join([row["title"], row.get("text") or "", *(row.get("answers") or [])])
        refs = intent.source.mapping_files or referenced_files(text)
        files = await asyncio.to_thread(resolve_files, root, refs) if refs else []
        if not files:
            files, _ = await asyncio.to_thread(discover, root, text)
        intent.source.mapping_files = [str(p.relative_to(root)).replace("\\", "/") if root in p.parents else p.name for p in files]

    async def _propose(self, intent_id: UUID, row: dict[str, Any], spec: PipelineSpec, validation: IntentValidation) -> None:
        spec.blockers = plan_blockers(spec, validation)
        markdown = render_spec_markdown(spec, validation)
        await self._repo.update(intent_id, status="spec_proposed", spec=spec.model_dump(by_alias=True), spec_markdown=markdown)
        await self._post(intent_id, row, "spec", markdown)

    async def _validate(self, expect: Expectation) -> IntentValidation:
        if self._snowflake_reader is None:
            return await validate(None, expect)
        try:
            async with self._snowflake_reader.session() as sql:
                return await validate(sql, expect)
        except Exception as exc:  # noqa: BLE001 - a connection that cannot be opened leaves the intent unvalidated
            log.warning("intent.validate.session_failed", error=str(exc)[:300])
            return IntentValidation(checked_at=datetime.now(tz=UTC), reachable=False, error=str(exc)[:300], summary="Not validated: Snowflake could not be reached.")

    async def revalidate(self, intent_id: UUID) -> IntentRecord:
        """Look in Snowflake again with the parsed intent as it is; a waiting intent goes on when its tables have landed."""
        row = await self._require(intent_id)
        if not row.get("intent"):
            raise InvalidRequestError("the intent has not been parsed yet")
        intent = StructuredIntent.model_validate(row["intent"])
        if row["status"] in ("waiting", "failed") or (row["status"] == "clarifying" and not row.get("questions")):
            try:
                await self._advance(intent_id, row, intent)
            except Exception as exc:  # noqa: BLE001 - the record carries the failure
                log.warning("intent.revalidate.failed", intent=str(intent_id), error=str(exc))
                await self._repo.update(intent_id, status="failed", error=str(exc)[:500])
            return await self.get(intent_id)
        expect = await self._planner.expectations(intent)
        validation = await self._validate(expect)
        route = choose_route(intent, expect, validation)
        await self._repo.update(intent_id, validation=validation.model_dump(mode="json"), route=route.model_dump(mode="json", exclude={"stages"}))
        return await self.get(intent_id)

    async def recheck_waiting(self) -> int:
        """Validate every waiting intent again; returns how many moved on."""
        moved = 0
        for row in await self._repo.by_status("waiting"):
            record = await self.revalidate(row["id"])
            moved += record.status != "waiting"
        return moved

    async def answer(self, intent_id: UUID, answers: list[str]) -> IntentRecord:
        row = await self._require(intent_id)
        if row["status"] not in ("clarifying", "spec_proposed", "failed"):
            raise InvalidRequestError(f"intent is {row['status']}; answers are taken while clarifying or while a spec is proposed")
        cleaned = [a.strip() for a in answers if a.strip()]
        await self._repo.update(intent_id, answers=[*(row.get("answers") or []), *cleaned])
        return await self.process(intent_id)

    async def decide(self, intent_id: UUID, body: IntentDecision) -> IntentRecord:
        row = await self._require(intent_id)
        if body.decision == "approve":
            if row["status"] != "spec_proposed":
                raise InvalidRequestError(f"intent is {row['status']}; only a proposed spec can be approved")
            blockers = (row.get("spec") or {}).get("blockers") or []
            if blockers:
                raise InvalidRequestError(
                    f"this plan reads {len(blockers)} table(s) that hold no rows ({'; '.join(blockers[:3])}); load them, then re-plan"
                )
            await self._repo.decide(intent_id, "approved", error=None)
            await self._post(intent_id, row, "approved", "Spec approved; generating the pipeline." + (f" Note: {body.note}" if body.note else ""))
            return await self.code(intent_id)
        if body.decision == "reject":
            if row["status"] in ("done", "rejected"):
                raise InvalidRequestError(f"intent is already {row['status']}")
            await self._repo.decide(intent_id, "rejected", error=None)
            await self._post(intent_id, row, "rejected", "Spec rejected." + (f" Reason: {body.note}" if body.note else ""))
            return await self.get(intent_id)
        if row["status"] not in ("pr_open", "loaded"):
            raise InvalidRequestError(f"intent is {row['status']}; only generated or loaded pipelines can be marked done")
        await self._repo.decide(intent_id, "done")
        await self._post(intent_id, row, "done", "Pipeline landed; closing the intent." + (f" {body.note}" if body.note else ""))
        return await self.get(intent_id)

    async def code(self, intent_id: UUID) -> IntentRecord:
        """Implement the approved spec with the template generator."""
        row = await self._require(intent_id)
        if row["status"] != "approved" or not row.get("spec"):
            raise InvalidRequestError("only an approved spec can be coded")
        spec = PipelineSpec.model_validate(row["spec"])
        await self._repo.update(intent_id, status="coding")
        try:
            async with self._lock:
                result = await self._generate(spec)
            await self._repo.update(intent_id, status="pr_open", coder=result.model_dump(), branch=result.branch, pr_url=result.pr_url)
            tests = {True: "tests passed", False: "tests FAILED", None: "tests not run"}[result.tests_passed]
            files = "\n".join(f"- {f.path}" for f in result.files)
            runs = self._autorun and spec.kind in _HUB_RUNS and result.tests_passed is not False
            steps = "create, load and check" if spec.kind == "model_layer" else "upload, create, load and check"
            after = f"The hub runs it now: {steps}." if runs else "Reply /done when it has landed."
            await self._post(intent_id, row, "generated", f"Pipeline generated in {result.workspace} ({tests}):\n{files}\n\n{result.summary}\n\n{after}")
            if runs:
                return await self.run(intent_id, triggered_by="approval")
        except Exception as exc:  # noqa: BLE001
            log.warning("intent.code.failed", intent=str(intent_id), error=str(exc))
            await self._repo.update(intent_id, status="failed", error=str(exc)[:500])
        return await self.get(intent_id)

    # ------------------------------------------------------------------ running the generated pipeline
    async def run(self, intent_id: UUID, *, triggered_by: str = "manual") -> IntentRecord:
        """Start a run of the generated pipeline (after approval, or again from the page); it continues in the background."""
        row = await self._require(intent_id)
        if self._runner is None:
            raise DependencyUnavailableError("the hub does not run pipelines here: set ECH_INTENT_RUN_ENABLED=true and the ECH_RUN_* settings")
        if row["status"] not in _RUNNABLE or not row.get("coder") or not row.get("spec"):
            raise InvalidRequestError(f"intent is {row['status']}; only a generated pipeline can be run")
        spec = PipelineSpec.model_validate(row["spec"])
        if spec.kind not in _HUB_RUNS or (spec.kind == "model_layer" and not spec.models):
            raise InvalidRequestError("only CSV-to-Iceberg pipelines and modelled layers run in the hub; hand the others to the reference agent")
        folder = Path(str(row["coder"].get("workspace") or ""))
        data_folder = self._planner.resolve_folder(spec.source.folder) if spec.kind == "ingest_csv_to_iceberg" else None
        await self._repo.update(intent_id, status="running", error=None)
        job = self._execute_run(intent_id, row, spec, folder, data_folder, triggered_by)
        if not self._background:
            await job
            return await self.get(intent_id)
        task = asyncio.create_task(job, name=f"intent-run-{intent_id}")
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)
        return await self.get(intent_id)

    async def _execute_run(self, intent_id: UUID, row: dict[str, Any], spec: PipelineSpec, folder: Path, data_folder: Path | None, triggered_by: str) -> None:
        assert self._runner is not None

        async def progress(run: PipelineRun) -> None:
            await self._repo.update(intent_id, run=run.model_dump(mode="json"))

        try:
            run = await self._runner.execute(
                spec, folder, data_folder, triggered_by=triggered_by, progress=progress, catalog=(lambda: self._catalog(spec, row)) if self._catalog_url else None
            )
        except Exception as exc:  # noqa: BLE001 - the record carries the failure
            log.warning("intent.run.crashed", intent=str(intent_id), error=str(exc))
            await self._repo.update(intent_id, status="failed", error=f"pipeline run: {exc}"[:500])
            return
        if run.status == "succeeded":
            await self._repo.update(intent_id, status="loaded", error=None)
            passed = sum(1 for c in run.checks if c.passed)
            warned = sum(1 for c in run.checks if not c.passed and c.severity == "warn")
            tables = len(spec.tables) or len(spec.models) or 1
            catalog = "The catalog refresh has started." if run.catalog_run_id else "Refresh the catalog from the Pipelines page."
            if spec.kind == "model_layer":
                done = (
                    f"{tables} table(s) built in {spec.target.database}.{spec.target.schema_name}: "
                    f"{sum(m.inserted for m in run.models):,} rows inserted, {sum(m.updated for m in run.models):,} updated, "
                    f"{sum(m.rejected for m in run.models):,} rejected with a reason"
                )
            else:
                done = f"{run.files_uploaded} file(s) uploaded, {tables} table(s) loaded into {spec.target.database}.{spec.target.schema_name}"
            await self._post(
                intent_id,
                row,
                "loaded",
                f"Pipeline ran in the hub: {done}; {passed} of {len(run.checks)} checks passed"
                f"{f', {warned} warning(s)' if warned else ''}. {catalog}\n\nReply /done once the numbers look right.",
            )
            return
        await self._repo.update(intent_id, status="failed", error=run.error[:500])
        await self._post(intent_id, row, "run_failed", f"The pipeline run stopped. {run.error}\n\nFix it and run it again from the intent page.")

    async def _catalog(self, spec: PipelineSpec, row: dict[str, Any]) -> str:
        """Ask the ingestion service for a Snowflake sync of the target schema, so the new tables reach the catalog."""
        import httpx  # noqa: PLC0415

        body = {
            "connector": "snowflake",
            "scope": [{"path": [spec.target.database, spec.target.schema_name], "kind": "schema"}],
            "triggered_by": f"intent:{row.get('jira_key') or row['id']}",
        }
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(f"{self._catalog_url}/api/v1/pipelines/runs", json=body)
        if response.status_code == 409:
            raise RuntimeError("the Snowflake connector is busy with another run")
        response.raise_for_status()
        return str(response.json().get("id") or "")

    async def _generate(self, spec: PipelineSpec) -> CoderResult:
        files = generator.generate(spec)
        folder, written = await asyncio.to_thread(_write_files, self._workspace, spec.name, files)
        passed, output = (await self._pytest(folder)) if (self._run_tests and "tests/test_pipeline.py" in files) else (None, "")
        branch = f"intent/{spec.name.replace('_', '-')}"
        if spec.kind == "model_layer" and spec.models:
            summary = (
                f"{len(written)} files rendered from the approved model: the {spec.target.schema_name} DDL, a staged merge per table with "
                "rejects and change detection, post-load checks, a scheduled task, offline tests and a README."
            )
        elif spec.kind == "ingest_csv_to_iceberg":
            summary = (
                f"{len(written)} files rendered from the approved spec: SQL for stage, Iceberg table, load, checks and task, "
                "a runner over the Snowflake SQL REST API with S3 upload, offline tests and a README."
            )
        else:
            summary = "No template for this kind; the spec and a README were written for the reference agent or a person."
        return CoderResult(
            generator="template", workspace=str(folder), files=written, tests_passed=passed, test_output=output[-4000:], branch=branch, pr_url=None, summary=summary
        )

    async def _pytest(self, folder: Path) -> tuple[bool | None, str]:
        # The generated tests are our own template, but they still run without any credential in reach.
        env = {k: v for k, v in os.environ.items() if not _SECRET.search(k)}
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        try:
            proc = await asyncio.create_subprocess_exec(
                sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "tests",
                cwd=str(folder), stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT, env=env,
            )
            out, _ = await asyncio.wait_for(proc.communicate(), timeout=180)
            text = out.decode(errors="replace")
            if "No module named pytest" in text:
                return None, text
            return proc.returncode == 0, text
        except (OSError, TimeoutError) as exc:
            return None, f"could not run pytest: {exc}"

    # ------------------------------------------------------------------ Jira
    async def sync_jira(self, *, import_new: bool = True) -> JiraSyncResult:
        """Follow the replies on the tickets already imported; with import_new (Sync Jira), also import the tickets
        the intent JQL matches that the hub does not hold yet. The poll loop never imports."""
        client = await self._jira_client()
        if client is None:
            raise DependencyUnavailableError("Jira is not connected: connect it on the Connectors page (site URL, email and API token)")
        result = JiraSyncResult()
        issues = await client.search(self._jira_jql(), max_results=50)
        result.fetched = len(issues)
        for issue in issues:
            try:
                existing = await self._repo.by_jira_key(issue["key"])
                if existing is None and not import_new:
                    continue
                if existing is None:
                    row = await self._repo.create(
                        source="jira", title=issue["summary"], text=issue["description"], reporter=issue["reporter"], jira_key=issue["key"], jira_url=issue["url"]
                    )
                    await self.process(row["id"])
                    result.created += 1
                    continue
                await self._apply_comments(client, existing, result)
            except Exception as exc:  # noqa: BLE001 - one ticket must not stop the sweep
                result.errors.append(f"{issue.get('key')}: {exc}"[:200])
                log.warning("intent.jira.sync_failed", key=issue.get("key"), error=str(exc))
        return result

    async def _apply_comments(self, client: JiraClient, row: dict[str, Any], result: JiraSyncResult) -> None:
        posted = {str(p.get("comment_id")) for p in (row.get("posted") or []) if p.get("comment_id")}
        for comment in await client.comments(row["jira_key"]):
            if comment["id"] in posted:
                continue
            command = parse_command(comment["text"])
            await self._repo.append_posted(row["id"], {"kind": "seen", "comment_id": comment["id"], "at": datetime.now(tz=UTC).isoformat()})
            if command is None:
                continue
            verb, payload = command
            try:
                if verb == "answer":
                    await self.answer(row["id"], [payload or comment["text"]])
                    result.answered += 1
                elif verb == "approve":
                    await self.decide(row["id"], IntentDecision(decision="approve", note=payload))
                    result.approved += 1
                elif verb == "reject":
                    await self.decide(row["id"], IntentDecision(decision="reject", note=payload))
                    result.rejected += 1
                elif verb == "done":
                    await self.decide(row["id"], IntentDecision(decision="done", note=payload))
            except InvalidRequestError as exc:
                await self._post(row["id"], row, "error", f"Could not apply /{verb}: {exc}")
            row = await self._require(row["id"])

    async def poll_loop(self) -> None:
        """Follow the replies on imported tickets on the configured cadence (idle while Jira is not connected; new
        tickets come in only by key, paste or Sync Jira), and every few minutes look in Snowflake again for intents
        waiting on their upstream tables."""
        last_recheck = 0.0
        while True:
            poll = 0
            try:
                client = await self._jira_client()
                poll = self._jira_poll()
                if client is not None and poll > 0:
                    await self.sync_jira(import_new=False)
            except Exception as exc:  # noqa: BLE001
                log.warning("intent.jira.poll_failed", error=str(exc))
            now = asyncio.get_running_loop().time()
            if now - last_recheck >= _RECHECK_SECONDS:
                last_recheck = now
                try:
                    moved = await self.recheck_waiting()
                    if moved:
                        log.info("intent.waiting.moved_on", count=moved)
                except Exception as exc:  # noqa: BLE001
                    log.warning("intent.waiting.recheck_failed", error=str(exc))
            await asyncio.sleep(max(poll, 15) if poll > 0 else 60)

    async def _post(self, intent_id: UUID, row: dict[str, Any], kind: str, text: str) -> None:
        """Write back to the ticket when the intent came from Jira; the UI reads the record either way."""
        if row.get("source") != "jira" or not row.get("jira_key"):
            return
        client = await self._jira_client()
        if client is None:
            return
        try:
            comment_id = await client.add_comment(row["jira_key"], text)
            await self._repo.append_posted(intent_id, {"kind": kind, "comment_id": comment_id, "at": datetime.now(tz=UTC).isoformat()})
        except Exception as exc:  # noqa: BLE001 - a failed comment must not fail the flow
            log.warning("intent.jira.comment_failed", key=row.get("jira_key"), error=str(exc))

    async def _require(self, intent_id: UUID) -> dict[str, Any]:
        row = await self._repo.get(intent_id)
        if row is None:
            raise NotFoundError(f"intent {intent_id} not found")
        return row
