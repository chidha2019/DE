"""Hybrid + GraphRAG retrieval engine behind ``POST /api/v1/context/retrieve``.

Stages (all timed, all exported as Prometheus histograms)
---------------------------------------------------------
1. ``embed``   — embed the query (same provider as ingestion).
2. ``vector``  — pgvector HNSW cosine search       ┐ run concurrently
   ``keyword`` — Postgres FTS (``ts_rank_cd``)      ┘
3. ``fusion``  — reciprocal rank fusion of both legs.
4. ``graph``   — Neo4j expansion: entities of the top hits (1st degree),
   ``DEPENDS_ON`` neighbours (2nd degree) and other chunks that mention them,
   injected as extra candidates with a bounded ``graph_boost``.
5. ``hydrate`` — load chunk text + document metadata for the rerank pool.
6. ``rerank``  — cross-encoder (or heuristic BM25) over the pool; blend with the
   fused score using ``reranker_weight``.
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable
from typing import Any, TypeVar
from uuid import UUID

from ech_core.config import Settings
from ech_core.domain.models import ChunkWithDocument, ScoredChunk
from ech_core.embeddings.base import EmbeddingProvider
from ech_core.logging import get_logger
from ech_core.metrics import (
    RETRIEVAL_CANDIDATES,
    RETRIEVAL_REQUESTS_TOTAL,
    RETRIEVAL_STAGE_DURATION,
)
from ech_core.repositories import (
    AuditRepository,
    ChunkRepository,
    EmbeddingRepository,
    GraphRepository,
)
from ech_core.schemas.context import (
    ContextChunk,
    ContextRetrieveRequest,
    ContextRetrieveResponse,
    EntityRef,
    GraphContext,
    ScoreBreakdown,
    StageTimings,
)
from ech_core.schemas.graph import GraphEdge, GraphNode
from ech_core.text import truncate
from query_service.retrieval.fusion import Candidate, reciprocal_rank_fusion
from query_service.retrieval.reranker import RerankDoc, Reranker

log = get_logger(__name__)
T = TypeVar("T")


class HybridRetrievalEngine:
    def __init__(
        self,
        *,
        settings: Settings,
        embedder: EmbeddingProvider,
        chunks: ChunkRepository,
        embeddings: EmbeddingRepository,
        graph: GraphRepository,
        reranker: Reranker,
        audit: AuditRepository,
    ) -> None:
        self._s = settings
        self._embedder = embedder
        self._chunks = chunks
        self._embeddings = embeddings
        self._graph = graph
        self._reranker = reranker
        self._audit = audit
        self._background: set[asyncio.Task[Any]] = set()

    # ================================================================== public
    async def retrieve(
        self, request: ContextRetrieveRequest, *, request_id: str | None = None
    ) -> ContextRetrieveResponse:
        started = time.perf_counter()
        timings = StageTimings()
        query = request.effective_query()
        opts = request.options
        filters = request.filters
        debug: dict[str, Any] = {}

        try:
            # 1. embed ---------------------------------------------------------------
            query_vector: list[float] | None = None
            if opts.use_vector:
                query_vector, timings.embed_ms = await self._timed(
                    "embed", self._embedder.embed_query(query)
                )

            # 2. legs (concurrent) ---------------------------------------------------
            legs: dict[str, list[ScoredChunk]] = {}
            jobs: list[tuple[str, Awaitable[tuple[list[ScoredChunk], float]]]] = []
            if opts.use_vector and query_vector is not None:
                jobs.append(
                    (
                        "vector",
                        self._timed(
                            "vector",
                            self._embeddings.vector_search(
                                query_vector,
                                limit=opts.vector_top_k or self._s.retrieval_vector_top_k,
                                ef_search=self._s.hnsw_ef_search,
                                source_systems=filters.source_systems,
                                document_ids=filters.document_ids,
                                attributes=filters.attributes,
                            ),
                        ),
                    )
                )
            if opts.use_keyword:
                jobs.append(
                    (
                        "keyword",
                        self._timed(
                            "keyword",
                            self._chunks.keyword_search(
                                query,
                                limit=opts.keyword_top_k or self._s.retrieval_keyword_top_k,
                                source_systems=filters.source_systems,
                                document_ids=filters.document_ids,
                                attributes=filters.attributes,
                            ),
                        ),
                    )
                )
            results = await asyncio.gather(*(job for _, job in jobs))
            for (leg, _), (hits, ms) in zip(jobs, results, strict=True):
                legs[leg] = hits
                setattr(timings, f"{leg}_ms", ms)

            # 3. fusion --------------------------------------------------------------
            t0 = time.perf_counter()
            candidates = reciprocal_rank_fusion(
                legs,
                k=self._s.retrieval_rrf_k,
                weights={
                    "vector": self._s.retrieval_vector_weight,
                    "keyword": self._s.retrieval_keyword_weight,
                },
            )
            timings.fusion_ms = self._ms(t0)
            RETRIEVAL_STAGE_DURATION.labels("fusion").observe(timings.fusion_ms / 1000)
            debug["leg_sizes"] = {k: len(v) for k, v in legs.items()}

            # 4. graph expansion -----------------------------------------------------
            graph_context: GraphContext | None = None
            chunk_entities: dict[str, list[EntityRef]] = {}
            if opts.use_graph and candidates:
                seeds = [c.chunk_id for c in candidates[: max(request.top_k * 2, 10)]]
                expansion, timings.graph_ms = await self._timed(
                    "graph",
                    self._graph.expand_from_chunks(
                        seeds,
                        hops=opts.graph_hops,
                        max_entities=self._s.retrieval_graph_max_entities,
                        max_expanded_chunks=self._s.retrieval_graph_max_expanded_chunks,
                    ),
                )
                by_id = {c.chunk_id: c for c in candidates}
                top_score = max((e.score for e in expansion.expanded_chunks), default=0.0)
                for exp in expansion.expanded_chunks:
                    boost = self._s.retrieval_graph_boost_weight * (
                        exp.score / top_score if top_score else 0.0
                    )
                    cand = by_id.get(exp.chunk_id)
                    if cand is None:
                        cand = Candidate(chunk_id=exp.chunk_id, document_id=exp.document_id)
                        candidates.append(cand)
                        by_id[exp.chunk_id] = cand
                    cand.graph_boost = max(cand.graph_boost, boost)
                    cand.graph_via = exp.via
                    cand.paths.add("graph")
                chunk_entities = {
                    cid: [
                        EntityRef(key=e.key, name=e.name, entity_type=e.entity_type) for e in ents
                    ]
                    for cid, ents in expansion.chunk_entities.items()
                }
                if opts.include_graph_context:
                    graph_context = GraphContext(
                        nodes=[GraphNode(**n) for n in expansion.nodes],
                        edges=[GraphEdge(**e) for e in expansion.edges],
                        seed_chunk_ids=seeds,
                        expanded_chunk_ids=[e.chunk_id for e in expansion.expanded_chunks],
                        first_degree_entities=expansion.first_degree_keys,
                        second_degree_entities=expansion.second_degree_keys,
                    )
                debug["graph"] = {
                    "first_degree": len(expansion.first_degree_keys),
                    "second_degree": len(expansion.second_degree_keys),
                    "expanded_chunks": len(expansion.expanded_chunks),
                }

            # 5. hydrate the rerank pool --------------------------------------------
            pool_size = (
                opts.rerank_candidates or request.top_k * self._s.retrieval_rerank_multiplier
            )
            candidates.sort(key=lambda c: (-c.preliminary, str(c.chunk_id)))
            pool = candidates[:pool_size]
            rows, timings.hydrate_ms = await self._timed(
                "hydrate", self._chunks.get_many_with_documents([c.chunk_id for c in pool])
            )
            rows_by_id: dict[UUID, ChunkWithDocument] = {r.id: r for r in rows}
            pool = [c for c in pool if c.chunk_id in rows_by_id]  # drop deleted docs

            # 6. rerank --------------------------------------------------------------
            reranked = False
            if opts.use_rerank and self._reranker.name != "none" and pool:
                docs = [
                    RerankDoc(
                        text=rows_by_id[c.chunk_id].content,
                        title=rows_by_id[c.chunk_id].document_title,
                    )
                    for c in pool
                ]
                scores, timings.rerank_ms = await self._timed(
                    "rerank", self._reranker.score(query, docs)
                )
                for cand, score in zip(pool, scores, strict=True):
                    cand.rerank = float(score)
                reranked = True

            w = self._s.reranker_weight if reranked else 0.0
            for cand in pool:
                base = cand.preliminary
                cand.final = (w * (cand.rerank or 0.0) + (1 - w) * base) if reranked else base
            pool.sort(key=lambda c: (-c.final, str(c.chunk_id)))
            top = pool[: request.top_k]

            # 7. assemble ------------------------------------------------------------
            results_out = [
                self._to_context_chunk(
                    c, rows_by_id[c.chunk_id], chunk_entities, opts.max_content_chars
                )
                for c in top
            ]
            timings.total_ms = self._ms(started)
            RETRIEVAL_CANDIDATES.observe(len(candidates))
            RETRIEVAL_REQUESTS_TOTAL.labels("ok").inc()
            self._audit_async(request, request_id, timings, len(results_out), len(candidates), "ok")
            return ContextRetrieveResponse(
                request_id=request_id,
                query=query,
                top_k=request.top_k,
                results=results_out,
                graph_context=graph_context,
                timings=timings,
                candidates_considered=len(candidates),
                reranker=self._reranker.name if reranked else "none",
                embedding_model=self._embedder.model_id,
                debug=debug if opts.include_debug else None,
            )
        except Exception:
            timings.total_ms = self._ms(started)
            RETRIEVAL_REQUESTS_TOTAL.labels("error").inc()
            self._audit_async(request, request_id, timings, 0, 0, "error")
            raise

    # ================================================================== helpers
    async def _timed(self, stage: str, awaitable: Awaitable[T]) -> tuple[T, float]:
        t0 = time.perf_counter()
        result = await awaitable
        ms = self._ms(t0)
        RETRIEVAL_STAGE_DURATION.labels(stage).observe(ms / 1000)
        return result, ms

    @staticmethod
    def _ms(since: float) -> float:
        return round((time.perf_counter() - since) * 1000, 3)

    @staticmethod
    def _to_context_chunk(
        cand: Candidate,
        row: ChunkWithDocument,
        chunk_entities: dict[str, list[EntityRef]],
        max_chars: int | None,
    ) -> ContextChunk:
        entities = chunk_entities.get(str(row.id))
        if entities is None:
            entities = [
                EntityRef(key=m["key"], name=m["name"], entity_type=str(m["entity_type"]))
                for m in row.metadata.get("entities", [])
                if isinstance(m, dict) and "key" in m
            ]
        content = truncate(row.content, max_chars) if max_chars else row.content
        return ContextChunk(
            chunk_id=row.id,
            document_id=row.document_id,
            document_title=row.document_title,
            source_system=row.source_system,
            uri=row.uri,
            chunk_index=row.chunk_index,
            section_path=row.section_path,
            content=content,
            token_count=row.token_count,
            scores=ScoreBreakdown(
                vector=cand.vector_score,
                keyword=cand.keyword_score,
                fused=round(cand.fused_norm, 6),
                graph_boost=round(cand.graph_boost, 6),
                rerank=round(cand.rerank, 6) if cand.rerank is not None else None,
                final=round(cand.final, 6),
            ),
            retrieval_paths=sorted(cand.paths),
            entities=entities,
            document_attributes=row.document_attributes,
        )

    def _audit_async(
        self,
        request: ContextRetrieveRequest,
        request_id: str | None,
        timings: StageTimings,
        results: int,
        candidates: int,
        status: str,
    ) -> None:
        """Persist the audit row without adding latency to the response."""
        coro = self._audit.record(
            action="context.retrieve",
            status=status,
            request_id=request_id,
            resource_type="context",
            latency_ms=timings.total_ms,
            details={
                "query_chars": len(request.effective_query()),
                "top_k": request.top_k,
                "results": results,
                "candidates": candidates,
                "options": request.options.model_dump(),
                "filters": request.filters.model_dump(mode="json", exclude_none=True),
                "timings": timings.model_dump(),
            },
        )
        task: asyncio.Task[Any] = asyncio.create_task(coro)
        self._background.add(task)

        def _done(t: asyncio.Task[Any]) -> None:
            self._background.discard(t)
            if not t.cancelled() and t.exception() is not None:
                log.warning("audit.write_failed", error=str(t.exception()))

        task.add_done_callback(_done)

    async def drain(self) -> None:
        """Await pending audit writes (used at shutdown)."""
        if self._background:
            await asyncio.gather(*self._background, return_exceptions=True)
