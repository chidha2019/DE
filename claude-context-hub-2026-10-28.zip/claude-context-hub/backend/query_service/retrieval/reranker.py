"""Rerankers: a lightweight cross-encoder (optional) and a BM25-based fallback.

All implementations return scores in ``[0, 1]`` aligned with the input order so
the engine can blend them with the fused retrieval score.
"""

from __future__ import annotations

import asyncio
import math
from collections import Counter
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any, Protocol

from ech_core.config import Settings
from ech_core.logging import get_logger
from ech_core.text import tokenize

log = get_logger(__name__)


@dataclass(frozen=True)
class RerankDoc:
    text: str
    title: str = ""


class Reranker(Protocol):
    name: str

    async def score(self, query: str, docs: Sequence[RerankDoc]) -> list[float]: ...


class NoopReranker:
    name = "none"

    async def score(self, query: str, docs: Sequence[RerankDoc]) -> list[float]:
        return [0.0 for _ in docs]


class HeuristicReranker:
    """BM25 over the candidate pool + exact-phrase and title bonuses.

    The pool itself is the corpus, so IDF reflects how discriminative each term
    is *among the candidates* — exactly what matters when re-ordering them.
    """

    name = "heuristic"

    def __init__(self, *, k1: float = 1.5, b: float = 0.75) -> None:
        self.k1 = k1
        self.b = b

    async def score(self, query: str, docs: Sequence[RerankDoc]) -> list[float]:
        if not docs:
            return []
        q_terms = [t for t in tokenize(query, drop_stopwords=True)] or tokenize(query)
        if not q_terms:
            return [0.0 for _ in docs]
        q_unique = list(dict.fromkeys(q_terms))

        tokenized = [tokenize(d.text) for d in docs]
        n = len(docs)
        avgdl = max(1.0, sum(len(t) for t in tokenized) / n)
        df: Counter[str] = Counter()
        for toks in tokenized:
            present = set(toks)
            for t in q_unique:
                if t in present:
                    df[t] += 1

        raw: list[float] = []
        q_lower = query.casefold().strip()
        for doc, toks in zip(docs, tokenized, strict=True):
            tf = Counter(toks)
            dl = len(toks)
            bm25 = 0.0
            for t in q_unique:
                f = tf.get(t, 0)
                if f == 0:
                    continue
                idf = math.log(1 + (n - df[t] + 0.5) / (df[t] + 0.5))
                denom = f + self.k1 * (1 - self.b + self.b * dl / avgdl)
                bm25 += idf * f * (self.k1 + 1) / denom
            # Bonuses are additive on top of BM25 but bounded.
            title_terms = set(tokenize(doc.title)) if doc.title else set()
            title_overlap = sum(1 for t in q_unique if t in title_terms) / len(q_unique)
            phrase = 1.0 if len(q_lower) > 3 and q_lower in doc.text.casefold() else 0.0
            raw.append(bm25 + 0.6 * title_overlap + 0.8 * phrase)

        top = max(raw) if raw else 0.0
        if top <= 0:
            return [0.0 for _ in docs]
        return [round(s / top, 6) for s in raw]


class CrossEncoderReranker:
    """sentence-transformers CrossEncoder (e.g. ``cross-encoder/ms-marco-MiniLM-L-6-v2``).

    Loaded lazily in a worker thread; falls back to :class:`HeuristicReranker`
    if the optional dependency is missing so the service keeps serving.
    """

    name = "cross_encoder"

    def __init__(self, model_name: str, *, max_length: int = 512) -> None:
        self.model_name = model_name
        self._max_length = max_length
        self._model: Any = None
        self._lock = asyncio.Lock()
        self._fallback = HeuristicReranker()
        self._disabled = False

    async def _ensure_loaded(self) -> Any | None:
        if self._model is not None or self._disabled:
            return self._model
        async with self._lock:
            if self._model is None and not self._disabled:
                try:
                    self._model = await asyncio.to_thread(self._load)
                    log.info("reranker.loaded", model=self.model_name)
                except Exception as exc:  # noqa: BLE001 - degrade, do not crash
                    self._disabled = True
                    log.warning(
                        "reranker.unavailable",
                        model=self.model_name,
                        error=str(exc),
                        fallback=self._fallback.name,
                    )
        return self._model

    def _load(self) -> Any:
        from sentence_transformers import CrossEncoder  # type: ignore[import-not-found]

        return CrossEncoder(self.model_name, max_length=self._max_length)

    async def score(self, query: str, docs: Sequence[RerankDoc]) -> list[float]:
        if not docs:
            return []
        model = await self._ensure_loaded()
        if model is None:
            return await self._fallback.score(query, docs)
        pairs = [(query, f"{d.title}\n{d.text}" if d.title else d.text) for d in docs]
        logits = await asyncio.to_thread(model.predict, pairs, show_progress_bar=False)
        return [1.0 / (1.0 + math.exp(-float(x))) for x in logits]


def build_reranker(settings: Settings) -> Reranker:
    if settings.reranker_provider == "cross_encoder":
        return CrossEncoderReranker(settings.reranker_model)
    if settings.reranker_provider == "none":
        return NoopReranker()
    return HeuristicReranker()
