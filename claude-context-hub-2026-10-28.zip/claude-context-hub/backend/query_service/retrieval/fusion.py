"""Reciprocal Rank Fusion (RRF) of the dense and lexical retrieval legs.

RRF is robust to the very different score distributions of cosine similarity
and ``ts_rank_cd``: each leg contributes ``w / (k + rank)`` and the sums are
normalised to ``[0, 1]`` so downstream weights are interpretable.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from uuid import UUID

from ech_core.domain.models import ScoredChunk


@dataclass
class Candidate:
    chunk_id: UUID
    document_id: UUID
    vector_score: float | None = None
    vector_rank: int | None = None
    keyword_score: float | None = None
    keyword_rank: int | None = None
    fused: float = 0.0
    fused_norm: float = 0.0
    graph_boost: float = 0.0
    graph_via: list[str] = field(default_factory=list)
    rerank: float | None = None
    final: float = 0.0
    paths: set[str] = field(default_factory=set)

    @property
    def preliminary(self) -> float:
        """Score used to pick the rerank pool before the reranker runs."""
        return min(1.0, self.fused_norm + self.graph_boost)


def reciprocal_rank_fusion(
    legs: Mapping[str, Sequence[ScoredChunk]],
    *,
    k: int = 60,
    weights: Mapping[str, float] | None = None,
) -> list[Candidate]:
    """Fuse ranked lists keyed by leg name (``"vector"``, ``"keyword"``).

    Returns candidates sorted by fused score (descending); ``fused_norm`` is
    ``fused / max(fused)`` so the top candidate always scores 1.0.
    """
    weights = weights or {}
    merged: dict[UUID, Candidate] = {}
    for leg, hits in legs.items():
        w = float(weights.get(leg, 1.0))
        for rank, hit in enumerate(hits, start=1):
            cand = merged.get(hit.chunk_id)
            if cand is None:
                cand = Candidate(chunk_id=hit.chunk_id, document_id=hit.document_id)
                merged[hit.chunk_id] = cand
            cand.fused += w / (k + rank)
            cand.paths.add(leg)
            if leg == "vector":
                cand.vector_score = max(0.0, min(1.0, float(hit.score)))
                cand.vector_rank = rank
            elif leg == "keyword":
                cand.keyword_score = max(0.0, min(1.0, float(hit.score)))
                cand.keyword_rank = rank

    candidates = list(merged.values())
    if not candidates:
        return []
    top = max(c.fused for c in candidates) or 1.0
    for c in candidates:
        c.fused_norm = c.fused / top
    candidates.sort(key=lambda c: (-c.fused, str(c.chunk_id)))
    return candidates
