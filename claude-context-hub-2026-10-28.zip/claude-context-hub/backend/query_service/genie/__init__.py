"""Genie: Databricks-Genie-style conversational access to the Enterprise Context Hub.

A *space* curates scope (retrieval filters), standing instructions and sample
questions. A question runs a short tool loop - hybrid search over the hub, read-only
Cypher against the entity graph, document reads, lineage - streams the answer over
SSE and persists it with ``[S#]`` citations, the tool trace (the Cypher that ran, as
Genie shows its SQL), follow-up suggestions, token usage and feedback.
"""

from query_service.genie.service import GenieService, build_model_client

__all__ = ["GenieService", "build_model_client"]
