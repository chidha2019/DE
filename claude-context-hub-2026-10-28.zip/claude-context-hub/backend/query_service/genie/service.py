"""Genie orchestration: spaces, conversations and the streamed tool loop behind ``ask``."""

from __future__ import annotations

import asyncio
import json
import os
import re
import time
from collections.abc import AsyncIterator
from contextlib import suppress
from dataclasses import dataclass
from typing import Any
from uuid import UUID

from ech_core.config import Settings
from ech_core.db.neo4j import GraphDatabase
from ech_core.exceptions import (
    ConflictError,
    DependencyUnavailableError,
    InvalidRequestError,
    NotFoundError,
)
from ech_core.llm import (
    AnthropicModelClient,
    ModelClient,
    ModelConfigError,
    ModelTurn,
    detect_provider,
)
from ech_core.logging import get_logger
from ech_core.repositories import AuditRepository, ChunkRepository, DocumentRepository
from ech_core.repositories.genie_repository import GenieRepository
from ech_core.schemas.common import Page
from ech_core.schemas.genie import (
    GenieAskRequest,
    GenieCitation,
    GenieConversationDetail,
    GenieConversationOut,
    GenieMessageOut,
    GenieSpaceIn,
    GenieSpaceOut,
    GenieSpaceUpdate,
    GenieStatus,
)
from query_service.genie.prompts import build_system_prompt
from query_service.genie.tools import TOOLS, GenieToolbox, SourceRegistry
from query_service.retrieval.engine import HybridRetrievalEngine
from query_service.services.graph_service import GraphService

log = get_logger(__name__)

_FOLLOW_UPS_LINE = re.compile(
    r"^[ \t]*\**FOLLOW_UPS\**[ \t]*:[ \t]*(\[.*?\])[ \t]*\**[ \t]*$", re.M | re.S
)
_FOLLOW_UPS_SECTION = re.compile(
    r"\n[ \t]*(?:#+[ \t]*|\*\*)?follow[- ]?ups?(?: questions)?\**:?[ \t]*\n"
    r"((?:[ \t]*[-*\d.]+[ \t]+.+\n?)+)\s*$",
    re.I,
)
_MARKER = re.compile(r"\[(S\d+)\]")
_USAGE_KEYS = (
    "input_tokens",
    "output_tokens",
    "cache_creation_input_tokens",
    "cache_read_input_tokens",
)


@dataclass
class GenieModelConfig:
    """Satisfies :class:`ech_core.llm.LLMConfig` from the service settings."""

    model: str | None
    effort: str
    max_tokens: int
    fallbacks: bool
    provider: str
    base_url: str | None


def build_model_client(settings: Settings) -> tuple[AnthropicModelClient | None, str | None]:
    """The configured model client, or ``None`` and the reason Genie is unavailable."""
    if not settings.genie_enabled:
        return None, "Genie is disabled (ECH_GENIE_ENABLED=false)"
    provider = settings.llm_provider
    if provider == "auto":
        provider = detect_provider(settings.llm_base_url or None)
    if provider == "anthropic" and not (
        os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN")
    ):
        return None, (
            "no Claude credentials: set DATABRICKS_HOST and DATABRICKS_TOKEN for a Databricks-hosted "
            "model, or ANTHROPIC_API_KEY for the Claude API"
        )
    config = GenieModelConfig(
        model=settings.llm_model or None,
        effort=settings.llm_effort,
        max_tokens=settings.llm_max_tokens,
        fallbacks=settings.llm_fallbacks,
        provider=provider,
        base_url=settings.llm_base_url or None,
    )
    try:
        return AnthropicModelClient(config), None
    except ModelConfigError as exc:
        return None, str(exc)
    except ImportError:
        return None, "the anthropic SDK is not installed (pip install anthropic)"


class GenieService:
    def __init__(
        self,
        *,
        repo: GenieRepository,
        engine: HybridRetrievalEngine,
        documents: DocumentRepository,
        chunks: ChunkRepository,
        graph: GraphService,
        graph_db: GraphDatabase,
        audit: AuditRepository,
        settings: Settings,
        model: ModelClient | None,
        unavailable_reason: str | None = None,
        semantic: Any | None = None,
    ) -> None:
        self._repo = repo
        self._engine = engine
        self._documents = documents
        self._chunks = chunks
        self._graph = graph
        self._graph_db = graph_db
        self._audit = audit
        self._settings = settings
        self._model = model
        self._reason = unavailable_reason
        self._semantic = semantic

    # ------------------------------------------------------------------ status
    def status(self) -> GenieStatus:
        client = self._model if isinstance(self._model, AnthropicModelClient) else None
        return GenieStatus(
            enabled=self._settings.genie_enabled,
            configured=self._model is not None,
            provider=client.profile.name if client else None,
            model=client.model if client else getattr(self._model, "model", None),
            host=client.host if client else None,
            credential=client.token_source if client else None,
            reason=self._reason,
            degraded_fields=list(client.degraded) if client else [],
        )

    # ------------------------------------------------------------------ spaces
    async def list_spaces(self) -> list[GenieSpaceOut]:
        return [GenieSpaceOut.model_validate(r) for r in await self._repo.list_spaces()]

    async def get_space(self, space_id: UUID) -> GenieSpaceOut:
        row = await self._repo.get_space(space_id)
        if row is None:
            raise NotFoundError(f"Genie space {space_id} not found")
        return GenieSpaceOut.model_validate(row)

    async def create_space(self, data: GenieSpaceIn) -> GenieSpaceOut:
        row = await self._repo.create_space(
            name=data.name.strip(),
            description=data.description.strip(),
            instructions=data.instructions.strip(),
            filters=data.filters.model_dump(mode="json", exclude_none=True),
            sample_questions=[q.strip() for q in data.sample_questions if q.strip()],
        )
        return GenieSpaceOut.model_validate(row)

    async def update_space(self, space_id: UUID, patch: GenieSpaceUpdate) -> GenieSpaceOut:
        fields = patch.model_dump(exclude_unset=True)
        if "filters" in fields and patch.filters is not None:
            fields["filters"] = patch.filters.model_dump(mode="json", exclude_none=True)
        if "sample_questions" in fields and fields["sample_questions"] is not None:
            fields["sample_questions"] = [
                q.strip() for q in fields["sample_questions"] if q.strip()
            ]
        row = await self._repo.update_space(space_id, fields)
        if row is None:
            raise NotFoundError(f"Genie space {space_id} not found")
        return GenieSpaceOut.model_validate(row)

    async def delete_space(self, space_id: UUID) -> None:
        space = await self.get_space(space_id)
        if space.is_default:
            raise ConflictError("the default space cannot be deleted")
        if not await self._repo.delete_space(space_id):
            raise NotFoundError(f"Genie space {space_id} not found")

    # ------------------------------------------------------------------ conversations
    async def list_conversations(
        self, space_id: UUID, *, limit: int, offset: int
    ) -> Page[GenieConversationOut]:
        await self.get_space(space_id)
        rows, total = await self._repo.list_conversations(space_id, limit=limit, offset=offset)
        return Page(
            items=[GenieConversationOut.model_validate(r) for r in rows],
            total=total,
            limit=limit,
            offset=offset,
        )

    async def get_conversation(self, conversation_id: UUID) -> GenieConversationDetail:
        row = await self._repo.get_conversation(conversation_id)
        if row is None:
            raise NotFoundError(f"conversation {conversation_id} not found")
        messages = await self._repo.list_messages(conversation_id)
        return GenieConversationDetail.model_validate(
            {**row, "messages": [GenieMessageOut.model_validate(m) for m in messages]}
        )

    async def delete_conversation(self, conversation_id: UUID) -> None:
        if not await self._repo.delete_conversation(conversation_id):
            raise NotFoundError(f"conversation {conversation_id} not found")

    async def set_feedback(self, message_id: UUID, value: int | None) -> GenieMessageOut:
        row = await self._repo.set_feedback(message_id, value)
        if row is None:
            raise NotFoundError(f"assistant message {message_id} not found")
        return GenieMessageOut.model_validate(row)

    # ------------------------------------------------------------------ ask
    async def ask(
        self, space_id: UUID, request: GenieAskRequest, *, request_id: str | None = None
    ) -> AsyncIterator[tuple[str, dict[str, Any]]]:
        """Yield ``(event_type, payload)`` pairs; see ``GenieStreamEvent`` for the contract.

        Errors that make the request invalid (unknown space, no model configured) are raised
        before the first event, so the API can answer with a proper status code.
        """
        space = await self.get_space(space_id)
        if self._model is None:
            raise DependencyUnavailableError(
                "Genie has no model configured", details={"reason": self._reason}
            )
        if request.conversation_id is not None:
            conversation = await self._repo.get_conversation(request.conversation_id)
            if conversation is None:
                raise NotFoundError(f"conversation {request.conversation_id} not found")
            if conversation["space_id"] != space.id:
                raise InvalidRequestError("that conversation belongs to another space")
        else:
            conversation = await self._repo.create_conversation(
                space.id, _title_for(request.question)
            )
        conversation_id: UUID = conversation["id"]
        history_rows = await self._repo.list_messages(conversation_id)
        user_row = await self._repo.add_message(
            conversation_id, role="user", content=request.question.strip()
        )
        fresh = await self._repo.get_conversation(conversation_id)
        yield (
            "conversation",
            {
                "conversation": _dump(GenieConversationOut.model_validate(fresh or conversation)),
                "user_message": _dump(GenieMessageOut.model_validate(user_row)),
            },
        )

        sources = SourceRegistry(
            [c for m in history_rows if m["role"] == "assistant" for c in (m["citations"] or [])]
        )
        toolbox = GenieToolbox(
            engine=self._engine,
            documents=self._documents,
            chunks=self._chunks,
            graph=self._graph,
            graph_db=self._graph_db,
            space=space,
            sources=sources,
            settings=self._settings,
            semantic=self._semantic,
        )
        system = build_system_prompt(space)
        messages = _history(history_rows, self._settings.genie_history_messages)
        messages.append({"role": "user", "content": request.question.strip()})

        started = time.perf_counter()
        usage = dict.fromkeys(_USAGE_KEYS, 0)
        answer = ""
        live_text = ""
        status = "complete"
        error: str | None = None
        model_name: str | None = None
        turns = 0
        finalized = False
        try:
            try:
                for _ in range(self._settings.genie_max_turns):
                    turns += 1
                    turn: ModelTurn | None = None
                    live_text = ""
                    async for event in self._model.stream(
                        system=system, tools=TOOLS, messages=messages
                    ):
                        if event.kind == "text":
                            live_text += event.text
                            yield "delta", {"text": event.text}
                        else:
                            turn = event.turn
                    assert turn is not None
                    for key in _USAGE_KEYS:
                        usage[key] += int(turn.usage.get(key) or 0)
                    model_name = turn.model or model_name
                    messages.append({"role": "assistant", "content": turn.content})
                    tool_uses = turn.tool_uses

                    if turn.stop_reason == "refusal":
                        answer = turn.text.strip() or "I can't help with that request."
                        break
                    if not tool_uses:
                        answer = turn.text
                        if turn.stop_reason == "max_tokens":
                            answer += "\n\n_(the answer was cut off by the token limit)_"
                        break

                    narration = turn.text.strip() or None
                    if narration:
                        yield "turn_reset", {"text": narration}
                    results: list[dict[str, Any]] = []
                    for index, tool_use in enumerate(tool_uses):
                        yield (
                            "step",
                            {
                                "step": len(toolbox.steps) + 1,
                                "tool": tool_use["name"],
                                "input": tool_use.get("input") or {},
                            },
                        )
                        outcome, step = await toolbox.execute(
                            tool_use["name"],
                            tool_use.get("input"),
                            narration=narration if index == 0 else None,
                        )
                        yield "step_done", step.as_dict()
                        block: dict[str, Any] = {
                            "type": "tool_result",
                            "tool_use_id": tool_use["id"],
                            "content": outcome.content,
                        }
                        if outcome.is_error:
                            block["is_error"] = True
                        results.append(block)
                    if turn.stop_reason == "max_tokens":
                        results.append(
                            {
                                "type": "text",
                                "text": "Your previous message was cut off by max_tokens. "
                                "Continue; re-issue any truncated tool call.",
                            }
                        )
                    messages.append({"role": "user", "content": results})
                else:
                    answer = live_text or (
                        "I reached the step limit before finishing. Try a narrower question."
                    )
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001 - the failure becomes the persisted answer
                log.exception("genie.ask_failed", conversation_id=str(conversation_id))
                status, error = "error", f"{type(exc).__name__}: {exc}"
                answer = live_text

            follow_ups, answer = _split_follow_ups(answer)
            citations, answer = _resolve_citations(answer, sources)
            latency_ms = int((time.perf_counter() - started) * 1000)
            row = await self._repo.add_message(
                conversation_id,
                role="assistant",
                content=answer.strip(),
                status=status,
                error=error,
                citations=[c.model_dump(mode="json") for c in citations],
                trace=[s.as_dict() for s in toolbox.steps],
                follow_ups=follow_ups,
                usage=usage,
                model=model_name or getattr(self._model, "model", None),
                latency_ms=latency_ms,
            )
            finalized = True
            message = GenieMessageOut.model_validate(row)
            await self._record_audit(
                space, conversation_id, status, request_id, latency_ms, turns, toolbox, usage
            )
            if status == "error":
                yield "error", {"error": error, "message": _dump(message)}
            else:
                yield "message", _dump(message)
        finally:
            if not finalized:  # the client went away mid-answer: keep what was said
                with suppress(Exception):
                    await self._repo.add_message(
                        conversation_id,
                        role="assistant",
                        content=live_text.strip(),
                        status="cancelled",
                        trace=[s.as_dict() for s in toolbox.steps],
                        usage=usage,
                        model=model_name,
                        latency_ms=int((time.perf_counter() - started) * 1000),
                    )

    async def _record_audit(
        self,
        space: GenieSpaceOut,
        conversation_id: UUID,
        status: str,
        request_id: str | None,
        latency_ms: int,
        turns: int,
        toolbox: GenieToolbox,
        usage: dict[str, int],
    ) -> None:
        try:
            await self._audit.record(
                action="genie.ask",
                status="ok" if status == "complete" else status,
                resource_type="genie_conversation",
                resource_id=str(conversation_id),
                request_id=request_id,
                latency_ms=float(latency_ms),
                details={
                    "space_id": str(space.id),
                    "turns": turns,
                    "tools": [s.tool for s in toolbox.steps],
                    "usage": usage,
                },
            )
        except Exception:  # noqa: BLE001 - auditing must never break the answer
            log.warning("genie.audit_failed", conversation_id=str(conversation_id))


# ----------------------------------------------------------------------------- helpers
def _dump(model: Any) -> dict[str, Any]:
    return model.model_dump(mode="json")


def _title_for(question: str) -> str:
    first = question.strip().splitlines()[0].strip() if question.strip() else "New conversation"
    return first if len(first) <= 80 else first[:79].rstrip() + "…"


def _history(rows: list[dict[str, Any]], limit: int) -> list[dict[str, Any]]:
    """Earlier turns as alternating user/assistant text messages (tool blocks are not kept)."""
    messages: list[dict[str, Any]] = []
    for row in rows[-limit:] if limit else []:
        content = (row.get("content") or "").strip()
        if row["role"] == "assistant" and (not content or row.get("status") != "complete"):
            content = content or "(no answer was produced)"
        if not content:
            continue
        if messages and messages[-1]["role"] == row["role"]:
            messages[-1]["content"] += "\n\n" + content  # the API wants alternating roles
        else:
            messages.append({"role": row["role"], "content": content})
    if messages and messages[0]["role"] == "assistant":
        messages.pop(0)
    if messages and messages[-1]["role"] == "user":
        messages.pop()  # the new question follows; never two user turns in a row
    return messages


def _split_follow_ups(answer: str) -> tuple[list[str], str]:
    match = _FOLLOW_UPS_LINE.search(answer)
    if match:
        follow_ups: list[str] = []
        with suppress(ValueError):
            parsed = json.loads(match.group(1))
            follow_ups = [str(q).strip() for q in parsed if str(q).strip()]
        if not follow_ups:
            follow_ups = re.findall(r'"([^"]{5,})"', match.group(1))
        return follow_ups[:4], (answer[: match.start()] + answer[match.end() :]).rstrip()
    section = _FOLLOW_UPS_SECTION.search(answer)
    if section:
        items = [
            re.sub(r"^[ \t]*[-*\d.]+[ \t]+", "", line).strip()
            for line in section.group(1).splitlines()
            if line.strip()
        ]
        return items[:4], answer[: section.start()].rstrip()
    return [], answer.rstrip()


def _resolve_citations(answer: str, sources: SourceRegistry) -> tuple[list[GenieCitation], str]:
    """Citations in order of first appearance; markers the model invented are removed."""
    seen: list[GenieCitation] = []
    for marker in _MARKER.findall(answer):
        citation = sources.get(marker)
        if citation is not None and citation not in seen:
            seen.append(citation)

    def keep(match: re.Match[str]) -> str:
        return match.group(0) if sources.get(match.group(1)) is not None else ""

    return seen, _MARKER.sub(keep, answer)
