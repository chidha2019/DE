"""Genie's tools: what the model may do against the hub, and the guardrails around it.

Every tool input is a pydantic model validated *before* execution (strict schemas on the
wire, bounds enforced here). ``query_graph`` is the Genie analogue of generated SQL: a
read-only Cypher statement, guarded by :func:`guard_cypher`, run in a managed read
transaction with a timeout and a row cap, and echoed back in the trace.
"""

from __future__ import annotations

import asyncio
import json
import re
import time
from dataclasses import asdict, dataclass
from typing import Any, Literal
from uuid import UUID

from pydantic import BaseModel, Field, ValidationError

from ech_core.config import Settings
from ech_core.db.neo4j import GraphDatabase
from ech_core.domain.models import DocumentRecord
from ech_core.exceptions import ECHError
from ech_core.llm import strict_tool_schema
from ech_core.logging import get_logger
from ech_core.repositories import ChunkRepository, DocumentRepository
from ech_core.schemas.context import ContextRetrieveRequest, RetrievalOptions
from ech_core.schemas.genie import GenieCitation, GenieSpaceOut
from query_service.retrieval.engine import HybridRetrievalEngine
from query_service.services.graph_service import GraphService
from query_service.services.semantic_service import SemanticService, SemanticSource

log = get_logger(__name__)


# ----------------------------------------------------------------------------- inputs
class SearchKnowledgeInput(BaseModel):
    query: str = Field(
        min_length=2,
        max_length=1000,
        description="natural-language question or keywords; specific technical phrasing works best",
    )
    top_k: int = Field(ge=1, le=12, description="how many chunks to return")
    use_graph: bool = Field(
        description="also expand through the entity graph (related documents, dependencies)"
    )


class QueryGraphInput(BaseModel):
    cypher: str = Field(
        min_length=6,
        max_length=4000,
        description="read-only Cypher: MATCH / OPTIONAL MATCH / WITH / UNWIND / RETURN / ORDER BY / LIMIT",
    )
    purpose: str = Field(
        min_length=1, max_length=300, description="one line: the question this query answers"
    )


class FindDocumentsInput(BaseModel):
    search: str = Field(min_length=1, max_length=200, description="title or path substring")
    limit: int = Field(ge=1, le=25)


class ReadDocumentInput(BaseModel):
    document_id: str = Field(
        min_length=36, max_length=36, description="document UUID from search or graph results"
    )
    max_chars: int = Field(ge=500, le=20_000, description="how much of the document to read")


class GetLineageInput(BaseModel):
    document_id: str = Field(min_length=36, max_length=36)
    depth: int = Field(ge=1, le=4, description="hops of REFERENCES to follow")


EntityKind = Literal["Person", "Project", "Technology", "Concept", "any"]


class ExploreEntityInput(BaseModel):
    name: str = Field(
        min_length=1, max_length=120, description="entity name, e.g. 'DuckDB' or 'Priya Natarajan'"
    )
    entity_type: EntityKind


class SemanticSearchInput(BaseModel):
    query: str = Field(
        min_length=1,
        max_length=200,
        description="a table, column or metric name fragment, or a business term such as 'premium'",
    )
    limit: int = Field(ge=1, le=50)


class DescribeAssetInput(BaseModel):
    name: str = Field(
        min_length=1,
        max_length=300,
        description="fully qualified name (catalog.schema.table) or just the table name",
    )


TOOLS: list[dict[str, Any]] = [
    {
        "name": "search_knowledge",
        "description": (
            "Hybrid (vector + keyword) search over the hub within this space's scope, optionally "
            "expanded through the entity graph. Returns ranked chunks labelled [S#]; cite those "
            "labels. Call this first for any question about content."
        ),
        "input_schema": strict_tool_schema(SearchKnowledgeInput),
    },
    {
        "name": "query_graph",
        "description": (
            "Run a read-only Cypher query against the knowledge graph (schema in the system prompt). "
            "Use it for structural questions: who contributed, what depends on what, which documents "
            "mention an entity, counts and rankings. Results come back as rows; the query is shown "
            "to the user."
        ),
        "input_schema": strict_tool_schema(QueryGraphInput),
    },
    {
        "name": "find_documents",
        "description": "List indexed documents whose title or path contains a substring (within scope).",
        "input_schema": strict_tool_schema(FindDocumentsInput),
    },
    {
        "name": "read_document",
        "description": (
            "Read a whole document (all chunks, labelled [S#]) when search snippets are not enough, "
            "e.g. to summarise a file or quote exact configuration."
        ),
        "input_schema": strict_tool_schema(ReadDocumentInput),
    },
    {
        "name": "get_lineage",
        "description": (
            "Which documents reference this one, which it references (imports, links, manifests) "
            "and who contributed, from the graph."
        ),
        "input_schema": strict_tool_schema(GetLineageInput),
    },
    {
        "name": "explore_entity",
        "description": (
            "Look an entity up by name: where it is mentioned, what it depends on and what depends "
            "on it, who contributed to those documents."
        ),
        "input_schema": strict_tool_schema(ExploreEntityInput),
    },
    {
        "name": "semantic_search",
        "description": (
            "Search the semantic layer built from Snowflake / Databricks catalog metadata: tables, "
            "views, metric views, columns with roles (identifier, dimension, time, measure) and "
            "metrics. Use it to find which dataset holds a business concept before describing it. "
            "Every hit is labelled [S#] by its asset; cite those labels."
        ),
        "input_schema": strict_tool_schema(SemanticSearchInput),
    },
    {
        "name": "describe_asset",
        "description": (
            "Everything the semantic layer knows about one dataset: columns with roles and keys, "
            "joins (declared and inferred), lineage, declared and inferred metrics and the view or "
            "metric-view definition. Use it for 'what is in X', 'how do I join X to Y', 'which "
            "metrics exist on X' and before writing SQL against X. The asset is labelled [S#]; "
            "cite it for the columns, joins, lineage and metrics you report."
        ),
        "input_schema": strict_tool_schema(DescribeAssetInput),
    },
]

_INPUT_MODELS: dict[str, type[BaseModel]] = {
    "search_knowledge": SearchKnowledgeInput,
    "query_graph": QueryGraphInput,
    "find_documents": FindDocumentsInput,
    "read_document": ReadDocumentInput,
    "get_lineage": GetLineageInput,
    "explore_entity": ExploreEntityInput,
    "semantic_search": SemanticSearchInput,
    "describe_asset": DescribeAssetInput,
}


# ----------------------------------------------------------------------------- cypher guard
class CypherRejectedError(ValueError):
    pass


_STRING_LITERAL = re.compile(r"'(?:[^'\\]|\\.)*'|\"(?:[^\"\\]|\\.)*\"")
_LINE_COMMENT = re.compile(r"//[^\n]*")
_BLOCK_COMMENT = re.compile(r"/\*.*?\*/", re.S)
_ALLOWED_START = re.compile(r"^\s*(MATCH|OPTIONAL\s+MATCH|WITH|UNWIND|RETURN)\b", re.I)
_FORBIDDEN = re.compile(
    r"\b(CREATE|MERGE|DELETE|DETACH|SET|REMOVE|DROP|LOAD|FOREACH|CALL|USE|ALTER|GRANT|REVOKE"
    r"|DENY|SHOW|TERMINATE|START|COMMIT|ROLLBACK|BEGIN|INDEX|CONSTRAINT)\b",
    re.I,
)
_TRAILING_LIMIT = re.compile(r"\bLIMIT\s+(\d+)\s*$", re.I)
_ANY_LIMIT = re.compile(r"\bLIMIT\s+(\d+)", re.I)


def guard_cypher(cypher: str, *, row_limit: int) -> str:
    """Return the statement to run, or raise :class:`CypherRejectedError`.

    One statement, read-only clauses only (checked outside string literals and comments),
    and every ``LIMIT`` capped at ``row_limit`` (one is appended when the query has none).
    """
    text = cypher.strip().rstrip(";").strip()
    if not text:
        raise CypherRejectedError("empty query")
    scan = _STRING_LITERAL.sub("''", text)
    scan = _BLOCK_COMMENT.sub(" ", _LINE_COMMENT.sub(" ", scan))
    if ";" in scan:
        raise CypherRejectedError("one statement only")
    if not _ALLOWED_START.match(scan):
        raise CypherRejectedError("must start with MATCH, OPTIONAL MATCH, WITH, UNWIND or RETURN")
    hit = _FORBIDDEN.search(scan)
    if hit:
        raise CypherRejectedError(f"read-only queries only: {hit.group(1).upper()} is not allowed")
    if _TRAILING_LIMIT.search(scan) is None:
        text = f"{text}\nLIMIT {row_limit}"
    return _ANY_LIMIT.sub(lambda m: f"LIMIT {min(int(m.group(1)), row_limit)}", text)


# ----------------------------------------------------------------------------- outcomes
@dataclass
class ToolOutcome:
    content: str
    is_error: bool = False


@dataclass
class ToolStep:
    step: int
    tool: str
    summary: str
    input: dict[str, Any]
    detail: str | None = None
    ok: bool = True
    duration_ms: float = 0.0
    rows: int | None = None
    narration: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class SourceRegistry:
    """Stable ``[S#]`` markers for every chunk the model has seen in a conversation."""

    def __init__(self, existing: list[dict[str, Any]] | None = None) -> None:
        self._by_chunk: dict[str, GenieCitation] = {}
        self._by_marker: dict[str, GenieCitation] = {}
        for raw in existing or []:
            citation = GenieCitation.model_validate(raw)
            self._by_chunk[str(citation.chunk_id)] = citation
            self._by_marker[citation.marker] = citation
        numbers = [int(m[1:]) for m in self._by_marker if m[1:].isdigit()]
        self._next = max(numbers, default=0) + 1

    def register(self, **fields: Any) -> GenieCitation:
        key = str(fields["chunk_id"])
        existing = self._by_chunk.get(key)
        if existing is not None:
            if float(fields.get("score") or 0.0) > existing.score:
                existing.score = float(fields["score"])
            return existing
        citation = GenieCitation(marker=f"S{self._next}", **fields)
        self._next += 1
        self._by_chunk[key] = citation
        self._by_marker[citation.marker] = citation
        return citation

    def get(self, marker: str) -> GenieCitation | None:
        return self._by_marker.get(marker)

    def __len__(self) -> int:
        return len(self._by_chunk)


# ----------------------------------------------------------------------------- toolbox
class GenieToolbox:
    def __init__(
        self,
        *,
        engine: HybridRetrievalEngine,
        documents: DocumentRepository,
        chunks: ChunkRepository,
        graph: GraphService,
        graph_db: GraphDatabase,
        space: GenieSpaceOut,
        sources: SourceRegistry,
        settings: Settings,
        semantic: SemanticService | None = None,
    ) -> None:
        self._engine = engine
        self._documents = documents
        self._chunks = chunks
        self._graph = graph
        self._graph_db = graph_db
        self._semantic = semantic
        self.space = space
        self.sources = sources
        self._settings = settings
        self.steps: list[ToolStep] = []

    async def execute(
        self, name: str, raw_input: Any, *, narration: str | None = None
    ) -> tuple[ToolOutcome, ToolStep]:
        step = ToolStep(
            step=len(self.steps) + 1,
            tool=name,
            summary=name,
            input=_summarise(raw_input),
            narration=narration,
        )
        started = time.perf_counter()
        model = _INPUT_MODELS.get(name)
        if model is None:
            outcome = ToolOutcome(f"unknown tool {name!r}", is_error=True)
        elif not isinstance(raw_input, dict):
            outcome = ToolOutcome("tool input was not a JSON object; re-issue the call", True)
        else:
            try:
                args = model.model_validate(raw_input)
            except ValidationError as exc:
                outcome = ToolOutcome(
                    f"invalid input for {name}: {exc.errors(include_url=False)}", is_error=True
                )
            else:
                try:
                    outcome = await getattr(self, f"_{name}")(args, step)
                except ECHError as exc:
                    outcome = ToolOutcome(f"{name} failed: {exc}", is_error=True)
                except Exception as exc:  # noqa: BLE001 - a tool must never kill the answer
                    log.exception("genie.tool_failed", tool=name)
                    outcome = ToolOutcome(f"{name} failed: {type(exc).__name__}: {exc}", True)
        step.ok = not outcome.is_error
        step.duration_ms = round((time.perf_counter() - started) * 1000, 1)
        if outcome.is_error and step.summary == name:
            step.summary = f"{name} failed"
        self.steps.append(step)
        return outcome, step

    # ------------------------------------------------------------------ tools
    async def _search_knowledge(self, args: SearchKnowledgeInput, step: ToolStep) -> ToolOutcome:
        request = ContextRetrieveRequest(
            query=args.query,
            top_k=args.top_k,
            filters=self.space.filters,
            options=RetrievalOptions(
                use_graph=args.use_graph,
                include_graph_context=args.use_graph,
                max_content_chars=self._settings.genie_search_max_chars,
            ),
        )
        response = await self._engine.retrieve(request)
        lines: list[str] = []
        for result in response.results:
            citation = self.sources.register(
                chunk_id=result.chunk_id,
                document_id=result.document_id,
                title=result.document_title,
                path=result.document_attributes.get("path"),
                source_system=str(result.source_system),
                uri=result.uri,
                score=result.scores.final,
                chunk_index=result.chunk_index,
                snippet=_clip(result.content, 200),
            )
            section = f" › {' > '.join(result.section_path)}" if result.section_path else ""
            lines.append(
                f"[{citation.marker}] {result.document_title}{section}  "
                f"(document_id={result.document_id}, chunk {result.chunk_index}, "
                f"score {result.scores.final:.2f}, via {','.join(result.retrieval_paths)})"
            )
            lines.append(result.content.strip())
            lines.append("")
        graph = response.graph_context
        if graph and graph.nodes:
            related = sorted({n.label for n in graph.nodes if n.type == "Document"})[:15]
            entities = [k.split(":", 1)[-1] for k in graph.first_degree_entities][:12]
            lines.append(f"graph neighbourhood: related documents: {', '.join(related) or '-'}")
            lines.append(f"entities: {', '.join(entities) or '-'}")
        if not response.results:
            lines.append("no chunks matched within this space's scope")
        step.summary = (
            f'Searched "{_clip(args.query, 80)}" → {len(response.results)} chunks '
            f"from {response.candidates_considered} candidates"
        )
        step.rows = len(response.results)
        return ToolOutcome("\n".join(lines).strip())

    async def _query_graph(self, args: QueryGraphInput, step: ToolStep) -> ToolOutcome:
        step.summary = args.purpose
        step.detail = args.cypher.strip()
        try:
            cypher = guard_cypher(args.cypher, row_limit=self._settings.genie_cypher_row_limit)
        except CypherRejectedError as exc:
            return ToolOutcome(f"query rejected: {exc}", is_error=True)
        step.detail = cypher
        try:
            async with asyncio.timeout(self._settings.genie_cypher_timeout_seconds):
                rows = await self._graph_db.execute_read(cypher)
        except TimeoutError:
            return ToolOutcome(
                f"query timed out after {self._settings.genie_cypher_timeout_seconds:.0f}s; "
                "narrow the pattern or lower the LIMIT",
                is_error=True,
            )
        except ECHError:
            raise
        except Exception as exc:  # noqa: BLE001 - the driver's message helps the model fix the query
            return ToolOutcome(f"Cypher failed: {_clip(str(exc), 600)}", is_error=True)
        step.rows = len(rows)
        return ToolOutcome(_format_rows(rows, max_rows=self._settings.genie_cypher_row_limit))

    async def _find_documents(self, args: FindDocumentsInput, step: ToolStep) -> ToolOutcome:
        docs, _total = await self._documents.list(
            search=args.search,
            source_systems=self.space.filters.source_systems,
            limit=args.limit,
        )
        docs = [d for d in docs if self._in_scope(d)]
        step.summary = f'Found {len(docs)} documents for "{_clip(args.search, 60)}"'
        step.rows = len(docs)
        if not docs:
            return ToolOutcome("no documents matched within this space's scope")
        return ToolOutcome(
            "\n".join(
                f"{d.title}  (document_id={d.id}, source={d.source_system}, "
                f"path={d.attributes.get('path') or '-'}"
                + (f", chunks={d.chunk_count}" if d.chunk_count is not None else "")
                + ")"
                for d in docs
            )
        )

    async def _read_document(self, args: ReadDocumentInput, step: ToolStep) -> ToolOutcome:
        doc = await self._documents.get(UUID(args.document_id))
        if doc is None:
            return ToolOutcome("no such document", is_error=True)
        if not self._in_scope(doc):
            return ToolOutcome("that document is outside this space's scope", is_error=True)
        chunks = await self._chunks.list_for_document(doc.id)
        parts: list[str] = []
        used = 0
        for index, chunk in enumerate(chunks):
            remaining = args.max_chars - used
            if remaining <= 0:
                parts.append(f"... {len(chunks) - index} more chunks not shown (raise max_chars)")
                break
            citation = self.sources.register(
                chunk_id=chunk.id,
                document_id=doc.id,
                title=doc.title,
                path=doc.attributes.get("path"),
                source_system=str(doc.source_system),
                uri=doc.uri,
                score=1.0,
                chunk_index=chunk.chunk_index,
                snippet=_clip(chunk.content, 200),
            )
            text = _clip(chunk.content.strip(), remaining)
            used += len(text)
            section = f" › {' > '.join(chunk.section_path)}" if chunk.section_path else ""
            parts.append(f"[{citation.marker}] chunk {chunk.chunk_index}{section}\n{text}")
        step.summary = f"Read {doc.title}"
        step.rows = len(chunks)
        header = (
            f"{doc.title}  (document_id={doc.id}, source={doc.source_system}, "
            f"path={doc.attributes.get('path') or '-'}, {len(chunks)} chunks)"
        )
        return ToolOutcome(header + "\n\n" + "\n\n".join(parts))

    async def _get_lineage(self, args: GetLineageInput, step: ToolStep) -> ToolOutcome:
        payload = await self._graph.lineage(UUID(args.document_id), depth=args.depth)
        if payload is None:
            return ToolOutcome("that document is not in the graph yet (not synced)", True)
        labels = {n.id: n.label for n in payload.nodes}
        center = args.document_id
        referenced_by = sorted(
            labels.get(e.source, e.source)
            for e in payload.edges
            if e.type == "REFERENCES" and e.target == center
        )
        references = sorted(
            labels.get(e.target, e.target)
            for e in payload.edges
            if e.type == "REFERENCES" and e.source == center
        )
        contributors = [
            labels.get(e.target, e.target)
            for e in payload.edges
            if e.type == "CONTRIBUTED_BY" and e.source == center
        ]
        title = labels.get(center, center)
        step.summary = f"Lineage of {title}"
        step.rows = len(payload.edges)
        return ToolOutcome(
            f"{title} (document_id={center})\n"
            f"referenced by ({len(referenced_by)}): {', '.join(referenced_by) or '-'}\n"
            f"references ({len(references)}): {', '.join(references) or '-'}\n"
            f"contributors: {', '.join(contributors) or '-'}\n"
            f"lineage graph: {len(payload.nodes)} nodes / {len(payload.edges)} edges within "
            f"{args.depth} hops"
        )

    async def _explore_entity(self, args: ExploreEntityInput, step: ToolStep) -> ToolOutcome:
        entity_type = None if args.entity_type == "any" else args.entity_type
        hits = await self._graph.search_entities(args.name, entity_type=entity_type, limit=5)
        if not hits:
            return ToolOutcome(f"no entity matches {args.name!r}", is_error=True)
        best = hits[0]
        payload = await self._graph.entity_graph(best.key, max_documents=15)
        if payload is None:
            return ToolOutcome(f"entity {best.key} has no neighbourhood", is_error=True)
        labels = {n.id: n.label for n in payload.nodes}
        docs = [n for n in payload.nodes if n.type == "Document"]
        depends_on = [
            f"{labels.get(e.target, e.target)} (w={e.properties.get('weight', 1)})"
            for e in payload.edges
            if e.type == "DEPENDS_ON" and e.source == best.key
        ]
        depended_by = [
            f"{labels.get(e.source, e.source)} (w={e.properties.get('weight', 1)})"
            for e in payload.edges
            if e.type == "DEPENDS_ON" and e.target == best.key
        ]
        people = sorted({labels[n.id] for n in payload.nodes if n.type == "Person"})
        step.summary = f"Explored {best.entity_type} {best.name}"
        step.rows = len(docs)
        lines = [
            f"{best.name}  (type={best.entity_type}, key={best.key}, mentions={best.mention_count})",
            f"mentioned in {len(docs)} documents:",
            *[f"  - {d.label}  (document_id={d.id})" for d in docs],
            f"depends on: {', '.join(depends_on) or '-'}",
            f"depended on by: {', '.join(depended_by) or '-'}",
            f"contributors to those documents: {', '.join(people) or '-'}",
        ]
        if len(hits) > 1:
            lines.append("other matches: " + ", ".join(f"{h.name} ({h.key})" for h in hits[1:]))
        return ToolOutcome("\n".join(lines))

    async def _semantic_search(self, args: SemanticSearchInput, step: ToolStep) -> ToolOutcome:
        if self._semantic is None:
            return ToolOutcome("the semantic layer is not available on this hub", is_error=True)
        text = await self._semantic.search_for_genie(
            args.query, limit=args.limit, cite=self._cite_asset
        )
        step.summary = f'Semantic search "{_clip(args.query, 60)}"'
        step.rows = sum(1 for line in text.splitlines() if line.startswith("  "))
        return ToolOutcome(text)

    async def _describe_asset(self, args: DescribeAssetInput, step: ToolStep) -> ToolOutcome:
        if self._semantic is None:
            return ToolOutcome("the semantic layer is not available on this hub", is_error=True)
        text = await self._semantic.describe_for_genie(args.name, cite=self._cite_asset)
        if text is None:
            return ToolOutcome(
                f"no semantic asset matches {args.name!r}; try semantic_search first",
                is_error=True,
            )
        step.summary = f"Described {args.name}"
        step.rows = text.count("\n  ")
        return ToolOutcome(text)

    # ------------------------------------------------------------------ helpers
    def _cite_asset(self, source: SemanticSource) -> str:
        """Register a semantic asset as a source; its document id doubles as the chunk key."""
        citation = self.sources.register(
            chunk_id=source.asset_id,
            document_id=source.asset_id,
            title=source.fqn,
            path=source.fqn,
            source_system=source.platform,
            uri=source.uri,
            score=1.0,
            chunk_index=0,
            snippet=_clip(source.snippet, 200),
            kind="asset",
        )
        return citation.marker

    def _in_scope(self, doc: DocumentRecord) -> bool:
        filters = self.space.filters
        if filters.source_systems and doc.source_system not in filters.source_systems:
            return False
        if filters.document_ids and doc.id not in set(filters.document_ids):
            return False
        if filters.attributes:
            return all(doc.attributes.get(k) == v for k, v in filters.attributes.items())
        return True


# ----------------------------------------------------------------------------- formatting
def _clip(text: str, limit: int) -> str:
    text = text or ""
    return text if len(text) <= limit else text[: max(limit - 1, 0)] + "…"


def _cell(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return json.dumps(value, default=str, ensure_ascii=False)


def _format_rows(rows: list[dict[str, Any]], *, max_rows: int, cell_chars: int = 200) -> str:
    if not rows:
        return "0 rows"
    columns = list(rows[0].keys())
    lines = [f"{len(rows)} rows", " | ".join(columns)]
    for row in rows[:max_rows]:
        lines.append(" | ".join(_clip(_cell(row.get(c)), cell_chars) for c in columns))
    if len(rows) > max_rows:
        lines.append(f"... {len(rows) - max_rows} more rows")
    return "\n".join(lines)


def _summarise(value: Any, limit: int = 300) -> dict[str, Any]:
    if not isinstance(value, dict):
        return {"input": _clip(str(value), limit)}
    return {k: (_clip(v, limit) if isinstance(v, str) else v) for k, v in value.items()}
