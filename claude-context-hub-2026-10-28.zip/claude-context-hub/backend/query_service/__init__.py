"""Query & Context API Service.

Serves low-latency context to AI agents: hybrid (dense + lexical) retrieval over
pgvector/FTS, GraphRAG expansion through Neo4j, cross-encoder reranking, plus
explorer, lineage and dashboard statistics endpoints.
"""
