"""Thin async client for the hub's query and ingestion services."""

from __future__ import annotations

from typing import Any

import httpx


class HubError(RuntimeError):
    def __init__(self, status: int, message: str, details: Any = None) -> None:
        super().__init__(f"hub {status}: {message}")
        self.status = status
        self.details = details


class HubClient:
    """Wraps the endpoints an agent needs: retrieve, documents, lineage, graph, publish."""

    def __init__(
        self,
        *,
        query_url: str = "http://localhost:8002",
        ingestion_url: str = "http://localhost:8001",
        repo: str | None = None,
        timeout: float = 60.0,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self.query_url = query_url.rstrip("/")
        self.ingestion_url = ingestion_url.rstrip("/")
        self.repo = repo
        self._client = client or httpx.AsyncClient(timeout=httpx.Timeout(timeout, connect=10.0))

    async def aclose(self) -> None:
        await self._client.aclose()

    # ------------------------------------------------------------------ transport
    async def _request(self, method: str, url: str, **kwargs: Any) -> Any:
        response = await self._client.request(method, url, **kwargs)
        if response.status_code >= 400:
            try:
                err = response.json().get("error", {})
            except ValueError:
                err = {}
            raise HubError(
                response.status_code, err.get("message") or response.text[:200], err.get("details")
            )
        if response.status_code == 204:
            return None
        return response.json()

    def _repo_filter(self) -> dict[str, Any]:
        return {"attributes": {"repo": self.repo}} if self.repo else {}

    # ------------------------------------------------------------------ retrieval
    async def retrieve(
        self,
        query: str,
        *,
        top_k: int = 8,
        use_graph: bool = True,
        max_content_chars: int = 1800,
        agent_state: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "query": query,
            "top_k": top_k,
            "filters": self._repo_filter(),
            "options": {
                "use_graph": use_graph,
                "include_graph_context": use_graph,
                "max_content_chars": max_content_chars,
            },
        }
        if agent_state:
            body["agent_state"] = agent_state
        return await self._request("POST", f"{self.query_url}/api/v1/context/retrieve", json=body)

    async def search_documents(self, search: str, *, limit: int = 20) -> list[dict[str, Any]]:
        page = await self._request(
            "GET", f"{self.query_url}/api/v1/documents", params={"search": search, "limit": limit}
        )
        items = page.get("items", [])
        if self.repo:
            items = [d for d in items if d.get("attributes", {}).get("repo") == self.repo]
        return items

    async def find_document(self, path: str) -> dict[str, Any] | None:
        """Locate the hub document for a repository path (search by basename, match path)."""
        basename = path.rsplit("/", 1)[-1]
        for doc in await self.search_documents(basename, limit=50):
            if doc.get("attributes", {}).get("path") == path:
                return doc
        return None

    async def document_chunks(self, document_id: str) -> list[dict[str, Any]]:
        return await self._request("GET", f"{self.query_url}/api/v1/documents/{document_id}/chunks")

    async def lineage(self, document_id: str, *, depth: int = 2) -> dict[str, Any]:
        return await self._request(
            "GET",
            f"{self.query_url}/api/v1/documents/{document_id}/lineage",
            params={"depth": depth},
        )

    async def document_graph(self, document_id: str) -> dict[str, Any]:
        return await self._request("GET", f"{self.query_url}/api/v1/documents/{document_id}/graph")

    async def neighborhood(self, entity_key: str, *, max_documents: int = 15) -> dict[str, Any]:
        return await self._request(
            "GET",
            f"{self.query_url}/api/v1/graph/neighborhood",
            params={"entity_key": entity_key, "max_documents": max_documents},
        )

    # ------------------------------------------------------------------ publish
    async def publish_document(
        self,
        *,
        title: str,
        content: str,
        external_id: str,
        author: str | None = None,
        references: list[str] | None = None,
        attributes: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Ingest an agent-produced artifact so the next agent can retrieve it."""
        return await self._request(
            "POST",
            f"{self.ingestion_url}/api/v1/documents",
            json={
                "title": title,
                "content": content,
                "external_id": external_id,
                "author": author,
                "references": references or [],
                "attributes": attributes or {},
            },
        )
