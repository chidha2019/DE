"""Local workspace: a repository checkout the agent reads, writes and tests in.

Safety properties
-----------------
* every path is resolved and must stay inside the workspace root (no ``..``,
  no absolute paths, no symlink escapes);
* commands are allow-listed (``pytest``, ``ruff``, ``pip install -r <file>``/
  ``-e .``) and always run through a dedicated virtualenv inside the workspace,
  never the host interpreter's site-packages;
* everything the agent writes is tracked so the run can be reported and
  published back to the hub.
"""

from __future__ import annotations

import asyncio
import io
import re
import shlex
import shutil
import sys
import tarfile
import time
from dataclasses import dataclass, field
from pathlib import Path

import httpx

_SKIP_DIRS = {".git", ".agent-venv", "__pycache__", ".pytest_cache", "node_modules", ".ruff_cache"}
_VENV_DIR = ".agent-venv"
_PIN_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*(\[[A-Za-z0-9,_-]+\])?==[A-Za-z0-9._+-]+$")


class WorkspaceError(ValueError):
    pass


@dataclass
class WrittenFile:
    path: str
    created: bool
    bytes: int
    reason: str = ""
    sources: list[str] = field(default_factory=list)


@dataclass
class CommandResult:
    command: str
    exit_code: int
    stdout: str
    stderr: str
    duration_seconds: float

    @property
    def ok(self) -> bool:
        return self.exit_code == 0


class Workspace:
    def __init__(self, root: Path) -> None:
        self.root = root.resolve()
        self.written: dict[str, WrittenFile] = {}
        self.commands: list[CommandResult] = []

    # ------------------------------------------------------------------ paths
    def resolve(self, relative: str) -> Path:
        rel = relative.strip().replace("\\", "/")
        if not rel or rel.startswith("/") or (len(rel) > 1 and rel[1] == ":"):
            raise WorkspaceError(f"path must be relative to the workspace: {relative!r}")
        candidate = (self.root / rel).resolve()
        if candidate != self.root and self.root not in candidate.parents:
            raise WorkspaceError(f"path escapes the workspace: {relative!r}")
        return candidate

    def relpath(self, path: Path) -> str:
        return path.relative_to(self.root).as_posix()

    # ------------------------------------------------------------------ files
    def exists(self, relative: str) -> bool:
        return self.resolve(relative).is_file()

    def read(self, relative: str, *, max_chars: int = 60_000) -> str:
        path = self.resolve(relative)
        if not path.is_file():
            raise WorkspaceError(f"no such file in workspace: {relative}")
        text = path.read_text(encoding="utf-8", errors="replace")
        if len(text) > max_chars:
            return text[:max_chars] + f"\n\n[... truncated {len(text) - max_chars} characters ...]"
        return text

    def write(
        self, relative: str, content: str, *, reason: str = "", sources: list[str] | None = None
    ) -> WrittenFile:
        path = self.resolve(relative)
        if any(part in _SKIP_DIRS for part in path.relative_to(self.root).parts):
            raise WorkspaceError(f"refusing to write into a tooling directory: {relative}")
        created = not path.exists()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8", newline="\n")
        rel = self.relpath(path)
        record = WrittenFile(
            path=rel,
            created=created and rel not in self.written,
            bytes=len(content.encode("utf-8")),
            reason=reason,
            sources=list(sources or []),
        )
        if rel in self.written:  # keep the first "created" verdict, update the rest
            record.created = self.written[rel].created
        self.written[rel] = record
        return record

    def list(self, pattern: str = "**/*", *, limit: int = 400) -> list[str]:
        out: list[str] = []
        for p in sorted(self.root.glob(pattern)):
            if not p.is_file():
                continue
            rel = p.relative_to(self.root)
            if any(part in _SKIP_DIRS for part in rel.parts):
                continue
            out.append(rel.as_posix())
            if len(out) >= limit:
                break
        return out

    def manifest(self) -> list[dict[str, object]]:
        return [
            {
                "path": w.path,
                "created": w.created,
                "bytes": w.bytes,
                "reason": w.reason,
                "sources": w.sources,
            }
            for w in self.written.values()
        ]

    # ------------------------------------------------------------------ materialise
    async def materialise(self, repo: str, ref: str | None = None) -> str:
        """Populate the workspace from GitHub (shallow clone, tarball fallback). Idempotent."""
        if self.root.exists() and any(p.name not in _SKIP_DIRS for p in self.root.iterdir()):
            return "existing"
        self.root.mkdir(parents=True, exist_ok=True)
        if shutil.which("git"):
            args = ["git", "clone", "--depth", "1", "--quiet"]
            if ref:
                args += ["--branch", ref]
            args += [f"https://github.com/{repo}.git", str(self.root)]
            proc = await asyncio.create_subprocess_exec(
                *args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
            _, err = await asyncio.wait_for(proc.communicate(), timeout=300)
            if proc.returncode == 0:
                return "git"
            sys.stderr.write(
                f"git clone failed ({err.decode(errors='replace')[:200]}); falling back to tarball\n"
            )
        async with httpx.AsyncClient(timeout=120.0, follow_redirects=True) as client:
            response = await client.get(
                f"https://codeload.github.com/{repo}/tar.gz/{ref or 'HEAD'}"
            )
            response.raise_for_status()
        with tarfile.open(fileobj=io.BytesIO(response.content), mode="r:gz") as tar:
            for member in tar.getmembers():
                parts = Path(member.name).parts[1:]  # strip the "<repo>-<sha>/" prefix
                if not parts or not member.isfile():
                    continue
                target = self.resolve("/".join(parts))
                target.parent.mkdir(parents=True, exist_ok=True)
                extracted = tar.extractfile(member)
                if extracted is not None:
                    target.write_bytes(extracted.read())
        return "tarball"

    # ------------------------------------------------------------------ commands
    def venv_python(self) -> Path:
        venv = self.root / _VENV_DIR
        python = venv / ("Scripts/python.exe" if sys.platform == "win32" else "bin/python")
        if not python.exists():
            import venv as venv_mod  # local import: only needed when running commands

            venv_mod.EnvBuilder(with_pip=True, clear=False).create(venv)
        return python

    def translate_command(self, command: str) -> list[str]:
        """Map an allow-listed shell-style command onto the workspace virtualenv."""
        try:
            parts = shlex.split(command, posix=True)
        except ValueError as exc:
            raise WorkspaceError(f"cannot parse command: {exc}") from exc
        if parts[:2] == ["python", "-m"]:
            parts = parts[2:]
        if not parts:
            raise WorkspaceError("empty command")
        head = parts[0]
        python = str(self.venv_python())
        if head == "pytest":
            return [python, "-m", "pytest", *parts[1:]]
        if head == "ruff":
            return [python, "-m", "ruff", *parts[1:]]
        if head == "pip":
            rest = parts[1:]
            if rest[:2] == ["install", "-r"] and len(rest) == 3:
                self.resolve(rest[2])  # must be a file inside the workspace
                return [python, "-m", "pip", "install", "-q", "-r", rest[2]]
            if rest in (["install", "-e", "."], ["install", "."]):
                return [python, "-m", "pip", "install", "-q", *rest[1:]]
            # Exact pins only (pytest==9.1.1): the escape hatch when a hash-pinned lock
            # file cannot be installed on this platform. No URLs, flags or ranges.
            if (
                rest[:1] == ["install"]
                and len(rest) > 1
                and all(_PIN_RE.match(p) for p in rest[1:])
            ):
                return [python, "-m", "pip", "install", "-q", *rest[1:]]
            raise WorkspaceError(
                "pip is limited to `pip install -r <requirements file>` or `pip install -e .`"
            )
        raise WorkspaceError(
            f"command {head!r} is not allowed; use pytest, ruff, pip install -r <file> or pip install -e ."
        )

    async def run_command(
        self, command: str, *, timeout: float = 900.0, max_output: int = 12_000
    ) -> CommandResult:
        argv = self.translate_command(command)
        started = time.perf_counter()
        proc = await asyncio.create_subprocess_exec(
            *argv,
            cwd=str(self.root),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except TimeoutError:
            proc.kill()
            await proc.wait()
            result = CommandResult(
                command, 124, "", f"timed out after {timeout:.0f}s", time.perf_counter() - started
            )
            self.commands.append(result)
            return result
        result = CommandResult(
            command,
            proc.returncode or 0,
            _tail(out.decode("utf-8", errors="replace"), max_output),
            _tail(err.decode("utf-8", errors="replace"), max_output // 2),
            round(time.perf_counter() - started, 2),
        )
        self.commands.append(result)
        return result


def _tail(text: str, limit: int) -> str:
    return (
        text
        if len(text) <= limit
        else f"[... {len(text) - limit} characters omitted ...]\n" + text[-limit:]
    )
