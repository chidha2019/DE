"""Reference pipeline-builder agent on top of the Enterprise Context Hub.

Given an *intent* ("add a gold fact table for claims aging"), the agent:

1. grounds itself through the hub (hybrid + graph retrieval, lineage, documents),
2. reads the exemplar files the hub points to from a local workspace checkout,
3. writes new/changed pipeline files that mirror the repository's conventions,
4. runs the repository's own tests inside a sandboxed virtualenv,
5. finishes with a manifest of files, citations and next steps.

The loop is a plain Claude Messages API tool loop (``pipeline_agent.agent``);
tools live in ``pipeline_agent.tools``; the hub and workspace adapters are
swappable so the whole thing is unit-testable without a network or an API key.
"""

from pipeline_agent.agent import AgentConfig, AgentResult, PipelineBuilderAgent

__all__ = ["AgentConfig", "AgentResult", "PipelineBuilderAgent"]
