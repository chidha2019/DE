"""The agent loop: Claude Messages API + tools, with the model behind a small protocol.

Why a manual loop rather than the SDK tool runner: the run needs a hard turn cap,
per-turn transcript logging, stop-reason handling (``max_tokens``, ``refusal``)
and a model double for tests - all of which are a few lines here.

The model client itself (provider profiles for the first-party API and the Databricks
gateway, strict tools, streaming, strip-and-retry of rejected fields) lives in
:mod:`ech_core.llm` and is shared with the query service's Genie.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from ech_core.llm import (
    DEFAULT_MODEL,
    PRICING,
    PROVIDERS,
    AnthropicModelClient,
    ModelClient,
    ModelConfigError,
    ModelTurn,
    ProviderProfile,
    detect_provider,
    resolve_base_url,
)
from pipeline_agent.prompts import SYSTEM_PROMPT, initial_user_message
from pipeline_agent.tools import TOOLS, ToolExecutor

__all__ = [
    "DEFAULT_MODEL",
    "PROVIDERS",
    "AgentConfig",
    "AgentResult",
    "AnthropicModelClient",
    "ModelClient",
    "ModelConfigError",
    "ModelTurn",
    "PipelineBuilderAgent",
    "ProviderProfile",
    "detect_provider",
    "resolve_base_url",
]


@dataclass
class AgentConfig:
    repo: str
    ref: str = "main"
    model: str | None = None  # None: the provider's default model
    effort: str = "high"
    max_turns: int = 30
    max_tokens: int = 64_000
    fallbacks: bool = True
    transcript_path: Path | None = None
    provider: str = "anthropic"  # key of PROVIDERS
    base_url: str | None = None  # overrides ANTHROPIC_BASE_URL / <host_env> + base_path

    def __post_init__(self) -> None:
        if self.model is None:
            profile = PROVIDERS.get(self.provider)
            self.model = profile.default_model if profile else DEFAULT_MODEL


@dataclass
class AgentResult:
    status: str  # finished | max_turns | refused | error
    summary: str
    files: list[dict[str, Any]]
    tests_passed: bool | None
    next_steps: list[str]
    confidence: float | None
    citations: list[dict[str, Any]]
    turns: int
    usage: dict[str, int]
    estimated_cost_usd: float | None
    transcript_path: str | None
    error: str | None = None


class PipelineBuilderAgent:
    def __init__(self, *, config: AgentConfig, model: ModelClient, executor: ToolExecutor) -> None:
        self.config = config
        self.model = model
        self.executor = executor
        self.usage: dict[str, int] = {
            "input_tokens": 0,
            "output_tokens": 0,
            "cache_creation_input_tokens": 0,
            "cache_read_input_tokens": 0,
        }

    # ------------------------------------------------------------------ public
    async def run(self, intent: str) -> AgentResult:
        ws = self.executor.workspace
        messages: list[dict[str, Any]] = [
            {
                "role": "user",
                "content": initial_user_message(
                    intent=intent,
                    repo=self.config.repo,
                    ref=self.config.ref,
                    top_level=sorted(
                        {p.split("/", 1)[0] + ("/" if "/" in p else "") for p in ws.list()}
                    ),
                    max_turns=self.config.max_turns,
                ),
            }
        ]
        status = "max_turns"
        error: str | None = None
        nudged = False
        turns = 0

        for turn in range(1, self.config.max_turns + 1):
            turns = turn
            try:
                response = await self.model.complete(
                    system=SYSTEM_PROMPT, tools=TOOLS, messages=messages
                )
            except Exception as exc:  # noqa: BLE001 - surface provider errors in the result
                status, error = "error", f"{type(exc).__name__}: {exc}"
                self._log(turn, {"error": error})
                break
            self._account(response.usage)
            messages.append({"role": "assistant", "content": response.content})
            tool_uses = [b for b in response.content if b.get("type") == "tool_use"]
            self._log(
                turn,
                {
                    "stop_reason": response.stop_reason,
                    "usage": response.usage,
                    "tools": [t["name"] for t in tool_uses],
                    "text": _text_of(response.content)[:400],
                },
            )

            if response.stop_reason == "refusal":
                status, error = "refused", json.dumps(response.stop_details or {})
                break

            results: list[dict[str, Any]] = []
            for tool_use in tool_uses:
                outcome = await self.executor.execute(tool_use["name"], tool_use.get("input"))
                block: dict[str, Any] = {
                    "type": "tool_result",
                    "tool_use_id": tool_use["id"],
                    "content": outcome.content,
                }
                if outcome.is_error:
                    block["is_error"] = True
                results.append(block)
                self._log(
                    turn,
                    {
                        "tool": tool_use["name"],
                        "input": _summ(tool_use.get("input")),
                        "is_error": outcome.is_error,
                        "result": outcome.content[:300],
                    },
                )

            if response.stop_reason == "max_tokens":
                results.append(
                    _text(
                        "Your previous message was cut off by max_tokens. Continue, re-issuing any tool call that was truncated."
                    )
                )
            elif not tool_uses:
                if nudged:
                    status = "ended_without_finish"
                    break
                nudged = True
                results.append(
                    _text(
                        "Call the `finish` tool to end the task (or keep working with tools if you are not done)."
                    )
                )

            messages.append({"role": "user", "content": results})
            if self.executor.finished is not None:
                status = "finished"
                break

        finished = self.executor.finished
        return AgentResult(
            status=status,
            summary=finished.summary if finished else (error or f"stopped after {turns} turns"),
            files=ws.manifest(),
            tests_passed=finished.tests_passed
            if finished
            else (ws.commands[-1].ok if ws.commands else None),
            next_steps=list(finished.next_steps) if finished else [],
            confidence=finished.confidence if finished else None,
            citations=[c.__dict__ for c in self.executor.citations.values()],
            turns=turns,
            usage=dict(self.usage),
            estimated_cost_usd=self._cost(),
            transcript_path=str(self.config.transcript_path)
            if self.config.transcript_path
            else None,
            error=error,
        )

    # ------------------------------------------------------------------ helpers
    def _account(self, usage: dict[str, Any]) -> None:
        for key in self.usage:
            self.usage[key] += int(usage.get(key) or 0)

    def _cost(self) -> float | None:
        price = PRICING.get(self.config.model or "")
        if price is None:
            return None
        inp, out, cwrite, cread = price
        u = self.usage
        return round(
            (
                u["input_tokens"] * inp
                + u["output_tokens"] * out
                + u["cache_creation_input_tokens"] * cwrite
                + u["cache_read_input_tokens"] * cread
            )
            / 1_000_000,
            4,
        )

    def _log(self, turn: int, record: dict[str, Any]) -> None:
        path = self.config.transcript_path
        if path is None:
            return
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as fh:
            fh.write(
                json.dumps(
                    {"ts": datetime.now(tz=UTC).isoformat(), "turn": turn, **record}, default=str
                )
                + "\n"
            )


def _text(text: str) -> dict[str, Any]:
    return {"type": "text", "text": text}


def _text_of(content: list[dict[str, Any]]) -> str:
    return "\n".join(b.get("text", "") for b in content if b.get("type") == "text")


def _summ(value: Any, limit: int = 200) -> Any:
    if isinstance(value, dict):
        return {
            k: (v if not isinstance(v, str) or len(v) <= limit else v[:limit] + "…")
            for k, v in value.items()
        }
    return value
