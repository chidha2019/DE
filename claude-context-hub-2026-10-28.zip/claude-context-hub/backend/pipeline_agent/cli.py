"""CLI: ``python -m pipeline_agent "<intent>" --repo owner/name [options]``."""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
from pathlib import Path

from pipeline_agent.agent import (
    PROVIDERS,
    AgentConfig,
    AgentResult,
    AnthropicModelClient,
    ModelConfigError,
    PipelineBuilderAgent,
    detect_provider,
)
from pipeline_agent.hub import HubClient
from pipeline_agent.tools import ToolExecutor
from pipeline_agent.workspace import Workspace


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="pipeline_agent",
        description="Build pipeline changes from an intent, grounded by the Enterprise Context Hub.",
    )
    p.add_argument("intent", help="what to build, e.g. 'Add a gold fact table fact_claims_aging'")
    p.add_argument("--repo", required=True, help="owner/name of the repository indexed in the hub")
    p.add_argument("--ref", default="main")
    p.add_argument(
        "--workspace",
        type=Path,
        default=None,
        help="checkout directory (default ./workspace/<repo name>)",
    )
    p.add_argument(
        "--no-clone", action="store_true", help="do not clone; the workspace must already exist"
    )
    p.add_argument(
        "--env-file",
        type=Path,
        default=None,
        help="KEY=VALUE file loaded into the environment first (keeps DATABRICKS_HOST/"
        "DATABRICKS_TOKEN or ANTHROPIC_API_KEY out of shell history); only the names are logged",
    )
    p.add_argument("--hub-query-url", default="http://localhost:8002")
    p.add_argument("--hub-ingestion-url", default="http://localhost:8001")
    p.add_argument(
        "--provider",
        default="auto",
        choices=["auto", *PROVIDERS],
        help="where Claude is served: anthropic (first-party API) or databricks (Mosaic AI Gateway, "
        "Anthropic Messages API); auto picks databricks when DATABRICKS_HOST and DATABRICKS_TOKEN "
        "or a Databricks ANTHROPIC_BASE_URL are set",
    )
    p.add_argument(
        "--base-url",
        default=None,
        help="API base URL; databricks: https://<workspace-host>[/ai-gateway/anthropic] "
        "(default from DATABRICKS_HOST)",
    )
    p.add_argument(
        "--model",
        default=None,
        help="model id; default per provider: "
        + ", ".join(f"{name}={prof.default_model}" for name, prof in PROVIDERS.items()),
    )
    p.add_argument("--effort", default="high", choices=["low", "medium", "high", "xhigh", "max"])
    p.add_argument("--max-turns", type=int, default=30)
    p.add_argument("--max-tokens", type=int, default=64_000)
    p.add_argument(
        "--no-fallbacks", action="store_true", help="disable server-side refusal fallbacks"
    )
    p.add_argument(
        "--publish",
        action="store_true",
        help="ingest the written files into the hub (source_system=manual) when done",
    )
    p.add_argument("--json", action="store_true", help="print the result as JSON")
    return p


def load_env_file(path: Path) -> list[str]:
    """Load ``KEY=VALUE`` lines into the environment (comments, blanks, ``export`` and quotes
    tolerated; later keys override). Returns the keys set - the values are never printed."""
    keys: list[str] = []
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export ") :].strip()
        key, sep, value = line.partition("=")
        key = key.strip()
        if not sep or not key:
            continue
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "'\"":
            value = value[1:-1]
        os.environ[key] = value
        keys.append(key)
    return keys


async def run(args: argparse.Namespace) -> AgentResult:
    if args.env_file is not None:
        loaded = load_env_file(args.env_file)
        print(f"env file: {args.env_file} set {', '.join(loaded) or 'nothing'}", file=sys.stderr)
    workspace_dir = args.workspace or Path("workspace") / args.repo.split("/")[-1]
    workspace = Workspace(workspace_dir)
    provider = detect_provider(args.base_url) if args.provider == "auto" else args.provider
    config = AgentConfig(
        repo=args.repo,
        ref=args.ref,
        model=args.model,  # None: the provider's default
        effort=args.effort,
        max_turns=args.max_turns,
        max_tokens=args.max_tokens,
        fallbacks=not args.no_fallbacks,
        transcript_path=workspace.root / ".agent" / "transcript.jsonl",
        provider=provider,
        base_url=args.base_url,
    )
    model = AnthropicModelClient(config)  # fails fast on a missing host/token, before any clone
    print(f"model: {model.describe()}", file=sys.stderr)
    if not args.no_clone:
        how = await workspace.materialise(args.repo, args.ref)
        print(f"workspace: {workspace.root} ({how})", file=sys.stderr)
    hub = HubClient(
        query_url=args.hub_query_url, ingestion_url=args.hub_ingestion_url, repo=args.repo
    )
    executor = ToolExecutor(hub=hub, workspace=workspace)
    agent = PipelineBuilderAgent(config=config, model=model, executor=executor)
    try:
        result = await agent.run(args.intent)
        if args.publish and result.files:
            await publish(hub, workspace, args.repo, result)
        return result
    finally:
        await hub.aclose()


async def publish(hub: HubClient, workspace: Workspace, repo: str, result: AgentResult) -> None:
    """Close the loop: the agent's artifacts become hub documents linked to their sources."""
    for entry in result.files:
        path = str(entry["path"])
        await hub.publish_document(
            title=f"{repo.split('/')[-1]}/{path}",
            content=workspace.read(path),
            external_id=f"{repo}:{path}",
            author="pipeline-agent",
            references=[
                s
                for s in entry.get("sources", [])
                if isinstance(s, str) and "/" in s and not s.startswith("chunk:")
            ],
            attributes={
                "repo": repo,
                "path": path,
                "generated_by": "pipeline-agent",
                "reason": entry.get("reason", ""),
            },
        )
        print(f"published {path} to the hub", file=sys.stderr)


def print_result(result: AgentResult, as_json: bool) -> None:
    if as_json:
        print(json.dumps(result.__dict__, indent=2, default=str))
        return
    print(f"\nstatus: {result.status}" + (f" ({result.error})" if result.error else ""))
    print(
        f"turns: {result.turns} · tokens in/out: {result.usage['input_tokens']}/{result.usage['output_tokens']} "
        f"(cache read {result.usage['cache_read_input_tokens']})"
        + (f" · ≈${result.estimated_cost_usd}" if result.estimated_cost_usd is not None else "")
    )
    print(f"tests passed: {result.tests_passed} · confidence: {result.confidence}")
    print("\nfiles:")
    for f in result.files:
        print(f"  {'+' if f['created'] else '~'} {f['path']} ({f['bytes']} B) — {f['reason']}")
    if result.next_steps:
        print("\nnext steps:")
        for step in result.next_steps:
            print(f"  - {step}")
    print(f"\ncitations: {len(result.citations)} hub chunks consulted")
    print(f"\n{result.summary}")
    if result.transcript_path:
        print(f"\ntranscript: {result.transcript_path}")


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        result = asyncio.run(run(args))
    except ModelConfigError as exc:
        print(f"model configuration: {exc}", file=sys.stderr)
        return 2
    print_result(result, args.json)
    return 0 if result.status == "finished" else 1


if __name__ == "__main__":
    sys.exit(main())
