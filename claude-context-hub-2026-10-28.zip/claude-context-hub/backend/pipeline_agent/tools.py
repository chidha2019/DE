"""Tool definitions (strict JSON schemas) and the executor that runs them.

Each tool has a pydantic input model: inputs are validated *before* execution
because with eager input streaming the SDK's tolerant parser can hand back a
truncated object instead of raising. A validation failure becomes an
``is_error`` tool result and the model re-issues the call.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

from pydantic import BaseModel, Field, ValidationError

from ech_core.llm import strict_tool_schema
from pipeline_agent.hub import HubClient, HubError
from pipeline_agent.workspace import Workspace, WorkspaceError


# ----------------------------------------------------------------------------- inputs
class RetrieveInput(BaseModel):
    query: str = Field(min_length=3, max_length=2000)
    top_k: int = Field(ge=1, le=20)
    use_graph: bool


class GetDocumentInput(BaseModel):
    path: str = Field(min_length=1, max_length=512)


class GetLineageInput(BaseModel):
    path: str = Field(min_length=1, max_length=512)
    depth: int = Field(ge=1, le=4)


class SearchDocumentsInput(BaseModel):
    query: str = Field(min_length=1, max_length=200)
    limit: int = Field(ge=1, le=50)


class ListFilesInput(BaseModel):
    pattern: str = Field(min_length=1, max_length=200)


class WriteFileInput(BaseModel):
    path: str = Field(min_length=1, max_length=512)
    content: str = Field(max_length=400_000)
    reason: str = Field(min_length=1, max_length=1000)
    sources: list[str] = Field(max_length=20)


class RunCommandInput(BaseModel):
    command: str = Field(min_length=3, max_length=500)
    timeout_seconds: int = Field(ge=10, le=1800)


class FinishInput(BaseModel):
    summary: str = Field(min_length=1, max_length=6000)
    files: list[str] = Field(max_length=100)
    next_steps: list[str] = Field(max_length=20)
    tests_passed: bool
    confidence: float = Field(ge=0.0, le=1.0)


# Strict-mode wire schema (bounds validated client-side by the pydantic models above).
_schema = strict_tool_schema


TOOLS: list[dict[str, Any]] = [
    {
        "name": "retrieve_context",
        "description": (
            "Hybrid (vector + keyword) retrieval over the hub with graph expansion, scoped to the target "
            "repository. Returns ranked chunks with scores, retrieval paths, entities and the graph "
            "neighbourhood (related documents/entities). Call this FIRST for any new question; prefer "
            "specific technical phrasing (e.g. 'how gold tables are registered in config/assets.yml')."
        ),
        "input_schema": _schema(RetrieveInput),
    },
    {
        "name": "get_document",
        "description": (
            "Return the full text of a repository file from the workspace checkout (exact bytes), e.g. "
            "'sql/gold/fact_loss_performance.sql'. Use it to read the exemplars retrieve_context pointed at."
        ),
        "input_schema": _schema(GetDocumentInput),
    },
    {
        "name": "get_lineage",
        "description": (
            "Lineage of a repository file from the hub graph: which files reference it, which it references "
            "(imports, manifests, markdown links) and who contributed. Use it to find where a new artifact "
            "must be registered or documented."
        ),
        "input_schema": _schema(GetLineageInput),
    },
    {
        "name": "search_documents",
        "description": "Find hub documents of the repository by title/path substring (e.g. 'quality', 'assets.yml').",
        "input_schema": _schema(SearchDocumentsInput),
    },
    {
        "name": "list_files",
        "description": "List workspace files matching a glob (e.g. 'sql/gold/*.sql', '**/*.yml').",
        "input_schema": _schema(ListFilesInput),
    },
    {
        "name": "write_file",
        "description": (
            "Create or overwrite ONE file inside the workspace with the complete content. `reason` says what the "
            "file does; `sources` lists the exemplar paths / hub chunk ids it mirrors (required, non-empty)."
        ),
        "input_schema": _schema(WriteFileInput),
    },
    {
        "name": "run_command",
        "description": (
            "Run an allow-listed command in the workspace's own virtualenv: `pip install -r <requirements file>`, "
            "`pip install -e .`, `pytest ...`, `ruff ...`. Install test dependencies before the first pytest. "
            "Returns exit code, stdout and stderr (tail)."
        ),
        "input_schema": _schema(RunCommandInput),
    },
    {
        "name": "finish",
        "description": (
            "End the task. Report what was built, every file written, whether the repository tests passed, "
            "remaining next steps for a human, and your confidence (0-1)."
        ),
        "input_schema": _schema(FinishInput),
    },
]

_INPUT_MODELS: dict[str, type[BaseModel]] = {
    "retrieve_context": RetrieveInput,
    "get_document": GetDocumentInput,
    "get_lineage": GetLineageInput,
    "search_documents": SearchDocumentsInput,
    "list_files": ListFilesInput,
    "write_file": WriteFileInput,
    "run_command": RunCommandInput,
    "finish": FinishInput,
}


# ----------------------------------------------------------------------------- executor
@dataclass
class ToolOutcome:
    content: str
    is_error: bool = False


@dataclass
class Citation:
    chunk_id: str
    document_id: str
    path: str
    score: float


@dataclass
class ToolExecutor:
    hub: HubClient
    workspace: Workspace
    citations: dict[str, Citation] = field(default_factory=dict)
    finished: FinishInput | None = None
    retrievals: int = 0

    async def execute(self, name: str, raw_input: Any) -> ToolOutcome:
        model = _INPUT_MODELS.get(name)
        if model is None:
            return ToolOutcome(f"unknown tool {name!r}", is_error=True)
        if not isinstance(raw_input, dict):
            return ToolOutcome(
                "tool input was not a JSON object (possibly truncated); re-issue the call",
                is_error=True,
            )
        try:
            args = model.model_validate(raw_input)
        except ValidationError as exc:
            return ToolOutcome(
                f"invalid input for {name}: {exc.errors(include_url=False)}; re-issue the call",
                is_error=True,
            )
        try:
            handler = getattr(self, f"_{name}")
            return await handler(args)
        except (HubError, WorkspaceError) as exc:
            return ToolOutcome(str(exc), is_error=True)

    # ------------------------------------------------------------------ hub tools
    async def _retrieve_context(self, args: RetrieveInput) -> ToolOutcome:
        self.retrievals += 1
        data = await self.hub.retrieve(args.query, top_k=args.top_k, use_graph=args.use_graph)
        lines = [
            f"query: {data['query']}",
            f"{len(data['results'])} results · {data['candidates_considered']} candidates · {data['timings']['total_ms']} ms",
            "",
        ]
        for i, r in enumerate(data["results"], 1):
            path = r.get("document_attributes", {}).get("path") or r["document_title"]
            self.citations[r["chunk_id"]] = Citation(
                r["chunk_id"], r["document_id"], path, r["scores"]["final"]
            )
            section = " > ".join(r.get("section_path") or [])
            ents = ", ".join(e["name"] for e in r.get("entities", [])[:6])
            lines.append(
                f"[{i}] chunk_id={r['chunk_id']} path={path} chunk#{r['chunk_index']} "
                f"score={r['scores']['final']:.2f} via={','.join(r['retrieval_paths'])}"
                + (f" section={section}" if section else "")
                + (f" entities={ents}" if ents else "")
            )
            lines.append(r["content"].strip())
            lines.append("")
        graph = data.get("graph_context")
        if graph:
            docs = sorted({n["label"] for n in graph["nodes"] if n["type"] == "Document"})
            ents = [k.split(":", 1)[1] for k in graph.get("first_degree_entities", [])][:12]
            lines.append(
                f"graph neighbourhood: {len(graph['nodes'])} nodes / {len(graph['edges'])} edges"
            )
            lines.append("related documents: " + ", ".join(docs[:20]))
            lines.append("entities: " + ", ".join(ents))
        return ToolOutcome("\n".join(lines))

    async def _search_documents(self, args: SearchDocumentsInput) -> ToolOutcome:
        docs = await self.hub.search_documents(args.query, limit=args.limit)
        if not docs:
            return ToolOutcome("no documents matched")
        return ToolOutcome(
            "\n".join(
                f"{d['attributes'].get('path') or d['title']}  (id={d['id']}, chunks={d.get('chunk_count')})"
                for d in docs
            )
        )

    async def _get_lineage(self, args: GetLineageInput) -> ToolOutcome:
        doc = await self.hub.find_document(args.path)
        if doc is None:
            return ToolOutcome(
                f"{args.path} is not indexed in the hub (run the connector) — use list_files/get_document instead",
                is_error=True,
            )
        lineage = await self.hub.lineage(doc["id"], depth=args.depth)
        labels = {n["id"]: n["label"] for n in lineage["nodes"]}
        short = lambda label: label.split("/", 1)[1] if "/" in label else label  # noqa: E731
        inbound = [
            short(labels[e["source"]])
            for e in lineage["edges"]
            if e["type"] == "REFERENCES" and e["target"] == doc["id"]
        ]
        outbound = [
            short(labels[e["target"]])
            for e in lineage["edges"]
            if e["type"] == "REFERENCES" and e["source"] == doc["id"]
        ]
        people = [
            labels[e["target"]]
            for e in lineage["edges"]
            if e["type"] == "CONTRIBUTED_BY" and e["source"] == doc["id"]
        ]
        return ToolOutcome(
            f"{args.path}\n"
            f"referenced by ({len(inbound)}): {', '.join(sorted(inbound)) or '-'}\n"
            f"references ({len(outbound)}): {', '.join(sorted(outbound)) or '-'}\n"
            f"contributors: {', '.join(people) or '-'}\n"
            f"lineage graph: {len(lineage['nodes'])} nodes / {len(lineage['edges'])} edges within {args.depth} hops"
        )

    # ------------------------------------------------------------------ workspace tools
    async def _get_document(self, args: GetDocumentInput) -> ToolOutcome:
        if self.workspace.exists(args.path):
            return ToolOutcome(self.workspace.read(args.path))
        doc = await self.hub.find_document(args.path)
        if doc is None:
            return ToolOutcome(f"{args.path} not found in workspace or hub", is_error=True)
        chunks = await self.hub.document_chunks(doc["id"])
        body = "\n".join(c["content"] for c in chunks)
        return ToolOutcome(
            f"[reconstructed from {len(chunks)} hub chunks; whitespace may differ]\n{body}"
        )

    async def _list_files(self, args: ListFilesInput) -> ToolOutcome:
        files = self.workspace.list(args.pattern)
        return ToolOutcome("\n".join(files) if files else "no files match")

    async def _write_file(self, args: WriteFileInput) -> ToolOutcome:
        if not args.sources:
            return ToolOutcome(
                "write_file requires at least one source (exemplar path or chunk id)", is_error=True
            )
        record = self.workspace.write(
            args.path, args.content, reason=args.reason, sources=args.sources
        )
        verb = "created" if record.created else "updated"
        return ToolOutcome(f"{verb} {record.path} ({record.bytes} bytes)")

    async def _run_command(self, args: RunCommandInput) -> ToolOutcome:
        result = await self.workspace.run_command(args.command, timeout=float(args.timeout_seconds))
        text = f"$ {result.command}\nexit code: {result.exit_code} ({result.duration_seconds}s)\n"
        if result.stdout:
            text += f"--- stdout ---\n{result.stdout}\n"
        if result.stderr:
            text += f"--- stderr ---\n{result.stderr}\n"
        return ToolOutcome(text, is_error=not result.ok)

    async def _finish(self, args: FinishInput) -> ToolOutcome:
        self.finished = args
        return ToolOutcome(json.dumps({"status": "finished", "files": args.files}))
