from pipeline_agent.cli import main

raise SystemExit(main())
