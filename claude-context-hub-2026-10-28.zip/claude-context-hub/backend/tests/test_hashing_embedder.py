import math

import pytest

from ech_core.embeddings.hashing import HashingEmbeddingProvider, hashing_embedding
from ech_core.exceptions import EmbeddingError


def _cos(a, b):
    return sum(x * y for x, y in zip(a, b, strict=True))


def test_vectors_are_unit_length_and_deterministic():
    v1 = hashing_embedding("Kubernetes deployments with ArgoCD", 1536)
    v2 = hashing_embedding("Kubernetes deployments with ArgoCD", 1536)
    assert v1 == v2
    assert len(v1) == 1536
    assert math.isclose(math.sqrt(sum(x * x for x in v1)), 1.0, rel_tol=1e-9)


def test_similarity_orders_lexically_related_text():
    q = hashing_embedding("billing invoices and usage metering", 1536)
    related = hashing_embedding("Nimbus Billing meters usage and produces invoices", 1536)
    unrelated = hashing_embedding("Grafana dashboards show Kubernetes pod restarts", 1536)
    assert _cos(q, related) > _cos(q, unrelated)


@pytest.mark.asyncio
async def test_provider_batches_and_pads():
    provider = HashingEmbeddingProvider(dimensions=64, batch_size=3)
    texts = [f"text number {i}" for i in range(10)] + ["   "]
    vectors = await provider.embed_texts(texts)
    assert len(vectors) == 11
    assert all(len(v) == 64 for v in vectors)
    assert provider.model_id == "hashing:feature-hashing-v1"
    assert await provider.embed_texts([]) == []


def test_fit_rejects_oversized_vectors():
    provider = HashingEmbeddingProvider(dimensions=8)
    assert provider._fit([1.0, 2.0]) == [1.0, 2.0, 0, 0, 0, 0, 0, 0]
    with pytest.raises(EmbeddingError):
        provider._fit([0.0] * 9)
