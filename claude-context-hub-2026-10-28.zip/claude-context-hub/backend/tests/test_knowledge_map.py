"""The Knowledge Hub's knowledge map: documents, their top entities, references and dependencies."""

from __future__ import annotations

import asyncio
from typing import Any

from query_service.services.graph_service import GraphService


class FakeRepo:
    def __init__(self, row: dict[str, Any]) -> None:
        self.row = row
        self.asked: int | None = None

    async def knowledge_map(self, *, max_documents: int = 150) -> dict[str, Any]:
        self.asked = max_documents
        return self.row


ROW = {
    "documents": [
        {"id": "d1", "title": "LIFE.BRONZE.POLICY", "source_system": "snowflake", "uri": None},
        {"id": "d2", "title": "LIFE.BRONZE.PHONE", "source_system": "snowflake", "uri": None},
    ],
    "mentions": [
        {"document_id": "d1", "key": "Technology:snowflake", "name": "Snowflake", "entity_type": "Technology", "mentions": 2},
        {"document_id": "d2", "key": "Technology:snowflake", "name": "Snowflake", "entity_type": "Technology", "mentions": 1},
        {"document_id": "d1", "key": "Project:life", "name": "Life Insurance Db", "entity_type": "Project", "mentions": 3},
        {"document_id": "d2", "key": "Concept:rare", "name": "Rare", "entity_type": "Concept", "mentions": 1},
    ],
    "refs": [{"source": "d2", "target": "d1", "title": "LIFE.BRONZE.POLICY", "source_system": "snowflake", "stub": False, "kind": "foreign_key"}],
    "contributors": [{"source": "d1", "key": "Person:ann", "name": "Ann", "role": "owner"}],
    "deps": [
        {"source": "Project:life", "target": "Technology:snowflake", "weight": 3.0},
        {"source": "Concept:rare", "target": "Technology:snowflake", "weight": 1.0},
    ],
}


def test_the_map_keeps_the_most_shared_entities_and_every_link():
    repo = FakeRepo(ROW)
    payload = asyncio.run(GraphService(repo).knowledge_map(max_documents=50, max_entities=2))  # type: ignore[arg-type]
    assert repo.asked == 50
    nodes = {n.id: n for n in payload.nodes}
    assert set(nodes) == {"d1", "d2", "Technology:snowflake", "Project:life", "Person:ann"}
    assert nodes["Technology:snowflake"].properties["documents"] == 2 and nodes["Technology:snowflake"].degree == 3
    edges = {(e.source, e.target, e.type) for e in payload.edges}
    assert ("d2", "d1", "REFERENCES") in edges and ("d1", "Person:ann", "CONTRIBUTED_BY") in edges
    assert ("Project:life", "Technology:snowflake", "DEPENDS_ON") in edges
    assert not any(e.source == "Concept:rare" or e.target == "Concept:rare" for e in payload.edges)
    mention = next(e for e in payload.edges if e.source == "d1" and e.target == "Technology:snowflake")
    assert mention.properties["weight"] == 2.0


def test_an_empty_hub_gives_an_empty_map():
    empty = {"documents": [], "mentions": [], "refs": [], "contributors": [], "deps": []}
    payload = asyncio.run(GraphService(FakeRepo(empty)).knowledge_map())  # type: ignore[arg-type]
    assert payload.nodes == [] and payload.edges == []
