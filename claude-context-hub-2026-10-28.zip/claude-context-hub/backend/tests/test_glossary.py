"""Business glossary: name rules, Claude mapping, review and the domain tree (repository faked)."""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime
from typing import Any
from uuid import UUID, uuid4

import pytest

from ech_core.exceptions import DependencyUnavailableError, InvalidRequestError
from ech_core.llm.client import ModelTurn
from ech_core.schemas.glossary import LinkCreate, MapRequest, ProposeTermsRequest, TermDecision
from query_service.services.glossary_service import (
    GlossaryService,
    TermIndex,
    batch_targets,
    build_prompt,
    mapping_fingerprint,
    normalize,
    parse_mapping,
    parse_term_proposals,
    split_batch,
)

# --------------------------------------------------------------------------- fixtures


def _term(key: str, name: str, domain: str, synonyms: list[str], kind: str = "entity") -> dict[str, Any]:
    return {"id": uuid4(), "key": key, "name": name, "domain_key": domain, "kind": kind, "synonyms": synonyms, "definition": f"{name}."}


CATALOG = [
    _term("policy", "Policy", "policy", ["policy", "contract", "insurance contract"]),
    _term("policy_number", "Policy Number", "policy", ["policy number", "policy id", "policy no", "contract number"], "attribute"),
    _term("customer", "Customer", "customer", ["customer", "client", "policy owner"]),
    _term("lapse", "Lapse", "policy_lifecycle", ["lapse", "lapsed", "lapsed policy"], "event"),
    _term("premium", "Premium", "policy", ["premium", "gross premium", "premium amount"], "measure"),
    _term("ingestion_timestamp", "Ingestion Timestamp", "data_platform", ["ingested at", "load timestamp"], "attribute"),
    _term("exposure", "Exposure", "experience", ["exposure", "exposed to risk"], "measure"),
]
BY_KEY = {t["key"]: t for t in CATALOG}


def _domain(key: str, name: str, parent: str | None, sort: int, terms: int, kpis: int) -> dict[str, Any]:
    return {"key": key, "name": name, "parent_key": parent, "description": "", "standard": "acord", "standard_ref": "", "sort_order": sort, "term_count": terms, "asset_count": 0, "kpi_count": kpis}


DOMAINS = [
    _domain("policy", "Policy Administration", None, 50, 3, 1),
    _domain("policy_lifecycle", "Policy Lifecycle Events", "policy", 51, 1, 2),
    _domain("customer", "Customer", "party", 11, 1, 0),
    _domain("party", "Party & Customer", None, 10, 0, 0),
    _domain("experience", "Experience Studies", None, 92, 1, 0),
    _domain("data_platform", "Data Platform", None, 130, 1, 0),
]

ASSET_ID = uuid4()
F_POLICY_NO, F_CUSTOMER_SK, F_PREMIUM, F_INGESTED, F_OBJ = (uuid4() for _ in range(5))
M_PREMIUM = uuid4()
ASSET = {
    "id": ASSET_ID, "fqn": "ins.gold.fct_lapse_experience", "name": "fct_lapse_experience", "display_name": "Lapse Experience",
    "summary": "", "description": "One row per policy-year exposed.", "kind": "fact", "domain_key": None,
}


def _field(fid: UUID, name: str, role: str, data_type: str) -> dict[str, Any]:
    return {"id": fid, "asset_id": ASSET_ID, "name": name, "display_name": name.replace("_", " ").title(), "role": role, "data_type": data_type, "description": "", "synonyms": []}


FIELDS = [
    _field(F_POLICY_NO, "POLICY_NO", "identifier", "string"),
    _field(F_CUSTOMER_SK, "customer_sk", "identifier", "bigint"),
    _field(F_PREMIUM, "annual_premium_amt", "measure", "decimal"),
    _field(F_INGESTED, "ingested_at", "time", "timestamp"),
    _field(F_OBJ, "object_id", "identifier", "string"),
]
METRICS = [{"id": M_PREMIUM, "asset_id": ASSET_ID, "name": "total_premium", "display_name": "Total Premium", "expression": "sum(annual_premium_amt)", "description": "", "synonyms": []}]


class FakeRepo:
    def __init__(self) -> None:
        self.rows: dict[tuple[UUID, str, UUID], dict[str, Any]] = {}
        self.field_synonyms: dict[UUID, list[str]] = {}
        self.proposed: list[dict[str, Any]] = []
        self.fingerprints: dict[UUID, str] = {}

    async def map_fingerprints(self, asset_ids: list[UUID]) -> dict[UUID, str]:
        return {a: self.fingerprints[a] for a in asset_ids if a in self.fingerprints}

    async def save_map_fingerprint(self, asset_id: UUID, fingerprint: str, model: str | None) -> None:
        self.fingerprints[asset_id] = fingerprint

    async def catalog(self, *, include_proposed: bool = False) -> list[dict[str, Any]]:
        return [*CATALOG, *self.proposed] if include_proposed else CATALOG

    def _term(self, term_id: UUID) -> dict[str, Any]:
        return next(t for t in [*CATALOG, *self.proposed] if t["id"] == term_id)

    async def unmapped_targets(self, asset_ids: list[UUID]) -> dict[str, list[dict[str, Any]]]:
        linked = {(k[1], k[2]) for k, r in self.rows.items() if r["status"] in ("accepted", "suggested")}
        return {
            "assets": [ASSET],
            "fields": [f for f in FIELDS if ("field", f["id"]) not in linked],
            "metrics": [m for m in METRICS if ("metric", m["id"]) not in linked],
        }

    async def create_proposed_term(self, *, key: str, name: str, definition: str, domain_key: str | None, kind: str, synonyms: list[str], proposed_by: str | None, rationale: str) -> dict[str, Any] | None:
        if key in BY_KEY or any(t["key"] == key for t in self.proposed):
            return None
        row = {
            "id": uuid4(), "key": key, "name": name, "definition": definition, "domain_key": domain_key, "kind": kind, "synonyms": synonyms,
            "standard": "hub", "status": "proposed", "proposed_by": proposed_by, "rationale": rationale,
        }
        self.proposed.append(row)
        return row

    async def term_by_key(self, key: str) -> dict[str, Any] | None:
        return BY_KEY.get(key) or next((t for t in self.proposed if t["key"] == key), None)

    async def decide_term(self, term_id: UUID, *, accept: bool) -> bool:
        term = next((t for t in self.proposed if t["id"] == term_id and t["status"] == "proposed"), None)
        if term is None:
            return False
        if accept:
            term["status"] = "curated"
        else:
            self.proposed.remove(term)
            for key in [k for k in self.rows if k[0] == term_id]:
                del self.rows[key]
        return True

    async def suggested_link_ids(self, term_id: UUID) -> list[UUID]:
        return [r["id"] for k, r in self.rows.items() if k[0] == term_id and r["status"] == "suggested"]

    async def domains(self) -> list[dict[str, Any]]:
        return DOMAINS

    async def scope_asset_ids(self, **_: Any) -> list[UUID]:
        return [ASSET_ID]

    async def mapping_targets(self, asset_ids: list[UUID]) -> dict[str, list[dict[str, Any]]]:
        assert asset_ids == [ASSET_ID]
        return {"assets": [ASSET], "fields": FIELDS, "metrics": METRICS}

    async def upsert_link(
        self, *, term_id: UUID, target_type: str, target_id: UUID, confidence: float, source: str, rationale: str, model: str | None = None
    ) -> tuple[dict[str, Any], bool]:
        key = (term_id, target_type, target_id)
        created = key not in self.rows
        row = self.rows.get(key)
        if row is None or (row["status"] == "suggested" and confidence > row["confidence"]):
            row = {
                "id": row["id"] if row else uuid4(), "term_id": term_id, "target_type": target_type, "target_id": target_id,
                "confidence": confidence, "source": source, "rationale": rationale, "model": model, "status": "suggested",
            }
            self.rows[key] = row
        return self._public(row), created

    def _public(self, row: dict[str, Any]) -> dict[str, Any]:
        term = self._term(row["term_id"])
        return {
            **row, "term_key": term["key"], "term_name": term["name"], "domain_key": term["domain_key"], "target_label": "x",
            "target_context": ASSET["fqn"], "asset_id": ASSET_ID, "created_at": datetime.now(tz=UTC), "decided_at": None,
        }

    async def links(
        self, *, status: str | None, target_type: str | None, target_id: UUID | None, term_id: UUID | None,
        asset_id: UUID | None = None, term_status: str | None = None, limit: int, offset: int,
    ) -> tuple[list[dict[str, Any]], int]:
        rows = [
            self._public(r) for r in self.rows.values()
            if (status is None or r["status"] == status) and (target_type is None or r["target_type"] == target_type)
        ]
        return rows[offset : offset + limit], len(rows)

    async def decide_link(self, link_id: UUID, status: str) -> dict[str, Any] | None:
        for row in self.rows.values():
            if row["id"] == link_id:
                row["status"] = status
                if status == "accepted" and row["target_type"] == "field":
                    term = self._term(row["term_id"])
                    self.field_synonyms[row["target_id"]] = sorted({*term["synonyms"], term["name"]})
                return self._public(row)
        return None

    async def create_curated_link(self, *, term_id: UUID, target_type: str, target_id: UUID) -> dict[str, Any]:
        row = {
            "id": uuid4(), "term_id": term_id, "target_type": target_type, "target_id": target_id, "confidence": 1.0,
            "source": "curated", "rationale": "linked by a person", "model": None, "status": "accepted",
        }
        self.rows[(term_id, target_type, target_id)] = row
        return self._public(row)


MODEL_ANSWER = """Sure, here is the mapping:
{"domain_key": "experience",
 "asset_terms": [{"term_key": "lapse", "confidence": 0.9, "rationale": "lapse experience study"},
                 {"term_key": "not_a_term", "confidence": 0.9, "rationale": "invented"}],
 "field_terms": [{"field": "POLICY_NO", "term_key": "policy_number", "confidence": 0.95},
                 {"field": "object_id", "term_key": "ingestion_timestamp", "confidence": 1.7},
                 {"field": "no_such_column", "term_key": "premium", "confidence": 0.9}],
 "metric_terms": [{"metric": "Total Premium", "term_key": "premium", "confidence": 0.8}]}
Done."""


class FakeModel:
    model = "claude-fake"

    def __init__(self, answers: list[str]) -> None:
        self.answers = list(answers)
        self.prompts: list[str] = []

    def describe(self) -> str:
        return self.model

    async def complete(self, *, system: str, tools: list[Any], messages: list[dict[str, Any]], **_: Any) -> ModelTurn:
        self.prompts.append(messages[-1]["content"])
        answer = self.answers.pop(0)
        return ModelTurn(content=[{"type": "text", "text": answer}], stop_reason="end_turn", model=self.model)


async def _wait(service: GlossaryService, run_id: UUID) -> None:
    for _ in range(200):
        run = service.get_run(run_id)
        if run is not None and run.status != "running":
            return
        await asyncio.sleep(0.01)


def _service(repo: FakeRepo, model: FakeModel | None = None, reason: str | None = None) -> GlossaryService:
    return GlossaryService(repo, model=model, unavailable_reason=reason)  # type: ignore[arg-type]


def _term_key(repo: FakeRepo, key: tuple[UUID, str, UUID]) -> str:
    return next(t["key"] for t in CATALOG if t["id"] == key[0])


# --------------------------------------------------------------------------- name rules


def test_normalize_splits_camel_snake_and_kebab_case():
    assert normalize("PolicyNumber") == "policy number"
    assert normalize("policy_number") == "policy number"
    assert normalize("Policy-Number ") == "policy number"
    assert normalize("") == ""


def test_term_index_matches_names_synonyms_prefixes_and_identifier_suffixes():
    index = TermIndex(CATALOG)
    hit = index.match("policy_number")
    assert hit is not None and (hit[0]["key"], hit[1]) == ("policy_number", 0.92) and "name" in hit[2]
    hit = index.match("POLICY_NO")
    assert hit is not None and (hit[0]["key"], hit[1]) == ("policy_number", 0.86)  # synonym "policy no"
    hit = index.match("dim_policy")
    assert hit is not None and (hit[0]["key"], hit[1]) == ("policy", 0.85)  # prefix stripped
    hit = index.match("customer_sk")
    assert hit is not None and (hit[0]["key"], hit[1]) == ("customer", 0.8)  # identifier suffix
    hit = index.match("ingested_at")
    assert hit is not None and hit[0]["key"] == "ingestion_timestamp"
    assert index.match("object_id") is None
    assert index.match("annual_premium_amt") is None  # too loose for a rule; Claude's job


def test_term_index_contains_prefers_longer_phrases_and_skips_short_tokens():
    index = TermIndex(CATALOG)
    hit = index.contains("fct_lapse_experience")
    assert hit is not None and (hit[0]["key"], hit[1]) == ("lapse", 0.62) and "lapse" in hit[2]
    hit = index.contains("stg_insurance_contract_daily")
    assert hit is not None and (hit[0]["key"], hit[1]) == ("policy", 0.7)  # two-word synonym beats the single word
    assert index.contains("raw_abc") is None


# --------------------------------------------------------------------------- model answer


def test_parse_mapping_drops_unknown_terms_columns_and_clamps_confidence():
    out = parse_mapping(MODEL_ANSWER, known_terms=set(BY_KEY), known_domains={d["key"] for d in DOMAINS}, fields=FIELDS, metrics=METRICS)
    assert out["domain_key"] == "experience"
    assert [a["term_key"] for a in out["asset_terms"]] == ["lapse"]
    assert {(f["field_id"], f["term_key"], f["confidence"]) for f in out["field_terms"]} == {
        (F_POLICY_NO, "policy_number", 0.95),
        (F_OBJ, "ingestion_timestamp", 1.0),
    }
    assert out["metric_terms"] == [{"metric_id": M_PREMIUM, "term_key": "premium", "confidence": 0.8}]


def test_parse_mapping_rejects_answers_without_json():
    with pytest.raises(InvalidRequestError):
        parse_mapping("I cannot map this.", known_terms=set(), known_domains=set(), fields=[], metrics=[])
    with pytest.raises(InvalidRequestError):
        parse_mapping("[1, 2]", known_terms=set(), known_domains=set(), fields=[], metrics=[])


def test_prompt_carries_the_glossary_the_domains_and_the_dataset():
    prompt = build_prompt(CATALOG, DOMAINS, ASSET, FIELDS, METRICS)
    assert "- policy_number | Policy Number | policy | policy number, policy id" in prompt
    assert "DOMAINS (key | name): policy | Policy Administration" in prompt
    assert "DATASET: ins.gold.fct_lapse_experience" in prompt
    assert "- annual_premium_amt | measure | decimal |" in prompt
    assert "- total_premium | sum(annual_premium_amt)" in prompt


# --------------------------------------------------------------------------- service


def test_rules_only_run_proposes_links_and_explains_itself():
    repo = FakeRepo()
    service = _service(repo, None, "no key")
    run = asyncio.run(service.start_map(MapRequest(use_model=False)))
    assert run.status == "completed"
    assert run.rule_links == 5  # asset->lapse, POLICY_NO, customer_sk, ingested_at, total_premium
    assert run.model_links == 0 and run.total == 0
    assert run.message == "Name rules proposed 5 links."
    kinds = {(_term_key(repo, key), key[1]) for key in repo.rows}
    assert {("lapse", "asset"), ("premium", "metric"), ("policy_number", "field"), ("customer", "field"), ("ingestion_timestamp", "field")} == kinds


def test_run_says_when_claude_is_not_configured():
    service = _service(FakeRepo(), None, "ANTHROPIC_API_KEY unset")
    run = asyncio.run(service.start_map(MapRequest()))
    assert run.status == "completed"
    assert run.message is not None and "Claude is not configured (ANTHROPIC_API_KEY unset)" in run.message


def test_model_run_adds_claude_proposals_without_duplicating_rule_links():
    repo = FakeRepo()
    model = FakeModel([MODEL_ANSWER])
    service = _service(repo, model)

    async def go():
        run = await service.start_map(MapRequest())
        assert run.status == "running" and run.total == 1
        await _wait(service, run.id)
        return service.get_run(run.id)

    run = asyncio.run(go())
    assert run is not None
    assert run.status == "completed"
    assert (run.done, run.failed) == (1, 0)
    assert run.rule_links == 5
    # Claude repeated three rule links (lapse, POLICY_NO, total premium) and added one: object_id -> ingestion timestamp.
    assert run.model_links == 1
    assert run.message == "Name rules proposed 5 links; Claude proposed 1 across 1 datasets."
    assert "GLOSSARY (key | name | domain | synonyms)" in model.prompts[0]
    # The rule's lower confidence on POLICY_NO was raised by Claude's 0.95.
    key = (BY_KEY["policy_number"]["id"], "field", F_POLICY_NO)
    assert repo.rows[key]["confidence"] == 0.95 and repo.rows[key]["source"] == "model"


def test_model_failure_on_one_dataset_is_recorded_not_fatal():
    class Broken(FakeModel):
        async def complete(self, **_: Any) -> ModelTurn:
            raise RuntimeError("boom")

    service = _service(FakeRepo(), Broken([]))

    async def go():
        run = await service.start_map(MapRequest())
        await _wait(service, run.id)
        return service.get_run(run.id)

    run = asyncio.run(go())
    assert run is not None
    assert run.status == "failed" and run.failed == 1 and run.error is not None and "boom" in run.error


def test_accepting_a_link_copies_synonyms_and_decisions_are_reflected():
    repo = FakeRepo()
    service = _service(repo)

    async def go():
        await service.start_map(MapRequest(use_model=False))
        suggested, total = await service.links(status="suggested", target_type="field", target_id=None, term_id=None, limit=50, offset=0)
        accepted = await service.decide(next(x for x in suggested if x.target_id == F_POLICY_NO).id, "accept")
        rejected = await service.decide(next(x for x in suggested if x.target_id == F_CUSTOMER_SK).id, "reject")
        return total, accepted, rejected

    total, accepted, rejected = asyncio.run(go())
    assert total == 3
    assert accepted.status == "accepted" and rejected.status == "rejected"
    assert repo.field_synonyms[F_POLICY_NO] == ["Policy Number", "contract number", "policy id", "policy no", "policy number"]


def test_curated_link_is_accepted_at_once():
    service = _service(FakeRepo())
    link = asyncio.run(service.create_link(LinkCreate(term_id=BY_KEY["exposure"]["id"], target_type="asset", target_id=ASSET_ID)))
    assert link.status == "accepted" and link.source == "curated" and link.confidence == 1.0


def test_domain_tree_nests_children_and_rolls_counts_up():
    service = _service(FakeRepo())
    tree = asyncio.run(service.domains())
    assert [d.key for d in tree] == ["party", "policy", "experience", "data_platform"]
    policy = next(d for d in tree if d.key == "policy")
    assert [c.key for c in policy.children] == ["policy_lifecycle"]
    assert (policy.term_count, policy.kpi_count) == (4, 3)
    party = next(d for d in tree if d.key == "party")
    assert [c.key for c in party.children] == ["customer"] and party.term_count == 1


# --------------------------------------------------------------------------- proposing new terms

PROPOSAL_ANSWER = """{"terms": [
 {"name": "Annual Premium", "kind": "measure", "domain_key": "policy", "definition": "Premium payable for one policy year.",
  "synonyms": ["annual premium", "yearly premium"],
  "columns": [{"dataset": "ins.gold.fct_lapse_experience", "column": "annual_premium_amt"}],
  "metrics": [{"dataset": "ins.gold.fct_lapse_experience", "metric": "total_premium"}],
  "confidence": 0.9, "rationale": "a premium amount per policy year"},
 {"name": "Client", "kind": "entity", "domain_key": "customer", "definition": "The buyer.", "synonyms": ["client"],
  "columns": [{"dataset": "ins.gold.fct_lapse_experience", "column": "customer_sk"}], "confidence": 0.8, "rationale": "a customer key"},
 {"name": "Ghost", "kind": "entity", "domain_key": "nowhere", "columns": [{"dataset": "x", "column": "nope"}], "confidence": 0.9},
 {"name": "Object Identifier", "kind": "attribute", "domain_key": "data_platform", "definition": "Technical id.",
  "synonyms": ["object id"], "columns": [{"dataset": "ins.gold.fct_lapse_experience", "column": "OBJECT_ID"}], "confidence": 0.6}
]}"""


def test_batch_targets_groups_by_dataset_and_splits_big_ones():
    targets = {"assets": [ASSET], "fields": FIELDS, "metrics": METRICS}
    assert len(batch_targets(targets, 40)) == 1
    small = batch_targets(targets, 4)  # 5 columns + 1 metric -> two chunks of the same dataset
    assert [len(b) for b in small] == [1, 1]
    assert len(small[0][0]["fields"]) == 4 and len(small[1][0]["fields"]) == 1 and len(small[1][0]["metrics"]) == 1
    assert batch_targets({"assets": [ASSET], "fields": [], "metrics": []}, 40) == []


def test_parse_term_proposals_keeps_only_grounded_terms():
    batch = [{"asset": ASSET, "fields": FIELDS, "metrics": METRICS}]
    out = parse_term_proposals(PROPOSAL_ANSWER, known_domains={"policy", "customer", "data_platform"}, batch=batch)
    assert [t["name"] for t in out] == ["Annual Premium", "Client", "Object Identifier"]
    annual = out[0]
    assert annual["field_ids"] == [F_PREMIUM] and annual["metric_ids"] == [M_PREMIUM] and annual["confidence"] == 0.9
    assert out[2]["field_ids"] == [F_OBJ]  # column names match case-insensitively
    with pytest.raises(InvalidRequestError):
        parse_term_proposals('{"nope": 1}', known_domains=set(), batch=batch)


def test_propose_run_creates_candidate_terms_links_evidence_and_dedupes():
    repo = FakeRepo()
    model = FakeModel([PROPOSAL_ANSWER])
    service = _service(repo, model)

    async def go():
        run = await service.start_propose(ProposeTermsRequest())
        assert run.mode == "propose" and run.status == "running" and run.total == 1
        await _wait(service, run.id)
        return service.get_run(run.id)

    run = asyncio.run(go())
    assert run is not None and run.status == "completed" and run.failed == 0
    # Annual Premium and Object Identifier are new; "Client" is the existing Customer term (its synonym "client").
    assert run.terms_proposed == 2
    assert run.model_links == 4
    names = {t["name"]: t for t in repo.proposed}
    assert set(names) == {"Annual Premium", "Object Identifier"}
    assert names["Annual Premium"]["status"] == "proposed" and names["Annual Premium"]["proposed_by"] == "claude-fake"
    assert names["Annual Premium"]["key"] == "annual_premium"
    customer_link = repo.rows[(BY_KEY["customer"]["id"], "field", F_CUSTOMER_SK)]
    assert "already covers" in customer_link["rationale"] and customer_link["source"] == "model"
    assert (names["Annual Premium"]["id"], "metric", M_PREMIUM) in repo.rows
    assert run.message == "Claude proposed 2 new terms and 4 links from 5 unmapped columns and 1 unmapped metrics."
    assert "EXISTING TERMS (do not propose these or near-duplicates): " in model.prompts[0]
    assert "UNMAPPED COLUMNS" in model.prompts[0] and "- annual_premium_amt | measure | decimal |" in model.prompts[0]


def test_failing_batch_is_halved_and_retried():
    class Flaky(FakeModel):
        calls = 0

        async def complete(self, **kw: Any) -> ModelTurn:
            self.calls += 1
            if self.calls == 1:
                raise TimeoutError("Request timed out or interrupted.")
            return await super().complete(**kw)

    repo = FakeRepo()
    model = Flaky([PROPOSAL_ANSWER, PROPOSAL_ANSWER])
    service = _service(repo, model)

    async def go():
        run = await service.start_propose(ProposeTermsRequest())
        await _wait(service, run.id)
        return service.get_run(run.id)

    run = asyncio.run(go())
    assert run is not None and run.status == "completed"
    assert (run.done, run.failed) == (1, 0)
    assert model.calls == 3  # the whole batch, then its two halves
    # Each half only carries part of the evidence, and the term created by the first half is reused by the second.
    assert run.terms_proposed == 2 and run.model_links == 4
    assert len(split_batch([{"asset": ASSET, "fields": FIELDS[:1], "metrics": []}])) == 1


def test_propose_run_needs_claude():
    service = _service(FakeRepo(), None, "no key")
    with pytest.raises(DependencyUnavailableError):
        asyncio.run(service.start_propose(ProposeTermsRequest()))


def test_deciding_a_proposed_term_accepts_its_links_or_deletes_it():
    repo = FakeRepo()
    service = _service(repo, FakeModel([PROPOSAL_ANSWER]))

    async def go():
        run = await service.start_propose(ProposeTermsRequest())
        await _wait(service, run.id)
        annual = next(t for t in repo.proposed if t["name"] == "Annual Premium")
        technical = next(t for t in repo.proposed if t["name"] == "Object Identifier")
        accepted = await service.decide_term(annual["id"], TermDecision(decision="accept", accept_links=True))
        rejected = await service.decide_term(technical["id"], TermDecision(decision="reject"))
        return annual, accepted, rejected

    annual, accepted, rejected = asyncio.run(go())
    assert accepted.links_accepted == 2 and annual["status"] == "curated"
    assert repo.rows[(annual["id"], "field", F_PREMIUM)]["status"] == "accepted"
    assert rejected.decision == "reject" and all(t["name"] != "Object Identifier" for t in repo.proposed)
    assert not any(key[1] == "field" and key[2] == F_OBJ for key in repo.rows)


# --------------------------------------------------------------------------- mapping after a sync


def test_fingerprint_sees_source_changes_but_not_review_decisions():
    base = mapping_fingerprint(ASSET, FIELDS, METRICS)
    reviewed_asset = {**ASSET, "display_name": "Lapse Study", "domain_key": "experience", "summary": "Accepted summary."}
    reviewed_fields = [{**f, "synonyms": ["policy number"], "display_name": "Policy No", "role": "attribute"} for f in FIELDS]
    assert mapping_fingerprint(reviewed_asset, list(reversed(reviewed_fields)), METRICS) == base
    retyped = [{**f, "data_type": "int"} if f["name"] == "POLICY_NO" else f for f in FIELDS]
    assert mapping_fingerprint(ASSET, retyped, METRICS) != base
    assert mapping_fingerprint(ASSET, [*FIELDS, {**FIELDS[0], "name": "lapse_reason"}], METRICS) != base
    assert mapping_fingerprint({**ASSET, "description": "Now one row per policy-month."}, FIELDS, METRICS) != base
    assert mapping_fingerprint(ASSET, FIELDS, [{**METRICS[0], "expression": "avg(annual_premium_amt)"}]) != base


class ChangingRepo(FakeRepo):
    def __init__(self) -> None:
        super().__init__()
        self.fields = list(FIELDS)

    async def mapping_targets(self, asset_ids: list[UUID]) -> dict[str, list[dict[str, Any]]]:
        return {"assets": [ASSET], "fields": self.fields, "metrics": METRICS}


def test_auto_map_sends_only_new_or_changed_datasets_to_claude():
    repo = ChangingRepo()
    model = FakeModel([MODEL_ANSWER, MODEL_ANSWER])
    service = _service(repo, model)

    first, datasets = asyncio.run(service.auto_map("snowflake"))
    assert first.trigger == "sync" and first.status == "completed" and datasets == 1
    assert (first.total, first.skipped, first.done, first.rule_links, first.model_links) == (1, 0, 1, 5, 1)
    assert ASSET_ID in repo.fingerprints and len(model.prompts) == 1

    # Nothing changed at the source: the rules run again (nothing new to add), Claude is not asked.
    second, _ = asyncio.run(service.auto_map("snowflake"))
    assert (second.total, second.skipped, second.rule_links, second.model_links) == (0, 1, 0, 0)
    assert second.message == "Name rules proposed 0 links; all 1 datasets are unchanged since Claude last mapped them."
    assert len(model.prompts) == 1

    # A column changes type at the source: the dataset goes back to Claude.
    repo.fields = [{**f, "data_type": "int"} if f["name"] == "POLICY_NO" else f for f in FIELDS]
    third, _ = asyncio.run(service.auto_map("snowflake"))
    assert (third.total, third.skipped, third.done) == (1, 0, 1) and len(model.prompts) == 2
    assert third.message == "Name rules proposed 0 links; Claude proposed 0 across 1 datasets."
    assert {r.trigger for r in service.list_runs()} == {"sync"}


def test_auto_map_without_claude_runs_the_name_rules_only():
    repo = FakeRepo()
    run, datasets = asyncio.run(_service(repo, None, "no key").auto_map("snowflake"))
    assert run.status == "completed" and datasets == 1 and run.rule_links == 5 and run.total == 0
    assert run.message == "Name rules proposed 5 links across 1 datasets; Claude is not configured (no key)."
    assert repo.fingerprints == {}


def test_a_failed_claude_call_leaves_the_dataset_for_the_next_sync():
    class Broken(FakeModel):
        async def complete(self, **_: Any) -> ModelTurn:
            raise RuntimeError("gateway timeout")

    repo = FakeRepo()
    run, _ = asyncio.run(_service(repo, Broken([])).auto_map("snowflake"))
    assert run.status == "failed" and run.failed == 1 and repo.fingerprints == {}


def test_a_manual_claude_run_counts_as_mapped_for_the_next_sync():
    repo = FakeRepo()
    service = _service(repo, FakeModel([MODEL_ANSWER]))

    async def go():
        run = await service.start_map(MapRequest())
        await _wait(service, run.id)
        return await service.auto_map("snowflake")

    run, _ = asyncio.run(go())
    assert (run.total, run.skipped) == (0, 1)


# --------------------------------------------------------------------------- grouped review


class GroupRepo(FakeRepo):
    """Links as the review sees them: the same column name in several datasets."""

    def __init__(self, rows: list[dict[str, Any]]) -> None:
        super().__init__()
        self.listed = rows

    async def links(self, **kw: Any) -> tuple[list[dict[str, Any]], int]:
        return self.listed, len(self.listed)


def _listed(term: dict[str, Any], label: str, dataset: str, confidence: float, source: str = "model") -> dict[str, Any]:
    return {
        "id": uuid4(), "term_id": term["id"], "term_key": term["key"], "term_name": term["name"], "domain_key": term["domain_key"],
        "target_type": "field", "target_id": uuid4(), "target_label": label, "target_context": dataset, "asset_id": uuid4(),
        "confidence": confidence, "source": source, "status": "suggested", "rationale": "", "model": None,
        "created_at": datetime.now(tz=UTC), "decided_at": None,
    }


def test_link_groups_put_the_same_column_and_term_together_biggest_first():
    rows = [
        _listed(BY_KEY["policy_number"], "POLICY_ID", "ins.policy.coverage", 0.85),
        _listed(BY_KEY["policy_number"], "policy_id", "ins.claims.claim", 0.9, "rule"),
        _listed(BY_KEY["policy_number"], "POLICY_ID", "ins.billing.invoice", 0.8),
        _listed(BY_KEY["premium"], "ANNUAL_PREMIUM", "ins.policy.policy", 0.95),
        _listed(BY_KEY["customer"], "POLICY_ID", "ins.policy.policy", 0.6),
    ]
    groups, total = asyncio.run(_service(GroupRepo(rows)).link_groups(status="suggested", target_type=None, term_status="reviewed", limit=50, offset=0))
    assert total == 3
    top = groups[0]
    assert (top.term_name, top.target_label, top.count) == ("Policy Number", "POLICY_ID", 3)
    assert (top.min_confidence, top.max_confidence, top.sources) == (0.8, 0.9, ["model", "rule"])
    assert [link.target_context for link in top.links] == ["ins.billing.invoice", "ins.claims.claim", "ins.policy.coverage"]
    # Same column, different term: a separate decision.
    assert {(g.target_label, g.term_name) for g in groups[1:]} == {("ANNUAL_PREMIUM", "Premium"), ("POLICY_ID", "Customer")}
    page, _ = asyncio.run(_service(GroupRepo(rows)).link_groups(status="suggested", target_type=None, term_status="reviewed", limit=1, offset=1))
    assert [g.target_label for g in page] == ["ANNUAL_PREMIUM"]


def test_deciding_many_applies_each_decision_and_counts_unknown_ids():
    repo = FakeRepo()
    service = _service(repo, None, "no key")
    asyncio.run(service.start_map(MapRequest(use_model=False)))
    fields = [r for r in repo.rows.values() if r["target_type"] == "field"]
    result = asyncio.run(service.decide_many([r["id"] for r in fields] + [uuid4()], "accept"))
    assert (result.decision, result.decided, result.missing) == ("accept", len(fields), 1)
    assert all(r["status"] == "accepted" for r in fields)
    assert repo.field_synonyms[F_POLICY_NO]  # accepting copied the term's synonyms, as a single decision would
