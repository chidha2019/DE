"""Semantic layer: role and kind inference, join inference, rendering, exports."""

from __future__ import annotations

import json

import yaml

from ech_core.semantic.exports import export
from ech_core.semantic.inference import classify_asset, infer_asset, infer_joins, referenced_fqns
from ech_core.semantic.models import (
    AssetKind,
    AssetType,
    FieldRole,
    MetricSource,
    Platform,
    RelationshipKind,
    SemanticAsset,
    SemanticField,
)
from ech_core.semantic.render import owner_is_person, render_asset_markdown


def field(name: str, data_type: str, **kw) -> SemanticField:
    return SemanticField(name=name, data_type=data_type, **kw)


def make_assets() -> tuple[SemanticAsset, SemanticAsset]:
    fact = SemanticAsset(
        platform=Platform.DATABRICKS,
        fqn="sales.gold.fact_orders",
        database="sales",
        schema_name="gold",
        name="fact_orders",
        description="One row per order.",
        fields=[
            field("order_id", "bigint", ordinal=0, is_primary_key=True),
            field("customer_id", "bigint", ordinal=1),
            field("order_date", "date", ordinal=2),
            field("total_amount", "decimal(18,2)", ordinal=3, description="Order total"),
            field("status", "string", ordinal=4),
            field("notes", "string", ordinal=5),
            field("discount_pct", "double", ordinal=6),
        ],
    )
    dim = SemanticAsset(
        platform=Platform.DATABRICKS,
        fqn="sales.gold.dim_customer",
        database="sales",
        schema_name="gold",
        name="dim_customer",
        fields=[
            field("customer_id", "bigint", ordinal=0, is_primary_key=True),
            field("customer_name", "string", ordinal=1),
            field("segment", "string", ordinal=2),
            field("signup_date", "date", ordinal=3),
            field("age", "int", ordinal=4),
        ],
    )
    return infer_asset(fact), infer_asset(dim)


def test_kind_and_field_roles():
    fact, dim = make_assets()
    assert fact.kind is AssetKind.FACT and dim.kind is AssetKind.DIMENSION
    assert {f.name: f.role for f in fact.fields} == {
        "order_id": FieldRole.IDENTIFIER,
        "customer_id": FieldRole.IDENTIFIER,
        "order_date": FieldRole.TIME,
        "total_amount": FieldRole.MEASURE,
        "status": FieldRole.DIMENSION,
        "notes": FieldRole.ATTRIBUTE,
        "discount_pct": FieldRole.MEASURE,
    }
    assert fact.field("total_amount").aggregation == "sum"
    assert fact.field("discount_pct").aggregation == "avg"
    assert all(0 < f.role_confidence < 1 for f in fact.fields), "inferred, never declared"
    assert dim.field("age").role is FieldRole.DIMENSION, "a number on a dimension table"


def test_inferred_metrics_and_declared_roles_are_kept():
    fact, _ = make_assets()
    metrics = {m.name: m for m in fact.metrics}
    assert metrics["total_amount"].expression == "SUM(total_amount)", "no total_total_amount"
    assert metrics["average_discount_pct"].aggregation == "avg"
    assert metrics["record_count"].expression == "COUNT(*)"
    assert "status" in metrics["record_count"].dimensions
    assert all(m.source is MetricSource.INFERRED for m in fact.metrics)

    declared = SemanticAsset(
        platform=Platform.SNOWFLAKE,
        fqn="A.B.MV",
        database="A",
        schema_name="B",
        name="MV",
        asset_type=AssetType.METRIC_VIEW,
        fields=[
            field(
                "Claim count",
                "bigint",
                role=FieldRole.MEASURE,
                role_confidence=1.0,
                aggregation="count",
            )
        ],
    )
    infer_asset(declared)
    assert declared.kind is AssetKind.METRIC
    assert (
        declared.fields[0].role is FieldRole.MEASURE and declared.fields[0].role_confidence == 1.0
    )
    assert declared.metrics == [], "metric definitions get no inferred metrics"


def test_join_inference():
    fact, dim = make_assets()
    joins = infer_joins([fact, dim])
    assert list(joins) == ["sales.gold.fact_orders"]
    (rel,) = joins["sales.gold.fact_orders"]
    assert rel.kind is RelationshipKind.JOIN_INFERRED and rel.target_fqn == dim.fqn
    assert rel.source_columns == ["customer_id"] and rel.target_columns == ["customer_id"]
    assert rel.confidence == 0.85 and "primary key of dim_customer" in rel.evidence


def test_classify_and_referenced_fqns():
    assert classify_asset("bridge_policy_coverage", AssetType.TABLE) is AssetKind.BRIDGE
    assert classify_asset("ref_claim_status", AssetType.TABLE) is AssetKind.REFERENCE
    assert classify_asset("anything", AssetType.METRIC_VIEW) is AssetKind.METRIC
    assert (
        classify_asset("customer", AssetType.TABLE, "Grain: one row per customer") is AssetKind.FACT
    )
    assert classify_asset("customer", AssetType.TABLE) is AssetKind.UNKNOWN
    sql = 'SELECT * FROM cat.sch.tbl t JOIN `c2`.`s2`.`t2` x ON t.id = x.id WHERE "DB"."S"."V" IS NOT NULL'
    assert referenced_fqns(sql) == ["cat.sch.tbl", "c2.s2.t2", "DB.S.V"]


def test_owner_detection():
    assert owner_is_person("ana@example.com") and owner_is_person("Priya Natarajan")
    assert not owner_is_person("System user")
    assert not owner_is_person("ANALYTICS_ADMIN")
    assert not owner_is_person("3f2b1a9c-1111-4ccc-8888-aaaaaaaaaaaa")
    assert not owner_is_person(None)


def test_render_markdown_sections():
    fact, dim = make_assets()
    fact.relationships += infer_joins([fact, dim])[fact.fqn]
    text = render_asset_markdown(fact)
    assert text.startswith("# sales.gold.fact_orders")
    assert "## Columns" in text and "| 0 | `order_id` |" in text
    assert "## Keys and relationships" in text and "Primary key: `order_id`" in text
    assert "Probably joins `sales.gold.dim_customer` on `customer_id` = `customer_id`" in text
    assert "## Metrics" in text and "**record_count**" in text and "Inferred:" in text
    assert "Grain and roles: identifiers: order_id, customer_id" in text


def test_exports():
    fact, dim = make_assets()
    fact.relationships += infer_joins([fact, dim])[fact.fqn]

    cortex, media = export([fact, dim], fmt="cortex", name="sales gold")
    model = yaml.safe_load(cortex)
    assert media == "application/yaml" and model["name"] == "sales_gold"
    assert len(model["tables"]) == 2
    orders = next(t for t in model["tables"] if t["name"] == "fact_orders")
    assert orders["base_table"] == {"database": "sales", "schema": "gold", "table": "fact_orders"}
    assert orders["primary_key"] == {"columns": ["order_id"]}
    assert {d["name"] for d in orders["time_dimensions"]} == {"order_date"}
    assert {f["name"] for f in orders["facts"]} == {"total_amount", "discount_pct"}
    assert any(
        m["name"] == "record_count" and "[inferred]" in m["description"] for m in orders["metrics"]
    )
    (rel,) = model["relationships"]
    assert rel["left_table"] == "fact_orders" and rel["right_table"] == "dim_customer"
    assert rel["relationship_columns"] == [
        {"left_column": "customer_id", "right_column": "customer_id"}
    ]

    mv, _ = export([fact, dim], fmt="databricks_metric_view", name="x")
    spec = yaml.safe_load(mv.split("\n---\n")[0].split("\n", 1)[1])
    assert spec["source"] == "sales.gold.fact_orders"
    assert spec["joins"] == [
        {
            "name": "dim_customer",
            "source": "sales.gold.dim_customer",
            "on": "source.customer_id = dim_customer.customer_id",
        }
    ]
    assert {d["name"] for d in spec["dimensions"]} >= {
        "status",
        "order_date",
        "dim_customer_segment",
    }
    assert any(m["expr"] == "COUNT(*)" for m in spec["measures"])

    hub, media = export([fact], fmt="hub", name="x")
    assert media == "application/json" and json.loads(hub)[0]["fqn"] == "sales.gold.fact_orders"
