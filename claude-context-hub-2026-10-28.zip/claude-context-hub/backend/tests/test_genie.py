"""Genie: the Cypher guard, strict tool schemas, the streamed ask loop and the SSE endpoint."""

from __future__ import annotations

import json
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from types import SimpleNamespace
from typing import Any
from uuid import UUID, uuid4

import pytest
from fastapi.testclient import TestClient

from ech_core.app_factory import create_app
from ech_core.config import Settings
from ech_core.exceptions import DependencyUnavailableError, NotFoundError
from ech_core.llm import ModelTurn, StreamEvent
from ech_core.observability import LatencyRecorder
from ech_core.schemas.context import (
    ContextChunk,
    ContextRetrieveRequest,
    ContextRetrieveResponse,
    ScoreBreakdown,
    StageTimings,
)
from ech_core.schemas.genie import GenieAskRequest
from query_service.api import api_router
from query_service.genie.service import GenieService, _history, _split_follow_ups
from query_service.genie.tools import TOOLS, CypherRejectedError, guard_cypher

SPACE_ID = UUID("00000000-0000-4000-8000-000000000001")
DOC_ID = uuid4()
CHUNK_A, CHUNK_B = uuid4(), uuid4()
NOW = datetime.now(tz=UTC)
_STRICT_UNSUPPORTED = {
    "minimum",
    "maximum",
    "minLength",
    "maxLength",
    "minItems",
    "maxItems",
    "pattern",
}


# ----------------------------------------------------------------------------- fakes
class FakeGenieRepo:
    def __init__(self) -> None:
        self.spaces: dict[UUID, dict[str, Any]] = {
            SPACE_ID: {
                "id": SPACE_ID,
                "name": "Everything in the hub",
                "description": "All sources.",
                "instructions": "",
                "filters": {},
                "sample_questions": ["What is indexed?"],
                "is_default": True,
                "created_at": NOW,
                "updated_at": NOW,
                "conversation_count": 0,
            }
        }
        self.conversations: dict[UUID, dict[str, Any]] = {}
        self.messages: dict[UUID, list[dict[str, Any]]] = {}

    async def list_spaces(self):
        return list(self.spaces.values())

    async def get_space(self, space_id):
        return self.spaces.get(space_id)

    async def create_space(self, **fields):
        space_id = uuid4()
        row = {"id": space_id, **fields, "is_default": False, "created_at": NOW, "updated_at": NOW}
        self.spaces[space_id] = {**row, "conversation_count": 0}
        return self.spaces[space_id]

    async def update_space(self, space_id, fields):
        row = self.spaces.get(space_id)
        if row:
            row.update(fields)
        return row

    async def delete_space(self, space_id):
        row = self.spaces.get(space_id)
        if not row or row["is_default"]:
            return False
        del self.spaces[space_id]
        return True

    async def create_conversation(self, space_id, title):
        conversation_id = uuid4()
        row = {
            "id": conversation_id,
            "space_id": space_id,
            "title": title,
            "created_at": NOW,
            "updated_at": NOW,
        }
        self.conversations[conversation_id] = row
        self.messages[conversation_id] = []
        return await self.get_conversation(conversation_id)

    async def get_conversation(self, conversation_id):
        row = self.conversations.get(conversation_id)
        if row is None:
            return None
        msgs = self.messages[conversation_id]
        return {
            **row,
            "message_count": len(msgs),
            "last_message_at": msgs[-1]["created_at"] if msgs else None,
        }

    async def list_conversations(self, space_id, *, limit, offset):
        rows = [
            await self.get_conversation(c)
            for c in self.conversations
            if self.conversations[c]["space_id"] == space_id
        ]
        return rows[offset : offset + limit], len(rows)

    async def touch_conversation(self, conversation_id):
        return None

    async def delete_conversation(self, conversation_id):
        return self.conversations.pop(conversation_id, None) is not None

    async def add_message(
        self,
        conversation_id,
        *,
        role,
        content,
        status="complete",
        error=None,
        citations=None,
        trace=None,
        follow_ups=None,
        usage=None,
        model=None,
        latency_ms=None,
    ):
        row = {
            "id": uuid4(),
            "conversation_id": conversation_id,
            "role": role,
            "content": content,
            "status": status,
            "error": error,
            "citations": citations or [],
            "trace": trace or [],
            "follow_ups": follow_ups or [],
            "usage": usage or {},
            "model": model,
            "latency_ms": latency_ms,
            "feedback": None,
            "created_at": datetime.now(tz=UTC),
        }
        self.messages[conversation_id].append(row)
        return row

    async def list_messages(self, conversation_id):
        return list(self.messages.get(conversation_id, []))

    async def set_feedback(self, message_id, value):
        for msgs in self.messages.values():
            for m in msgs:
                if m["id"] == message_id and m["role"] == "assistant":
                    m["feedback"] = value
                    return m
        return None


class FakeEngine:
    def __init__(self) -> None:
        self.requests: list[ContextRetrieveRequest] = []

    async def retrieve(self, request: ContextRetrieveRequest, *, request_id=None):
        self.requests.append(request)

        def chunk(chunk_id: UUID, index: int, text: str, score: float) -> ContextChunk:
            return ContextChunk(
                chunk_id=chunk_id,
                document_id=DOC_ID,
                document_title="omniclaim-lakehouse-pipelines/README.md",
                source_system="github",
                uri=None,
                chunk_index=index,
                section_path=["README", "Gold layer"],
                content=text,
                token_count=40,
                scores=ScoreBreakdown(fused=score, final=score),
                retrieval_paths=["vector", "keyword"],
                document_attributes={"path": "README.md", "repo": "acme/omniclaim"},
            )

        return ContextRetrieveResponse(
            query=request.effective_query(),
            top_k=request.top_k,
            results=[
                chunk(CHUNK_A, 0, "The gold layer is built with DuckDB.", 0.9),
                chunk(CHUNK_B, 1, "Fact tables are registered in config/assets.yml.", 0.7),
            ],
            timings=StageTimings(total_ms=5.0),
            candidates_considered=12,
            reranker="heuristic",
            embedding_model="hashing:v1",
        )


class FakeGraphDB:
    def __init__(self) -> None:
        self.queries: list[str] = []

    async def execute_read(self, query: str, **params):
        self.queries.append(query)
        return [{"name": "DuckDB", "mentions": 7}, {"name": "Parquet", "mentions": 3}]


class FakeAudit:
    def __init__(self) -> None:
        self.records: list[dict[str, Any]] = []

    async def record(self, **fields):
        self.records.append(fields)


class ScriptedModel:
    """Streams canned turns: text blocks arrive as two deltas, then the completed turn."""

    model = "scripted-model"

    def __init__(self, turns: list[ModelTurn]) -> None:
        self.turns = list(turns)
        self.requests: list[tuple[str, list[dict[str, Any]]]] = []

    async def stream(self, *, system, tools, messages):
        assert tools is TOOLS
        self.requests.append((system, json.loads(json.dumps(messages, default=str))))
        if not self.turns:
            raise AssertionError("model script exhausted")
        turn = self.turns.pop(0)
        for block in turn.content:
            if block.get("type") == "text":
                for piece in (block["text"][:5], block["text"][5:]):
                    if piece:
                        yield StreamEvent("text", text=piece)
        yield StreamEvent("message", turn=turn)


class FailingModel:
    model = "failing-model"

    async def stream(self, **_):
        raise RuntimeError("gateway down")
        yield  # pragma: no cover - makes this an async generator


def tool_use(id_: str, name: str, **inp: Any) -> dict[str, Any]:
    return {"type": "tool_use", "id": id_, "name": name, "input": inp}


def text(value: str) -> dict[str, Any]:
    return {"type": "text", "text": value}


def turn(*blocks: dict[str, Any], stop: str = "tool_use") -> ModelTurn:
    return ModelTurn(
        content=list(blocks),
        stop_reason=stop,
        usage={"input_tokens": 100, "output_tokens": 50},
        model="scripted-model",
    )


def make_service(model, repo=None, engine=None, graph_db=None, semantic=None):
    repo = repo or FakeGenieRepo()
    engine = engine or FakeEngine()
    graph_db = graph_db or FakeGraphDB()
    service = GenieService(
        repo=repo,
        engine=engine,
        documents=SimpleNamespace(),
        chunks=SimpleNamespace(),
        graph=SimpleNamespace(),
        graph_db=graph_db,
        audit=FakeAudit(),
        settings=Settings(_env_file=None),
        model=model,
        unavailable_reason=None if model else "no model configured in the test",
        semantic=semantic,
    )
    return service, repo, engine, graph_db


def _schema_keys(node: Any) -> set[str]:
    keys: set[str] = set()
    if isinstance(node, dict):
        for key, value in node.items():
            if key == "properties" and isinstance(value, dict):
                for sub in value.values():
                    keys |= _schema_keys(sub)
                continue
            keys.add(key)
            keys |= _schema_keys(value)
    elif isinstance(node, list):
        for value in node:
            keys |= _schema_keys(value)
    return keys


# ----------------------------------------------------------------------------- guard + schemas
def test_cypher_guard_allows_reads_caps_limits_and_rejects_writes():
    assert guard_cypher("MATCH (n) RETURN n", row_limit=50).endswith("LIMIT 50")
    assert guard_cypher("MATCH (n) RETURN n LIMIT 10", row_limit=50).endswith("LIMIT 10")
    assert guard_cypher("MATCH (n) RETURN n LIMIT 500;", row_limit=50).endswith("LIMIT 50")
    assert "LIMIT 50" in guard_cypher("MATCH (n) RETURN n LIMIT 500 // all", row_limit=50)
    literal = "MATCH (d:Document) WHERE d.title = 'Data Set; DROP it' RETURN d.title // set\n"
    guarded = guard_cypher(literal, row_limit=5)
    assert guarded.startswith("MATCH") and guarded.endswith("LIMIT 5")
    for bad in [
        "CREATE (n) RETURN n",
        "MATCH (n) SET n.x = 1 RETURN n",
        "MATCH (n) DETACH DELETE n",
        "CALL db.labels()",
        "MATCH (n) RETURN n; MATCH (m) RETURN m",
        "LOAD CSV FROM 'x' AS row RETURN row",
        "MERGE (n:X) RETURN n",
        "",
    ]:
        with pytest.raises(CypherRejectedError):
            guard_cypher(bad, row_limit=50)


def test_genie_tool_schemas_are_strict():
    for tool in TOOLS:
        schema = tool["input_schema"]
        assert schema["additionalProperties"] is False
        assert set(schema["required"]) == set(schema["properties"]), tool["name"]
        assert not _schema_keys(schema) & _STRICT_UNSUPPORTED, tool["name"]
    explore = next(t for t in TOOLS if t["name"] == "explore_entity")["input_schema"]
    assert "any" in explore["properties"]["entity_type"]["enum"]


# ----------------------------------------------------------------------------- ask loop
async def test_ask_streams_steps_citations_follow_ups_and_persists():
    model = ScriptedModel(
        [
            turn(
                tool_use(
                    "t1", "search_knowledge", query="gold layer engine", top_k=4, use_graph=False
                )
            ),
            turn(
                text("Checking the graph."),
                tool_use(
                    "t2",
                    "query_graph",
                    cypher="MATCH (e:Technology)<-[:MENTIONS]-() RETURN e.name AS name, count(*) AS mentions ORDER BY mentions DESC",
                    purpose="Most mentioned technologies",
                ),
            ),
            turn(
                text(
                    "The gold layer is built with DuckDB [S1]; it is also the most-mentioned technology in the graph[S9].\n\n"
                    'FOLLOW_UPS: ["Which gold tables exist?", "Who maintains the DuckDB code?"]'
                ),
                stop="end_turn",
            ),
        ]
    )
    service, repo, engine, graph_db = make_service(model)
    events = [
        e
        async for e in service.ask(
            SPACE_ID, GenieAskRequest(question="What engine does the gold layer use?")
        )
    ]
    kinds = [kind for kind, _ in events]

    assert kinds[0] == "conversation" and kinds[-1] == "message"
    assert (
        kinds.count("step") == 2
        and kinds.count("step_done") == 2
        and kinds.count("turn_reset") == 1
    )
    assert "delta" in kinds
    conversation = events[0][1]["conversation"]
    assert conversation["title"] == "What engine does the gold layer use?"
    assert events[0][1]["user_message"]["role"] == "user"

    message = events[-1][1]
    assert message["status"] == "complete" and message["role"] == "assistant"
    assert message["content"] == (
        "The gold layer is built with DuckDB [S1]; it is also the most-mentioned technology in the graph."
    ), "unknown markers are removed, known ones kept"
    assert message["follow_ups"] == ["Which gold tables exist?", "Who maintains the DuckDB code?"]
    assert [c["marker"] for c in message["citations"]] == ["S1"]
    assert (
        message["citations"][0]["path"] == "README.md" and message["citations"][0]["score"] == 0.9
    )
    assert message["usage"] == {
        "input_tokens": 300,
        "output_tokens": 150,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
    }
    assert message["model"] == "scripted-model" and message["latency_ms"] is not None

    trace = message["trace"]
    assert [s["tool"] for s in trace] == ["search_knowledge", "query_graph"]
    assert (
        trace[0]["ok"]
        and trace[0]["rows"] == 2
        and trace[0]["summary"].startswith('Searched "gold layer engine"')
    )
    assert trace[1]["detail"].endswith("LIMIT 50") and trace[1]["rows"] == 2
    assert (
        trace[1]["narration"] == "Checking the graph."
        and trace[1]["summary"] == "Most mentioned technologies"
    )
    assert engine.requests[0].top_k == 4 and graph_db.queries[0] == trace[1]["detail"]

    # the tool result carried the [S#] labels the model cites
    system, sent = model.requests[2]
    tool_results = sent[2]["content"] if isinstance(sent[2]["content"], list) else []
    assert any(
        "[S1] omniclaim-lakehouse-pipelines/README.md" in r.get("content", "") for r in tool_results
    )
    assert "Space: Everything in the hub" in system

    stored = await repo.list_messages(UUID(conversation["id"]))
    assert [m["role"] for m in stored] == ["user", "assistant"]

    # a follow-up question in the same conversation sees the earlier turns and keeps the markers
    follow_up = ScriptedModel(
        [turn(text('Yes - DuckDB [S1].\nFOLLOW_UPS: ["Anything else?"]'), stop="end_turn")]
    )
    service2, *_ = make_service(follow_up, repo=repo)
    events2 = [
        e
        async for e in service2.ask(
            SPACE_ID,
            GenieAskRequest(question="Are you sure?", conversation_id=UUID(conversation["id"])),
        )
    ]
    _, history = follow_up.requests[0]
    assert [m["role"] for m in history] == ["user", "assistant", "user"]
    assert "DuckDB [S1]" in history[1]["content"] and history[2]["content"] == "Are you sure?"
    final = events2[-1][1]
    assert final["content"] == "Yes - DuckDB [S1]." and [
        c["marker"] for c in final["citations"]
    ] == ["S1"]
    assert final["follow_ups"] == ["Anything else?"]
    assert len(await repo.list_messages(UUID(conversation["id"]))) == 4


async def test_ask_refuses_before_streaming_without_model_or_space():
    service, *_ = make_service(None)
    assert service.status().configured is False and "no model" in service.status().reason
    with pytest.raises(DependencyUnavailableError):
        await anext(service.ask(SPACE_ID, GenieAskRequest(question="hi")))
    service, *_ = make_service(ScriptedModel([]))
    with pytest.raises(NotFoundError):
        await anext(service.ask(uuid4(), GenieAskRequest(question="hi")))


async def test_model_failure_is_persisted_as_an_error_message():
    service, repo, *_ = make_service(FailingModel())
    events = [e async for e in service.ask(SPACE_ID, GenieAskRequest(question="Will this fail?"))]
    assert [k for k, _ in events] == ["conversation", "error"]
    payload = events[-1][1]
    assert "gateway down" in payload["error"]
    assert payload["message"]["status"] == "error" and payload["message"]["role"] == "assistant"
    conversation_id = UUID(events[0][1]["conversation"]["id"])
    assert [m["status"] for m in await repo.list_messages(conversation_id)] == ["complete", "error"]


def test_follow_up_parsing_and_history_alternation():
    assert _split_follow_ups('Answer.\n\nFOLLOW_UPS: ["A?", "B?"]') == (["A?", "B?"], "Answer.")
    assert _split_follow_ups('Answer.\n\n**FOLLOW_UPS**: ["A?"]') == (["A?"], "Answer.")
    assert _split_follow_ups("Answer.\n\nFollow-up questions:\n- A?\n- B?\n") == (
        ["A?", "B?"],
        "Answer.",
    )
    assert _split_follow_ups("Plain answer.") == ([], "Plain answer.")

    rows = [
        {"role": "assistant", "content": "orphan", "status": "complete"},
        {"role": "user", "content": "q1", "status": "complete"},
        {"role": "user", "content": "q1 again", "status": "complete"},
        {"role": "assistant", "content": "", "status": "error"},
        {"role": "user", "content": "q2", "status": "complete"},
        {"role": "assistant", "content": "a2", "status": "complete"},
        {"role": "user", "content": "dangling", "status": "complete"},
    ]
    history = _history(rows, limit=20)
    assert [m["role"] for m in history] == ["user", "assistant", "user", "assistant"]
    assert (
        history[0]["content"] == "q1\n\nq1 again"
        and history[1]["content"] == "(no answer was produced)"
    )
    assert _history(rows, limit=0) == []


# ----------------------------------------------------------------------------- API
def _client(service) -> TestClient:
    @asynccontextmanager
    async def lifespan(app):
        app.state.container = SimpleNamespace(genie=service)
        yield

    app = create_app(
        settings=Settings(_env_file=None, service_name="test-query"),
        title="t",
        description="d",
        version="0",
        lifespan=lifespan,
        routers=[api_router],
        latency_recorder=LatencyRecorder(100),
    )
    return TestClient(app)


def _parse_sse(body: str) -> list[tuple[str, dict[str, Any]]]:
    frames = []
    for raw in body.split("\n\n"):
        lines = [line for line in raw.splitlines() if line and not line.startswith(":")]
        if not lines:
            continue
        event = next(line[len("event: ") :] for line in lines if line.startswith("event: "))
        data = next(line[len("data: ") :] for line in lines if line.startswith("data: "))
        frames.append((event, json.loads(data)))
    return frames


def test_genie_api_streams_sse_and_reports_status():
    model = ScriptedModel([turn(text('Hello from Genie.\nFOLLOW_UPS: ["More?"]'), stop="end_turn")])
    service, repo, *_ = make_service(model)
    with _client(service) as client:
        status = client.get("/api/v1/genie/status").json()
        assert status["configured"] is True and status["model"] == "scripted-model"

        spaces = client.get("/api/v1/genie/spaces").json()
        assert spaces[0]["id"] == str(SPACE_ID) and spaces[0]["is_default"] is True

        with client.stream(
            "POST", f"/api/v1/genie/spaces/{SPACE_ID}/ask", json={"question": "Hi"}
        ) as response:
            assert response.status_code == 200
            assert response.headers["content-type"].startswith("text/event-stream")
            body = "".join(response.iter_text())
        frames = _parse_sse(body)
        assert frames[0][0] == "conversation" and frames[-1][0] == "message"
        assert frames[-1][1]["content"] == "Hello from Genie." and frames[-1][1]["follow_ups"] == [
            "More?"
        ]
        assert (
            "".join(d["text"] for k, d in frames if k == "delta")
            == 'Hello from Genie.\nFOLLOW_UPS: ["More?"]'
        )

        conversation_id = frames[0][1]["conversation"]["id"]
        detail = client.get(f"/api/v1/genie/conversations/{conversation_id}").json()
        assert [m["role"] for m in detail["messages"]] == ["user", "assistant"]
        message_id = detail["messages"][1]["id"]
        assert (
            client.post(f"/api/v1/genie/messages/{message_id}/feedback", json={"value": 1}).json()[
                "feedback"
            ]
            == 1
        )

        missing = client.post(f"/api/v1/genie/spaces/{uuid4()}/ask", json={"question": "Hi"})
        assert missing.status_code == 404 and missing.json()["error"]["code"]

        created = client.post(
            "/api/v1/genie/spaces",
            json={
                "name": "omniclaim",
                "filters": {"attributes": {"repo": "acme/omniclaim"}},
                "sample_questions": ["Which gold tables exist?"],
            },
        )
        assert created.status_code == 201 and created.json()["filters"]["attributes"] == {
            "repo": "acme/omniclaim"
        }
        assert client.delete(f"/api/v1/genie/spaces/{created.json()['id']}").status_code == 204
        assert client.delete(f"/api/v1/genie/spaces/{SPACE_ID}").status_code == 409
