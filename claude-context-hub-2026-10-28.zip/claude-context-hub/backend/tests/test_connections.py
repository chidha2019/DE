"""Connections edited and tested from the Connectors page: encrypted credentials, drafts and live swaps."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

import pytest
from pydantic import SecretStr

from ech_core.config import Settings
from ech_core.connections import SavedConnections, SecretBox
from ech_core.exceptions import InvalidRequestError, NotFoundError
from ech_core.schemas.connectors import ConnectionDraft
from ingestion_service.connectors import connections
from ingestion_service.connectors.base import ConnectorHealth
from ingestion_service.connectors.catalog import describe_catalog
from ingestion_service.connectors.connections import CONNECTION_FIELDS, ConnectionService, coerce
from ingestion_service.connectors.registry import ConnectorRegistry

TOKEN = "not-a-real-token"


class FakeRepo:
    def __init__(self) -> None:
        self.rows: dict[str, dict[str, Any]] = {}

    async def all(self) -> list[dict[str, Any]]:
        return list(self.rows.values())

    async def get(self, connector: str) -> dict[str, Any] | None:
        return self.rows.get(connector)

    async def upsert(self, connector: str, settings: dict[str, Any], secrets: bytes | None, updated_by: str | None) -> None:
        self.rows[connector] = {"connector": connector, "settings": settings, "secrets": secrets, "updated_by": updated_by, "updated_at": None}

    async def delete(self, connector: str) -> None:
        self.rows.pop(connector, None)


class FakeConnector:
    display_name = "Snowflake"

    def __init__(self, settings: Settings, name: str = "snowflake") -> None:
        self.name = name
        self.settings = settings
        self.closed = False

    async def health_check(self) -> ConnectorHealth:
        if self.settings.snowflake_warehouse == "BROKEN":
            return ConnectorHealth(healthy=False, details={"error": "warehouse BROKEN does not exist"})
        return ConnectorHealth(healthy=True, details={"warehouse": self.settings.snowflake_warehouse, "databases": self.settings.snowflake_database_list})

    async def aclose(self) -> None:
        self.closed = True


@pytest.fixture
def built(monkeypatch: pytest.MonkeyPatch) -> list[FakeConnector]:
    made: list[FakeConnector] = []

    def fake_build(adapter: str, settings: Settings) -> FakeConnector:
        connector = FakeConnector(settings, adapter)
        made.append(connector)
        return connector

    monkeypatch.setattr(connections, "build_connector", fake_build)
    return made


def _base(tmp_path: Path, **overrides: Any) -> Settings:
    values: dict[str, Any] = {
        "snowflake_account": "acme-test",
        "snowflake_token": SecretStr(TOKEN),
        "snowflake_databases": "SALES",
        "snowflake_warehouse": "COMPUTE_WH",
        "state_dir": tmp_path,
    }
    values.update(overrides)
    return Settings(_env_file=None, **values)


def _service(settings: Settings, repo: FakeRepo | None = None, registry: ConnectorRegistry | None = None) -> ConnectionService:
    return ConnectionService(settings=settings, repo=repo if repo is not None else FakeRepo(), registry=registry if registry is not None else ConnectorRegistry(), box=SecretBox(settings))  # type: ignore[arg-type]


def test_secret_box_generates_one_key_and_round_trips(tmp_path: Path) -> None:
    settings = Settings(_env_file=None, state_dir=tmp_path / "state")
    box = SecretBox(settings)
    assert box.available and (tmp_path / "state" / "secrets.key").is_file()
    blob = box.seal({"snowflake_token": TOKEN})
    assert blob is not None and TOKEN.encode() not in blob
    assert SecretBox(settings).open(blob) == {"snowflake_token": TOKEN}  # the generated key is reused
    assert SecretBox(Settings(_env_file=None, state_dir=tmp_path / "other")).open(blob) == {}  # another key cannot read it
    assert box.seal({}) is None


def test_form_values_are_coerced_to_settings_types() -> None:
    snowflake = {s.name: s for s in CONNECTION_FIELDS["snowflake"]}
    assert coerce(snowflake["snowflake_databases"], ["SALES ", "", "FINANCE"]) == "SALES, FINANCE"
    assert coerce(snowflake["snowflake_databases"], "A,\nB") == "A, B"
    assert coerce(snowflake["snowflake_max_tables"], "500") == 500
    assert coerce(snowflake["snowflake_include_tags"], "false") is False
    assert coerce(snowflake["snowflake_warehouse"], "  ") is None
    with pytest.raises(InvalidRequestError):
        coerce(snowflake["snowflake_max_tables"], "0")
    with pytest.raises(InvalidRequestError):
        coerce(snowflake["snowflake_auth_scheme"], "PASSWORD")
    databricks = {s.name: s for s in CONNECTION_FIELDS["databricks"]}
    with pytest.raises(InvalidRequestError):
        coerce(databricks["databricks_host"], "adb-1.azuredatabricks.net")


def test_describe_never_returns_credentials(tmp_path: Path) -> None:
    service = _service(_base(tmp_path))
    out = service.describe("snowflake")
    token = next(f for f in out.fields if f.name == "snowflake_token")
    assert token.value is None and token.secret_set and token.source == "env"
    assert next(f for f in out.fields if f.name == "snowflake_databases").value == "SALES"
    assert TOKEN not in out.model_dump_json()
    with pytest.raises(NotFoundError):
        service.describe("oracle")


def test_a_draft_is_tested_without_being_saved(tmp_path: Path, built: list[FakeConnector]) -> None:
    repo = FakeRepo()
    service = _service(_base(tmp_path), repo)
    result = asyncio.run(service.test("snowflake", ConnectionDraft(values={"snowflake_warehouse": "ANALYTICS_WH"})))
    assert result.ok and result.draft and result.details["warehouse"] == "ANALYTICS_WH"
    assert repo.rows == {} and built[-1].closed  # nothing stored; the throwaway connector is closed
    bad = asyncio.run(service.test("snowflake", ConnectionDraft(values={"snowflake_warehouse": "BROKEN"})))
    assert not bad.ok and bad.error == "warehouse BROKEN does not exist"
    missing = asyncio.run(service.test("snowflake", ConnectionDraft(values={"snowflake_databases": ""})))
    assert not missing.ok and missing.error == "Missing Databases"
    assert asyncio.run(service.test("snowflake")).draft is False


def test_saving_encrypts_credentials_and_swaps_the_live_connector(tmp_path: Path, built: list[FakeConnector]) -> None:
    repo = FakeRepo()
    registry = ConnectorRegistry()
    service = _service(_base(tmp_path), repo, registry)
    draft = ConnectionDraft(
        values={"snowflake_warehouse": "ANALYTICS_WH", "snowflake_databases": "SALES"},
        secrets={"snowflake_token": "rotated-not-real"},
        updated_by="tester",
    )
    out = asyncio.run(service.save("snowflake", draft))
    row = repo.rows["snowflake"]
    assert row["settings"] == {"snowflake_warehouse": "ANALYTICS_WH"}  # SALES equals the environment, so it is not stored
    assert row["secrets"] and b"rotated-not-real" not in row["secrets"]
    live = registry.get("snowflake")
    assert live is built[-1] and live.settings.snowflake_token.get_secret_value() == "rotated-not-real"  # type: ignore[attr-defined]
    fields = {f.name: f for f in out.fields}
    assert fields["snowflake_warehouse"].source == "hub" and fields["snowflake_token"].source == "hub"
    assert fields["snowflake_token"].value is None and "rotated-not-real" not in out.model_dump_json()

    # A restart applies what was saved.
    after_restart = ConnectorRegistry()
    asyncio.run(_service(_base(tmp_path), repo, after_restart).load())
    assert after_restart.get("snowflake").settings.snowflake_warehouse == "ANALYTICS_WH"  # type: ignore[attr-defined]

    # A credential set to null goes back to the environment's.
    asyncio.run(service.save("snowflake", ConnectionDraft(secrets={"snowflake_token": None})))
    assert registry.get("snowflake").settings.snowflake_token.get_secret_value() == TOKEN  # type: ignore[attr-defined]
    with pytest.raises(InvalidRequestError):
        asyncio.run(service.save("snowflake", ConnectionDraft(values={"snowflake_password": "x"})))


def test_reset_returns_to_the_environment(tmp_path: Path, built: list[FakeConnector]) -> None:
    repo = FakeRepo()
    registry = ConnectorRegistry()
    service = _service(_base(tmp_path), repo, registry)
    asyncio.run(service.save("snowflake", ConnectionDraft(values={"snowflake_warehouse": "ANALYTICS_WH"})))
    out = asyncio.run(service.reset("snowflake"))
    assert repo.rows == {} and service.source("snowflake") == "env"
    assert registry.get("snowflake").settings.snowflake_warehouse == "COMPUTE_WH"  # type: ignore[attr-defined]
    assert next(f for f in out.fields if f.name == "snowflake_warehouse").source == "env"

    # Configured only from the hub: a reset takes the connector away again.
    hub_only = ConnectorRegistry()
    other = _service(_base(tmp_path, snowflake_databases=""), FakeRepo(), hub_only)
    asyncio.run(other.save("snowflake", ConnectionDraft(values={"snowflake_databases": "FINANCE"})))
    assert hub_only.names() == ["snowflake"]
    asyncio.run(other.reset("snowflake"))
    assert hub_only.names() == []


def test_catalog_marks_editable_connections_and_where_their_settings_live() -> None:
    catalog = describe_catalog({"snowflake"}, editable={"snowflake", "databricks"}, sources={"snowflake": "hub"})
    entries = {e.key: e for e in catalog.entries}
    assert entries["snowflake"].editable and entries["snowflake"].settings_source == "hub"
    assert entries["databricks"].editable and entries["databricks"].settings_source is None
    assert not entries["oracle"].editable


def test_what_one_service_saves_another_reads(tmp_path: Path, built: list[FakeConnector]) -> None:
    repo = FakeRepo()
    writer = _service(_base(tmp_path), repo)
    asyncio.run(writer.save("snowflake", ConnectionDraft(values={"snowflake_warehouse": "ANALYTICS_WH"})))
    draft = ConnectionDraft(values={"grafana_url": "https://grafana.example.test"}, secrets={"grafana_token": "glsa-not-a-real-token"})
    asyncio.run(writer.save("grafana", draft))

    # The query service: the same key (shared state directory), only reading.
    reader = SavedConnections(_base(tmp_path), repo, SecretBox(_base(tmp_path)), ttl_seconds=60)  # type: ignore[arg-type]
    settings = asyncio.run(reader.settings())
    assert settings.snowflake_warehouse == "ANALYTICS_WH" and settings.snowflake_databases == "SALES"
    assert settings.grafana_url == "https://grafana.example.test"
    assert settings.grafana_token is not None and settings.grafana_token.get_secret_value() == "glsa-not-a-real-token"

    # Cached for the TTL, then read again.
    asyncio.run(writer.reset("grafana"))
    assert asyncio.run(reader.settings()).grafana_url == "https://grafana.example.test"
    fresh = SavedConnections(_base(tmp_path), repo, SecretBox(_base(tmp_path)), ttl_seconds=0)  # type: ignore[arg-type]
    assert asyncio.run(fresh.settings()).grafana_url is None


def test_a_reader_falls_back_when_the_database_cannot_answer(tmp_path: Path) -> None:
    class BrokenRepo(FakeRepo):
        async def all(self) -> list[dict[str, Any]]:
            raise ConnectionError("database down")

    base = _base(tmp_path)
    reader = SavedConnections(base, BrokenRepo(), SecretBox(base))  # type: ignore[arg-type]
    assert asyncio.run(reader.settings()) is base and reader.current() is base


def test_an_empty_secrets_key_counts_as_unset(tmp_path: Path) -> None:
    box = SecretBox(Settings(_env_file=None, secrets_key=SecretStr(""), state_dir=tmp_path))
    assert box.available and (tmp_path / "secrets.key").is_file()
