"""Saved pipelines: create, change, run, schedule and the HTTP surface (repository faked)."""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from datetime import UTC, datetime, timedelta
from types import SimpleNamespace
from typing import Any
from uuid import UUID, uuid4

import pytest
from fastapi.testclient import TestClient

from ech_core.app_factory import create_app
from ech_core.config import Settings
from ech_core.domain.enums import RunStatus, SourceSystem
from ech_core.domain.models import IngestionRunRecord
from ech_core.exceptions import ConflictError, ConnectorError, InvalidRequestError, NotFoundError
from ech_core.observability import LatencyRecorder
from ech_core.schemas.ingestion import RunOptions, ScopeItem, SourceOptions
from ech_core.schemas.pipelines import (
    DiscoveryNode,
    DiscoveryResult,
    PipelineIn,
    PipelineUpdate,
    PreviewRequest,
    Schedule,
)
from ingestion_service.api import api_router
from ingestion_service.connectors.base import BaseConnector, ConnectorOptions, SourceDocument
from ingestion_service.connectors.registry import ConnectorRegistry
from ingestion_service.services.pipeline_definitions import BUSY_RETRY, PipelineDefinitionService

NOW = datetime(2026, 10, 26, 7, 0, tzinfo=UTC)


class WarehouseConnector(BaseConnector):
    name = "snowflake"
    source_system = SourceSystem.SNOWFLAKE
    display_name = "Snowflake"
    discoverable = True
    scope_levels = ("Database", "Schema", "Table")

    def __init__(self) -> None:
        self.estimate: int | None = 12
        self.fail = False
        self.seen: list[ConnectorOptions] = []

    async def estimate_count(self, options: ConnectorOptions) -> int | None:
        self.seen.append(options)
        if self.fail:
            raise ConnectorError("warehouse unreachable")
        return self.estimate

    async def discover(self, path: list[str]) -> DiscoveryResult:
        node = DiscoveryNode(name="INSURANCE", path=["INSURANCE"], kind="database", expandable=True)
        return DiscoveryResult(connector=self.name, path=path, nodes=[node] if not path else [])

    async def iter_documents(self, options: ConnectorOptions) -> AsyncIterator[SourceDocument]:
        return
        yield  # pragma: no cover


class FlatConnector(WarehouseConnector):
    name = "manual-files"
    source_system = SourceSystem.MANUAL
    display_name = "Files"
    discoverable = False


class FakeRepo:
    def __init__(self) -> None:
        self.rows: dict[UUID, dict[str, Any]] = {}

    async def create(self, **kw: Any) -> UUID:
        pid = uuid4()
        connector = kw.pop("connector_name")
        self.rows[pid] = {
            **kw, "id": pid, "connector_name": connector, "source_system": kw["source_system"].value,
            "created_at": NOW, "updated_at": NOW, "runs_total": 0, "runs_failed": 0,
            "lr_id": None, "lr_status": None, "lr_triggered_by": None, "lr_started_at": None,
            "lr_finished_at": None, "lr_created_at": None, "lr_stats": None, "lr_error": None,
        }
        return pid

    async def get(self, pid: UUID) -> dict[str, Any] | None:
        return self.rows.get(pid)

    async def list(self, *, connector_name: str | None = None, search: str | None = None) -> list[dict[str, Any]]:
        rows = [r for r in self.rows.values() if not connector_name or r["connector_name"] == connector_name]
        return [r for r in rows if not search or search.lower() in r["name"].lower()]

    async def name_taken(self, name: str, *, except_id: UUID | None = None) -> bool:
        return any(r["name"].lower() == name.lower() and r["id"] != except_id for r in self.rows.values())

    async def update(self, pid: UUID, **fields: Any) -> bool:
        self.rows[pid].update(fields)
        return True

    async def delete(self, pid: UUID) -> bool:
        return self.rows.pop(pid, None) is not None

    async def due(self, now: datetime, *, limit: int = 50) -> list[dict[str, Any]]:
        return [r for r in self.rows.values() if r["enabled"] and r["next_run_at"] and r["next_run_at"] <= now]

    async def set_next_run(self, pid: UUID, when: datetime | None) -> None:
        self.rows[pid]["next_run_at"] = when


class FakePipeline:
    def __init__(self) -> None:
        self.requests: list[Any] = []
        self.busy = False
        self.broken: set[str] = set()

    async def trigger(self, request: Any) -> IngestionRunRecord:
        if self.busy:
            raise ConflictError("Connector already has an active run")
        if request.connector in self.broken:
            raise RuntimeError("boom")
        self.requests.append(request)
        return IngestionRunRecord(
            id=uuid4(), connector_name=request.connector, source_system=SourceSystem.SNOWFLAKE,
            status=RunStatus.QUEUED, pipeline_id=request.pipeline_id, triggered_by=request.triggered_by,
            created_at=NOW, updated_at=NOW,
        )


class FakeAudit:
    async def record(self, **kw: Any) -> None:
        return None


def build() -> tuple[PipelineDefinitionService, FakeRepo, FakePipeline, WarehouseConnector]:
    registry, warehouse = ConnectorRegistry(), WarehouseConnector()
    registry.register(warehouse)
    registry.register(FlatConnector())
    repo, pipeline = FakeRepo(), FakePipeline()
    return PipelineDefinitionService(repo=repo, registry=registry, pipeline=pipeline, audit=FakeAudit()), repo, pipeline, warehouse  # type: ignore[arg-type]


def body(**kw: Any) -> PipelineIn:
    base: dict[str, Any] = {
        "name": "Policy metadata", "connector": "snowflake",
        "scope": [ScopeItem(path=["INSURANCE", "BRONZE"], kind="schema")],
        "schedule": Schedule(type="daily", time="02:00"),
        "options": RunOptions(limit=500), "source_options": SourceOptions(include_lineage=False),
        "owner": "data-eng", "tags": ["core"],
    }
    return PipelineIn(**{**base, **kw})


# ----------------------------------------------------------------------------- create and read
@pytest.mark.asyncio
async def test_create_stores_the_scope_schedule_and_first_run():
    service, repo, _, _ = build()
    out = await service.create(body())
    assert (out.name, out.connector, out.connector_label, out.connection_available) == ("Policy metadata", "snowflake", "Snowflake", True)
    assert out.scope == [ScopeItem(path=["INSURANCE", "BRONZE"], kind="schema")]
    assert out.schedule_label == "Daily at 02:00 UTC" and out.next_run_at is not None and out.next_run_at > datetime.now(tz=UTC)
    assert out.options.limit == 500 and out.source_options.include_lineage is False
    assert out.tags == ["core"] and out.created_by == "data-eng" and out.last_run is None
    stored = repo.rows[out.id]
    assert stored["scope"] == [{"path": ["INSURANCE", "BRONZE"], "kind": "schema"}]
    assert stored["source_options"] == {"include_lineage": False}, "unset switches are not stored"
    assert [p.id for p in await service.list(search="policy")] == [out.id]
    assert await service.list(connector="manual-files") == []


@pytest.mark.asyncio
async def test_create_refuses_bad_names_connectors_and_scopes():
    service, _, _, _ = build()
    await service.create(body())
    with pytest.raises(ConflictError):
        await service.create(body(name="POLICY METADATA"))
    with pytest.raises(NotFoundError):
        await service.create(body(name="Other", connector="nowhere"))
    with pytest.raises(InvalidRequestError):
        await service.create(body(name="Files", connector="manual-files"))
    flat = await service.create(body(name="Files", connector="manual-files", scope=[]))
    assert flat.scope == [] and flat.connector_label == "Files"
    with pytest.raises(NotFoundError):
        await service.get(uuid4())


@pytest.mark.asyncio
async def test_a_manual_or_disabled_pipeline_has_no_next_run():
    service, _, _, _ = build()
    manual = await service.create(body(name="Manual", schedule=Schedule()))
    paused = await service.create(body(name="Paused", enabled=False))
    assert manual.next_run_at is None and manual.schedule_label == "Manual"
    assert paused.next_run_at is None and paused.enabled is False


# ----------------------------------------------------------------------------- running
@pytest.mark.asyncio
async def test_running_builds_an_ordinary_run_that_remembers_its_pipeline():
    service, _, pipeline, _ = build()
    out = await service.create(body())
    run = await service.run(out.id, actor="admin-ui")
    request = pipeline.requests[-1]
    assert (request.connector, request.triggered_by, request.pipeline_id) == ("snowflake", "admin-ui", out.id)
    assert request.scope == [ScopeItem(path=["INSURANCE", "BRONZE"], kind="schema")]
    assert request.options.limit == 500 and request.source_options.include_lineage is False
    assert run.pipeline_id == out.id and run.status is RunStatus.QUEUED


@pytest.mark.asyncio
async def test_run_now_at_creation_starts_a_run_and_a_busy_connection_does_not_fail_the_create():
    service, _, pipeline, _ = build()
    await service.create(body(run_now=True), actor="admin-ui")
    assert len(pipeline.requests) == 1
    pipeline.busy = True
    created = await service.create(body(name="Second", run_now=True))
    assert created.name == "Second" and len(pipeline.requests) == 1


# ----------------------------------------------------------------------------- change
@pytest.mark.asyncio
async def test_changing_the_schedule_recomputes_the_next_run_and_disabling_clears_it():
    service, _, _, _ = build()
    out = await service.create(body(schedule=Schedule()))
    assert out.next_run_at is None
    hourly = await service.update(out.id, PipelineUpdate(schedule=Schedule(type="interval", every_minutes=60)))
    assert hourly.next_run_at is not None and hourly.schedule_label == "Every hour"
    off = await service.set_enabled(out.id, False)
    assert off.enabled is False and off.next_run_at is None
    on = await service.set_enabled(out.id, True)
    assert on.next_run_at is not None
    renamed = await service.update(out.id, PipelineUpdate(name="Renamed", scope=[ScopeItem(path=["INSURANCE"], kind="database")], tags=["Core ", "x"]))
    assert renamed.name == "Renamed" and renamed.scope[0].path == ["INSURANCE"] and renamed.tags == ["core", "x"]
    assert renamed.schedule_label == "Every hour", "fields that were not sent stay"
    other = await service.create(body(name="Other"))
    with pytest.raises(ConflictError):
        await service.update(other.id, PipelineUpdate(name="renamed"))
    await service.delete(out.id)
    assert [p.name for p in await service.list()] == ["Other"]


# ----------------------------------------------------------------------------- scheduler
@pytest.mark.asyncio
async def test_the_scheduler_starts_due_pipelines_and_books_the_next_run():
    service, repo, pipeline, _ = build()
    due = await service.create(body(name="Due", schedule=Schedule(type="interval", every_minutes=60)))
    later = await service.create(body(name="Later", schedule=Schedule(type="interval", every_minutes=60)))
    repo.rows[due.id]["next_run_at"] = NOW - timedelta(minutes=1)
    repo.rows[later.id]["next_run_at"] = NOW + timedelta(hours=1)
    assert await service.tick(NOW) == 1
    assert [r.pipeline_id for r in pipeline.requests] == [due.id] and pipeline.requests[0].triggered_by == "scheduler"
    assert repo.rows[due.id]["next_run_at"] == NOW + timedelta(hours=1)
    assert repo.rows[later.id]["next_run_at"] == NOW + timedelta(hours=1)
    assert await service.tick(NOW) == 0


@pytest.mark.asyncio
async def test_a_busy_connection_is_retried_shortly_and_a_broken_pipeline_does_not_stop_the_rest():
    service, repo, pipeline, _ = build()
    first = await service.create(body(name="First", schedule=Schedule(type="interval", every_minutes=360)))
    second = await service.create(body(name="Second", connector="manual-files", scope=[], schedule=Schedule(type="interval", every_minutes=360)))
    for pid in (first.id, second.id):
        repo.rows[pid]["next_run_at"] = NOW - timedelta(minutes=5)
    pipeline.busy = True
    assert await service.tick(NOW) == 0
    assert repo.rows[first.id]["next_run_at"] == NOW + BUSY_RETRY
    pipeline.busy = False
    pipeline.broken = {"snowflake"}
    for pid in (first.id, second.id):
        repo.rows[pid]["next_run_at"] = NOW - timedelta(minutes=5)
    assert await service.tick(NOW) == 1, "the healthy pipeline still ran"
    assert repo.rows[first.id]["next_run_at"] == NOW + timedelta(hours=6), "a failed start waits for the next slot"


# ----------------------------------------------------------------------------- preview
@pytest.mark.asyncio
async def test_preview_estimates_the_scope_and_survives_a_failing_source():
    service, _, _, warehouse = build()
    request = PreviewRequest(connector="snowflake", scope=[ScopeItem(path=["INSURANCE"], kind="database")], options=RunOptions(limit=5), source_options=SourceOptions(include_tags=False))
    result = await service.preview(request)
    assert (result.estimated_documents, result.scope_items, result.whole_connection, result.note) == (12, 1, False, None)
    assert warehouse.seen[-1].scope[0].path == ["INSURANCE"] and warehouse.seen[-1].limit == 5
    assert (await service.preview(PreviewRequest(connector="snowflake"))).whole_connection is True
    warehouse.fail = True
    broken = await service.preview(request)
    assert broken.estimated_documents is None and "unreachable" in (broken.note or "")
    with pytest.raises(InvalidRequestError):
        await service.preview(PreviewRequest(connector="manual-files", scope=request.scope))


# ----------------------------------------------------------------------------- HTTP
class FakeRuns:
    def __init__(self) -> None:
        self.calls: list[dict[str, Any]] = []

    async def list(self, **kw: Any) -> tuple[list[Any], int]:
        self.calls.append(kw)
        return [], 0


def client_for(service: PipelineDefinitionService, runs: FakeRuns):
    registry = ConnectorRegistry()
    registry.register(WarehouseConnector())
    registry.register(FlatConnector())

    @asynccontextmanager
    async def lifespan(app):
        app.state.container = SimpleNamespace(pipeline_defs=service, runs=runs, registry=registry)
        yield

    app = create_app(
        settings=Settings(_env_file=None, service_name="test-ingestion"),
        title="t", description="d", version="0", lifespan=lifespan, routers=[api_router],
        latency_recorder=LatencyRecorder(100),
    )
    return TestClient(app)


def test_pipeline_routes_do_not_shadow_the_run_routes():
    service, _, _, _ = build()
    runs = FakeRuns()
    with client_for(service, runs) as client:
        pid = uuid4()
        listed = client.get("/api/v1/pipelines/runs", params={"pipeline_id": str(pid), "limit": 5})
        assert listed.status_code == 200 and listed.json()["total"] == 0
        assert runs.calls[-1]["pipeline_id"] == pid and runs.calls[-1]["limit"] == 5

        created = client.post("/api/v1/pipelines", json={"name": "Policy metadata", "connector": "snowflake", "scope": [{"path": ["INSURANCE", "BRONZE"], "kind": "schema"}], "schedule": {"type": "daily", "time": "02:00"}})
        assert created.status_code == 201, created.text
        made = created.json()
        assert made["schedule_label"] == "Daily at 02:00 UTC" and made["scope"][0]["path"] == ["INSURANCE", "BRONZE"]
        assert client.get(f"/api/v1/pipelines/{made['id']}").json()["name"] == "Policy metadata"
        assert [p["id"] for p in client.get("/api/v1/pipelines").json()] == [made["id"]]

        run = client.post(f"/api/v1/pipelines/{made['id']}/run")
        assert run.status_code == 202 and run.json()["pipeline_id"] == made["id"]
        paused = client.post(f"/api/v1/pipelines/{made['id']}/schedule", json={"enabled": False})
        assert paused.json()["enabled"] is False and paused.json()["next_run_at"] is None
        changed = client.put(f"/api/v1/pipelines/{made['id']}", json={"description": "Raw policy tables"})
        assert changed.json()["description"] == "Raw policy tables"
        assert client.delete(f"/api/v1/pipelines/{made['id']}").status_code == 204
        assert client.get(f"/api/v1/pipelines/{made['id']}").status_code == 404


def test_pipeline_validation_errors_use_the_error_envelope():
    service, _, _, _ = build()
    with client_for(service, FakeRuns()) as client:
        bad = client.post("/api/v1/pipelines", json={"name": "Weekly", "connector": "snowflake", "schedule": {"type": "weekly", "time": "06:30"}})
        assert bad.status_code == 422 and bad.json()["error"]["code"] == "validation_error"
        duplicate = [client.post("/api/v1/pipelines", json={"name": "Same", "connector": "snowflake"}).status_code for _ in range(2)]
        assert duplicate == [201, 409]
        unknown = client.post("/api/v1/pipelines", json={"name": "Nowhere", "connector": "nowhere"})
        assert unknown.status_code == 404


def test_schema_browsing_route_passes_the_path_and_refuses_flat_connections():
    service, _, _, _ = build()
    with client_for(service, FakeRuns()) as client:
        top = client.get("/api/v1/connectors/snowflake/discover")
        assert top.status_code == 200 and [n["name"] for n in top.json()["nodes"]] == ["INSURANCE"]
        deeper = client.get("/api/v1/connectors/snowflake/discover", params=[("path", "INSURANCE"), ("path", "BRONZE")])
        assert deeper.json()["path"] == ["INSURANCE", "BRONZE"]
        flat = client.get("/api/v1/connectors/manual-files/discover")
        assert flat.status_code == 502 and flat.json()["error"]["code"] == "connector_error"
        assert client.get("/api/v1/connectors/nowhere/discover").status_code == 404
