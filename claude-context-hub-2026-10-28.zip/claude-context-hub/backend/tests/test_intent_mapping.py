"""A modelled layer compiled from design files (mapping, data model, DDL): binding, SQL, dry run, generated pipeline, run."""

from __future__ import annotations

import asyncio
import contextlib
import importlib.util
import io
import subprocess
import sys
from collections.abc import AsyncIterator
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import sqlglot

from ech_core.schemas.intents import (
    IntentSource,
    IntentTarget,
    IntentValidation,
    PipelineRun,
    StructuredIntent,
    ValidatedObject,
)
from query_service.intents import generator, mapping
from query_service.intents.mapping_modeler import MappingModeler
from query_service.intents.runner import PipelineRunner, checks_in, missing_settings, models_in, reconciliation_in
from query_service.intents.validate import Expectation, ReadOnlySql

MAPPING = """
version: 1.0
domain: retail
models:
  - target_table: SILVER.FACT_ORDER
    sources:
      - source_id: CRM
        location: BRONZE.CRM.ORDERS
        join:
          table: BRONZE.CRM.CUSTOMER
          condition: "ORDERS.cust_id = CUSTOMER.cust_id"
    transformations:
      - target_column: ORDER_SK
        logic: "HASH('CRM', order_id)"
      - target_column: CUSTOMER_SK
        logic: "HASH('CRM', CUSTOMER.cust_id)"
      - target_column: AMOUNT
        logic: "TRY_TO_NUMBER(amount, 18, 2)"
        filter: "AMOUNT IS NOT NULL"
  - target_table: SILVER.DIM_CUSTOMER
    sources:
      - source_id: CRM
        location: BRONZE.CRM.CUSTOMER
      - source_id: ERP
        location: BRONZE.ERP.CLIENT
    transformations:
      - target_column: CUSTOMER_SK
        logic: "HASH(SOURCE_SYSTEM, SOURCE_ID)"
      - target_column: SOURCE_SYSTEM
        logic: {CRM: "'CRM'", ERP: "'ERP'"}
      - target_column: SOURCE_ID
        logic: {CRM: "cust_id", ERP: "clientId"}
      - target_column: SEGMENT
        logic:
          CRM: "LOOKUP(segmentId) FROM BRONZE.CRM.SEGMENT RETURNING segment_name"
          default: "NULL"
      - target_column: ROW_HASH
        logic: "HASH(SEGMENT, SOURCE_ID)"
"""

MODEL = """
version: 1.0
models:
  - name: SILVER.DIM_CUSTOMER
    type: dimension
    primary_key: CUSTOMER_SK
    columns:
      - {name: CUSTOMER_SK, type: VARCHAR(64)}
      - {name: SOURCE_SYSTEM, type: VARCHAR(10)}
      - {name: SOURCE_ID, type: VARCHAR(50)}
      - {name: SEGMENT, type: VARCHAR(50), description: the segment's name}
      - {name: ROW_HASH, type: VARCHAR(64)}
  - name: SILVER.FACT_ORDER
    type: fact
    primary_key: ORDER_SK
    columns:
      - {name: ORDER_SK, type: VARCHAR(64)}
      - {name: CUSTOMER_SK, type: VARCHAR(64)}
      - {name: AMOUNT, type: "NUMBER(18,2)"}
    foreign_keys:
      - {column: CUSTOMER_SK, references: SILVER.DIM_CUSTOMER.CUSTOMER_SK}
"""

DDL = """-- the retail silver layer
CREATE TABLE SILVER.DIM_CUSTOMER (
    CUSTOMER_SK VARCHAR(64) NOT NULL,
    SOURCE_SYSTEM VARCHAR(10) NOT NULL,
    SOURCE_ID VARCHAR(50),
    SEGMENT VARCHAR(50),
    ROW_HASH VARCHAR(64),
    CREATED_TS TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    UPDATED_TS TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    PRIMARY KEY (CUSTOMER_SK)
);
COMMENT ON TABLE SILVER.DIM_CUSTOMER IS 'Customers, one per system';
COMMENT ON COLUMN SILVER.DIM_CUSTOMER.SEGMENT IS 'Segment name; NULL when unknown';

CREATE TABLE SILVER.FACT_ORDER (
    ORDER_SK VARCHAR(64) NOT NULL,
    CUSTOMER_SK VARCHAR(64),
    AMOUNT NUMBER(18,2),
    PRIMARY KEY (ORDER_SK),
    FOREIGN KEY (CUSTOMER_SK) REFERENCES SILVER.DIM_CUSTOMER(CUSTOMER_SK)
);
"""

# The layer below as Snowflake holds it: loaded names carry a shared suffix and the columns are upper case.
CATALOG = {
    "SHOP.BRONZE.CUSTOMER_ICEBERG": ["CUST_ID", "SEGMENT_ID", "_SOURCE_FILE"],
    "SHOP.BRONZE.SEGMENT_ICEBERG": ["SEGMENT_ID", "SEGMENT_NAME"],
    "SHOP.BRONZE.ORDERS_ICEBERG": ["ORDER_ID", "CUST_ID", "AMOUNT"],
    "SHOP.BRONZE.CLIENT_ICEBERG": ["X", "Y"],  # another system's client table: same name, other columns
}
TICKET = "Build the retail silver layer in SHOP.SILVER: SILVER.DIM_CUSTOMER, SILVER.FACT_ORDER and SILVER.BRIDGE_ORDER_PROMO as Iceberg tables."


def _design() -> mapping.Design:
    return mapping.load_design({"design/mapping.yaml": MAPPING, "design/model.yaml": MODEL, "design/ddl.sql": DDL})


def _files(root: Path) -> Path:
    folder = root / "design"
    folder.mkdir(parents=True)
    (folder / "mapping.yaml").write_text(MAPPING, encoding="utf-8")
    (folder / "model.yaml").write_text(MODEL, encoding="utf-8")
    (folder / "ddl.sql").write_text(DDL, encoding="utf-8")
    (root / "other.yaml").write_text("models:\n  - name: X\n    columns: []\n", encoding="utf-8")
    return folder


# --------------------------------------------------------------------------- the documents
def test_the_three_documents_are_told_apart_by_their_content():
    assert (mapping.classify(MAPPING), mapping.classify(MODEL), mapping.classify(DDL)) == ("mapping", "model", "ddl")
    assert mapping.classify("just: text") is None
    design = _design()
    assert [m.target for m in design.mapping] == ["FACT_ORDER", "DIM_CUSTOMER"] and design.mapping[0].schema == "SILVER"
    assert design.models["FACT_ORDER"].foreign_keys[0].table == "DIM_CUSTOMER"
    customer = design.ddl["DIM_CUSTOMER"]
    assert customer.primary_key == ["CUSTOMER_SK"] and not customer.columns[1].nullable and customer.columns[2].nullable
    assert design.ddl["FACT_ORDER"].foreign_keys[0].to_column == "CUSTOMER_SK"


def test_the_ddl_is_created_in_the_target_database_as_written():
    ddl = mapping.qualify_ddl(_design().ddl["FACT_ORDER"], "SHOP", "SILVER")
    assert "CREATE TABLE IF NOT EXISTS SHOP.SILVER.FACT_ORDER" in ddl and "REFERENCES SHOP.SILVER.DIM_CUSTOMER" in ddl
    comments = mapping.qualify_ddl(_design().ddl["DIM_CUSTOMER"], "SHOP", "SILVER")
    assert "COMMENT ON COLUMN SHOP.SILVER.DIM_CUSTOMER.SEGMENT IS 'Segment name; NULL when unknown'" in comments
    assert "the retail silver layer" not in comments  # the file's own comments are left out


# --------------------------------------------------------------------------- binding and SQL
def test_sources_bind_by_name_and_columns_and_identifiers_resolve_to_the_loaded_columns():
    compiled = {c.name: c for c in mapping.compile_design(_design(), CATALOG, prefer_schema="BRONZE")}
    customer = compiled["DIM_CUSTOMER"]
    assert customer.branches == ["CRM"]
    assert customer.skipped and "another system's table" in customer.skipped[0] and customer.waiting_on == ["BRONZE.ERP.CLIENT"]
    sql = customer.sql
    sqlglot.parse_one(sql, read="snowflake")
    assert "CUSTOMER.CUST_ID AS SOURCE_ID" in sql
    assert "LEFT JOIN (SELECT L.SEGMENT_ID AS K, ANY_VALUE(L.SEGMENT_NAME) AS V FROM SHOP.BRONZE.SEGMENT_ICEBERG AS L GROUP BY L.SEGMENT_ID) AS LK1" in sql
    # A key hashes its values as they are (a missing part leaves the key NULL); a change hash never is NULL.
    assert "SHA2(CONCAT_WS('|', TO_VARCHAR(SOURCE_SYSTEM), TO_VARCHAR(SOURCE_ID)), 256) AS CUSTOMER_SK" in sql
    assert "COALESCE(TO_VARCHAR(SEGMENT), '~')" in sql
    assert "B1_1 AS" in sql  # the columns read from other target columns come in a later stage
    assert (customer.hash_column, customer.created_column, customer.updated_column) == ("ROW_HASH", "CREATED_TS", "UPDATED_TS")
    assert [c.name for c in customer.columns] == ["CUSTOMER_SK", "SOURCE_SYSTEM", "SOURCE_ID", "SEGMENT", "ROW_HASH"]


def test_targets_come_after_what_their_foreign_keys_point_at_and_joins_and_filters_compile():
    compiled = mapping.compile_design(_design(), CATALOG)
    assert [c.name for c in compiled] == ["DIM_CUSTOMER", "FACT_ORDER"]
    order = compiled[1]
    assert "JOIN SHOP.BRONZE.CUSTOMER_ICEBERG AS CUSTOMER ON ORDERS.CUST_ID = CUSTOMER.CUST_ID" in order.sql
    assert "TRY_TO_NUMBER(TO_VARCHAR(ORDERS.AMOUNT), 18, 2)" in order.sql and "WHERE (AMOUNT IS NOT NULL)" in order.sql
    sqlglot.parse_one(order.sql, read="snowflake")


def test_a_target_whose_sources_are_not_loaded_waits():
    catalog = {k: v for k, v in CATALOG.items() if "ORDERS" not in k}
    order = next(c for c in mapping.compile_design(_design(), catalog) if c.name == "FACT_ORDER")
    assert order.sql == "" and order.waiting_on == ["BRONZE.CRM.ORDERS"]


# --------------------------------------------------------------------------- finding the files
def test_the_design_is_found_from_the_targets_a_ticket_names(tmp_path: Path):
    folder = _files(tmp_path)
    files, named = mapping.discover(tmp_path, TICKET)
    assert files[0] == folder / "mapping.yaml" and {f.name for f in files} == {"mapping.yaml", "model.yaml", "ddl.sql"}
    assert set(named) == {"DIM_CUSTOMER", "FACT_ORDER"}
    assert mapping.discover(tmp_path, "build something else") == ([], [])


def test_files_a_ticket_names_resolve_under_the_data_directory(tmp_path: Path):
    _files(tmp_path)
    refs = mapping.referenced_files("Mapping in C:\\Users\\me\\work\\design\\mapping.yaml, DDL in ddl.sql")
    assert refs == ["C:\\Users\\me\\work\\design\\mapping.yaml", "ddl.sql"]
    found = mapping.resolve_files(tmp_path, refs)
    assert [p.name for p in found] == ["mapping.yaml", "ddl.sql"]
    assert len(mapping.resolve_files(tmp_path, ["design"])) == 3
    assert mapping.resolve_files(tmp_path, ["../../etc/passwd.yaml"]) == []


def test_questions_the_design_or_the_planner_answer_are_not_asked():
    from query_service.intents.service import _settled

    expect = Expectation(designed=True, design_names=["SOURCE_SYSTEM", "DIM_CUSTOMER"])
    assert _settled("What value should SOURCE_SYSTEM carry for rows from SHOP.BRONZE?", expect)
    assert _settled("How often does the bronze load run, so the silver refresh cadence can match it?", expect)
    assert not _settled("Who signs off the silver layer?", expect)


# --------------------------------------------------------------------------- the modeler's dry run
class DryRunSql:
    """Answers the modeler's read-only counts: 5 rows, 4 keys, one missing SOURCE_SYSTEM, 2 orders without a customer."""

    def __init__(self) -> None:
        self.sent: list[str] = []

    async def query(self, statement: str) -> list[dict[str, Any]]:
        self.sent.append(statement)
        if "NOT EXISTS" in statement:
            return [{"N": 2}]
        return [{"N": 5, "K": 4, "BK": 0, "NN_0": 0, "NN_1": 1}]


class DryRunReader:
    def __init__(self) -> None:
        self.sql = DryRunSql()

    @contextlib.asynccontextmanager
    async def session(self) -> AsyncIterator[ReadOnlySql]:
        yield ReadOnlySql(self.sql)  # type: ignore[arg-type]


def _validation() -> IntentValidation:
    objects = [ValidatedObject(kind="table", name=name, role="source", exists=True, columns=cols) for name, cols in CATALOG.items()]
    return IntentValidation(checked_at=datetime.now(tz=UTC), reachable=True, objects=objects)


def _intent() -> StructuredIntent:
    return StructuredIntent(
        kind="model_layer",
        layer="silver",
        summary="Retail silver",
        source=IntentSource(database="SHOP", schema="BRONZE", mapping_files=["design"]),
        target=IntentTarget(database="SHOP", schema="SILVER", external_volume="LAKE_VOL"),
    )


def _modelled(root: Path):
    _files(root)
    expect = Expectation(target_database="SHOP", target_schema="SILVER", source_database="SHOP", source_schema="BRONZE")
    reader = DryRunReader()
    modeler = MappingModeler(reader=reader, data_dir=root)  # type: ignore[arg-type]
    spec = asyncio.run(modeler.model(_intent(), "Retail silver", expect, _validation(), ticket=TICKET))
    return spec, reader


def test_the_modeler_dry_runs_each_table_and_tells_the_approver_what_it_found(tmp_path: Path):
    spec, reader = _modelled(tmp_path)
    assert spec.name == "model_retail_silver" and spec.kind == "model_layer"
    assert spec.target.table_format == "native" and spec.target.external_volume is None and spec.target.load_mode == "merge"
    assert spec.source.mapping_files == ["design/ddl.sql", "design/mapping.yaml", "design/model.yaml"]
    customer = spec.models[0]
    assert (customer.name, customer.rows, customer.duplicates, customer.nulls) == ("DIM_CUSTOMER", 5, 1, {"SOURCE_SYSTEM": 1})
    assert customer.ddl.startswith("CREATE TABLE IF NOT EXISTS SHOP.SILVER.DIM_CUSTOMER") and customer.hash_column == "ROW_HASH"
    assert any(t.kind == "unique" for t in customer.tests) and any(t.name.endswith("_required") for t in customer.tests)
    assert spec.models[1].relationships[0].to_table == "DIM_CUSTOMER"
    risks = "\n".join(spec.risks)
    assert "DIM_CUSTOMER: built from 1 of 2 sources; ERP waits for BRONZE.ERP.CLIENT." in risks
    assert "1 of 5 rows repeat a CUSTOMER_SK" in risks and "SHOP.SILVER.LOAD_REJECTS" in risks
    assert "1 rows have no SOURCE_SYSTEM, a NOT NULL column" in risks
    assert "FACT_ORDER: 2 rows have a CUSTOMER_SK that DIM_CUSTOMER does not hold" in risks
    assert "The ticket names BRIDGE_ORDER_PROMO" in risks and "native Snowflake tables" in risks
    assert all(s.lstrip().startswith("SELECT") for s in reader.sql.sent)  # read-only throughout


# --------------------------------------------------------------------------- the generated pipeline
def _generated(tmp_path: Path) -> Path:
    spec, _ = _modelled(tmp_path / "data")
    folder = tmp_path / "pipeline"
    for rel, text in generator.generate(spec).items():
        path = folder / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
    return folder


def _load_pipeline(folder: Path) -> Any:
    found = importlib.util.spec_from_file_location("generated_pipeline", folder / "pipeline.py")
    assert found is not None and found.loader is not None
    module = importlib.util.module_from_spec(found)
    found.loader.exec_module(module)
    return module


def test_the_pipeline_creates_as_the_ddl_says_and_merges_with_rejects(tmp_path: Path):
    folder = _generated(tmp_path)
    setup = (folder / "sql" / "010_setup.sql").read_text(encoding="utf-8")
    tables = (folder / "sql" / "020_table.sql").read_text(encoding="utf-8")
    load = (folder / "sql" / "030_load.sql").read_text(encoding="utf-8")
    checks = (folder / "sql" / "040_checks.sql").read_text(encoding="utf-8")
    assert "CREATE TABLE IF NOT EXISTS SHOP.SILVER.LOAD_REJECTS" in setup
    assert "CREATE TABLE IF NOT EXISTS SHOP.SILVER.DIM_CUSTOMER" in tables and "CREATE ICEBERG" not in tables
    assert "CREATE OR REPLACE TRANSIENT TABLE SHOP.SILVER._STG_DIM_CUSTOMER" in load
    assert "INSERT INTO SHOP.SILVER.LOAD_REJECTS" in load and "'repeats a CUSTOMER_SK already loaded in this run'" in load
    assert "WHEN MATCHED AND t.ROW_HASH IS DISTINCT FROM s.ROW_HASH THEN UPDATE SET" in load and "t.UPDATED_TS = CURRENT_TIMESTAMP()" in load
    assert "INSERT (CUSTOMER_SK, SOURCE_SYSTEM, SOURCE_ID, SEGMENT, ROW_HASH, CREATED_TS, UPDATED_TS)" in load
    assert "DROP TABLE IF EXISTS SHOP.SILVER._STG_DIM_CUSTOMER" in load
    assert "'warn' AS severity" in checks and "customer_sk_in_dim_customer" in checks
    result = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "tests"], cwd=folder, capture_output=True, text=True, check=False)
    assert result.returncode == 0, result.stdout[-2000:]


def test_the_schema_is_created_only_when_validation_found_it_missing(tmp_path: Path):
    _files(tmp_path)
    validation = _validation()
    validation.objects.append(ValidatedObject(kind="schema", name="SHOP.SILVER", role="target", exists=False))
    expect = Expectation(target_database="SHOP", target_schema="SILVER", source_database="SHOP", source_schema="BRONZE")
    modeler = MappingModeler(reader=DryRunReader(), data_dir=tmp_path)  # type: ignore[arg-type]
    spec = asyncio.run(modeler.model(_intent(), "Retail silver", expect, validation, ticket=TICKET))
    assert spec.create == ["schema"] and any("needs CREATE SCHEMA on SHOP" in r for r in spec.risks)
    assert "CREATE SCHEMA IF NOT EXISTS SHOP.SILVER" in generator.generate(spec)["sql/010_setup.sql"]
    existing, _ = _modelled(tmp_path / "again")
    assert existing.create == [] and "CREATE SCHEMA" not in generator.generate(existing)["sql/010_setup.sql"]


def test_the_generated_runner_splits_outside_quotes_and_reports_each_table(tmp_path: Path):
    pipeline = _load_pipeline(_generated(tmp_path))
    assert pipeline.split_statements("COMMENT ON TABLE T IS 'a; b';\nSELECT 'it''s; fine';\nEXECUTE IMMEDIATE $$ BEGIN X; Y; END; $$;") == [
        "COMMENT ON TABLE T IS 'a; b'",
        "SELECT 'it''s; fine'",
        "EXECUTE IMMEDIATE $$ BEGIN X; Y; END; $$",
    ]
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        pipeline.report(
            [
                {"rows": [{"number of rows inserted": "1"}]},
                {"rows": [{"number of rows inserted": "4", "number of rows updated": "0"}]},
                {"rows": [{"MODEL_NAME": "DIM_CUSTOMER", "STAGED": "5", "REJECTED": "1", "TABLE_ROWS": "4"}]},
            ]
        )
        failures = pipeline.checks([{"rows": [{"CHECK_NAME": "A.fk", "FAILURES": "2", "SEVERITY": "warn"}, {"CHECK_NAME": "A.key", "FAILURES": "0"}]}])
    assert out.getvalue().splitlines() == ["model DIM_CUSTOMER staged=5 rejected=1 inserted=4 updated=0 rows=4", "WARN A.fk (2)", "pass A.key (0)"]
    assert failures == 0


# --------------------------------------------------------------------------- running it in the hub
_FAKE_MODEL_PIPELINE = '''import sys
command = sys.argv[1]
if command == "apply":
    print("ok  CREATE SCHEMA IF NOT EXISTS SHOP.SILVER")
elif command == "load":
    print("ok  MERGE INTO SHOP.SILVER.DIM_CUSTOMER t USING (")
    print("model DIM_CUSTOMER staged=5 rejected=1 inserted=4 updated=0 rows=4")
    print("pass DIM_CUSTOMER.dim_customer_key_unique (0)")
    print("WARN FACT_ORDER.customer_sk_in_dim_customer (2)")
else:
    sys.exit(3)
'''


def test_a_modelled_layer_runs_without_an_upload_and_warnings_do_not_fail_it(tmp_path: Path):
    spec, _ = _modelled(tmp_path / "data")
    folder = tmp_path / "pipeline"
    folder.mkdir()
    (folder / "pipeline.py").write_text(_FAKE_MODEL_PIPELINE, encoding="utf-8")
    env = {"PATH": "", "ECH_RUN_SNOWFLAKE_HOST": "h", "ECH_RUN_SNOWFLAKE_TOKEN": "not-a-real-token", "ECH_RUN_SNOWFLAKE_WAREHOUSE": "w"}
    assert missing_settings(spec, {k.removeprefix("ECH_RUN_"): v for k, v in env.items()}) == []
    runner = PipelineRunner(lambda: env, python=sys.executable)

    async def progress(run: PipelineRun) -> None:
        return None

    run = asyncio.run(runner.execute(spec, folder, None, triggered_by="approval", progress=progress))
    assert run.status == "succeeded", run.error
    steps = {s.key: s for s in run.steps}
    assert steps["upload"].status == "skipped" and "nothing to upload" in steps["upload"].detail
    assert [(m.name, m.staged, m.rejected, m.inserted, m.rows) for m in run.models] == [("DIM_CUSTOMER", 5, 1, 4, 4)]
    assert [(c.name, c.passed, c.severity) for c in run.checks] == [
        ("DIM_CUSTOMER.dim_customer_key_unique", True, "error"),
        ("FACT_ORDER.customer_sk_in_dim_customer", False, "warn"),
    ]
    assert "1 warning(s)" in steps["load"].detail and any("customer_sk_in_dim_customer" in w for w in run.warnings)


def test_check_and_model_lines_are_read_from_the_output():
    assert models_in("noise\nmodel X staged=3 rejected=0 inserted=1 updated=2 rows=3\n")[0].updated == 2
    checks = checks_in("WARN A.fk (0)\nFAIL A.key (1)\n")
    assert [(c.passed, c.severity) for c in checks] == [(True, "warn"), (False, "error")]


# --------------------------------------------------------------------------- reconciliation
def test_each_modelled_table_is_reconciled_against_its_source(tmp_path: Path):
    folder = _generated(tmp_path)
    text = (folder / "sql" / "045_reconcile.sql").read_text(encoding="utf-8")
    assert "-- DIM_CUSTOMER\nWITH src AS (" in text and "-- FACT_ORDER\nWITH src AS (" in text
    # The same rules as the staged load: a repeated key or a NULL in a NOT NULL column is rejected, which explains a difference.
    assert "ROW_NUMBER() OVER (PARTITION BY CUSTOMER_SK ORDER BY ROW_HASH) AS _RN" in text
    assert "kept AS (\n  SELECT * FROM src WHERE NOT (CUSTOMER_SK IS NULL OR SOURCE_SYSTEM IS NULL OR _RN > 1)\n)" in text
    for measure in ("'rows' AS MEASURE", "'keys' AS MEASURE", "'sum:AMOUNT' AS MEASURE"):
        assert measure in text
    assert "'sum:AMOUNT' AS MEASURE, (SELECT COALESCE(SUM(k.AMOUNT), 0) FROM kept k)" in text and "'warn' AS SEVERITY" in text
    pipeline = _load_pipeline(folder)
    statements = pipeline.render(folder / "sql" / "045_reconcile.sql", {})
    assert len(statements) == 2 and all(s.startswith("WITH src AS") for s in statements)
    for statement in statements:
        sqlglot.parse_one(statement, read="snowflake")  # each one parses as a single Snowflake statement


def test_the_generated_runner_prints_a_reconciliation_and_counts_its_gaps(tmp_path: Path):
    pipeline = _load_pipeline(_generated(tmp_path))
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        gaps = pipeline.reconcile(
            [
                {
                    "rows": [
                        {"RECON_TABLE": "DIM_CUSTOMER", "MEASURE": "rows", "SOURCE_VALUE": "5", "TARGET_VALUE": "4", "EXPLAINED": "1", "SEVERITY": "error"},
                        {"RECON_TABLE": "DIM_CUSTOMER", "MEASURE": "keys", "SOURCE_VALUE": "4", "TARGET_VALUE": "3", "EXPLAINED": "0", "SEVERITY": "error"},
                        {"RECON_TABLE": "FACT_ORDER", "MEASURE": "sum:AMOUNT", "SOURCE_VALUE": "10.50", "TARGET_VALUE": "10.00", "EXPLAINED": "0", "SEVERITY": "warn"},
                        {"RECON_TABLE": "FACT_ORDER", "MEASURE": "rows", "SOURCE_VALUE": "3", "TARGET_VALUE": "3", "EXPLAINED": "0", "SEVERITY": "error"},
                    ]
                },
                {"rows": [{"CHECK_NAME": "not a reconciliation row", "FAILURES": "0"}]},
            ]
        )
    lines = out.getvalue().splitlines()
    assert gaps == 1  # only the keys gap: rejected rows explain the rows, and a total only warns
    assert lines == [
        "recon DIM_CUSTOMER rows source=5 target=4 explained=1 gap=0 explained",
        "recon DIM_CUSTOMER keys source=4 target=3 explained=0 gap=1 GAP",
        "recon FACT_ORDER sum:AMOUNT source=10.50 target=10.00 explained=0 gap=0.50 WARN",
        "recon FACT_ORDER rows source=3 target=3 explained=0 gap=0 match",
    ]
    found = reconciliation_in("noise\n" + out.getvalue())
    assert [(r.table, r.measure, r.status, r.gap) for r in found] == [
        ("DIM_CUSTOMER", "rows", "explained", 0.0),
        ("DIM_CUSTOMER", "keys", "gap", 1.0),
        ("FACT_ORDER", "sum:AMOUNT", "warn", 0.5),
        ("FACT_ORDER", "rows", "match", 0.0),
    ]


_FAKE_GAP_PIPELINE = '''import sys
command = sys.argv[1]
if command == "apply":
    print("ok  CREATE SCHEMA IF NOT EXISTS SHOP.SILVER")
elif command == "load":
    print("ok  MERGE INTO SHOP.SILVER.DIM_CUSTOMER t USING (")
    print("model DIM_CUSTOMER staged=5 rejected=1 inserted=3 updated=0 rows=3")
    print("pass DIM_CUSTOMER.dim_customer_key_unique (0)")
    print("recon DIM_CUSTOMER rows source=5 target=3 explained=1 gap=1 GAP")
    print("recon FACT_ORDER sum:AMOUNT source=10.5 target=10.5 explained=0 gap=0 match")
    sys.exit(1)
else:
    sys.exit(3)
'''


def test_a_reconciliation_gap_fails_the_load_and_says_where(tmp_path: Path):
    spec, _ = _modelled(tmp_path / "data")
    folder = tmp_path / "pipeline"
    folder.mkdir()
    (folder / "pipeline.py").write_text(_FAKE_GAP_PIPELINE, encoding="utf-8")
    env = {"PATH": "", "ECH_RUN_SNOWFLAKE_HOST": "h", "ECH_RUN_SNOWFLAKE_TOKEN": "not-a-real-token", "ECH_RUN_SNOWFLAKE_WAREHOUSE": "w"}
    runner = PipelineRunner(lambda: env, python=sys.executable)

    async def progress(run: PipelineRun) -> None:
        return None

    run = asyncio.run(runner.execute(spec, folder, None, triggered_by="approval", progress=progress))
    assert run.status == "failed"
    assert "1 reconciliation gap(s): DIM_CUSTOMER rows source 5, target 3, 1 rejected" in run.error
    assert [(r.table, r.measure, r.status) for r in run.reconciliation] == [("DIM_CUSTOMER", "rows", "gap"), ("FACT_ORDER", "sum:AMOUNT", "match")]
    load = next(s for s in run.steps if s.key == "load")
    assert load.status == "failed" and any(m.label == "reconciled" and m.value == "1 of 2" for m in load.metrics)
