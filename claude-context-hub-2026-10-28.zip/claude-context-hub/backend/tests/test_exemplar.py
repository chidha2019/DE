"""An exemplar's checks copied onto a new CSV source, and the models that read the exemplar flagged."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

from ech_core.schemas.intents import (
    IntentSource,
    IntentTarget,
    SpecColumn,
    SpecTest,
    StructuredIntent,
)
from query_service.intents import generator
from query_service.intents.exemplar import (
    adopt_contract,
    column_map,
    downstream_models,
    precheck,
    translate_checks,
)
from query_service.intents.planner import Planner, render_spec_markdown

TABLE = "BRONZE.A_CLAIM"


def _check(name: str, sql: str, others: list[str] | None = None, params: list[str] | None = None) -> dict[str, Any]:
    return {"name": name, "sql": sql, "others": others or [], "params": params}


# The statements as the crawler stores them: templates resolved, %(param)s turned into a quoted name.
CHECKS = [
    _check(
        "A_CLAIM.unique",
        "select 'A_CLAIM.unique' check_name,count(*) FAILURES from (select CLAIM_ID from BRONZE.A_CLAIM group by CLAIM_ID having count(*)>1) violations",
    ),
    _check(
        "A_CLAIM.CLAIM_ID.required",
        "select 'A_CLAIM.CLAIM_ID.required' check_name,count(*) FAILURES from (select 1 from BRONZE.A_CLAIM where CLAIM_ID is null) violations",
    ),
    _check(
        "A_CLAIM.DATE_OF_CLAIM.date",
        "select 'A_CLAIM.DATE_OF_CLAIM.date' check_name,count(*) FAILURES from (select 1 from BRONZE.A_CLAIM where DATE_OF_CLAIM is not null "
        "and (not regexp_like(DATE_OF_CLAIM,'[0-9]{4}-[0-9]{2}-[0-9]{2}') or try_to_date(DATE_OF_CLAIM,'YYYY-MM-DD') is null)) violations",
    ),
    _check(
        "A_CLAIM.AGREEMENT_ID.reference",
        "select 'A_CLAIM.AGREEMENT_ID.reference' check_name,count(*) FAILURES from (select 1 from BRONZE.A_CLAIM c left join BRONZE.A_INSURANCE_POLICY p "
        "on c.AGREEMENT_ID=p.AGREEMENT_ID where c.AGREEMENT_ID is not null and p.AGREEMENT_ID is null) violations",
        others=["BRONZE.A_INSURANCE_POLICY"],
    ),
    _check(
        "A_CLAIM.nonnegative_amount",
        "select 'A_CLAIM.nonnegative_amount' check_name,count(*) FAILURES from (select 1 from BRONZE.A_CLAIM where try_to_decimal(CLAIM_AMOUNT,18,2)<0) violations",
    ),
    _check(
        "A_CLAIM.status",
        "select 'A_CLAIM.status' check_name,count(*) FAILURES from BRONZE.A_CLAIM where CLAIM_STATUS is null "
        "or upper(replace(CLAIM_STATUS,' ','_')) not in ('OPEN','UNDER_REVIEW','APPROVED','REJECTED')",
    ),
    _check(
        "A_CLAIM.within_snapshot",
        "select 'A_CLAIM.within_snapshot' check_name,count(*) FAILURES from BRONZE.A_CLAIM where try_to_date(DATE_OF_CLAIM,'YYYY-MM-DD')>to_date('as_of')",
        params=["as_of"],
    ),
    _check("A_CLAIM.batch", "select 'A_CLAIM.batch' check_name,count(*) FAILURES from BRONZE.A_CLAIM where CLAIM_ID = 'batch_id'", params=["batch_id"]),
    _check(
        "A_CLAIM.extra_csv_fields",
        "select 'A_CLAIM.extra_csv_fields' check_name,count(*) FAILURES from (select 1 from BRONZE.A_CLAIM where EXTRA_COLUMN is not null) violations",
    ),
]
EXEMPLAR_COLUMNS = [
    {"column": "CLAIM_ID", "source_header": "Claim_Id", "required": True},
    {"column": "DATE_OF_CLAIM", "source_header": "Date_Of_Claim", "required": True},
    {"column": "DAMAGE_TYPE", "source_header": "Damage_Type", "required": False},
    {"column": "CLAIM_STATUS", "source_header": "Claim_Status", "required": True},
    {"column": "CLAIM_AMOUNT", "source_header": "Claim_Amount", "required": True},
]
DOWNSTREAM = {
    "key": "acme/claims|table|SILVER.FACT_LOSS_EVENT",
    "name": "SILVER.FACT_LOSS_EVENT",
    "layer": "silver",
    "files": ["config/models.yml", "sql/silver/fact_loss_event.sql"],
    "reads": ["BRONZE.A_CLAIM", "BRONZE.A_INCIDENT"],
    "affects": ["GOLD.FACT_LOSS_PERFORMANCE"],
    "columns": [
        {"column": "SOURCE_CLAIM_ID", "upstream": ["BRONZE.A_CLAIM.CLAIM_ID"]},
        {"column": "REQUESTED_AMT", "upstream": ["BRONZE.A_CLAIM.CLAIM_AMOUNT"]},
        {"column": "LOSS_DT", "upstream": ["BRONZE.A_INCIDENT.INCIDENT_DATE"]},
        {"column": "SOURCE_SYSTEM", "derivation": "constant", "upstream": []},
        {"column": "ADJUSTER", "upstream": ["BRONZE.A_CLAIM.ADJUSTER_NAME"]},
    ],
}


def _exemplar() -> dict[str, Any]:
    return {
        "repo": "acme/claims",
        "url": "https://github.com/acme/claims",
        "sha": "abc123",
        "table": {"name": TABLE},
        "columns": EXEMPLAR_COLUMNS,
        "checks": CHECKS,
        "downstream": [DOWNSTREAM],
    }


def _columns() -> list[SpecColumn]:
    return [
        SpecColumn(name="CLAIM_ID", type="VARCHAR(64)", nullable=False, source_header="Claim_Id"),
        SpecColumn(name="DATE_OF_CLAIM", type="DATE", nullable=False, source_header="Date_Of_Claim"),
        SpecColumn(name="DAMAGE_TYPE", type="VARCHAR(64)", nullable=False, source_header="Damage_Type"),
        SpecColumn(name="CLAIM_STATUS", type="VARCHAR(64)", nullable=False, source_header="Claim_Status"),
        SpecColumn(name="CLAIM_AMT", type="NUMBER(18,2)", nullable=True, source_header="Claim Amount"),
    ]


def _translated(columns: list[SpecColumn]):
    return translate_checks(CHECKS, TABLE, column_map(EXEMPLAR_COLUMNS, columns), {c.name: c.type for c in columns})


def test_checks_are_copied_covered_or_skipped_with_a_reason() -> None:
    columns = _columns()
    assert column_map(EXEMPLAR_COLUMNS, columns)["CLAIM_AMOUNT"] == "CLAIM_AMT"  # matched on the CSV header
    copied = _translated(columns)
    outcome = {a.name: a for a in copied.accounting}
    assert len(outcome) == len(CHECKS)
    assert copied.unique is not None and copied.unique.columns == ["CLAIM_ID"] and copied.unique.origin == "A_CLAIM.unique"
    assert copied.not_null == ["CLAIM_ID"] and copied.not_null_origin == "A_CLAIM.CLAIM_ID.required"
    assert outcome["A_CLAIM.CLAIM_ID.required"].test == "required_columns_not_null"
    assert outcome["A_CLAIM.DATE_OF_CLAIM.date"].outcome == "covered"  # the load casts the column to DATE
    reference = outcome["A_CLAIM.AGREEMENT_ID.reference"]
    assert reference.outcome == "skipped" and "BRONZE.A_INSURANCE_POLICY" in reference.detail
    assert outcome["A_CLAIM.batch"].outcome == "skipped" and "batch_id" in outcome["A_CLAIM.batch"].detail
    assert outcome["A_CLAIM.extra_csv_fields"].outcome == "skipped" and "EXTRA_COLUMN" in outcome["A_CLAIM.extra_csv_fields"].detail
    tests = {t.name: t for t in copied.conditions}
    assert set(tests) == {"nonnegative_amount", "status", "within_snapshot"}
    assert tests["nonnegative_amount"].condition == "CLAIM_AMT < 0"  # safe cast dropped, column renamed
    assert tests["within_snapshot"].condition == "DATE_OF_CLAIM > CAST(CURRENT_DATE AS DATE)"
    assert "as_of read as CURRENT_DATE" in tests["within_snapshot"].detail
    assert tests["status"].origin == "A_CLAIM.status" and "UPPER(REPLACE(CLAIM_STATUS, ' ', '_'))" in (tests["status"].condition or "")


def test_a_check_without_stored_sql_asks_for_a_new_crawl() -> None:
    copied = translate_checks([{"name": "A_CLAIM.old", "sql": None}], TABLE, {"CLAIM_ID": "CLAIM_ID"}, {"CLAIM_ID": "VARCHAR"})
    assert copied.accounting[0].outcome == "skipped" and "crawl the repository again" in copied.accounting[0].detail


def test_copied_checks_run_against_the_sample_before_anything_is_loaded() -> None:
    columns = _columns()
    tests = [
        SpecTest(name="required_columns_not_null", kind="not_null", columns=["CLAIM_ID", "CLAIM_AMT"]),
        *_translated(columns).conditions,
        SpecTest(name="udf", kind="condition", columns=["CLAIM_ID"], condition="MY_UDF(CLAIM_ID) = 1"),
    ]
    records: list[dict[str, str | None]] = [
        {"CLAIM_ID": "C-1", "DATE_OF_CLAIM": "2020-01-02", "DAMAGE_TYPE": "Hail", "CLAIM_STATUS": "Open", "CLAIM_AMT": "120.50"},
        {"CLAIM_ID": "C-2", "DATE_OF_CLAIM": "2020-01-03", "DAMAGE_TYPE": None, "CLAIM_STATUS": "Denied", "CLAIM_AMT": "-5"},
        {"CLAIM_ID": "C-3", "DATE_OF_CLAIM": "2020-01-03", "DAMAGE_TYPE": "Fire", "CLAIM_STATUS": "Under Review", "CLAIM_AMT": None},
    ]
    precheck(tests, columns, records)
    by = {t.name: t for t in tests}
    assert by["status"].sample_failures == 1 and by["status"].sample_examples == ["CLAIM_STATUS=Denied"]
    assert by["nonnegative_amount"].sample_failures == 1 and by["nonnegative_amount"].sample_examples == ["CLAIM_AMT=-5"]
    assert by["within_snapshot"].sample_failures == 0
    assert by["required_columns_not_null"].sample_failures == 1 and by["required_columns_not_null"].sample_examples == ["CLAIM_AMT blank"]
    assert by["udf"].sample_failures is None  # not runnable offline; it still runs after the load


def test_the_exemplar_contract_decides_nullability_where_the_sample_agrees() -> None:
    columns = _columns()
    assumptions, risks = adopt_contract(_exemplar(), columns, column_map(EXEMPLAR_COLUMNS, columns))
    by = {c.name: c for c in columns}
    assert by["DAMAGE_TYPE"].nullable  # optional in the contract, though the sample had no blanks
    assert by["CLAIM_AMT"].nullable  # required, but the sample has blanks: the copied check reports them
    assert assumptions == ["DAMAGE_TYPE stays nullable, as in BRONZE.A_CLAIM's contract; the sample just had no blanks."]
    assert len(risks) == 1 and risks[0].startswith("CLAIM_AMT is required in BRONZE.A_CLAIM's contract")


def test_downstream_models_show_which_columns_the_new_feed_supplies() -> None:
    models, risks = downstream_models(_exemplar(), column_map(EXEMPLAR_COLUMNS, _columns()), "BRONZE.C_CLAIM")
    (model,) = models
    assert {c.column: c.status for c in model.columns} == {
        "SOURCE_CLAIM_ID": "mapped",
        "REQUESTED_AMT": "mapped",
        "LOSS_DT": "needs",
        "SOURCE_SYSTEM": "constant",
        "ADJUSTER": "missing",
    }
    assert next(c for c in model.columns if c.column == "REQUESTED_AMT").provided_by == ["CLAIM_AMT"]
    assert model.files == ["sql/silver/fact_loss_event.sql"]
    assert model.file_url == "https://github.com/acme/claims/blob/abc123/sql/silver/fact_loss_event.sql"
    assert model.link == "/knowledge?repo=acme%2Fclaims&node=acme%2Fclaims%7Ctable%7CSILVER.FACT_LOSS_EVENT"
    (risk,) = risks
    assert risk.startswith("Nothing reads BRONZE.C_CLAIM yet. In acme/claims, SILVER.FACT_LOSS_EVENT (sql/silver/fact_loss_event.sql) reads BRONZE.A_CLAIM")
    assert "never reach GOLD.FACT_LOSS_PERFORMANCE" in risk and "supplies 2 of its 5 columns" in risk
    assert "LOSS_DT comes from BRONZE.A_INCIDENT" in risk and "ADJUSTER needs exemplar columns" in risk and "SOURCE_SYSTEM is a constant there" in risk


class _FakeRepoGraph:
    async def conventions(self) -> list[dict[str, Any]]:
        headers = ["Claim_Id", "Date_Of_Claim", "Damage_Type", "Claim_Status", "Claim_Amount"]
        return [
            {
                "repo": "acme/claims",
                "ref": "main",
                "stages": [],
                "volumes": [{"name": "ICEBERG_VOL"}],
                "pipelines": [],
                "sources": [{"repo": "acme/claims", "source": "A_CLAIM", "headers": headers, "path": "core/claim.csv", "table": TABLE}],
                "tables": [{"name": TABLE, "layer": "bronze"}],
            }
        ]

    async def exemplar(self, repo: str, table: str) -> dict[str, Any]:
        assert (repo, table) == ("acme/claims", TABLE)
        return _exemplar()


def test_planner_copies_exemplar_checks_and_flags_downstream_models(tmp_path: Path) -> None:
    folder = tmp_path / "claims"
    folder.mkdir()
    (folder / "claims_1.csv").write_text(
        "Claim_Id,Date_Of_Claim,Damage_Type,Claim_Status,Claim_Amount\nC-1,2020-01-02,Hail,Open,120.50\nC-2,2020-01-03,Fire,Denied,80.00\n",
        encoding="utf-8",
    )
    planner = Planner(semantic=None, glossary=None, data_dir=tmp_path, repo_graph=_FakeRepoGraph())  # type: ignore[arg-type]
    target = IntentTarget(database="OMNI", schema_name="BRONZE", table="C_CLAIM", load_mode="merge", merge_keys=["claim_id"])
    intent = StructuredIntent(kind="ingest_csv_to_iceberg", source=IntentSource(folder="claims"), target=target)
    spec = asyncio.run(planner.plan(intent, "Load Summit claims"))

    assert spec.target.merge_keys == ["CLAIM_ID"]  # the ticket's lower-case key named after the real column
    assert {c.name: c.nullable for c in spec.columns}["DAMAGE_TYPE"] is True
    outcomes = [c.outcome for c in spec.exemplar_checks]
    assert (outcomes.count("copied"), outcomes.count("covered"), outcomes.count("skipped")) == (5, 1, 3)
    tests = {t.name: t for t in spec.tests}
    assert tests["claim_id_unique"].origin == "A_CLAIM.unique"
    assert tests["required_columns_not_null"].origin == "A_CLAIM.CLAIM_ID.required"
    assert tests["status"].sample_failures == 1
    assert any(r.startswith("status (copied from A_CLAIM.status) fails on 1 of 2 sampled rows: CLAIM_STATUS=Denied") for r in spec.risks)
    assert any(r.startswith("Nothing reads BRONZE.C_CLAIM yet.") for r in spec.risks)
    assert [d.table for d in spec.downstream] == ["SILVER.FACT_LOSS_EVENT"]

    markdown = render_spec_markdown(spec)
    assert "Exemplar checks: 5 copied, 1 covered by the typed load, 3 skipped" in markdown
    assert "- SILVER.FACT_LOSS_EVENT (acme/claims, sql/silver/fact_loss_event.sql): this feed supplies 2 of 5 columns" in markdown

    files = generator.generate(spec)
    checks = files["sql/040_checks.sql"]
    assert "-- copied from A_CLAIM.status\nSELECT 'status' AS check_name, COUNT(*) AS failures FROM OMNI.BRONZE.C_CLAIM WHERE CLAIM_STATUS IS NULL" in checks
    assert "SELECT 'nonnegative_amount' AS check_name, COUNT(*) AS failures FROM OMNI.BRONZE.C_CLAIM WHERE CLAIM_AMOUNT < 0;" in checks
    assert "ON t.CLAIM_ID = s.CLAIM_ID" in files["sql/030_load.sql"]
    readme = files["README.md"]
    assert "- status: condition on CLAIM_STATUS (copied from A_CLAIM.status)" in readme
    assert "## Downstream models to update" in readme and "  - LOSS_DT: needs (today: BRONZE.A_INCIDENT.INCIDENT_DATE)" in readme
