"""Line of business at sync time: tags, pipeline defaults, column values, inheritance along joins."""

from __future__ import annotations

import asyncio
from types import SimpleNamespace
from typing import Any
from uuid import UUID, uuid4

from ech_core.semantic.lines import (
    LineEvidence,
    LineValue,
    LineVocabulary,
    from_defaults,
    from_tags,
    from_values,
    inherit,
    line_columns,
)
from ingestion_service.services.pipeline_service import PipelineService

VOCAB = LineVocabulary(
    values=[LineValue("life", "Life", ("life insurance",)), LineValue("annuity", "Annuity", ("annuities",))],
    names=["Line of Business", "lob", "business line", "product line"],
)


def test_vocabulary_reads_codes_lists_and_tag_names():
    assert VOCAB.match("LIFE") == ({"life"}, [])
    assert VOCAB.match("Life, ANNUITIES") == ({"life", "annuity"}, [])
    assert VOCAB.match("Property") == (set(), ["Property"])
    assert VOCAB.is_line_name("LINE_OF_BUSINESS") and VOCAB.is_line_name("GOV.TAGS.LOB") and VOCAB.is_line_name("product_line")
    assert not VOCAB.is_line_name("PRODUCT_TYPE")


def test_tags_on_the_table_or_a_column_answer_first():
    ev = from_tags(["DOMAIN=CLAIMS", "LINE_OF_BUSINESS=ANNUITY"], VOCAB)
    assert ev is not None and ev.lines == {"annuity"} and ev.source == "tag" and "LINE_OF_BUSINESS=ANNUITY" in ev.evidence
    assert from_tags(["LINE_OF_BUSINESS"], VOCAB) is None


def test_the_most_specific_pipeline_default_wins():
    defaults = [
        {"name": "all", "line": "life", "paths": []},
        {"name": "annuity schema", "line": "annuity", "paths": [["INS", "ANNUITY"]]},
    ]
    assert from_defaults("INS.ANNUITY.CONTRACT", defaults, VOCAB).lines == {"annuity"}  # type: ignore[union-attr]
    assert from_defaults("INS.POLICY.POLICY", defaults, VOCAB).lines == {"life"}  # type: ignore[union-attr]
    assert from_defaults("INS.POLICY.POLICY", [], VOCAB) is None


def test_columns_by_name_or_accepted_link_and_their_values():
    linked = uuid4()
    fields = [{"id": uuid4(), "name": "LINE_OF_BUSINESS"}, {"id": linked, "name": "BIZ_SEGMENT"}, {"id": uuid4(), "name": "PRODUCT_TYPE"}]
    assert line_columns(fields, VOCAB, {linked}) == ["LINE_OF_BUSINESS", "BIZ_SEGMENT"]
    ev, unknown = from_values("LINE_OF_BUSINESS", ["LIFE", "ANNUITY", "PENSION"], VOCAB)
    assert ev is not None and ev.lines == {"life", "annuity"} and unknown == ["PENSION"]


def test_inheritance_follows_references_nearest_first():
    product, version, policy, claim, party = (uuid4() for _ in range(5))
    direct = {product: LineEvidence({"life", "annuity"}, "values", "values of LINE_OF_BUSINESS")}
    parents = {version: [product], policy: [version, party], claim: [policy], party: []}
    names = {product: "PRODUCT.PRODUCT", version: "PRODUCT.PRODUCT_VERSION", policy: "POLICY.POLICY", claim: "CLAIMS.CLAIM", party: "PARTY.PARTY"}
    got = inherit(direct, parents, names)
    assert set(got) == {version, policy, claim}  # the party table references nothing with a line: shared
    assert got[claim].lines == {"life", "annuity"} and got[claim].source == "inherited"
    assert got[claim].evidence == "inherited via POLICY.POLICY → PRODUCT.PRODUCT_VERSION → PRODUCT.PRODUCT"
    assert inherit(direct, parents, names, max_hops=2).keys() == {version, policy}


class FakeLines:
    def __init__(self, inputs: dict[str, Any], defaults: list[dict[str, Any]]) -> None:
        self._inputs, self._defaults = inputs, defaults
        self.stored: dict[UUID, LineEvidence] = {}

    async def vocabulary(self) -> LineVocabulary:
        return VOCAB

    async def inputs(self, source_system: str) -> dict[str, Any]:
        return self._inputs

    async def pipeline_defaults(self, source_system: str) -> list[dict[str, Any]]:
        return self._defaults

    async def replace(self, source_system: str, lines: dict[UUID, LineEvidence]) -> int:
        self.stored = lines
        return len(lines)


class FakeConnector:
    def __init__(self) -> None:
        self.queries: list[tuple[str, str]] = []

    async def distinct_values(self, fqn: str, column: str, *, limit: int = 50) -> list[str] | None:
        self.queries.append((fqn, column))
        return ["LIFE", "ANNUITY"]


def test_the_sync_step_applies_tags_then_defaults_then_values_then_inheritance():
    tagged, product, policy, party = (uuid4() for _ in range(4))
    assets = [
        {"id": tagged, "fqn": "INS.ANALYTICS.ANNUITY_KPI", "tags": ["LINE_OF_BUSINESS=ANNUITY"]},
        {"id": product, "fqn": "INS.PRODUCT.PRODUCT", "tags": []},
        {"id": policy, "fqn": "INS.POLICY.POLICY", "tags": []},
        {"id": party, "fqn": "INS.PARTY.PARTY", "tags": []},
    ]
    fields = [
        {"id": uuid4(), "asset_id": tagged, "name": "LINE_OF_BUSINESS", "tags": []},
        {"id": uuid4(), "asset_id": product, "name": "LINE_OF_BUSINESS", "tags": []},
    ]
    repo = FakeLines({"assets": assets, "fields": fields, "edges": [(policy, product)], "linked": set()}, [])
    connector = FakeConnector()
    summary = asyncio.run(PipelineService._decide_lines(SimpleNamespace(_lines=repo), connector, "snowflake"))  # type: ignore[arg-type]
    assert connector.queries == [("INS.PRODUCT.PRODUCT", "LINE_OF_BUSINESS")]  # the tagged table is never queried
    assert repo.stored[tagged].lines == {"annuity"} and repo.stored[product].source == "values"
    assert repo.stored[policy].lines == {"life", "annuity"} and party not in repo.stored
    assert summary == "Line of business: 3 of 4 datasets (1 from tags, 0 from a pipeline default, 1 from column values, 1 inherited), 1 shared across lines"
