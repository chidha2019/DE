import uuid

from ech_core import ids


def test_document_id_is_deterministic_and_case_insensitive_on_system():
    a = ids.document_id("confluence", "123456")
    b = ids.document_id("Confluence", " 123456 ")
    assert a == b
    assert a != ids.document_id("github", "123456")
    assert isinstance(a, uuid.UUID) and a.version == 5


def test_chunk_id_depends_on_document_and_index():
    doc = ids.document_id("github", "org/repo:README.md")
    assert ids.chunk_id(doc, 0) != ids.chunk_id(doc, 1)
    assert ids.chunk_id(doc, 3) == ids.chunk_id(doc, 3)


def test_entity_key_normalises_name():
    assert ids.entity_key("Project", "  Atlas   Platform ") == "Project:atlas platform"
    assert ids.entity_key("Person", "Chloé Dubois") == ids.entity_key("Person", "CHLOÉ DUBOIS")
    assert ids.normalize_entity_name("(Kubernetes)") == "kubernetes"
