import uuid

from ech_core.domain.models import ScoredChunk
from query_service.retrieval.fusion import reciprocal_rank_fusion


def _hits(*ids, doc=None):
    doc = doc or uuid.uuid4()
    return [
        ScoredChunk(chunk_id=i, document_id=doc, score=1.0 - n * 0.1) for n, i in enumerate(ids)
    ]


def test_rrf_prefers_chunks_present_in_both_legs():
    a, b, c, d = (uuid.uuid4() for _ in range(4))
    fused = reciprocal_rank_fusion({"vector": _hits(a, b, c), "keyword": _hits(d, b, a)}, k=60)
    order = [x.chunk_id for x in fused]
    assert set(order[:2]) == {a, b}, "a and b appear in both legs and must rank first"
    assert fused[0].fused_norm == 1.0
    both = next(x for x in fused if x.chunk_id == b)
    assert both.paths == {"vector", "keyword"}
    assert both.vector_rank == 2 and both.keyword_rank == 2
    only_vec = next(x for x in fused if x.chunk_id == c)
    assert only_vec.paths == {"vector"} and only_vec.keyword_score is None


def test_weights_shift_the_balance():
    a, b = uuid.uuid4(), uuid.uuid4()
    legs = {"vector": _hits(a, b), "keyword": _hits(b, a)}
    vec_heavy = reciprocal_rank_fusion(legs, weights={"vector": 2.0, "keyword": 0.5})
    kw_heavy = reciprocal_rank_fusion(legs, weights={"vector": 0.5, "keyword": 2.0})
    assert vec_heavy[0].chunk_id == a
    assert kw_heavy[0].chunk_id == b


def test_empty_input():
    assert reciprocal_rank_fusion({}) == []
    assert reciprocal_rank_fusion({"vector": [], "keyword": []}) == []
