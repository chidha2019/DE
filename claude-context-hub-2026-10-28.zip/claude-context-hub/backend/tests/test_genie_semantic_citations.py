"""Genie cites semantic_search / describe_asset results as [S#] sources."""

from __future__ import annotations

from uuid import UUID

from test_genie import SPACE_ID, ScriptedModel, make_service, text, tool_use, turn

from ech_core.schemas.genie import GenieAskRequest
from query_service.genie.tools import SourceRegistry
from query_service.services.semantic_service import SemanticSource

FACT_ID = UUID("66f7f7b5-6ca6-594a-9228-bc2cdec28dcd")
DIM_ID = UUID("f74b2a7f-1111-5222-8333-444455556666")
FACT_FQN = "lake.gold.fact_claim_payment"
DIM_FQN = "lake.gold.dim_policy"


class FakeSemanticService:
    """Mimics SemanticService.search_for_genie / describe_for_genie with the cite callback."""

    def __init__(self) -> None:
        self.calls: list[tuple[str, str]] = []

    async def search_for_genie(self, query, *, limit=10, cite=None):
        self.calls.append(("search", query))
        fact = cite(
            SemanticSource(FACT_ID, FACT_FQN, "databricks", "https://dbx/explore/fact", "payments")
        )
        dim = cite(SemanticSource(DIM_ID, DIM_FQN, "databricks", None, "policies"))
        return (
            "assets:\n"
            f"  [{fact}] {FACT_FQN} (table, fact, 5 columns, 2 metrics): payments\n"
            f"  [{dim}] {DIM_FQN} (table, dimension, 3 columns, 0 metrics): policies\n"
            "columns:\n"
            f"  [{fact}] {FACT_FQN}.policy_id (string, identifier)"
        )

    async def describe_for_genie(self, name, *, max_fields=80, cite=None):
        self.calls.append(("describe", name))
        if name != FACT_FQN:
            return None
        # The same asset registers the same marker again.
        fact = cite(
            SemanticSource(FACT_ID, FACT_FQN, "databricks", "https://dbx/explore/fact", "payments")
        )
        return (
            f"[{fact}] {FACT_FQN}  (table, fact, databricks)\n"
            "columns (name | type | role | key | description):\n"
            "  policy_id | string | identifier | | \n"
            "relationships:\n"
            f"  foreign_key -> {DIM_FQN} on policy_id -> policy_id (confidence 1.00)"
        )


def test_registry_keys_assets_by_id_and_keeps_kind():
    sources = SourceRegistry()
    first = sources.register(
        chunk_id=FACT_ID,
        document_id=FACT_ID,
        title=FACT_FQN,
        path=FACT_FQN,
        source_system="databricks",
        uri=None,
        score=1.0,
        chunk_index=0,
        snippet="",
        kind="asset",
    )
    again = sources.register(
        chunk_id=FACT_ID,
        document_id=FACT_ID,
        title=FACT_FQN,
        path=FACT_FQN,
        source_system="databricks",
        uri=None,
        score=1.0,
        chunk_index=0,
        snippet="",
        kind="asset",
    )
    assert first.marker == "S1" and again is first and first.kind == "asset"
    # A conversation restored from persisted citations keeps the asset kind and numbering.
    restored = SourceRegistry([first.model_dump(mode="json")])
    assert restored.get("S1").kind == "asset" and len(restored) == 1


async def test_semantic_tools_label_assets_and_answers_cite_them():
    model = ScriptedModel(
        [
            turn(tool_use("t1", "semantic_search", query="claim payments policy", limit=10)),
            turn(
                {
                    "type": "tool_use",
                    "id": "t2",
                    "name": "describe_asset",
                    "input": {"name": FACT_FQN},
                }
            ),
            turn(
                text(
                    f"Payments live in `{FACT_FQN}` [S1] and join to policies on policy_id [S1][S2]; "
                    "the graph says nothing more [S7].\n\n"
                    'FOLLOW_UPS: ["Which metrics are declared on it?"]'
                ),
                stop="end_turn",
            ),
        ]
    )
    semantic = FakeSemanticService()
    service, repo, engine, graph_db = make_service(model, semantic=semantic)
    events = [
        e
        async for e in service.ask(
            SPACE_ID, GenieAskRequest(question="Where are claim payments and how do they join?")
        )
    ]
    message = events[-1][1]

    assert message["status"] == "complete"
    assert message["content"] == (
        f"Payments live in `{FACT_FQN}` [S1] and join to policies on policy_id [S1][S2]; "
        "the graph says nothing more ."
    ), "asset markers resolve, the invented one is dropped"
    citations = {c["marker"]: c for c in message["citations"]}
    assert set(citations) == {"S1", "S2"}
    fact = citations["S1"]
    assert fact["kind"] == "asset" and fact["title"] == FACT_FQN and fact["path"] == FACT_FQN
    assert fact["document_id"] == str(FACT_ID) and fact["chunk_id"] == str(FACT_ID)
    assert fact["source_system"] == "databricks" and fact["uri"] == "https://dbx/explore/fact"
    assert citations["S2"]["title"] == DIM_FQN and citations["S2"]["uri"] is None
    assert semantic.calls == [
        ("search", "claim payments policy"),
        ("describe", FACT_FQN),
    ]

    # The tool results the model saw carried the labels it cited, with S1 reused by describe_asset.
    _, sent = model.requests[2]
    tool_results = [
        r for turn_ in sent if isinstance(turn_["content"], list) for r in turn_["content"]
    ]
    contents = [r.get("content", "") for r in tool_results if r.get("type") == "tool_result"]
    assert any(f"[S1] {FACT_FQN} (table, fact" in c for c in contents)
    assert any(c.startswith(f"[S1] {FACT_FQN}  (table, fact, databricks)") for c in contents)
    assert not engine.requests and not graph_db.queries
