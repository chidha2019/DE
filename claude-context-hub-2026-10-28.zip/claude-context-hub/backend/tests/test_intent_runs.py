"""Running an approved pipeline in the hub, and reading a KAN-3 style ticket (table pattern, existing stage)."""

from __future__ import annotations

import asyncio
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from ech_core.schemas.intents import (
    IntentDecision,
    IntentSource,
    IntentTarget,
    PipelineRun,
    PipelineSpec,
    StructuredIntent,
)
from query_service.intents.parser import _merge, rule_parse
from query_service.intents.runner import PipelineRunner, mask, missing_settings, runtime_env
from query_service.intents.tableset import SourceFile, own_identifier, pattern_name
from tests.test_intents import FakeGlossary, FakeJira, FakeRepo, _planner

TICKET = """## Source

15 CSV files, comma-delimited with a header row, encoded Windows-1250, in one folder: `C:\\Users\\me\\projects\\DE-main\\csv`

Landing: Azure Blob Storage, storage account `acmestore`, container named `iceberg-container`, folder `bronze`
(azure://acmestore.blob.core.windows.net/iceberg-container/bronze/). Snowflake reads it through the existing stage
LIFE_DB.BRONZE.AZURE_BRONZE_STAGE and the storage integration that stage already uses, with file format
LIFE_DB.BRONZE.FF_CSV_HEADER (Windows-1250, header row parsed).

## Target

* Snowflake database LIFE_DB, schema BRONZE: one Snowflake-managed Iceberg table per file on external volume ECH_AZURE_ICEBERG_VOL.
* Table names: `<FILE>_ICEBERG` (city.csv → LIFE_DB.BRONZE.CITY_ICEBERG).
"""


# --------------------------------------------------------------------------- the ticket
def test_rules_read_the_table_pattern_the_stage_and_the_whole_folder():
    intent = rule_parse("Bronze: load the CSV files through Azure Blob Storage into Iceberg tables", TICKET)
    assert intent.source.folder == "C:\\Users\\me\\projects\\DE-main\\csv"
    assert intent.source.stage == "LIFE_DB.BRONZE.AZURE_BRONZE_STAGE"
    assert intent.source.file_format == "LIFE_DB.BRONZE.FF_CSV_HEADER"
    assert (intent.target.database, intent.target.schema_name, intent.target.table) == ("LIFE_DB", "BRONZE", None)
    assert intent.target.table_pattern == "<FILE>_ICEBERG"
    assert intent.target.external_volume == "ECH_AZURE_ICEBERG_VOL"
    assert not any("table should the data land" in q for q in intent.open_questions)


def test_a_model_that_keeps_the_folder_tail_or_reads_the_stage_as_the_table_is_corrected():
    rules = rule_parse("Bronze load", TICKET)
    model = StructuredIntent(
        kind="ingest_csv_to_iceberg",
        source=IntentSource(folder="csv", storage_provider="azure"),
        target=IntentTarget(database="LIFE_DB", schema="BRONZE", table="AZURE_BRONZE_STAGE"),
    )
    merged = _merge(rules, model)
    assert merged.source.folder == rules.source.folder
    assert merged.target.table is None and merged.target.table_pattern == "<FILE>_ICEBERG"
    assert merged.source.stage == "LIFE_DB.BRONZE.AZURE_BRONZE_STAGE"


def test_questions_the_planner_answers_itself_are_never_asked():
    from query_service.intents.service import _settled
    from query_service.intents.validate import Expectation

    bare = Expectation()
    assert _settled("What BASE_LOCATION (path on ECH_AZURE_ICEBERG_VOL) should each Iceberg table use, e.g. one per table name?", bare)
    assert _settled("What cron schedule should the task run on?", bare)
    assert _settled("Which storage integration does LIFE_DB.BRONZE.AZURE_BRONZE_STAGE use?", Expectation(stage="LIFE_DB.BRONZE.AZURE_BRONZE_STAGE"))
    assert not _settled("Which storage integration does the stage use?", bare)
    assert not _settled("Which Azure storage account and container do the files land in?", bare)


def test_pattern_names_and_own_identifiers():
    assert pattern_name("<FILE>_ICEBERG", "claimStatus") == "CLAIMSTATUS_ICEBERG"
    assert pattern_name("RAW_<FILE>", "house-nr") == "RAW_HOUSE_NR"
    f = SourceFile(path=Path("houseNr.csv"), rel="houseNr.csv", system="", header=["houseNr_id", "houseNr_nr"])
    assert own_identifier(f) == "houseNr_id"
    assert own_identifier(SourceFile(path=Path("a.csv"), rel="a.csv", system="", header=["x", "y"])) is None


# --------------------------------------------------------------------------- the ticket's stage
def test_validation_looks_up_the_named_stage():
    from query_service.intents.validate import Expectation, validate
    from tests.test_intent_routes import FakeSnowflake

    expect = Expectation(target_database="LIFE_DB", target_schema="BRONZE", target_tables=["CITY_ICEBERG"], stage="LIFE_DB.BRONZE.AZURE_BRONZE_STAGE")
    with_stage = FakeSnowflake({"LIFE_DB.BRONZE.CITY_ICEBERG": ["CITY_ID"]}, stages={"LIFE_DB.BRONZE.AZURE_BRONZE_STAGE": "azure://acme.blob.core.windows.net/c/bronze/"})
    found = asyncio.run(validate(with_stage, expect)).find("stage", "LIFE_DB.BRONZE.AZURE_BRONZE_STAGE")
    assert found is not None and found.exists and "azure://acme" in found.detail and "AZ_INT" in found.detail
    # the schema was dropped and recreated: nothing in it is visible, and the stage is reported gone, not as an error
    gone = asyncio.run(validate(FakeSnowflake({"LIFE_DB.OTHER.X": ["A"]}), expect))
    stage = gone.find("stage", "LIFE_DB.BRONZE.AZURE_BRONZE_STAGE")
    assert gone.reachable and stage is not None and stage.exists is False and "not visible" in stage.detail
    assert "stage LIFE_DB.BRONZE.AZURE_BRONZE_STAGE is missing" in gone.summary


def test_a_missing_stage_makes_the_plan_create_its_own(tmp_path: Path):
    from ech_core.schemas.intents import IntentValidation, ValidatedObject
    from query_service.intents import generator

    root = tmp_path / "data" / "csv"
    root.mkdir(parents=True)
    (root / "branch.csv").write_text("branch_id,branch_name,city_id\n1,Centrum,1\n", encoding="utf-8")
    (root / "city.csv").write_text("city_id,city_name\n1,Lodz\n", encoding="utf-8")
    intent = rule_parse("Bronze: load the CSV files", TICKET)
    planner = _planner(tmp_path)

    def validation(exists: bool) -> IntentValidation:
        obj = ValidatedObject(
            kind="stage",
            name="LIFE_DB.BRONZE.AZURE_BRONZE_STAGE",
            role="prerequisite",
            exists=exists,
            detail="reads azure://acme/c/bronze/ through AZ_INT" if exists else "schema LIFE_DB.BRONZE does not exist or is not visible to the hub's role",
        )
        return IntentValidation(checked_at=datetime.now(tz=UTC), reachable=True, objects=[obj])

    kept = asyncio.run(planner.plan(intent, "Bronze load", validation(True)))
    assert kept.source.stage == "LIFE_DB.BRONZE.AZURE_BRONZE_STAGE" and kept.stage_name == "LIFE_DB.BRONZE.AZURE_BRONZE_STAGE"
    assert "CREATE STAGE" not in generator.generate(kept)["sql/010_setup.sql"]
    assert any("through AZ_INT" in a for a in kept.assumptions)
    gone = asyncio.run(planner.plan(intent, "Bronze load", validation(False)))
    assert gone.source.stage is None and gone.stage_name == "BRONZE_LANDING_STAGE"
    assert any("AZURE_BRONZE_STAGE is not in Snowflake" in r for r in gone.risks)
    setup = generator.generate(gone)["sql/010_setup.sql"]
    assert "CREATE STAGE IF NOT EXISTS LIFE_DB.BRONZE.BRONZE_LANDING_STAGE" in setup and "${STORAGE_INTEGRATION}" in setup
    assert "ECH_RUN_STORAGE_INTEGRATION" in missing_settings(gone, {"SNOWFLAKE_HOST": "h", "SNOWFLAKE_TOKEN": "t", "SNOWFLAKE_WAREHOUSE": "w"})


# --------------------------------------------------------------------------- the runner's environment
def _spec(**source: Any) -> PipelineSpec:
    return PipelineSpec(
        name="ingest_life_db_bronze",
        kind="ingest_csv_to_iceberg",
        summary="s",
        source=IntentSource(folder="DE-main/csv", storage_provider="azure", azure_account="acmestore", azure_container="iceberg-container", **source),
        target=IntentTarget(database="LIFE_DB", schema="BRONZE", external_volume="VOL"),
    )


def test_runtime_env_passes_only_the_allow_listed_names():
    env = runtime_env(
        {
            "PATH": "/usr/bin",
            "ECH_RUN_SNOWFLAKE_TOKEN": "pat-not-a-real-token",
            "ECH_RUN_SNOWFLAKE_HOST": "acct.snowflakecomputing.com",
            "ECH_RUN_STORAGE_INTEGRATION": "<name of the storage integration>",
            "ECH_SNOWFLAKE_TOKEN": "hub-token-not-real",
            "ECH_POSTGRES_PASSWORD": "not-a-real-password",
            "SNOWFLAKE_TOKEN": "plain-token-not-real",
        }
    )
    assert env["SNOWFLAKE_TOKEN"] == "pat-not-a-real-token" and env["SNOWFLAKE_HOST"] == "acct.snowflakecomputing.com"
    assert env["PATH"] == "/usr/bin"
    assert "STORAGE_INTEGRATION" not in env  # a placeholder from .env.example is not a value
    assert not any(k.startswith("ECH_") for k in env)
    assert "hub-token-not-real" not in env.values() and "not-a-real-password" not in env.values()


def test_missing_settings_follow_the_spec():
    bare = {"SNOWFLAKE_HOST": "h", "SNOWFLAKE_TOKEN": "t", "SNOWFLAKE_WAREHOUSE": "w"}
    # An existing stage reads through its own integration; the Azure upload still needs a connection string.
    assert missing_settings(_spec(stage="LIFE_DB.BRONZE.AZURE_BRONZE_STAGE"), bare) == ["ECH_RUN_AZURE_STORAGE_CONNECTION_STRING"]
    assert "ECH_RUN_STORAGE_INTEGRATION" in missing_settings(_spec(), bare)
    assert missing_settings(None, {}) == ["ECH_RUN_SNOWFLAKE_HOST", "ECH_RUN_SNOWFLAKE_TOKEN", "ECH_RUN_SNOWFLAKE_WAREHOUSE"]


def test_mask_hides_tokens_and_the_account_key():
    env = {"SNOWFLAKE_TOKEN": "pat-not-a-real-token", "AZURE_STORAGE_CONNECTION_STRING": "AccountName=a;AccountKey=bm90LWEta2V5LXZhbHVl;EndpointSuffix=x"}
    out = mask("token pat-not-a-real-token and key bm90LWEta2V5LXZhbHVl", env)
    assert "pat-not-a-real-token" not in out and "bm90LWEta2V5LXZhbHVl" not in out and out.count("•••") == 2


# --------------------------------------------------------------------------- the runner's steps
_FAKE_PIPELINE = '''import os, sys
command = sys.argv[1]
if command == "upload":
    print("uploaded branch.csv -> azure://acmestore.blob.core.windows.net/iceberg-container/bronze/branch.csv")
    print("uploaded city.csv -> azure://acmestore.blob.core.windows.net/iceberg-container/bronze/city.csv")
elif command == "apply":
    print("ok  CREATE FILE FORMAT IF NOT EXISTS LIFE_DB.BRONZE.BRONZE_CSV_FORMAT")
    print("ok  CREATE ICEBERG TABLE IF NOT EXISTS LIFE_DB.BRONZE.BRANCH_ICEBERG (")
elif command == "load":
    print("ok  COPY INTO LIFE_DB.BRONZE.BRANCH_ICEBERG")
    print("pass BRANCH_ICEBERG.row_count (0)")
    if os.environ.get("FAIL_CHECK"):
        print("FAIL BRANCH_ICEBERG.unique_branch_id (2)")
        print("token was " + os.environ["SNOWFLAKE_TOKEN"])
        sys.exit(1)
    print("pass BRANCH_ICEBERG.unique_branch_id (0)")
'''


def _fake_folder(tmp_path: Path) -> tuple[Path, Path]:
    folder = tmp_path / "pipelines" / "ingest_life_db_bronze"
    folder.mkdir(parents=True)
    (folder / "pipeline.py").write_text(_FAKE_PIPELINE, encoding="utf-8")
    data = tmp_path / "data" / "csv"
    data.mkdir(parents=True)
    return folder, data


def _source_env(**extra: str) -> dict[str, str]:
    env = {
        "PATH": "",
        "ECH_RUN_SNOWFLAKE_HOST": "h",
        "ECH_RUN_SNOWFLAKE_TOKEN": "pat-not-a-real-token",
        "ECH_RUN_SNOWFLAKE_WAREHOUSE": "w",
        "ECH_RUN_SNOWFLAKE_ROLE": "ACCOUNTADMIN",
        "ECH_RUN_AZURE_STORAGE_CONNECTION_STRING": "AccountName=a;AccountKey=bm90LWEta2V5LXZhbHVl",
    }
    return {**env, **extra}


def test_a_run_uploads_applies_loads_checks_and_refreshes_the_catalog(tmp_path: Path):
    folder, data = _fake_folder(tmp_path)
    runner = PipelineRunner(lambda: _source_env(), python=sys.executable)
    seen: list[str] = []

    async def progress(run: PipelineRun) -> None:
        seen.append(run.status)

    async def catalog() -> str:
        return "run-123"

    run = asyncio.run(
        runner.execute(_spec(stage="LIFE_DB.BRONZE.AZURE_BRONZE_STAGE"), folder, data, triggered_by="approval", progress=progress, catalog=catalog)
    )
    assert run.status == "succeeded", run.error
    assert run.files_uploaded == 2 and run.statements == 3
    assert [c.name for c in run.checks] == ["BRANCH_ICEBERG.row_count", "BRANCH_ICEBERG.unique_branch_id"] and all(c.passed for c in run.checks)
    assert [s.status for s in run.steps] == ["ok", "ok", "ok", "ok", "ok"]
    assert run.catalog_run_id == "run-123" and run.triggered_by == "approval"
    assert run.warnings and "ACCOUNTADMIN" in run.warnings[0]
    assert "running" in seen and seen[-1] == "succeeded"


def test_a_failed_check_stops_the_run_and_the_log_keeps_no_secret(tmp_path: Path):
    folder, data = _fake_folder(tmp_path)
    # FAIL_CHECK is not allow-listed, so set it through the subprocess environment the runner builds.
    runner = PipelineRunner(lambda: _source_env(), python=sys.executable)
    env = runner.env()
    runner.env = lambda: {**env, "FAIL_CHECK": "1"}  # type: ignore[method-assign]

    async def progress(run: PipelineRun) -> None:
        return None

    run = asyncio.run(runner.execute(_spec(stage="LIFE_DB.BRONZE.X"), folder, data, triggered_by="manual", progress=progress))
    assert run.status == "failed" and "1 check(s) failed: BRANCH_ICEBERG.unique_branch_id" in run.error
    load = next(s for s in run.steps if s.key == "load")
    assert load.status == "failed" and "pat-not-a-real-token" not in load.log and "•••" in load.log
    assert next(s for s in run.steps if s.key == "catalog").status == "skipped"


def test_preflight_names_what_is_missing_without_running_anything(tmp_path: Path):
    folder, data = _fake_folder(tmp_path)
    runner = PipelineRunner(lambda: {"PATH": ""}, python=sys.executable)

    async def progress(run: PipelineRun) -> None:
        return None

    run = asyncio.run(runner.execute(_spec(stage="LIFE_DB.BRONZE.X"), folder, data, triggered_by="manual", progress=progress))
    assert run.status == "failed" and run.steps[0].status == "failed"
    assert "ECH_RUN_SNOWFLAKE_TOKEN" in run.steps[0].detail and "ECH_RUN_AZURE_STORAGE_CONNECTION_STRING" in run.steps[0].detail
    assert all(s.status == "skipped" for s in run.steps[1:])


def test_a_refused_role_stops_the_run_before_any_upload(tmp_path: Path):
    folder, data = _fake_folder(tmp_path)
    tried: list[str] = []

    async def probe(env: dict[str, str]) -> str | None:
        tried.append(env["SNOWFLAKE_ROLE"])
        return f"Snowflake refused the pipeline's credentials: Role 'ACCOUNTADMIN' is not granted ({env['SNOWFLAKE_TOKEN']})"

    runner = PipelineRunner(lambda: _source_env(), python=sys.executable, probe=probe)

    async def progress(run: PipelineRun) -> None:
        return None

    run = asyncio.run(runner.execute(_spec(stage="LIFE_DB.BRONZE.X"), folder, data, triggered_by="approval", progress=progress))
    assert tried == ["ACCOUNTADMIN"]
    assert run.status == "failed" and run.steps[0].status == "failed" and "is not granted" in run.steps[0].detail
    assert "pat-not-a-real-token" not in run.steps[0].detail
    assert run.files_uploaded == 0 and all(s.status == "skipped" for s in run.steps[1:])


# --------------------------------------------------------------------------- approval runs the pipeline
class FakeRunner:
    def __init__(self, status: str = "succeeded") -> None:
        self.status = status
        self.calls: list[str] = []

    def role(self) -> str:
        return "LOADER"

    def missing(self, spec: PipelineSpec | None) -> list[str]:
        return []

    async def execute(self, spec, folder, data_folder, *, triggered_by, progress, catalog=None) -> PipelineRun:
        self.calls.append(triggered_by)
        run = PipelineRun(status=self.status, triggered_by=triggered_by, started_at=datetime.now(tz=UTC), files_uploaded=1, error="" if self.status == "succeeded" else "Load and check: boom")
        await progress(run)
        return run


def test_approval_generates_and_runs_then_the_intent_is_loaded(tmp_path: Path):
    from ech_core.schemas.intents import IntentCreate
    from query_service.intents.service import IntentService
    from tests.test_intents import TICKET as POLICY_TICKET
    from tests.test_intents import _csv_folder

    _csv_folder(tmp_path)
    runner = FakeRunner()
    jira = FakeJira([])
    service = IntentService(
        repo=FakeRepo(),  # type: ignore[arg-type]
        planner=_planner(tmp_path),
        model=None,
        glossary=FakeGlossary(),  # type: ignore[arg-type]
        workspace_dir=tmp_path / "pipelines",
        data_dir=tmp_path / "data",
        jira=jira,  # type: ignore[arg-type]
        run_tests=False,
        background_modeling=False,
        runner=runner,  # type: ignore[arg-type]
        autorun=True,
    )

    async def go():
        record = await service.create(IntentCreate(title="Ingest policy CSVs", text=POLICY_TICKET))
        assert record.status == "spec_proposed" and record.run_missing == []
        loaded = await service.decide(record.id, IntentDecision(decision="approve"))
        again = await service.run(record.id)
        done = await service.decide(record.id, IntentDecision(decision="done"))
        return loaded, again, done

    loaded, again, done = asyncio.run(go())
    assert loaded.status == "loaded" and loaded.run is not None and loaded.run.triggered_by == "approval"
    assert runner.calls == ["approval", "manual"] and again.status == "loaded"
    assert done.status == "done"
    assert service.config().run_enabled and service.config().autorun and service.config().run_role == "LOADER"


def test_a_failed_run_marks_the_intent_failed_and_it_can_run_again(tmp_path: Path):
    from ech_core.schemas.intents import IntentCreate
    from query_service.intents.service import IntentService
    from tests.test_intents import TICKET as POLICY_TICKET
    from tests.test_intents import _csv_folder

    _csv_folder(tmp_path)
    runner = FakeRunner(status="failed")
    service = IntentService(
        repo=FakeRepo(),  # type: ignore[arg-type]
        planner=_planner(tmp_path),
        model=None,
        glossary=FakeGlossary(),  # type: ignore[arg-type]
        workspace_dir=tmp_path / "pipelines",
        data_dir=tmp_path / "data",
        run_tests=False,
        background_modeling=False,
        runner=runner,  # type: ignore[arg-type]
        autorun=True,
    )

    async def go():
        record = await service.create(IntentCreate(title="Ingest policy CSVs", text=POLICY_TICKET))
        failed = await service.decide(record.id, IntentDecision(decision="approve"))
        runner.status = "succeeded"
        return failed, await service.run(record.id)

    failed, rerun = asyncio.run(go())
    assert failed.status == "failed" and failed.error == "Load and check: boom"
    assert rerun.status == "loaded"
