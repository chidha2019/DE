"""GitHubRepoConnector against an in-memory GitHub (httpx.MockTransport)."""

from __future__ import annotations

import json

import httpx
import pytest

from ech_core.domain.enums import EntityType
from ech_core.exceptions import ConnectorError
from ingestion_service.connectors.base import ConnectorOptions
from ingestion_service.connectors.github_live import GitHubRepoConnector, RepoSpec

FILES: dict[str, str] = {
    "README.md": "# omniclaim\n\nSee [operations](docs/OPERATIONS.md) and `pipeline/runner.py`.\n",
    "docs/OPERATIONS.md": "# Operations\n\nRun `python -m pipeline.cli` on Airflow. Back to [readme](../README.md).\n",
    "pipeline/__init__.py": "",
    "pipeline/cli.py": "import argparse\nfrom pipeline.runner import run\nimport pipeline.sql\n\n\ndef main():\n    run()\n",
    "pipeline/runner.py": "from pipeline import sql\n\n\ndef run():\n    return sql.load('sql/gold/fact.sql')\n",
    "pipeline/sql.py": "def load(path):\n    return open(path).read()\n",
    "sql/gold/fact.sql": "select 1 as one;\n",
    "requirements.lock": "x" * 5000,
    "big.py": "y" * 10_000,
    "image.png": "\x00binary",
}
TREE = [
    {"path": p, "type": "blob", "sha": f"sha-{i}", "size": len(c.encode())}
    for i, (p, c) in enumerate(FILES.items())
]


def make_connector(
    *, rate_limited: bool = False, max_file_bytes: int = 8_000
) -> tuple[GitHubRepoConnector, list[str]]:
    calls: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        calls.append(request.url.path)
        headers = {"x-ratelimit-remaining": "0" if rate_limited else "57"}
        if request.url.host == "api.test":
            if rate_limited:
                return httpx.Response(
                    403,
                    headers={**headers, "x-ratelimit-reset": "1700000000"},
                    json={"message": "rate"},
                )
            path = request.url.path
            if path == "/repos/acme/omniclaim":
                return httpx.Response(
                    200,
                    headers=headers,
                    json={
                        "default_branch": "main",
                        "description": "demo",
                        "pushed_at": "2026-10-24T14:13:14Z",
                        "created_at": "2026-01-01T00:00:00Z",
                    },
                )
            if path == "/repos/acme/omniclaim/git/trees/main":
                return httpx.Response(200, headers=headers, json={"tree": TREE, "truncated": False})
            if path == "/repos/acme/omniclaim/languages":
                return httpx.Response(200, headers=headers, json={"Python": 1000, "Dockerfile": 10})
            if path == "/repos/acme/omniclaim/contributors":
                return httpx.Response(
                    200, headers=headers, json=[{"login": "chidha2019"}, {"login": "octocat"}]
                )
            return httpx.Response(404, headers=headers, json={"message": "nope"})
        if request.url.host == "raw.test":
            file_path = request.url.path.split("/acme/omniclaim/main/", 1)[1]
            body = FILES.get(file_path)
            return (
                httpx.Response(
                    200,
                    content=body.encode("utf-8", "surrogateescape") if body is not None else b"",
                )
                if body is not None
                else httpx.Response(404)
            )
        return httpx.Response(500)

    client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    connector = GitHubRepoConnector(
        repos=["acme/omniclaim"],
        api_url="https://api.test",
        raw_url="https://raw.test",
        max_file_bytes=max_file_bytes,
        client=client,
    )
    return connector, calls


def test_repo_spec_parsing():
    assert RepoSpec.parse("acme/omniclaim") == RepoSpec("acme", "omniclaim")
    assert RepoSpec.parse("https://github.com/acme/omniclaim.git@dev") == RepoSpec(
        "acme", "omniclaim", "dev"
    )
    with pytest.raises(ValueError):
        RepoSpec.parse("not-a-repo")


@pytest.mark.asyncio
async def test_crawl_selects_text_files_and_links_them():
    connector, calls = make_connector()
    docs = [d async for d in connector.iter_documents(ConnectorOptions())]
    paths = {d.attributes["path"] for d in docs}
    assert paths == {
        "README.md",
        "docs/OPERATIONS.md",
        "pipeline/__init__.py",
        "pipeline/cli.py",
        "pipeline/runner.py",
        "pipeline/sql.py",
        "sql/gold/fact.sql",
    } - {"pipeline/__init__.py"}
    assert "requirements.lock" not in paths, "lock files are excluded by glob"
    assert "big.py" not in paths, "oversized files are skipped"
    assert "image.png" not in paths, "binary extensions are not included"

    by_path = {d.attributes["path"]: d for d in docs}
    readme = by_path["README.md"]
    assert readme.references == [
        "acme/omniclaim:docs/OPERATIONS.md",
        "acme/omniclaim:pipeline/runner.py",
    ]
    assert readme.mime_type == "text/markdown" and readme.content.startswith("# omniclaim")
    ops = by_path["docs/OPERATIONS.md"]
    assert ops.references == ["acme/omniclaim:README.md"], "relative '../' links resolve"
    cli = by_path["pipeline/cli.py"]
    assert set(cli.references) == {
        "acme/omniclaim:pipeline/runner.py",
        "acme/omniclaim:pipeline/sql.py",
    }
    assert cli.content.startswith("# omniclaim/pipeline/cli.py") and "```python" in cli.content
    runner = by_path["pipeline/runner.py"]
    assert "acme/omniclaim:sql/gold/fact.sql" in runner.references, "path-like tokens resolve"
    assert "acme/omniclaim:pipeline/__init__.py" in runner.references, (
        "'from pipeline import' hits the package"
    )

    assert {e.name for e in readme.explicit_entities if e.entity_type is EntityType.PROJECT} == {
        "Omniclaim"
    }
    assert {"Python", "Docker"} <= {
        e.name for e in readme.explicit_entities if e.entity_type is EntityType.TECHNOLOGY
    }
    assert "SQL" in {e.name for e in by_path["sql/gold/fact.sql"].explicit_entities}
    assert readme.contributors == ["chidha2019", "octocat"] and readme.author == "chidha2019"
    assert readme.uri == "https://github.com/acme/omniclaim/blob/main/README.md"
    assert readme.external_id == "acme/omniclaim:README.md"

    # metadata endpoints are hit once per snapshot; bodies come from the raw host
    api_calls = [c for c in calls if not c.startswith("/acme/")]
    assert api_calls.count("/repos/acme/omniclaim/git/trees/main") == 1


@pytest.mark.asyncio
async def test_health_estimate_and_limit_reuse_cached_metadata():
    connector, calls = make_connector()
    health = await connector.health_check()
    assert health.healthy and health.details["repositories"][0]["files"] == 6
    assert health.details["api_rate_limit_remaining"] == 57
    assert await connector.estimate_count(ConnectorOptions()) == 6
    assert await connector.estimate_count(ConnectorOptions(limit=2)) == 2
    assert len([c for c in calls if c.endswith("/git/trees/main")]) == 1, "snapshot cached"
    docs = [d async for d in connector.iter_documents(ConnectorOptions(limit=2))]
    assert len(docs) == 2
    assert connector.known_entities()[0].name == "Omniclaim"


@pytest.mark.asyncio
async def test_rate_limit_is_reported_as_connector_error():
    connector, _ = make_connector(rate_limited=True)
    health = await connector.health_check()
    assert not health.healthy
    assert "rate limit" in json.dumps(health.details)
    with pytest.raises(ConnectorError) as exc:
        _ = [d async for d in connector.iter_documents(ConnectorOptions())]
    assert exc.value.details.get("hint") == "set ECH_GITHUB_TOKEN"
