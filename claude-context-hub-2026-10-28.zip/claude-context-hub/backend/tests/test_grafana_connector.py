"""Grafana client, connector and SRE projection against an in-memory Grafana (httpx.MockTransport)."""

from __future__ import annotations

import asyncio
import json
from datetime import UTC, datetime

import httpx

from ech_core.config import Settings
from ech_core.domain.enums import EntityType
from ech_core.grafana_client import (
    GrafanaClient,
    merge_rule_states,
    metric_names,
    panel_queries,
    referenced_tables,
    references_of,
)
from ingestion_service.connectors.base import ConnectorOptions
from ingestion_service.connectors.grafana import (
    GrafanaConnector,
    alert_rule_document,
    dashboard_document,
)
from query_service.api.observability import _unconfigured, build_observability

BASE = "https://grafana.example"
TOKEN = "not-a-real-token"

DASHBOARD = {
    "dashboard": {
        "uid": "lapse",
        "title": "Lapse experience",
        "tags": ["actuarial", "life"],
        "description": "Lapse rate by study year and product line.",
        "version": 7,
        "panels": [
            {
                "id": 1,
                "type": "timeseries",
                "title": "Lapse rate",
                "datasource": {"type": "grafana-postgresql-datasource", "uid": "pg"},
                "targets": [
                    {
                        "refId": "A",
                        "rawSql": "SELECT study_year, avg(lapse_rate) FROM life_edw.actuarial.fct_lapse_experience f "
                        "JOIN life_edw.actuarial.dim_product p ON f.product_id = p.id GROUP BY 1",
                    }
                ],
            },
            {
                "id": 2,
                "type": "row",
                "title": "Service",
                "panels": [
                    {
                        "id": 3,
                        "type": "stat",
                        "title": "Requests",
                        "datasource": {"type": "prometheus"},
                        "targets": [{"refId": "A", "expr": 'sum(rate(ech_http_requests_total{service="query"}[5m])) by (route)'}],
                    }
                ],
            },
        ],
        "templating": {"list": [{"name": "product", "type": "query"}]},
    },
    "meta": {"folderTitle": "Actuarial", "url": "/d/lapse/lapse-experience", "updated": "2026-10-20T10:00:00Z", "created": "2026-01-01T00:00:00Z"},
}
SEARCH = [{"uid": "lapse", "title": "Lapse experience", "url": "/d/lapse/lapse-experience", "tags": ["actuarial", "life"], "folderTitle": "Actuarial", "type": "dash-db"}]
RULES = [
    {
        "uid": "r1",
        "title": "High lapse rate",
        "folderUID": "f1",
        "ruleGroup": "actuarial",
        "for": "5m",
        "labels": {"severity": "critical"},
        "annotations": {"summary": "Lapse rate above 8%", "runbook_url": "https://runbooks.example/lapse"},
        "updated": "2026-10-21T00:00:00Z",
        "data": [{"refId": "A", "datasourceUid": "pg", "model": {"rawSql": "select avg(lapse_rate) from life_edw.actuarial.fct_lapse_experience"}}],
    },
    {
        "uid": "r2",
        "title": "Query latency",
        "labels": {"severity": "warning"},
        "annotations": {},
        "data": [{"refId": "A", "model": {"expr": "histogram_quantile(0.95, sum(rate(ech_http_request_duration_seconds_bucket[5m])) by (le)) > 1.5", "datasource": {"type": "prometheus"}}}],
    },
]
STATES = {
    "status": "success",
    "data": {
        "groups": [
            {
                "name": "actuarial",
                "rules": [
                    {"uid": "r1", "name": "High lapse rate", "state": "firing", "health": "ok", "alerts": [{"state": "Alerting"}]},
                    {"name": "Query latency", "state": "inactive", "health": "ok", "alerts": []},
                ],
            }
        ]
    },
}


def fake_grafana(*, reject: bool = False) -> tuple[GrafanaClient, list[str]]:
    calls: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        calls.append(request.url.path)
        if reject or request.headers.get("authorization") != f"Bearer {TOKEN}":
            return httpx.Response(401, json={"message": "invalid token"})
        routes = {
            "/api/health": {"database": "ok", "version": "11.2.0"},
            "/api/org": {"id": 1, "name": "Acme"},
            "/api/search": SEARCH,
            "/api/dashboards/uid/lapse": DASHBOARD,
            "/api/v1/provisioning/alert-rules": RULES,
            "/api/prometheus/grafana/api/v1/rules": STATES,
        }
        body = routes.get(request.url.path)
        if body is None:
            return httpx.Response(404, json={"message": "not found"})
        return httpx.Response(200, content=json.dumps(body), headers={"content-type": "application/json"})

    http = httpx.AsyncClient(base_url=BASE, transport=httpx.MockTransport(handler), headers={"Authorization": f"Bearer {TOKEN}"})
    return GrafanaClient(BASE, TOKEN, client=http), calls


def test_panel_queries_and_references():
    queries = panel_queries(DASHBOARD["dashboard"])
    assert [(q.panel, q.kind, q.datasource) for q in queries] == [
        ("Lapse rate", "sql", "grafana-postgresql-datasource"),
        ("Requests", "promql", "prometheus"),
    ]
    tables, metrics = references_of(queries)
    assert tables == ["life_edw.actuarial.fct_lapse_experience", "life_edw.actuarial.dim_product"]
    assert metrics == ["ech_http_requests_total"]


def test_metric_names_drop_functions_labels_and_ranges():
    expr = "histogram_quantile(0.95, sum(rate(ech_http_request_duration_seconds_bucket[5m])) by (le)) > 1.5"
    assert metric_names(expr) == ["ech_http_request_duration_seconds_bucket"]
    assert referenced_tables("SELECT 1 FROM a.b JOIN c ON a.b.id = c.id join c") == ["a.b", "c"]


def test_merge_rule_states_matches_by_uid_then_title():
    merged = merge_rule_states(RULES, STATES["data"]["groups"])
    assert [(r["uid"], r["state"], r["active_alerts"], r["severity"]) for r in merged] == [("r1", "firing", 1, "critical"), ("r2", "inactive", 0, "warning")]
    assert merged[0]["summary"] == "Lapse rate above 8%"


def test_documents_carry_queries_tables_metrics_and_entities():
    doc = dashboard_document(BASE, DASHBOARD)
    assert doc.external_id == "dashboard:lapse"
    assert doc.uri == f"{BASE}/d/lapse/lapse-experience"
    assert doc.attributes["tables"] == ["life_edw.actuarial.fct_lapse_experience", "life_edw.actuarial.dim_product"]
    assert doc.attributes["metrics"] == ["ech_http_requests_total"]
    assert doc.attributes["panels"] == 1  # the row is layout, not a panel
    assert "## Tables referenced" in doc.content and "## Variables" in doc.content
    names = {(e.name, e.entity_type) for e in doc.explicit_entities}
    assert names >= {("Grafana", EntityType.TECHNOLOGY), ("PostgreSQL", EntityType.TECHNOLOGY), ("Prometheus", EntityType.TECHNOLOGY), ("Actuarial", EntityType.PROJECT)}
    assert doc.source_updated_at == datetime(2026, 10, 20, 10, 0, tzinfo=UTC)

    rule = merge_rule_states(RULES, STATES["data"]["groups"])[0]
    rule["url"] = f"{BASE}/alerting/grafana/r1/view"
    alert = alert_rule_document(rule)
    assert alert.external_id == "alert:r1"
    assert alert.title == "Alert: High lapse rate"
    assert alert.attributes["state"] == "firing"
    assert alert.attributes["severity"] == "critical"
    assert alert.attributes["tables"] == ["life_edw.actuarial.fct_lapse_experience"]
    assert "Runbook: https://runbooks.example/lapse" in alert.content


def test_connector_health_and_stream():
    client, calls = fake_grafana()
    connector = GrafanaConnector(BASE, TOKEN, client=client)

    async def run():
        health = await connector.health_check()
        docs = [d async for d in connector.iter_documents(ConnectorOptions())]
        one = [d async for d in connector.iter_documents(ConnectorOptions(limit=1))]
        estimate = await connector.estimate_count(ConnectorOptions())
        await connector.aclose()
        return health, docs, one, estimate

    health, docs, one, estimate = asyncio.run(run())
    assert health.healthy is True
    assert health.details == {"url": BASE, "version": "11.2.0", "org": "Acme", "dashboards": 1}
    assert [d.external_id for d in docs] == ["dashboard:lapse", "alert:r1", "alert:r2"]
    assert [d.external_id for d in one] == ["dashboard:lapse"]
    assert estimate == 3
    assert "/api/dashboards/uid/lapse" in calls
    assert connector.known_entities()[0].name == "Grafana"


def test_rejected_token_is_reported_not_raised():
    client, _ = fake_grafana(reject=True)
    connector = GrafanaConnector(BASE, "wrong-token", client=client)
    health = asyncio.run(connector.health_check())
    assert health.healthy is False
    assert "token rejected" in health.details["error"]


def test_observability_projection_sorts_firing_first():
    client, _ = fake_grafana()
    snapshot = asyncio.run(client.snapshot())
    report = build_observability(BASE, snapshot, documents=2, now=datetime(2026, 10, 26, tzinfo=UTC))
    assert (report.configured, report.healthy, report.org, report.version) == (True, True, "Acme", "11.2.0")
    assert (report.rules_total, report.firing, report.pending, report.documents) == (2, 1, 0, 2)
    assert [r.state for r in report.alert_rules] == ["firing", "inactive"]
    assert report.alert_rules[0].url == f"{BASE}/alerting/grafana/r1/view"
    assert report.dashboards[0].url == f"{BASE}/d/lapse/lapse-experience"
    assert report.dashboards[0].folder == "Actuarial"


def test_unconfigured_names_the_missing_settings(monkeypatch):
    for name in ("GRAFANA_URL", "GRAFANA_TOKEN", "ECH_GRAFANA_URL", "ECH_GRAFANA_TOKEN"):
        monkeypatch.delenv(name, raising=False)
    report = _unconfigured(Settings(_env_file=None), 0)
    assert report.configured is False
    assert "GRAFANA_URL" in (report.reason or "") and "GRAFANA_TOKEN" in (report.reason or "")
