"""Provider profiles of the real model client: first-party beta surface vs an Anthropic-compatible gateway."""

from __future__ import annotations

import copy
import os
from types import SimpleNamespace
from typing import Any

import pytest

from pipeline_agent.agent import (
    PROVIDERS,
    AgentConfig,
    AnthropicModelClient,
    ModelConfigError,
    detect_provider,
    resolve_base_url,
)
from pipeline_agent.tools import TOOLS

anthropic = pytest.importorskip("anthropic")
httpx2 = pytest.importorskip("httpx2")

HOST = "adb-123.azuredatabricks.net"
GATEWAY = f"https://{HOST}/ai-gateway/anthropic"
FIRST_PARTY = "https://api.anthropic.com"
MESSAGE = {
    "content": [{"type": "text", "text": "ok"}],
    "stop_reason": "end_turn",
    "usage": {"input_tokens": 1, "output_tokens": 1},
    "model": "system.ai.claude-opus-5-5",
}
ENV = (
    "ANTHROPIC_API_KEY",
    "ANTHROPIC_AUTH_TOKEN",
    "ANTHROPIC_BASE_URL",
    "DATABRICKS_HOST",
    "DATABRICKS_TOKEN",
)


class FakeStream:
    """Stands in for ``client.messages.stream(**kwargs)``; raises the scripted 400s first."""

    deltas: tuple[str, ...] = ()  # text events the stream emits before the final message

    def __init__(
        self, calls: list[dict[str, Any]], errors: list[str], kwargs: dict[str, Any]
    ) -> None:
        self.calls, self.errors, self.kwargs = calls, errors, kwargs

    def __aiter__(self) -> FakeStream:
        self._pending = list(self.deltas)
        return self

    async def __anext__(self) -> SimpleNamespace:
        if not self._pending:
            raise StopAsyncIteration
        return SimpleNamespace(type="text", text=self._pending.pop(0))

    async def __aenter__(self) -> FakeStream:
        self.calls.append(copy.deepcopy(self.kwargs))  # a snapshot: the retry mutates kwargs
        if self.errors:
            detail = self.errors.pop(0)
            response = httpx2.Response(
                400, request=httpx2.Request("POST", f"{GATEWAY}/v1/messages")
            )
            raise anthropic.BadRequestError(
                f"Error code: 400 - {detail}",
                response=response,
                body={"error": {"type": "invalid_request_error", "message": detail}},
            )
        return self

    async def __aexit__(self, *exc: object) -> bool:
        return False

    async def get_final_message(self) -> SimpleNamespace:
        return SimpleNamespace(to_dict=lambda: dict(MESSAGE))


class TalkingStream(FakeStream):
    """Emits text deltas, as the SDK does while the model writes, then the final message."""

    deltas = ("Hel", "lo", " there")

    async def get_final_message(self) -> SimpleNamespace:
        return SimpleNamespace(
            to_dict=lambda: {**MESSAGE, "content": [{"type": "text", "text": "Hello there"}]}
        )


class EmptyStream(FakeStream):
    """A 200 that is not an SSE Messages stream (portal page, wrong path): the SDK asserts."""

    response = SimpleNamespace(status_code=200, headers={"content-type": "text/html"})

    async def get_final_message(self) -> SimpleNamespace:
        raise AssertionError


def clear_env(monkeypatch: pytest.MonkeyPatch) -> None:
    for name in ENV:
        monkeypatch.delenv(name, raising=False)


def test_provider_detection_and_base_url_resolution(monkeypatch):
    clear_env(monkeypatch)
    assert detect_provider() == "anthropic"
    assert detect_provider(GATEWAY) == "databricks"
    assert detect_provider("https://proxy.example.com/serving-endpoints/anthropic") == "databricks"
    assert detect_provider(FIRST_PARTY) == "anthropic"
    monkeypatch.setenv("ANTHROPIC_BASE_URL", GATEWAY)
    assert detect_provider() == "databricks"
    monkeypatch.delenv("ANTHROPIC_BASE_URL")
    monkeypatch.setenv("DATABRICKS_HOST", HOST)
    assert detect_provider() == "anthropic", "a host without a token is not a Databricks setup"
    monkeypatch.setenv("DATABRICKS_TOKEN", "not-a-real-token")
    assert detect_provider() == "databricks"
    monkeypatch.setenv("ANTHROPIC_BASE_URL", FIRST_PARTY)
    assert detect_provider() == "databricks", "an inherited first-party base URL does not veto"
    monkeypatch.setenv("ANTHROPIC_API_KEY", "not-a-real-key")
    assert detect_provider() == "anthropic", "a first-party key wins when both are configured"
    monkeypatch.delenv("ANTHROPIC_API_KEY")

    databricks = PROVIDERS["databricks"]
    assert resolve_base_url(databricks, None) == GATEWAY, (
        "the host variable beats ANTHROPIC_BASE_URL"
    )
    monkeypatch.delenv("ANTHROPIC_BASE_URL")
    assert resolve_base_url(databricks, None) == GATEWAY, "a bare host gets the gateway path"
    assert resolve_base_url(databricks, f"https://{HOST}/") == GATEWAY
    legacy = f"https://{HOST}/serving-endpoints/anthropic"
    assert resolve_base_url(databricks, legacy) == legacy, "an explicit path is kept"
    monkeypatch.delenv("DATABRICKS_HOST")
    assert resolve_base_url(PROVIDERS["anthropic"], None) is None
    monkeypatch.setenv("ANTHROPIC_BASE_URL", FIRST_PARTY)
    assert resolve_base_url(databricks, None) is None, "an inherited first-party URL is no gateway"
    assert resolve_base_url(PROVIDERS["anthropic"], None) == FIRST_PARTY
    monkeypatch.setenv("ANTHROPIC_BASE_URL", GATEWAY)
    assert resolve_base_url(databricks, None) == GATEWAY, "a gateway ANTHROPIC_BASE_URL is honoured"


def test_gateway_profile_requires_host_and_its_own_token(monkeypatch):
    clear_env(monkeypatch)
    with pytest.raises(ModelConfigError, match="DATABRICKS_HOST"):
        AnthropicModelClient(AgentConfig(repo="acme/x", provider="databricks"))
    monkeypatch.setenv("DATABRICKS_HOST", HOST)
    monkeypatch.setenv("ANTHROPIC_AUTH_TOKEN", "first-party-session-token")
    with pytest.raises(ModelConfigError, match="DATABRICKS_TOKEN"):
        AnthropicModelClient(AgentConfig(repo="acme/x", provider="databricks"))
    with pytest.raises(ModelConfigError, match="unknown provider"):
        AnthropicModelClient(AgentConfig(repo="acme/x", provider="bedrock"))


async def test_gateway_profile_uses_ga_namespace_and_degrades_on_400(monkeypatch):
    clear_env(monkeypatch)
    monkeypatch.setenv("DATABRICKS_HOST", HOST)
    monkeypatch.setenv("DATABRICKS_TOKEN", "not-a-real-token")
    monkeypatch.setenv("ANTHROPIC_AUTH_TOKEN", "first-party-session-token")
    monkeypatch.setenv("ANTHROPIC_BASE_URL", FIRST_PARTY)
    client = AnthropicModelClient(
        AgentConfig(
            repo="acme/x", provider="databricks", model=PROVIDERS["databricks"].default_model
        )
    )
    assert str(client._client.base_url).rstrip("/") == GATEWAY
    assert client._client.auth_token == "not-a-real-token", (
        "the gateway token, not the inherited one"
    )
    assert client._client.api_key is None
    assert client.describe() == (
        f"system.ai.claude-opus-5-5 via databricks ({HOST}; credential: DATABRICKS_TOKEN)"
    )

    calls: list[dict[str, Any]] = []
    errors = ["tools.0.strict: extra inputs are not permitted"]
    monkeypatch.setattr(
        client._client.messages, "stream", lambda **kw: FakeStream(calls, errors, kw)
    )

    def no_beta(**kwargs: Any) -> None:
        raise AssertionError("a gateway profile must not use the beta namespace")

    monkeypatch.setattr(client._client.beta.messages, "stream", no_beta)

    turn = await client.complete(
        system="sys", tools=TOOLS, messages=[{"role": "user", "content": "hi"}]
    )
    assert turn.stop_reason == "end_turn" and turn.model == "system.ai.claude-opus-5-5"
    first, second = calls
    assert "betas" not in first and "fallbacks" not in first and "extra_body" not in first
    assert first["output_config"] == {"effort": "high"}
    assert all("eager_input_streaming" not in t for t in first["tools"])
    assert all(t["strict"] is True for t in first["tools"])
    assert all("strict" not in t for t in second["tools"])
    assert second["system"][0]["cache_control"] == {"type": "ephemeral"}, (
        "only the named field goes"
    )
    assert client.degraded == ["strict"]

    await client.complete(
        system="sys", tools=TOOLS, messages=[{"role": "user", "content": "again"}]
    )
    assert len(calls) == 3 and all("strict" not in t for t in calls[2]["tools"]), (
        "degradation sticks"
    )


async def test_unrelated_400_is_not_swallowed(monkeypatch):
    clear_env(monkeypatch)
    monkeypatch.setenv("DATABRICKS_HOST", HOST)
    monkeypatch.setenv("DATABRICKS_TOKEN", "not-a-real-token")
    client = AnthropicModelClient(AgentConfig(repo="acme/x", provider="databricks"))
    calls: list[dict[str, Any]] = []
    monkeypatch.setattr(
        client._client.messages,
        "stream",
        lambda **kw: FakeStream(calls, ["model system.ai.claude-opus-5-5 not found"], kw),
    )
    with pytest.raises(anthropic.BadRequestError):
        await client.complete(
            system="sys", tools=TOOLS, messages=[{"role": "user", "content": "hi"}]
        )
    assert len(calls) == 1 and client.degraded == []


async def test_first_party_profile_keeps_beta_surface(monkeypatch):
    clear_env(monkeypatch)
    monkeypatch.setenv("ANTHROPIC_API_KEY", "not-a-real-key")
    client = AnthropicModelClient(AgentConfig(repo="acme/x"))
    assert client.base_url is None
    assert client.describe() == (
        "claude-opus-5-5 via anthropic (api.anthropic.com; credential: ANTHROPIC_API_KEY)"
    )
    calls: list[dict[str, Any]] = []
    monkeypatch.setattr(
        client._client.beta.messages, "stream", lambda **kw: FakeStream(calls, [], kw)
    )
    await client.complete(system="sys", tools=TOOLS, messages=[{"role": "user", "content": "hi"}])
    (request,) = calls
    assert request["betas"] == ["server-side-fallback-2026-07-01"]
    assert request.get("fallbacks") == "default" or request["extra_body"] == {
        "fallbacks": "default"
    }
    assert all(t["strict"] is True and t["eager_input_streaming"] is True for t in request["tools"])
    assert request["system"][0]["cache_control"] == {"type": "ephemeral"}


async def test_non_sse_response_becomes_a_configuration_error(monkeypatch):
    clear_env(monkeypatch)
    monkeypatch.setenv("DATABRICKS_HOST", HOST)
    monkeypatch.setenv("DATABRICKS_TOKEN", "not-a-real-token")
    client = AnthropicModelClient(AgentConfig(repo="acme/x", provider="databricks"))
    monkeypatch.setattr(client._client.messages, "stream", lambda **kw: EmptyStream([], [], kw))
    with pytest.raises(ModelConfigError) as excinfo:
        await client.complete(
            system="sys", tools=TOOLS, messages=[{"role": "user", "content": "hi"}]
        )
    message = str(excinfo.value)
    assert "no Messages stream (HTTP 200, content-type text/html)" in message
    assert GATEWAY in message and "'system.ai.claude-opus-5-5'" in message


async def test_stream_yields_text_deltas_then_the_completed_turn(monkeypatch):
    clear_env(monkeypatch)
    monkeypatch.setenv("DATABRICKS_HOST", HOST)
    monkeypatch.setenv("DATABRICKS_TOKEN", "not-a-real-token")
    client = AnthropicModelClient(AgentConfig(repo="acme/x", provider="databricks"))
    monkeypatch.setattr(client._client.messages, "stream", lambda **kw: TalkingStream([], [], kw))
    events = [
        e
        async for e in client.stream(
            system="sys", tools=TOOLS, messages=[{"role": "user", "content": "hi"}]
        )
    ]
    assert [e.kind for e in events] == ["text", "text", "text", "message"]
    assert "".join(e.text for e in events[:-1]) == "Hello there"
    turn = events[-1].turn
    assert turn is not None and turn.text == "Hello there" and turn.tool_uses == []


def test_env_file_sets_keys_and_reports_only_names(tmp_path, monkeypatch):
    from pipeline_agent.cli import load_env_file

    monkeypatch.setenv("ECH_TEST_HOST", "stale")  # registers the keys for restoration
    monkeypatch.setenv("ECH_TEST_TOKEN", "stale")
    env_file = tmp_path / ".env.agent"
    env_file.write_text(
        "# agent credentials\n"
        "export ECH_TEST_HOST=https://adb-1.azuredatabricks.net/\n"
        "ECH_TEST_TOKEN='quoted value'\n"
        "malformed line without an equals sign\n"
        "=no-key\n",
        encoding="utf-8",
    )
    assert load_env_file(env_file) == ["ECH_TEST_HOST", "ECH_TEST_TOKEN"]
    assert os.environ["ECH_TEST_HOST"] == "https://adb-1.azuredatabricks.net/"
    assert os.environ["ECH_TEST_TOKEN"] == "quoted value"
