"""Pipeline schedules and scopes, and how each connector reads a scope and browses its schema."""

from __future__ import annotations

import time
from datetime import UTC, datetime, timedelta

import pytest
from pydantic import ValidationError

from ech_core.exceptions import ConnectorError
from ech_core.grafana_client import GrafanaSnapshot
from ech_core.schedule import describe, next_run_at
from ech_core.schemas.ingestion import ScopeItem, SourceOptions
from ech_core.schemas.pipelines import PipelineIn, Schedule
from ingestion_service.connectors.base import ConnectorOptions
from ingestion_service.connectors.databricks_uc import CatalogScope, DatabricksCatalogConnector
from ingestion_service.connectors.github_live import GitHubRepoConnector, _RepoSnapshot
from ingestion_service.connectors.grafana import ALERTS_KEY, GrafanaConnector
from ingestion_service.connectors.scope import path_prefix_match, plan_scope
from ingestion_service.connectors.snowflake import SnowflakeConnector

MONDAY_7AM = datetime(2026, 10, 26, 7, 0, tzinfo=UTC)


def item(*path: str) -> ScopeItem:
    return ScopeItem(path=list(path))


# ----------------------------------------------------------------------------- schedules
def test_schedule_validation_names_what_is_missing():
    with pytest.raises(ValidationError, match="every_minutes"):
        Schedule(type="interval")
    with pytest.raises(ValidationError, match="HH:MM"):
        Schedule(type="daily", time="25:00")
    with pytest.raises(ValidationError, match="days"):
        Schedule(type="weekly", time="06:30", days=[])
    with pytest.raises(ValidationError):
        Schedule(type="interval", every_minutes=1)
    assert Schedule(type="weekly", time="06:30", days=[3, 0, 0]).days == [0, 3]


def test_next_run_for_every_schedule_type():
    assert next_run_at(Schedule(), MONDAY_7AM) is None
    assert next_run_at(Schedule(type="interval", every_minutes=30), MONDAY_7AM) == MONDAY_7AM + timedelta(minutes=30)
    assert next_run_at(Schedule(type="daily", time="08:00"), MONDAY_7AM) == datetime(2026, 10, 26, 8, 0, tzinfo=UTC)
    assert next_run_at(Schedule(type="daily", time="06:30"), MONDAY_7AM) == datetime(2026, 10, 27, 6, 30, tzinfo=UTC)
    thursday = next_run_at(Schedule(type="weekly", time="06:30", days=[3]), MONDAY_7AM)
    assert thursday == datetime(2026, 10, 29, 6, 30, tzinfo=UTC) and thursday.weekday() == 3
    assert next_run_at(Schedule(type="weekly", time="06:30", days=[0]), MONDAY_7AM) == datetime(2026, 11, 2, 6, 30, tzinfo=UTC)
    assert next_run_at(Schedule(type="weekly", time="09:00", days=[0]), MONDAY_7AM) == datetime(2026, 10, 26, 9, 0, tzinfo=UTC)
    assert next_run_at(Schedule(type="daily", time="07:00"), MONDAY_7AM) == datetime(2026, 10, 27, 7, 0, tzinfo=UTC), "strictly after"


def test_schedule_labels_read_like_a_sentence():
    assert describe(Schedule()) == "Manual"
    assert [describe(Schedule(type="interval", every_minutes=m)) for m in (15, 60, 360, 1440, 2880)] == [
        "Every 15 minutes", "Every hour", "Every 6 hours", "Every day", "Every 2 days",
    ]
    assert describe(Schedule(type="daily", time="02:00")) == "Daily at 02:00 UTC"
    assert describe(Schedule(type="weekly", time="06:30", days=[0, 1, 2, 3, 4])) == "Weekdays at 06:30 UTC"
    assert describe(Schedule(type="weekly", time="06:30", days=[0])) == "Mondays at 06:30 UTC"
    assert describe(Schedule(type="weekly", time="06:30", days=[3, 0])) == "Mon, Thu at 06:30 UTC"


def test_pipeline_input_is_tidied():
    body = PipelineIn(name="  Policy   ingest ", connector="snowflake", tags=["Core", "core", " Daily "])
    assert body.name == "Policy ingest" and body.tags == ["core", "daily"]
    with pytest.raises(ValidationError):
        ScopeItem(path=["INSURANCE", " "])


# ----------------------------------------------------------------------------- scope planning
def test_a_wider_selection_absorbs_the_narrower_ones():
    plans = plan_scope(
        [item("insurance", "bronze", "policy"), item("insurance", "gold"), item("insurance", "gold", "x"), item("other")],
        root=str.upper,
    )
    assert list(plans) == ["INSURANCE", "OTHER"]
    assert plans["INSURANCE"].schemas == {"gold"} and plans["INSURANCE"].tables == {"bronze": {"policy"}}
    assert plans["OTHER"].whole
    whole = plan_scope([item("db", "s", "t"), item("db")], root=str.upper)["DB"]
    assert whole.whole and not whole.schemas and not whole.tables
    plan = plans["INSURANCE"]
    assert plan.allows("gold", "anything") and plan.allows("bronze", "policy") and not plan.allows("bronze", "claim")
    assert not plan.allows("silver")
    assert path_prefix_match(["repo", "docs", "a.md"], [["repo", "docs"]]) and not path_prefix_match(["repo", "src"], [["repo", "docs"]])


# ----------------------------------------------------------------------------- snowflake
class FakeSql:
    """Answers the first needle found in a statement; records every statement."""

    def __init__(self, answers: dict[str, list[dict]]) -> None:
        self.answers = answers
        self.statements: list[str] = []

    async def query(self, statement: str, *, database=None, schema=None) -> list[dict]:
        self.statements.append(statement)
        for needle, rows in self.answers.items():
            if needle in statement:
                return rows
        return []


def snowflake(sql: FakeSql, **kwargs) -> SnowflakeConnector:
    return SnowflakeConnector(sql=sql, account="acct", databases=["INSURANCE"], **kwargs)  # type: ignore[arg-type]


def test_snowflake_filters_the_selected_schemas_and_tables_in_sql():
    conn = snowflake(FakeSql({}), schemas=["INSURANCE.SILVER"])
    plan = plan_scope([item("insurance", "BRONZE"), item("insurance", "GOLD", "POLICY")], root=str.upper)["INSURANCE"]
    assert conn._scope_filter("INSURANCE", plan) == (
        " AND (TABLE_SCHEMA IN ('BRONZE') OR (TABLE_SCHEMA = 'GOLD' AND TABLE_NAME IN ('POLICY')))"
    )
    assert conn._scope_filter("INSURANCE", plan_scope([item("insurance")], root=str.upper)["INSURANCE"]) == ""
    assert conn._scope_filter("INSURANCE", None) == " AND TABLE_SCHEMA IN ('SILVER')", "no pipeline scope keeps the server scope"


@pytest.mark.asyncio
async def test_snowflake_estimate_and_read_follow_the_scope():
    table = {"table_schema": "BRONZE", "table_name": "POLICY", "table_type": "BASE TABLE", "comment": "Policies", "row_count": 10, "bytes": 100, "created": None, "last_altered": None, "table_owner": "ADMIN", "clustering_key": None}
    column = {"table_schema": "BRONZE", "table_name": "POLICY", "column_name": "POLICY_NO", "ordinal_position": 1, "data_type": "TEXT", "is_nullable": "NO", "comment": "", "numeric_precision": None, "numeric_scale": None}
    sql = FakeSql({"count(*)": [{"n": 7}], "INFORMATION_SCHEMA.COLUMNS": [column], "INFORMATION_SCHEMA.TABLES": [table]})
    conn = snowflake(sql)
    scoped = ConnectorOptions(scope=[item("insurance", "BRONZE")], source_options=SourceOptions(include_lineage=False, include_tags=False))
    assert await conn.estimate_count(scoped) == 7
    assert "TABLE_SCHEMA IN ('BRONZE')" in sql.statements[-1]
    docs = [d async for d in conn.iter_documents(scoped)]
    assert [d.external_id for d in docs] == ["INSURANCE.BRONZE.POLICY"]
    assert any("TABLE_SCHEMA IN ('BRONZE')" in s for s in sql.statements if "INFORMATION_SCHEMA.TABLES" in s and "ROW_COUNT" in s)
    assert not any("OBJECT_DEPENDENCIES" in s or "TAG_REFERENCES" in s for s in sql.statements), "the pipeline switched lineage and tags off"
    sql.statements.clear()
    [d async for d in conn.iter_documents(ConnectorOptions(scope=[item("insurance", "BRONZE")]))]
    assert any("OBJECT_DEPENDENCIES" in s for s in sql.statements), "unset options keep the server default"


@pytest.mark.asyncio
async def test_snowflake_browses_databases_schemas_tables_and_columns():
    sql = FakeSql(
        {
            "SHOW DATABASES": [{"name": "INSURANCE", "comment": "Core", "kind": "STANDARD"}],
            "GROUP BY TABLE_SCHEMA": [{"table_schema": "BRONZE", "n": 3}],
            "INFORMATION_SCHEMA.SCHEMATA": [{"schema_name": "BRONZE", "comment": "Raw"}, {"schema_name": "GOLD", "comment": ""}],
            "TABLE_SCHEMA = 'BRONZE' ORDER BY": [{"table_name": "POLICY", "table_type": "BASE TABLE", "row_count": 12, "comment": ""}],
            "INFORMATION_SCHEMA.COLUMNS": [
                {"column_name": "POLICY_NO", "ordinal_position": 1, "data_type": "TEXT", "is_nullable": "NO", "comment": ""},
                {"column_name": "PREMIUM", "ordinal_position": 2, "data_type": "NUMBER", "is_nullable": "YES", "comment": "", "numeric_precision": 12, "numeric_scale": 2},
            ],
        }
    )
    conn = snowflake(sql)
    root = await conn.discover([])
    assert [(n.name, n.kind, n.expandable, n.description) for n in root.nodes] == [("INSURANCE", "database", True, "Core")]
    schemas = await conn.discover(["INSURANCE"])
    assert [(n.name, n.child_count, n.path) for n in schemas.nodes] == [("BRONZE", 3, ["INSURANCE", "BRONZE"]), ("GOLD", 0, ["INSURANCE", "GOLD"])]
    tables = await conn.discover(["INSURANCE", "BRONZE"])
    assert [(n.name, n.kind, n.detail, n.row_count) for n in tables.nodes] == [("POLICY", "table", "Base Table", 12)]
    columns = await conn.discover(["INSURANCE", "BRONZE", "POLICY"])
    assert [(n.name, n.detail, n.selectable) for n in columns.nodes] == [("POLICY_NO", "TEXT not null", False), ("PREMIUM", "NUMBER(12,2)", False)]
    with pytest.raises(ConnectorError):
        await conn.discover(["INSURANCE", "BRONZE", "POLICY", "POLICY_NO"])
    assert any("TABLE_SCHEMA = 'BRONZE' AND TABLE_NAME = 'POLICY'" in s for s in sql.statements), "columns are read for exactly that table"


# ----------------------------------------------------------------------------- databricks
def databricks() -> DatabricksCatalogConnector:
    conn = DatabricksCatalogConnector(host="https://dbc.example", token="x", catalogs=["main"])
    data = {
        ("/api/2.1/unity-catalog/catalogs", None, None): [{"name": "main", "comment": "Prod", "catalog_type": "MANAGED_CATALOG"}, {"name": "system"}],
        ("/api/2.1/unity-catalog/schemas", "main", None): [{"name": "bronze"}, {"name": "silver"}, {"name": "information_schema"}],
        ("/api/2.1/unity-catalog/tables", "main", "bronze"): [{"name": "policy", "table_type": "MANAGED"}, {"name": "claim", "table_type": "VIEW"}],
        ("/api/2.1/unity-catalog/tables", "main", "silver"): [{"name": "fact", "table_type": "MANAGED"}],
    }

    async def paged(path, key, **params):
        return data.get((path, params.get("catalog_name"), params.get("schema_name")), [])

    async def get(path, **params):
        return {"columns": [{"name": "policy_no", "type_text": "string", "nullable": False}, {"name": "premium", "type_text": "decimal(12,2)"}]}

    conn._paged = paged  # type: ignore[method-assign]
    conn._get = get  # type: ignore[method-assign]
    return conn


@pytest.mark.asyncio
async def test_databricks_resolves_scope_to_schemas_and_tables():
    conn = databricks()
    scoped = ConnectorOptions(scope=[item("main", "bronze", "policy"), item("main", "silver")])
    targets = await conn._scoped(scoped)
    assert [t[0] for t in targets] == [CatalogScope("main", "bronze"), CatalogScope("main", "silver")]
    names = [[t["name"] for t in await conn._tables_in(scope, plan)] for scope, plan in targets]
    assert names == [["policy"], ["fact"]], "a table selection narrows its schema; a schema selection reads all of it"
    assert await conn.estimate_count(scoped) == 2
    whole = await conn._scoped(ConnectorOptions(scope=[item("MAIN")]))
    assert [s.schema for s, _ in whole] == ["bronze", "silver"], "system schemas are skipped"


@pytest.mark.asyncio
async def test_databricks_browses_catalogs_schemas_tables_and_columns():
    conn = databricks()
    assert [n.name for n in (await conn.discover([])).nodes] == ["main"]
    assert [n.name for n in (await conn.discover(["main"])).nodes] == ["bronze", "silver"]
    tables = (await conn.discover(["main", "bronze"])).nodes
    assert [(n.name, n.detail) for n in tables] == [("policy", "Managed"), ("claim", "View")]
    columns = (await conn.discover(["main", "bronze", "policy"])).nodes
    assert [(n.name, n.detail, n.selectable) for n in columns] == [("policy_no", "string not null", False), ("premium", "decimal(12,2)", False)]


# ----------------------------------------------------------------------------- github
def github() -> GitHubRepoConnector:
    conn = GitHubRepoConnector(repos=["acme/data"], token=None)
    paths = ["README.md", "docs/guide.md", "docs/api/spec.md", "src/app.py", "src/util.py", "logo.png"]
    blobs = [{"path": p, "size": 100, "type": "blob"} for p in paths]
    conn._snapshots["acme/data"] = _RepoSnapshot(
        spec=conn._specs[0], ref="main", meta={"description": "Data platform"}, blobs=blobs, languages={}, contributors=[], fetched_at=time.monotonic()
    )
    return conn


@pytest.mark.asyncio
async def test_github_browses_repositories_folders_and_files():
    conn = github()
    repos = (await conn.discover([])).nodes
    assert [(n.name, n.kind, n.child_count, n.description) for n in repos] == [("acme/data", "repo", 5, "Data platform")]
    top = (await conn.discover(["acme/data"])).nodes
    assert [(n.name, n.kind, n.child_count) for n in top] == [("docs", "folder", 2), ("src", "folder", 2), ("README.md", "file", None)]
    docs = (await conn.discover(["acme/data", "docs"])).nodes
    assert [(n.name, n.kind) for n in docs] == [("api", "folder"), ("guide.md", "file")]
    with pytest.raises(ConnectorError):
        await conn.discover(["other/repo"])


def test_github_reads_only_the_selected_folders_with_the_chosen_extensions():
    conn = github()
    blobs = conn._snapshots["acme/data"].blobs
    picked = conn._picked(ConnectorOptions(scope=[item("ACME/data", "docs")]))
    assert [(s.full_name, sub) for s, sub in picked] == [("acme/data", [["docs"]])]
    assert [b["path"] for b in conn._selected(blobs, ConnectorOptions(), picked[0][1])] == ["docs/api/spec.md", "docs/guide.md"]
    python_only = ConnectorOptions(scope=[item("acme/data", "src")], source_options=SourceOptions(include_extensions=["py"], exclude_globs=["src/util*"]))
    spec, sub = conn._picked(python_only)[0]
    assert [b["path"] for b in conn._selected(blobs, python_only, sub)] == ["src/app.py"]
    assert conn._picked(ConnectorOptions(scope=[item("acme/data")]))[0][1] is None, "a repository selection reads the whole repository"
    assert conn._picked(ConnectorOptions(scope=[item("elsewhere/repo")])) == []
    assert len(conn._selected(blobs)) == 5, "no options keeps the server defaults"


# ----------------------------------------------------------------------------- grafana
class FakeGrafana:
    base = "http://grafana"

    async def snapshot(self, *, max_dashboards: int = 500) -> GrafanaSnapshot:
        dashboards = [
            {"uid": "a1", "title": "Lapse experience", "folderTitle": "Actuarial", "tags": ["kpi"]},
            {"uid": "b2", "title": "Latency", "folderTitle": None},
        ]
        return GrafanaSnapshot(version="11", org="Main", dashboards=dashboards, rules=[{"uid": "r1", "title": "High errors"}])

    async def aclose(self) -> None:
        return None


@pytest.mark.asyncio
async def test_grafana_browses_folders_dashboards_and_alert_rules():
    conn = GrafanaConnector("http://grafana", None, client=FakeGrafana())  # type: ignore[arg-type]
    root = (await conn.discover([])).nodes
    assert [(n.name, n.kind, n.child_count) for n in root] == [("Actuarial", "folder", 1), ("General", "folder", 1), ("Alert rules", "alerts", 1)]
    assert root[-1].path == [ALERTS_KEY]
    inside = (await conn.discover(["Actuarial"])).nodes
    assert [(n.name, n.path, n.detail) for n in inside] == [("Lapse experience", ["Actuarial", "a1"], "kpi")]
    with pytest.raises(ConnectorError):
        await conn.discover([ALERTS_KEY])


@pytest.mark.asyncio
async def test_grafana_selects_folders_dashboards_and_alerts():
    conn = GrafanaConnector("http://grafana", None, client=FakeGrafana())  # type: ignore[arg-type]
    snap = await FakeGrafana().snapshot()

    def counts(**kw) -> tuple[int, int]:
        dashboards, rules = conn._select(snap, ConnectorOptions(**kw))
        return len(dashboards), len(rules)

    assert counts() == (2, 1), "no selection reads everything"
    assert counts(scope=[item("General")]) == (1, 0), "alert rules only come with the Alert rules node"
    assert counts(scope=[item("Actuarial", "a1"), item(ALERTS_KEY)]) == (1, 1)
    assert counts(scope=[item(ALERTS_KEY)]) == (0, 1)
    assert counts(source_options=SourceOptions(include_alert_rules=False)) == (2, 0)
    assert await conn.estimate_count(ConnectorOptions(scope=[item("Actuarial")])) == 1
