"""Connector catalogue: descriptors merged with registry, health, freshness and document counts."""

from __future__ import annotations

from datetime import UTC, datetime

from ech_core.schemas.ingestion import ConnectorInfo
from ingestion_service.connectors.catalog import CATEGORIES, DESCRIPTORS, describe_catalog


def test_every_descriptor_has_a_known_category_and_no_secret_values():
    keys = {c.key for c in CATEGORIES}
    for d in DESCRIPTORS:
        assert d.category in keys, d.key
        assert all(name.isupper() for name in d.env_vars), d.key
        assert d.capabilities, d.key
    assert len({d.key for d in DESCRIPTORS}) == len(DESCRIPTORS)


def test_availability_follows_registry_and_adapters():
    catalog = describe_catalog({"databricks"})
    by_key = {e.key: e for e in catalog.entries}
    assert by_key["databricks"].availability == "configured"
    assert by_key["snowflake"].availability == "available"  # adapter exists, nothing configured
    assert by_key["github-live"].availability == "available"
    assert by_key["manual"].availability == "configured"  # always on
    assert by_key["manual"].healthy is True
    assert by_key["grafana"].availability == "available"  # adapter landed, nothing configured
    assert by_key["tableau"].availability == "planned"
    assert by_key["tableau"].adapter is None
    assert catalog.total == len(DESCRIPTORS)
    assert catalog.configured + catalog.available + catalog.planned == catalog.total
    assert catalog.configured == 2


def test_live_state_is_merged_onto_configured_connectors():
    when = datetime(2026, 10, 25, 9, 30, tzinfo=UTC)
    info = ConnectorInfo(
        name="databricks",
        source_system="databricks",
        display_name="Databricks Unity Catalog",
        description="",
        healthy=True,
        details={"catalogs": 3},
        estimated_documents=96,
    )
    catalog = describe_catalog(
        {"databricks"},
        health={"databricks": info},
        freshness=[
            {"connector_name": "databricks", "source_system": "databricks", "last_success_at": when, "last_status": "completed", "runs": 4, "failed": 1, "documents_upserted": 384},
        ],
        documents_by_source={"databricks": 96, "confluence": 36},
        now=when,
    )
    by_key = {e.key: e for e in catalog.entries}
    db = by_key["databricks"]
    assert db.healthy is True
    assert db.health_details == {"catalogs": 3}
    assert db.estimated_documents == 96
    assert db.documents == 96
    assert db.last_success_at == when
    assert db.last_status == "completed"
    assert (db.runs_7d, db.failed_7d) == (4, 1)
    # A planned connector can still own documents from an earlier import.
    assert by_key["confluence"].documents == 36
    assert by_key["confluence"].availability == "planned"
    assert by_key["confluence"].healthy is None
    assert catalog.generated_at == when


def test_category_counts_cover_every_entry():
    catalog = describe_catalog(set())
    assert sum(c.count for c in catalog.categories) == catalog.total
    assert [c.key for c in catalog.categories] == [c.key for c in CATEGORIES]
