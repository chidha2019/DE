"""QA Engineer, Architect and SRE personas: reports, routes and the persona key."""

from __future__ import annotations

from contextlib import asynccontextmanager
from datetime import UTC, datetime, timedelta
from types import SimpleNamespace
from typing import Any
from uuid import uuid4

import pytest
from fastapi.testclient import TestClient

from ech_core.app_factory import create_app
from ech_core.config import KPI_TARGET_DEFAULTS, Settings
from ech_core.observability import LatencyRecorder
from ech_core.schemas.genie import GenieSpaceOut, GenieStatus
from ech_core.schemas.stats import AnalystReport, ArchitectureReport, PlatformReport, QualityReport
from query_service.api import api_router
from query_service.services.stats_service import StatsService

NOW = datetime.now(tz=UTC)
ASSET = uuid4()
RUN = uuid4()


# ----------------------------------------------------------------------------- fakes
class FakeRuns:
    async def kpi_rollup(self, *, days: int) -> dict[str, Any]:
        return {
            "completed": 9,
            "failed": 1,
            "cancelled": 0,
            "documents_seen": 500,
            "documents_upserted": 480,
            "documents_failed": 20,
            "graph_failed": 0,
            "avg_duration_s": 30.0,
            "busy_seconds": 300.0,
        }

    async def recent_failures(self, *, days: int, limit: int = 20) -> list[dict[str, Any]]:
        return [
            {
                "id": RUN,
                "connector_name": "databricks",
                "source_system": "databricks",
                "status": "failed",
                "error": "401 Unauthorized: token expired",
                "started_at": NOW - timedelta(hours=2),
                "finished_at": NOW - timedelta(hours=2, minutes=-1),
                "documents_failed": 20,
            }
        ]

    async def count_active(self) -> int:
        return 1

    async def count_stale_active(self, *, hours: int) -> int:
        return 2


class FakeDocuments:
    async def graph_sync_breakdown(self) -> dict[str, int]:
        return {"synced": 90, "pending": 3, "failed": 1}

    async def counts_by_source(self) -> dict[str, int]:
        return {"databricks": 96, "github": 40}

    async def counts_by_kind(self) -> dict[str, int]:
        return {"dataset": 96, "document": 40}

    async def count(self) -> int:
        return 136


class FakeAudit:
    def __init__(self) -> None:
        self.recent_calls: list[dict[str, Any]] = []

    async def request_rollup(self, *, hours: int) -> list[dict[str, Any]]:
        return [
            {
                "action": "context.retrieve",
                "requests": 200,
                "errors": 4,
                "p50_ms": 120.0,
                "p95_ms": 900.0,
                "p99_ms": 1400.0,
                "avg_ms": 200.0,
            },
            {
                "action": "genie.ask",
                "requests": 50,
                "errors": 1,
                "p50_ms": 3000.0,
                "p95_ms": 9000.0,
                "p99_ms": 12000.0,
                "avg_ms": 3500.0,
            },
        ]

    async def recent(
        self, *, limit: int = 50, action: str | None = None, status: str | None = None
    ) -> list[Any]:
        self.recent_calls.append({"limit": limit, "action": action, "status": status})
        return []

    async def rows_per_day(self, *, days: int) -> float:
        return 310.5


class FakeSemantic:
    async def coverage_kpis(self) -> dict[str, Any]:
        return {
            "assets": 96,
            "described": 57,
            "owned": 96,
            "facts": 35,
            "keyed_facts": 0,
            "connected": 90,
            "fields": 1100,
            "fields_described": 300,
            "joins_declared": 12,
            "joins_inferred": 78,
            "metrics": 189,
            "metrics_declared": 12,
            "fresh_24h": 96,
            "stale_7d": 0,
            "last_synced_at": NOW - timedelta(hours=3),
        }

    async def review_counts(self) -> dict[str, int]:
        return {"suggested": 38, "accepted": 58, "rejected": 0, "unclassified": 3, "assets": 96}

    async def review_queue(self, *, limit: int = 50) -> list[dict[str, Any]]:
        return [
            {
                "id": ASSET,
                "fqn": "life_edw.silver.beneficiary",
                "display_name": "Beneficiary",
                "kind": "fact",
                "enrichment": {
                    "status": "suggested",
                    "display_name": "Policy Beneficiary Designations",
                    "kind": "bridge",
                    "confidence": 0.68,
                    "metrics": [{"name": "x"}],
                    "generated_at": NOW.isoformat(),
                },
            },
            {
                # jsonb may come back as text when no codec is registered
                "id": uuid4(),
                "fqn": "customer360_demo.bronze.card_account",
                "display_name": None,
                "kind": "fact",
                "enrichment": '{"status": "suggested", "display_name": "Credit Card Accounts", '
                '"kind": "dimension", "confidence": "0.6", "metrics": []}',
            },
        ]

    async def overview(self) -> dict[str, Any]:
        return {
            "assets": 96,
            "by_kind": {"fact": 35, "dimension": 40, "metric": 10, "bridge": 6, "reference": 5},
            "by_asset_type": {"table": 80, "view": 8, "metric_view": 8},
            "by_role": {"identifier": 267, "measure": 84},
            "scopes": [{"platform": "databricks"} for _ in range(11)],
        }

    async def platform_summary(self) -> list[dict[str, Any]]:
        return [
            {
                "platform": "databricks",
                "databases": 3,
                "schemas": 11,
                "assets": 96,
                "metric_views": 8,
                "last_synced_at": NOW,
                "by_kind": {"fact": 35},
                "by_asset_type": {"table": 80},
            }
        ]

    async def relationship_kinds(self) -> dict[str, int]:
        return {"join_inferred": 78, "foreign_key": 12, "lineage_upstream": 60}

    async def metrics_by_source(self) -> dict[str, int]:
        return {"declared": 12, "curated": 95, "inferred": 82}

    async def shared_dimensions(self, *, limit: int = 12) -> list[dict[str, Any]]:
        return [
            {"id": ASSET, "fqn": "life_edw.silver.policy", "display_name": "Policies", "facts": 4}
        ]

    async def cross_platform_links(self) -> int:
        return 0


class FakePlatform:
    async def table_sizes(self) -> list[dict[str, Any]]:
        return [
            {"table": "embeddings", "rows": 5000, "bytes": 40_000_000},
            {"table": "chunks", "rows": 5000, "bytes": 9_000_000},
        ]

    async def database_bytes(self) -> int:
        return 120_000_000


class FakeGraph:
    def __init__(self, *, broken: bool = False) -> None:
        self.broken = broken

    async def stats(self) -> dict[str, Any]:
        if self.broken:
            raise RuntimeError("neo4j down")
        return {
            "nodes_total": 1200,
            "edges_total": 3400,
            "nodes_by_label": {"Document": 136},
            "edges_by_type": {"HAS_CHUNK": 5000},
            "density": 0.01,
        }


class FakeEmbeddings:
    async def count(self) -> int:
        return 5000


def _service(*, graph_broken: bool = False, audit: FakeAudit | None = None) -> StatsService:
    return StatsService(
        documents=FakeDocuments(),  # type: ignore[arg-type]
        chunks=SimpleNamespace(),  # type: ignore[arg-type]
        embeddings=FakeEmbeddings(),  # type: ignore[arg-type]
        runs=FakeRuns(),  # type: ignore[arg-type]
        audit=audit or FakeAudit(),  # type: ignore[arg-type]
        graph=FakeGraph(broken=graph_broken),  # type: ignore[arg-type]
        embedder=SimpleNamespace(model_id="hashing-64", dimensions=64),  # type: ignore[arg-type]
        latency=LatencyRecorder(100),
        semantic=FakeSemantic(),  # type: ignore[arg-type]
        platform=FakePlatform(),  # type: ignore[arg-type]
        kpi_targets={"retrieval_p95_ms": 1000.0},
    )


# ----------------------------------------------------------------------------- persona key
def test_space_schema_accepts_the_new_personas():
    base = {
        "id": uuid4(),
        "name": "x",
        "description": "",
        "instructions": "",
        "filters": {},
        "sample_questions": [],
        "is_default": False,
        "created_at": NOW,
        "updated_at": NOW,
    }
    for key in ("qa_engineer", "architect", "sre", "devops", "devsecops", "data_steward", "data_scientist", "compliance"):
        assert GenieSpaceOut.model_validate({**base, "persona": key}).persona == key


def test_new_targets_have_defaults_and_settings():
    keys = ("review_backlog", "unclassified_assets", "request_error_rate", "retrieval_p95_ms")
    for key in (*keys, "runs_stale"):
        assert key in KPI_TARGET_DEFAULTS
        assert Settings(_env_file=None).kpi_targets[key] == KPI_TARGET_DEFAULTS[key]


# ----------------------------------------------------------------------------- QA
@pytest.mark.asyncio
async def test_quality_report_gates_queue_and_failures():
    audit = FakeAudit()
    report = await _service(audit=audit).quality(days=7)
    assert isinstance(report, QualityReport)
    by_key = {k.key: k for g in report.groups for k in g.kpis}
    assert [g.key for g in report.groups] == ["ingestion", "integrity", "review", "serving"]
    # 9 of 10 finished runs = 90 % against a 95 % target: a warning, not a pass
    assert by_key["run_success_rate"].value == 90.0
    assert by_key["run_success_rate"].status == "warn"
    # a zero target tolerates up to two as a warning: 38 suggestions and 3 unclassified are off target
    assert by_key["review_backlog"].status == "bad"
    assert by_key["unclassified_assets"].status == "bad"
    # serving: 5 of 250 requests errored = 2 %; p95 900 ms is under the overridden 1000 ms
    assert by_key["request_error_rate"].value == 2.0
    assert by_key["retrieval_p95_ms"].value == 900.0
    assert by_key["retrieval_p95_ms"].status == "ok"
    assert by_key["retrieval_p95_ms"].unit == "ms"
    gated = [k for k in by_key.values() if k.target is not None and k.value is not None]
    assert report.gates_total == len(gated)
    assert 0 < report.gates_passed < report.gates_total
    # targets: one row per distinct key, the override flagged, no row for genie_error_rate
    targets = {t.key: t for t in report.targets}
    assert targets["retrieval_p95_ms"].overridden is True
    assert targets["retrieval_p95_ms"].value == 1000.0
    assert "genie_error_rate" not in targets
    # the queue parses jsonb dicts and text alike; a missing display name falls back to the table
    assert [r.proposed_name for r in report.review_queue] == [
        "Policy Beneficiary Designations",
        "Credit Card Accounts",
    ]
    assert report.review_queue[0].metrics == 1
    assert report.review_queue[0].proposed_kind == "bridge"
    assert report.review_queue[1].display_name == "card_account"
    assert report.review_queue[1].confidence == 0.6
    assert report.failed_runs[0].error is not None
    assert report.failed_runs[0].error.startswith("401")
    assert report.failed_runs[0].documents_failed == 20
    assert audit.recent_calls == [{"limit": 20, "action": None, "status": "error"}]


# ----------------------------------------------------------------------------- SRE
@pytest.mark.asyncio
async def test_platform_report_budget_storage_and_graph_outage():
    report = await _service(graph_broken=True).platform(hours=24)
    assert isinstance(report, PlatformReport)
    assert report.error_budget.requests == 250
    assert report.error_budget.errors == 5
    assert report.error_budget.allowed_errors == 2.5
    assert report.error_budget.consumed_pct == 200.0
    actions = {r.action: r for r in report.requests}
    assert actions["context.retrieve"].p95_ms == 900.0
    assert actions["genie.ask"].error_rate == 2.0
    assert [t.table for t in report.storage] == ["embeddings", "chunks"]
    assert report.database_bytes == 120_000_000
    assert report.embeddings_bytes_estimate == 5000 * 64 * 4
    # Neo4j being down must not break the report
    assert report.graph_nodes == 0
    assert report.graph_edges == 0
    by_key = {k.key: k for g in report.groups for k in g.kpis}
    assert by_key["runs_stale"].value == 2.0
    assert by_key["runs_stale"].status == "warn"
    assert by_key["graph_failed"].value == 1.0
    assert by_key["catalog_sync_age_h"].status == "ok"
    assert report.runs_active == 1
    assert report.audit_rows_per_day == 310.5


# ----------------------------------------------------------------------------- Architect
@pytest.mark.asyncio
async def test_architecture_report_integrations_and_model():
    settings = Settings(
        _env_file=None,
        databricks_host="https://adb-1.azuredatabricks.net",
        databricks_catalogs="life_edw,customer360_demo",
        github_repos="",
    )
    genie = GenieStatus(
        enabled=True, configured=True, provider="databricks", model="claude-opus-5-5"
    )
    report = await _service().architecture(genie=genie, settings=settings)
    assert isinstance(report, ArchitectureReport)
    assert report.subject_areas == 11
    assert report.facts == 35
    assert report.dimensions == 40
    assert report.metric_views == 8
    assert report.governed_metrics == 12 + 95
    assert report.shared_dimensions[0].facts == 4
    status = {i.key: i.status for i in report.integrations}
    assert status["databricks"] == "configured"
    assert status["github"] == "available"  # documents exist, nothing configured
    assert status["snowflake"] == "missing"
    assert status["confluence"] == "missing"
    assert status["genie_model"] == "configured"
    assert status["genie_ask"] == "configured"
    assert status["neo4j"] == "configured"
    assert status["export_cortex"] == "available"
    databricks = next(i for i in report.integrations if i.key == "databricks")
    assert "96 assets in 3 catalog(s)" in databricks.detail
    assert "life_edw" in databricks.detail
    assert report.genie_model == "claude-opus-5-5"
    assert report.embedding_model == "hashing-64"

    # without a Genie model the assistant surfaces show as missing with the reason
    offline = await _service().architecture(
        genie=GenieStatus(enabled=True, configured=False, reason="no credentials"),
        settings=settings,
    )
    model = next(i for i in offline.integrations if i.key == "genie_model")
    assert model.status == "missing"
    assert model.detail == "no credentials"


# ----------------------------------------------------------------------------- routes
def test_persona_routes_are_served():
    class FakeStats:
        def __init__(self) -> None:
            self.calls: list[tuple[str, Any]] = []

        async def quality(self, *, days: int) -> QualityReport:
            self.calls.append(("quality", days))
            return QualityReport(window_days=days, generated_at=NOW)

        async def analyst(self, *, days: int) -> AnalystReport:
            self.calls.append(("analyst", days))
            return AnalystReport(window_days=days, generated_at=NOW)

        async def platform(self, *, hours: int) -> PlatformReport:
            self.calls.append(("platform", hours))
            return PlatformReport(
                window_hours=hours,
                generated_at=NOW,
                error_budget={"target_error_rate": 1.0},  # type: ignore[arg-type]
            )

        async def architecture(
            self, *, genie: GenieStatus | None, settings: Settings
        ) -> ArchitectureReport:
            self.calls.append(("architecture", genie.configured if genie else None))
            return ArchitectureReport(generated_at=NOW)

    class FakeGenie:
        def status(self) -> GenieStatus:
            return GenieStatus(enabled=True, configured=True)

    stats = FakeStats()
    audit = FakeAudit()

    @asynccontextmanager
    async def lifespan(app):
        settings = Settings(_env_file=None)

        class NoSavedConnections:
            async def settings(self) -> Settings:
                return settings

        app.state.container = SimpleNamespace(
            stats=stats, audit=audit, genie=FakeGenie(), settings=settings, saved_connections=NoSavedConnections()
        )
        yield

    app = create_app(
        settings=Settings(_env_file=None, service_name="test-query"),
        title="t",
        description="d",
        version="0",
        lifespan=lifespan,
        routers=[api_router],
        latency_recorder=LatencyRecorder(100),
    )
    with TestClient(app) as client:
        assert client.get("/api/v1/stats/quality", params={"days": 3}).json()["window_days"] == 3
        platform = client.get("/api/v1/stats/platform", params={"hours": 12}).json()
        assert platform["window_hours"] == 12
        assert client.get("/api/v1/stats/architecture").status_code == 200
        audit_rows = client.get("/api/v1/stats/audit", params={"status": "error", "limit": 5})
        assert audit_rows.json() == []
        assert client.get("/api/v1/stats/quality", params={"days": 0}).status_code == 422
        assert client.get("/api/v1/stats/analyst", params={"days": 14}).json()["window_days"] == 14
    assert stats.calls == [("quality", 3), ("platform", 12), ("architecture", True), ("analyst", 14)]
    assert audit.recent_calls == [{"limit": 5, "action": None, "status": "error"}]
