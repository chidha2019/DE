"""Snowflake connector against a fake SQL REST API: statements, 202 polling, partitions, auth."""

from __future__ import annotations

import base64
import json
from typing import Any

import httpx
import pytest

from ech_core.exceptions import ConnectorError
from ech_core.semantic.models import (
    AssetKind,
    AssetType,
    FieldRole,
    MetricSource,
    RelationshipKind,
    SemanticAsset,
)
from ingestion_service.connectors.base import ConnectorOptions
from ingestion_service.connectors.snowflake import (
    SnowflakeAuth,
    SnowflakeConnector,
    SnowflakeSqlClient,
    build_keypair_jwt,
    normalize_account,
)

HOST = "https://xy12345.us-east-1.snowflakecomputing.com"
TS = "1700000000.000000000"


def result(
    columns: list[tuple[str, str]],
    rows: list[list[Any]],
    *,
    handle: str = "h1",
    partitions: int = 1,
) -> dict[str, Any]:
    return {
        "statementHandle": handle,
        "resultSetMetaData": {
            "numRows": len(rows),
            "rowType": [{"name": name, "type": kind, "scale": 0} for name, kind in columns],
            "partitionInfo": [{"rowCount": 1}] * partitions,
        },
        "data": rows,
    }


TABLE_COLUMNS = [
    ("TABLE_SCHEMA", "TEXT"),
    ("TABLE_NAME", "TEXT"),
    ("TABLE_TYPE", "TEXT"),
    ("COMMENT", "TEXT"),
    ("ROW_COUNT", "FIXED"),
    ("BYTES", "FIXED"),
    ("CREATED", "TIMESTAMP_LTZ"),
    ("LAST_ALTERED", "TIMESTAMP_LTZ"),
    ("TABLE_OWNER", "TEXT"),
    ("CLUSTERING_KEY", "TEXT"),
]
TABLES = result(
    TABLE_COLUMNS,
    [
        [
            "GOLD",
            "FACT_SALES",
            "BASE TABLE",
            "Sales at line grain",
            "100",
            "2048",
            TS,
            TS,
            "ANALYTICS_ADMIN",
            None,
        ],
        [
            "GOLD",
            "DIM_PRODUCT",
            "BASE TABLE",
            "Products",
            "10",
            "512",
            TS,
            TS,
            "ANALYTICS_ADMIN",
            None,
        ],
    ],
)
COLUMN_COLUMNS = [
    ("TABLE_SCHEMA", "TEXT"),
    ("TABLE_NAME", "TEXT"),
    ("COLUMN_NAME", "TEXT"),
    ("ORDINAL_POSITION", "FIXED"),
    ("DATA_TYPE", "TEXT"),
    ("IS_NULLABLE", "TEXT"),
    ("COMMENT", "TEXT"),
    ("NUMERIC_PRECISION", "FIXED"),
    ("NUMERIC_SCALE", "FIXED"),
]
COLUMNS_P0 = result(
    COLUMN_COLUMNS,
    [
        ["GOLD", "FACT_SALES", "SALE_ID", "1", "NUMBER", "NO", None, "38", "0"],
        ["GOLD", "FACT_SALES", "PRODUCT_ID", "2", "NUMBER", "NO", None, "38", "0"],
        ["GOLD", "FACT_SALES", "SALE_DATE", "3", "DATE", "YES", None, None, None],
        ["GOLD", "FACT_SALES", "NET_AMOUNT", "4", "NUMBER", "YES", "Net sales", "18", "2"],
    ],
    partitions=2,
)
COLUMNS_P1 = {
    "data": [
        ["GOLD", "DIM_PRODUCT", "PRODUCT_ID", "1", "NUMBER", "NO", None, "38", "0"],
        ["GOLD", "DIM_PRODUCT", "PRODUCT_NAME", "2", "TEXT", "YES", None, None, None],
        ["GOLD", "DIM_PRODUCT", "CATEGORY", "3", "TEXT", "YES", None, None, None],
    ]
}
PKS = result(
    [
        ("created_on", "TIMESTAMP_LTZ"),
        ("database_name", "TEXT"),
        ("schema_name", "TEXT"),
        ("table_name", "TEXT"),
        ("column_name", "TEXT"),
        ("key_sequence", "FIXED"),
        ("constraint_name", "TEXT"),
    ],
    [
        [TS, "ANALYTICS", "GOLD", "FACT_SALES", "SALE_ID", "1", "PK_SALES"],
        [TS, "ANALYTICS", "GOLD", "DIM_PRODUCT", "PRODUCT_ID", "1", "PK_PRODUCT"],
    ],
)
FKS = result(
    [
        ("pk_database_name", "TEXT"),
        ("pk_schema_name", "TEXT"),
        ("pk_table_name", "TEXT"),
        ("pk_column_name", "TEXT"),
        ("fk_database_name", "TEXT"),
        ("fk_schema_name", "TEXT"),
        ("fk_table_name", "TEXT"),
        ("fk_column_name", "TEXT"),
        ("key_sequence", "FIXED"),
        ("fk_name", "TEXT"),
    ],
    [
        [
            "ANALYTICS",
            "GOLD",
            "DIM_PRODUCT",
            "PRODUCT_ID",
            "ANALYTICS",
            "GOLD",
            "FACT_SALES",
            "PRODUCT_ID",
            "1",
            "FK_SALES_PRODUCT",
        ]
    ],
)
DEPS = result(
    [
        ("REFERENCED_DATABASE", "TEXT"),
        ("REFERENCED_SCHEMA", "TEXT"),
        ("REFERENCED_OBJECT_NAME", "TEXT"),
        ("REFERENCING_DATABASE", "TEXT"),
        ("REFERENCING_SCHEMA", "TEXT"),
        ("REFERENCING_OBJECT_NAME", "TEXT"),
    ],
    [["ANALYTICS", "GOLD", "FACT_SALES", "ANALYTICS", "MART", "V_SALES"]],
)
SEMANTIC_VIEWS = result(
    [
        ("created_on", "TIMESTAMP_LTZ"),
        ("name", "TEXT"),
        ("database_name", "TEXT"),
        ("schema_name", "TEXT"),
        ("comment", "TEXT"),
        ("owner", "TEXT"),
    ],
    [[TS, "SALES_SV", "ANALYTICS", "GOLD", "Sales semantic view", "ANALYTICS_ADMIN"]],
)
DESCRIBE = result(
    [
        ("object_kind", "TEXT"),
        ("object_name", "TEXT"),
        ("parent_entity", "TEXT"),
        ("property", "TEXT"),
        ("property_value", "TEXT"),
    ],
    [
        ["TABLE", "SALES", None, "BASE_TABLE_DATABASE_NAME", "ANALYTICS"],
        ["TABLE", "SALES", None, "BASE_TABLE_SCHEMA_NAME", "GOLD"],
        ["TABLE", "SALES", None, "BASE_TABLE_NAME", "FACT_SALES"],
        ["TABLE", "PRODUCT", None, "BASE_TABLE_DATABASE_NAME", "ANALYTICS"],
        ["TABLE", "PRODUCT", None, "BASE_TABLE_SCHEMA_NAME", "GOLD"],
        ["TABLE", "PRODUCT", None, "BASE_TABLE_NAME", "DIM_PRODUCT"],
        ["RELATIONSHIP", "SALES_TO_PRODUCT", None, "TABLE", "SALES"],
        ["RELATIONSHIP", "SALES_TO_PRODUCT", None, "REF_TABLE", "PRODUCT"],
        ["RELATIONSHIP", "SALES_TO_PRODUCT", None, "RELATIONSHIP_COLUMNS", "(PRODUCT_ID)"],
        ["RELATIONSHIP", "SALES_TO_PRODUCT", None, "REF_COLUMNS", "(PRODUCT_ID)"],
        ["DIMENSION", "CATEGORY", "PRODUCT", "EXPRESSION", "PRODUCT.CATEGORY"],
        ["DIMENSION", "CATEGORY", "PRODUCT", "DATA_TYPE", "VARCHAR"],
        ["FACT", "NET_AMOUNT", "SALES", "EXPRESSION", "SALES.NET_AMOUNT"],
        ["FACT", "NET_AMOUNT", "SALES", "DATA_TYPE", "NUMBER(18,2)"],
        ["METRIC", "TOTAL_NET_SALES", "SALES", "EXPRESSION", "SUM(SALES.NET_AMOUNT)"],
        ["METRIC", "TOTAL_NET_SALES", "SALES", "COMMENT", "Net sales in USD"],
        ["METRIC", "TOTAL_NET_SALES", "SALES", "SYNONYMS", "[revenue, net revenue]"],
    ],
)


def make_handler(calls: list[str]):
    def handler(request: httpx.Request) -> httpx.Response:
        calls.append(f"{request.method} {request.url.path}")
        assert request.headers["Authorization"] == "Bearer not-a-real-token"
        assert (
            request.headers["X-Snowflake-Authorization-Token-Type"] == "PROGRAMMATIC_ACCESS_TOKEN"
        )
        if request.method == "GET":
            if request.url.params.get("partition") == "1":
                return httpx.Response(200, json=COLUMNS_P1)
            if request.url.path.endswith("/h-tables"):
                return httpx.Response(200, json=TABLES)
            return httpx.Response(404, json={"message": "unknown handle"})
        body = json.loads(request.content)
        statement = body["statement"]
        upper = statement.upper()
        assert body["warehouse"] == "WH" and body["role"] == "ANALYST" and body["timeout"] == 120
        if "CURRENT_ACCOUNT()" in upper:
            columns = [
                ("ACCOUNT", "TEXT"),
                ("USER", "TEXT"),
                ("ROLE", "TEXT"),
                ("WAREHOUSE", "TEXT"),
            ]
            return httpx.Response(200, json=result(columns, [["XY12345", "SVC", "ANALYST", "WH"]]))
        if "COUNT(*) AS N" in upper:
            return httpx.Response(200, json=result([("N", "FIXED")], [["2"]]))
        if "INFORMATION_SCHEMA.TABLES" in upper:
            return httpx.Response(202, json={"statementHandle": "h-tables", "message": "running"})
        if "INFORMATION_SCHEMA.COLUMNS" in upper:
            return httpx.Response(200, json=COLUMNS_P0)
        if "INFORMATION_SCHEMA.VIEWS" in upper:
            columns = [
                ("TABLE_SCHEMA", "TEXT"),
                ("TABLE_NAME", "TEXT"),
                ("VIEW_DEFINITION", "TEXT"),
            ]
            return httpx.Response(200, json=result(columns, []))
        if "SHOW PRIMARY KEYS" in upper:
            return httpx.Response(200, json=PKS)
        if "SHOW IMPORTED KEYS" in upper:
            return httpx.Response(200, json=FKS)
        if "TAG_REFERENCES" in upper:
            return httpx.Response(422, json={"message": "SQL compilation error: not authorized."})
        if "OBJECT_DEPENDENCIES" in upper:
            return httpx.Response(200, json=DEPS)
        if "SHOW SEMANTIC VIEWS" in upper:
            return httpx.Response(200, json=SEMANTIC_VIEWS)
        if "DESCRIBE SEMANTIC VIEW" in upper:
            assert '"ANALYTICS"."GOLD"."SALES_SV"' in statement
            return httpx.Response(200, json=DESCRIBE)
        return httpx.Response(404, json={"message": f"unexpected statement {statement[:60]}"})

    return handler


def make_connector(calls: list[str]) -> SnowflakeConnector:
    client = httpx.AsyncClient(transport=httpx.MockTransport(make_handler(calls)), base_url=HOST)
    sql = SnowflakeSqlClient(
        host=HOST,
        auth=SnowflakeAuth(scheme="PROGRAMMATIC_ACCESS_TOKEN", token="not-a-real-token"),
        warehouse="WH",
        role="ANALYST",
        client=client,
    )
    return SnowflakeConnector(sql=sql, account="xy12345.us-east-1", databases=["analytics"])


async def test_health_and_estimate():
    calls: list[str] = []
    connector = make_connector(calls)
    health = await connector.health_check()
    assert health.healthy and health.details["account"] == "XY12345"
    assert health.details["databases"] == ["analytics"]
    assert await connector.estimate_count(ConnectorOptions()) == 2


async def test_documents_with_polling_partitions_and_optional_failures():
    calls: list[str] = []
    connector = make_connector(calls)
    docs = [d async for d in connector.iter_documents(ConnectorOptions())]
    assert [d.external_id for d in docs] == [
        "ANALYTICS.GOLD.FACT_SALES",
        "ANALYTICS.GOLD.DIM_PRODUCT",
        "ANALYTICS.GOLD.SALES_SV",
    ]
    assert "GET /api/v2/statements/h-tables" in calls, "a 202 is polled to completion"
    assert sum(1 for c in calls if c == "GET /api/v2/statements/h1") == 1, (
        "second partition fetched"
    )

    fact = SemanticAsset.model_validate(docs[0].attributes["semantic"])
    assert (
        fact.kind is AssetKind.FACT and fact.asset_type is AssetType.TABLE and fact.row_count == 100
    )
    assert fact.primary_key == ["SALE_ID"] and fact.field("NET_AMOUNT").data_type == "NUMBER(18,2)"
    assert fact.field("NET_AMOUNT").role is FieldRole.MEASURE
    assert fact.field("SALE_DATE").role is FieldRole.TIME
    assert docs[0].author is None, "a role is not a person"
    assert {(r.kind, r.target_fqn) for r in fact.relationships} == {
        (RelationshipKind.FOREIGN_KEY, "ANALYTICS.GOLD.DIM_PRODUCT"),
        (RelationshipKind.LINEAGE_DOWNSTREAM, "ANALYTICS.MART.V_SALES"),
    }
    fk = next(r for r in fact.relationships if r.kind is RelationshipKind.FOREIGN_KEY)
    assert fk.source_columns == ["PRODUCT_ID"] and fk.target_columns == ["PRODUCT_ID"]
    assert "FK_SALES_PRODUCT" in fk.evidence
    assert fact.tags == [], "the tag query failed on privileges and was tolerated"
    assert fact.source_created_at is not None and fact.source_created_at.year == 2023

    semantic_view = SemanticAsset.model_validate(docs[2].attributes["semantic"])
    assert semantic_view.asset_type is AssetType.SEMANTIC_VIEW
    assert semantic_view.kind is AssetKind.METRIC
    assert {f.name: (f.role, f.role_confidence) for f in semantic_view.fields} == {
        "CATEGORY": (FieldRole.DIMENSION, 1.0),
        "NET_AMOUNT": (FieldRole.MEASURE, 1.0),
    }
    (metric,) = semantic_view.metrics
    assert metric.source is MetricSource.DECLARED and metric.expression == "SUM(SALES.NET_AMOUNT)"
    assert metric.aggregation == "sum" and metric.synonyms == ["revenue", "net revenue"]
    assert metric.description == "Net sales in USD"
    assert semantic_view.properties["logical_tables"] == {
        "SALES": "ANALYTICS.GOLD.FACT_SALES",
        "PRODUCT": "ANALYTICS.GOLD.DIM_PRODUCT",
    }
    kinds = {(r.kind, r.target_fqn) for r in semantic_view.relationships}
    assert (RelationshipKind.METRIC_SOURCE, "ANALYTICS.GOLD.FACT_SALES") in kinds
    assert (RelationshipKind.JOIN_DECLARED, "ANALYTICS.GOLD.DIM_PRODUCT") in kinds
    join = next(r for r in semantic_view.relationships if r.kind is RelationshipKind.JOIN_DECLARED)
    assert join.source_columns == ["PRODUCT_ID"] and join.target_columns == ["PRODUCT_ID"]
    assert docs[2].attributes["reference_kinds"]["ANALYTICS.GOLD.DIM_PRODUCT"] == "join_declared"


async def test_sql_errors_surface_as_connector_errors():
    calls: list[str] = []
    connector = make_connector(calls)
    with pytest.raises(ConnectorError, match="HTTP 422"):
        await connector._sql.query("SELECT * FROM SNOWFLAKE.ACCOUNT_USAGE.TAG_REFERENCES")


def test_account_normalisation_and_auth_validation():
    assert normalize_account("xy12345.us-east-1") == "XY12345"
    assert normalize_account("xy12345.us-east-1.aws") == "XY12345"
    assert normalize_account("myorg-myaccount") == "MYORG-MYACCOUNT"
    assert normalize_account("myorg.myaccount") == "MYORG-MYACCOUNT"
    with pytest.raises(ConnectorError, match="ECH_SNOWFLAKE_TOKEN"):
        SnowflakeAuth(scheme="OAUTH")
    with pytest.raises(ConnectorError, match="private key"):
        SnowflakeAuth(scheme="KEYPAIR_JWT", account="a", user="u")
    headers = SnowflakeAuth(scheme="oauth", token="t").headers()
    assert headers == {"Authorization": "Bearer t", "X-Snowflake-Authorization-Token-Type": "OAUTH"}


def test_keypair_jwt_claims_and_signature():
    pytest.importorskip("cryptography")
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import padding, rsa

    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    pem = key.private_bytes(
        serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()
    )
    token = build_keypair_jwt(
        account="xy12345.us-east-1", user="svc_user", private_key_pem=pem, now=1700000000
    )
    header_b64, payload_b64, signature_b64 = token.split(".")

    def unpad(segment: str) -> bytes:
        return base64.urlsafe_b64decode(segment + "=" * (-len(segment) % 4))

    assert json.loads(unpad(header_b64)) == {"alg": "RS256", "typ": "JWT"}
    payload = json.loads(unpad(payload_b64))
    assert payload["sub"] == "XY12345.SVC_USER"
    assert payload["iss"].startswith("XY12345.SVC_USER.SHA256:")
    assert payload["exp"] - payload["iat"] == 3540 and payload["iat"] == 1700000000
    key.public_key().verify(
        unpad(signature_b64),
        f"{header_b64}.{payload_b64}".encode(),
        padding.PKCS1v15(),
        hashes.SHA256(),
    )


async def test_a_warehouse_the_role_cannot_use_fails_the_health_check():
    async def handler(request: httpx.Request) -> httpx.Response:
        columns = [("ACCOUNT", "TEXT"), ("USER", "TEXT"), ("ROLE", "TEXT"), ("WAREHOUSE", "TEXT")]
        return httpx.Response(200, json=result(columns, [["XY12345", "SVC", "ANALYST", None]]))

    client = httpx.AsyncClient(transport=httpx.MockTransport(handler), base_url=HOST)
    sql = SnowflakeSqlClient(host=HOST, auth=SnowflakeAuth(scheme="PROGRAMMATIC_ACCESS_TOKEN", token="not-a-real-token"), warehouse="NOPE", client=client)
    health = await SnowflakeConnector(sql=sql, account="xy12345", databases=["analytics"]).health_check()
    assert not health.healthy and health.details["error"] == "warehouse NOPE does not exist or role ANALYST cannot use it"
