"""Snowflake settings as docker-compose delivers them: every variable present, unused ones empty."""

from __future__ import annotations

import pytest

from ech_core.config import Settings
from ingestion_service.connectors.snowflake import SnowflakeConnector


def test_token_auth_ignores_an_empty_private_key_path_and_reads_either_token_name(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("ECH_SNOWFLAKE_ACCOUNT", "ORG-ACCT")
    monkeypatch.setenv("ECH_SNOWFLAKE_HOST", "ORG-ACCT.snowflakecomputing.com")
    monkeypatch.setenv("ECH_SNOWFLAKE_AUTH_SCHEME", "PROGRAMMATIC_ACCESS_TOKEN")
    monkeypatch.setenv("ECH_SNOWFLAKE_PRIVATE_KEY_PATH", "")
    monkeypatch.setenv("ECH_SNOWFLAKE_PRIVATE_KEY_PASSPHRASE", "")
    monkeypatch.setenv("ECH_SNOWFLAKE_DATABASES", "INSURANCE")
    monkeypatch.delenv("ECH_SNOWFLAKE_TOKEN", raising=False)
    monkeypatch.setenv("SNOWFLAKE_TOKEN", "not-a-real-token")  # the name generated pipelines use
    settings = Settings(_env_file=None)
    assert settings.snowflake_private_key_path is None
    assert settings.snowflake_token is not None and settings.snowflake_token.get_secret_value() == "not-a-real-token"
    connector = SnowflakeConnector.from_settings(settings)
    assert connector is not None
