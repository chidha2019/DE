"""Mapping after every successful sync: the watcher groups finished syncs per source system and records each pass."""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime
from typing import Any
from uuid import UUID, uuid4

from ech_core.schemas.glossary import MapRun
from query_service.services.glossary_auto import GlossaryAutoMapper


class FakeRepo:
    def __init__(self, pending: list[dict[str, Any]]) -> None:
        self.pending = pending
        self.passes: dict[UUID, dict[str, Any]] = {}

    async def pending_syncs(self) -> list[dict[str, Any]]:
        covered = {r for p in self.passes.values() for r in p["runs"]}
        return [s for s in self.pending if s["id"] not in covered]

    async def start_auto_run(self, source_system: str, ingestion_run_ids: list[UUID]) -> UUID:
        pass_id = uuid4()
        self.passes[pass_id] = {"system": source_system, "runs": list(ingestion_run_ids), "status": "running"}
        return pass_id

    async def finish_auto_run(self, run_id: UUID, *, status: str, counts: dict[str, int], message: str | None, error: str | None) -> None:
        self.passes[run_id].update(status=status, counts=counts, message=message, error=error)


class FakeGlossary:
    def __init__(self, fail_on: str | None = None) -> None:
        self.calls: list[str] = []
        self.fail_on = fail_on

    async def auto_map(self, source_system: str) -> tuple[MapRun, int]:
        self.calls.append(source_system)
        if source_system == self.fail_on:
            raise RuntimeError("database went away")
        run = MapRun(
            id=uuid4(), status="completed", trigger="sync", total=2, skipped=40, rule_links=7, model_links=3, message="ok",
            started_at=datetime.now(tz=UTC),
        )
        return run, 42


def _sync(system: str) -> dict[str, Any]:
    return {"id": uuid4(), "source_system": system, "finished_at": datetime.now(tz=UTC)}


def test_one_pass_per_source_system_however_many_syncs_finished():
    a, b, c = _sync("snowflake"), _sync("snowflake"), _sync("databricks")
    repo, glossary = FakeRepo([a, b, c]), FakeGlossary()
    mapper = GlossaryAutoMapper(glossary, repo, interval_seconds=30)  # type: ignore[arg-type]

    assert asyncio.run(mapper.tick()) == 2
    assert sorted(glossary.calls) == ["databricks", "snowflake"]
    snowflake = next(p for p in repo.passes.values() if p["system"] == "snowflake")
    assert snowflake["runs"] == [a["id"], b["id"]] and snowflake["status"] == "completed"
    assert snowflake["counts"] == {"datasets": 42, "model_datasets": 2, "unchanged": 40, "model_failed": 0, "rule_links": 7, "model_links": 3}

    # The syncs are covered now: the next poll does nothing until another sync finishes.
    assert asyncio.run(mapper.tick()) == 0
    repo.pending.append(_sync("snowflake"))
    assert asyncio.run(mapper.tick()) == 1 and glossary.calls.count("snowflake") == 2


def test_a_failing_pass_is_recorded_and_does_not_stop_the_others():
    repo, glossary = FakeRepo([_sync("snowflake"), _sync("databricks")]), FakeGlossary(fail_on="snowflake")
    mapper = GlossaryAutoMapper(glossary, repo, interval_seconds=30)  # type: ignore[arg-type]
    assert asyncio.run(mapper.tick()) == 2
    by_system = {p["system"]: p for p in repo.passes.values()}
    assert by_system["snowflake"]["status"] == "failed" and "database went away" in by_system["snowflake"]["error"]
    assert by_system["databricks"]["status"] == "completed"
