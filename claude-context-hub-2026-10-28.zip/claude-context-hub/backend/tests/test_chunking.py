from ech_core.text import count_tokens
from ingestion_service.chunking import ChunkingConfig, SemanticChunker


def test_chunker_respects_budget_and_keeps_section_paths(sample_markdown):
    chunker = SemanticChunker(
        ChunkingConfig(
            target_tokens=60,
            max_tokens=120,
            min_tokens=10,
            overlap_tokens=12,
            overlap_strategy="sentence",
        )
    )
    chunks = chunker.chunk(sample_markdown)
    assert len(chunks) >= 4
    assert [c.index for c in chunks] == list(range(len(chunks)))
    for c in chunks:
        assert c.token_count <= 120 + 12  # body within max, overlap on top
        assert c.char_start <= c.char_end <= len(sample_markdown)
        assert c.content.strip()
    paths = {tuple(c.section_path) for c in chunks}
    assert ("Atlas Platform — Architecture Overview", "Architecture") in paths
    assert ("Atlas Platform — Architecture Overview", "Operations") in paths


def test_code_fence_is_kept_atomic(sample_markdown):
    chunks = SemanticChunker(
        ChunkingConfig(
            target_tokens=40,
            max_tokens=200,
            min_tokens=5,
            overlap_tokens=0,
            overlap_strategy="none",
        )
    ).chunk(sample_markdown)
    code_chunks = [c for c in chunks if "kubectl get pods" in c.content]
    assert code_chunks, "code block should be present"
    assert "argocd app sync atlas" in code_chunks[0].content, "fence must not be split"


def test_overlap_strategies():
    text = " ".join(f"Sentence number {i} talks about platform engineering." for i in range(60))
    base = dict(target_tokens=80, max_tokens=120, min_tokens=10, overlap_tokens=16)
    none = SemanticChunker(ChunkingConfig(overlap_strategy="none", **base)).chunk(text)
    sent = SemanticChunker(ChunkingConfig(overlap_strategy="sentence", **base)).chunk(text)
    tok = SemanticChunker(ChunkingConfig(overlap_strategy="token", **base)).chunk(text)
    assert all(c.overlap_tokens == 0 for c in none)
    assert any(c.overlap_tokens > 0 for c in sent[1:])
    assert any(c.overlap_tokens > 0 for c in tok[1:])
    # overlapping text starts the next chunk and comes from the previous one
    for prev, cur in zip(sent, sent[1:], strict=False):
        if cur.overlap_tokens:
            first_line = cur.content.split("\n", 1)[0]
            assert first_line.split(" ")[-1] in prev.content


def test_oversized_unit_is_hard_split():
    text = "word " * 2000  # single giant "sentence"
    chunks = SemanticChunker(
        ChunkingConfig(
            target_tokens=100,
            max_tokens=100,
            min_tokens=5,
            overlap_tokens=0,
            overlap_strategy="none",
        )
    ).chunk(text)
    assert len(chunks) >= 20
    assert all(count_tokens(c.content) <= 100 for c in chunks)


def test_empty_and_tiny_inputs():
    chunker = SemanticChunker()
    assert chunker.chunk("") == []
    assert chunker.chunk("   \n  ") == []
    one = chunker.chunk("Just one short line.")
    assert len(one) == 1 and one[0].token_count > 0
