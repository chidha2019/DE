"""Data Engineer KPIs: pipeline reliability, graph consistency, catalog coverage, freshness."""

from __future__ import annotations

from contextlib import asynccontextmanager
from datetime import UTC, datetime, timedelta
from types import SimpleNamespace
from typing import Any

from fastapi.testclient import TestClient

from ech_core.app_factory import create_app
from ech_core.config import KPI_TARGET_DEFAULTS, Settings
from ech_core.observability import LatencyRecorder
from ech_core.schemas.stats import EngineeringKpis, KpiValue
from query_service.api import api_router
from query_service.services.stats_service import StatsService, kpi_status

NOW = datetime.now(tz=UTC)


def test_kpi_status_bands():
    # higher is better: at target ok, a little under warn, far under bad
    assert kpi_status(96, target=95, direction="higher") == "ok"
    assert kpi_status(88, target=95, direction="higher") == "warn"
    assert kpi_status(40, target=95, direction="higher") == "bad"
    # lower is better with a zero target: a couple is a warning, more is bad
    assert kpi_status(0, target=0, direction="lower") == "ok"
    assert kpi_status(2, target=0, direction="lower") == "warn"
    assert kpi_status(5, target=0, direction="lower") == "bad"
    # lower is better with a positive target: within double is a warning
    assert kpi_status(30, target=24, direction="lower") == "warn"
    assert kpi_status(72, target=24, direction="lower") == "bad"
    assert kpi_status(None, target=95, direction="higher") == "na"
    assert kpi_status(12.5, target=None, direction="higher") == "info"


class FakeRuns:
    async def kpi_rollup(self, *, days: int) -> dict[str, Any]:
        assert days == 7
        return {
            "completed": 19,
            "failed": 1,
            "cancelled": 0,
            "documents_seen": 1000,
            "documents_upserted": 990,
            "documents_failed": 10,
            "graph_failed": 0,
            "avg_duration_s": 42.0,
            "busy_seconds": 840.0,
        }

    async def connector_freshness(self, *, days: int) -> list[dict[str, Any]]:
        return [
            {
                "connector_name": "databricks",
                "source_system": "databricks",
                "last_success_at": NOW - timedelta(hours=3),
                "last_status": "completed",
                "runs": 4,
                "failed": 0,
                "documents_upserted": 96,
            },
            {
                "connector_name": "github-live",
                "source_system": "github",
                "last_success_at": None,
                "last_status": "failed",
                "runs": 1,
                "failed": 1,
                "documents_upserted": 0,
            },
        ]


class FakeDocuments:
    async def graph_sync_breakdown(self) -> dict[str, int]:
        return {"synced": 150, "pending": 5, "failed": 2}


class FakeSemantic:
    async def coverage_kpis(self) -> dict[str, Any]:
        return {
            "assets": 100,
            "described": 60,
            "owned": 100,
            "facts": 20,
            "keyed_facts": 0,
            "connected": 94,
            "fields": 1000,
            "fields_described": 500,
            "joins_declared": 10,
            "joins_inferred": 59,
            "metrics": 105,
            "metrics_declared": 12,
            "fresh_24h": 100,
            "stale_7d": 0,
            "last_synced_at": NOW - timedelta(hours=3),
        }


def _service(**overrides: Any) -> StatsService:
    return StatsService(
        documents=FakeDocuments(),  # type: ignore[arg-type]
        chunks=SimpleNamespace(),  # type: ignore[arg-type]
        embeddings=SimpleNamespace(),  # type: ignore[arg-type]
        runs=FakeRuns(),  # type: ignore[arg-type]
        audit=SimpleNamespace(),  # type: ignore[arg-type]
        graph=SimpleNamespace(),  # type: ignore[arg-type]
        embedder=SimpleNamespace(model_id="hashing", dimensions=1536),  # type: ignore[arg-type]
        latency=LatencyRecorder(10),
        semantic=FakeSemantic(),  # type: ignore[arg-type]
        kpi_targets=overrides.get("kpi_targets"),
    )


async def test_engineering_kpis_roll_up_every_source():
    kpis = await _service().engineering(days=7)
    assert isinstance(kpis, EngineeringKpis) and kpis.window_days == 7
    by_key: dict[str, KpiValue] = {k.key: k for group in kpis.groups for k in group.kpis}

    assert by_key["run_success_rate"].value == 95.0 and by_key["run_success_rate"].status == "ok"
    assert by_key["runs_failed"].value == 1 and by_key["runs_failed"].status == "warn"
    assert by_key["doc_failure_rate"].value == 1.0 and by_key["doc_failure_rate"].status == "ok"
    assert by_key["throughput"].value == round(990 / 14, 1)
    assert by_key["throughput"].status == "info"
    assert by_key["graph_sync_rate"].value == round(150 / 157 * 100, 1)
    assert by_key["graph_failed"].value == 2 and by_key["graph_failed"].status == "warn"
    assert by_key["facts_keyed_pct"].value == 0.0 and by_key["facts_keyed_pct"].status == "bad"
    assert by_key["joins_declared_pct"].value == round(10 / 69 * 100, 1)
    age = by_key["catalog_sync_age_h"]
    assert age.status == "ok" and age.value is not None and 2.9 < age.value < 3.1

    databricks, github = kpis.connectors
    assert databricks.connector == "databricks" and databricks.age_hours is not None
    assert 2.9 < databricks.age_hours < 3.1
    assert github.last_success_at is None and github.age_hours is None and github.failed == 1


async def test_engineering_kpis_without_runs_or_catalog_are_not_applicable():
    class EmptyRuns(FakeRuns):
        async def kpi_rollup(self, *, days: int):
            return {
                "completed": 0,
                "failed": 0,
                "cancelled": 0,
                "documents_seen": 0,
                "documents_upserted": 0,
                "documents_failed": 0,
                "graph_failed": 0,
                "avg_duration_s": None,
                "busy_seconds": 0.0,
            }

        async def connector_freshness(self, *, days: int):
            return []

    class EmptySemantic:
        async def coverage_kpis(self):
            return {
                "assets": 0,
                "described": 0,
                "owned": 0,
                "facts": 0,
                "keyed_facts": 0,
                "connected": 0,
                "fields": 0,
                "fields_described": 0,
                "joins_declared": 0,
                "joins_inferred": 0,
                "metrics": 0,
                "metrics_declared": 0,
                "fresh_24h": 0,
                "stale_7d": 0,
                "last_synced_at": None,
            }

    service = _service()
    service._runs = EmptyRuns()  # type: ignore[assignment]
    service._semantic = EmptySemantic()  # type: ignore[assignment]
    kpis = await service.engineering(days=7)
    by_key = {k.key: k for group in kpis.groups for k in group.kpis}
    assert by_key["run_success_rate"].status == "na" and by_key["run_success_rate"].value is None
    assert by_key["assets_described_pct"].status == "na"
    assert by_key["catalog_sync_age_h"].status == "na"
    assert kpis.connectors == []


def test_engineering_kpis_route():
    service = _service()

    @asynccontextmanager
    async def lifespan(app):
        app.state.container = SimpleNamespace(stats=service)
        yield

    app = create_app(
        settings=Settings(_env_file=None, service_name="test-query"),
        title="t",
        description="d",
        version="0",
        lifespan=lifespan,
        routers=[api_router],
        latency_recorder=LatencyRecorder(100),
    )
    with TestClient(app) as client:
        response = client.get("/api/v1/stats/engineering", params={"days": 7})
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["window_days"] == 7 and [g["key"] for g in body["groups"]] == [
            "pipelines",
            "graph",
            "catalog",
            "freshness",
        ]
        assert client.get("/api/v1/stats/engineering", params={"days": 0}).status_code == 422


async def test_custom_targets_change_verdicts_and_are_reported():
    service = _service(kpi_targets={"run_success_rate": 99, "catalog_sync_age_h": 6})
    kpis = await service.engineering(days=7)
    by_key = {k.key: k for g in kpis.groups for k in g.kpis}
    assert by_key["run_success_rate"].target == 99 and by_key["run_success_rate"].status == "warn"
    assert by_key["catalog_sync_age_h"].target == 6 and by_key["catalog_sync_age_h"].status == "ok"
    targets = {t.key: t for t in kpis.targets}
    assert targets["run_success_rate"].overridden and targets["run_success_rate"].default == 95
    assert targets["run_success_rate"].env_var == "ECH_KPI_TARGET_RUN_SUCCESS_RATE"
    assert not targets["graph_sync_rate"].overridden
    # the Data Engineer scorecard carries its own targets; QA and SRE add the rest
    assert set(targets) < set(KPI_TARGET_DEFAULTS)
    assert "review_backlog" not in targets and "runs_stale" not in targets


def test_settings_expose_kpi_targets(monkeypatch):
    for key in KPI_TARGET_DEFAULTS:
        monkeypatch.delenv(f"ECH_KPI_TARGET_{key.upper()}", raising=False)
    assert Settings(_env_file=None).kpi_targets == KPI_TARGET_DEFAULTS
    monkeypatch.setenv("ECH_KPI_TARGET_RUN_SUCCESS_RATE", "99")
    monkeypatch.setenv("ECH_KPI_TARGET_CATALOG_SYNC_AGE_H", "6.5")
    targets = Settings(_env_file=None).kpi_targets
    assert targets["run_success_rate"] == 99.0 and targets["catalog_sync_age_h"] == 6.5
