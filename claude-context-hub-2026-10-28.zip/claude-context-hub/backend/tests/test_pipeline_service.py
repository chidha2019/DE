"""Pipeline tests with in-memory fakes for Postgres and Neo4j repositories.

They exercise the real chunker, extractor, hashing embedder and the saga logic
(change detection, graph-sync status transitions, reconcile) without databases.
"""

from __future__ import annotations

import uuid
from contextlib import asynccontextmanager
from datetime import UTC, datetime

import pytest

from ech_core.config import Settings
from ech_core.domain.enums import EntityType, GraphSyncStatus, SourceSystem
from ech_core.domain.models import DocumentRecord
from ech_core.embeddings.hashing import HashingEmbeddingProvider
from ingestion_service.connectors import ConnectorRegistry, SourceDocument
from ingestion_service.connectors.base import ExplicitEntity
from ingestion_service.services.event_bus import EventBus
from ingestion_service.services.pipeline_service import PipelineService
from ingestion_service.services.run_manager import RunManager


# ----------------------------------------------------------------------------- fakes
class FakePG:
    @asynccontextmanager
    async def transaction(self):
        yield object()


class FakeDocuments:
    def __init__(self):
        self.rows: dict[uuid.UUID, DocumentRecord] = {}

    async def get_for_update(self, conn, document_id):
        return self.rows.get(document_id)

    async def upsert(self, conn, data, *, content_changed):
        prev = self.rows.get(data.id)
        now = datetime.now(tz=UTC)
        record = DocumentRecord(
            **data.model_dump(),
            version=(
                prev.version + 1 if prev and content_changed else (prev.version if prev else 1)
            ),
            graph_sync_status=(
                GraphSyncStatus.PENDING
                if content_changed or prev is None
                else prev.graph_sync_status
            ),
            ingested_at=prev.ingested_at if prev else now,
            updated_at=now,
        )
        self.rows[data.id] = record
        return record

    async def set_graph_pending(self, conn, document_id):
        self.rows[document_id] = self.rows[document_id].model_copy(
            update={"graph_sync_status": GraphSyncStatus.PENDING}
        )

    async def mark_graph_synced(self, document_id, node_id):
        self.rows[document_id] = self.rows[document_id].model_copy(
            update={"graph_sync_status": GraphSyncStatus.SYNCED, "graph_node_id": node_id}
        )

    async def mark_graph_failed(self, document_id, error):
        self.rows[document_id] = self.rows[document_id].model_copy(
            update={"graph_sync_status": GraphSyncStatus.FAILED, "graph_sync_error": error}
        )

    async def list_graph_unsynced(self, limit=100):
        return [r for r in self.rows.values() if r.graph_sync_status is not GraphSyncStatus.SYNCED][
            :limit
        ]

    async def get(self, document_id, include_counts=True):
        return self.rows.get(document_id)

    async def delete(self, document_id):
        return self.rows.pop(document_id, None) is not None


class FakeChunks:
    def __init__(self):
        self.by_doc = {}

    async def replace_for_document(self, conn, document_id, chunks):
        self.by_doc[document_id] = list(chunks)

    async def list_for_document(self, document_id):
        return list(self.by_doc.get(document_id, []))


class FakeEmbeddings:
    def __init__(self):
        self.records = {}

    async def upsert_many(self, conn, records):
        for r in records:
            assert len(r.vector) == 1536
            self.records[r.chunk_id] = r


class FakeGraph:
    def __init__(self, fail_times=0):
        self.payloads = []
        self.fail_times = fail_times
        self.deleted = []

    async def sync_document(self, payload):
        if self.fail_times > 0:
            self.fail_times -= 1
            raise RuntimeError("neo4j down")
        self.payloads.append(payload)
        return f"4:node:{len(self.payloads)}"

    async def delete_document(self, document_id):
        self.deleted.append(document_id)

    async def delete_orphan_entities(self):
        return 0

    async def prune_dangling_dependencies(self):
        return 0


class FakeRuns:
    async def merge_stats(self, *a, **k): ...
    async def append_event(self, *a, **k): ...
    async def set_status(self, *a, **k): ...


class FakeAudit:
    def __init__(self):
        self.actions = []

    async def record(self, **kwargs):
        self.actions.append(kwargs["action"])


def make_service(graph: FakeGraph | None = None):
    settings = Settings(
        _env_file=None, chunk_target_tokens=120, chunk_max_tokens=200, chunk_min_tokens=20
    )
    docs, chunks, embs = FakeDocuments(), FakeChunks(), FakeEmbeddings()
    graph = graph or FakeGraph()
    service = PipelineService(
        settings=settings,
        pg=FakePG(),
        documents=docs,
        chunks=chunks,
        embeddings=embs,
        runs=FakeRuns(),
        audit=FakeAudit(),
        graph=graph,
        embedder=HashingEmbeddingProvider(dimensions=1536),
        registry=ConnectorRegistry(),
        event_bus=EventBus(),
        run_manager=RunManager(),
    )
    return service, docs, chunks, embs, graph


SAMPLE_MARKDOWN = """# Atlas Platform — Architecture Overview

Owner: Priya Natarajan · Reviewer: Marcus Feld · Status: Approved

## Context

Atlas Platform (ATLAS) is the internal developer platform that provisions Kubernetes workloads.
The system is owned by Priya Natarajan and maintained by Lena Okafor, Daniel Brooks. Atlas Platform
depends on Helios Identity: outages there propagate into ATLAS incident reviews.

## Architecture

The service is implemented with Kubernetes and Terraform, persists state in ArgoCD and relies on
Go, Prometheus, Helm for the remaining platform concerns. All components are deployed through
Atlas Platform using ArgoCD and Helm charts. Requests are authenticated by Helios Identity tokens.

## Operations

* HighErrorRate: open Grafana and confirm the burn rate.
* QueueBacklog: scale consumers and apply Backpressure.

Service Level Objective: 99.9% monthly availability measured by Sentinel Observability probes.
This paragraph exists so the chunker has enough material to split on when the target token
budget is small. It keeps talking about Disaster Recovery drills and the Incident Response plan
so the extractor has concepts to find, and about Zero Trust networking.
"""


async def first_confluence_doc() -> SourceDocument:
    """A realistic source document (the mock corpus is gone): people, projects, technologies."""
    return SourceDocument(
        external_id="ENG:atlas-architecture",
        title="Atlas Platform — Architecture Overview",
        content=SAMPLE_MARKDOWN,
        uri="https://confluence.example.com/x/atlas",
        author="Priya Natarajan",
        contributors=["Lena Okafor"],
        references=["ENG:helios-runbook"],
        explicit_entities=[
            ExplicitEntity(name="Atlas Platform", entity_type=EntityType.PROJECT),
            ExplicitEntity(name="Helios Identity", entity_type=EntityType.PROJECT),
            ExplicitEntity(name="Priya Natarajan", entity_type=EntityType.PERSON),
        ],
    )


# ----------------------------------------------------------------------------- tests
@pytest.mark.asyncio
async def test_process_document_writes_chunks_embeddings_and_graph():
    service, docs, chunks, embs, graph = make_service()
    src = await first_confluence_doc()
    outcome = await service.process_document(src, SourceSystem.CONFLUENCE)

    assert outcome.changed and not outcome.skipped and outcome.graph_synced
    assert outcome.chunks == len(chunks.by_doc[outcome.document_id]) >= 2
    assert outcome.embeddings == outcome.chunks == len(embs.records)
    assert outcome.entities > 0
    record = docs.rows[outcome.document_id]
    assert record.graph_sync_status is GraphSyncStatus.SYNCED and record.version == 1
    assert record.attributes["contributors"] and record.attributes["references"]

    payload = graph.payloads[-1]
    assert payload.document_id == outcome.document_id
    assert len(payload.chunks) == outcome.chunks
    assert {m.entity_type.value for m in payload.mentions} >= {"Project", "Technology", "Person"}
    assert payload.contributors and payload.references
    assert payload.dependencies, "Project -> Technology DEPENDS_ON edges derived from co-mentions"
    # chunk metadata persists entities so reconcile never needs re-extraction
    assert all("entities" in c.metadata for c in chunks.by_doc[outcome.document_id])


@pytest.mark.asyncio
async def test_unchanged_document_is_skipped_and_full_refresh_bumps_version():
    service, docs, *_ = make_service()
    src = await first_confluence_doc()
    first = await service.process_document(src, SourceSystem.CONFLUENCE)
    second = await service.process_document(src, SourceSystem.CONFLUENCE)
    assert second.skipped and not second.changed
    assert docs.rows[first.document_id].version == 1

    from ech_core.schemas.ingestion import RunOptions

    third = await service.process_document(
        src, SourceSystem.CONFLUENCE, options=RunOptions(full_refresh=True)
    )
    assert third.changed and docs.rows[first.document_id].version == 2


@pytest.mark.asyncio
async def test_graph_failure_is_recorded_and_reconciled():
    service, docs, chunks, embs, graph = make_service(FakeGraph(fail_times=1))
    src = await first_confluence_doc()
    outcome = await service.process_document(src, SourceSystem.CONFLUENCE)
    assert not outcome.graph_synced and outcome.graph_error and "neo4j down" in outcome.graph_error
    assert docs.rows[outcome.document_id].graph_sync_status is GraphSyncStatus.FAILED
    # search data is intact even though the graph is stale
    assert chunks.by_doc[outcome.document_id] and embs.records

    result = await service.reconcile_graph(limit=10)
    assert result.scanned == 1 and result.synced == 1 and result.failed == 0
    assert docs.rows[outcome.document_id].graph_sync_status is GraphSyncStatus.SYNCED
    rebuilt = graph.payloads[-1]
    assert len(rebuilt.mentions) > 0, "mentions rebuilt from chunk metadata"


@pytest.mark.asyncio
async def test_delete_removes_graph_then_postgres():
    service, docs, _, _, graph = make_service()
    src = await first_confluence_doc()
    outcome = await service.process_document(src, SourceSystem.CONFLUENCE)
    await service.delete_document(outcome.document_id)
    assert graph.deleted == [outcome.document_id]
    assert outcome.document_id not in docs.rows
