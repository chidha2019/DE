import pytest

from ech_core.config import Settings
from query_service.retrieval.reranker import (
    HeuristicReranker,
    NoopReranker,
    RerankDoc,
    build_reranker,
)


@pytest.mark.asyncio
async def test_heuristic_reranker_prefers_relevant_passage():
    reranker = HeuristicReranker()
    docs = [
        RerankDoc(
            "Grafana dashboards visualise Prometheus metrics for Kubernetes clusters.", "Sentinel"
        ),
        RerankDoc(
            "Nimbus Billing meters usage, rates it and produces invoices through Stripe.",
            "Nimbus Billing",
        ),
        RerankDoc(
            "The onboarding guide explains how to request access in Helios Identity.", "Onboarding"
        ),
    ]
    scores = await reranker.score("how does Nimbus Billing produce invoices", docs)
    assert len(scores) == 3
    assert max(scores) == 1.0 and min(scores) >= 0.0
    assert scores.index(max(scores)) == 1


@pytest.mark.asyncio
async def test_rerankers_handle_edge_cases():
    assert await HeuristicReranker().score("anything", []) == []
    assert len(await HeuristicReranker().score("the of and", [RerankDoc("x")])) == 1
    assert await NoopReranker().score("q", [RerankDoc("a"), RerankDoc("b")]) == [0.0, 0.0]


def test_factory_respects_settings():
    assert (
        build_reranker(Settings(_env_file=None, reranker_provider="heuristic")).name == "heuristic"
    )
    assert build_reranker(Settings(_env_file=None, reranker_provider="none")).name == "none"
    assert (
        build_reranker(Settings(_env_file=None, reranker_provider="cross_encoder")).name
        == "cross_encoder"
    )
