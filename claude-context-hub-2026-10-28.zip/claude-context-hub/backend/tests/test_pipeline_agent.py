"""Agent loop, tools and workspace against a fake hub and a scripted model."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import httpx
import pytest

from pipeline_agent.agent import AgentConfig, ModelTurn, PipelineBuilderAgent
from pipeline_agent.hub import HubClient
from pipeline_agent.tools import TOOLS, ToolExecutor
from pipeline_agent.workspace import CommandResult, Workspace, WorkspaceError

REPO = "acme/omniclaim"
GOLD_DOC_ID = "11111111-1111-5111-8111-111111111111"
ASSETS_DOC_ID = "22222222-2222-5222-8222-222222222222"


# ----------------------------------------------------------------------------- fakes
def fake_hub(calls: list[str]) -> HubClient:
    def handler(request: httpx.Request) -> httpx.Response:
        calls.append(f"{request.method} {request.url.path}")
        if request.url.path == "/api/v1/context/retrieve":
            body = json.loads(request.content)
            assert body["filters"] == {"attributes": {"repo": REPO}}, (
                "retrieval must be repo-scoped"
            )
            return httpx.Response(
                200,
                json={
                    "query": body["query"],
                    "top_k": body["top_k"],
                    "candidates_considered": 12,
                    "reranker": "heuristic",
                    "embedding_model": "hashing:v1",
                    "timings": {"total_ms": 12.5},
                    "results": [
                        {
                            "chunk_id": "chunk-gold-1",
                            "document_id": GOLD_DOC_ID,
                            "document_title": "omniclaim/sql/gold/fact_loss.sql",
                            "source_system": "github",
                            "uri": None,
                            "chunk_index": 0,
                            "section_path": [],
                            "token_count": 40,
                            "content": "select l.LOSS_SK from {{ silver('FACT_LOSS') }} l",
                            "retrieval_paths": ["vector", "keyword"],
                            "scores": {
                                "vector": 0.9,
                                "keyword": 0.5,
                                "fused": 1.0,
                                "graph_boost": 0.0,
                                "rerank": 0.8,
                                "final": 0.92,
                            },
                            "entities": [
                                {
                                    "key": "Technology:sql",
                                    "name": "SQL",
                                    "entity_type": "Technology",
                                }
                            ],
                            "document_attributes": {"repo": REPO, "path": "sql/gold/fact_loss.sql"},
                        }
                    ],
                    "graph_context": {
                        "nodes": [
                            {
                                "id": ASSETS_DOC_ID,
                                "label": "omniclaim/config/assets.yml",
                                "type": "Document",
                                "properties": {},
                                "degree": 1,
                            }
                        ],
                        "edges": [],
                        "seed_chunk_ids": ["chunk-gold-1"],
                        "expanded_chunk_ids": [],
                        "first_degree_entities": ["Technology:sql"],
                        "second_degree_entities": [],
                    },
                    "debug": None,
                    "request_id": "r1",
                },
            )
        if request.url.path == "/api/v1/documents":
            return httpx.Response(
                200,
                json={
                    "items": [
                        {
                            "id": GOLD_DOC_ID,
                            "title": "omniclaim/sql/gold/fact_loss.sql",
                            "chunk_count": 1,
                            "attributes": {"repo": REPO, "path": "sql/gold/fact_loss.sql"},
                        },
                        {
                            "id": ASSETS_DOC_ID,
                            "title": "omniclaim/config/assets.yml",
                            "chunk_count": 1,
                            "attributes": {"repo": REPO, "path": "config/assets.yml"},
                        },
                        {
                            "id": "other",
                            "title": "other/assets.yml",
                            "chunk_count": 1,
                            "attributes": {"repo": "other/repo", "path": "config/assets.yml"},
                        },
                    ],
                    "total": 3,
                    "limit": 50,
                    "offset": 0,
                },
            )
        if request.url.path == f"/api/v1/documents/{GOLD_DOC_ID}/lineage":
            return httpx.Response(
                200,
                json={
                    "nodes": [
                        {
                            "id": GOLD_DOC_ID,
                            "label": "omniclaim/sql/gold/fact_loss.sql",
                            "type": "Document",
                            "properties": {},
                            "degree": 2,
                        },
                        {
                            "id": ASSETS_DOC_ID,
                            "label": "omniclaim/config/assets.yml",
                            "type": "Document",
                            "properties": {},
                            "degree": 1,
                        },
                        {
                            "id": "Person:dev",
                            "label": "dev",
                            "type": "Person",
                            "properties": {},
                            "degree": 1,
                        },
                    ],
                    "edges": [
                        {
                            "source": ASSETS_DOC_ID,
                            "target": GOLD_DOC_ID,
                            "type": "REFERENCES",
                            "properties": {},
                        },
                        {
                            "source": GOLD_DOC_ID,
                            "target": "Person:dev",
                            "type": "CONTRIBUTED_BY",
                            "properties": {},
                        },
                    ],
                    "center_id": GOLD_DOC_ID,
                    "chunk_entities": None,
                },
            )
        if request.url.path == "/api/v1/documents" and request.method == "POST":
            return httpx.Response(
                201,
                json={
                    "document_id": "new",
                    "changed": True,
                    "chunks": 1,
                    "embeddings": 1,
                    "entities": 0,
                    "graph_sync_status": "synced",
                },
            )
        return httpx.Response(404, json={"error": {"code": "not_found", "message": "nope"}})

    client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    return HubClient(
        query_url="http://query.test", ingestion_url="http://ingest.test", repo=REPO, client=client
    )


class ScriptedModel:
    """Replays canned assistant turns and records what the agent sent each time."""

    def __init__(self, turns: list[ModelTurn]) -> None:
        self.turns = list(turns)
        self.requests: list[list[dict[str, Any]]] = []

    async def complete(
        self, *, system: str, tools: list[dict[str, Any]], messages: list[dict[str, Any]]
    ) -> ModelTurn:
        assert tools is TOOLS and "Ground first" in system
        self.requests.append([json.loads(json.dumps(m)) for m in messages])
        if not self.turns:
            raise AssertionError("model script exhausted")
        return self.turns.pop(0)


def tool_use(id_: str, name: str, **inp: Any) -> dict[str, Any]:
    return {"type": "tool_use", "id": id_, "name": name, "input": inp}


def turn(
    *blocks: dict[str, Any], stop: str = "tool_use", usage: dict[str, int] | None = None
) -> ModelTurn:
    return ModelTurn(
        content=list(blocks),
        stop_reason=stop,
        usage=usage or {"input_tokens": 100, "output_tokens": 50},
    )


def make_workspace(tmp_path: Path) -> Workspace:
    root = tmp_path / "ws"
    (root / "sql/gold").mkdir(parents=True)
    (root / "config").mkdir()
    (root / "tests").mkdir()
    (root / "README.md").write_text("# omniclaim\n", encoding="utf-8")
    (root / "sql/gold/fact_loss.sql").write_text(
        "select l.LOSS_SK from {{ silver('FACT_LOSS') }} l\n", encoding="utf-8"
    )
    (root / "config/assets.yml").write_text(
        "assets:\n- id: GOLD.FACT_LOSS\n  definition: sql/gold/fact_loss.sql\n", encoding="utf-8"
    )
    (root / "tests/test_x.py").write_text("def test_ok():\n    assert True\n", encoding="utf-8")
    return Workspace(root)


# ----------------------------------------------------------------------------- tests
@pytest.mark.asyncio
async def test_full_loop_grounds_writes_tests_and_finishes(tmp_path, monkeypatch):
    calls: list[str] = []
    ws = make_workspace(tmp_path)
    ran: list[str] = []

    async def fake_run(self, command, *, timeout=900.0, max_output=12_000):
        ran.append(command)
        result = CommandResult(command, 0, "2 passed in 0.1s", "", 0.1)
        self.commands.append(result)
        return result

    monkeypatch.setattr(Workspace, "run_command", fake_run)

    new_sql = "select a.AGREEMENT_SK, datediff(day, a.OPEN_DT, current_date) AGE_DAYS from {{ silver('FACT_AGREEMENT') }} a\n"
    model = ScriptedModel(
        [
            turn(
                {"type": "thinking", "thinking": "", "signature": "sig"},
                tool_use(
                    "t1",
                    "retrieve_context",
                    query="how gold tables are defined",
                    top_k=5,
                    use_graph=True,
                ),
            ),
            turn(
                tool_use("t2", "get_document", path="sql/gold/fact_loss.sql"),
                tool_use("t3", "get_lineage", path="sql/gold/fact_loss.sql", depth=2),
            ),
            turn(
                tool_use(
                    "t4",
                    "write_file",
                    path="../evil.sql",
                    content="x",
                    reason="escape",
                    sources=["sql/gold/fact_loss.sql"],
                ),
                tool_use(
                    "t5",
                    "write_file",
                    path="sql/gold/fact_claims_aging.sql",
                    content=new_sql,
                    reason="new gold table",
                    sources=["chunk-gold-1", "sql/gold/fact_loss.sql"],
                ),
            ),
            turn(
                tool_use(
                    "t6",
                    "write_file",
                    path="config/assets.yml",
                    content="assets:\n- id: GOLD.FACT_LOSS\n  definition: sql/gold/fact_loss.sql\n- id: GOLD.FACT_CLAIMS_AGING\n  definition: sql/gold/fact_claims_aging.sql\n",
                    reason="register",
                    sources=["config/assets.yml"],
                )
            ),
            turn(
                tool_use(
                    "t7",
                    "run_command",
                    command="pip install -r requirements-dev.in",
                    timeout_seconds=600,
                ),
                tool_use("t8", "run_command", command="pytest -q", timeout_seconds=600),
            ),
            turn(
                tool_use(
                    "t9",
                    "finish",
                    summary="Added GOLD.FACT_CLAIMS_AGING",
                    files=["sql/gold/fact_claims_aging.sql", "config/assets.yml"],
                    next_steps=["review grain"],
                    tests_passed=True,
                    confidence=0.8,
                ),
                stop="end_turn",
            ),
        ]
    )
    config = AgentConfig(
        repo=REPO, max_turns=10, transcript_path=ws.root / ".agent/transcript.jsonl"
    )
    hub = fake_hub(calls)
    agent = PipelineBuilderAgent(
        config=config, model=model, executor=ToolExecutor(hub=hub, workspace=ws)
    )
    result = await agent.run("Add a gold fact table fact_claims_aging")

    assert result.status == "finished" and result.turns == 6
    assert (ws.root / "sql/gold/fact_claims_aging.sql").read_text(encoding="utf-8") == new_sql
    assert not (tmp_path / "evil.sql").exists(), "path traversal must be rejected"
    assert {f["path"] for f in result.files} == {
        "sql/gold/fact_claims_aging.sql",
        "config/assets.yml",
    }
    created = {f["path"]: f["created"] for f in result.files}
    assert (
        created["sql/gold/fact_claims_aging.sql"] is True and created["config/assets.yml"] is False
    )
    assert ran == ["pip install -r requirements-dev.in", "pytest -q"]
    assert (
        result.tests_passed is True
        and result.confidence == 0.8
        and result.next_steps == ["review grain"]
    )
    assert [c["chunk_id"] for c in result.citations] == ["chunk-gold-1"]
    assert result.usage["input_tokens"] == 600 and result.usage["output_tokens"] == 300
    assert result.estimated_cost_usd == round((600 * 4 + 300 * 20) / 1_000_000, 4)

    # conversation plumbing: full assistant blocks (incl. thinking) echoed back, tool results paired by id,
    # errors flagged, all results of a turn in ONE user message
    second_request = model.requests[1]
    assert (
        second_request[1]["role"] == "assistant"
        and second_request[1]["content"][0]["type"] == "thinking"
    )
    results_msg = second_request[2]
    assert results_msg["role"] == "user" and results_msg["content"][0]["tool_use_id"] == "t1"
    assert "chunk_id=chunk-gold-1" in results_msg["content"][0]["content"]
    assert "related documents: omniclaim/config/assets.yml" in results_msg["content"][0]["content"]
    fourth = model.requests[3][-1]["content"]
    assert [b["tool_use_id"] for b in fourth] == ["t4", "t5"]
    assert fourth[0]["is_error"] is True and "escapes the workspace" in fourth[0]["content"]
    assert "is_error" not in fourth[1]
    lineage_result = model.requests[2][-1]["content"][1]["content"]
    assert (
        "referenced by (1): config/assets.yml" in lineage_result
        and "contributors: dev" in lineage_result
    )

    transcript = (ws.root / ".agent/transcript.jsonl").read_text(encoding="utf-8").splitlines()
    assert len(transcript) >= 6 and json.loads(transcript[0])["turn"] == 1
    assert calls.count("POST /api/v1/context/retrieve") == 1
    await hub.aclose()


@pytest.mark.asyncio
async def test_invalid_tool_input_and_missing_finish_are_handled(tmp_path):
    ws = make_workspace(tmp_path)
    model = ScriptedModel(
        [
            turn(
                tool_use("t1", "write_file", path="x.sql", content="select 1", reason="r")
            ),  # sources missing -> validation error
            turn(
                {"type": "text", "text": "I think I am done."}, stop="end_turn"
            ),  # no finish -> nudge
            turn({"type": "text", "text": "Really done."}, stop="end_turn"),
        ]
    )
    hub = fake_hub([])
    agent = PipelineBuilderAgent(
        config=AgentConfig(repo=REPO, max_turns=5),
        model=model,
        executor=ToolExecutor(hub=hub, workspace=ws),
    )
    result = await agent.run("noop")
    assert result.status == "ended_without_finish" and result.turns == 3
    first_result = model.requests[1][-1]["content"][0]
    assert (
        first_result["is_error"] is True
        and "invalid input for write_file" in first_result["content"]
    )
    assert "finish" in model.requests[2][-1]["content"][0]["text"]
    assert not (ws.root / "x.sql").exists()
    await hub.aclose()


@pytest.mark.asyncio
async def test_refusal_and_model_errors_stop_the_loop(tmp_path):
    ws = make_workspace(tmp_path)
    model = ScriptedModel(
        [ModelTurn(content=[], stop_reason="refusal", stop_details={"category": "cyber"})]
    )
    agent = PipelineBuilderAgent(
        config=AgentConfig(repo=REPO, max_turns=5),
        model=model,
        executor=ToolExecutor(hub=fake_hub([]), workspace=ws),
    )
    result = await agent.run("x")
    assert result.status == "refused" and "cyber" in (result.error or "")

    class Boom:
        async def complete(self, **_: Any) -> ModelTurn:
            raise RuntimeError("api down")

    agent = PipelineBuilderAgent(
        config=AgentConfig(repo=REPO, max_turns=5),
        model=Boom(),
        executor=ToolExecutor(hub=fake_hub([]), workspace=ws),
    )
    result = await agent.run("x")
    assert result.status == "error" and "api down" in (result.error or "")


def test_workspace_guards_and_command_allowlist(tmp_path):
    ws = make_workspace(tmp_path)
    for bad in ["../x", "/etc/passwd", "C:/Windows/x", "sql/../../x", ".agent-venv/pwn.py"]:
        with pytest.raises(WorkspaceError):
            ws.write(bad, "x")
    assert ws.read("README.md").startswith("# omniclaim")
    assert ws.list("sql/**/*.sql") == ["sql/gold/fact_loss.sql"]
    for bad_cmd in [
        "rm -rf /",
        "python -c 'import os'",
        "pip install requests",
        "pip install -r ../../etc/passwd",
        "bash -c ls",
    ]:
        with pytest.raises(WorkspaceError):
            ws.translate_command(bad_cmd)
    argv = ws.translate_command("python -m pytest -q tests/test_x.py")
    assert argv[1:] == ["-m", "pytest", "-q", "tests/test_x.py"] and Path(argv[0]).name.startswith(
        "python"
    )
    assert ws.translate_command("pip install -r requirements-dev.in")[1:] == [
        "-m",
        "pip",
        "install",
        "-q",
        "-r",
        "requirements-dev.in",
    ]


_STRICT_UNSUPPORTED = {
    "minimum",
    "maximum",
    "exclusiveMinimum",
    "exclusiveMaximum",
    "multipleOf",
    "minLength",
    "maxLength",
    "pattern",
    "minItems",
    "maxItems",
    "uniqueItems",
}


def _schema_keys(node: Any) -> set[str]:
    """Schema keywords in use; the keys under ``properties`` are field names, not keywords."""
    keys: set[str] = set()
    if isinstance(node, dict):
        for key, value in node.items():
            if key == "properties" and isinstance(value, dict):
                for sub in value.values():
                    keys |= _schema_keys(sub)
                continue
            keys.add(key)
            keys |= _schema_keys(value)
    elif isinstance(node, list):
        for value in node:
            keys |= _schema_keys(value)
    return keys


def test_tool_schemas_are_strict_and_closed():
    for tool in TOOLS:
        schema = tool["input_schema"]
        assert schema["additionalProperties"] is False
        assert set(schema["required"]) == set(schema["properties"]), tool["name"]
        assert "title" not in json.dumps(schema["properties"])
        # The API rejects numeric/string/array constraints under strict mode (400).
        assert not _schema_keys(schema) & _STRICT_UNSUPPORTED, tool["name"]
    retrieve = next(t for t in TOOLS if t["name"] == "retrieve_context")["input_schema"]
    assert "1 to 20" in retrieve["properties"]["top_k"]["description"], "bounds become hints"
    write = next(t for t in TOOLS if t["name"] == "write_file")["input_schema"]
    assert "at most 20 items" in write["properties"]["sources"]["description"]


def test_exact_pins_are_allowed_but_nothing_looser(tmp_path):
    ws = make_workspace(tmp_path)
    argv = ws.translate_command("pip install pytest==9.1.1 duckdb==1.5.0 sqlglot[rs]==30.24.0")
    assert argv[1:] == [
        "-m",
        "pip",
        "install",
        "-q",
        "pytest==9.1.1",
        "duckdb==1.5.0",
        "sqlglot[rs]==30.24.0",
    ]
    for bad in [
        "pip install pytest",
        "pip install pytest>=9",
        "pip install git+https://x/y",
        "pip install --index-url http://evil pytest==9.1.1",
        "pip install -U pytest==9.1.1",
    ]:
        with pytest.raises(WorkspaceError):
            ws.translate_command(bad)
