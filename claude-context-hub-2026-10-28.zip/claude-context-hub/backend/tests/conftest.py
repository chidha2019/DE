"""Shared fixtures. Tests here never touch Postgres/Neo4j — repositories are faked."""

from __future__ import annotations

import os

import pytest

# Deterministic, dependency-free settings for every test process.
os.environ.setdefault("ECH_EMBEDDING_PROVIDER", "hashing")
os.environ.setdefault("ECH_RERANKER_PROVIDER", "heuristic")
os.environ.setdefault("ECH_LOG_LEVEL", "WARNING")
os.environ.setdefault("ECH_METRICS_ENABLED", "true")

from ech_core.config import Settings, get_settings  # noqa: E402


@pytest.fixture(scope="session")
def settings() -> Settings:
    get_settings.cache_clear()
    return Settings(_env_file=None)


@pytest.fixture
def sample_markdown() -> str:
    return """# Atlas Platform — Architecture Overview

Owner: Priya Natarajan · Reviewer: Marcus Feld · Status: Approved

## Context

Atlas Platform (ATLAS) is the internal developer platform that provisions Kubernetes workloads.
The system is owned by Priya Natarajan and maintained by Lena Okafor, Daniel Brooks. Atlas Platform
depends on Helios Identity: outages there propagate into ATLAS incident reviews.

## Architecture

The service is implemented with Kubernetes and Terraform, persists state in ArgoCD and relies on
Go, Prometheus, Helm for the remaining platform concerns. All components are deployed through
Atlas Platform using ArgoCD and Helm charts. Requests are authenticated by Helios Identity tokens.

```bash
kubectl get pods -n atlas
argocd app sync atlas
```

## Operations

* HighErrorRate: open Grafana and confirm the burn rate.
* QueueBacklog: scale consumers and apply Backpressure.

Service Level Objective: 99.9% monthly availability measured by Sentinel Observability probes.
This is a long paragraph that exists to make sure the chunker has enough material to split on
when the target token budget is small. It keeps talking about Disaster Recovery drills and the
Incident Response plan so the extractor has concepts to find, and about Zero Trust networking.
"""
