"""Intent routes: read-only validation in Snowflake, the route it picks, a table set planned from repository
contracts, the data modeler's proposal and the pipelines generated from both. Snowflake, the repository graph
and the model are fakes; nothing leaves the test."""

from __future__ import annotations

import asyncio
import json
import re
import subprocess
import sys
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

import pytest
from test_intents import FakeGlossary, FakeRepo

from ech_core.exceptions import InvalidRequestError
from ech_core.llm.client import ModelTurn
from ech_core.schemas.intents import (
    IntentRoute,
    IntentValidation,
    StructuredIntent,
    ValidatedObject,
)
from query_service.intents import generator
from query_service.intents.modeler import DataModeler
from query_service.intents.parser import rule_parse
from query_service.intents.planner import Planner, render_spec_markdown
from query_service.intents.route import choose_route, route_stages
from query_service.intents.service import IntentService
from query_service.intents.tableset import find_files, is_table_set, match_sources
from query_service.intents.validate import Expectation, ReadOnlySql, validate
from query_service.intents.workflow import build_workflow

REPO = "acme/lake"
CHECK = "select '{name}' check_name,count(*) FAILURES from ({inner}) violations"


# --------------------------------------------------------------------------- fakes
class FakeSnowflake:
    """Answers the validator's and the modeler's read-only statements from a small catalogue."""

    def __init__(
        self,
        tables: dict[str, list[str]] | None = None,
        *,
        volumes: tuple[str, ...] = (),
        integrations: tuple[str, ...] = (),
        stages: dict[str, str] | None = None,
    ) -> None:
        self.tables = {k.upper(): v for k, v in (tables or {}).items()}  # DB.SCHEMA.TABLE -> columns
        self.volumes = volumes
        self.integrations = integrations
        self.stages = {k.upper(): v for k, v in (stages or {}).items()}  # DB.SCHEMA.STAGE -> url
        self.sent: list[str] = []

    def _dbs(self) -> set[str]:
        return {t.split(".")[0] for t in self.tables}

    async def query(self, statement: str) -> list[dict[str, Any]]:
        self.sent.append(statement)
        if m := re.match(r"SHOW DATABASES LIKE '(\w+)'", statement):
            return [{"name": m.group(1)}] if m.group(1) in self._dbs() else []
        if m := re.match(r"SHOW EXTERNAL VOLUMES LIKE '(\w+)'", statement):
            return [{"name": m.group(1)}] if m.group(1) in self.volumes else []
        if m := re.match(r"SHOW INTEGRATIONS LIKE '(\w+)'", statement):
            return [{"name": m.group(1), "enabled": "true"}] if m.group(1) in self.integrations else []
        if m := re.match(r"SHOW STAGES LIKE '(\w+)' IN SCHEMA \"(\w+)\"\.\"(\w+)\"", statement):
            schema = f"{m.group(2)}.{m.group(3)}"
            if not any(t.startswith(schema + ".") for t in (*self.tables, *self.stages)):
                raise RuntimeError("SQL compilation error: Object does not exist, or operation cannot be performed.")  # an invisible schema
            url = self.stages.get(f"{schema}.{m.group(1)}")
            return [{"name": m.group(1), "url": url, "storage_integration": "AZ_INT"}] if url else []
        db = re.search(r'FROM "(\w+)"\.INFORMATION_SCHEMA', statement)
        if db and "SCHEMATA" in statement:
            return [{"schema_name": s} for s in sorted({t.split(".")[1] for t in self.tables if t.startswith(db.group(1) + ".")})]
        if db and ".TABLES" in statement:
            return [{"table_schema": t.split(".")[1], "table_name": t.split(".")[2], "table_type": "BASE TABLE", "row_count": 2} for t in self.tables if t.startswith(db.group(1) + ".")]
        if db and ".COLUMNS" in statement:
            return [
                {"table_schema": t.split(".")[1], "table_name": t.split(".")[2], "column_name": c}
                for t, cols in self.tables.items()
                if t.startswith(db.group(1) + ".")
                for c in cols
            ]
        if statement.startswith("EXPLAIN"):
            return []
        if "COUNT(DISTINCT" in statement and "BLANK_KEYS" in statement:
            return [{"n": 2, "keys": 2, "blank_keys": 0}]
        return [{"CLAIM_SK": "C1"}]


class FakeReader:
    def __init__(self, snowflake: FakeSnowflake | None) -> None:
        self.snowflake = snowflake

    @asynccontextmanager
    async def session(self) -> AsyncIterator[ReadOnlySql | None]:
        yield ReadOnlySql(self.snowflake) if self.snowflake is not None else None


def _check(name: str, inner: str, others: list[str] | None = None) -> dict[str, Any]:
    return {"name": name, "rule": name.rsplit(".", 1)[-1], "sql": CHECK.format(name=name, inner=inner), "others": others or [], "params": []}


SOURCES = [
    {"repo": REPO, "source": "claim", "headers": ["Claim_Id", "Cust_Id", "Claim_Amount", "Currency"], "path": "core/claim.csv", "system": "core", "table": "BRONZE.A_CLAIM", "volume": "LAKE_VOL", "load_mode": "FULL_INGEST"},
    {"repo": REPO, "source": "customer", "headers": ["Cust_Id", "Name"], "path": "core/customer.csv", "system": "core", "table": "BRONZE.A_CUSTOMER", "volume": "LAKE_VOL", "load_mode": "FULL_INGEST"},
]
EXEMPLARS: dict[str, dict[str, Any]] = {
    "BRONZE.A_CLAIM": {
        "repo": REPO,
        "url": "https://github.com/acme/lake",
        "sha": "abc",
        "table": {"name": "BRONZE.A_CLAIM", "key": ["CLAIM_ID"], "external_volume": "LAKE_VOL"},
        "columns": [
            {"column": "CLAIM_ID", "type": "STRING", "required": True, "is_key": True},
            {"column": "CUST_ID", "type": "STRING", "required": True},
            {"column": "CLAIM_AMOUNT", "type": "STRING", "required": True},
            {"column": "CURRENCY", "type": "STRING", "required": True},
        ],
        "checks": [
            _check("A_CLAIM.CUST_ID.reference", "select 1 from BRONZE.A_CLAIM c left join BRONZE.A_CUSTOMER p on c.CUST_ID=p.CUST_ID where c.CUST_ID is not null and p.CUST_ID is null", ["BRONZE.A_CUSTOMER"]),
            _check("A_CLAIM.unique", "select CLAIM_ID from BRONZE.A_CLAIM group by CLAIM_ID having count(*)>1"),
            _check("A_CLAIM.CURRENCY.required", "select 1 from BRONZE.A_CLAIM where CURRENCY is null"),
            _check("A_CLAIM.CLAIM_AMOUNT.decimal", "select 1 from BRONZE.A_CLAIM where CLAIM_AMOUNT is not null and not regexp_like(CLAIM_AMOUNT, '^-?[0-9]+([.][0-9]+)?$')"),
            _check("A_CLAIM.policy_ref", "select 1 from BRONZE.A_CLAIM c left join BRONZE.A_POLICY p on c.CLAIM_ID=p.CLAIM_ID where p.CLAIM_ID is null", ["BRONZE.A_POLICY"]),
        ],
        "downstream": [{"key": f"{REPO}|table|SILVER.FACT_CLAIM", "name": "SILVER.FACT_CLAIM", "layer": "silver", "files": ["sql/silver/fact_claim.sql"], "reads": ["BRONZE.A_CLAIM"], "affects": [], "columns": []}],
    },
    "BRONZE.A_CUSTOMER": {
        "repo": REPO,
        "url": None,
        "sha": None,
        "table": {"name": "BRONZE.A_CUSTOMER", "key": ["CUST_ID"], "external_volume": "LAKE_VOL"},
        "columns": [{"column": "CUST_ID", "type": "STRING", "required": True, "is_key": True}, {"column": "NAME", "type": "STRING", "required": False}],
        "checks": [_check("A_CUSTOMER.unique", "select CUST_ID from BRONZE.A_CUSTOMER group by CUST_ID having count(*)>1")],
        "downstream": [],
    },
    "SILVER.FACT_CLAIM": {
        "repo": REPO,
        "url": None,
        "sha": None,
        "table": {"name": "SILVER.FACT_CLAIM", "table": "FACT_CLAIM", "key": ["CLAIM_SK"], "grain": ["CLAIM_SK"], "external_volume": "LAKE_VOL"},
        "columns": [
            {"column": "CLAIM_SK", "type": "STRING", "upstream": ["BRONZE.A_CLAIM.CLAIM_ID"]},
            {"column": "AMOUNT", "type": "NUMBER(18,2)", "upstream": ["BRONZE.A_CLAIM.CLAIM_AMOUNT"]},
        ],
        "checks": [],
        "downstream": [],
    },
}


class FakeGraph:
    async def conventions(self) -> list[dict[str, Any]]:
        return [
            {
                "repo": REPO,
                "ref": "main",
                "stages": [{"stage": "INGESTION.LANDING", "integration": "LAKE_READ"}],
                "volumes": [{"name": "LAKE_VOL", "base_url": "s3://x/"}],
                "pipelines": [],
                "sources": SOURCES,
                "tables": [
                    {"repo": REPO, "name": "BRONZE.A_CLAIM", "layer": "bronze"},
                    {"repo": REPO, "name": "BRONZE.A_CUSTOMER", "layer": "bronze"},
                    {"repo": REPO, "name": "SILVER.FACT_CLAIM", "layer": "silver"},
                ],
            }
        ]

    async def exemplar(self, repo: str, table: str) -> dict[str, Any] | None:
        return EXEMPLARS.get(table)


def _files(tmp_path: Path, *, extra: bool = False) -> Path:
    root = tmp_path / "data" / "landing_files"
    (root / "core").mkdir(parents=True)
    (root / "core" / "claim.csv").write_text("Claim_Id,Cust_Id,Claim_Amount\nC1,K1,10.50\nC2,K9,abc\n", encoding="utf-8")
    (root / "core" / "customer.csv").write_text("Cust_Id,Name\nK1,Ann\nK2,Bob\n", encoding="utf-8")
    if extra:
        (root / "other").mkdir()
        (root / "other" / "notes.csv").write_text("id,text\n1,hello\n", encoding="utf-8")
    return root


def _planner(tmp_path: Path) -> Planner:
    return Planner(semantic=None, glossary=FakeGlossary(), data_dir=tmp_path / "data", repo_graph=FakeGraph())  # type: ignore[arg-type]


BRONZE_TICKET = (
    "Load the CSV files in C:\\Users\\me\\Downloads\\exports\\landing_files to LAKE.BRONZE.A_<FILE> as Snowflake managed Iceberg tables, "
    "one table per file, full refresh hourly."
)


# --------------------------------------------------------------------------- read-only guard and validation
def test_validation_sends_only_read_only_statements():
    sql = ReadOnlySql(FakeSnowflake())
    for statement in ("SELECT 1", "SHOW DATABASES LIKE 'X'", "EXPLAIN USING TEXT SELECT 1", "WITH a AS (SELECT 1) SELECT * FROM a", "SELECT 'DROP TABLE x' AS note"):
        asyncio.run(sql.query(statement))
    for statement in ("DROP TABLE X", "CREATE DATABASE X", "SELECT 1; DROP TABLE X", "WITH a AS (SELECT 1) INSERT INTO t SELECT * FROM a", "COPY INTO t FROM @s", "  truncate table t"):
        with pytest.raises(InvalidRequestError):
            asyncio.run(sql.query(statement))


def test_validation_finds_what_exists_and_what_is_missing():
    expect = Expectation(target_database="LAKE", target_schema="BRONZE", target_tables=["A_CLAIM", "A_CUSTOMER"], external_volume="LAKE_VOL", integration="LAKE_READ")
    missing = asyncio.run(validate(ReadOnlySql(FakeSnowflake(integrations=("LAKE_READ",))), expect))
    assert missing.reachable and not missing.find("database", "LAKE").exists  # type: ignore[union-attr]
    assert "Database LAKE does not exist yet" in missing.summary and "0 of 2 target tables exist" in missing.summary
    assert "external volume LAKE_VOL is missing" in missing.summary and "LAKE_READ" not in missing.summary

    half = asyncio.run(validate(ReadOnlySql(FakeSnowflake({"LAKE.BRONZE.A_CLAIM": ["CLAIM_ID"]}, volumes=("LAKE_VOL",))), expect))
    claim = half.find("table", "LAKE.BRONZE.A_CLAIM")
    assert claim is not None and claim.exists and claim.columns == ["CLAIM_ID"] and claim.rows == 2
    assert "1 of 2 target tables exist" in half.summary

    offline = asyncio.run(validate(None, expect))
    assert not offline.reachable and offline.summary.startswith("Not validated")


# --------------------------------------------------------------------------- routes
def _validation(*objects: ValidatedObject) -> IntentValidation:
    from datetime import UTC, datetime

    return IntentValidation(checked_at=datetime.now(tz=UTC), reachable=True, objects=list(objects))


def _table(name: str, role: str, exists: bool) -> ValidatedObject:
    return ValidatedObject(kind="table", name=name, role=role, exists=exists)  # type: ignore[arg-type]


def test_the_route_follows_what_snowflake_has():
    ingest = StructuredIntent(kind="ingest_csv_to_iceberg")
    expect = Expectation(target_database="LAKE", target_schema="BRONZE", target_tables=["A", "B"])
    assert choose_route(ingest, expect, _validation(_table("LAKE.BRONZE.A", "target", False), _table("LAKE.BRONZE.B", "target", False))).key == "ingest_new"
    assert choose_route(ingest, expect, _validation(_table("LAKE.BRONZE.A", "target", True), _table("LAKE.BRONZE.B", "target", True))).key == "ingest_existing"
    partly = choose_route(ingest, expect, _validation(_table("LAKE.BRONZE.A", "target", True), _table("LAKE.BRONZE.B", "target", False)))
    assert partly.key == "ingest_new" and "1 of 2" in partly.reason

    silver = StructuredIntent(kind="model_layer", layer="silver", depends_on=["KAN-3"])
    expect = Expectation(target_database="LAKE", target_schema="SILVER", source_database="LAKE", source_schema="BRONZE", source_tables=["A"])
    waiting = choose_route(silver, expect, _validation(_table("LAKE.BRONZE.A", "source", False)))
    assert waiting.key == "wait_upstream" and waiting.waits_on == ["KAN-3"] and "KAN-3" in waiting.reason
    assert choose_route(silver, expect, _validation(_table("LAKE.BRONZE.A", "source", True))).key == "model_new"
    both = _validation(_table("LAKE.BRONZE.A", "source", True), _table("LAKE.SILVER.F", "target", True))
    assert choose_route(silver, expect, both).key == "model_existing"
    unchecked = choose_route(silver, expect, None)
    assert unchecked.key == "model_new" and "not checked" in unchecked.reason
    assert choose_route(StructuredIntent(kind="other"), expect, None).key == "manual"


def test_route_stages_follow_the_status():
    route = IntentRoute(key="wait_upstream", title="Wait", reason="", waits_on=["KAN-3"])
    stages = {s.key: s for s in route_stages(route, "waiting", validated=True)}
    assert [stages[k].status for k in ("read", "review", "validate", "wait", "model")] == ["done", "done", "done", "blocked", "pending"]
    assert stages["wait"].detail == "KAN-3" and stages["validate"].detail == "checked in Snowflake"

    model = IntentRoute(key="model_new", title="Model", reason="")
    proposed = {s.key: s.status for s in route_stages(model, "spec_proposed", validated=True)}
    assert proposed["model"] == "done" and proposed["approve"] == "current" and proposed["catalog"] == "pending"
    rejected = {s.key: s for s in route_stages(model, "rejected", validated=False)}
    assert rejected["approve"].status == "blocked" and rejected["approve"].detail == "rejected" and rejected["generate"].status == "skipped"
    assert rejected["validate"].status == "skipped"
    assert all(s.status == "done" for s in route_stages(model, "done", validated=True))
    asking = {s.key: s.status for s in route_stages(model, "clarifying", validated=True)}
    assert asking["review"] == "current" and asking["validate"] == "done"  # validation ran before the questions


def test_layer_tickets_parse_into_model_intents():
    silver = rule_parse("Build silver", "On the LAKE.BRONZE layer we need to build the silver layer. Depends on KAN-3.")
    assert (silver.kind, silver.layer, silver.depends_on) == ("model_layer", "silver", ["KAN-3"])
    assert (silver.source.database, silver.source.schema_name, silver.target.schema_name, silver.target.table) == ("LAKE", "BRONZE", "SILVER", None)
    assert not silver.open_questions
    gold = rule_parse("Gold", "From the silver to gold (curated).")
    assert gold.kind == "model_layer" and gold.layer == "gold" and gold.source.schema_name == "SILVER" and gold.open_questions


# --------------------------------------------------------------------------- the bronze route: a table set
def test_files_match_the_repository_sources_by_path_then_by_name(tmp_path: Path):
    root = _files(tmp_path, extra=True)
    files = find_files(root)
    assert [f.rel for f in files] == ["core/claim.csv", "core/customer.csv", "other/notes.csv"] and is_table_set(files)
    matched = match_sources(files, asyncio.run(FakeGraph().conventions()))
    assert [(m.table, m.matched_by, m.qualified) for m in matched] == [
        ("A_CLAIM", "path", "BRONZE.A_CLAIM"),
        ("A_CUSTOMER", "path", "BRONZE.A_CUSTOMER"),
        ("NOTES", "name", None),
    ]


def test_a_path_from_the_reporters_machine_resolves_to_its_tail_under_the_data_dir(tmp_path: Path):
    root = _files(tmp_path)
    planner = _planner(tmp_path)
    assert planner.resolve_folder("C:\\Users\\me\\Downloads\\exports\\landing_files") == root.resolve()
    assert planner.resolve_folder("../../etc") is None


def test_a_table_set_is_planned_from_the_contracts(tmp_path: Path):
    _files(tmp_path)
    planner = _planner(tmp_path)
    intent = rule_parse("Load the landing files", BRONZE_TICKET)
    intent.target.external_volume = None
    expect = asyncio.run(planner.expectations(intent))
    assert expect.target_tables == ["A_CLAIM", "A_CUSTOMER"] and expect.identifiers_known and expect.integration == "LAKE_READ"
    validation = asyncio.run(validate(ReadOnlySql(FakeSnowflake()), expect))
    spec = asyncio.run(planner.plan(intent, "Load the landing files", validation))

    assert spec.name == "ingest_lake_bronze" and spec.create == ["database", "schema"] and spec.target.external_volume == "LAKE_VOL"
    claim = next(t for t in spec.tables if t.name == "A_CLAIM")
    assert claim.keys == ["CLAIM_ID"] and claim.source_file == "core/claim.csv" and claim.missing_columns == ["CURRENCY"]
    assert {c.type for c in claim.columns} == {"VARCHAR"}  # STRING in the contract
    tests = {t.name: t for t in claim.tests}
    reference = tests["cust_id_reference"]
    assert reference.kind == "query" and "LAKE.BRONZE.A_CUSTOMER" in (reference.condition or "") and reference.sample_failures == 1  # K9 has no customer
    assert tests["claim_amount_decimal"].kind == "condition" and tests["claim_amount_decimal"].sample_failures == 1  # "abc"
    outcomes = {a.name: a.outcome for a in claim.exemplar_checks}
    assert outcomes["A_CLAIM.CURRENCY.required"] == "skipped" and outcomes["A_CLAIM.policy_ref"] == "skipped" and outcomes["A_CLAIM.unique"] == "copied"
    assert any("A_CLAIM (CURRENCY)" in r for r in spec.risks) and any(r.startswith("External volume LAKE_VOL is not visible") for r in spec.risks)
    assert [d.table for d in spec.downstream] == ["SILVER.FACT_CLAIM"]
    markdown = render_spec_markdown(spec, validation)
    assert "Tables (2)" in markdown and "A_CLAIM ← core/claim.csv" in markdown and "Database LAKE does not exist yet" in markdown


def test_the_generated_table_set_pipeline_runs_its_own_tests(tmp_path: Path):
    _files(tmp_path)
    planner = _planner(tmp_path)
    intent = rule_parse("Load the landing files", BRONZE_TICKET)
    validation = asyncio.run(validate(ReadOnlySql(FakeSnowflake()), asyncio.run(planner.expectations(intent))))
    spec = asyncio.run(planner.plan(intent, "Load the landing files", validation))
    files = generator.generate(spec)
    assert files["sql/010_setup.sql"].startswith("-- objects the read-only validation found missing\nCREATE DATABASE IF NOT EXISTS LAKE;\nCREATE SCHEMA IF NOT EXISTS LAKE.BRONZE;")
    assert files["sql/020_table.sql"].count("CREATE ICEBERG TABLE IF NOT EXISTS") == 2
    assert "PATTERN = '.*core/claim\\.csv'" in files["sql/030_load.sql"] and "TRUNCATE TABLE IF EXISTS LAKE.BRONZE.A_CUSTOMER" in files["sql/030_load.sql"]
    assert "SELECT 'A_CLAIM.cust_id_reference' AS check_name, COUNT(*) AS failures FROM (SELECT 1 FROM LAKE.BRONZE.A_CLAIM" in files["sql/040_checks.sql"]
    assert "CREATE OR REPLACE TASK LAKE.BRONZE.INGEST_LAKE_BRONZE_TASK" in files["sql/050_task.sql"]
    assert "relative_to(root).as_posix()" in files["pipeline.py"]
    folder = tmp_path / "pipelines" / spec.name
    for rel, content in files.items():
        (folder / rel).parent.mkdir(parents=True, exist_ok=True)
        (folder / rel).write_text(content, encoding="utf-8")
    run = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "tests"], cwd=folder, capture_output=True, text=True, timeout=180)  # noqa: S603
    assert run.returncode == 0, run.stdout + run.stderr


# --------------------------------------------------------------------------- the data modeler and the silver build
class FakeModel:
    """Tries its SQL once, then answers with a proposal of two tables, one of them wrong."""

    def __init__(self) -> None:
        self.calls = 0
        self.seen_tools: list[str] = []

    async def complete(self, *, system: str, tools: list[dict[str, Any]], messages: list[dict[str, Any]]) -> ModelTurn:
        self.calls += 1
        self.seen_tools = [t["name"] for t in tools]
        if self.calls == 1:
            return ModelTurn(
                content=[
                    {"type": "tool_use", "id": "t1", "name": "repo_model", "input": {"name": "SILVER.FACT_CLAIM"}},
                    {"type": "tool_use", "id": "t2", "name": "test_sql", "input": {"sql": "SELECT c.CLAIM_ID AS CLAIM_SK FROM LAKE.BRONZE.A_CLAIM c", "key": ["CLAIM_SK"]}},
                ],
                stop_reason="tool_use",
            )
        results = messages[-1]["content"]
        assert '"CLAIM_SK"' in results[0]["content"] and '"compiles": true' in results[1]["content"]
        proposal = {
            "models": [
                {
                    "name": "FACT_CLAIM",
                    "kind": "fact",
                    "grain": "one row per claim",
                    "keys": ["CLAIM_SK"],
                    "sources": ["LAKE.BRONZE.A_CLAIM"],
                    "sql": "SELECT c.CLAIM_ID AS CLAIM_SK, TRY_TO_DECIMAL(c.CLAIM_AMOUNT, 18, 2) AS AMOUNT FROM LAKE.BRONZE.A_CLAIM c",
                    "columns": [
                        {"name": "CLAIM_SK", "type": "VARCHAR", "expression": "c.CLAIM_ID", "nullable": False, "sources": ["BRONZE.A_CLAIM.CLAIM_ID"]},
                        {"name": "AMOUNT", "type": "NUMBER(18,2)", "expression": "TRY_TO_DECIMAL(c.CLAIM_AMOUNT, 18, 2)"},
                    ],
                    "relationships": [{"columns": ["CUSTOMER_SK"], "to_table": "DIM_CUSTOMER", "to_columns": ["CUSTOMER_SK"]}],
                    "exemplar": "SILVER.FACT_CLAIM",
                    "deviations": [],
                },
                {
                    "name": "DIM_CUSTOMER",
                    "kind": "dimension",
                    "grain": "one row per customer",
                    "keys": ["CUSTOMER_SK"],
                    "sources": ["LAKE.BRONZE.A_CUSTOMER"],
                    "sql": "SELECT p.CUST_ID AS CUSTOMER_SK, p.SEGMENT AS SEGMENT FROM LAKE.BRONZE.A_CUSTOMER p",
                    "columns": [{"name": "CUSTOMER_SK", "type": "VARCHAR", "expression": "p.CUST_ID"}, {"name": "SEGMENT", "type": "VARCHAR", "expression": "p.SEGMENT"}],
                    "exemplar": None,
                },
            ],
            "notes": ["DIM_CUSTOMER is new: the repository has no customer dimension."],
        }
        return ModelTurn(content=[{"type": "text", "text": json.dumps(proposal)}], stop_reason="end_turn")


SILVER_TICKET = "On LAKE.BRONZE we need to build the silver layer. Depends on KAN-3."
LOADED = {"LAKE.BRONZE.A_CLAIM": ["CLAIM_ID", "CUST_ID", "CLAIM_AMOUNT"], "LAKE.BRONZE.A_CUSTOMER": ["CUST_ID", "NAME"]}


def test_the_data_modeler_proposes_and_its_proposal_is_checked(tmp_path: Path):
    snowflake = FakeSnowflake(LOADED, volumes=("LAKE_VOL",))
    reader = FakeReader(snowflake)
    model = FakeModel()
    planner = _planner(tmp_path)
    modeler = DataModeler(model=model, reader=reader, repo_graph=FakeGraph())  # type: ignore[arg-type]
    intent = rule_parse("Build silver", SILVER_TICKET)
    expect = asyncio.run(planner.expectations(intent))
    assert expect.source_tables == ["A_CLAIM", "A_CUSTOMER"] and expect.target_tables == ["FACT_CLAIM"]
    validation = asyncio.run(validate(ReadOnlySql(snowflake), expect))
    spec = asyncio.run(modeler.model(intent, "Build silver", expect, validation))

    assert model.seen_tools == ["profile_columns", "repo_model", "test_sql"] and spec.kind == "model_layer"
    fact, dim = spec.models
    assert fact.findings == ["compiles in Snowflake; key CLAIM_SK unique over 2 rows"] and fact.exemplar == "SILVER.FACT_CLAIM"
    assert any("A_CUSTOMER.SEGMENT" in f for f in dim.findings) and any(r.startswith("DIM_CUSTOMER: uses columns") for r in spec.risks)
    assert {t.kind for t in fact.tests} >= {"row_count", "unique", "not_null"}
    assert "DIM_CUSTOMER is new: the repository has no customer dimension." in spec.assumptions
    assert all(re.match(r"^\s*(SELECT|SHOW|EXPLAIN|WITH|DESCRIBE)", s, re.I) for s in snowflake.sent)  # read-only throughout

    files = generator.generate(spec)
    assert files["sql/010_setup.sql"].endswith("CREATE SCHEMA IF NOT EXISTS LAKE.SILVER;\n")
    load = files["sql/030_load.sql"]
    assert load.index("-- DIM_CUSTOMER") > 0 and "INSERT INTO LAKE.SILVER.FACT_CLAIM (CLAIM_SK, AMOUNT, _LOADED_AT)" in load
    assert "LEFT JOIN LAKE.SILVER.DIM_CUSTOMER b ON a.CUSTOMER_SK = b.CUSTOMER_SK" in files["sql/040_checks.sql"]
    folder = tmp_path / "pipelines" / spec.name
    for rel, content in files.items():
        (folder / rel).parent.mkdir(parents=True, exist_ok=True)
        (folder / rel).write_text(content, encoding="utf-8")
    run = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "tests"], cwd=folder, capture_output=True, text=True, timeout=180)  # noqa: S603
    assert run.returncode == 0, run.stdout + run.stderr


# --------------------------------------------------------------------------- the service follows the route
def _service(tmp_path: Path, snowflake: FakeSnowflake, model: Any = None) -> tuple[IntentService, FakeRepo]:
    repo = FakeRepo()
    reader = FakeReader(snowflake)
    planner = _planner(tmp_path)
    service = IntentService(
        repo=repo,  # type: ignore[arg-type]
        planner=planner,
        model=None,
        glossary=FakeGlossary(),  # type: ignore[arg-type]
        workspace_dir=tmp_path / "pipelines",
        data_dir=tmp_path / "data",
        snowflake_reader=reader,  # type: ignore[arg-type]
        modeler=DataModeler(model=model, reader=reader, repo_graph=FakeGraph()),  # type: ignore[arg-type]
        background_modeling=False,
    )
    return service, repo


def test_a_silver_intent_waits_for_its_bronze_tables_then_is_modelled(tmp_path: Path):
    snowflake = FakeSnowflake(volumes=("LAKE_VOL",))
    service, _ = _service(tmp_path, snowflake, FakeModel())
    from ech_core.schemas.intents import IntentCreate

    record = asyncio.run(service.create(IntentCreate(title="Build silver", text=SILVER_TICKET)))
    assert record.status == "waiting" and record.route is not None and record.route.key == "wait_upstream" and record.route.waits_on == ["KAN-3"]
    assert [s.status for s in record.route.stages][:4] == ["done", "done", "done", "blocked"]

    snowflake.tables.update(LOADED)  # KAN-3's load has run
    record = asyncio.run(service.revalidate(record.id))
    assert record.status == "spec_proposed" and record.route is not None and record.route.key == "model_new"
    assert record.spec is not None and [m.name for m in record.spec.models] == ["FACT_CLAIM", "DIM_CUSTOMER"]
    assert [w.kind for w in record.workflow][:4] == ["source", "model", "table", "load"]
    assert record.review is not None and next(c for c in record.review.checks if c.key == "target").status == "ok"


def test_a_bronze_intent_with_contract_keys_asks_no_identifier_question(tmp_path: Path):
    _files(tmp_path)
    service, repo = _service(tmp_path, FakeSnowflake())
    record = asyncio.run(service.create(__import__("ech_core.schemas.intents", fromlist=["IntentCreate"]).IntentCreate(title="Load the landing files", text=BRONZE_TICKET)))
    row = repo.rows[record.id]
    intent = StructuredIntent.model_validate(row["intent"])
    intent.open_questions = ["Which column is the identifier column for each of the files?"]
    row.update(status="clarifying", questions=[])
    asyncio.run(service._advance(record.id, row, intent))  # noqa: SLF001 - the question a model would have asked
    record = asyncio.run(service.get(record.id))
    assert record.status == "spec_proposed" and record.route is not None and record.route.key == "ingest_new"
    assert record.spec is not None and len(record.spec.tables) == 2 and record.validation is not None and record.validation.reachable
    assert [w.kind for w in record.workflow][:5] == ["prepare", "source", "land", "stage", "table"]


class _ParserModel:
    """Reads the ticket's volume and integration, as a model that missed the answer would."""

    async def complete(self, *, system: str, tools: list[dict[str, Any]], messages: list[dict[str, Any]]) -> ModelTurn:
        answer = {
            "kind": "ingest_csv_to_iceberg",
            "summary": "Load the landing files",
            "source": {"folder": "landing_files", "storage_integration": "LAKE_READ"},
            "target": {"database": "LAKE", "schema": "BRONZE", "external_volume": "LAKE_VOL", "load_mode": "full_refresh"},
            "open_questions": [],
            "confidence": 0.9,
        }
        return ModelTurn(content=[{"type": "text", "text": json.dumps(answer)}], stop_reason="end_turn")


def test_an_answer_overrides_the_volume_and_integration_and_the_plan_uses_them(tmp_path: Path):
    from query_service.intents.parser import parse_intent

    ticket = BRONZE_TICKET + " Use external volume LAKE_VOL and storage integration LAKE_READ."
    answer = "Use external volume ECH_ICEBERG_VOL and storage integration ECH_S3_INT instead of the repo's names."
    rules = rule_parse("Load the landing files", f"{ticket}\n{answer}")
    assert (rules.target.external_volume, rules.source.storage_integration) == ("ECH_ICEBERG_VOL", "ECH_S3_INT")
    intent = asyncio.run(parse_intent(_ParserModel(), title="Load the landing files", text=ticket, answers=[answer], glossary_names=[], data_dir="data"))  # type: ignore[arg-type]
    assert (intent.target.external_volume, intent.source.storage_integration) == ("ECH_ICEBERG_VOL", "ECH_S3_INT")

    _files(tmp_path)
    planner = _planner(tmp_path)
    expect = asyncio.run(planner.expectations(intent))
    assert (expect.external_volume, expect.integration) == ("ECH_ICEBERG_VOL", "ECH_S3_INT")
    validation = asyncio.run(validate(ReadOnlySql(FakeSnowflake(volumes=("ECH_ICEBERG_VOL",), integrations=("ECH_S3_INT",))), expect))
    assert "ECH_ICEBERG_VOL" not in validation.summary and "ECH_S3_INT" not in validation.summary
    spec = asyncio.run(planner.plan(intent, "Load the landing files", validation))
    assert spec.target.external_volume == "ECH_ICEBERG_VOL" and spec.source.storage_integration == "ECH_S3_INT"
    assert "Storage integration ECH_S3_INT as the ticket says, instead of LAKE_READ, which acme/lake lands files through." in spec.assumptions
    assert "External volume ECH_ICEBERG_VOL as the ticket says, instead of LAKE_VOL, which acme/lake uses." in spec.assumptions
    assert not any("ECH_S3_INT is not visible" in r or "ECH_ICEBERG_VOL is not visible" in r for r in spec.risks)
    files = generator.generate(spec)
    assert "  STORAGE_INTEGRATION = ECH_S3_INT\n" in files["sql/010_setup.sql"]
    assert files["sql/020_table.sql"].count("EXTERNAL_VOLUME = 'ECH_ICEBERG_VOL'") == 2


def test_a_same_named_file_with_other_columns_does_not_take_that_contract(tmp_path: Path):
    root = tmp_path / "flat"
    root.mkdir()
    (root / "claim.csv").write_text("claim_id,claim_name,insurance_id,claim_amount,cs_id\n1,Fire,7,100,1\n", encoding="utf-8")
    (root / "customer.csv").write_text("Cust_Id,Name\nK1,Ann\n", encoding="utf-8")
    matched = {m.file.rel: m for m in match_sources(find_files(root), asyncio.run(FakeGraph().conventions()))}
    assert matched["customer.csv"].table == "A_CUSTOMER" and matched["customer.csv"].matched_by == "path"  # same name, same columns
    assert matched["claim.csv"].table == "CLAIM" and matched["claim.csv"].qualified is None  # same name, other columns
    assert matched["claim.csv"].file.rows == 1


def test_checks_across_tables_wait_for_the_load_when_a_file_was_only_partly_read(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    import query_service.intents.planner as planner_module

    monkeypatch.setattr(planner_module, "TABLE_SET_ROWS", 1)
    _files(tmp_path)
    planner = _planner(tmp_path)
    intent = rule_parse("Load the landing files", BRONZE_TICKET)
    spec = asyncio.run(planner.plan(intent, "Load the landing files", None))
    claim = next(t for t in spec.tables if t.name == "A_CLAIM")
    reference = next(t for t in claim.tests if t.name == "cust_id_reference")
    assert reference.sample_failures is None  # one row of each file proves nothing about orphans
    assert claim.rows == 2  # the file's rows, not the rows read
    assert any("have more than 1 rows" in a and "run after the load" in a for a in spec.assumptions)


def test_central_european_files_are_read_and_loaded_as_windows_1250(tmp_path: Path):
    from query_service.intents.tableset import detect_encoding

    root = tmp_path / "data" / "landing_files"
    root.mkdir(parents=True)
    (root / "street.csv").write_bytes("street_id,street_name\n1,Złota\n2,Ogrodowa\n".encode("cp1250"))
    (root / "city.csv").write_text("city_id,city_name\n1,Lodz\n", encoding="ascii")
    assert detect_encoding((root / "street.csv").read_bytes()) == "cp1250" and detect_encoding("Zürich".encode("latin-1")) == "latin-1"
    files = {f.rel: f for f in find_files(root)}
    assert files["street.csv"].header == ["street_id", "street_name"] and files["street.csv"].rows == 2 and files["city.csv"].encoding == "ascii"
    planner = _planner(tmp_path)
    intent = rule_parse("Load the landing files", BRONZE_TICKET)
    spec = asyncio.run(planner.plan(intent, "Load the landing files", None))
    street = next(t for t in spec.tables if t.name == "A_STREET")  # the ticket names the tables A_<FILE>
    assert [c.name for c in street.columns] == ["STREET_ID", "STREET_NAME"] and street.rows == 2
    assert spec.source.encoding == "cp1250" and any("encoded CP1250" in a and "WINDOWS1250" in a for a in spec.assumptions)
    assert "  ENCODING = 'WINDOWS1250';" in generator.generate(spec)["sql/010_setup.sql"]


def test_a_file_that_reads_the_same_in_both_code_pages_is_not_a_mixed_encoding(tmp_path: Path):
    from query_service.intents.tableset import set_encoding

    root = tmp_path / "files"
    root.mkdir()
    (root / "street.csv").write_bytes("id,name\n1,Złota\n".encode("cp1250"))
    (root / "phone_type.csv").write_bytes("id,name\n1,komórkowy\n".encode("cp1250"))  # ó: the same byte in Latin-1
    (root / "city.csv").write_text("id,name\n1,Lodz\n", encoding="ascii")
    files = find_files(root)
    assert {f.rel: f.encoding for f in files} == {"city.csv": "ascii", "phone_type.csv": "latin-1", "street.csv": "cp1250"}
    assert set_encoding(files) == ("cp1250", [])
    (root / "utf.csv").write_text("id,name\n1,Kraków ż\n", encoding="utf-8")
    assert set_encoding(find_files(root))[1] == ["utf.csv"]


def test_prose_after_external_volume_is_not_a_volume_name():
    text = "Load into OMNICLAIM.BRONZE on an external volume on Azure Blob Storage (name to be confirmed) through an Azure storage integration (name to be confirmed)."
    intent = rule_parse("Load the files", text)
    assert intent.target.external_volume is None and intent.source.storage_integration is None
    assert rule_parse("x", "csv files to A.B.C on external volume ech_iceberg_vol").target.external_volume == "ech_iceberg_vol"
    assert rule_parse("x", "csv files to A.B.C, external volume AZ_VOL, storage integration AZ_INT").source.storage_integration == "AZ_INT"


def test_the_hub_does_not_ask_what_it_reads_from_the_files():
    from query_service.intents.service import _settled

    read = Expectation(files_read=True)
    assert _settled("Which of the 15 files are encoded in Windows-1250, and which are UTF-8?", read)
    assert _settled("What delimiter do the files use?", read)
    assert not _settled("What are the Azure storage account and landing container names?", read)
    assert not _settled("Which files are encoded in Windows-1250?", Expectation())


AZURE_TICKET = (
    "Load the CSV files in C:/Users/me/Downloads/exports/landing_files to LAKE.BRONZE.A_<FILE> as Snowflake managed Iceberg tables, "
    "one table per file, full refresh hourly. Land them in Azure Blob Storage: storage account lakeacct01, container raw-landing. "
    "External volume AZ_ICEBERG_VOL, storage integration AZ_LANDING_INT."
)


def test_an_azure_ticket_names_account_container_and_folder():
    intent = rule_parse("Load the landing files", AZURE_TICKET)
    s = intent.source
    assert (s.storage_provider, s.azure_account, s.azure_container, s.azure_prefix, s.storage_integration) == ("azure", "lakeacct01", "raw-landing", None, "AZ_LANDING_INT")
    url = rule_parse("x", "csv files in data/x land in azure://lakeacct01.blob.core.windows.net/raw-landing/omniclaim/bronze/").source
    assert (url.azure_account, url.azure_container, url.azure_prefix) == ("lakeacct01", "raw-landing", "omniclaim/bronze")
    later = rule_parse("x", "csv files in data/x land in s3://bucket/p. Changed: Azure Blob, storage account is `lakeacct`, container named landing")
    assert (later.source.storage_provider, later.source.azure_account, later.source.azure_container) == ("azure", "lakeacct", "landing")
    pending = rule_parse("x", "csv files in data/x land in Azure Blob Storage; the storage account and container are to be confirmed")
    assert pending.source.azure_account is None and pending.source.azure_container is None
    assert "Which Azure storage account and container do the files land in?" in pending.open_questions


def test_an_azure_plan_stages_from_azure_and_uploads_with_the_azure_sdk(tmp_path: Path):
    from query_service.intents.landing import covers

    _files(tmp_path)
    planner = _planner(tmp_path)
    intent = rule_parse("Load the landing files", AZURE_TICKET)
    snowflake = FakeSnowflake(volumes=("AZ_ICEBERG_VOL",), integrations=("AZ_LANDING_INT",))
    described = {
        'DESCRIBE INTEGRATION "AZ_LANDING_INT"': [
            {"property": "STORAGE_PROVIDER", "property_value": "AZURE"},
            {"property": "STORAGE_ALLOWED_LOCATIONS", "property_value": "azure://lakeacct01.blob.core.windows.net/other/"},
            {"property": "AZURE_MULTI_TENANT_APP_NAME", "property_value": "SnowflakeApp_123"},
        ],
        'DESCRIBE EXTERNAL VOLUME "AZ_ICEBERG_VOL"': [
            {"parent_property": "STORAGE_LOCATIONS", "property": "STORAGE_LOCATION_1", "property_value": json.dumps({"STORAGE_PROVIDER": "AZURE", "STORAGE_BASE_URL": "azure://lakeacct01.blob.core.windows.net/iceberg/"})}
        ],
    }
    original = snowflake.query

    async def query(statement: str) -> list[dict[str, Any]]:
        return described[statement] if statement in described else await original(statement)

    snowflake.query = query  # type: ignore[method-assign]
    validation = asyncio.run(validate(ReadOnlySql(snowflake), asyncio.run(planner.expectations(intent))))
    integration = validation.find("integration", "AZ_LANDING_INT")
    assert integration is not None and integration.properties["STORAGE_PROVIDER"] == "AZURE"
    spec = asyncio.run(planner.plan(intent, "Load the landing files", validation))

    assert spec.source.azure_prefix == "ingest_lake_bronze"  # no folder named: one per pipeline
    url = "azure://lakeacct01.blob.core.windows.net/raw-landing/ingest_lake_bronze/"
    assert any(a.startswith(f"Files land in Azure Blob Storage at {url}") for a in spec.assumptions)
    assert any("Storage Blob Data Reader" in a and "SnowflakeApp_123" in a for a in spec.assumptions)
    assert any(r.startswith("Storage integration AZ_LANDING_INT may not read") for r in spec.risks)  # its allowed location is another container
    assert any(a == "External volume AZ_ICEBERG_VOL keeps the table data at azure://lakeacct01.blob.core.windows.net/iceberg/." for a in spec.assumptions)
    assert covers("azure://lakeacct01.blob.core.windows.net/raw-landing/", url) and covers("*", url) and covers("", url) is None

    files = generator.generate(spec)
    assert f"  URL = '{url}'\n  STORAGE_INTEGRATION = AZ_LANDING_INT\n" in files["sql/010_setup.sql"]
    assert "azure-storage-blob" in files["requirements.txt"] and "boto3" not in files["requirements.txt"]
    runner = files["pipeline.py"]
    assert "BlobServiceClient" in runner and "LANDING_ACCOUNT = 'lakeacct01'" in runner and "LANDING_PREFIX = 'ingest_lake_bronze'" in runner
    assert [w.title for w in build_workflow(spec) if w.kind == "land"] == ["Land in Azure Blob Storage"]
    folder = tmp_path / "pipelines" / spec.name
    for rel, content in files.items():
        (folder / rel).parent.mkdir(parents=True, exist_ok=True)
        (folder / rel).write_text(content, encoding="utf-8")
    run = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "tests"], cwd=folder, capture_output=True, text=True, timeout=180)  # noqa: S603
    assert run.returncode == 0, run.stdout + run.stderr

    # Without account and container, the stage URL and the runner read them from the environment.
    open_spec = spec.model_copy(update={"source": spec.source.model_copy(update={"azure_account": None, "azure_container": None, "azure_prefix": None})})
    open_files = generator.generate(open_spec)
    assert "azure://${AZURE_STORAGE_ACCOUNT}.blob.core.windows.net/${AZURE_CONTAINER}/${AZURE_PREFIX}/" in open_files["sql/010_setup.sql"]
    assert "'AZURE_STORAGE_ACCOUNT', 'AZURE_CONTAINER', 'AZURE_PREFIX'" in open_files["pipeline.py"]


def test_an_s3_integration_for_azure_files_is_a_risk():
    from query_service.intents.planner import landing_findings

    source = rule_parse("x", AZURE_TICKET).source
    wrong = ValidatedObject(kind="integration", name="ECH_S3_INT", role="prerequisite", exists=True, properties={"STORAGE_PROVIDER": "S3"})
    _, risks = landing_findings(source, _validation(wrong))
    assert risks == ["Storage integration ECH_S3_INT reads S3, but the files land in Azure Blob Storage: name a storage integration for Azure Blob Storage."]


def test_a_database_and_layer_without_a_table_name_the_target_of_a_file_load():
    intent = rule_parse("Bronze", "Load the CSV files in data/x into OMNICLAIM.BRONZE as Snowflake-managed Iceberg tables, one per file.")
    assert (intent.target.database, intent.target.schema_name, intent.target.table) == ("OMNICLAIM", "BRONZE", None)


# --------------------------------------------------------------------------- bronze loaded under its own names
LOADED_ELSEWHERE = {
    "LIFE.BRONZE.CUSTOMER_ICEBERG": ["CUST_ID", "NAME"],
    "LIFE.BRONZE.CLAIM_ICEBERG": ["CLAIM_ID", "CLAIM_NAME", "INSURANCE_ID", "CLAIM_AMOUNT", "CS_ID"],
}


def test_a_layer_is_built_from_whatever_its_source_schema_holds(tmp_path: Path):
    planner = _planner(tmp_path)
    intent = rule_parse("Build silver", "On LIFE.BRONZE we need to build the silver layer. Depends on KAN-3.")
    expect = asyncio.run(planner.expectations(intent))
    assert expect.source_tables == ["A_CLAIM", "A_CUSTOMER"]  # what the repository calls them
    empty = asyncio.run(validate(ReadOnlySql(FakeSnowflake()), expect))
    assert choose_route(intent, expect, empty).key == "wait_upstream"  # nothing loaded yet: the expected names are awaited
    loaded = asyncio.run(validate(ReadOnlySql(FakeSnowflake(LOADED_ELSEWHERE)), expect))
    sources = [o.name for o in loaded.objects if o.kind == "table" and o.role == "source"]
    assert sources == ["LIFE.BRONZE.CLAIM_ICEBERG", "LIFE.BRONZE.CUSTOMER_ICEBERG"] and "2 of 2 source tables exist" in loaded.summary
    route = choose_route(intent, expect, loaded)
    assert route.key == "model_new" and "2 source tables in LIFE.BRONZE" in route.reason


def test_repository_tables_are_matched_to_the_loaded_ones_by_name_and_columns():
    from query_service.intents.modeler import ModelContext, match_loaded

    repo = asyncio.run(FakeGraph().conventions())[0]
    loaded = {**LOADED_ELSEWHERE, "LIFE.BRONZE.CLIENTTYPE_ICEBERG": ["CLIENTTYPE_ID", "CLIENTTYPE_NAME"]}
    mapping = match_loaded(repo, "bronze", "BRONZE", loaded)
    assert mapping == {"BRONZE.A_CUSTOMER": "LIFE.BRONZE.CUSTOMER_ICEBERG"}  # A_CLAIM's columns differ from this claim file's
    ctx = ModelContext(layer="silver", upstream="bronze", database="LIFE", target_schema="SILVER", source_schema="BRONZE", sources=loaded, loaded_as=mapping)
    assert ctx.resolve("BRONZE.A_CUSTOMER.CUST_ID") == "LIFE.BRONZE.CUSTOMER_ICEBERG.CUST_ID"
    assert ctx.resolve("BRONZE.A_CLAIM.CLAIM_ID") == "BRONZE.A_CLAIM.CLAIM_ID"  # not loaded: left as the repository has it
    ctx.loaded_as["BRONZE.B_CLIENTTYPE"] = "LIFE.BRONZE.CLIENTTYPE_ICEBERG"
    assert ctx.resolve("BRONZE.B_CLIENTTYPE.CLIENT_TYPE_ID") == "LIFE.BRONZE.CLIENTTYPE_ICEBERG.CLIENTTYPE_ID"  # names compared without underscores


class BriefModel:
    """Keeps what the modeler was told, then proposes one table over the loaded customer table."""

    def __init__(self) -> None:
        self.brief: dict[str, Any] = {}
        self.system = ""

    async def complete(self, *, system: str, tools: list[dict[str, Any]], messages: list[dict[str, Any]]) -> ModelTurn:
        self.system = system
        self.brief = json.loads(messages[0]["content"])
        proposal = {
            "models": [
                {
                    "name": "DIM_CUSTOMER",
                    "kind": "dimension",
                    "grain": "one row per customer",
                    "keys": ["CUSTOMER_SK"],
                    "sources": ["LIFE.BRONZE.CUSTOMER_ICEBERG"],
                    "sql": "SELECT c.CUST_ID AS CUSTOMER_SK, c.NAME AS NAME FROM LIFE.BRONZE.CUSTOMER_ICEBERG c",
                    "columns": [{"name": "CUSTOMER_SK", "type": "VARCHAR", "expression": "c.CUST_ID"}, {"name": "NAME", "type": "VARCHAR", "expression": "c.NAME"}],
                }
            ]
        }
        return ModelTurn(content=[{"type": "text", "text": json.dumps(proposal)}], stop_reason="end_turn")


def test_the_modeler_is_told_the_loaded_names_of_the_repository_tables(tmp_path: Path):
    snowflake = FakeSnowflake(LOADED_ELSEWHERE)
    model = BriefModel()
    modeler = DataModeler(model=model, reader=FakeReader(snowflake), repo_graph=FakeGraph())  # type: ignore[arg-type]
    intent = rule_parse("Build silver", "On LIFE.BRONZE we need to build the silver layer.")
    expect = asyncio.run(_planner(tmp_path).expectations(intent))
    validation = asyncio.run(validate(ReadOnlySql(snowflake), expect))
    spec = asyncio.run(modeler.model(intent, "Build silver", expect, validation))
    assert model.brief["repository_tables_loaded_as"] == {"BRONZE.A_CUSTOMER": "LIFE.BRONZE.CUSTOMER_ICEBERG"}
    assert [t["name"] for t in model.brief["source_tables"]] == ["LIFE.BRONZE.CLAIM_ICEBERG", "LIFE.BRONZE.CUSTOMER_ICEBERG"]
    assert "repository_tables_loaded_as maps them" in model.system
    assert spec.models[0].findings == ["compiles in Snowflake; key CUSTOMER_SK unique over 2 rows"]


def test_a_ticket_title_names_the_layer_and_reconcile_to_does_not():
    silver = rule_parse("Silver: build the conformed model in LIFE_INSURANCE_DB.SILVER", "From LIFE_INSURANCE_DB.BRONZE. Silver row counts reconcile to bronze after each run.")
    assert (silver.kind, silver.layer, silver.source.schema_name, silver.target.schema_name) == ("model_layer", "silver", "BRONZE", "SILVER")
    gold = rule_parse("Gold: curated tables", "Build the curated gold layer in LIFE_INSURANCE_DB.GOLD from LIFE_INSURANCE_DB.SILVER. Totals reconcile to silver.")
    assert (gold.layer, gold.source.schema_name, gold.target.database) == ("gold", "SILVER", "LIFE_INSURANCE_DB")
    untitled = rule_parse("Next layer", "Build the conformed silver layer from LIFE_INSURANCE_DB.BRONZE; counts reconcile to bronze.")
    assert untitled.layer == "silver"


def test_a_storage_url_is_not_a_target_and_the_files_folder_beats_the_code_folder():
    text = (
        r"Done by the pipeline in C:\Users\me\projects\iceberg-pipeline. CSV files in C:\Users\me\DE-main\csv, landing in "
        "azure://acct01.blob.core.windows.net/landing-zone/in/ through stage LIFE.LANDING.AZURE_STAGE into LIFE.BRONZE.CITY_ICEBERG."
    )
    intent = rule_parse("Bronze: load the files", text)
    assert (intent.target.database, intent.target.schema_name, intent.target.table) == ("LIFE", "BRONZE", "CITY_ICEBERG")
    assert intent.source.folder == r"C:\Users\me\DE-main\csv"
    assert (intent.source.azure_account, intent.source.azure_container, intent.source.azure_prefix) == ("acct01", "landing-zone", "in")
