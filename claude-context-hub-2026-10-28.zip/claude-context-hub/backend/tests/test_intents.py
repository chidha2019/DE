"""Intent service: parsing, CSV sampling, planning, generation and the state machine, with Jira faked."""

from __future__ import annotations

import asyncio
import sqlite3
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from uuid import UUID, uuid4

import pytest
import sqlglot
from sqlglot import exp

from ech_core.exceptions import DependencyUnavailableError, InvalidRequestError
from ech_core.jira_client import adf_to_text, parse_command, text_to_adf
from ech_core.llm.client import ModelTurn
from ech_core.schemas.intents import IntentCreate, IntentDecision, StructuredIntent
from query_service.intents import generator
from query_service.intents.csvsample import sample_folder, snowflake_identifier
from query_service.intents.parser import parse_intent, parse_model_answer, rule_parse
from query_service.intents.planner import Planner, cron_for, render_spec_markdown
from query_service.intents.service import IntentService

TICKET = (
    "Ingest the policy CSV files in data/policies_sample into the Snowflake Iceberg table INSURANCE.BRONZE.POLICY "
    "through S3 (s3://ech-landing/policies). Use external volume ECH_ICEBERG_VOL. Daily."
)
VAGUE = "We need the new policy extracts loaded into Snowflake as CSV files."


def _csv_folder(tmp_path: Path) -> Path:
    folder = tmp_path / "data" / "policies_sample"
    folder.mkdir(parents=True)
    (folder / "policies_2026_01.csv").write_text(
        "Policy Number,policyHolder,Annual Premium,Effective Date,Status,isParticipating,Updated At\n"
        "P-1001,Ann Lee,1200.50,2026-01-01,INFORCE,true,2026-01-02 10:00:00\n"
        "P-1002,Bo Chan,980.00,2026-01-03,LAPSED,false,2026-01-04 11:30:00\n"
        "P-1003,,1500.75,2026-01-05,INFORCE,true,\n",
        encoding="utf-8",
    )
    (folder / "policies_2026_02.csv").write_text(
        "Policy Number,policyHolder,Annual Premium,Effective Date,Status,isParticipating,Updated At\n"
        "P-2001,Di Ruiz,2100.00,2026-02-01,INFORCE,false,2026-02-02 09:15:00\n",
        encoding="utf-8",
    )
    return folder


# --------------------------------------------------------------------------- parser


def test_rule_parse_reads_folder_table_volume_and_schedule():
    intent = rule_parse("Ingest policy CSVs", TICKET)
    assert intent.kind == "ingest_csv_to_iceberg"
    assert intent.source.folder == "data/policies_sample"
    assert (intent.source.s3_bucket, intent.source.s3_prefix) == ("ech-landing", "policies")
    assert (intent.target.database, intent.target.schema_name, intent.target.table) == ("INSURANCE", "BRONZE", "POLICY")
    assert intent.target.external_volume == "ECH_ICEBERG_VOL"
    assert intent.freshness == "daily"
    assert intent.open_questions == []


def test_rule_parse_asks_for_what_is_missing():
    intent = rule_parse("Load policy extracts", VAGUE)
    assert intent.kind == "ingest_csv_to_iceberg"
    assert len(intent.open_questions) == 3
    assert any("CSV files" in q for q in intent.open_questions)
    assert any("DATABASE.SCHEMA.TABLE" in q for q in intent.open_questions)


def test_model_answer_is_validated_and_merged_with_rules():
    answer = (
        'Sure:\n{"kind": "ingest_csv_to_iceberg", "summary": "Load policy CSVs", "source": {"folder": null}, '
        '"target": {"database": "INSURANCE", "schema": "BRONZE", "table": "POLICY"}, "grain": "one policy", '
        '"business_terms": ["Policy", "Premium"], "open_questions": ["Which external volume?", "Who owns this pipeline?"], "confidence": 1.7}'
    )
    parsed = parse_model_answer(answer)
    assert parsed.target.schema_name == "BRONZE" and parsed.confidence == 1.0
    nulls = parse_model_answer('{"kind": "other", "summary": null, "owner": null, "freshness": null, "source": {"delimiter": null}, "target": null}')
    assert (nulls.owner, nulls.freshness, nulls.source.delimiter, nulls.target.platform) == ("", "daily", ",", "snowflake")

    class Model:
        async def complete(self, **_: Any) -> ModelTurn:
            return ModelTurn(content=[{"type": "text", "text": answer}], stop_reason="end_turn", model="claude-fake")

    merged = asyncio.run(parse_intent(Model(), title="Load policy CSVs", text=TICKET, answers=[], glossary_names=["Policy"], data_dir="data"))
    assert merged.source.folder == "data/policies_sample"  # filled from the rules
    assert merged.target.external_volume == "ECH_ICEBERG_VOL"
    assert merged.open_questions == []  # the volume question is answered by the ticket; the owner one never blocks


def test_a_later_answer_moves_the_s3_location_and_load_mode_questions_do_not_block():
    answered = rule_parse("Ingest policy CSVs", TICKET + "\nThe landing bucket is s3://de-context-hub-bucket/policies now.")
    assert (answered.source.s3_bucket, answered.source.s3_prefix) == ("de-context-hub-bucket", "policies")

    class Model:
        async def complete(self, **_: Any) -> ModelTurn:
            text = '{"kind": "ingest_csv_to_iceberg", "source": {"s3_bucket": "ech-landing", "s3_prefix": "policies"}, "target": {}, "open_questions": ["Should each load append or merge on Policy Number?"]}'
            return ModelTurn(content=[{"type": "text", "text": text}], stop_reason="end_turn", model="claude-fake")

    merged = asyncio.run(
        parse_intent(Model(), title="Ingest policy CSVs", text=TICKET, answers=["The landing bucket is s3://de-context-hub-bucket/policies now."], glossary_names=[], data_dir="data")
    )
    assert merged.source.s3_bucket == "de-context-hub-bucket"  # the answer wins over the ticket and over the model
    assert merged.open_questions == []  # load mode defaults to append


# --------------------------------------------------------------------------- csv sampling


def test_sampler_infers_types_nullability_and_identifiers(tmp_path: Path):
    folder = _csv_folder(tmp_path)
    sample = sample_folder(folder)
    assert sample.files == ["policies_2026_01.csv", "policies_2026_02.csv"] and sample.rows == 4
    by_name = {c.name: c for c in sample.columns}
    assert list(by_name) == ["POLICY_NUMBER", "POLICY_HOLDER", "ANNUAL_PREMIUM", "EFFECTIVE_DATE", "STATUS", "IS_PARTICIPATING", "UPDATED_AT"]
    assert by_name["POLICY_NUMBER"].inferred_type() == "VARCHAR(64)" and not by_name["POLICY_NUMBER"].nullable
    assert by_name["ANNUAL_PREMIUM"].inferred_type() == "NUMBER(18,2)"
    assert by_name["EFFECTIVE_DATE"].inferred_type() == "DATE"
    assert by_name["IS_PARTICIPATING"].inferred_type() == "BOOLEAN"
    assert by_name["UPDATED_AT"].inferred_type() == "TIMESTAMP_NTZ" and by_name["UPDATED_AT"].nullable
    assert by_name["POLICY_HOLDER"].nullable
    assert snowflake_identifier("2nd Address-Line") == "C_2ND_ADDRESS_LINE"


# --------------------------------------------------------------------------- planner and generator


class FakeGlossary:
    async def catalog(self, *, include_proposed: bool = False) -> list[dict[str, Any]]:
        return [
            {"id": uuid4(), "key": "policy_number", "name": "Policy Number", "domain_key": "policy", "kind": "attribute", "synonyms": ["policy number", "policy no"], "definition": "The identifier of a policy."},
            {"id": uuid4(), "key": "annualized_premium", "name": "Annualized Premium", "domain_key": "policy", "kind": "measure", "synonyms": ["annual premium"], "definition": "Premium on an annual basis."},
        ]


class FakeSemantic:
    async def search(self, query: str, *, limit: int = 20) -> dict[str, list[dict[str, Any]]]:
        if "policy" in query.lower():
            return {"assets": [{"id": uuid4(), "fqn": "life_edw.silver.policy", "kind": "dimension"}]}
        return {"assets": []}


def _planner(tmp_path: Path) -> Planner:
    return Planner(semantic=FakeSemantic(), glossary=FakeGlossary(), data_dir=tmp_path / "data")  # type: ignore[arg-type]


def test_planner_builds_a_grounded_spec_from_the_sample(tmp_path: Path):
    _csv_folder(tmp_path)
    intent = rule_parse("Ingest policy CSVs", TICKET)
    intent.business_terms = ["Policy"]
    spec = asyncio.run(_planner(tmp_path).plan(intent, "Ingest policy CSVs"))
    assert spec.name == "ingest_policy" and spec.kind == "ingest_csv_to_iceberg"
    assert spec.sampled_files == ["policies_2026_01.csv", "policies_2026_02.csv"] and spec.sampled_rows == 4
    cols = {c.name: c for c in spec.columns}
    assert cols["POLICY_NUMBER"].term_name == "Policy Number" and cols["ANNUAL_PREMIUM"].term_name == "Annualized Premium"
    assert cols["POLICY_NUMBER"].type == "VARCHAR(64)" and not cols["POLICY_NUMBER"].nullable
    assert spec.stage_name == "POLICY_STAGE" and spec.file_format_name == "POLICY_CSV_FORMAT"
    assert spec.target.base_location == "bronze/policy" and spec.schedule == "0 2 * * *"
    kinds = {t.kind for t in spec.tests}
    assert {"row_count", "not_null", "unique", "freshness", "file_count"} <= kinds
    assert next(t for t in spec.tests if t.kind == "unique").columns == ["POLICY_NUMBER"]
    assert spec.matches and spec.matches[0].name == "life_edw.silver.policy"
    assert spec.risks == []  # folder found, volume named
    md = render_spec_markdown(spec)
    assert "INSURANCE.BRONZE.POLICY" in md and "- POLICY_NUMBER VARCHAR(64) NOT NULL → Policy Number" in md and "/approve" in md


def test_planner_without_files_falls_back_to_the_ticket(tmp_path: Path):
    intent = rule_parse("Ingest policy CSVs", TICKET.replace("Use external volume ECH_ICEBERG_VOL.", ""))
    intent.columns_hint = ["policy number", "premium"]
    spec = asyncio.run(_planner(tmp_path).plan(intent, "Ingest policy CSVs"))
    assert [c.name for c in spec.columns] == ["POLICY_NUMBER", "PREMIUM"]
    assert any("not under the data directory" in r for r in spec.risks)
    assert any("ECH_EXTERNAL_VOLUME" in r for r in spec.risks)
    assert cron_for("hourly") == "0 * * * *" and cron_for("on demand") == "manual"


def test_generated_pipeline_is_self_contained_and_its_tests_pass(tmp_path: Path):
    _csv_folder(tmp_path)
    intent = rule_parse("Ingest policy CSVs", TICKET + " Merge on policy number.")
    spec = asyncio.run(_planner(tmp_path).plan(intent, "Ingest policy CSVs"))
    assert spec.target.load_mode == "merge" and spec.target.merge_keys == ["POLICY_NUMBER"]
    files = generator.generate(spec)
    assert set(files) == {
        "README.md", "spec.json", "sql/010_setup.sql", "sql/020_table.sql", "sql/030_load.sql", "sql/040_checks.sql", "sql/045_reconcile.sql",
        "sql/050_task.sql", "pipeline.py", "requirements.txt", "tests/test_pipeline.py",
    }
    # A merge deduplicates, so the load is reconciled by distinct key: the keys in the staged files against the target.
    reconcile = files["sql/045_reconcile.sql"]
    assert "FROM @INSURANCE.BRONZE.POLICY_STAGE (FILE_FORMAT => 'INSURANCE.BRONZE.POLICY_CSV_FORMAT', PATTERN => '.*\\.csv')" in reconcile
    assert "'keys' AS MEASURE" in reconcile and "'rows' AS MEASURE" not in reconcile
    assert "CREATE ICEBERG TABLE IF NOT EXISTS INSURANCE.BRONZE.POLICY" in files["sql/020_table.sql"]
    assert "EXTERNAL_VOLUME = 'ECH_ICEBERG_VOL'" in files["sql/020_table.sql"]
    assert "  POLICY_NUMBER VARCHAR(64) NOT NULL,  -- Policy Number\n" in files["sql/020_table.sql"]  # comma before the comment
    assert "  _LOADED_AT TIMESTAMP_NTZ\n)" in files["sql/020_table.sql"]  # no trailing comma on the last column
    assert "PATTERN = '.*\\.csv'" in files["sql/030_load.sql"]
    assert "URL = 's3://ech-landing/policies/'" in files["sql/010_setup.sql"]
    assert (
        "MERGE INTO INSURANCE.BRONZE.POLICY t USING (\n  SELECT * FROM INSURANCE.BRONZE.POLICY_STAGING\n"
        "  QUALIFY ROW_NUMBER() OVER (PARTITION BY POLICY_NUMBER ORDER BY _FILE_LAST_MODIFIED DESC, _SOURCE_FILE DESC, _FILE_ROW_NUMBER DESC) = 1\n"
        ") s ON t.POLICY_NUMBER = s.POLICY_NUMBER"
    ) in files["sql/030_load.sql"]
    assert "USING CRON 0 2 * * * UTC" in files["sql/050_task.sql"]
    folder = tmp_path / "pipelines" / spec.name
    for rel, content in files.items():
        (folder / rel).parent.mkdir(parents=True, exist_ok=True)
        (folder / rel).write_text(content, encoding="utf-8")
    run = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "tests"], cwd=folder, capture_output=True, text=True, timeout=180)  # noqa: S603
    assert run.returncode == 0, run.stdout + run.stderr
    plan = subprocess.run([sys.executable, "pipeline.py", "plan"], cwd=folder, capture_output=True, text=True, timeout=60)  # noqa: S603
    assert plan.returncode == 0 and "COPY INTO INSURANCE.BRONZE.POLICY_STAGING" in plan.stdout and "${" not in plan.stdout


def test_merge_keeps_the_latest_row_when_a_key_arrives_twice(tmp_path: Path):
    folder = _csv_folder(tmp_path)
    (folder / "policies_2026_03.csv").write_text(
        "Policy Number,policyHolder,Annual Premium,Effective Date,Status,isParticipating,Updated At\n"
        "P-1001,Ann Lee,1300.00,2026-01-01,LAPSED,true,2026-03-02 10:00:00\n",
        encoding="utf-8",
    )
    intent = rule_parse("Ingest policy CSVs", TICKET + " Merge on policy number.")
    spec = asyncio.run(_planner(tmp_path).plan(intent, "Ingest policy CSVs"))
    assert any(a.startswith("POLICY_NUMBER P-1001 appears on 2 sampled rows (policies_2026_01.csv, policies_2026_03.csv)") for a in spec.assumptions)
    assert next(t for t in spec.tests if t.kind == "unique").detail == "across the table (merge load)"

    files = generator.generate(spec)
    load = files["sql/030_load.sql"]
    assert " LIKE " not in load and "  _FILE_LAST_MODIFIED TIMESTAMP_NTZ,\n  _FILE_ROW_NUMBER NUMBER\n);" in load
    assert "METADATA$FILE_LAST_MODIFIED AS _FILE_LAST_MODIFIED,\n    METADATA$FILE_ROW_NUMBER AS _FILE_ROW_NUMBER\n" in load
    checks = files["sql/040_checks.sql"]
    assert "FROM (SELECT POLICY_NUMBER FROM INSURANCE.BRONZE.POLICY GROUP BY ALL HAVING COUNT(*) > 1)" in checks  # the whole table, not per file
    task = files["sql/050_task.sql"]
    assert "AS\nEXECUTE IMMEDIATE $$\nBEGIN\n  CREATE OR REPLACE TRANSIENT TABLE INSURANCE.BRONZE.POLICY_STAGING (" in task
    assert "\n  DROP TABLE IF EXISTS INSURANCE.BRONZE.POLICY_STAGING;\nEND;\n$$;\nALTER TASK" in task

    # Run the MERGE source on staged rows: the newest file wins, then the later file name, then the later row.
    merge = next(s for s in load.split(";") if "MERGE INTO" in s)
    source = sqlglot.parse_one(merge[merge.index("SELECT * FROM") : merge.index(") s ON")], read="snowflake")
    table = source.find(exp.Table)
    assert table is not None
    table.replace(exp.to_table("staging"))
    db = sqlite3.connect(":memory:")
    db.execute("CREATE TABLE staging (POLICY_NUMBER TEXT, STATUS TEXT, _SOURCE_FILE TEXT, _FILE_LAST_MODIFIED TEXT, _FILE_ROW_NUMBER INTEGER)")
    db.executemany(
        "INSERT INTO staging VALUES (?, ?, ?, ?, ?)",
        [
            ("P-1", "older file", "b.csv", "2026-01-01 10:00:00", 1),
            ("P-1", "newer file", "a.csv", "2026-01-02 10:00:00", 1),
            ("P-2", "earlier name", "a.csv", "2026-01-01 10:00:00", 2),
            ("P-2", "later name", "c.csv", "2026-01-01 10:00:00", 1),
            ("P-3", "earlier row", "a.csv", "2026-01-01 10:00:00", 3),
            ("P-3", "later row", "a.csv", "2026-01-01 10:00:00", 4),
        ],
    )
    picked = dict(db.execute(f"SELECT POLICY_NUMBER, STATUS FROM ({source.sql(dialect='sqlite')})").fetchall())
    assert picked == {"P-1": "newer file", "P-2": "later name", "P-3": "later row"}


# --------------------------------------------------------------------------- jira helpers


def test_adf_round_trip_and_commands():
    adf = text_to_adf("Questions:\n- where are the files?\n- which table?\n\nReply with /answer.")
    assert adf["content"][0]["type"] == "paragraph" and adf["content"][1]["type"] == "bulletList"
    assert "where are the files?" in adf_to_text(adf) and "Reply with /answer." in adf_to_text(adf)
    assert parse_command("/approve") == ("approve", "")
    assert parse_command("  /Reject  wrong table") == ("reject", "wrong table")
    assert parse_command("/answer the files are in data/x\nload into A.B.C") == ("answer", "the files are in data/x\nload into A.B.C")
    assert parse_command("looks good") is None


# --------------------------------------------------------------------------- service with fakes


class FakeRepo:
    def __init__(self) -> None:
        self.rows: dict[UUID, dict[str, Any]] = {}

    async def list(self, *, status: str | None, limit: int, offset: int):
        rows = [r for r in self.rows.values() if status is None or r["status"] == status]
        return rows[offset : offset + limit], len(rows)

    async def get(self, intent_id: UUID):
        return self.rows.get(intent_id)

    async def by_jira_key(self, key: str):
        return next((r for r in self.rows.values() if r["jira_key"] == key), None)

    async def create(self, *, source: str, title: str, text: str, reporter: str, jira_key: str | None = None, jira_url: str | None = None):
        now = datetime.now(tz=UTC)
        row = {
            "id": uuid4(), "source": source, "jira_key": jira_key, "jira_url": jira_url, "title": title, "text": text, "reporter": reporter,
            "status": "received", "intent": None, "questions": [], "answers": [], "spec": None, "spec_markdown": "", "coder": None,
            "branch": None, "pr_url": None, "error": None, "posted": [], "created_at": now, "updated_at": now, "decided_at": None,
        }
        self.rows[row["id"]] = row
        return row

    async def update(self, intent_id: UUID, **fields: Any):
        self.rows[intent_id].update(fields)
        return self.rows[intent_id]

    async def decide(self, intent_id: UUID, status: str, **fields: Any):
        return await self.update(intent_id, status=status, decided_at=datetime.now(tz=UTC), **fields)

    async def append_posted(self, intent_id: UUID, entry: dict[str, Any]) -> None:
        self.rows[intent_id]["posted"] = [*self.rows[intent_id]["posted"], entry]

    async def counts(self):
        return {}


class FakeJira:
    def __init__(self, issues: list[dict[str, Any]]) -> None:
        self.issues = issues
        self.comments_by_key: dict[str, list[dict[str, Any]]] = {}
        self.posted: list[tuple[str, str]] = []
        self._next = 100

    async def search(self, jql: str, *, max_results: int = 50):
        return self.issues

    async def issue(self, key: str):
        return next(i for i in self.issues if i["key"] == key)

    async def comments(self, key: str):
        return list(self.comments_by_key.get(key, []))

    async def add_comment(self, key: str, text: str) -> str:
        self._next += 1
        self.posted.append((key, text))
        self.comments_by_key.setdefault(key, []).append({"id": str(self._next), "author": "hub", "text": text, "created": ""})
        return str(self._next)

    def reply(self, key: str, text: str) -> None:
        self._next += 1
        self.comments_by_key.setdefault(key, []).append({"id": str(self._next), "author": "reporter", "text": text, "created": ""})


def _service(tmp_path: Path, jira: FakeJira | None = None) -> tuple[IntentService, FakeRepo]:
    repo = FakeRepo()
    service = IntentService(
        repo=repo,  # type: ignore[arg-type]
        planner=_planner(tmp_path),
        model=None,
        glossary=FakeGlossary(),  # type: ignore[arg-type]
        workspace_dir=tmp_path / "pipelines",
        data_dir=tmp_path / "data",
        jira=jira,  # type: ignore[arg-type]
        jira_jql="labels = ech-intent",
        poll_seconds=60 if jira else 0,
        run_tests=True,
    )
    return service, repo


def test_manual_intent_runs_through_spec_approval_and_generation(tmp_path: Path):
    _csv_folder(tmp_path)
    service, _ = _service(tmp_path)

    async def go():
        record = await service.create(IntentCreate(title="Ingest policy CSVs", text=TICKET))
        assert record.status == "spec_proposed" and record.spec is not None and "Pipeline spec: ingest_policy" in record.spec_markdown
        with pytest.raises(InvalidRequestError):
            await service.decide(record.id, IntentDecision(decision="done"))
        coded = await service.decide(record.id, IntentDecision(decision="approve"))
        files = await service.files(record.id)
        done = await service.decide(record.id, IntentDecision(decision="done"))
        return record, coded, files, done

    record, coded, files, done = asyncio.run(go())
    assert coded.status == "pr_open" and coded.coder is not None
    assert coded.coder.tests_passed is True, coded.coder.test_output
    assert coded.branch == "intent/ingest-policy" and len(coded.coder.files) == 11  # with sql/045_reconcile.sql
    assert (tmp_path / "pipelines" / "ingest_policy" / "sql" / "020_table.sql").exists()
    assert {f.path for f in files} == {f.path for f in coded.coder.files}
    assert done.status == "done" and done.decided_at is not None


def test_vague_intent_waits_for_answers_then_plans(tmp_path: Path):
    _csv_folder(tmp_path)
    service, _ = _service(tmp_path)

    async def go():
        record = await service.create(IntentCreate(title="Load policy extracts", text=VAGUE))
        assert record.status == "clarifying" and len(record.questions) == 3
        with pytest.raises(InvalidRequestError):
            await service.decide(record.id, IntentDecision(decision="approve"))
        return await service.answer(record.id, ["files are in data/policies_sample, load into INSURANCE.BRONZE.POLICY, external volume ECH_ICEBERG_VOL"])

    answered = asyncio.run(go())
    assert answered.status == "spec_proposed" and answered.questions == []
    assert answered.spec is not None and answered.spec.target.table == "POLICY" and answered.spec.sampled_rows == 4


def test_jira_sync_creates_intents_posts_questions_and_applies_replies(tmp_path: Path):
    _csv_folder(tmp_path)
    jira = FakeJira(
        [{"key": "DATA-7", "url": "https://x.atlassian.net/browse/DATA-7", "summary": "Load policy extracts", "description": VAGUE, "reporter": "Ann", "status": "To Do", "labels": ["ech-intent"]}]
    )
    service, repo = _service(tmp_path, jira)

    async def go():
        first = await service.sync_jira()
        assert (first.fetched, first.created) == (1, 1)
        row = await repo.by_jira_key("DATA-7")
        assert row is not None and row["status"] == "clarifying"
        assert jira.posted and jira.posted[0][0] == "DATA-7" and "Before I can plan this" in jira.posted[0][1]
        jira.reply("DATA-7", "/answer files in data/policies_sample; table INSURANCE.BRONZE.POLICY; external volume ECH_ICEBERG_VOL")
        second = await service.sync_jira()
        assert second.answered == 1
        row = await repo.by_jira_key("DATA-7")
        assert row["status"] == "spec_proposed" and any("Pipeline spec: ingest_policy" in t for _, t in jira.posted)
        jira.reply("DATA-7", "looks fine to me")  # not a command
        jira.reply("DATA-7", "/approve")
        third = await service.sync_jira()
        assert third.approved == 1
        row = await repo.by_jira_key("DATA-7")
        assert row["status"] == "pr_open" and any("Pipeline generated" in t for _, t in jira.posted)
        return await service.sync_jira()  # nothing new: the hub's own comments and seen replies are skipped

    fourth = asyncio.run(go())
    assert (fourth.answered, fourth.approved, fourth.rejected, fourth.errors) == (0, 0, 0, [])


def test_jira_poll_follows_imported_tickets_but_imports_none(tmp_path: Path):
    _csv_folder(tmp_path)
    jira = FakeJira(
        [{"key": "DATA-7", "url": "https://x.atlassian.net/browse/DATA-7", "summary": "Load policy extracts", "description": VAGUE, "reporter": "Ann", "status": "To Do", "labels": ["ech-intent"]}]
    )
    service, repo = _service(tmp_path, jira)

    async def go():
        polled = await service.sync_jira(import_new=False)
        assert (polled.fetched, polled.created) == (1, 0)
        assert await repo.by_jira_key("DATA-7") is None and jira.posted == []
        await service.import_jira("DATA-7")  # read by key on the Intents page
        jira.reply("DATA-7", "/answer files in data/policies_sample; table INSURANCE.BRONZE.POLICY; external volume ECH_ICEBERG_VOL")
        return await service.sync_jira(import_new=False)

    followed = asyncio.run(go())
    assert (followed.created, followed.answered) == (0, 1)


def test_structured_intent_round_trips_through_json_aliases():
    intent = rule_parse("Ingest policy CSVs", TICKET)
    dumped = intent.model_dump(by_alias=True)
    assert dumped["target"]["schema"] == "BRONZE"
    assert StructuredIntent.model_validate(dumped).target.schema_name == "BRONZE"


# ----------------------------------------------------------------------------- read, review, plan as a workflow
def test_issue_key_reads_keys_and_browse_urls():
    from query_service.intents.service import issue_key

    assert issue_key("data-123") == "DATA-123"
    assert issue_key("https://acme.atlassian.net/browse/DATA-42") == "DATA-42"
    assert issue_key("https://acme.atlassian.net/jira/software/projects/DATA/boards/1?selectedIssue=DATA-7") == "DATA-7"
    assert issue_key("no key here") is None


def test_rule_parse_reads_acceptance_criteria_bullets():
    text = TICKET + "\n\nAcceptance criteria:\n- Row count matches the files\n- POLICY_NUMBER is unique\n\nThanks"
    assert rule_parse("Ingest policy CSVs", text).acceptance_criteria == ["Row count matches the files", "POLICY_NUMBER is unique"]


def test_review_scores_a_complete_ticket_ready_and_a_vague_one_blocked(tmp_path: Path):
    _csv_folder(tmp_path)
    service, _ = _service(tmp_path)

    async def go():
        full = await service.create(IntentCreate(title="Ingest policy CSVs", text=TICKET + "\n\nAcceptance criteria:\n- Row count matches the files"))
        vague = await service.create(IntentCreate(title="Load policy extracts", text=VAGUE))
        return full, vague

    full, vague = asyncio.run(go())
    assert full.review is not None and full.review.verdict == "ready" and full.review.score >= 75
    checks = {c.key: c for c in full.review.checks}
    assert checks["source"].status == "ok" and "2 file(s)" in checks["source"].detail
    assert checks["acceptance"].status == "ok" and checks["questions"].status == "ok"
    assert vague.review is not None and vague.review.verdict == "needs_answers"
    blocked = {c.key for c in vague.review.checks if c.blocking and c.status == "missing"}
    assert {"source", "target", "storage", "questions"} <= blocked
    assert vague.workflow == []


def test_workflow_lays_the_spec_out_in_run_order(tmp_path: Path):
    from query_service.intents.workflow import describe_cron

    _csv_folder(tmp_path)
    service, _ = _service(tmp_path)
    record = asyncio.run(service.create(IntentCreate(title="Ingest policy CSVs", text=TICKET)))
    steps = {s.key: s for s in record.workflow}
    assert [s.key for s in record.workflow] == ["source", "land", "stage", "table", "load", "validate", "schedule", "govern"]
    assert steps["source"].status == "ready" and "s3://ech-landing/policies/ with boto3" in steps["land"].summary
    assert steps["table"].summary == "INSURANCE.BRONZE.POLICY" and steps["load"].title == "Copy new files in"
    assert steps["govern"].status == "ready" and "Policy Number" in steps["govern"].items
    assert describe_cron("0 2 * * *") == "daily at 02:00 UTC" and describe_cron("15 * * * *") == "hourly at minute 15"
    assert describe_cron("0 6 * * 1") == "every Monday at 06:00 UTC" and describe_cron("manual") == "on demand"


def test_jira_issue_is_read_once_by_key_or_url(tmp_path: Path):
    _csv_folder(tmp_path)
    issue = {"key": "DATA-9", "url": "https://acme.atlassian.net/browse/DATA-9", "summary": "Ingest policy CSVs", "description": TICKET, "reporter": "Ana", "status": "To Do", "labels": []}

    class OneIssue(FakeJira):
        async def issue(self, key: str):
            assert key == "DATA-9"
            return issue

        def issue_url(self, key: str) -> str:
            return f"https://acme.atlassian.net/browse/{key}"

    service, repo = _service(tmp_path, OneIssue([issue]))
    offline, _ = _service(tmp_path)

    async def go():
        first = await service.import_jira("https://acme.atlassian.net/browse/DATA-9")
        again = await service.import_jira("data-9")
        with pytest.raises(InvalidRequestError):
            await service.import_jira("not a key")
        with pytest.raises(DependencyUnavailableError):
            await offline.import_jira("DATA-10")
        pasted = await offline.create(IntentCreate(title="Ingest policy CSVs", text=TICKET, jira_key="data-11"))
        return first, again, pasted

    first, again, pasted = asyncio.run(go())
    assert first.source == "jira" and first.jira_key == "DATA-9" and first.reporter == "Ana" and first.status == "spec_proposed"
    assert again.id == first.id and len(repo.rows) == 1
    assert pasted.source == "jira" and pasted.jira_key == "DATA-11" and pasted.jira_url is None


def test_review_judges_a_planned_intent_by_its_plan(tmp_path: Path):
    from query_service.intents.review import review_intent

    _csv_folder(tmp_path)
    intent = rule_parse("Ingest policy CSVs", TICKET)
    spec = asyncio.run(_planner(tmp_path).plan(intent, "Ingest policy CSVs"))
    unplanned = intent.model_copy(deep=True)
    unplanned.target.external_volume = None
    before = review_intent(unplanned, questions=[], spec=None, glossary_names=[])
    after = review_intent(unplanned, questions=[], spec=spec, glossary_names=[])
    assert before is not None and before.verdict == "needs_answers"
    assert after is not None and {c.key: c.status for c in after.checks}["storage"] == "ok" and after.verdict != "needs_answers"


# ----------------------------------------------------------------------------- the semantic layer shapes the plan
class FakeCatalog:
    """A semantic layer holding a few tables: search, fields, relationships and lookup by name."""

    def __init__(self, tables: dict[str, dict[str, Any]]) -> None:
        self.tables = {fqn: {"id": uuid4(), "asset_type": "table", "kind": "fact", **t} for fqn, t in tables.items()}

    def _by_id(self, asset_id: UUID) -> dict[str, Any]:
        return next(t for t in self.tables.values() if t["id"] == asset_id)

    async def search(self, query: str, *, limit: int = 20) -> dict[str, list[dict[str, Any]]]:
        assets = [{"id": t["id"], "fqn": fqn, "asset_type": t["asset_type"], "kind": t["kind"]} for fqn, t in self.tables.items()]
        fields = [
            {"name": f["name"], "asset_id": t["id"], "asset_fqn": fqn, "asset_type": t["asset_type"]}
            for fqn, t in self.tables.items()
            for f in t["fields"]
            if f["name"].upper() == query.upper()
        ]
        return {"assets": assets[:limit], "fields": fields[:limit], "metrics": []}

    async def find_asset_row(self, fqn: str) -> dict[str, Any] | None:
        for name, t in self.tables.items():
            if name.lower() == fqn.lower() or name.lower().endswith("." + fqn.lower()):
                return {"id": t["id"], "fqn": name, "asset_type": t["asset_type"], "kind": t["kind"]}
        return None

    async def fields(self, asset_id: UUID) -> list[dict[str, Any]]:
        return [{"is_primary_key": False, "role": "attribute", "nullable": True, **f} for f in self._by_id(asset_id)["fields"]]

    async def relationships(self, asset_id: UUID) -> list[dict[str, Any]]:
        return list(self._by_id(asset_id).get("relationships", []))


def _field(name: str, data_type: str, **extra: Any) -> dict[str, Any]:
    return {"name": name, "data_type": data_type, **extra}


POLICY_TABLE = {
    "fields": [
        _field("POLICY_ID", "NUMBER(18,0)", is_primary_key=True, role="identifier"),
        _field("POLICY_NUMBER", "TEXT", role="identifier"),
        _field("ANNUAL_PREMIUM", "NUMBER(18,4)", role="measure"),
        _field("EFFECTIVE_DATE", "TIMESTAMP_NTZ", role="time"),
        _field("UPDATED_AT", "DATE", role="time"),
        _field("IS_PARTICIPATING", "BOOLEAN"),
        _field("WRITING_AGENT_ID", "NUMBER(18,0)", role="identifier"),
    ],
    "relationships": [
        {"direction": "in", "kind": "foreign_key", "source_columns": ["POLICY_ID"], "target_columns": ["POLICY_ID"], "other_fqn": "LIFE.CLAIMS.CLAIM", "confidence": 1.0},
        {
            "direction": "out",
            "kind": "join_declared",
            "source_columns": ["POLICY_NUMBER"],
            "target_columns": ["POLICY_NUMBER"],
            "other_fqn": "LIFE.BILLING.INVOICE",
            "confidence": 1.0,
        },
        {"direction": "out", "kind": "lineage_upstream", "source_columns": ["POLICY_NUMBER"], "target_columns": [], "other_fqn": "LIFE.RAW.POLICY", "confidence": 1.0},
    ],
}


def _catalog_planner(tmp_path: Path, tables: dict[str, dict[str, Any]]) -> Planner:
    return Planner(semantic=FakeCatalog(tables), glossary=FakeGlossary(), data_dir=tmp_path / "data")  # type: ignore[arg-type]


def test_a_matching_catalog_table_lends_its_types_and_joins(tmp_path: Path):
    from query_service.intents.workflow import build_workflow

    _csv_folder(tmp_path)
    intent = rule_parse("Ingest policy CSVs", TICKET)
    # A view carrying more of the feed loses to the base table: only the table declares a key and joins.
    view = {"asset_type": "view", "fields": [_field(n, "TEXT") for n in ("POLICY_NUMBER", "POLICY_HOLDER", "ANNUAL_PREMIUM", "EFFECTIVE_DATE", "STATUS", "UPDATED_AT")]}
    tables = {"LIFE.POLICY.POLICY": POLICY_TABLE, "LIFE.ANALYTICS.POLICY_VIEW": view}
    spec = asyncio.run(_catalog_planner(tmp_path, tables).plan(intent, "Ingest policy CSVs"))
    m = spec.catalog_match
    assert m is not None and m.fqn == "LIFE.POLICY.POLICY" and m.feed_columns == 7 and len(m.matched_columns) == 5
    assert m.key == ["POLICY_ID"] and not m.key_in_feed and not m.duplicate and m.types_adopted == 2
    cols = {c.name: c for c in spec.columns}
    assert cols["ANNUAL_PREMIUM"].type == "NUMBER(18,4)" and cols["EFFECTIVE_DATE"].type == "TIMESTAMP_NTZ"
    assert cols["POLICY_NUMBER"].type == "VARCHAR(64)" and cols["POLICY_NUMBER"].catalog_type == "TEXT"
    assert cols["UPDATED_AT"].type == "TIMESTAMP_NTZ" and any("UPDATED_AT" in r and "DATE" in r for r in spec.risks)
    assert any("keyed on POLICY_ID" in r and "POLICY_NUMBER" in r for r in spec.risks)
    assert [(j.kind, j.columns, j.to_table) for j in spec.joins] == [
        ("shared_key", ["POLICY_NUMBER"], "LIFE.POLICY.POLICY"),
        ("join_declared", ["POLICY_NUMBER"], "LIFE.BILLING.INVOICE"),
    ]
    steps = {s.key: s for s in build_workflow(spec)}
    assert steps["relate"].status == "ready" and len(steps["relate"].items) == 2
    assert any(x.label == "types from catalog" and x.value == "2" for x in steps["table"].metrics)
    markdown = render_spec_markdown(spec)
    assert "Catalog match" in markdown and "LIFE.BILLING.INVOICE" in markdown


def test_a_near_identical_table_is_a_duplicate_and_its_declared_key_wins(tmp_path: Path):
    from query_service.intents.review import review_intent

    _csv_folder(tmp_path)
    twin = {
        "fields": [
            _field("POLICY_NUMBER", "VARCHAR(64)", is_primary_key=True, role="identifier"),
            _field("EFFECTIVE_DATE", "DATE", is_primary_key=True, role="time"),
            _field("POLICY_HOLDER", "VARCHAR(64)"),
            _field("ANNUAL_PREMIUM", "NUMBER(18,2)"),
            _field("STATUS", "VARCHAR(64)"),
            _field("IS_PARTICIPATING", "BOOLEAN"),
            _field("UPDATED_AT", "TIMESTAMP_NTZ"),
        ]
    }
    intent = rule_parse("Ingest policy CSVs", TICKET + " Merge the rows.")
    assert intent.target.load_mode == "merge" and not intent.target.merge_keys
    spec = asyncio.run(_catalog_planner(tmp_path, {"LIFE.SILVER.POLICY_EXTRACT": twin}).plan(intent, "Ingest policy CSVs"))
    m = spec.catalog_match
    assert m is not None and m.duplicate and m.key_in_feed and "7 of 7" in m.duplicate_reason
    assert spec.target.merge_keys == ["POLICY_NUMBER", "EFFECTIVE_DATE"]
    unique = next(t for t in spec.tests if t.kind == "unique")
    assert unique.columns == ["POLICY_NUMBER", "EFFECTIVE_DATE"] and unique.origin == "LIFE.SILVER.POLICY_EXTRACT primary key"
    assert any("duplicate of LIFE.SILVER.POLICY_EXTRACT" in r for r in spec.risks)
    review = review_intent(intent, questions=[], spec=spec, glossary_names=[])
    assert review is not None and {c.key: c.status for c in review.checks}["duplicate"] == "warn" and "may duplicate" in review.headline


def test_a_target_that_already_exists_is_flagged(tmp_path: Path):
    _csv_folder(tmp_path)
    existing = {"fields": [_field("POLICY_NUMBER", "TEXT", role="identifier"), _field("BALANCE", "NUMBER(18,2)")]}
    intent = rule_parse("Ingest policy CSVs", TICKET)
    spec = asyncio.run(_catalog_planner(tmp_path, {"INSURANCE.BRONZE.POLICY": existing}).plan(intent, "Ingest policy CSVs"))
    assert spec.catalog_match is not None and spec.catalog_match.duplicate and "already exists" in spec.catalog_match.duplicate_reason
    assert any("INSURANCE.BRONZE.POLICY already exists in the catalog" in r for r in spec.risks)


def test_catalog_types_are_written_the_snowflake_way():
    from ech_core.schemas.intents import SpecColumn
    from query_service.intents.catalog import reconcile, snowflake_type

    assert snowflake_type("DECIMAL(10,2)") == "NUMBER(10,2)" and snowflake_type("BIGINT") == "NUMBER(38,0)" and snowflake_type("TIMESTAMP") == "TIMESTAMP_NTZ"
    code = SpecColumn(name="PRODUCT_CODE", type="NUMBER(18,0)", sample="00123")
    assert reconcile(code, "STRING") == ("VARCHAR", True, None)
    amount = SpecColumn(name="AMOUNT", type="NUMBER(18,4)", sample="1.2345")
    kept, adopted, conflict = reconcile(amount, "NUMBER(18,2)")
    assert kept == "NUMBER(18,4)" and not adopted and conflict is not None and "drop decimals" in conflict
