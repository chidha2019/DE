"""ER diagrams from design documents and model plans."""

from __future__ import annotations

from pathlib import Path

from ech_core.schemas.intents import ModelColumn, ModelRelationship, ModelTable
from query_service.intents import er, mapping

DATA = Path(__file__).resolve().parents[2] / "data"


def test_the_silver_design_draws_every_table_and_each_foreign_key():
    folders = dict(mapping.design_folders(DATA))
    texts = folders["DE-main/silver"]
    d = er.from_design(mapping.load_design(texts), origin="DE-main/silver", files=sorted(texts))
    names = {e.name: e for e in d.entities}
    assert set(names) == {"DIM_PARTY", "DIM_LOCATION", "DIM_COMMUNICATION", "DIM_INSURANCE_PRODUCT", "FACT_AGREEMENT", "FACT_FINANCIAL_TX", "FACT_LOSS_EVENT"}
    party = names["DIM_PARTY"]
    assert party.kind == "dimension" and party.concept == "Party" and party.schema_name == "SILVER"
    assert [c.name for c in party.columns if c.pk] == ["PARTY_SK"] and party.columns[0].description  # described by the data model
    # A fact that references the same dimension twice keeps both roles, and a nullable key is an optional relationship.
    to_party = {r.from_columns[0]: r for r in d.relationships if r.from_table == "FACT_AGREEMENT" and r.to_table == "DIM_PARTY"}
    assert set(to_party) == {"INSURED_PARTY_SK", "PRODUCER_PARTY_SK"}
    assert to_party["INSURED_PARTY_SK"].required and not to_party["PRODUCER_PARTY_SK"].required
    assert next(c for c in names["FACT_AGREEMENT"].columns if c.name == "PRODUCT_SK").fk == "DIM_INSURANCE_PRODUCT.PRODUCT_SK"
    assert not [e for e in d.entities if e.kind == "external"] and d.problems == []
    # The packages' own worked examples are not design documents.
    assert not [o for o in folders if o.startswith("digital-worker")]


def test_a_plan_draws_what_it_references_but_does_not_model_as_external():
    models = [
        ModelTable(
            name="SILVER.FACT_CLAIM",
            kind="fact",
            grain="one row per claim",
            sql="SELECT 1",
            keys=["CLAIM_SK"],
            columns=[ModelColumn(name="CLAIM_SK", type="VARCHAR(64)", expression="x", nullable=False), ModelColumn(name="POLICY_SK", type="NUMBER(38,0)", expression="y")],
            relationships=[ModelRelationship(columns=["POLICY_SK"], to_table="SILVER.DIM_POLICY", to_columns=["POLICY_SK"])],
            rows=120,
        )
    ]
    d = er.from_models(models, key="intent:1", title="KAN-9 · model", origin="KAN-9")
    assert [e.name for e in d.entities] == ["FACT_CLAIM", "DIM_POLICY"]
    assert d.entities[1].kind == "external" and d.entities[0].rows == 120
    rel = d.relationships[0]
    assert (rel.from_table, rel.to_table, rel.cardinality, rel.required) == ("FACT_CLAIM", "DIM_POLICY", "many_to_one", False)
    # Mermaid wants one-word types and the parent on the left.
    assert "NUMBER POLICY_SK FK" in d.mermaid and 'DIM_POLICY |o--o{ FACT_CLAIM : "POLICY_SK"' in d.mermaid
    assert d.mermaid.startswith("erDiagram\n")
