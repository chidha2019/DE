"""Databricks Unity Catalog connector against a fake REST API (pagination, retries, lineage)."""

from __future__ import annotations

from typing import Any
from urllib.parse import parse_qs

import httpx

from ech_core.semantic.models import (
    AssetKind,
    AssetType,
    FieldRole,
    MetricSource,
    RelationshipKind,
    SemanticAsset,
)
from ingestion_service.connectors.base import ConnectorOptions
from ingestion_service.connectors.databricks_uc import DatabricksCatalogConnector

HOST = "https://adb-1.azuredatabricks.net"
METRIC_VIEW_YAML = """version: 0.1
source: lake.gold.fact_claims
joins:
  - name: policy
    source: lake.gold.dim_policy
    on: source.policy_id = policy.policy_id
dimensions:
  - name: Claim status
    expr: status
measures:
  - name: Paid amount
    expr: SUM(paid_amount)
    comment: Total paid
"""


def _entry(name: str, table_type: str) -> dict[str, Any]:
    return {
        "name": name,
        "full_name": f"lake.gold.{name}",
        "catalog_name": "lake",
        "schema_name": "gold",
        "table_type": table_type,
    }


LIST = {
    "fact_claims": _entry("fact_claims", "MANAGED"),
    "dim_policy": _entry("dim_policy", "MANAGED"),
    "mv_claims": _entry("mv_claims", "METRIC_VIEW"),
}
DETAIL = {
    "fact_claims": {
        **LIST["fact_claims"],
        "data_source_format": "DELTA",
        "comment": "Claims at claim grain.",
        "owner": "ana@example.com",
        "created_at": 1690000000000,
        "updated_at": 1700000000000,
        "columns": [
            {"name": "claim_id", "type_text": "bigint", "position": 0, "nullable": False},
            {"name": "policy_id", "type_text": "bigint", "position": 1, "nullable": False},
            {
                "name": "paid_amount",
                "type_text": "decimal(18,2)",
                "position": 2,
                "comment": "Amount paid",
            },
            {"name": "claim_date", "type_text": "date", "position": 3, "partition_index": 0},
            {"name": "status", "type_text": "string", "position": 4},
        ],
        "properties": {
            "spark.sql.statistics.numRows": "1200",
            "delta.lastCommitTimestamp": "1700000000000",
        },
        "table_constraints": [
            {"primary_key_constraint": {"name": "pk_claims", "child_columns": ["claim_id"]}},
            {
                "foreign_key_constraint": {
                    "name": "fk_policy",
                    "child_columns": ["policy_id"],
                    "parent_table": "lake.gold.dim_policy",
                    "parent_columns": ["policy_id"],
                }
            },
        ],
    },
    "dim_policy": {
        **LIST["dim_policy"],
        "data_source_format": "DELTA",
        "comment": "Policies.",
        "owner": "System user",
        "columns": [
            {"name": "policy_id", "type_text": "bigint", "position": 0},
            {"name": "policy_number", "type_text": "string", "position": 1},
            {"name": "lob_cd", "type_text": "string", "position": 2},
        ],
        "table_constraints": [
            {"primary_key_constraint": {"name": "pk_policy", "child_columns": ["policy_id"]}}
        ],
    },
    "mv_claims": {
        **LIST["mv_claims"],
        "owner": "ana@example.com",
        "comment": "Claim payments by status.",
        "view_definition": METRIC_VIEW_YAML,
        "columns": [
            {"name": "Claim status", "type_text": "string", "position": 0},
            {
                "name": "Paid amount",
                "type_text": "decimal(18,2)",
                "position": 1,
                "comment": "Paid total",
            },
        ],
    },
}
LINEAGE = {
    "lake.gold.fact_claims": {
        "upstreams": [
            {"tableInfo": {"catalog_name": "lake", "schema_name": "silver", "name": "claims_raw"}}
        ],
        "downstreams": [{"dashboardV3Infos": [{"dashboard_id": "d1"}]}],
    }
}


def make_handler(calls: list[str], *, flaky: bool = False):
    state = {"catalogs": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        params = {k: v[0] for k, v in parse_qs(request.url.query.decode()).items()}
        calls.append(f"{request.url.path} {params}")
        assert request.headers["Authorization"] == "Bearer not-a-real-token"
        path = request.url.path
        if path == "/api/2.1/unity-catalog/catalogs":
            state["catalogs"] += 1
            if flaky and state["catalogs"] == 1:
                return httpx.Response(429, headers={"Retry-After": "0"}, json={"message": "slow"})
            return httpx.Response(200, json={"catalogs": [{"name": "lake"}, {"name": "other"}]})
        if path == "/api/2.1/unity-catalog/schemas":
            assert params["catalog_name"] == "lake"
            return httpx.Response(
                200, json={"schemas": [{"name": "gold"}, {"name": "information_schema"}]}
            )
        if path == "/api/2.1/unity-catalog/tables":
            if params.get("page_token") == "p2":
                return httpx.Response(200, json={"tables": [LIST["dim_policy"], LIST["mv_claims"]]})
            return httpx.Response(
                200, json={"tables": [LIST["fact_claims"]], "next_page_token": "p2"}
            )
        if path.startswith("/api/2.1/unity-catalog/tables/"):
            name = path.rsplit(".", 1)[-1]
            if name in DETAIL:
                return httpx.Response(200, json=DETAIL[name])
            return httpx.Response(404, json={"message": "no such table"})
        if path == "/api/2.0/lineage-tracking/table-lineage":
            return httpx.Response(200, json=LINEAGE.get(params["table_name"], {}))
        return httpx.Response(404, json={"message": f"unexpected {path}"})

    return handler


def make_connector(calls: list[str], **kw) -> DatabricksCatalogConnector:
    client = httpx.AsyncClient(
        transport=httpx.MockTransport(make_handler(calls, **kw)), base_url=HOST
    )
    return DatabricksCatalogConnector(
        host=HOST, token="not-a-real-token", catalogs=["lake"], client=client, concurrency=2
    )


async def test_health_and_estimate_with_retry():
    calls: list[str] = []
    connector = make_connector(calls, flaky=True)
    health = await connector.health_check()
    assert health.healthy and health.details["visible_catalogs"] == 2
    assert health.details["missing_catalogs"] == []
    assert sum(1 for c in calls if "/catalogs" in c) == 2, "429 is retried"
    assert await connector.estimate_count(ConnectorOptions()) == 3, "both pages counted"
    assert await connector.estimate_count(ConnectorOptions(limit=2)) == 2


async def test_documents_carry_semantic_assets():
    calls: list[str] = []
    connector = make_connector(calls)
    docs = [d async for d in connector.iter_documents(ConnectorOptions())]
    assert [d.external_id for d in docs] == [
        "lake.gold.fact_claims",
        "lake.gold.dim_policy",
        "lake.gold.mv_claims",
    ]

    fact = docs[0]
    assert fact.title == "lake.gold.fact_claims" and fact.author == "ana@example.com"
    assert fact.contributors == ["ana@example.com"]
    assert set(fact.references) == {"lake.gold.dim_policy", "lake.silver.claims_raw"}
    assert fact.attributes["reference_kinds"] == {
        "lake.gold.dim_policy": "foreign_key",
        "lake.silver.claims_raw": "lineage_upstream",
    }
    assert (
        fact.attributes["asset"]["kind"] == "fact" and fact.attributes["connector"] == "databricks"
    )
    asset = SemanticAsset.model_validate(fact.attributes["semantic"])
    assert asset.kind is AssetKind.FACT and asset.asset_type is AssetType.TABLE
    assert asset.row_count == 1200 and asset.primary_key == ["claim_id"]
    assert {f.name: f.role for f in asset.fields} == {
        "claim_id": FieldRole.IDENTIFIER,
        "policy_id": FieldRole.IDENTIFIER,
        "paid_amount": FieldRole.MEASURE,
        "claim_date": FieldRole.TIME,
        "status": FieldRole.DIMENSION,
    }
    assert (
        asset.field("claim_date").is_partition and asset.field("paid_amount").aggregation == "sum"
    )
    assert {r.kind for r in asset.relationships} == {
        RelationshipKind.FOREIGN_KEY,
        RelationshipKind.LINEAGE_UPSTREAM,
    }
    assert (
        asset.properties["consumers"] == ["dashboard d1"] and asset.properties["format"] == "DELTA"
    )
    assert asset.uri == f"{HOST}/explore/data/lake/gold/fact_claims"
    assert {e.name for e in fact.explicit_entities} >= {"Databricks", "Lake", "Delta Lake"}
    assert "## Columns" in fact.content and "Foreign key to `lake.gold.dim_policy`" in fact.content

    dim = SemanticAsset.model_validate(docs[1].attributes["semantic"])
    assert dim.kind is AssetKind.DIMENSION and docs[1].author is None, "a system owner is no person"

    mv = SemanticAsset.model_validate(docs[2].attributes["semantic"])
    assert mv.asset_type is AssetType.METRIC_VIEW and mv.kind is AssetKind.METRIC
    (metric,) = mv.metrics
    assert metric.source is MetricSource.DECLARED and metric.expression == "SUM(paid_amount)"
    assert metric.aggregation == "sum" and metric.dimensions == ["Claim status"]
    assert metric.description == "Total paid"
    assert {(r.kind, r.target_fqn) for r in mv.relationships} == {
        (RelationshipKind.METRIC_SOURCE, "lake.gold.fact_claims"),
        (RelationshipKind.JOIN_DECLARED, "lake.gold.dim_policy"),
    }
    join = next(r for r in mv.relationships if r.kind is RelationshipKind.JOIN_DECLARED)
    assert join.source_columns == ["policy_id"] and join.target_columns == ["policy_id"]
    status = mv.field("Claim status")
    assert status.role is FieldRole.DIMENSION and status.role_confidence == 1.0
    paid = mv.field("Paid amount")
    assert paid.role is FieldRole.MEASURE and paid.aggregation == "sum"
    assert "## Definition" in docs[2].content and "Declared:" in docs[2].content


async def test_limit_and_fetch_document():
    calls: list[str] = []
    connector = make_connector(calls)
    assert len([d async for d in connector.iter_documents(ConnectorOptions(limit=1))]) == 1
    doc = await connector.fetch_document("lake.gold.dim_policy")
    assert doc is not None and doc.external_id == "lake.gold.dim_policy"
    assert await connector.fetch_document("lake.gold.missing") is None
