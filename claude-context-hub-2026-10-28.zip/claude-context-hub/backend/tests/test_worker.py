"""The Data Engineer digital worker: signals, diagnosis, skills packages, the hash-chained journal, and a sweep."""

from __future__ import annotations

import asyncio
import json
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any
from uuid import UUID, uuid4

import httpx

from ech_core.domain.enums import RunStatus
from ech_core.domain.models import IngestionRunRecord
from ech_core.repositories.worker_repository import OPEN_STATUSES, chain_ok, entry_body, record_hash
from ech_core.schemas.intents import (
    IntentSource,
    IntentTarget,
    IntentValidation,
    ModelTable,
    PipelineSpec,
    ValidatedObject,
)
from ech_core.schemas.worker import WorkerDecision
from query_service.intents.blockers import plan_blockers
from query_service.worker import capabilities as caps
from query_service.worker import integrity as integ
from query_service.worker import signals as sig
from query_service.worker.service import DigitalWorker
from query_service.worker.skills import load_bindings, load_packages, read_package, skills_for

NOW = datetime(2026, 10, 28, 9, 0, tzinfo=UTC)
PACKAGE = Path(__file__).resolve().parents[2] / "data" / "digital-worker" / "data_engineer" / "repo-crawler" / "SKILL.md"


# --------------------------------------------------------------------------- diagnosis and signals
def test_failures_are_diagnosed_by_cause_and_whether_a_rerun_helps():
    assert not sig.diagnose("SQL access control error: Requested role 'X' is not assigned to the executing user").retry
    assert not sig.diagnose("HTTP 401 Unauthorized").retry
    assert sig.diagnose("ReadTimeout: timed out").retry
    assert sig.diagnose("run abandoned: the service restarted").retry
    assert "does not recognise" in sig.diagnose("something odd").cause


def test_a_failed_run_is_one_item_per_connector_until_a_later_run_succeeds():
    failures = [
        {"id": "r3", "connector_name": "snowflake", "error": "timed out", "finished_at": NOW - timedelta(hours=1)},
        {"id": "r2", "connector_name": "snowflake", "error": "timed out", "finished_at": NOW - timedelta(hours=3)},
        {"id": "r1", "connector_name": "databricks", "error": "HTTP 403 Forbidden", "finished_at": NOW - timedelta(hours=2)},
        {"id": "r0", "connector_name": "github-live", "error": "timed out", "finished_at": NOW - timedelta(hours=5)},
    ]
    freshness = [{"connector_name": "github-live", "last_success_at": NOW - timedelta(hours=4)}]
    found = {s.key: s for s in sig.failed_runs(failures, freshness)}
    assert set(found) == {"run-failed:r3", "run-failed:r1"}  # github-live recovered; snowflake only its latest failure
    assert (found["run-failed:r3"].status, found["run-failed:r3"].tier, found["run-failed:r3"].action["kind"]) == ("waiting", "T2", "rerun")
    assert (found["run-failed:r1"].status, found["run-failed:r1"].action["kind"]) == ("diagnosed", "open")  # credentials: a person first


def test_intents_turn_into_the_right_work():
    rows = [
        {"id": "a", "status": "spec_proposed", "jira_key": "KAN-3", "title": "Bronze", "spec": {"tables": [1, 2], "risks": ["r"]}},
        {"id": "b", "status": "clarifying", "jira_key": "KAN-4", "title": "Silver", "questions": ["Which schema?"]},
        {"id": "c", "status": "running", "title": "Run", "spec": {"kind": "model_layer", "source": {"mapping_files": ["m.yaml"]}}},
        {"id": "d", "status": "done", "title": "Closed"},
    ]
    found = {s.key: s for s in sig.intents(rows)}
    assert set(found) == {"intent:a:approve", "intent:b:questions", "intent:c:working"}
    assert found["intent:a:approve"].action["kind"] == "approve_intent" and "2 tables planned, 1 risk" in found["intent:a:approve"].detail
    assert found["intent:c:working"].skill == "silver-compiler" and found["intent:c:working"].status == "running"


def test_stale_catalogs_gaps_and_uncrawled_repos():
    freshness = [
        {"connector_name": "snowflake", "source_system": "snowflake", "last_success_at": NOW - timedelta(hours=30), "last_status": "completed"},
        {"connector_name": "databricks", "source_system": "databricks", "last_success_at": NOW - timedelta(hours=2), "last_status": "completed"},
        {"connector_name": "jira", "source_system": "jira", "last_success_at": NOW - timedelta(days=9), "last_status": "completed"},
    ]
    assert [s.key for s in sig.stale_syncs(freshness, NOW)] == ["sync:snowflake"]
    gaps = sig.catalog_gaps({"assets": 15, "described": 12, "facts": 4, "keyed_facts": 4, "undocumented": [{"fqn": "DB.S.T"}]})
    assert [g.key for g in gaps] == ["curate:undocumented"] and "DB.S.T" in gaps[0].detail
    payload = {"configured": ["acme/pipes"], "crawled": [{"repo": "acme/lake", "crawled_at": (NOW - timedelta(days=1)).isoformat()}]}
    assert [s.key for s in sig.repos(payload, NOW)] == ["crawl:acme/pipes"]


# --------------------------------------------------------------------------- skills
def test_the_repo_crawler_package_describes_the_hub_skill():
    pkg = read_package(PACKAGE.read_text(encoding="utf-8"), where="repo-crawler/SKILL.md")
    assert pkg is not None and pkg.key == "repo-crawler" and pkg.tier == "T2"
    assert "same graph hash" in pkg.gate and pkg.stops == ("Gate failure (non-idempotent output) stops the graph write.",)
    assert pkg.actions == ("read", "write_graph") and pkg.extra["persona"] == "context-librarian"
    skills = {s.key: s for s in skills_for("data_engineer", [pkg])}
    crawler = skills["repo-crawler"]
    assert crawler.source == "package" and crawler.runnable and crawler.package == "repo-crawler/SKILL.md"
    other = read_package("---\nname: evidence-pack-builder\nmetadata:\n  autonomy_ceiling: T3\n---\n# x\n")
    assert other is not None
    listed = skills_for("data_engineer", [other])
    assert listed[-1].key == "evidence-pack-builder" and not listed[-1].runnable


def test_the_collection_packages_govern_the_skills_they_are_bound_to():
    folder = PACKAGE.parents[1]
    packages = load_packages(folder)
    names = {p.key for p in packages}
    assert {"repo-crawler", "data-engineering-agent", "data-modelling-agent"} <= names
    skills = {s.key: s for s in skills_for("data_engineer", packages, load_bindings(folder))}
    builder, modeller = skills["pipeline-builder"], skills["silver-compiler"]
    assert builder.source == "package" and builder.package.startswith("data-engineering-agent") and builder.tier == "T2"  # no ceiling named: the hub's stays
    assert "Never invent a column" in builder.rules and "Reference files" not in builder.rules
    assert modeller.source == "package" and "The validators are authoritative" in modeller.rules
    # Masking has no hub skill yet, so the one playbook bound nowhere is reference only.
    assert [s.key for s in skills.values() if not s.runnable] == ["lineage-pii-and-governance"]


def test_playbooks_add_red_flags_and_checks_without_changing_the_tier_or_gate():
    folder = PACKAGE.parents[1]
    triage = read_package((folder / "de-agent-skills" / "incident-triage-and-pipeline-recovery" / "SKILL.md").read_text(encoding="utf-8"))
    assert triage is not None and triage.playbook and triage.rules == () and triage.tier == ""
    assert "reruns happen before impact is understood" in triage.red_flags
    assert triage.checks[0] == "Impact scope and affected consumers are identified"  # the checkbox is dropped
    backfill = read_package((folder / "de-agent-skills" / "safe-backfill-and-replay-orchestration" / "SKILL.md").read_text(encoding="utf-8"))
    assert backfill is not None and "templates/backfill-plan.yaml is complete and approved" in backfill.checks  # backticks dropped

    skills = {s.key: s for s in skills_for("data_engineer", load_packages(folder), load_bindings(folder))}
    hub = {s.key: s for s in skills_for("data_engineer", [])}
    run_triage = skills["run-triage"]
    assert [p.key for p in run_triage.playbooks] == ["incident-triage-and-pipeline-recovery", "safe-backfill-and-replay-orchestration"]
    assert (run_triage.tier, run_triage.gate, run_triage.source) == (hub["run-triage"].tier, hub["run-triage"].gate, "hub")
    builder = skills["pipeline-builder"]  # its governing package stays, the two playbooks join it
    assert builder.package.startswith("data-engineering-agent") and {p.key for p in builder.playbooks} == {"pipeline-planning-and-task-breakdown", "data-specification"}
    assert [p.key for p in skills["schema-integrity"].playbooks] == ["schema-evolution-and-contract-migrations"]
    assert skills["lineage-pii-and-governance"].tier == "T1" and skills["lineage-pii-and-governance"].red_flags


# --------------------------------------------------------------------------- capabilities
def _facts(**overrides: bool) -> dict[str, caps.Fact]:
    facts = {key: caps.Fact(True, "in place") for key in caps.NEEDS}
    facts.update({k: caps.Fact(v, "in place" if v else "missing here") for k, v in overrides.items()})
    return facts


def test_preparing_code_and_executing_it_are_separate_abilities():
    found = {c["key"]: c for c in caps.evaluate(caps.DATA_ENGINEER, _facts(runner=False))}
    prepare = found["prepare"]
    assert prepare["readiness"] == "available"  # the code can still be prepared
    execute = next(a for a in prepare["abilities"] if a["label"].startswith("Execute"))
    assert execute["status"] == "tool_unavailable" and execute["reason"] == "Pipeline runner: missing here"
    refused = {c["key"]: c for c in caps.evaluate(caps.DATA_ENGINEER, _facts(run_access=False))}["prepare"]
    assert next(a for a in refused["abilities"] if a["label"].startswith("Execute"))["status"] == "missing_connection"


def test_a_capability_is_available_only_when_a_headline_ability_has_everything_it_needs():
    found = {c["key"]: c for c in caps.evaluate(caps.DATA_ENGINEER, _facts(jira=False, model=False, designs=False, graph=False, catalog=False))}
    assert (found["understand"]["readiness"], found["understand"]["reason"]) == ("missing_connection", "Jira connection: missing here")
    assert found["design"]["readiness"] == "tool_unavailable"  # neither route: no Claude to propose, no design files to compile
    assert {c["key"]: c for c in caps.evaluate(caps.DATA_ENGINEER, _facts(model=False))}["design"]["readiness"] == "available"  # the files compile
    assert found["explain"]["readiness"] == "missing_connection"
    # Optional abilities the hub does not have never make a capability look unavailable, and an unchecked need is missing.
    assert {c["key"]: c for c in caps.evaluate(caps.DATA_ENGINEER, _facts(er_diagram=False))}["design"]["readiness"] == "available"
    unchecked = {c["key"]: c for c in caps.evaluate(caps.DATA_ENGINEER, {})}
    assert unchecked["understand"]["readiness"] == "missing_connection" and unchecked["investigate"]["readiness"] == "available"


def test_the_worker_reads_its_facts_without_secrets(tmp_path: Path):
    class Config:
        jira_configured, snowflake_configured, model_available, run_enabled, run_role = True, True, False, True, "LOADER"
        run_missing = ["ECH_RUN_SNOWFLAKE_TOKEN"]

    worker = DigitalWorker(
        repo=MemoryWorkerRepo(),  # type: ignore[arg-type]
        runs=FakeRuns(),  # type: ignore[arg-type]
        intent_rows=Empty(),  # type: ignore[arg-type]
        semantic=Empty(),  # type: ignore[arg-type]
        crawls=Empty(),  # type: ignore[arg-type]
        skills_dir=tmp_path,
        ingestion_url=None,
        intent_config=lambda: Config(),
    )
    facts = worker.facts()
    assert facts["jira"].ok and not facts["model"].ok and facts["runner"].ok
    assert (facts["run_settings"].ok, facts["run_settings"].detail) == (False, "missing ECH_RUN_SNOWFLAKE_TOKEN")
    assert not facts["ingestion"].ok and not facts["catalog"].ok and "first sweep" in facts["catalog"].detail
    worker._intents_seen = [{"run": {"status": "failed", "started_at": "2026-10-28T09:00:00", "error": "Insufficient privileges to operate on schema"}}]
    assert not worker.facts()["run_access"].ok


# --------------------------------------------------------------------------- the journal
def _chain(n: int) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    prev = None
    for i in range(n):
        row = {"worker": "w", "at": NOW + timedelta(seconds=i), "kind": "observed", "item_key": f"k{i}", "skill": "s", "message": f"m{i}", "evidence": {"i": i}}
        digest = record_hash(prev, entry_body(row))
        rows.append({**row, "id": i + 1, "prev_hash": prev, "record_hash": digest})
        prev = digest
    return list(reversed(rows))


def test_the_journal_chain_shows_an_edited_entry():
    rows = _chain(4)
    assert chain_ok(rows)
    rows[2] = {**rows[2], "message": "rewritten"}
    assert not chain_ok(rows)


# --------------------------------------------------------------------------- a sweep end to end, in memory
class MemoryWorkerRepo:
    def __init__(self) -> None:
        self.items_: dict[str, dict[str, Any]] = {}
        self.rows: list[dict[str, Any]] = []
        self.paused = False
        self.last_tick: datetime | None = None

    async def item(self, key: str) -> dict[str, Any] | None:
        return dict(self.items_[key]) if key in self.items_ else None

    async def items(self, worker: str, *, closed_since: datetime | None = None, limit: int = 120) -> list[dict[str, Any]]:
        return [dict(i) for i in self.items_.values() if i["status"] in OPEN_STATUSES or (closed_since and i["updated_at"] >= closed_since)]

    async def open_keys(self, worker: str) -> dict[str, dict[str, Any]]:
        return {k: dict(v) for k, v in self.items_.items() if v["status"] in OPEN_STATUSES}

    async def upsert(self, **f: Any) -> tuple[dict[str, Any], bool]:
        now = datetime.now(UTC)
        new = f["key"] not in self.items_
        base = self.items_.get(f["key"], {"created_at": now, "decided_by": None, "decided_at": None})
        self.items_[f["key"]] = {**base, **json.loads(json.dumps(f, default=str)), "updated_at": now}
        return dict(self.items_[f["key"]]), new

    async def update(self, key: str, **fields: Any) -> dict[str, Any] | None:
        self.items_[key] = {**self.items_[key], **fields, "updated_at": datetime.now(UTC)}
        return dict(self.items_[key])

    async def append(self, worker: str, kind: str, message: str, *, item_key: str | None = None, skill: str | None = None, evidence: dict[str, Any] | None = None) -> dict[str, Any]:
        prev = self.rows[-1]["record_hash"] if self.rows else None
        row = {"worker": worker, "at": datetime.now(UTC), "kind": kind, "item_key": item_key, "skill": skill, "message": message, "evidence": json.loads(json.dumps(evidence or {}, default=str))}
        row.update(id=len(self.rows) + 1, prev_hash=prev, record_hash=record_hash(prev, entry_body(row)))
        self.rows.append(row)
        return row

    async def journal(self, worker: str, *, limit: int = 40) -> list[dict[str, Any]]:
        return list(reversed(self.rows))[:limit]

    async def counts(self, worker: str) -> dict[str, Any]:
        st = [i["status"] for i in self.items_.values()]
        return {"open": sum(s in OPEN_STATUSES for s in st), "waiting": st.count("waiting"), "running": st.count("running"), "done_today": st.count("done"), "failed_today": st.count("failed")}

    async def skill_counts(self, worker: str) -> dict[str, dict[str, Any]]:
        return {}

    async def state(self, worker: str) -> dict[str, Any]:
        return {"worker": worker, "paused": self.paused, "last_tick": self.last_tick}

    async def set_paused(self, worker: str, paused: bool) -> None:
        self.paused = paused

    async def touch(self, worker: str) -> None:
        self.last_tick = datetime.now(UTC)


class FakeRuns:
    def __init__(self) -> None:
        self.failed_id = uuid4()
        self.started: IngestionRunRecord | None = None
        self.recovered = False

    async def recent_failures(self, *, days: int, limit: int = 20) -> list[dict[str, Any]]:
        return [{"id": self.failed_id, "connector_name": "snowflake", "error": "ReadTimeout: timed out", "finished_at": datetime.now(UTC) - timedelta(minutes=5)}]

    async def connector_freshness(self, *, days: int) -> list[dict[str, Any]]:
        ok = datetime.now(UTC) if self.recovered else datetime.now(UTC) - timedelta(hours=1)
        return [{"connector_name": "snowflake", "source_system": "snowflake", "last_success_at": ok, "last_status": "completed", "runs": 3}]

    async def count_stale_active(self, *, hours: int) -> int:
        return 0

    async def get(self, run_id: UUID) -> IngestionRunRecord | None:
        if run_id == self.failed_id:
            return _record(run_id, RunStatus.FAILED, {"scope": [{"path": ["DB", "S"], "kind": "schema"}], "full_refresh": True})
        return self.started

    async def list(self, **kwargs: Any) -> tuple[list[IngestionRunRecord], int]:
        return [], 0


def _record(run_id: UUID, status: RunStatus, config: dict[str, Any] | None = None) -> IngestionRunRecord:
    now = datetime.now(UTC)
    return IngestionRunRecord(id=run_id, connector_name="snowflake", source_system="snowflake", status=status, config=config or {}, stats={"documents_upserted": 15}, created_at=now, updated_at=now)


class Empty:
    async def list(self, **kwargs: Any) -> tuple[list[dict[str, Any]], int]:
        return [], 0

    async def health(self, *, list_limit: int = 25) -> dict[str, Any]:
        return {"assets": 3, "described": 3, "facts": 0, "keyed_facts": 0}

    async def get(self, crawl_id: UUID) -> dict[str, Any] | None:
        return None


def test_a_sweep_picks_up_a_failure_waits_for_approval_then_reruns_and_follows_it(tmp_path: Path):
    repo, runs = MemoryWorkerRepo(), FakeRuns()
    posted: list[dict[str, Any]] = []
    started_id = uuid4()

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/repo-graph/repos":
            return httpx.Response(200, json={"crawled": [], "configured": []})
        posted.append(json.loads(request.content))
        return httpx.Response(202, json={"id": str(started_id)})

    worker = DigitalWorker(
        repo=repo,  # type: ignore[arg-type]
        runs=runs,  # type: ignore[arg-type]
        intent_rows=Empty(),  # type: ignore[arg-type]
        semantic=Empty(),  # type: ignore[arg-type]
        crawls=Empty(),  # type: ignore[arg-type]
        skills_dir=tmp_path,
        ingestion_url="http://ingestion",
        http=lambda: httpx.AsyncClient(base_url="http://ingestion", transport=httpx.MockTransport(handler)),
    )
    key = f"run-failed:{runs.failed_id}"

    async def go() -> None:
        await worker.sweep()
        item = repo.items_[key]
        assert item["status"] == "waiting" and item["action"]["kind"] == "rerun"
        assert [r["kind"] for r in repo.rows] == ["observed", "diagnosed", "proposed"]
        await worker.sweep()  # nothing new: no journal noise
        assert len(repo.rows) == 3

        decided = await worker.decide("data_engineer", key, WorkerDecision(decision="approve"))
        assert decided.status == "running" and decided.evidence["started"]["id"] == str(started_id)
        assert posted == [
            {"connector": "snowflake", "options": {"full_refresh": True}, "scope": [{"path": ["DB", "S"], "kind": "schema"}], "source_options": {}, "triggered_by": "worker:data_engineer"}
        ]

        runs.started = _record(started_id, RunStatus.COMPLETED)
        runs.recovered = True
        await worker.sweep()
        assert repo.items_[key]["status"] == "done"
        snap = await worker.snapshot("data_engineer")
        assert snap.chain_ok and [e.kind for e in reversed(snap.journal)] == ["observed", "diagnosed", "proposed", "approved", "acted", "done"]
        assert "snowflake run completed: 15 documents" in snap.journal[0].message
        assert {s.key for s in snap.skills} >= {"run-triage", "repo-crawler", "catalog-sync"}

        repo.paused = True
        assert await worker.sweep() == 0

    asyncio.run(go())


TRIAGE_PLAYBOOK = """---
name: triage-playbook
description: x
---
## Red Flags
- reruns happen before impact is understood
## Verification
- [ ] Impact scope is identified
- [ ] Publish is reopened only after validation
"""


def test_an_approval_records_which_playbook_checks_were_confirmed(tmp_path: Path):
    from ech_core.exceptions import InvalidRequestError

    folder = tmp_path / "data_engineer"
    (folder / "triage").mkdir(parents=True)
    (folder / "triage" / "SKILL.md").write_text(TRIAGE_PLAYBOOK, encoding="utf-8")
    (folder / "bindings.yml").write_text("triage-playbook: run-triage\n", encoding="utf-8")
    repo, runs = MemoryWorkerRepo(), FakeRuns()

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/repo-graph/repos":
            return httpx.Response(200, json={"crawled": [], "configured": []})
        return httpx.Response(202, json={"id": str(uuid4())})

    worker = DigitalWorker(
        repo=repo,  # type: ignore[arg-type]
        runs=runs,  # type: ignore[arg-type]
        intent_rows=Empty(),  # type: ignore[arg-type]
        semantic=Empty(),  # type: ignore[arg-type]
        crawls=Empty(),  # type: ignore[arg-type]
        skills_dir=tmp_path,
        ingestion_url="http://ingestion",
        http=lambda: httpx.AsyncClient(base_url="http://ingestion", transport=httpx.MockTransport(handler)),
    )
    key = f"run-failed:{runs.failed_id}"
    assert worker.checklist("data_engineer", "run-triage") == [
        ("triage-playbook", "Impact scope is identified"),
        ("triage-playbook", "Publish is reopened only after validation"),
    ]

    async def go() -> None:
        await worker.sweep()
        try:
            await worker.decide("data_engineer", key, WorkerDecision(decision="approve", checks=["Looks fine to me"]))
            raise AssertionError("a check no playbook lists was accepted")
        except InvalidRequestError as exc:
            assert "not a check" in str(exc)
        assert repo.items_[key]["status"] == "waiting"  # nothing started, nothing journalled
        await worker.decide("data_engineer", key, WorkerDecision(decision="approve", checks=["Impact scope is identified"]))
        approved = next(r for r in repo.rows if r["kind"] == "approved")
        assert approved["message"].endswith("; 1 of 2 playbook checks confirmed")
        assert approved["evidence"]["checklist"] == [
            {"playbook": "triage-playbook", "check": "Impact scope is identified", "confirmed": True},
            {"playbook": "triage-playbook", "check": "Publish is reopened only after validation", "confirmed": False},
        ]
        assert repo.items_[key]["status"] == "running"  # an unticked check does not block the approval

    asyncio.run(go())


def test_a_dismissed_failure_stays_quiet_and_open_items_cannot_be_approved(tmp_path: Path):
    repo, runs = MemoryWorkerRepo(), FakeRuns()

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"crawled": [], "configured": []})

    worker = DigitalWorker(
        repo=repo,  # type: ignore[arg-type]
        runs=runs,  # type: ignore[arg-type]
        intent_rows=Empty(),  # type: ignore[arg-type]
        semantic=Empty(),  # type: ignore[arg-type]
        crawls=Empty(),  # type: ignore[arg-type]
        skills_dir=tmp_path,
        ingestion_url="http://ingestion",
        http=lambda: httpx.AsyncClient(base_url="http://ingestion", transport=httpx.MockTransport(handler)),
    )
    key = f"run-failed:{runs.failed_id}"

    async def go() -> None:
        await worker.sweep()
        await worker.decide("data_engineer", key, WorkerDecision(decision="dismiss", note="known outage"))
        await worker.sweep()
        assert repo.items_[key]["status"] == "dismissed"
        assert repo.rows[-1]["kind"] == "dismissed" and "known outage" in repo.rows[-1]["message"]

    asyncio.run(go())


# --------------------------------------------------------------------------- planned against live
def _observed(fqn: str, rows: int | None) -> dict[str, Any]:
    db, schema, name = fqn.split(".")
    return {"platform": "snowflake", "fqn": fqn, "database_name": db, "schema_name": schema, "name": name, "row_count": rows, "synced_at": NOW}


def test_declared_tables_are_live_empty_or_planned_with_their_readers():
    declared = integ.from_repo(
        [
            {"repo": "acme/lake", "name": "BRONZE.B_CITY", "layer": "bronze", "reads": []},
            {"repo": "acme/lake", "name": "BRONZE.CLIENT", "layer": "bronze", "reads": []},
            {"repo": "acme/lake", "name": "SILVER.DIM_PARTY", "layer": "silver", "reads": ["BRONZE.CLIENT"]},
        ]
    )
    observed = [_observed("DB.BRONZE.CITY_ICEBERG", 16), _observed("DB.BRONZE.CLIENT", 0), _observed("DB.BRONZE.OTHER", 5)]
    rows = {r["table"]: r for r in integ.classify(declared, observed, {"SILVER.DIM_PARTY": ["KAN-5 plan"]})}
    assert (rows["BRONZE.B_CITY"]["status"], rows["BRONZE.B_CITY"]["loaded_as"]) == ("live", "CITY_ICEBERG")
    assert rows["BRONZE.CLIENT"]["status"] == "empty" and rows["BRONZE.CLIENT"]["readers"] == ["SILVER.DIM_PARTY derives from it"]
    assert rows["SILVER.DIM_PARTY"]["status"] == "planned_only" and rows["SILVER.DIM_PARTY"]["readers"] == ["KAN-5 plan reads it"]
    s = integ.summary(list(rows.values()), observed)
    assert s["origins"][0] == {"origin": "acme/lake", "kind": "repo", "declared": 3, "live": 1, "empty": 1, "exists": 0, "planned_only": 1, "aliases": 1}
    assert s["undeclared"] == 1
    found = {x.key: x for x in integ.signals(list(rows.values()))}
    assert set(found) == {"integrity:planned_only:acme/lake", "integrity:empty:acme/lake"}
    assert found["integrity:empty:acme/lake"].evidence["readers"] == ["SILVER.DIM_PARTY derives from it"]


def test_design_documents_declare_their_tables_and_foreign_keys(tmp_path: Path):
    design = tmp_path / "DE-main" / "silver"
    design.mkdir(parents=True)
    (design / "ddl.sql").write_text(
        "CREATE TABLE SILVER.DIM_PARTY (PARTY_SK VARCHAR NOT NULL, PRIMARY KEY (PARTY_SK));\n"
        "CREATE TABLE SILVER.FACT_AGREEMENT (AGREEMENT_SK VARCHAR NOT NULL, PARTY_SK VARCHAR, PRIMARY KEY (AGREEMENT_SK),"
        " FOREIGN KEY (PARTY_SK) REFERENCES SILVER.DIM_PARTY(PARTY_SK));\n",
        encoding="utf-8",
    )
    skipped = tmp_path / "digital-worker" / "data_engineer"
    skipped.mkdir(parents=True)
    (skipped / "example.sql").write_text("CREATE TABLE GOLD.NOT_OURS (A INT);", encoding="utf-8")
    declared = integ.from_designs(tmp_path)
    assert [(d.origin, d.schema, d.name, d.reads) for d in declared] == [
        ("DE-main/silver", "SILVER", "DIM_PARTY", []),
        ("DE-main/silver", "SILVER", "FACT_AGREEMENT", ["SILVER.DIM_PARTY"]),
    ]
    rows = {r["table"]: r for r in integ.classify(declared, [])}
    assert rows["SILVER.DIM_PARTY"]["readers"] == ["SILVER.FACT_AGREEMENT references it"]


def test_a_plan_reading_empty_or_missing_tables_is_blocked():
    spec = PipelineSpec(
        name="model_x",
        kind="model_layer",
        summary="",
        source=IntentSource(database="DB", schema="BRONZE"),
        target=IntentTarget(database="DB", schema="SILVER"),
        models=[
            ModelTable(name="A", kind="dimension", grain="g", sql="SELECT 1", sources=["DB.BRONZE.LOADED", "DB.BRONZE.EMPTY", "DB.BRONZE.GONE", "DB.SILVER.A"]),
        ],
    )
    validation = IntentValidation(
        checked_at=NOW,
        reachable=True,
        objects=[
            ValidatedObject(kind="table", name="DB.BRONZE.LOADED", role="source", exists=True, rows=10),
            ValidatedObject(kind="table", name="DB.BRONZE.EMPTY", role="source", exists=True, rows=0),
        ],
    )
    blockers = plan_blockers(spec, validation)
    assert blockers == [
        "DB.BRONZE.EMPTY exists but holds no rows: it was created and never loaded.",
        "DB.BRONZE.GONE is not in the warehouse: it is declared, not built.",
    ]
    assert plan_blockers(spec, IntentValidation(checked_at=NOW, reachable=False)) == []  # unchecked: nothing to claim
    found = sig.intents([{"id": "i", "status": "spec_proposed", "title": "Gold", "spec": {"blockers": blockers}}])
    assert [(s.key, s.status, s.action["kind"]) for s in found] == [("intent:i:blocked", "diagnosed", "open")]


def test_a_blocked_plan_cannot_be_approved(tmp_path: Path):
    from ech_core.exceptions import InvalidRequestError
    from ech_core.schemas.intents import IntentDecision
    from tests.test_intents import _service

    service, repo = _service(tmp_path)

    async def go() -> None:
        row = await repo.create(source="manual", title="Gold", text="", reporter="")
        await repo.update(row["id"], status="spec_proposed", spec={"blockers": ["DB.SILVER.X is not in the warehouse: it is declared, not built."]})
        try:
            await service.decide(row["id"], IntentDecision(decision="approve"))
        except InvalidRequestError as exc:
            assert "hold no rows" in str(exc)
        else:
            raise AssertionError("a blocked plan was approved")
        assert repo.rows[row["id"]]["status"] == "spec_proposed"

    asyncio.run(go())


class FakeGraph:
    async def declared_tables(self) -> list[dict[str, Any]]:
        return [{"repo": "acme/lake", "name": "SILVER.DIM_PARTY", "layer": "silver", "reads": []}]


class BrokenGraph:
    async def declared_tables(self) -> list[dict[str, Any]]:
        raise RuntimeError("neo4j is down")


def test_a_sweep_reports_planned_tables_and_says_so_when_the_graph_is_down(tmp_path: Path):
    repo, runs = MemoryWorkerRepo(), FakeRuns()
    runs.recovered = True

    async def catalog_tables() -> list[dict[str, Any]]:
        return [_observed("DB.BRONZE.CLIENT", 10)]

    repo.catalog_tables = catalog_tables  # type: ignore[attr-defined]

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"crawled": [], "configured": []})

    def make(graph: Any) -> DigitalWorker:
        return DigitalWorker(
            repo=repo,  # type: ignore[arg-type]
            runs=runs,  # type: ignore[arg-type]
            intent_rows=Empty(),  # type: ignore[arg-type]
            semantic=Empty(),  # type: ignore[arg-type]
            crawls=Empty(),  # type: ignore[arg-type]
            skills_dir=tmp_path / "skills",
            ingestion_url="http://ingestion",
            http=lambda: httpx.AsyncClient(base_url="http://ingestion", transport=httpx.MockTransport(handler)),
            repo_graph=graph,
            design_root=tmp_path,
        )

    async def go() -> None:
        worker = make(FakeGraph())
        await worker.sweep(force=True)
        assert repo.items_["integrity:planned_only:acme/lake"]["skill"] == "schema-integrity"
        snap = await worker.snapshot("data_engineer")
        assert snap.integrity is not None and snap.integrity.available and snap.integrity.origins[0].planned_only == 1
        assert snap.integrity.undeclared == 1 and "schema-integrity" in {s.key for s in snap.skills}

        down = make(BrokenGraph())
        await down.sweep(force=True)
        snap = await down.snapshot("data_engineer")
        assert snap.integrity is not None and not snap.integrity.available and "neo4j is down" in snap.integrity.problem
        assert repo.items_["integrity:planned_only:acme/lake"]["status"] == "diagnosed"  # blind is not resolved: the finding stays open

    asyncio.run(go())

