from contextlib import asynccontextmanager

import pytest
from fastapi import APIRouter
from fastapi.testclient import TestClient

from ech_core.app_factory import create_app
from ech_core.config import Settings
from ech_core.exceptions import NotFoundError
from ech_core.observability import LatencyRecorder


@pytest.fixture
def client():
    settings = Settings(_env_file=None, service_name="test-service")
    router = APIRouter()

    @router.get("/boom")
    async def boom():
        raise NotFoundError("nothing here", details={"thing": 1})

    @router.get("/crash")
    async def crash():
        raise RuntimeError("unexpected")

    @router.get("/ok/{item_id}")
    async def ok(item_id: int):
        return {"item_id": item_id}

    @asynccontextmanager
    async def lifespan(app):
        async def good():
            return True

        async def bad():
            return False

        app.state.readiness_checks = {"postgres": good, "neo4j": bad}
        yield

    recorder = LatencyRecorder(100)
    app = create_app(
        settings=settings,
        title="t",
        description="d",
        version="0.0.1",
        lifespan=lifespan,
        routers=[router],
        latency_recorder=recorder,
    )
    with TestClient(app, raise_server_exceptions=False) as c:
        c.recorder = recorder
        yield c


def test_error_envelope_and_request_id(client):
    r = client.get("/boom", headers={"X-Request-ID": "req-123"})
    assert r.status_code == 404
    body = r.json()["error"]
    assert body["code"] == "not_found" and body["details"] == {"thing": 1}
    assert body["request_id"] == "req-123"
    assert r.headers["x-request-id"] == "req-123"
    assert "x-response-time-ms" in r.headers


def test_unhandled_exception_is_masked(client):
    r = client.get("/crash")
    assert r.status_code == 500
    assert r.json()["error"]["code"] == "internal_error"


def test_validation_error_uses_envelope(client):
    r = client.get("/ok/not-an-int")
    assert r.status_code == 422
    assert r.json()["error"]["code"] == "validation_error"


def test_health_and_metrics(client):
    assert client.get("/health/live").json()["status"] == "ok"
    ready = client.get("/health/ready")
    assert ready.status_code == 503
    assert ready.json()["checks"] == {"postgres": True, "neo4j": False}
    metrics = client.get("/metrics")
    assert metrics.status_code == 200
    assert "ech_http_requests_total" in metrics.text


def test_latency_recorder_collects_samples(client):
    for i in range(3):
        client.get(f"/ok/{i}")
    series = client.recorder.series(window_minutes=5, bucket_seconds=60, path_prefix="/ok")
    assert series.overall is not None and series.overall.count == 3
    assert series.points[-1].count >= 1
