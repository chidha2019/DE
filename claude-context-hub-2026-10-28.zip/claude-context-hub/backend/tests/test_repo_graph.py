"""Repo knowledge graph: SQL templating, Snowflake DDL detection and the graph a crawl builds."""

from __future__ import annotations

import pytest

from ech_core.repo_graph import GraphBuild, RepoInfo, build_repo_graph, file_role, is_text_path
from ech_core.repo_graph import sql_text as st

SOURCES = """
version: 1
mode: complete_snapshot
sources:
- id: A_CLAIM
  format: csv
  key: [CLAIM_ID]
  source_path: vantage_core/claim.csv
  source_system: vantage_core
  columns:
  - {name: CLAIM_ID, source: Claim_Id, kind: text, required: true}
  - {name: AGREEMENT_ID, source: Agreement_Id, kind: text, required: true}
  - {name: CLAIM_AMOUNT, source: Claim_Amount, kind: decimal, required: true}
- id: A_INCIDENT
  format: csv
  key: [INCIDENT_ID]
  source_path: vantage_core/incident.csv
  source_system: vantage_core
  columns:
  - {name: INCIDENT_ID, source: Incident_Id, kind: text, required: true}
  - {name: CLAIM_ID, source: Claim_Id, kind: text, required: true}
  - {name: INCIDENT_DATE, source: Incident_Date, kind: date, required: false}
"""
MODELS = """
models:
- name: fact_loss_event
  layer: silver
  key: [LOSS_EVENT_SK]
  columns:
  - {name: LOSS_EVENT_SK, type: STRING}
  - {name: SOURCE_SYSTEM, type: STRING}
  - {name: LOSS_DT, type: DATE}
  - {name: REQUESTED_AMT, type: "NUMBER(18,2)"}
"""
ASSETS = """
assets:
- id: SILVER.FACT_LOSS_EVENT
  grain: [LOSS_EVENT_SK]
  owner: data-engineering
  definition: sql/silver/fact_loss_event.sql
  depends_on: [BRONZE.A_CLAIM, BRONZE.A_INCIDENT]
"""
PIPELINE = "pipeline_id: claims_core\nmax_run_seconds: 3300\nsilver: [fact_loss_event]\n"
STORAGE = """
create storage integration if not exists LANDING_READ
 type=EXTERNAL_STAGE storage_provider='S3' enabled=true
 storage_aws_role_arn='arn:aws:iam::111:role/landing-read'
 storage_allowed_locations=('s3://landing-bucket/');
create external volume if not exists ICEBERG_VOL
 storage_locations=((name='managed' storage_provider='S3'
 storage_base_url='s3://lake-bucket/managed/'
 storage_aws_role_arn='arn:aws:iam::111:role/iceberg-write'))
 allow_writes=true;
"""
DEPLOY = '''
def statements(sql, settings):
    return [
        f"create file format if not exists {sql.database}.INGESTION.CSV_SOURCE type=CSV skip_header=1 "
        "field_optionally_enclosed_by='x'",
        f"create stage if not exists {sql.database}.INGESTION.LANDING "
        f"url='s3://{settings.landing_bucket}/' storage_integration=LANDING_READ",
    ]
'''
SQLPY = '''
from pipeline.config import read_config


class SQL:
    """Renders the layer SQL."""

    def __init__(self, database, external_volume="ICEBERG_VOL"):
        self.sources = read_config("sources.yml")

    def copy(self, source, files):
        return (
            f"copy into {self.table('BRONZE', source['id'])} from (select 1 from @{self.database}.INGESTION.LANDING t) "
            f"file_format=(format_name={self.database}.INGESTION.{fmt}) load_mode=FULL_INGEST"
        )

    def _iceberg(self, layer, name, columns):
        return (
            f"create iceberg table if not exists {self.table(layer, name)} (x) "
            f"catalog='SNOWFLAKE' external_volume='{self.external_volume}' base_location='{path}'"
        )
'''
CONFIGPY = '"""Config loading."""\n\ndef read_config(name):\n    return name\n'
SILVER = """
select {{ key('A','CLAIM','c.CLAIM_ID') }} LOSS_EVENT_SK, 'A' SOURCE_SYSTEM,
 to_date(i.INCIDENT_DATE,'YYYY-MM-DD') LOSS_DT, to_decimal(c.CLAIM_AMOUNT,18,2) REQUESTED_AMT
from {{ bronze('A_CLAIM') }} c join {{ bronze('A_INCIDENT') }} i on c.CLAIM_ID=i.CLAIM_ID
"""
CHECKS = """
select 'A_CLAIM.unique' CHECK_NAME,count(*) FAILURES from (select CLAIM_ID from {{ bronze('A_CLAIM') }} group by CLAIM_ID having count(*)>1) violations
union all
select 'A_CLAIM.CLAIM_ID.required' CHECK_NAME,count(*) FAILURES from (select 1 from {{ bronze('A_CLAIM') }} where CLAIM_ID is null) violations
"""
SERVING = """
create or replace secure view {{ database }}.SERVING.LOSS_METRICS as
select l.LOSS_EVENT_SK, l.REQUESTED_AMT AS REQUESTED_AMOUNT from {{ database }}.SILVER.FACT_LOSS_EVENT l;
"""
JENKINS = "pipeline { stages { stage('Validate') { } stage('Deploy') { } } }"
ALERTS = """
groups:
  - name: claims
    rules:
      - alert: ClaimsStale
        expr: freshness_seconds > 7200
        labels: {severity: critical, owner: data-engineering}
"""
TEST = "from pipeline.sql import SQL\n\ndef test_it():\n    assert SQL\n"

FILES = {
    "config/sources.yml": SOURCES,
    "config/models.yml": MODELS,
    "config/assets.yml": ASSETS,
    "config/pipeline.yml": PIPELINE,
    "sql/bootstrap/storage.sql": STORAGE,
    "sql/bootstrap/serving.sql": SERVING,
    "sql/silver/fact_loss_event.sql": SILVER,
    "sql/checks/bronze_quality.sql": CHECKS,
    "pipeline/deploy.py": DEPLOY,
    "pipeline/sql.py": SQLPY,
    "pipeline/config.py": CONFIGPY,
    "tests/test_sql.py": TEST,
    "observability/alerts.yml": ALERTS,
    "Jenkinsfile": JENKINS,
    "README.md": "# Claims lakehouse\n\nFACT_LOSS_EVENT feeds LOSS_METRICS.\n",
}
REPO = "acme/claims-lakehouse"


@pytest.fixture(scope="module")
def built() -> tuple[GraphBuild, dict]:
    return build_repo_graph(RepoInfo(REPO, "main", sha="abc123"), dict(FILES))


def _edge(g: GraphBuild, src: tuple[str, str], dst: tuple[str, str], rel: str):
    return g.edges.get((g.key(*src), g.key(*dst), rel))


# ----------------------------------------------------------------------------- SQL helpers
def test_normalize_sql_resolves_layer_macros_refs_and_keys() -> None:
    sql = st.normalize_sql("select {{ key('A','X','c.ID') }} K from {{ bronze('a_claim') }} c join {{ ref('dim') }} d on 1=1 join {{ database }}.GOLD.T t")
    assert "BRONZE.A_CLAIM" in sql
    assert "MD5(CONCAT(c.ID))" in sql
    assert " DIM " in sql
    assert "GOLD.T" in sql and "database" not in sql.lower()


def test_ddl_objects_read_templated_python_strings() -> None:
    found = {(o.kind, o.name): o for o in st.ddl_objects(st.join_python_strings(DEPLOY))}
    stage = found[("stage", "INGESTION.LANDING")]
    assert stage.templated and stage.props["storage_integration"] == "LANDING_READ"
    assert found[("file_format", "INGESTION.CSV_SOURCE")].props["type"] == "CSV"
    copy = next(o for o in st.ddl_objects(st.join_python_strings(SQLPY)) if o.kind == "copy")
    assert copy.props["layer"] == "bronze" and copy.props["stage_ref"] == "INGESTION.LANDING"


def test_table_refs_skip_ctes() -> None:
    tree = st.parse("with s as (select * from BRONZE.A) select * from s join SILVER.B b on 1=1")
    assert tree is not None
    assert st.table_refs(tree) == {"BRONZE.A", "SILVER.B"}


def test_file_roles() -> None:
    assert file_role("tests/test_x.py") == "test"
    assert file_role("Jenkinsfile") == "ci"
    assert file_role("sql/silver/x.sql") == "sql"
    assert is_text_path("Jenkinsfile") and not is_text_path("data/x.parquet")


# ----------------------------------------------------------------------------- the graph
def test_sources_become_bronze_iceberg_tables_on_the_volume(built) -> None:
    g, summary = built
    table = g.get("table", "BRONZE.A_CLAIM")
    assert table is not None
    assert table.props["table_type"] == "iceberg" and table.props["managed"] is True
    assert table.props["external_volume"] == "ICEBERG_VOL"
    assert _edge(g, ("table", "BRONZE.A_CLAIM"), ("external_volume", "ICEBERG_VOL"), "STORED_ON").methods == {"inferred"}
    assert _edge(g, ("table", "BRONZE.A_CLAIM"), ("source", "A_CLAIM"), "LOADED_FROM") is not None
    column = g.get("column", "BRONZE.A_CLAIM.CLAIM_AMOUNT")
    assert column is not None and column.props["source_header"] == "Claim_Amount"
    assert summary["tables_by_layer"]["bronze"] == 2


def test_landing_path_runs_through_stage_integration_and_format(built) -> None:
    g, _ = built
    assert _edge(g, ("source", "A_CLAIM"), ("stage", "INGESTION.LANDING"), "LANDS_IN") is not None
    assert _edge(g, ("stage", "INGESTION.LANDING"), ("storage_integration", "LANDING_READ"), "USES").methods == {"parsed"}
    assert _edge(g, ("stage", "INGESTION.LANDING"), ("file_format", "INGESTION.CSV_SOURCE"), "USES") is not None
    assert _edge(g, ("stage", "INGESTION.LANDING"), ("s3_location", "s3://landing-bucket/"), "READS_FROM") is not None
    assert _edge(g, ("external_volume", "ICEBERG_VOL"), ("s3_location", "s3://lake-bucket/managed/"), "WRITES_TO") is not None


def test_table_lineage_is_declared_and_parsed(built) -> None:
    g, summary = built
    edge = _edge(g, ("table", "SILVER.FACT_LOSS_EVENT"), ("table", "BRONZE.A_INCIDENT"), "DERIVED_FROM")
    assert edge is not None and edge.methods == {"declared", "parsed"}
    assert summary["declared_vs_parsed"] == []


def test_column_lineage_traces_through_macros_and_views(built) -> None:
    g, summary = built
    assert _edge(g, ("column", "SILVER.FACT_LOSS_EVENT.LOSS_DT"), ("column", "BRONZE.A_INCIDENT.INCIDENT_DATE"), "DERIVED_FROM")
    assert _edge(g, ("column", "SILVER.FACT_LOSS_EVENT.LOSS_EVENT_SK"), ("column", "BRONZE.A_CLAIM.CLAIM_ID"), "DERIVED_FROM")
    assert g.get("column", "SILVER.FACT_LOSS_EVENT.SOURCE_SYSTEM").props["derivation"] == "constant"
    assert _edge(g, ("column", "SERVING.LOSS_METRICS.REQUESTED_AMOUNT"), ("column", "SILVER.FACT_LOSS_EVENT.REQUESTED_AMT"), "DERIVED_FROM")
    assert g.get("table", "SERVING.LOSS_METRICS").props["table_type"] == "secure_view"
    assert summary["lineage"] == {"model_columns": 4, "traced": 3, "constant": 1, "failed": 0}


def test_checks_code_ci_and_alerts(built) -> None:
    g, _ = built
    check = g.get("check", "A_CLAIM.CLAIM_ID.required")
    assert check is not None and check.props["column"] == "CLAIM_ID" and check.props["rule"] == "required"
    assert _edge(g, ("check", "A_CLAIM.unique"), ("table", "BRONZE.A_CLAIM"), "CHECKS").props["role"] == "subject"
    assert g.get("table", "BRONZE.A_CLAIM").props["checks"] == 2
    assert _edge(g, ("file", "pipeline/sql.py"), ("file", "pipeline/config.py"), "IMPORTS")
    assert _edge(g, ("file", "pipeline/sql.py"), ("file", "config/sources.yml"), "READS")
    assert _edge(g, ("file", "tests/test_sql.py"), ("file", "pipeline/sql.py"), "TESTS")
    assert g.get("symbol", "pipeline.sql.SQL").props["summary"] == "Renders the layer SQL."
    assert _edge(g, ("ci_stage", "Jenkinsfile:Validate"), ("ci_stage", "Jenkinsfile:Deploy"), "NEXT")
    assert _edge(g, ("alert", "ClaimsStale"), ("pipeline", "claims_core"), "MONITORS")
    assert _edge(g, ("file", "README.md"), ("table", "SILVER.FACT_LOSS_EVENT"), "DOCUMENTS")


def test_drift_between_declared_and_parsed_dependencies_is_reported() -> None:
    files = dict(FILES)
    files["config/assets.yml"] = ASSETS.replace("depends_on: [BRONZE.A_CLAIM, BRONZE.A_INCIDENT]", "depends_on: [BRONZE.A_CLAIM]")
    g, summary = build_repo_graph(RepoInfo(REPO, "main"), files)
    assert summary["declared_vs_parsed"] == ["SILVER.FACT_LOSS_EVENT reads BRONZE.A_INCIDENT but the assets config does not declare it"]


def test_rows_are_neo4j_ready_and_whitelisted(built) -> None:
    g, _ = built
    nodes = g.node_rows()
    assert set(nodes) <= {"Repository", "RepoFile", "CodeSymbol", "Pipeline", "SourceSystem", "DataSource", "DataTable", "DataColumn",
                          "QualityCheck", "StorageIntegration", "ExternalVolume", "Stage", "FileFormat", "S3Location", "CiStage", "Alert"}
    for rows in nodes.values():
        for row in rows:
            assert row["key"].startswith(f"{REPO}|") and row["props"]["repo"] == REPO
            assert all(not isinstance(v, dict) for v in row["props"].values())
    edges = g.edge_rows()
    assert all(r["props"]["methods"] for rows in edges.values() for r in rows)
    with pytest.raises(ValueError):
        g.edge(g.repo_key if hasattr(g, "repo_key") else next(iter(g.nodes)), next(iter(g.nodes)), "DROPS", method="parsed")
    with pytest.raises(ValueError):
        g.node("weird", "x")


# ----------------------------------------------------------------------------- the planner uses the graph
class _FakeRepoGraph:
    async def conventions(self) -> list[dict]:
        return [
            {
                "repo": "acme/claims",
                "ref": "main",
                "stages": [{"stage": "INGESTION.LANDING", "integration": "LANDING_READ", "file_format": "INGESTION.CSV_SOURCE"}],
                "volumes": [{"name": "ICEBERG_VOL", "base_url": "s3://lake/"}],
                "pipelines": [{"name": "claims_core"}],
                "sources": [
                    {"repo": "acme/claims", "source": "A_CLAIM", "headers": ["Claim_Id", "Agreement_Id", "Claim_Amount"], "path": "vantage_core/claim.csv", "table": "BRONZE.A_CLAIM"}
                ],
                "tables": [{"name": "BRONZE.A_CLAIM", "layer": "bronze"}, {"name": "BRONZE.CLAIMS", "layer": "bronze"}],
            }
        ]


async def test_planner_reuses_repo_conventions(tmp_path) -> None:
    from ech_core.schemas.intents import IntentTarget, StructuredIntent
    from query_service.intents.planner import Planner

    planner = Planner(semantic=None, glossary=None, data_dir=tmp_path, repo_graph=_FakeRepoGraph())  # type: ignore[arg-type]
    intent = StructuredIntent(kind="ingest_csv_to_iceberg", target=IntentTarget(table="CLAIMS"), columns_hint=["Claim_Id", "Claim_Amount", "Status"])
    spec = await planner.plan(intent, "Load claims")
    assert spec.target.external_volume == "ICEBERG_VOL"
    assert spec.target.schema_name == "BRONZE"
    assert spec.matches[0].kind == "exemplar" and spec.matches[0].name == "BRONZE.A_CLAIM"
    assert spec.matches[0].link and spec.matches[0].link.startswith("/knowledge?repo=acme%2Fclaims")
    assert any("already exists in acme/claims" in r for r in spec.risks)
    assert any("LANDING_READ" in a for a in spec.assumptions)
    assert not any("No external volume" in r for r in spec.risks)


def test_checks_keep_their_sql_and_run_time_parameters() -> None:
    files = dict(FILES)
    files["sql/checks/bronze_quality.sql"] = CHECKS + (
        "union all\n"
        "select 'A_CLAIM.within_snapshot' CHECK_NAME,count(*) FAILURES from {{ bronze('A_CLAIM') }} "
        "where try_to_date(DATE_OF_CLAIM,'YYYY-MM-DD')>to_date(%(as_of)s);\n"
    )
    g, _ = build_repo_graph(RepoInfo(REPO, "main"), files)
    unique = g.get("check", "A_CLAIM.unique")
    assert unique is not None and unique.props["sql"].startswith("select 'A_CLAIM.unique' check_name,count(*) FAILURES from (select CLAIM_ID from BRONZE.A_CLAIM")
    assert "params" not in unique.props
    snapshot = g.get("check", "A_CLAIM.within_snapshot")
    assert snapshot is not None and snapshot.props["params"] == ["as_of"]
    assert snapshot.props["sql"].endswith("to_date('as_of')")  # the statement stops at its semicolon
