"""Documents carry a kind: pages/files/code are documents, catalog assets are datasets."""

from __future__ import annotations

from contextlib import asynccontextmanager
from datetime import UTC, datetime
from types import SimpleNamespace
from typing import Any
from uuid import uuid4

import pytest
from fastapi.testclient import TestClient
from test_pipeline_service import SAMPLE_MARKDOWN, make_service

from ech_core.app_factory import create_app
from ech_core.config import Settings
from ech_core.domain.enums import DocumentKind, GraphSyncStatus, SourceSystem
from ech_core.domain.models import DocumentRecord, DocumentUpsert
from ech_core.observability import LatencyRecorder
from ech_core.schemas.documents import DocumentSummary
from ingestion_service.connectors.base import SourceDocument
from query_service.api import api_router

NOW = datetime.now(tz=UTC)


def _record(kind: DocumentKind) -> DocumentRecord:
    return DocumentRecord(
        id=uuid4(),
        source_system=SourceSystem.DATABRICKS,
        kind=kind,
        external_id="lake.gold.fact_claim",
        title="lake.gold.fact_claim",
        mime_type="text/markdown",
        language="en",
        content_hash="x",
        content_length=10,
        version=1,
        attributes={"asset": {"asset_type": "metric_view"}},
        graph_sync_status=GraphSyncStatus.SYNCED,
        ingested_at=NOW,
        updated_at=NOW,
    )


def test_kind_defaults_to_document_and_flows_into_summaries():
    upsert = DocumentUpsert(
        id=uuid4(),
        source_system=SourceSystem.GITHUB,
        external_id="README.md",
        title="README",
        content_hash="x",
    )
    assert upsert.kind is DocumentKind.DOCUMENT
    assert SourceDocument(external_id="a", title="a", content="x").kind is DocumentKind.DOCUMENT
    summary = DocumentSummary.from_record(_record(DocumentKind.DATASET))
    assert summary.kind is DocumentKind.DATASET
    assert summary.model_dump(mode="json")["kind"] == "dataset"


@pytest.mark.asyncio
async def test_pipeline_marks_documents_with_a_semantic_payload_as_datasets():
    service, docs, *_ = make_service()
    page = SourceDocument(external_id="docs/arch.md", title="Architecture", content=SAMPLE_MARKDOWN)
    table = SourceDocument(
        external_id="lake.gold.fact_claim",
        title="lake.gold.fact_claim",
        content="# fact_claim\n\nOne row per claim.\n",
        attributes={"asset": {"asset_type": "table"}, "semantic": {"fqn": "lake.gold.fact_claim"}},
    )
    page_out = await service.process_document(page, SourceSystem.GITHUB)
    table_out = await service.process_document(table, SourceSystem.DATABRICKS)

    assert docs.rows[page_out.document_id].kind is DocumentKind.DOCUMENT
    assert docs.rows[table_out.document_id].kind is DocumentKind.DATASET
    # the semantic payload itself never lands in documents.attributes
    assert "semantic" not in docs.rows[table_out.document_id].attributes
    assert docs.rows[table_out.document_id].attributes["asset"] == {"asset_type": "table"}


def test_documents_api_filters_by_kind():
    calls: list[dict[str, Any]] = []

    class FakeDocuments:
        async def list(self, **kw: Any):
            calls.append(kw)
            return [_record(DocumentKind.DATASET)], 1

    @asynccontextmanager
    async def lifespan(app):
        app.state.container = SimpleNamespace(documents=FakeDocuments())
        yield

    app = create_app(
        settings=Settings(_env_file=None, service_name="test-query"),
        title="t",
        description="d",
        version="0",
        lifespan=lifespan,
        routers=[api_router],
        latency_recorder=LatencyRecorder(100),
    )
    with TestClient(app) as client:
        response = client.get("/api/v1/documents", params={"kind": "dataset", "limit": 10})
        assert response.status_code == 200, response.text
        assert response.json()["items"][0]["kind"] == "dataset"
        assert calls[-1]["kind"] is DocumentKind.DATASET
        assert client.get("/api/v1/documents", params={"kind": "page"}).status_code == 422
        client.get("/api/v1/documents")
        assert calls[-1]["kind"] is None, "no filter means every kind, the UI chooses"
