from ech_core.domain.enums import EntityType
from ingestion_service.extraction import RuleBasedEntityExtractor


def _by_type(entities, etype):
    return {e.name for e in entities if e.entity_type is etype}


def test_extracts_all_four_entity_types(sample_markdown):
    extractor = RuleBasedEntityExtractor(
        projects=["Atlas Platform", "Helios Identity", "Sentinel Observability"],
        people=["Priya Natarajan", "Lena Okafor"],
    )
    found = extractor.extract(sample_markdown, section_path=["Architecture Overview", "Operations"])
    assert {"Kubernetes", "Terraform", "ArgoCD", "Grafana", "Helm"} <= _by_type(
        found, EntityType.TECHNOLOGY
    )
    assert {"Atlas Platform", "Helios Identity", "Sentinel Observability"} <= _by_type(
        found, EntityType.PROJECT
    )
    people = _by_type(found, EntityType.PERSON)
    assert {"Priya Natarajan", "Lena Okafor"} <= people
    assert "Marcus Feld" in people, "cue phrase 'Reviewer:' should catch unknown people"
    assert "Daniel Brooks" in people, "'maintained by' cue should catch names"
    concepts = _by_type(found, EntityType.CONCEPT)
    assert {"Disaster Recovery", "Incident Response", "Zero Trust", "Backpressure"} <= concepts


def test_results_are_deduplicated_and_deterministic(sample_markdown):
    extractor = RuleBasedEntityExtractor(projects=["Atlas Platform"])
    a = extractor.extract(sample_markdown)
    b = extractor.extract(sample_markdown)
    assert [(e.entity_type, e.normalized_name) for e in a] == [
        (e.entity_type, e.normalized_name) for e in b
    ]
    keys = [(e.entity_type, e.normalized_name) for e in a]
    assert len(keys) == len(set(keys))
    atlas = next(e for e in a if e.normalized_name == "atlas platform")
    assert atlas.occurrences >= 3 and atlas.confidence >= 0.9


def test_technology_names_are_not_misread_as_projects():
    text = "The Prometheus Service and the Kafka Pipeline are monitored by the Grafana Portal."
    found = RuleBasedEntityExtractor().extract(text)
    assert not _by_type(found, EntityType.PROJECT)
    assert {"Prometheus", "Kafka", "Grafana"} <= _by_type(found, EntityType.TECHNOLOGY)


def test_field_labels_are_not_people():
    found = RuleBasedEntityExtractor().extract(
        "Status: Approved · Date: 2025-01-01 · Owner: Recovery Time"
    )
    assert not _by_type(found, EntityType.PERSON)


def test_names_never_span_lines_or_absorb_systems():
    text = (
        "Deciders: Aiko Tanaka\n"
        "Orion Data Mesh is maintained by Daniel Brooks.\n"
        "The canary is managed by Atlas Platform and measured by Sentinel Observability.\n"
        "Technical owner: Priya Natarajan\n"
        "All production changes are reviewed.\n"
        "Compliance contact: Fatima Al-Sayed · Backup: Tomás Herrera"
    )
    extractor = RuleBasedEntityExtractor(
        projects=["Atlas Platform", "Orion Data Mesh", "Sentinel Observability"]
    )
    found = extractor.extract(text)
    assert _by_type(found, EntityType.PERSON) == {
        "Aiko Tanaka",
        "Daniel Brooks",
        "Priya Natarajan",
        "Fatima Al-Sayed",
        "Tomás Herrera",
    }
    assert _by_type(found, EntityType.PROJECT) == {
        "Atlas Platform",
        "Orion Data Mesh",
        "Sentinel Observability",
    }, "'Data Mesh' must not be split out of 'Orion Data Mesh'"
    assert "Data Mesh" in _by_type(found, EntityType.CONCEPT)


def test_generic_suffix_phrases_are_not_projects():
    found = RuleBasedEntityExtractor().extract(
        "Aiko Tanaka is the Data Platform Lead; the Payment Service team owns Nimbus Billing."
    )
    projects = _by_type(found, EntityType.PROJECT)
    assert "Data Platform" not in projects and "Payment Service" not in projects
    assert "Nimbus Billing" in projects


def test_heading_concepts_skip_titles_and_known_entities():
    extractor = RuleBasedEntityExtractor(projects=["Atlas Platform"])
    found = extractor.extract(
        "Body text without concepts.",
        section_path=["Nimbus Billing Onboarding Guide", "Atlas Platform", "Disaster Recovery"],
    )
    assert _by_type(found, EntityType.CONCEPT) == {"Disaster Recovery"}
    assert not _by_type(found, EntityType.PERSON)
