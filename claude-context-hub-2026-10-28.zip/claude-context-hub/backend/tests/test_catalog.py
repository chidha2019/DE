"""Semantic Catalog: domain placement, object typing, inferred hierarchies, quality and filters."""

from __future__ import annotations

import asyncio
import dataclasses
from datetime import UTC, datetime
from typing import Any
from uuid import UUID, uuid4

from ech_core.repositories.catalog_repository import CatalogSnapshot
from ech_core.schemas.catalog import SHARED_LINE, UNASSIGNED_KEY
from query_service.services.catalog_service import (
    CatalogService,
    build_catalog,
    filter_objects,
    infer_hierarchies,
    sort_objects,
)

NOW = datetime(2026, 10, 26, 12, 0, tzinfo=UTC)


def _domain(key: str, name: str, parent: str | None, sort: int) -> dict[str, Any]:
    return {"key": key, "name": name, "parent_key": parent, "description": "", "standard": "acord", "sort_order": sort}


DOMAINS = [
    _domain("party", "Party & Customer", None, 10),
    _domain("customer", "Customer", "party", 11),
    _domain("policy", "Policy Administration", None, 50),
    _domain("claims", "Claims", None, 70),
]

FACT, DIM_CUSTOMER, DIM_DATE, ORPHAN = uuid4(), uuid4(), uuid4(), uuid4()
F_PREMIUM, F_CUSTOMER_SK, M_TOTAL, K_GROWTH = uuid4(), uuid4(), uuid4(), uuid4()


def _asset(
    aid: UUID,
    name: str,
    kind: str,
    *,
    domain: str | None = None,
    owner: str | None = "data-eng",
    description: str = "One row per thing.",
    schema: str = "gold",
) -> dict[str, Any]:
    return {
        "id": aid,
        "platform": "databricks",
        "fqn": f"insurance.{schema}.{name}",
        "database_name": "insurance",
        "schema_name": schema,
        "name": name,
        "asset_type": "table",
        "kind": kind,
        "display_name": "",
        "summary": "",
        "description": description,
        "owner": owner,
        "name_source": "derived",
        "domain_key": domain,
        "source_updated_at": None,
        "synced_at": NOW,
        "updated_at": NOW,
    }


def _field(
    aid: UUID, name: str, role: str, data_type: str = "string", *, pk: bool = False, agg: str | None = None, fid: UUID | None = None
) -> dict[str, Any]:
    return {
        "id": fid or uuid4(),
        "asset_id": aid,
        "name": name,
        "display_name": "",
        "ordinal": 0,
        "data_type": data_type,
        "description": "",
        "is_primary_key": pk,
        "role": role,
        "role_confidence": 0.9,
        "aggregation": agg,
    }


ASSETS = [
    # No domain of its own: placed by its columns' terms (policy twice, party once).
    _asset(FACT, "fct_policy_transaction", "fact"),
    # Placed by an accepted dataset-level term in the Customer sub-domain.
    _asset(DIM_CUSTOMER, "dim_customer", "dimension"),
    # Placed by the dataset's own domain_key.
    _asset(DIM_DATE, "dim_date", "dimension", domain="claims"),
    # Nothing places it: unassigned, unclassified, undocumented.
    _asset(ORPHAN, "tmp_objects", "unknown", owner=None, description=""),
]
FIELDS = [
    _field(FACT, "policy_sk", "identifier", "bigint", pk=True),
    _field(FACT, "customer_sk", "identifier", "bigint", fid=F_CUSTOMER_SK),
    _field(FACT, "annual_premium_amt", "measure", "decimal", agg="sum", fid=F_PREMIUM),
    _field(FACT, "policy_status", "dimension"),
    _field(FACT, "effective_date", "time", "date"),
    _field(FACT, "policy_year", "dimension", "int"),  # year + a date on a fact is not a calendar
    _field(DIM_CUSTOMER, "customer_sk", "identifier", "bigint", pk=True),
    _field(DIM_CUSTOMER, "country_code", "dimension"),
    _field(DIM_CUSTOMER, "state_code", "dimension"),
    _field(DIM_CUSTOMER, "city", "dimension"),
    _field(DIM_CUSTOMER, "parent_customer_sk", "identifier", "bigint"),
    _field(DIM_DATE, "calendar_date", "time", "date", pk=True),
    _field(DIM_DATE, "month_name", "dimension"),
    _field(DIM_DATE, "quarter", "dimension"),
    _field(DIM_DATE, "year", "dimension", "int"),
    _field(ORPHAN, "object_id", "identifier"),
]
METRICS = [
    {"id": M_TOTAL, "asset_id": FACT, "name": "total_premium", "display_name": "", "expression": "sum(annual_premium_amt)", "aggregation": "sum", "description": "Premium written.", "source": "curated", "dimensions": ["policy_status"]},
    {"id": uuid4(), "asset_id": FACT, "name": "policy_count", "display_name": "", "expression": "count(*)", "aggregation": "count", "description": "", "source": "inferred", "dimensions": []},
]
RELATIONSHIPS = [
    {"id": uuid4(), "source_asset_id": FACT, "target_asset_id": DIM_CUSTOMER, "target_fqn": "insurance.gold.dim_customer", "kind": "join_inferred", "source_columns": ["customer_sk"], "target_columns": ["customer_sk"], "confidence": 0.9, "evidence": "same name and type"},
    {"id": uuid4(), "source_asset_id": FACT, "target_asset_id": None, "target_fqn": "insurance.bronze.policy_raw", "kind": "lineage_upstream", "source_columns": [], "target_columns": [], "confidence": 1.0, "evidence": "view definition"},
]
LINKS = [
    {"target_type": "asset", "target_id": DIM_CUSTOMER, "confidence": 0.95, "term_name": "Customer", "term_kind": "entity", "domain_key": "customer"},
    {"target_type": "field", "target_id": F_PREMIUM, "confidence": 0.9, "term_name": "Premium", "term_kind": "measure", "domain_key": "policy"},
    {"target_type": "field", "target_id": F_CUSTOMER_SK, "confidence": 0.8, "term_name": "Customer", "term_kind": "entity", "domain_key": "customer"},
    {"target_type": "metric", "target_id": M_TOTAL, "confidence": 0.9, "term_name": "Premium", "term_kind": "measure", "domain_key": "policy"},
]
KPIS = [
    {"id": K_GROWTH, "key": "premium_growth", "name": "Premium Growth", "domain_key": "policy", "term_id": uuid4(), "metric_id": M_TOTAL, "definition": "Growth of written premium.", "formula": "premium / prior premium - 1", "grain": "product", "period": "monthly", "unit": "percent", "direction": "higher", "target_value": 0.05, "owner": "cfo", "updated_at": NOW, "term_name": "Premium"},
]
SNAPSHOT = CatalogSnapshot(assets=ASSETS, fields=FIELDS, metrics=METRICS, relationships=RELATIONSHIPS, domains=DOMAINS, term_links=LINKS, kpis=KPIS)


def _built():
    return build_catalog(SNAPSHOT, now=NOW)


def _one(objects, object_id: str):
    return next(o for o in objects if o.id == object_id)


# ----------------------------------------------------------------------------- placement
def test_entities_are_placed_by_dataset_domain_then_term_then_column_votes():
    objects = _built().objects
    fact = _one(objects, f"entity:{FACT}")
    assert (fact.domain_key, fact.domain_source) == ("policy", "columns")
    customer = _one(objects, f"entity:{DIM_CUSTOMER}")
    assert (customer.domain_key, customer.domain_name, customer.domain_source) == ("customer", "Customer", "term")
    assert customer.term == "Customer"
    date = _one(objects, f"entity:{DIM_DATE}")
    assert (date.domain_key, date.domain_source) == ("claims", "dataset")
    orphan = _one(objects, f"entity:{ORPHAN}")
    assert (orphan.domain_key, orphan.domain_source) == (None, "none")
    assert fact.model == "insurance.gold" and fact.model_label == "Gold" and fact.owner == "data-eng"
    assert fact.updated_at == NOW


# ----------------------------------------------------------------------------- object types
def test_columns_metrics_and_kpis_become_dimensions_measures_and_metrics():
    built = _built()
    counts = built.catalog.counts
    assert (counts.entities, counts.dimensions, counts.measures, counts.metrics) == (4, 10, 1, 3)
    assert (counts.relationships, counts.hierarchies, counts.total) == (2, 3, 23)
    premium = _one(built.objects, f"measure:{F_PREMIUM}")
    assert premium.type == "measure" and premium.subtype == "sum" and premium.detail == "decimal"
    assert (premium.domain_key, premium.domain_source, premium.term) == ("policy", "term", "Premium")
    dims = [o for o in built.objects if o.type == "dimension"]
    assert {o.subtype for o in dims} == {"categorical", "time"}
    assert all(o.technical_name.startswith("insurance.gold.") for o in dims)
    assert not any(o.technical_name.endswith("_sk") for o in dims), "identifiers are keys, not dimensions"
    total = _one(built.objects, f"metric:{M_TOTAL}")
    assert (total.subtype, total.term, total.domain_key, total.detail) == ("curated", "Premium", "policy", "sum(annual_premium_amt)")
    kpi = _one(built.objects, f"metric:kpi:{K_GROWTH}")
    assert (kpi.subtype, kpi.domain_source, kpi.owner, kpi.model) == ("kpi", "kpi", "cfo", "insurance.gold")
    assert kpi.asset_id == FACT and kpi.detail == "premium / prior premium - 1"


def test_relationships_follow_the_source_dataset_and_describe_the_join():
    rels = [o for o in _built().objects if o.type == "relationship"]
    join = next(o for o in rels if o.subtype == "inferred join")
    assert join.detail == "customer_sk = customer_sk" and join.domain_key == "policy"
    assert join.name.endswith("Customer") and join.asset_id == FACT
    lineage = next(o for o in rels if o.subtype == "lineage")
    assert "insurance.bronze.policy_raw" in lineage.technical_name
    assert {c.name: c.ok for c in lineage.checks}["target in catalog"] is False
    assert {c.name: c.ok for c in join.checks}["target in catalog"] is True


# ----------------------------------------------------------------------------- hierarchies
def test_hierarchies_are_inferred_from_column_patterns_not_declared():
    by_asset = {}
    for f in FIELDS:
        by_asset.setdefault(f["asset_id"], []).append(f)
    date = infer_hierarchies(ASSETS[2], by_asset[DIM_DATE])
    assert [h["family"] for h in date] == ["calendar"]
    assert [level for level, _ in date[0]["levels"]] == ["Year", "Quarter", "Month", "Day"]
    customer = infer_hierarchies(ASSETS[1], by_asset[DIM_CUSTOMER])
    assert [h["family"] for h in customer] == ["geography", "parent-child"]
    assert customer[1]["levels"] == [("Parent", "parent_customer_sk"), ("Child", "customer_sk")]
    assert infer_hierarchies(ASSETS[0], by_asset[FACT]) == [], "a fact with one date and a year column has no calendar"
    invoice = _asset(uuid4(), "fct_premium_invoice_line", "fact")
    columns = [_field(invoice["id"], "plan_id", "dimension"), _field(invoice["id"], "coverage_month", "time", "date"), _field(invoice["id"], "plan_year", "dimension", "int")]
    assert infer_hierarchies(invoice, columns) == [], "coverage_month is a month, not a coverage level; plan_year is not a plan"
    denormalised = [_field(invoice["id"], n, "dimension") for n in ("calendar_year", "calendar_month", "transaction_date", "policy_year")]
    assert infer_hierarchies(invoice, denormalised) == [{"family": "calendar", "levels": [("Year", "calendar_year"), ("Month", "calendar_month")]}]
    hierarchies = [o for o in _built().objects if o.type == "hierarchy"]
    calendar = next(o for o in hierarchies if o.subtype == "calendar")
    assert calendar.name == "Calendar hierarchy on Date" and calendar.detail.startswith("Year: Year › Quarter: Quarter")
    assert calendar.domain_key == "claims" and {c.name: c.ok for c in calendar.checks}["three or more levels"] is True


# ----------------------------------------------------------------------------- the tree
def test_domain_tree_rolls_sub_domains_into_parents_and_lists_unassigned_last():
    catalog = _built().catalog
    assert [d.key for d in catalog.domains] == ["party", "policy", "claims", UNASSIGNED_KEY]
    party = catalog.domains[0]
    assert [c.key for c in party.children] == ["customer"]
    customer = party.children[0]
    assert (customer.counts.entities, customer.counts.dimensions, customer.counts.hierarchies, customer.counts.total) == (1, 3, 2, 6)
    assert party.counts.total == 6, "nothing sits directly in Party; it shows what its sub-domains hold"
    policy = catalog.domains[1]
    assert (policy.counts.entities, policy.counts.dimensions, policy.counts.measures) == (1, 3, 1)
    assert (policy.counts.metrics, policy.counts.relationships, policy.counts.total) == (3, 2, 10)
    assert catalog.domains[2].counts.total == 6
    assert catalog.domains[3].counts.total == 1 and catalog.domains[3].name == "Unassigned"
    assert (catalog.placed, catalog.entities_placed) == (22, 3)
    assert catalog.models == ["insurance.gold"] and catalog.owners == ["cfo", "data-eng"]
    assert catalog.quality is not None and 0 < catalog.quality <= 100
    assert "inferred" in catalog.hierarchy_note


# ----------------------------------------------------------------------------- quality
def test_quality_scores_count_the_checks_that_apply_to_each_type():
    objects = _built().objects
    orphan = _one(objects, f"entity:{ORPHAN}")
    assert orphan.quality == round(100 / 8)
    assert {c.name for c in orphan.checks} == {"described", "business name", "owner", "keys", "connected", "classified", "term linked", "domain"}
    assert {c.name: c.ok for c in orphan.checks}["keys"] is True
    customer = _one(objects, f"entity:{DIM_CUSTOMER}")
    assert customer.quality == 100
    premium = _one(objects, f"measure:{F_PREMIUM}")
    checks = {c.name: c.ok for c in premium.checks}
    assert checks == {"described": False, "business name": True, "term linked": True, "typed": True, "role confident": True, "domain": True}
    assert premium.quality == round(100 * 5 / 6)


# ----------------------------------------------------------------------------- filters
def test_filters_narrow_by_domain_with_sub_domains_type_model_owner_and_text():
    built = _built()
    assert len(filter_objects(built, domain="party")) == 6
    assert len(filter_objects(built, domain="customer")) == 6
    assert len(filter_objects(built, domain=UNASSIGNED_KEY)) == 1
    assert len(filter_objects(built, type="measure")) == 1
    assert len(filter_objects(built, owner="cfo")) == 1
    assert len(filter_objects(built, model="insurance.gold")) == 23
    assert filter_objects(built, model="insurance.silver") == []
    assert {o.type for o in filter_objects(built, search="premium")} == {"measure", "metric"}
    assert len(filter_objects(built, search="premium")) == 3
    assert [o.technical_name for o in filter_objects(built, search="premium curated")] == ["insurance.gold.fct_policy_transaction.total_premium"]
    assert all(o.quality == 100 for o in filter_objects(built, min_quality=100))
    assert len(filter_objects(built, domain="policy", type="relationship")) == 2


class FakeRepo:
    async def snapshot(self) -> CatalogSnapshot:
        return SNAPSHOT


def test_service_pages_filtered_objects_from_one_snapshot():
    service = CatalogService(FakeRepo())  # type: ignore[arg-type]
    page = asyncio.run(
        service.objects(domain=None, type="dimension", model=None, owner=None, search=None, min_quality=0, limit=4, offset=4)
    )
    assert (page.total, len(page.items), page.offset) == (10, 4, 4)
    assert all(o.type == "dimension" for o in page.items)
    catalog = asyncio.run(service.catalog())
    assert catalog.counts.total == 23 and catalog.generated_at.tzinfo is not None


def test_sources_and_domain_models_count_every_object_once():
    catalog = _built().catalog
    by_model = {s.model: s for s in catalog.sources}
    gold = by_model["insurance.gold"]
    assert (gold.database, gold.schema_name, gold.counts.total) == ("insurance", "gold", 23)
    assert sum(s.counts.total for s in catalog.sources) == catalog.counts.total
    assert sum(d.counts.total for d in catalog.domain_models) == catalog.counts.total
    # Direct placement: the parent and its sub-domain are counted apart, and add up to the rolled-up figure.
    direct = {d.domain_key: 0 for d in catalog.domain_models}
    for d in catalog.domain_models:
        direct[d.domain_key] += d.counts.total
    assert direct.get("party", 0) + direct.get("customer", 0) == 6
    assert direct[UNASSIGNED_KEY] == 1


def test_direct_and_database_filters_and_server_side_sorting():
    built = _built()
    party = filter_objects(built, domain="party", direct=True)
    assert all(o.domain_key == "party" for o in party)
    assert len(party) + len(filter_objects(built, domain="customer", direct=True)) == 6
    in_db = sum(s.counts.total for s in built.catalog.sources if s.database == "insurance")
    assert len(filter_objects(built, database="insurance")) == in_db
    assert filter_objects(built, database="insur") == []

    rows = filter_objects(built)
    by_quality = sort_objects(rows, "quality", descending=True)
    assert [o.quality for o in by_quality] == sorted((o.quality for o in rows), reverse=True)
    assert sort_objects(rows, "domain")[-1].domain_key is None
    names = [o.name.lower() for o in sort_objects(rows, "name")]
    assert names == sorted(names)


def test_lines_of_business_follow_the_dataset_and_group_per_domain():
    snap = dataclasses.replace(
        SNAPSHOT,
        lines=[
            {"asset_id": FACT, "line_key": "life", "source": "inherited", "evidence": "inherited via gold.dim_product"},
            {"asset_id": FACT, "line_key": "annuity", "source": "inherited", "evidence": "inherited via gold.dim_product"},
            {"asset_id": DIM_DATE, "line_key": "life", "source": "tag", "evidence": "tag LINE_OF_BUSINESS=LIFE"},
        ],
        line_values=[{"key": "life", "name": "Life", "description": ""}, {"key": "annuity", "name": "Annuity", "description": ""}],
    )
    built = build_catalog(snap, now=NOW)
    fact_objects = [o for o in built.objects if o.asset_id == FACT]
    assert fact_objects and all(o.lines == ["life", "annuity"] and o.lines_note == "inherited via gold.dim_product" for o in fact_objects)
    by_key = {line.key: line for line in built.catalog.lines}
    assert list(by_key) == ["life", "annuity", SHARED_LINE]
    assert by_key["life"].counts.total == len(fact_objects) + sum(1 for o in built.objects if o.asset_id == DIM_DATE)
    assert sum(d.counts.total for d in by_key["life"].domains) == by_key["life"].counts.total
    assert "claims" in {d.domain_key for d in by_key["life"].domains}
    assert len(filter_objects(built, lob="annuity")) == len(fact_objects)
    shared = filter_objects(built, lob=SHARED_LINE)
    assert shared and all(not o.lines for o in shared) and by_key[SHARED_LINE].counts.total == len(shared)
