from ech_core.repositories.chunk_repository import keyword_terms


def test_keyword_terms_drop_stopwords_and_dedupe():
    terms = keyword_terms("How are the bronze layer data-quality checks executed? Bronze checks!")
    assert terms == ["bronze", "layer", "data", "quality", "checks", "executed"]


def test_keyword_terms_are_tsquery_safe():
    terms = keyword_terms(
        "select * from sql/checks/bronze_quality.sql; DROP TABLE x -- ' | & ! ( )"
    )
    assert all(t.isalnum() for t in terms)
    assert "bronze" in terms and "quality" in terms
    assert keyword_terms("the of and a") == []
    assert len(keyword_terms(" ".join(f"term{i}" for i in range(60)))) == 24
