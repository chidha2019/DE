"""Persona workspaces: Genie spaces carry a persona; the semantic API serves their views."""

from __future__ import annotations

from contextlib import asynccontextmanager
from datetime import UTC, datetime
from types import SimpleNamespace
from typing import Any
from uuid import uuid4

import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError

from ech_core.app_factory import create_app
from ech_core.config import Settings
from ech_core.observability import LatencyRecorder
from ech_core.schemas.common import Page
from ech_core.schemas.genie import GenieSpaceOut
from ech_core.schemas.semantic import GlossaryTerm, SemanticHealth, SemanticMetricRow
from query_service.api import api_router
from query_service.services.semantic_service import SemanticService

ASSET_ID = uuid4()
NOW = datetime.now(tz=UTC)


def _metric(**overrides: Any) -> SemanticMetricRow:
    base = {
        "id": uuid4(),
        "name": "Claim count",
        "expression": "COUNT(DISTINCT claim_id)",
        "aggregation": "count",
        "description": "Distinct claims, every status",
        "source": "declared",
        "dimensions": ["Claim status"],
        "asset_id": ASSET_ID,
        "asset_fqn": "lake.gold.mv_claims",
        "asset_name": "mv_claims",
        "asset_type": "metric_view",
        "asset_kind": "metric",
        "platform": "databricks",
        "database_name": "lake",
        "schema_name": "gold",
        "uri": None,
    }
    return SemanticMetricRow.model_validate({**base, **overrides})


class FakeSemantic:
    def __init__(self) -> None:
        self.calls: list[tuple[str, dict[str, Any]]] = []

    async def metrics_catalog(self, **kw: Any) -> Page[SemanticMetricRow]:
        self.calls.append(("metrics", kw))
        return Page(items=[_metric()], total=1, limit=kw["limit"], offset=kw["offset"])

    async def glossary(self, **kw: Any) -> Page[GlossaryTerm]:
        self.calls.append(("glossary", kw))
        term = GlossaryTerm(
            term="claim_id",
            role="identifier",
            data_types=["string"],
            description="Claim identifier",
            asset_count=3,
            declared=True,
            assets=[{"id": ASSET_ID, "fqn": "lake.gold.fact_claim"}],
        )
        return Page(items=[term], total=1, limit=kw["limit"], offset=kw["offset"])

    async def health(self) -> SemanticHealth:
        self.calls.append(("health", {}))
        return SemanticHealth(
            assets=10,
            described=8,
            owned=6,
            facts=3,
            keyed_facts=1,
            with_relationships=9,
            isolated=1,
            inferred_joins=4,
            low_confidence_joins=2,
            stale_assets=0,
            last_synced_at=NOW,
            keyless_facts=[
                {
                    "id": ASSET_ID,
                    "fqn": "lake.gold.fact_claim",
                    "asset_type": "table",
                    "kind": "fact",
                    "field_count": 12,
                    "owner": None,
                    "platform": "databricks",
                }
            ],
            review_joins=[
                {
                    "id": uuid4(),
                    "source_asset_id": ASSET_ID,
                    "source_fqn": "lake.gold.fact_claim",
                    "target_asset_id": None,
                    "target_fqn": "lake.gold.dim_policy",
                    "source_columns": ["policy_id"],
                    "target_columns": ["policy_id"],
                    "confidence": 0.75,
                    "evidence": "dimension base name",
                }
            ],
            coverage=[
                {
                    "platform": "databricks",
                    "database_name": "lake",
                    "schema_name": "gold",
                    "assets": 10,
                    "described": 8,
                    "owned": 6,
                    "facts": 3,
                    "keyed_facts": 1,
                    "synced_at": NOW,
                }
            ],
        )


def _client(semantic: FakeSemantic) -> TestClient:
    @asynccontextmanager
    async def lifespan(app):
        app.state.container = SimpleNamespace(semantic=semantic)
        yield

    app = create_app(
        settings=Settings(_env_file=None, service_name="test-query"),
        title="t",
        description="d",
        version="0",
        lifespan=lifespan,
        routers=[api_router],
        latency_recorder=LatencyRecorder(100),
    )
    return TestClient(app)


def test_space_schema_accepts_only_known_personas():
    base = {
        "id": uuid4(),
        "name": "Data Engineer",
        "created_at": NOW,
        "updated_at": NOW,
    }
    assert GenieSpaceOut.model_validate({**base, "persona": "data_engineer"}).persona == (
        "data_engineer"
    )
    assert GenieSpaceOut.model_validate(base).persona is None
    with pytest.raises(ValidationError):
        GenieSpaceOut.model_validate({**base, "persona": "intern"})


def test_persona_endpoints_pass_filters_and_validate_payloads():
    semantic = FakeSemantic()
    with _client(semantic) as client:
        metrics = client.get(
            "/api/v1/semantic/metrics", params={"search": "claim", "source": "declared", "limit": 5}
        )
        assert metrics.status_code == 200, metrics.text
        body = metrics.json()
        assert body["total"] == 1 and body["items"][0]["name"] == "Claim count"
        assert body["items"][0]["asset_id"] == str(ASSET_ID)
        assert semantic.calls[-1] == (
            "metrics",
            {
                "search": "claim",
                "source": "declared",
                "database": None,
                "schema": None,
                "limit": 5,
                "offset": 0,
            },
        )
        assert (
            client.get("/api/v1/semantic/metrics", params={"source": "guessed"}).status_code == 422
        )

        glossary = client.get("/api/v1/semantic/glossary", params={"role": "identifier"})
        assert glossary.status_code == 200
        term = glossary.json()["items"][0]
        assert term["term"] == "claim_id" and term["assets"][0]["fqn"] == "lake.gold.fact_claim"
        assert semantic.calls[-1][1]["role"] == "identifier"

        health = client.get("/api/v1/semantic/health")
        assert health.status_code == 200
        payload = health.json()
        assert payload["facts"] - payload["keyed_facts"] == 2
        assert payload["keyless_facts"][0]["fqn"] == "lake.gold.fact_claim"
        assert payload["review_joins"][0]["confidence"] == 0.75
        assert payload["coverage"][0]["schema_name"] == "gold"


async def test_glossary_service_trims_assets_and_tolerates_null_arrays():
    class Repo:
        async def glossary(self, **_: Any):
            return (
                [
                    {
                        "term": "policy_id",
                        "role": "identifier",
                        "data_types": None,
                        "description": "",
                        "asset_count": 7,
                        "declared": False,
                        "assets": [
                            {"id": str(uuid4()), "fqn": f"lake.gold.t{i}"} for i in range(7)
                        ],
                    }
                ],
                1,
            )

    service = SemanticService(Repo())  # type: ignore[arg-type]
    page = await service.glossary(search=None, role=None, limit=10, offset=0)
    (term,) = page.items
    assert term.data_types == [] and len(term.assets) == 5 and term.asset_count == 7
