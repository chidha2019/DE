"""Business names, role-based classification, Claude enrichment and the business model."""

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from types import SimpleNamespace
from typing import Any
from uuid import UUID, uuid4

import pytest
from fastapi.testclient import TestClient

from ech_core.app_factory import create_app
from ech_core.config import Settings
from ech_core.llm.client import ModelTurn
from ech_core.observability import LatencyRecorder
from ech_core.schemas.semantic import (
    BusinessModel,
    EnrichmentDecision,
    EnrichRequest,
    SemanticAssetDetail,
)
from ech_core.semantic.inference import infer_asset, refine_kind
from ech_core.semantic.models import (
    AssetKind,
    AssetType,
    FieldRole,
    MetricSource,
    Platform,
    SemanticAsset,
    SemanticField,
)
from ech_core.semantic.naming import business_name, first_sentence, summary_for
from query_service.api import api_router
from query_service.services.enrichment_service import (
    EnrichmentService,
    build_prompt,
    parse_suggestion,
)
from query_service.services.semantic_service import SemanticService

NOW = datetime.now(tz=UTC)


# ----------------------------------------------------------------------------- naming
def test_business_names_strip_prefixes_expand_abbreviations_and_keep_acronyms():
    assert business_name("fact_claim_payment_v1") == "Claim Payment"
    assert business_name("dim_group_policy_v1") == "Group Policy"
    assert business_name("mv_claim_payments_v1_draft") == "Claim Payments"
    assert business_name("cust_acct_id") == "Customer Account ID"
    assert business_name("kyc_record") == "KYC Record"
    assert business_name("lake.gold.loan_borrower_relationship") == "Loan Borrower Relationship"
    assert business_name("claimAmountUSD") == "Claim Amount USD"
    assert business_name("line_of_business") == "Line of Business"
    assert business_name("Payment date") == "Payment Date"
    assert business_name("FACE_AMOUNT") == "Face Amount"
    assert business_name("TRANSACTION_SEQ") == "Transaction Sequence"
    assert business_name("KYC_record") == "KYC Record"
    assert business_name("") == ""


def test_first_sentence_trims_and_keeps_whole_words():
    assert first_sentence("One row per claim. Includes denied claims.") == "One row per claim."
    long = "word " * 60
    cut = first_sentence(long, limit=40)
    assert cut.endswith("…") and len(cut) <= 41


def _asset(name: str, fields: list[SemanticField], **overrides: Any) -> SemanticAsset:
    base = {
        "platform": Platform.DATABRICKS,
        "fqn": f"lake.gold.{name}",
        "database": "lake",
        "schema_name": "gold",
        "name": name,
        "fields": fields,
    }
    return SemanticAsset(**{**base, **overrides})


def _f(name: str, data_type: str, **kw: Any) -> SemanticField:
    return SemanticField(name=name, data_type=data_type, **kw)


# ----------------------------------------------------------------------------- classifier
def test_unknown_tables_are_classified_from_their_column_roles():
    fact = infer_asset(
        _asset(
            "card_transaction",
            [
                _f("transaction_id", "string"),
                _f("card_id", "string"),
                _f("transaction_date", "date"),
                _f("amount", "decimal(18,2)"),
                _f("fee_amount", "decimal(18,2)"),
                _f("merchant_category", "string"),
            ],
        )
    )
    assert fact.kind is AssetKind.FACT and fact.kind_source == "inferred"
    assert fact.display_name == "Card Transaction"
    assert any(m.name == "total_amount" for m in fact.metrics)
    assert fact.summary.startswith("Card Transaction records")

    dimension = infer_asset(
        _asset(
            "core_customer",
            [
                _f("customer_id", "string", is_primary_key=True),
                _f("first_name", "string"),
                _f("segment", "string"),
                _f("country_code", "string"),
                _f("email", "string"),
            ],
        )
    )
    assert dimension.kind is AssetKind.DIMENSION
    assert dimension.summary.startswith("Core Customer reference data keyed by customer_id")

    bridge = infer_asset(
        _asset("loan_borrower_relationship", [_f("loan_id", "string"), _f("borrower_id", "string")])
    )
    assert bridge.kind is AssetKind.BRIDGE

    reference = infer_asset(
        _asset("claim_status", [_f("status_code", "string"), _f("status_name", "string")])
    )
    assert reference.kind is AssetKind.REFERENCE

    assert refine_kind(_asset("empty", [])) is AssetKind.UNKNOWN


def test_declared_names_and_kinds_are_kept():
    asset = _asset(
        "mv_claims",
        [_f("Claim status", "string", role=FieldRole.DIMENSION, role_confidence=1.0)],
        asset_type=AssetType.METRIC_VIEW,
        display_name="Claims Overview",
        name_source="curated",
        description="Governed claim counts. Second sentence.",
    )
    out = infer_asset(asset)
    assert out.kind is AssetKind.METRIC and out.kind_source == "declared"
    assert out.display_name == "Claims Overview" and out.name_source == "curated"
    assert out.summary == "Governed claim counts."
    assert out.fields[0].display_name == "Claim Status"
    assert summary_for(out) == "Governed claim counts."


# ----------------------------------------------------------------------------- enrichment
ASSET_ID = UUID("66f7f7b5-6ca6-594a-9228-bc2cdec28dcd")


def _detail(**overrides: Any) -> SemanticAssetDetail:
    base: dict[str, Any] = {
        "id": ASSET_ID,
        "document_id": ASSET_ID,
        "source_system": "databricks",
        "platform": "databricks",
        "fqn": "lake.silver.card_account",
        "database_name": "lake",
        "schema_name": "silver",
        "name": "card_account",
        "asset_type": "table",
        "kind": "unknown",
        "description": "",
        "display_name": "Card Account",
        "summary": "",
        "name_source": "derived",
        "kind_source": "inferred",
        "synced_at": NOW,
        "fields": [
            {
                "id": uuid4(),
                "name": "card_id",
                "ordinal": 0,
                "data_type": "string",
                "role": "identifier",
                "is_primary_key": True,
            },
            {
                "id": uuid4(),
                "name": "credit_limit",
                "ordinal": 1,
                "data_type": "decimal",
                "role": "measure",
            },
            {
                "id": uuid4(),
                "name": "status",
                "ordinal": 2,
                "data_type": "string",
                "role": "dimension",
            },
        ],
        "relationships": [],
        "metrics": [],
        "enrichment": {},
    }
    return SemanticAssetDetail.model_validate({**base, **overrides})


MODEL_ANSWER = """Here you go:
```json
{"display_name": "Credit Card Account", "summary": "One row per credit card account with its limit and status.",
 "kind": "dimension", "confidence": 0.82, "rationale": "keyed by card_id; attributes describe the account",
 "metrics": [
   {"name": "Total Credit Limit", "display_name": "Total Credit Limit", "expression": "SUM(credit_limit)", "description": "Sum of limits", "dimensions": ["status", "nope"]},
   {"name": "bogus", "expression": "SUM(balance)", "description": "uses a column that does not exist"},
   {"name": "accounts", "expression": "COUNT(*)", "description": "Number of accounts"}
 ]}
```"""


def test_parse_suggestion_validates_metrics_against_real_columns():
    suggestion = parse_suggestion(MODEL_ANSWER, _detail(), model="claude-test")
    assert suggestion.display_name == "Credit Card Account" and suggestion.kind == "dimension"
    assert [m.name for m in suggestion.metrics] == ["total_credit_limit", "accounts"]
    assert suggestion.metrics[0].dimensions == ["status"]
    assert suggestion.confidence == 0.82 and suggestion.model == "claude-test"
    assert suggestion.status == "suggested"
    assert "card_account" in build_prompt(_detail())


class FakeModel:
    model = "claude-fake"

    def __init__(self, answers: list[str]) -> None:
        self.answers = list(answers)
        self.calls: list[dict[str, Any]] = []

    async def complete(
        self, *, system: str, tools: list[dict[str, Any]], messages: list[dict[str, Any]]
    ):
        self.calls.append({"system": system, "messages": messages})
        if not self.answers:
            raise RuntimeError("gateway down")
        answer = self.answers.pop(0)
        return ModelTurn(
            content=[{"type": "text", "text": answer}], stop_reason="end_turn", model=self.model
        )


class FakeRepo:
    def __init__(self) -> None:
        self.enrichment: dict[UUID, dict[str, Any]] = {}
        self.applied: list[dict[str, Any]] = []
        self.metrics: list[dict[str, Any]] = []
        self.rows: list[dict[str, Any]] = []

    async def set_enrichment(self, asset_id: UUID, payload: dict[str, Any]) -> None:
        self.enrichment[asset_id] = payload

    async def apply_enrichment(self, asset_id: UUID, **fields: Any) -> None:
        self.applied.append({"asset_id": asset_id, **fields})

    async def add_metric(self, asset_id: UUID, **fields: Any) -> None:
        self.metrics.append({"asset_id": asset_id, **fields})

    async def list_assets(self, **kw: Any):
        return self.rows, len(self.rows)


class FakeSemantic:
    def __init__(self, repo: FakeRepo) -> None:
        self.repo = repo

    async def get_asset(self, asset_id: UUID) -> SemanticAssetDetail:
        stored = self.repo.enrichment.get(asset_id, {})
        applied = next((a for a in reversed(self.repo.applied) if a["asset_id"] == asset_id), None)
        return _detail(
            id=asset_id,
            document_id=asset_id,
            enrichment=stored,
            display_name=applied["display_name"] if applied else "Card Account",
            kind=applied["kind"] if applied else "unknown",
        )


async def test_suggest_then_accept_with_edits_marks_curated_and_adds_chosen_metrics():
    repo = FakeRepo()
    model = FakeModel([MODEL_ANSWER])
    service = EnrichmentService(repo=repo, semantic=FakeSemantic(repo), model=model)  # type: ignore[arg-type]
    suggestion = await service.suggest(ASSET_ID)
    assert repo.enrichment[ASSET_ID]["display_name"] == "Credit Card Account"
    assert "Dataset metadata" in model.calls[0]["messages"][0]["content"]

    detail = await service.decide(
        ASSET_ID,
        EnrichmentDecision(
            action="accept", display_name="Card Account (Credit)", metric_names=["accounts"]
        ),
    )
    assert repo.applied[-1]["display_name"] == "Card Account (Credit)"
    assert repo.applied[-1]["name_source"] == "curated" and repo.applied[-1]["kind"] == "dimension"
    assert [m["name"] for m in repo.metrics] == ["accounts"]
    assert repo.metrics[0]["source"] == "curated"
    assert repo.enrichment[ASSET_ID]["status"] == "accepted"
    assert detail.display_name == "Card Account (Credit)" and suggestion.kind == "dimension"


async def test_accept_as_is_is_attributed_to_the_model_and_reject_keeps_names():
    repo = FakeRepo()
    service = EnrichmentService(
        repo=repo,  # type: ignore[arg-type]
        semantic=FakeSemantic(repo),  # type: ignore[arg-type]
        model=FakeModel([MODEL_ANSWER, MODEL_ANSWER]),
    )
    await service.suggest(ASSET_ID)
    await service.decide(ASSET_ID, EnrichmentDecision(action="accept"))
    assert repo.applied[-1]["name_source"] == "model" and repo.applied[-1]["kind_source"] == "model"
    assert [m["name"] for m in repo.metrics] == ["total_credit_limit", "accounts"]

    other = uuid4()
    await service.suggest(other)
    await service.decide(other, EnrichmentDecision(action="reject"))
    assert repo.enrichment[other]["status"] == "rejected"
    assert all(a["asset_id"] != other for a in repo.applied)


async def _wait(service: EnrichmentService, run_id: UUID) -> None:
    for _ in range(100):
        run = service.get_run(run_id)
        if run is not None and run.status != "running":
            return
        await asyncio.sleep(0.01)


async def test_scope_run_skips_documented_assets_and_survives_a_model_failure():
    repo = FakeRepo()
    documented, undocumented, unknown = uuid4(), uuid4(), uuid4()
    repo.rows = [
        {
            "id": documented,
            "description": "Documented.",
            "kind": "fact",
            "name_source": "curated",
            "enrichment": {},
        },
        {
            "id": undocumented,
            "description": "",
            "kind": "fact",
            "name_source": "derived",
            "enrichment": {},
        },
        {
            "id": unknown,
            "description": "x",
            "kind": "unknown",
            "name_source": "derived",
            "enrichment": {"status": "accepted"},
        },
    ]
    service = EnrichmentService(
        repo=repo,  # type: ignore[arg-type]
        semantic=FakeSemantic(repo),  # type: ignore[arg-type]
        model=FakeModel([MODEL_ANSWER]),
        concurrency=1,
    )
    run = await service.start_run(EnrichRequest(only_undocumented=True, redo=False, limit=10))
    assert run.total == 1, "documented and already-enriched assets are skipped"
    await _wait(service, run.id)
    done = service.get_run(run.id)
    assert done is not None and done.status == "completed" and done.done == 1 and done.failed == 0

    repo.rows[0]["description"] = ""
    failing = await service.start_run(EnrichRequest(only_undocumented=True, redo=True, limit=10))
    assert failing.total == 3
    await _wait(service, failing.id)
    result = service.get_run(failing.id)
    assert result is not None and result.failed == 3 and result.status == "failed"
    assert "gateway down" in (result.error or "")


async def test_scope_run_with_nothing_to_name_says_why():
    repo = FakeRepo()
    repo.rows = [
        {"id": uuid4(), "description": "Documented.", "kind": "fact", "name_source": "curated", "enrichment": {}},
        {"id": uuid4(), "description": "", "kind": "fact", "name_source": "derived", "enrichment": {"status": "suggested"}},
        {"id": uuid4(), "description": "x", "kind": "unknown", "name_source": "derived", "enrichment": {"status": "accepted"}},
    ]
    service = EnrichmentService(
        repo=repo,  # type: ignore[arg-type]
        semantic=FakeSemantic(repo),  # type: ignore[arg-type]
        model=FakeModel([MODEL_ANSWER]),
        concurrency=1,
    )
    run = await service.start_run(EnrichRequest(only_undocumented=True, redo=False, limit=10))
    assert run.status == "completed" and run.total == 0
    assert (run.skipped_proposed, run.skipped_documented) == (2, 1)
    assert run.message == (
        "Nothing new to name: 2 already have a Claude proposal awaiting review or accepted; "
        "1 is already described, classified and named."
    )
    assert run.finished_at is not None

    redo = await service.start_run(EnrichRequest(only_undocumented=True, redo=True, limit=10))
    assert redo.total == 2 and redo.message is None, "redo re-proposes the two with proposals; the documented one stays out"


def test_run_refuses_without_a_model():
    service = EnrichmentService(
        repo=FakeRepo(),  # type: ignore[arg-type]
        semantic=FakeSemantic(FakeRepo()),  # type: ignore[arg-type]
        model=None,
        unavailable_reason="no key",
    )
    assert not service.available
    with pytest.raises(Exception, match="no key"):
        asyncio.run(service.start_run(EnrichRequest()))


# ----------------------------------------------------------------------------- business model
class ModelRepo:
    """Enough of SemanticRepository for business_model(): one fact, one dimension, one metric view."""

    FACT = uuid4()
    DIM = uuid4()
    MV = uuid4()

    def _row(
        self, id_: UUID, name: str, kind: str, asset_type: str = "table", **extra: Any
    ) -> dict[str, Any]:
        return {
            "id": id_,
            "document_id": id_,
            "source_system": "databricks",
            "platform": "databricks",
            "fqn": f"lake.gold.{name}",
            "database_name": "lake",
            "schema_name": "gold",
            "name": name,
            "asset_type": asset_type,
            "kind": kind,
            "description": "d",
            "display_name": business_name(name),
            "summary": "s",
            "name_source": "derived",
            "kind_source": "inferred",
            "field_count": 3,
            "metric_count": 1,
            "relationship_count": 1,
            "synced_at": NOW,
            "enrichment": {},
            **extra,
        }

    async def list_assets(self, **kw: Any):
        rows = [
            self._row(self.FACT, "fact_claim", "fact"),
            self._row(self.DIM, "dim_policy", "dimension", name_source="model"),
            self._row(self.MV, "mv_claims", "metric", asset_type="metric_view"),
        ]
        return rows, len(rows)

    async def scope_relationships(self, ids: list[UUID]):
        return [
            {
                "id": uuid4(),
                "source_asset_id": self.FACT,
                "target_asset_id": self.DIM,
                "target_fqn": "lake.gold.dim_policy",
                "kind": "join_inferred",
                "source_columns": ["policy_id"],
                "target_columns": ["policy_id"],
                "confidence": 0.75,
                "evidence": "dimension base name",
                "target_kind": "dimension",
                "target_display_name": "Policy",
                "target_name": "dim_policy",
            },
            {
                "id": uuid4(),
                "source_asset_id": self.MV,
                "target_asset_id": self.FACT,
                "target_fqn": "lake.gold.fact_claim",
                "kind": "metric_source",
                "source_columns": [],
                "target_columns": [],
                "confidence": 1.0,
                "evidence": "",
                "target_kind": "fact",
                "target_display_name": "Claim",
                "target_name": "fact_claim",
            },
        ]

    async def scope_metrics(self, ids: list[UUID]):
        return [
            {
                "id": uuid4(),
                "asset_id": self.FACT,
                "name": "total_paid",
                "display_name": "Total Paid",
                "expression": "SUM(paid)",
                "aggregation": "sum",
                "description": "",
                "source": "inferred",
                "dimensions": [],
                "fields": ["paid"],
                "synonyms": [],
            },
            {
                "id": uuid4(),
                "asset_id": self.MV,
                "name": "Claim count",
                "display_name": "Claim Count",
                "expression": "COUNT(DISTINCT claim_id)",
                "aggregation": "count",
                "description": "",
                "source": "declared",
                "dimensions": ["Claim status"],
                "fields": [],
                "synonyms": [],
            },
        ]

    async def scope_role_fields(self, ids: list[UUID]):
        return [
            {"asset_id": self.FACT, "name": "paid", "display_name": "Paid", "role": "measure"},
            {
                "asset_id": self.FACT,
                "name": "claim_date",
                "display_name": "Claim Date",
                "role": "time",
            },
            {
                "asset_id": self.FACT,
                "name": "policy_id",
                "display_name": "Policy ID",
                "role": "identifier",
            },
            {
                "asset_id": self.MV,
                "name": "Claim status",
                "display_name": "Claim Status",
                "role": "dimension",
            },
        ]


async def test_business_model_groups_stars_metric_views_and_dimensions():
    service = SemanticService(ModelRepo())  # type: ignore[arg-type]
    model = await service.business_model(source_system=None, database=None, schema=None)
    assert model.assets == 3 and model.facts == 1 and model.dimensions == 1
    assert model.metric_views == 1 and model.governed_metrics == 1
    (area,) = model.subject_areas
    assert area.label == "Gold" and area.named == 1 and area.described == 3
    (star,) = area.facts
    assert star.asset.display_name == "Claim" and star.measures == ["Paid"]
    assert star.time == ["Claim Date"]
    assert star.roles == {"measure": 1, "time": 1, "identifier": 1}
    (dim,) = star.dimensions
    assert dim.display_name == "Policy" and dim.join_columns == ["policy_id"]
    assert dim.confidence == 0.75
    assert dim.asset is not None and dim.asset.name_source == "model"
    assert [m.name for m in star.metrics] == ["total_paid"]
    (mv,) = area.metric_views
    assert mv.source_fqn == "lake.gold.fact_claim" and mv.dimensions == ["Claim Status"]
    assert mv.metrics[0].source == "declared"
    assert [d.display_name for d in area.dimensions] == ["Policy"]


# ----------------------------------------------------------------------------- API
def test_enrichment_routes():
    repo = FakeRepo()
    semantic_service = FakeSemantic(repo)
    enrichment = EnrichmentService(
        repo=repo,  # type: ignore[arg-type]
        semantic=semantic_service,  # type: ignore[arg-type]
        model=FakeModel([MODEL_ANSWER]),
    )

    class SemanticApi:
        async def business_model(self, **kw: Any) -> BusinessModel:
            return BusinessModel(assets=0)

    @asynccontextmanager
    async def lifespan(app):
        app.state.container = SimpleNamespace(semantic=SemanticApi(), enrichment=enrichment)
        yield

    app = create_app(
        settings=Settings(_env_file=None, service_name="test-query"),
        title="t",
        description="d",
        version="0",
        lifespan=lifespan,
        routers=[api_router],
        latency_recorder=LatencyRecorder(100),
    )
    with TestClient(app) as client:
        model = client.get("/api/v1/semantic/business-model")
        assert model.status_code == 200 and model.json()["enrichment_available"] is True

        suggested = client.post(f"/api/v1/semantic/assets/{ASSET_ID}/enrich")
        assert suggested.status_code == 200, suggested.text
        assert suggested.json()["display_name"] == "Credit Card Account"

        decided = client.post(
            f"/api/v1/semantic/assets/{ASSET_ID}/enrichment",
            json={"action": "accept", "metric_names": ["accounts"]},
        )
        assert decided.status_code == 200, decided.text
        assert decided.json()["display_name"] == "Credit Card Account"

        run = client.post("/api/v1/semantic/enrich", json={"schema": "silver", "limit": 5})
        assert run.status_code == 202, run.text
        body = run.json()
        assert body["total"] == 0 and body["status"] == "completed"
        assert client.get(f"/api/v1/semantic/enrich/{body['id']}").status_code == 200
        assert client.get(f"/api/v1/semantic/enrich/{uuid4()}").status_code == 404
        assert client.get("/api/v1/semantic/enrich").json()[0]["id"] == body["id"]
        assert client.post("/api/v1/semantic/enrich", json={"limit": 0}).status_code == 422

    assert MetricSource("curated") is MetricSource.CURATED
