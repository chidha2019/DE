import asyncio
import uuid

import pytest

from ech_core.exceptions import InvalidRunStateError
from ingestion_service.services.event_bus import EventBus, RunEvent
from ingestion_service.services.run_manager import RunManager


@pytest.mark.asyncio
async def test_publish_subscribe_with_filter_and_replay():
    bus = EventBus(history=10, queue_size=5)
    run_a, run_b = uuid.uuid4(), uuid.uuid4()
    bus.publish(RunEvent(run_id=run_a, event_type="run.started", message="a"))
    bus.publish(RunEvent(run_id=run_b, event_type="run.started", message="b"))
    async with bus.subscribe(run_id=run_a, replay=10) as queue:
        replayed = await asyncio.wait_for(queue.get(), 1)
        assert replayed.run_id == run_a and replayed.seq == 1
        bus.publish(RunEvent(run_id=run_b, event_type="x", message="ignored"))
        bus.publish(RunEvent(run_id=run_a, event_type="run.progress", message="live"))
        live = await asyncio.wait_for(queue.get(), 1)
        assert live.message == "live" and live.seq == 4
        assert bus.subscriber_count == 1
    assert bus.subscriber_count == 0


@pytest.mark.asyncio
async def test_slow_subscriber_drops_oldest_instead_of_blocking():
    bus = EventBus(history=10, queue_size=2)
    run = uuid.uuid4()
    async with bus.subscribe() as queue:
        for i in range(5):
            bus.publish(RunEvent(run_id=run, event_type="e", message=str(i)))
        assert queue.qsize() == 2
        assert (await queue.get()).message == "3"
        assert (await queue.get()).message == "4"


@pytest.mark.asyncio
async def test_run_manager_pause_resume_cancel_lifecycle():
    manager = RunManager()
    run_id = uuid.uuid4()
    handle = manager.register(run_id, "confluence")
    progressed = asyncio.Event()

    async def work():
        await handle.pause_event.wait()
        progressed.set()
        await handle.cancel_event.wait()

    manager.pause(run_id)
    manager.start(handle, work)
    await asyncio.sleep(0.01)
    assert handle.paused and not progressed.is_set()
    manager.resume(run_id)
    await asyncio.wait_for(progressed.wait(), 1)
    assert manager.active_for_connector("confluence") is handle
    manager.cancel(run_id)
    await asyncio.wait_for(handle.task, 1)
    assert manager.get(run_id) is None  # done-callback removed it
    with pytest.raises(InvalidRunStateError):
        manager.pause(run_id)
