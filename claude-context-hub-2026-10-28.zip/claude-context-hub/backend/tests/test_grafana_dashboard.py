"""The hub's Grafana dashboard: queries only name exported metrics, and importing it hits /api/dashboards/db."""

from __future__ import annotations

import asyncio
import inspect
import json
import re

import httpx

import ech_core.metrics as metrics_module
from ech_core.grafana_client import GrafanaClient, GrafanaSnapshot
from ech_core.grafana_dashboard import HUB_DASHBOARD_UID, hub_dashboard
from query_service.api.observability import build_observability

BASE = "https://grafana.example"
TOKEN = "not-a-real-token"


def exported_metric_names() -> set[str]:
    base = set(re.findall(r'"(ech_[a-z0-9_]+)"', inspect.getsource(metrics_module)))
    names = set(base)
    for name in base:
        stem = name[: -len("_total")] if name.endswith("_total") else name
        names |= {f"{stem}_total", f"{stem}_bucket", f"{stem}_count", f"{stem}_sum", f"{stem}_created"}
    return names


def test_dashboard_queries_reference_only_exported_metrics():
    dashboard = hub_dashboard()
    assert dashboard["uid"] == HUB_DASHBOARD_UID
    panels = [p for p in dashboard["panels"] if p["type"] != "row"]
    assert len(panels) >= 15
    allowed = exported_metric_names()
    seen: set[str] = set()
    for panel in panels:
        assert panel["gridPos"]["x"] + panel["gridPos"]["w"] <= 24, panel["title"]
        for target in panel["targets"]:
            used = set(re.findall(r"ech_[a-z0-9_]+", target["expr"]))
            assert used, panel["title"]
            assert used <= allowed, (panel["title"], used - allowed)
            seen |= used
    # Every family the services export is on the board somewhere.
    assert {"ech_http_requests_total", "ech_http_request_duration_seconds_bucket", "ech_retrieval_requests_total", "ech_ingestion_documents_total", "ech_graph_sync_total"} <= seen
    assert dashboard["templating"]["list"][0]["type"] == "datasource"


def test_import_posts_the_model_with_overwrite():
    posted: list[dict] = []

    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "POST" and request.url.path == "/api/dashboards/db":
            body = json.loads(request.content)
            posted.append(body)
            return httpx.Response(200, json={"status": "success", "uid": body["dashboard"]["uid"], "url": f"/d/{body['dashboard']['uid']}/enterprise-context-hub", "version": 3})
        return httpx.Response(404, json={"message": "not found"})

    http = httpx.AsyncClient(base_url=BASE, transport=httpx.MockTransport(handler), headers={"Authorization": f"Bearer {TOKEN}"})
    client = GrafanaClient(BASE, TOKEN, client=http)
    result = asyncio.run(client.import_dashboard(hub_dashboard()))
    asyncio.run(client.aclose())
    assert result["uid"] == HUB_DASHBOARD_UID and result["version"] == 3
    assert posted[0]["overwrite"] is True
    assert posted[0]["dashboard"]["title"] == "Enterprise Context Hub"
    assert client.dashboard_url(result["url"]) == f"{BASE}/d/{HUB_DASHBOARD_UID}/enterprise-context-hub"


def test_observability_reports_the_hub_dashboard_when_present():
    snapshot = GrafanaSnapshot(version="11.2.0", org="Acme", dashboards=[{"uid": HUB_DASHBOARD_UID, "title": "Enterprise Context Hub", "url": f"{BASE}/d/{HUB_DASHBOARD_UID}/x"}, {"uid": "other", "title": "Other"}])
    report = build_observability(BASE, snapshot)
    assert report.hub_dashboard_url == f"{BASE}/d/{HUB_DASHBOARD_UID}/x"
    assert build_observability(BASE, GrafanaSnapshot(version=None, org=None)).hub_dashboard_url is None
