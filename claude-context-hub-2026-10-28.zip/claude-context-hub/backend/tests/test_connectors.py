"""Connector registry: only configured, real connectors are registered; mocks are gone."""

from __future__ import annotations

from ech_core.config import Settings
from ingestion_service.connectors import build_default_registry


def _clear(monkeypatch) -> None:
    for name in (
        "DATABRICKS_HOST",
        "DATABRICKS_TOKEN",
        "ECH_GITHUB_REPOS",
        "ECH_DATABRICKS_CATALOGS",
    ):
        monkeypatch.delenv(name, raising=False)


def test_registry_is_empty_without_configuration(monkeypatch):
    _clear(monkeypatch)
    assert build_default_registry().names() == []
    assert build_default_registry(Settings(_env_file=None)).names() == []


def test_registry_registers_configured_connectors(monkeypatch):
    _clear(monkeypatch)
    settings = Settings(
        _env_file=None,
        github_repos="acme/repo",
        databricks_host="https://adb-1.azuredatabricks.net",
        databricks_token="not-a-real-token",
        databricks_catalogs="main, samples",
    )
    registry = build_default_registry(settings)
    assert registry.names() == ["databricks", "github-live"]
    databricks = registry.get("databricks")
    assert databricks.source_system.value == "databricks"
    assert {e.name for e in databricks.known_entities()} >= {"Databricks", "Main", "Samples"}


def test_incomplete_connectors_are_skipped_not_fatal(monkeypatch):
    _clear(monkeypatch)
    assert (
        build_default_registry(Settings(_env_file=None, snowflake_databases="ANALYTICS")).names()
        == []
    )
    assert (
        build_default_registry(Settings(_env_file=None, databricks_catalogs="main")).names() == []
    )
