"""Business Analyst scorecard: self-serve answers, request turnaround and certified report metrics."""

from __future__ import annotations

from types import SimpleNamespace
from typing import Any

import pytest

from ech_core.config import KPI_TARGET_DEFAULTS, Settings
from ech_core.observability import LatencyRecorder
from query_service.services.stats_service import StatsService

ANALYST_KEYS = ("genie_answered_pct", "intent_decision_h", "intents_clarifying", "reporting_metrics_declared_pct")


class FakeGenieLog:
    def __init__(self, counts: dict[str, int]) -> None:
        self.counts = counts
        self.calls: list[dict[str, Any]] = []

    async def answer_counts(self, *, persona: str, days: int) -> dict[str, int]:
        self.calls.append({"persona": persona, "days": days})
        return self.counts


class FakeIntents:
    def __init__(self, row: dict[str, Any]) -> None:
        self.row = row

    async def turnaround(self, *, days: int) -> dict[str, Any]:
        return self.row


class FakeSemantic:
    def __init__(self, row: dict[str, Any]) -> None:
        self.row = row

    async def coverage_kpis(self) -> dict[str, Any]:
        return self.row


def _service(**repos: Any) -> StatsService:
    stub = SimpleNamespace()
    return StatsService(
        documents=stub,  # type: ignore[arg-type]
        chunks=stub,  # type: ignore[arg-type]
        embeddings=stub,  # type: ignore[arg-type]
        runs=stub,  # type: ignore[arg-type]
        audit=stub,  # type: ignore[arg-type]
        graph=stub,  # type: ignore[arg-type]
        embedder=stub,  # type: ignore[arg-type]
        latency=LatencyRecorder(10),
        **repos,
    )


def test_analyst_targets_have_defaults_and_settings():
    for key in ANALYST_KEYS:
        assert key in KPI_TARGET_DEFAULTS
        assert Settings(_env_file=None).kpi_targets[key] == KPI_TARGET_DEFAULTS[key]


@pytest.mark.asyncio
async def test_analyst_report_scores_answers_requests_and_certified_metrics():
    genie = FakeGenieLog({"asked": 10, "answered": 7, "unhelpful": 1, "failed": 1})
    service = _service(
        genie_log=genie,
        intents=FakeIntents({"clarifying": 2, "questions": 5, "decided": 4, "decision_h": 30.0}),
        semantic=FakeSemantic({"metrics": 30, "reporting_metrics": 10, "reporting_metrics_declared": 8}),
    )
    report = await service.analyst(days=7)
    assert [g.key for g in report.groups] == ["answers", "requests", "trust"]
    by_key = {k.key: k for g in report.groups for k in g.kpis}
    # only the analyst's own Genie space counts
    assert genie.calls == [{"persona": "business_analyst", "days": 7}]
    # 7 of 10 answered against 80 %: within ten points, so a warning
    assert by_key["genie_answered_pct"].value == 70.0
    assert by_key["genie_answered_pct"].status == "warn"
    assert "1 marked unhelpful" in by_key["genie_answered_pct"].detail
    # a 30-hour median beats the 48-hour target; two requests waiting is a warning against zero
    assert by_key["intent_decision_h"].value == 30.0
    assert by_key["intent_decision_h"].unit == "hours"
    assert by_key["intent_decision_h"].status == "ok"
    assert by_key["intents_clarifying"].value == 2.0
    assert by_key["intents_clarifying"].status == "warn"
    assert by_key["intents_clarifying"].detail == "5 open questions from the planner"
    # 8 of 10 curated-layer metrics declared meets the 80 % target
    assert by_key["reporting_metrics_declared_pct"].value == 80.0
    assert by_key["reporting_metrics_declared_pct"].status == "ok"
    assert {t.key for t in report.targets} == set(ANALYST_KEYS)
    assert all(t.env_var == f"ECH_KPI_TARGET_{t.key.upper()}" for t in report.targets)


@pytest.mark.asyncio
async def test_analyst_report_without_activity_has_no_verdicts():
    # no questions, no decided requests and only raw-layer metrics: nothing to judge, not "off target"
    service = _service(
        genie_log=FakeGenieLog({"asked": 0, "answered": 0, "unhelpful": 0, "failed": 0}),
        intents=FakeIntents({"clarifying": 0, "questions": 0, "decided": 0, "decision_h": None}),
        semantic=FakeSemantic({"metrics": 20, "reporting_metrics": 0, "reporting_metrics_declared": 0}),
    )
    by_key = {k.key: k for g in (await service.analyst(days=7)).groups for k in g.kpis}
    assert by_key["genie_answered_pct"].status == "na"
    assert by_key["intent_decision_h"].status == "na"
    assert by_key["intents_clarifying"].status == "ok"
    assert by_key["reporting_metrics_declared_pct"].status == "na"
    assert by_key["reporting_metrics_declared_pct"].detail == "no curated-layer metrics yet; all 20 sit on raw schemas"


@pytest.mark.asyncio
async def test_analyst_report_without_repositories():
    report = await _service().analyst(days=3)
    assert report.window_days == 3
    assert all(k.status == "na" for g in report.groups for k in g.kpis)
