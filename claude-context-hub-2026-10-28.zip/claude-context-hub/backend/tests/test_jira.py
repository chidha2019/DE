"""Jira: the client's paging, the link that follows the saved connection, the connector (issues as documents),
the Connectors-page fields and the intent service reading tickets through the link."""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any

import httpx
import pytest
from pydantic import SecretStr

from ech_core.config import Settings
from ech_core.exceptions import ConnectorError, DependencyUnavailableError
from ech_core.jira_client import JiraClient, JiraLink, jira_identity
from ingestion_service.connectors.base import ConnectorOptions
from ingestion_service.connectors.catalog import describe_catalog
from ingestion_service.connectors.connections import CONNECTION_FIELDS, build_connector
from ingestion_service.connectors.jira import JiraConnector, issue_document
from query_service.intents.service import IntentService

TOKEN = "not-a-real-token"
SITE = "https://acme.atlassian.net"


def _settings(tmp_path: Path, **overrides: Any) -> Settings:
    values: dict[str, Any] = {"jira_base_url": SITE, "jira_email": "data@acme.test", "jira_api_token": SecretStr(TOKEN), "state_dir": tmp_path}
    values.update(overrides)
    return Settings(_env_file=None, **values)


def _raw(key: str, summary: str = "Load the claims extracts") -> dict[str, Any]:
    return {
        "key": key,
        "fields": {
            "summary": summary,
            "description": {"type": "doc", "content": [{"type": "paragraph", "content": [{"type": "text", "text": "Files are in summit_claims."}]}]},
            "reporter": {"displayName": "Ana Reyes"},
            "assignee": {"displayName": "Data Bot"},
            "status": {"name": "To Do"},
            "issuetype": {"name": "Story"},
            "priority": {"name": "High"},
            "project": {"key": "DATA", "name": "Data Platform"},
            "labels": ["ech-intent"],
            "created": "2026-10-27T13:18:04.000+0000",
            "updated": "2026-10-27T14:02:11.000+0000",
        },
    }


def _client(handler: Any) -> JiraClient:
    http = httpx.AsyncClient(base_url=SITE, transport=httpx.MockTransport(handler))
    return JiraClient(SITE, "data@acme.test", TOKEN, client=http)


def test_search_all_pages_through_the_enhanced_search():
    bodies: list[dict[str, Any]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content)
        bodies.append(body)
        if "nextPageToken" not in body:
            return httpx.Response(200, json={"issues": [_raw("DATA-1"), _raw("DATA-2")], "nextPageToken": "p2"})
        return httpx.Response(200, json={"issues": [_raw("DATA-3")], "isLast": True})

    issues = asyncio.run(_client(handler).search_all("project = DATA", limit=10))
    assert [i["key"] for i in issues] == ["DATA-1", "DATA-2", "DATA-3"]
    assert bodies[1]["nextPageToken"] == "p2" and bodies[0]["maxResults"] == 10


def test_search_falls_back_to_the_legacy_search():
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/search/jql"):
            return httpx.Response(404, json={"errorMessages": ["not here"]})
        return httpx.Response(200, json={"issues": [_raw("DATA-1")], "total": 1})

    issues = asyncio.run(_client(handler).search("project = DATA", max_results=5))
    assert [i["key"] for i in issues] == ["DATA-1"] and issues[0]["project"] == "DATA"


def test_an_issue_becomes_a_document_with_people_project_and_times():
    flat = _client(lambda r: httpx.Response(200))._flatten(_raw("DATA-7"))
    doc = issue_document(flat)
    assert doc.external_id == "DATA-7" and doc.title == "DATA-7 · Load the claims extracts" and doc.uri == f"{SITE}/browse/DATA-7"
    assert "- **Status:** To Do" in doc.content and "- **Project:** Data Platform (DATA)" in doc.content and "Files are in summit_claims." in doc.content
    assert doc.author == "Ana Reyes" and doc.contributors == ["Ana Reyes", "Data Bot"]
    assert doc.attributes["labels"] == ["ech-intent"] and doc.source_created_at is not None and doc.source_created_at.utcoffset() is not None
    assert {e.name for e in doc.explicit_entities} == {"Jira", "Data Platform"}


def test_the_link_follows_the_saved_connection(tmp_path: Path):
    current = {"settings": Settings(_env_file=None, state_dir=tmp_path)}

    async def settings() -> Settings:
        return current["settings"]

    link = JiraLink(settings, lambda: current["settings"])

    async def go():
        none = await link.client()
        current["settings"] = _settings(tmp_path)
        first = await link.client()
        again = await link.client()
        current["settings"] = _settings(tmp_path, jira_api_token=SecretStr("another-fake-token"))
        rotated = await link.client()
        await link.aclose()
        return none, first, again, rotated

    none, first, again, rotated = asyncio.run(go())
    assert none is None and first is not None and first.base_url == SITE
    assert again is first and rotated is not first
    assert jira_identity(_settings(tmp_path)) is not None and TOKEN not in repr(jira_identity(_settings(tmp_path)))


def test_connector_checks_the_account_and_reads_issues():
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/myself"):
            return httpx.Response(200, json={"displayName": "Data Bot"})
        return httpx.Response(200, json={"issues": [_raw("DATA-1"), _raw("DATA-2", "Policy extracts")], "isLast": True})

    connector = JiraConnector(_client(handler), jql="project = DATA", max_issues=5, intent_jql='labels = "ech-intent"')

    async def go():
        health = await connector.health_check()
        docs = [d async for d in connector.iter_documents(ConnectorOptions())]
        return health, docs

    health, docs = asyncio.run(go())
    assert health.healthy and health.details["account"] == "Data Bot" and health.details["intent tickets"] == 2
    assert [d.external_id for d in docs] == ["DATA-1", "DATA-2"]

    denied = JiraConnector(_client(lambda r: httpx.Response(401, text="no")), jql="x", max_issues=5, intent_jql="x")
    result = asyncio.run(denied.health_check())
    assert not result.healthy and "401" in result.details["error"]


def test_jira_is_editable_on_the_connectors_page_and_in_the_catalog(tmp_path: Path):
    fields = {f.name: f for f in CONNECTION_FIELDS["jira"]}
    assert fields["jira_api_token"].kind == "secret" and fields["jira_base_url"].required and fields["jira_email"].required
    connector = build_connector("jira", _settings(tmp_path))
    assert isinstance(connector, JiraConnector)
    asyncio.run(connector.aclose())
    with pytest.raises(ConnectorError):
        build_connector("jira", _settings(tmp_path, jira_api_token=None))
    entry = next(e for e in describe_catalog(set()).entries if e.key == "jira")
    assert entry.adapter == "jira" and entry.availability == "available"
    assert next(e for e in describe_catalog({"jira"}).entries if e.key == "jira").availability == "configured"


class _Link:
    def __init__(self, client: Any) -> None:
        self._client = client

    def configured(self) -> bool:
        return self._client is not None

    def jql(self) -> str:
        return 'labels = "ech-intent"'

    def poll_seconds(self) -> int:
        return 120

    async def client(self) -> Any:
        return self._client


class _Repo:
    async def by_jira_key(self, key: str) -> None:
        return None


def _service(tmp_path: Path, link: _Link) -> IntentService:
    return IntentService(
        repo=_Repo(),  # type: ignore[arg-type]
        planner=None,  # type: ignore[arg-type]
        model=None,
        glossary=None,
        workspace_dir=tmp_path / "pipelines",
        data_dir=tmp_path / "data",
        jira_link=link,  # type: ignore[arg-type]
    )


def test_intent_service_follows_the_link(tmp_path: Path):
    connected = _service(tmp_path, _Link(object()))
    config = connected.config()
    assert connected.polling and config.jira_configured and config.poll_seconds == 120 and config.jira_jql == 'labels = "ech-intent"'

    offline = _service(tmp_path, _Link(None))
    assert offline.polling and not offline.config().jira_configured
    with pytest.raises(DependencyUnavailableError, match="Connectors page"):
        asyncio.run(offline.import_jira("DATA-5"))
    with pytest.raises(DependencyUnavailableError, match="Connectors page"):
        asyncio.run(offline.sync_jira())


def test_posted_entries_stored_as_json_text_are_read_back_as_objects():
    from ech_core.repositories.intent_repository import _row

    entry = {"kind": "questions", "comment_id": "10032", "at": "2026-10-27T18:58:02+00:00"}
    stored_as_text = {"posted": [json.dumps([entry])], "intent": None}
    assert _row(stored_as_text)["posted"] == [entry]
    assert _row({"posted": json.dumps([entry, json.dumps(entry)])})["posted"] == [entry, entry]
    assert _row({"posted": None})["posted"] == []


def test_append_posted_writes_through_update():
    from ech_core.repositories.intent_repository import IntentRepository

    calls: list[tuple[str, tuple[Any, ...]]] = []
    row = {"id": "x", "posted": json.dumps([{"kind": "spec", "comment_id": "1"}])}

    class Db:
        async def fetchrow(self, sql: str, *args: Any) -> dict[str, Any]:
            return row

        async def execute(self, sql: str, *args: Any) -> None:
            calls.append((sql, args))

    repo = IntentRepository(Db())  # type: ignore[arg-type]
    asyncio.run(repo.append_posted("x", {"kind": "questions", "comment_id": "2"}))  # type: ignore[arg-type]
    sql, args = calls[0]
    assert "posted = $1::jsonb" in sql and "||" not in sql
    assert json.loads(args[0]) == [{"kind": "spec", "comment_id": "1"}, {"kind": "questions", "comment_id": "2"}]
