"""Enumerations mirrored 1:1 by Postgres enum types and Neo4j labels."""

from __future__ import annotations

from enum import StrEnum


class SourceSystem(StrEnum):
    CONFLUENCE = "confluence"
    SHAREPOINT = "sharepoint"
    GITHUB = "github"
    MANUAL = "manual"
    SNOWFLAKE = "snowflake"
    DATABRICKS = "databricks"
    GRAFANA = "grafana"
    JIRA = "jira"


class DocumentKind(StrEnum):
    """What a stored document is to a reader: a page/file/code, or a catalog dataset."""

    DOCUMENT = "document"
    DATASET = "dataset"


class GraphSyncStatus(StrEnum):
    PENDING = "pending"
    SYNCED = "synced"
    FAILED = "failed"


class RunStatus(StrEnum):
    QUEUED = "queued"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

    @property
    def is_terminal(self) -> bool:
        return self in {RunStatus.COMPLETED, RunStatus.FAILED, RunStatus.CANCELLED}

    @property
    def is_active(self) -> bool:
        return self in {RunStatus.QUEUED, RunStatus.RUNNING, RunStatus.PAUSED}


class EntityType(StrEnum):
    """Also used verbatim as secondary Neo4j labels, hence the capitalisation."""

    PERSON = "Person"
    PROJECT = "Project"
    TECHNOLOGY = "Technology"
    CONCEPT = "Concept"


class RelationshipType(StrEnum):
    HAS_CHUNK = "HAS_CHUNK"
    MENTIONS = "MENTIONS"
    REFERENCES = "REFERENCES"
    DEPENDS_ON = "DEPENDS_ON"
    CONTRIBUTED_BY = "CONTRIBUTED_BY"


class EventLevel(StrEnum):
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
