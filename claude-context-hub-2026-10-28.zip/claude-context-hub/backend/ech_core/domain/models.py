"""Persistence-level records exchanged between repositories and services.

These are *internal* models (not the public API schemas in ``ech_core.schemas``).
They map 1:1 to table rows / graph payloads and use pydantic for cheap
validation and ``from_row`` coercion of asyncpg records.
"""

from __future__ import annotations

from collections.abc import Mapping
from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from ech_core.domain.enums import DocumentKind, EntityType, GraphSyncStatus, RunStatus, SourceSystem


class _Record(BaseModel):
    model_config = ConfigDict(from_attributes=True, extra="ignore")

    @classmethod
    def from_row(cls, row: Mapping[str, Any]):  # type: ignore[no-untyped-def]
        return cls.model_validate(dict(row))


# ----------------------------------------------------------------------------- documents
class DocumentUpsert(BaseModel):
    """Input for ``DocumentRepository.upsert``."""

    id: UUID
    source_system: SourceSystem
    kind: DocumentKind = DocumentKind.DOCUMENT
    external_id: str
    title: str
    uri: str | None = None
    author: str | None = None
    mime_type: str = "text/markdown"
    language: str = "en"
    content_hash: str
    content_length: int = 0
    attributes: dict[str, Any] = Field(default_factory=dict)
    source_created_at: datetime | None = None
    source_updated_at: datetime | None = None
    last_run_id: UUID | None = None


class DocumentRecord(_Record):
    id: UUID
    source_id: UUID | None = None
    source_system: SourceSystem
    kind: DocumentKind = DocumentKind.DOCUMENT
    external_id: str
    title: str
    uri: str | None = None
    author: str | None = None
    mime_type: str
    language: str
    content_hash: str
    content_length: int
    version: int
    attributes: dict[str, Any] = Field(default_factory=dict)
    graph_sync_status: GraphSyncStatus
    graph_node_id: str | None = None
    graph_synced_at: datetime | None = None
    graph_sync_error: str | None = None
    source_created_at: datetime | None = None
    source_updated_at: datetime | None = None
    ingested_at: datetime
    updated_at: datetime
    deleted_at: datetime | None = None
    last_run_id: UUID | None = None
    chunk_count: int | None = None
    embedding_count: int | None = None


# ----------------------------------------------------------------------------- chunks
class ChunkRecord(_Record):
    id: UUID
    document_id: UUID
    chunk_index: int
    content: str
    token_count: int
    char_start: int
    char_end: int
    section_path: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime | None = None


class ChunkWithDocument(ChunkRecord):
    document_title: str
    source_system: SourceSystem
    uri: str | None = None
    document_attributes: dict[str, Any] = Field(default_factory=dict)


class EmbeddingRecord(BaseModel):
    chunk_id: UUID
    model: str
    dimensions: int
    vector: list[float]


class ScoredChunk(BaseModel):
    """A hit from one retrieval leg (vector or keyword)."""

    chunk_id: UUID
    document_id: UUID
    score: float


# ----------------------------------------------------------------------------- pipelines
class IngestionRunRecord(_Record):
    id: UUID
    connector_name: str
    source_system: SourceSystem
    status: RunStatus
    config: dict[str, Any] = Field(default_factory=dict)
    stats: dict[str, Any] = Field(default_factory=dict)
    triggered_by: str | None = None
    pipeline_id: UUID | None = None
    error: str | None = None
    started_at: datetime | None = None
    finished_at: datetime | None = None
    created_at: datetime
    updated_at: datetime


class RunEventRecord(_Record):
    id: int
    run_id: UUID
    level: str
    event_type: str
    message: str
    payload: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime


class AuditRecord(_Record):
    id: int
    request_id: str | None = None
    actor: str | None = None
    action: str
    resource_type: str | None = None
    resource_id: str | None = None
    status: str
    latency_ms: float | None = None
    details: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime


# ----------------------------------------------------------------------------- graph
class EntityMention(BaseModel):
    """An entity detected in a chunk (also persisted in ``chunks.metadata.entities``)."""

    key: str
    name: str
    entity_type: EntityType
    normalized_name: str
    confidence: float = Field(ge=0.0, le=1.0)


class GraphChunkPayload(BaseModel):
    chunk_id: UUID
    chunk_index: int
    token_count: int
    section_path: list[str] = Field(default_factory=list)
    preview: str = ""


class GraphMentionPayload(BaseModel):
    chunk_id: UUID
    key: str
    name: str
    entity_type: EntityType
    normalized_name: str
    confidence: float


class GraphContributorPayload(BaseModel):
    key: str
    name: str
    normalized_name: str
    role: str = "author"


class GraphReferencePayload(BaseModel):
    document_id: UUID
    external_id: str
    source_system: SourceSystem
    title: str | None = None
    kind: str = "link"


class GraphDependencyPayload(BaseModel):
    from_key: str
    to_key: str
    weight: float = 1.0


class GraphDocumentPayload(BaseModel):
    """Everything needed to (re)write one document's subgraph atomically."""

    document_id: UUID
    external_id: str
    source_system: SourceSystem
    title: str
    uri: str | None = None
    author: str | None = None
    version: int = 1
    mime_type: str = "text/markdown"
    chunks: list[GraphChunkPayload] = Field(default_factory=list)
    mentions: list[GraphMentionPayload] = Field(default_factory=list)
    contributors: list[GraphContributorPayload] = Field(default_factory=list)
    references: list[GraphReferencePayload] = Field(default_factory=list)
    dependencies: list[GraphDependencyPayload] = Field(default_factory=list)


class GraphEntityRef(BaseModel):
    key: str
    name: str
    entity_type: str


class ExpandedChunk(BaseModel):
    chunk_id: UUID
    document_id: UUID
    score: float
    via: list[str] = Field(default_factory=list)


class GraphExpansion(BaseModel):
    """Result of ``GraphRepository.expand_from_chunks``."""

    nodes: list[dict[str, Any]] = Field(default_factory=list)
    edges: list[dict[str, Any]] = Field(default_factory=list)
    chunk_entities: dict[str, list[GraphEntityRef]] = Field(default_factory=dict)
    expanded_chunks: list[ExpandedChunk] = Field(default_factory=list)
    first_degree_keys: list[str] = Field(default_factory=list)
    second_degree_keys: list[str] = Field(default_factory=list)
