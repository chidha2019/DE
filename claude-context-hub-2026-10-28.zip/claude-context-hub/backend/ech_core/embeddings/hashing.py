"""Deterministic feature-hashing embeddings (no model, no network).

Not a semantic model — it is a signed feature-hashing projection of word
unigrams, bigrams and character trigrams, L2-normalised. It gives stable,
lexically meaningful cosine similarities so the *whole pipeline* (pgvector,
HNSW, fusion, graph expansion, reranking) can be developed and tested without
API keys or model downloads. Swap in ``openai`` or ``local`` for production.

Hashing uses BLAKE2b (not Python's randomised ``hash``) so vectors are
identical across processes and restarts.
"""

from __future__ import annotations

import asyncio
import math
from collections import Counter
from collections.abc import Sequence
from hashlib import blake2b

from ech_core.embeddings.base import EmbeddingProvider, Vector, l2_normalize
from ech_core.text import tokenize

_INLINE_THRESHOLD = 8  # batches larger than this run in a worker thread


def _features(text: str) -> Counter[str]:
    tokens = tokenize(text)
    feats: Counter[str] = Counter()
    for tok in tokens:
        feats[f"w:{tok}"] += 1
        padded = f"#{tok}#"
        for i in range(len(padded) - 2):
            feats[f"c:{padded[i : i + 3]}"] += 1
    for a, b in zip(tokens, tokens[1:], strict=False):
        feats[f"b:{a}_{b}"] += 1
    return feats


def hashing_embedding(text: str, dimensions: int) -> Vector:
    vec = [0.0] * dimensions
    for feat, count in _features(text).items():
        digest = blake2b(feat.encode("utf-8"), digest_size=8).digest()
        idx = int.from_bytes(digest[:4], "little") % dimensions
        sign = 1.0 if digest[4] & 1 else -1.0
        weight = 1.0 + math.log(count)
        if feat.startswith("c:"):
            weight *= 0.35  # character features are a smoothing signal, not the main one
        vec[idx] += sign * weight
    return l2_normalize(vec)


class HashingEmbeddingProvider(EmbeddingProvider):
    name = "hashing"

    def __init__(
        self, *, dimensions: int = 1536, batch_size: int = 256, max_concurrency: int = 4
    ) -> None:
        super().__init__(
            model="feature-hashing-v1",
            dimensions=dimensions,
            batch_size=batch_size,
            max_concurrency=max_concurrency,
        )

    async def _embed_batch(self, texts: Sequence[str]) -> list[Vector]:
        if len(texts) <= _INLINE_THRESHOLD:
            return [hashing_embedding(t, self.dimensions) for t in texts]
        return await asyncio.to_thread(
            lambda: [hashing_embedding(t, self.dimensions) for t in texts]
        )
