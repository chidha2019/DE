"""Abstract embedding provider with batching, bounded concurrency and metrics."""

from __future__ import annotations

import asyncio
import math
import time
from abc import ABC, abstractmethod
from collections.abc import Sequence

from ech_core.exceptions import EmbeddingError
from ech_core.metrics import EMBEDDING_BATCH_DURATION, EMBEDDING_TEXTS_TOTAL

Vector = list[float]


def l2_normalize(vector: Sequence[float]) -> Vector:
    norm = math.sqrt(sum(x * x for x in vector))
    if norm == 0.0:
        return list(vector)
    return [x / norm for x in vector]


class EmbeddingProvider(ABC):
    """Base class. Subclasses implement :meth:`_embed_batch` only.

    Vectors are *always* returned with exactly ``dimensions`` components:
    shorter native vectors are zero-padded (cosine similarity is invariant to
    trailing zeros), longer ones are rejected because truncation would silently
    destroy information.
    """

    name: str = "base"

    def __init__(
        self,
        *,
        model: str,
        dimensions: int,
        batch_size: int = 64,
        max_concurrency: int = 4,
    ) -> None:
        self.model = model
        self._dimensions = dimensions
        self._batch_size = max(1, batch_size)
        self._semaphore = asyncio.Semaphore(max(1, max_concurrency))

    @property
    def dimensions(self) -> int:
        return self._dimensions

    @property
    def model_id(self) -> str:
        return f"{self.name}:{self.model}"

    # ------------------------------------------------------------------ public API
    async def embed_texts(self, texts: Sequence[str]) -> list[Vector]:
        if not texts:
            return []
        batches = [texts[i : i + self._batch_size] for i in range(0, len(texts), self._batch_size)]
        results = await asyncio.gather(*(self._guarded(batch) for batch in batches))
        vectors = [v for batch in results for v in batch]
        if len(vectors) != len(texts):
            raise EmbeddingError(
                "Provider returned a different number of vectors than texts",
                details={"expected": len(texts), "got": len(vectors), "provider": self.name},
            )
        return [self._fit(v) for v in vectors]

    async def embed_query(self, text: str) -> Vector:
        return (await self.embed_texts([text]))[0]

    async def health_check(self) -> bool:
        return True

    async def aclose(self) -> None:  # pragma: no cover - default no-op
        return None

    # ------------------------------------------------------------------ internals
    async def _guarded(self, batch: Sequence[str]) -> list[Vector]:
        async with self._semaphore:
            started = time.perf_counter()
            vectors = await self._embed_batch([t if t.strip() else " " for t in batch])
            EMBEDDING_BATCH_DURATION.labels(self.name).observe(time.perf_counter() - started)
            EMBEDDING_TEXTS_TOTAL.labels(self.name).inc(len(batch))
            return vectors

    def _fit(self, vector: Sequence[float]) -> Vector:
        n = len(vector)
        if n == self._dimensions:
            return list(vector)
        if n < self._dimensions:
            return [*vector, *([0.0] * (self._dimensions - n))]
        raise EmbeddingError(
            "Embedding has more dimensions than the configured target",
            details={"got": n, "expected": self._dimensions, "provider": self.name},
        )

    @abstractmethod
    async def _embed_batch(self, texts: Sequence[str]) -> list[Vector]:
        """Embed one batch; return vectors in input order."""
