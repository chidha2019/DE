"""Build the configured embedding provider from settings."""

from __future__ import annotations

from ech_core.config import Settings
from ech_core.embeddings.base import EmbeddingProvider
from ech_core.embeddings.hashing import HashingEmbeddingProvider
from ech_core.exceptions import EmbeddingError
from ech_core.logging import get_logger

log = get_logger(__name__)


def build_embedding_provider(settings: Settings) -> EmbeddingProvider:
    provider = settings.embedding_provider
    if provider == "openai":
        if settings.openai_api_key is None or not settings.openai_api_key.get_secret_value():
            raise EmbeddingError(
                "ECH_EMBEDDING_PROVIDER=openai requires ECH_OPENAI_API_KEY to be set"
            )
        from ech_core.embeddings.openai_provider import OpenAIEmbeddingProvider

        instance: EmbeddingProvider = OpenAIEmbeddingProvider(
            api_key=settings.openai_api_key.get_secret_value(),
            model=settings.embedding_model,
            dimensions=settings.embedding_dimensions,
            base_url=settings.openai_base_url,
            timeout_seconds=settings.openai_timeout_seconds,
            batch_size=settings.embedding_batch_size,
            max_concurrency=settings.embedding_max_concurrency,
        )
    elif provider == "local":
        from ech_core.embeddings.local_provider import LocalEmbeddingProvider

        instance = LocalEmbeddingProvider(
            model=settings.local_embedding_model,
            dimensions=settings.embedding_dimensions,
            batch_size=min(settings.embedding_batch_size, 64),
            max_concurrency=1,
        )
    else:
        instance = HashingEmbeddingProvider(
            dimensions=settings.embedding_dimensions,
            batch_size=settings.embedding_batch_size,
            max_concurrency=settings.embedding_max_concurrency,
        )
    log.info(
        "embeddings.provider",
        provider=instance.name,
        model=instance.model,
        dimensions=instance.dimensions,
    )
    return instance
