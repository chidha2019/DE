"""Embedding providers behind one async interface."""

from ech_core.embeddings.base import EmbeddingProvider
from ech_core.embeddings.factory import build_embedding_provider

__all__ = ["EmbeddingProvider", "build_embedding_provider"]
