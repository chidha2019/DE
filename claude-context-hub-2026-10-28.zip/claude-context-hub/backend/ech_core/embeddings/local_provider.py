"""Local sentence-transformers provider (optional extra ``ech-backend[local]``).

The model is loaded lazily in a worker thread on first use so service startup
stays fast; encoding also runs off the event loop. Native vectors (e.g. 384-d
for MiniLM) are zero-padded to the configured dimension by the base class.
"""

from __future__ import annotations

import asyncio
from collections.abc import Sequence
from typing import Any

from ech_core.embeddings.base import EmbeddingProvider, Vector
from ech_core.exceptions import EmbeddingError
from ech_core.logging import get_logger

log = get_logger(__name__)


class LocalEmbeddingProvider(EmbeddingProvider):
    name = "local"

    def __init__(
        self,
        *,
        model: str = "sentence-transformers/all-MiniLM-L6-v2",
        dimensions: int = 1536,
        batch_size: int = 32,
        max_concurrency: int = 1,
    ) -> None:
        super().__init__(
            model=model,
            dimensions=dimensions,
            batch_size=batch_size,
            max_concurrency=max_concurrency,
        )
        self._model: Any = None
        self._load_lock = asyncio.Lock()

    async def _ensure_loaded(self) -> Any:
        if self._model is not None:
            return self._model
        async with self._load_lock:
            if self._model is None:
                log.info("local_embeddings.loading", model=self.model)
                try:
                    self._model = await asyncio.to_thread(self._load)
                except ImportError as exc:
                    raise EmbeddingError(
                        "sentence-transformers is not installed; "
                        "install with `pip install 'ech-backend[local]'`"
                    ) from exc
                native = int(self._model.get_sentence_embedding_dimension())
                if native > self.dimensions:
                    raise EmbeddingError(
                        "Local model dimension exceeds the configured target",
                        details={"native": native, "target": self.dimensions},
                    )
                log.info("local_embeddings.loaded", model=self.model, native_dimensions=native)
        return self._model

    def _load(self) -> Any:
        from sentence_transformers import SentenceTransformer  # type: ignore[import-not-found]

        return SentenceTransformer(self.model)

    async def health_check(self) -> bool:
        try:
            await self._ensure_loaded()
            return True
        except Exception:  # noqa: BLE001
            return False

    async def _embed_batch(self, texts: Sequence[str]) -> list[Vector]:
        model = await self._ensure_loaded()
        arrays = await asyncio.to_thread(
            model.encode,
            list(texts),
            normalize_embeddings=True,
            convert_to_numpy=True,
            show_progress_bar=False,
        )
        return [[float(x) for x in row] for row in arrays]
