"""OpenAI ``/v1/embeddings`` provider (text-embedding-3-*) over httpx.

Uses the REST API directly to avoid a heavyweight SDK dependency. Retries
429/5xx and transport errors with exponential backoff and honours
``Retry-After`` when present.
"""

from __future__ import annotations

import asyncio
import random
from collections.abc import Sequence

import httpx

from ech_core.embeddings.base import EmbeddingProvider, Vector
from ech_core.exceptions import EmbeddingError
from ech_core.logging import get_logger

log = get_logger(__name__)

_RETRY_STATUSES = {408, 409, 429, 500, 502, 503, 504}


class OpenAIEmbeddingProvider(EmbeddingProvider):
    name = "openai"

    def __init__(
        self,
        *,
        api_key: str,
        model: str = "text-embedding-3-small",
        dimensions: int = 1536,
        base_url: str = "https://api.openai.com/v1",
        timeout_seconds: float = 30.0,
        batch_size: int = 64,
        max_concurrency: int = 4,
        max_retries: int = 4,
    ) -> None:
        super().__init__(
            model=model,
            dimensions=dimensions,
            batch_size=batch_size,
            max_concurrency=max_concurrency,
        )
        if not api_key:
            raise EmbeddingError("OpenAI embedding provider requires an API key")
        self._max_retries = max_retries
        self._client = httpx.AsyncClient(
            base_url=base_url.rstrip("/"),
            timeout=httpx.Timeout(timeout_seconds, connect=10.0),
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            limits=httpx.Limits(max_connections=max_concurrency * 2),
        )

    async def aclose(self) -> None:
        await self._client.aclose()

    async def health_check(self) -> bool:
        try:
            await self.embed_texts(["healthcheck"])
            return True
        except Exception:  # noqa: BLE001
            return False

    async def _embed_batch(self, texts: Sequence[str]) -> list[Vector]:
        body: dict[str, object] = {"model": self.model, "input": list(texts)}
        if self.model.startswith("text-embedding-3"):
            body["dimensions"] = self.dimensions  # native Matryoshka truncation

        delay = 1.0
        last_error = ""
        for attempt in range(1, self._max_retries + 1):
            try:
                response = await self._client.post("/embeddings", json=body)
            except httpx.HTTPError as exc:
                last_error = f"transport error: {exc}"
            else:
                if response.status_code == 200:
                    data = response.json().get("data", [])
                    # The API preserves order but also returns an index; sort defensively.
                    data.sort(key=lambda item: item.get("index", 0))
                    return [list(map(float, item["embedding"])) for item in data]
                last_error = f"HTTP {response.status_code}: {response.text[:300]}"
                if response.status_code not in _RETRY_STATUSES:
                    raise EmbeddingError(
                        "OpenAI embeddings request failed", details={"error": last_error}
                    )
                retry_after = response.headers.get("Retry-After")
                if retry_after:
                    try:
                        delay = max(delay, float(retry_after))
                    except ValueError:
                        pass
            log.warning(
                "openai.embeddings.retry",
                attempt=attempt,
                max_attempts=self._max_retries,
                delay_seconds=round(delay, 2),
                error=last_error,
            )
            await asyncio.sleep(delay + random.uniform(0, 0.25))
            delay = min(delay * 2, 20.0)
        raise EmbeddingError(
            "OpenAI embeddings request failed after retries", details={"error": last_error}
        )
