"""Deterministic identifier derivation.

The hub spans two datastores. Rather than storing a cross-reference table we
make identifiers *derivable*:

* ``document_id = uuid5(ECH_NAMESPACE, "<source_system>:<external_id>")``
* ``chunk_id    = uuid5(document_id, "chunk:<index>")``
* ``entity_key  = "<EntityType>:<normalized_name>"``

The same source object therefore always resolves to the same Postgres row and
the same Neo4j node, which is what makes idempotent re-ingestion and
cross-store joins trivial.
"""

from __future__ import annotations

import re
import unicodedata
import uuid

ECH_NAMESPACE = uuid.UUID("6f1c2a7e-9b3d-4c8e-8e1a-2d5b7c9e4f10")

_WS_RE = re.compile(r"\s+")
_EDGE_PUNCT_RE = re.compile(r"^[\W_]+|[\W_]+$")


def document_id(source_system: str, external_id: str) -> uuid.UUID:
    """Stable UUID for a source object."""
    return uuid.uuid5(ECH_NAMESPACE, f"{source_system.strip().lower()}:{external_id.strip()}")


def chunk_id(doc_id: uuid.UUID, chunk_index: int) -> uuid.UUID:
    """Stable UUID for the n-th chunk of a document."""
    return uuid.uuid5(doc_id, f"chunk:{chunk_index}")


def normalize_entity_name(name: str) -> str:
    """Canonical form used for entity de-duplication across documents."""
    folded = unicodedata.normalize("NFKC", name).casefold()
    folded = _WS_RE.sub(" ", folded).strip()
    return _EDGE_PUNCT_RE.sub("", folded)


def entity_key(entity_type: str, name: str) -> str:
    """Single-property key for the Neo4j uniqueness constraint."""
    return f"{entity_type}:{normalize_entity_name(name)}"


def new_run_id() -> uuid.UUID:
    return uuid.uuid4()
