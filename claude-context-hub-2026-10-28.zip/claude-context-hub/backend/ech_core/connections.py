"""Connection settings saved from the Connectors page, shared by both services.

The ingestion service writes them (``ingestion_service/connectors/connections.py``); both services
apply them on top of the environment. Plain values are stored as JSON and credentials Fernet-encrypted
with ECH_SECRETS_KEY, or with a key generated once into ECH_STATE_DIR, which both containers mount.
"""

from __future__ import annotations

import asyncio
import json
import os
import time
from pathlib import Path
from typing import Any

from cryptography.fernet import Fernet, InvalidToken
from pydantic import SecretStr

from ech_core.config import Settings
from ech_core.exceptions import InvalidRequestError
from ech_core.logging import get_logger
from ech_core.repositories.connector_settings_repository import ConnectorSettingsRepository

log = get_logger(__name__)


class SecretBox:
    """Fernet encryption for saved credentials; the key comes from ECH_SECRETS_KEY or is generated once into state_dir."""

    def __init__(self, settings: Settings) -> None:
        configured = settings.secrets_key.get_secret_value().strip() if settings.secrets_key else ""
        key = configured.encode() if configured else self._load_or_create(settings.state_dir)
        self._fernet: Fernet | None = None
        if key:
            try:
                self._fernet = Fernet(key)
            except ValueError as exc:
                log.warning("secrets.key_invalid", error=str(exc))

    @staticmethod
    def _load_or_create(state_dir: Path) -> bytes | None:
        path = state_dir / "secrets.key"
        try:
            if path.is_file():
                return path.read_bytes().strip()
            state_dir.mkdir(parents=True, exist_ok=True)
            key = Fernet.generate_key()
            try:
                fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            except FileExistsError:
                return path.read_bytes().strip()
            with os.fdopen(fd, "wb") as handle:
                handle.write(key)
            log.info("secrets.key_created", path=str(path))
            return key
        except OSError as exc:
            log.warning("secrets.key_unavailable", path=str(path), error=str(exc))
            return None

    @property
    def available(self) -> bool:
        return self._fernet is not None

    def seal(self, values: dict[str, str]) -> bytes | None:
        if not values:
            return None
        if self._fernet is None:
            raise InvalidRequestError("No key to encrypt credentials: set ECH_SECRETS_KEY or make ECH_STATE_DIR writable")
        return self._fernet.encrypt(json.dumps(values).encode())

    def open(self, blob: bytes | None) -> dict[str, str]:
        if not blob or self._fernet is None:
            return {}
        try:
            data = json.loads(self._fernet.decrypt(bytes(blob)))
        except (InvalidToken, ValueError):
            log.warning("secrets.unreadable", hint="the key changed since these credentials were saved")
            return {}
        return {str(k): str(v) for k, v in data.items()} if isinstance(data, dict) else {}


def apply_saved(base: Settings, values: dict[str, Any], secrets: dict[str, str]) -> Settings:
    """The environment's settings with saved values and credentials laid over them; unknown names are ignored."""
    known = Settings.model_fields
    update: dict[str, Any] = {k: v for k, v in values.items() if k in known}
    update.update({k: SecretStr(v) for k, v in secrets.items() if k in known})
    return base.model_copy(update=update)


class SavedConnections:
    """Read side for a service that does not edit connections: every saved connection applied, cached briefly."""

    def __init__(self, settings: Settings, repo: ConnectorSettingsRepository, box: SecretBox, ttl_seconds: float = 10.0) -> None:
        self._base = settings
        self._repo = repo
        self._box = box
        self._ttl = ttl_seconds
        self._cached: Settings | None = None
        self._loaded_at = 0.0
        self._lock = asyncio.Lock()

    async def settings(self) -> Settings:
        if self._fresh():
            return self.current()
        async with self._lock:
            if self._fresh():
                return self.current()
            try:
                rows = await self._repo.all()
            except Exception as exc:  # noqa: BLE001 - saved connections are an overlay; the environment still works
                log.warning("connections.saved_unreadable", error=str(exc))
                return self.current()
            values: dict[str, Any] = {}
            secrets: dict[str, str] = {}
            for row in rows:
                values.update(dict(row["settings"] or {}))
                secrets.update(self._box.open(row["secrets"]))
            self._cached = apply_saved(self._base, values, secrets)
            self._loaded_at = time.monotonic()
            return self._cached

    def current(self) -> Settings:
        """The last settings read, without touching the database; the environment before the first read."""
        return self._cached or self._base

    def _fresh(self) -> bool:
        return self._cached is not None and time.monotonic() - self._loaded_at < self._ttl
