"""The graph a crawl builds in memory before it is written to Neo4j in one transaction.

Every node carries the umbrella label ``:RepoGraph`` plus one kind label (``:DataTable``,
``:Stage``, ...), a unique ``node_key`` (``<repo>|<kind>|<name>``) and the ``repo`` it came from,
so one repository's subgraph can be replaced or removed without touching anything else.
Every edge records how it was established (``methods``: declared in config, parsed from SQL or
code, or inferred from a convention) and the files that are its evidence.
"""

from __future__ import annotations

import json
from collections import Counter
from dataclasses import dataclass, field
from typing import Any

# kind -> Neo4j label (whitelisted: labels cannot be query parameters)
KIND_LABELS: dict[str, str] = {
    "repository": "Repository",
    "file": "RepoFile",
    "symbol": "CodeSymbol",
    "pipeline": "Pipeline",
    "source_system": "SourceSystem",
    "source": "DataSource",
    "table": "DataTable",
    "column": "DataColumn",
    "check": "QualityCheck",
    "storage_integration": "StorageIntegration",
    "external_volume": "ExternalVolume",
    "stage": "Stage",
    "file_format": "FileFormat",
    "s3_location": "S3Location",
    "ci_stage": "CiStage",
    "alert": "Alert",
}

REL_TYPES: frozenset[str] = frozenset(
    {
        "CONTAINS",  # repository -> file
        "DEFINES",  # repository -> pipeline
        "INGESTS",  # pipeline -> source
        "BUILDS",  # pipeline -> table
        "FROM_SYSTEM",  # source -> source_system
        "LANDS_IN",  # source -> stage
        "READS_FROM",  # stage -> s3_location
        "ALLOWS",  # storage_integration -> s3_location
        "WRITES_TO",  # external_volume -> s3_location
        "USES",  # stage -> storage_integration | file_format
        "LOADED_FROM",  # bronze table -> source
        "DERIVED_FROM",  # table -> table, column -> column
        "STORED_ON",  # iceberg table -> external_volume
        "HAS_COLUMN",  # table -> column
        "DEFINED_IN",  # anything -> file
        "CHECKS",  # check -> table
        "IMPORTS",  # file -> file
        "DECLARES",  # file -> symbol
        "READS",  # code file -> config/sql file it loads
        "TESTS",  # test file -> code file
        "NEXT",  # ci_stage -> ci_stage
        "MONITORS",  # alert -> pipeline
        "DOCUMENTS",  # doc file -> table
    }
)


@dataclass
class GNode:
    key: str
    kind: str
    name: str
    props: dict[str, Any] = field(default_factory=dict)


@dataclass
class GEdge:
    src: str
    dst: str
    type: str
    methods: set[str] = field(default_factory=set)
    evidence: set[str] = field(default_factory=set)
    props: dict[str, Any] = field(default_factory=dict)


def _neo_value(value: Any) -> Any:
    """Neo4j properties are primitives or homogeneous lists of primitives."""
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, (list, tuple, set)):
        items = list(value)
        if all(isinstance(v, str) for v in items):
            return items
        if all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in items):
            return items
        return [json.dumps(v, default=str) if not isinstance(v, str) else v for v in items]
    return json.dumps(value, default=str)


class GraphBuild:
    def __init__(self, repo: str) -> None:
        self.repo = repo
        self.nodes: dict[str, GNode] = {}
        self.edges: dict[tuple[str, str, str], GEdge] = {}
        self.warnings: list[str] = []

    # ------------------------------------------------------------------ nodes
    def key(self, kind: str, name: str) -> str:
        return f"{self.repo}|{kind}|{name}"

    def node(self, kind: str, name: str, **props: Any) -> str:
        if kind not in KIND_LABELS:
            raise ValueError(f"unknown node kind {kind!r}")
        key = self.key(kind, name)
        clean = {k: v for k, v in props.items() if v is not None and v != "" and v != []}
        existing = self.nodes.get(key)
        if existing is None:
            self.nodes[key] = GNode(key=key, kind=kind, name=name, props=clean)
        else:
            for k, v in clean.items():
                existing.props.setdefault(k, v)
        return key

    def has(self, kind: str, name: str) -> bool:
        return self.key(kind, name) in self.nodes

    def get(self, kind: str, name: str) -> GNode | None:
        return self.nodes.get(self.key(kind, name))

    def of_kind(self, kind: str) -> list[GNode]:
        return [n for n in self.nodes.values() if n.kind == kind]

    # ------------------------------------------------------------------ edges
    def edge(self, src: str, dst: str, rel: str, *, method: str, evidence: str | None = None, **props: Any) -> None:
        if rel not in REL_TYPES:
            raise ValueError(f"unknown relationship {rel!r}")
        if src not in self.nodes or dst not in self.nodes or src == dst:
            return
        key = (src, dst, rel)
        edge = self.edges.get(key)
        if edge is None:
            edge = GEdge(src=src, dst=dst, type=rel)
            self.edges[key] = edge
        edge.methods.add(method)
        if evidence:
            edge.evidence.add(evidence)
        for k, v in props.items():
            if v is not None:
                edge.props.setdefault(k, v)

    def warn(self, message: str) -> None:
        if message not in self.warnings and len(self.warnings) < 200:
            self.warnings.append(message)

    # ------------------------------------------------------------------ output
    def stats(self) -> dict[str, Any]:
        return {
            "nodes": len(self.nodes),
            "edges": len(self.edges),
            "nodes_by_kind": dict(Counter(n.kind for n in self.nodes.values()).most_common()),
            "edges_by_type": dict(Counter(e.type for e in self.edges.values()).most_common()),
            "edges_by_method": dict(Counter(m for e in self.edges.values() for m in e.methods).most_common()),
        }

    def node_rows(self) -> dict[str, list[dict[str, Any]]]:
        rows: dict[str, list[dict[str, Any]]] = {}
        for n in self.nodes.values():
            props = {k: _neo_value(v) for k, v in n.props.items()}
            props.update(repo=self.repo, kind=n.kind, name=n.name)
            props.setdefault("display", n.name)
            rows.setdefault(KIND_LABELS[n.kind], []).append({"key": n.key, "props": props})
        return rows

    def edge_rows(self) -> dict[str, list[dict[str, Any]]]:
        rows: dict[str, list[dict[str, Any]]] = {}
        for e in self.edges.values():
            props = {k: _neo_value(v) for k, v in e.props.items()}
            props["methods"] = sorted(e.methods)
            props["evidence"] = sorted(e.evidence)[:20]
            props["repo"] = self.repo
            rows.setdefault(e.type, []).append({"src": e.src, "dst": e.dst, "props": props})
        return rows
