"""SQL understanding for the repo crawler: templating, Snowflake DDL, table references, column lineage.

Repositories template their SQL (Jinja macros such as ``{{ bronze('A_CLAIM') }}``, dbt's
``{{ ref('x') }}``, ``{{ database }}.SCHEMA.TABLE``) and build DDL inside Python f-strings. Both are
normalised to plain Snowflake SQL first; sqlglot then parses SELECTs for table references and
column-level lineage, while account objects (storage integrations, external volumes, stages, file
formats, Iceberg tables, COPY INTO) are read with patterns because they are rarely parseable.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

import sqlglot
from sqlglot import exp
from sqlglot.lineage import lineage as sqlglot_lineage

LAYER_NAMES = ("raw", "landing", "bronze", "silver", "gold", "serving", "staging", "mart", "marts", "control", "ingestion")

_JINJA_EXPR = re.compile(r"\{\{\s*(\w+)\s*(?:\((.*?)\))?\s*\}\}", re.S)
_JINJA_BLOCK = re.compile(r"\{%.*?%\}|\{#.*?#\}", re.S)
_PYFORMAT = re.compile(r"%\((\w+)\)s")
_ARG = re.compile(r"'[^']*'|\"[^\"]*\"|[^,]+")
_LINE_COMMENT = re.compile(r"--[^\n]*")
# A Python implicit string concatenation split over lines: "...abc "\n    f"def..."
_PY_CONCAT = re.compile(r"[\"']\s*\n\s*[fFrRbB]{0,2}[\"']")
# An identifier that may contain f-string / Jinja placeholders: {sql.database}.INGESTION.LANDING
IDENT = r"((?:\{[^}\n]*\}+|[^\s(;,'\"])+)"

_DDL = {
    "storage_integration": re.compile(
        r"create\s+(?:or\s+replace\s+)?storage\s+integration\s+(?:if\s+not\s+exists\s+)?" + IDENT, re.I
    ),
    "external_volume": re.compile(r"create\s+(?:or\s+replace\s+)?external\s+volume\s+(?:if\s+not\s+exists\s+)?" + IDENT, re.I),
    "stage": re.compile(r"create\s+(?:or\s+replace\s+)?(?:temporary\s+)?stage\s+(?:if\s+not\s+exists\s+)?" + IDENT, re.I),
    "file_format": re.compile(r"create\s+(?:or\s+replace\s+)?file\s+format\s+(?:if\s+not\s+exists\s+)?" + IDENT, re.I),
    "iceberg_table": re.compile(r"create\s+(?:or\s+replace\s+)?iceberg\s+table\s+(?:if\s+not\s+exists\s+)?" + IDENT, re.I),
    "table": re.compile(
        r"create\s+(?:or\s+replace\s+)?(?:transient\s+|temporary\s+|local\s+)?table\s+(?:if\s+not\s+exists\s+)?" + IDENT, re.I
    ),
    "view": re.compile(
        r"create\s+(?:or\s+replace\s+)?(?:(secure)\s+)?(?:materialized\s+)?view\s+(?:if\s+not\s+exists\s+)?" + IDENT, re.I
    ),
    "copy": re.compile(r"copy\s+into\s+" + IDENT, re.I),
}
_NEXT_STATEMENT = re.compile(r";|\bcreate\s+(?:or\s+replace\s+)?\w|\bcopy\s+into\b|\bdesc(?:ribe)?\s+\w", re.I)
_PROPS = {
    "storage_provider": re.compile(r"storage_provider\s*=\s*'(\w+)'", re.I),
    "role_arn": re.compile(r"storage_aws_role_arn\s*=\s*'([^']+)'", re.I),
    "allowed_locations": re.compile(r"storage_allowed_locations\s*=\s*\(([^)]*)\)", re.I),
    "base_url": re.compile(r"storage_base_url\s*=\s*'([^']+)'", re.I),
    "url": re.compile(r"\burl\s*=\s*'([^']+)'", re.I),
    "storage_integration": re.compile(r"storage_integration\s*=\s*" + IDENT, re.I),
    "type": re.compile(r"\btype\s*=\s*'?(\w+)", re.I),
    "skip_header": re.compile(r"skip_header\s*=\s*(\d+)", re.I),
    "catalog": re.compile(r"\bcatalog\s*=\s*'(\w+)'", re.I),
    "external_volume": re.compile(r"external_volume\s*=\s*'?" + IDENT, re.I),
    "base_location": re.compile(r"base_location\s*=\s*'([^']+)'", re.I),
    "encryption": re.compile(r"encryption\s*=\s*\(\s*type\s*=\s*'(\w+)'", re.I),
    "stage_ref": re.compile(r"@" + IDENT),
    "format_name": re.compile(r"format_name\s*=\s*" + IDENT, re.I),
    "load_mode": re.compile(r"load_mode\s*=\s*(\w+)", re.I),
    "on_error": re.compile(r"on_error\s*=\s*'?(\w+)", re.I),
}
_S3 = re.compile(r"s3://[^'\"\s)]+")
_IDENT_PROPS = ("storage_integration", "external_volume", "stage_ref", "format_name")


# --------------------------------------------------------------------------- identifiers
def clean_ident(raw: str) -> tuple[str, bool]:
    """``{sql.database}.INGESTION.LANDING`` -> (``INGESTION.LANDING``, templated=True).

    Placeholder parts are dropped; quotes stripped; upper-cased. The result is the name the object
    has in every environment (schema.object for schema objects, the bare name for account objects).
    """
    text = raw.strip().strip("'\"").rstrip(".")
    templated = "{" in text or "%(" in text
    parts: list[str] = []
    for part in re.split(r"\.(?![^{]*\})", text):
        part = part.strip().strip('"')
        if not part or "{" in part or "}" in part or "%(" in part:
            continue
        parts.append(part.upper())
    return ".".join(parts), templated


def layer_literal(raw: str) -> str | None:
    """The layer a templated target names: ``{self.table('BRONZE', source['id'])}`` -> ``bronze``."""
    for single, double in re.findall(r"'(\w+)'|\"(\w+)\"", raw):
        word = (single or double).lower()
        if word in LAYER_NAMES:
            return word
    return None


# --------------------------------------------------------------------------- templating
def _args(raw: str | None) -> list[str]:
    return [a.strip().strip("'\"") for a in _ARG.findall(raw or "") if a.strip()]


def sql_params(text: str) -> list[str]:
    """The pyformat parameters (``%(as_of)s``) a statement expects at run time."""
    return sorted(set(_PYFORMAT.findall(text)))


def normalize_sql(text: str, layers: tuple[str, ...] = LAYER_NAMES) -> str:
    """Turn templated SQL into plain Snowflake SQL that sqlglot can parse."""
    layer_set = {name.lower() for name in layers}

    def expr(match: re.Match[str]) -> str:
        fn, raw = match.group(1), match.group(2)
        args = _args(raw)
        low = fn.lower()
        if low in layer_set and args:
            return f"{fn.upper()}.{args[0].upper()}"
        if low == "ref" and args:
            return args[-1].upper()
        if low == "source" and len(args) >= 2:
            return f"{args[0].upper()}.{args[1].upper()}"
        if raw is None:
            return f"__{fn.upper()}__"
        columns = [a for a in args if re.fullmatch(r"[A-Za-z_]\w*\.[A-Za-z_]\w*", a)]
        if columns:  # a key or hash macro over columns keeps their lineage
            return "MD5(CONCAT(" + ",".join(columns) + "))"
        return "NULL"

    out = _JINJA_BLOCK.sub("", text)
    out = _JINJA_EXPR.sub(expr, out)
    out = re.sub(r"__\w+__\.", "", out)
    out = _PYFORMAT.sub(lambda m: f"'{m.group(1)}'", out)
    return out


def split_statements(text: str) -> list[str]:
    body = _LINE_COMMENT.sub("", text)
    return [s.strip() for s in body.split(";") if s.strip()]


def join_python_strings(text: str) -> str:
    return _PY_CONCAT.sub("", text)


# --------------------------------------------------------------------------- DDL objects
@dataclass
class DdlObject:
    kind: str  # storage_integration | external_volume | stage | file_format | iceberg_table | table | view | copy
    name: str
    templated: bool
    raw_name: str
    props: dict[str, Any] = field(default_factory=dict)
    body: str = ""


def _body_after(text: str, start: int, limit: int = 2500) -> str:
    rest = text[start : start + limit]
    stop = _NEXT_STATEMENT.search(rest)
    return rest[: stop.start()] if stop else rest


def ddl_objects(text: str) -> list[DdlObject]:
    """Account and schema objects created (or loaded) by a SQL file or a Python module."""
    found: list[DdlObject] = []
    for kind, pattern in _DDL.items():
        for match in pattern.finditer(text):
            raw = match.group(match.lastindex or 1)
            name, templated = clean_ident(raw)
            body = _body_after(text, match.end())
            props: dict[str, Any] = {}
            for prop, rx in _PROPS.items():
                hit = rx.search(body)
                if not hit:
                    continue
                value = hit.group(1)
                if prop in _IDENT_PROPS:
                    cleaned, was_templated = clean_ident(value)
                    props[prop] = cleaned
                    if was_templated:
                        props[f"{prop}_templated"] = True
                elif prop == "allowed_locations":
                    props[prop] = _S3.findall(value)
                else:
                    props[prop] = value
            if kind == "view" and match.group(1):
                props["secure"] = True
            if kind in ("iceberg_table", "copy"):
                props["layer"] = layer_literal(raw)
            found.append(DdlObject(kind=kind, name=name, templated=templated, raw_name=raw, props=props, body=body))
    return found


# --------------------------------------------------------------------------- parsing
def parse(sql: str) -> exp.Expression | None:
    try:
        tree = sqlglot.parse_one(sql, dialect="snowflake")
        return tree if isinstance(tree, exp.Expression) else None
    except Exception:  # noqa: BLE001 - unparseable SQL is reported by the caller
        return None


def cte_names(tree: exp.Expression) -> set[str]:
    return {cte.alias_or_name.upper() for cte in tree.find_all(exp.CTE)}


def table_refs(tree: exp.Expression) -> set[str]:
    """Tables a statement reads, as SCHEMA.NAME (or NAME), excluding its own CTEs."""
    ctes = cte_names(tree)
    refs: set[str] = set()
    for table in tree.find_all(exp.Table):
        name = table.name.upper()
        if not name:
            continue
        db = (table.db or "").upper()
        if not db and name in ctes:
            continue
        refs.add(f"{db}.{name}" if db else name)
    return refs


def output_columns(tree: exp.Expression) -> list[str]:
    select = tree if isinstance(tree, exp.Query) else tree.find(exp.Query)
    if select is None:
        return []
    names: list[str] = []
    for projection in select.selects:
        name = projection.alias_or_name
        if name and name != "*":
            names.append(name.upper())
    return names


def column_lineage(
    tree: exp.Expression, columns: list[str], schema: dict[str, dict[str, dict[str, str]]]
) -> tuple[dict[str, list[tuple[str, str]]], list[str]]:
    """For each output column, the (SCHEMA.TABLE, COLUMN) leaves it is computed from.

    Returns the mapping and the columns that could not be traced (constants map to []).
    """
    traced: dict[str, list[tuple[str, str]]] = {}
    failed: list[str] = []
    for column in columns:
        node = None
        # With the contract schema first (resolves unqualified columns); without it when the contract
        # misses columns the code adds at deploy time (alias-qualified SQL still traces).
        for attempt in (schema, {}):
            try:
                node = sqlglot_lineage(column, tree, attempt, dialect="snowflake")
                break
            except Exception:  # noqa: BLE001, S112 - one bad column must not stop the file
                continue
        if node is None:
            failed.append(column)
            continue
        leaves: set[tuple[str, str]] = set()
        for n in node.walk():
            if n.downstream or not isinstance(n.source, exp.Table):
                continue
            table = n.source
            name = table.name.upper()
            db = (table.db or "").upper()
            leaves.add((f"{db}.{name}" if db else name, n.name.split(".")[-1].upper()))
        traced[column] = sorted(leaves)
    return traced, failed


def create_table_columns(tree: exp.Expression) -> list[tuple[str, str]]:
    """(name, type) pairs of a parsed CREATE TABLE."""
    schema = tree.find(exp.Schema)
    if schema is None:
        return []
    out: list[tuple[str, str]] = []
    for col in schema.expressions:
        if isinstance(col, exp.ColumnDef):
            kind = col.args.get("kind")
            out.append((col.name.upper(), kind.sql(dialect="snowflake").upper() if kind else ""))
    return out
