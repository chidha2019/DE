"""Turn a repository's files into a typed knowledge graph of its data pipelines.

What it understands (each fact is recorded with how it was established):

* **declared** - source contracts (``sources:`` YAML), model contracts (``models:``), asset
  dependencies (``assets:`` with ``depends_on``), a pipeline definition (``pipeline_id``),
  Prometheus alert rules and CI stages.
* **parsed** - SQL: Jinja-templated SELECTs per layer folder (``sql/silver/dim_party.sql``) give
  table and column lineage through sqlglot; bootstrap SQL gives storage integrations, external
  volumes, native tables and (secure) views; check SQL gives named quality checks per table.
  Python: imports, classes and functions, files a module reads, and Snowflake DDL built in
  f-strings (stages, file formats, Iceberg tables, COPY INTO).
* **inferred** - conventions that tie those together, e.g. every Bronze table is loaded through
  the single landing stage a ``COPY INTO <BRONZE>`` uses, and every layer table created by an
  Iceberg template is stored on the repository's external volume.
"""

from __future__ import annotations

import ast
import fnmatch
import re
from dataclasses import dataclass, field
from pathlib import PurePosixPath
from typing import Any

import yaml

from ech_core.repo_graph import sql_text as st
from ech_core.repo_graph.model import GraphBuild

TEXT_EXTENSIONS = {
    ".sql", ".py", ".yml", ".yaml", ".json", ".md", ".rst", ".toml", ".cfg", ".ini", ".txt", ".sh",
    ".tf", ".example", ".sample", ".template", ".in", ".j2", ".jinja",
}
TEXT_NAMES = {"Jenkinsfile", "Dockerfile", "Makefile", "Procfile", ".gitlab-ci.yml"}
LANGUAGES = {".sql": "sql", ".py": "python", ".yml": "yaml", ".yaml": "yaml", ".json": "json", ".md": "markdown", ".sh": "shell", ".tf": "terraform", ".toml": "toml"}
MODEL_LAYERS = ("bronze", "silver", "gold", "serving", "staging", "mart", "marts", "raw", "intermediate")
_MODEL_PATH = re.compile(r"(?:^|/)(?:sql|models|transformations?|transform)/(?:[\w-]+/)*?(?P<layer>[a-z_]+)/(?P<name>[\w]+)\.sql$", re.I)
_CHECK_BRANCH = re.compile(r"select\s+'([^']+)'\s+(?:as\s+)?check_name\b(.*?)(?=\bunion\s+all\b|\Z)", re.I | re.S)
_LAYER_REF = re.compile(r"\b(BRONZE|SILVER|GOLD|SERVING|CONTROL|STAGING|RAW|MART|MARTS)\.([A-Z0-9_]+)\b", re.I)
_JENKINS_STAGE = re.compile(r"""stage\(\s*['"]([^'"]+)['"]\s*\)""")
_ENV_LINE = re.compile(r"^\s*([A-Z][A-Z0-9_]*)\s*=\s*(.*)$", re.M)
# Only names of objects from example env files; never a credential, even a placeholder one.
_SAFE_ENV_VALUES = {
    "SNOWFLAKE_DATABASE", "SNOWFLAKE_WAREHOUSE", "SNOWFLAKE_ROLE", "SNOWFLAKE_EXTERNAL_VOLUME", "PIPELINE_SCHEDULE",
    "S3_MANIFEST_KEY", "ENVIRONMENT", "K8S_NAMESPACE", "AWS_REGION",
}
_PY_VOLUME_DEFAULT = re.compile(r"external_volume\s*=\s*[\"']([A-Za-z_][\w$]*)[\"']")
_WORD = re.compile(r"[A-Z][A-Z0-9_]{3,}")
_RESERVED_PROPS = {"display", "mode", "schedule", "layers", "repo", "kind", "name"}


@dataclass(frozen=True)
class RepoInfo:
    full_name: str
    ref: str
    sha: str | None = None
    url: str = ""
    description: str | None = None
    default_branch: str | None = None
    languages: dict[str, int] = field(default_factory=dict)


def is_text_path(path: str) -> bool:
    p = PurePosixPath(path)
    return p.name in TEXT_NAMES or p.suffix.lower() in TEXT_EXTENSIONS


def file_role(path: str) -> str:
    p = path.lower()
    name = PurePosixPath(p).name
    if p.startswith("tests/") or "/tests/" in p or name.startswith("test_") or name.endswith("_test.py"):
        return "test"
    if name == "jenkinsfile" or p.startswith(".github/workflows/") or name in (".gitlab-ci.yml", "azure-pipelines.yml"):
        return "ci"
    if name == "dockerfile" or name.endswith(".dockerfile"):
        return "container"
    if p.endswith(".sql"):
        return "sql"
    if p.endswith(".py"):
        return "code"
    if p.endswith((".md", ".rst")):
        return "doc"
    if p.startswith("observability/") or "alert" in name or "prometheus" in name or "otel" in name:
        return "observability"
    if p.startswith(("deploy/", "infra/", "k8s/", "helm/", "terraform/")) or p.endswith(".tf"):
        return "deploy"
    if p.endswith((".yml", ".yaml", ".json", ".toml", ".ini", ".cfg")) or ".env" in name:
        return "config"
    return "other"


def _t(layer: str, name: str) -> str:
    return f"{layer.upper()}.{name.upper()}"


class RepoGraphExtractor:
    def __init__(self, info: RepoInfo, files: dict[str, str], sizes: dict[str, int] | None = None) -> None:
        self.info = info
        self.files = files
        self.sizes = sizes or {}
        self.g = GraphBuild(info.full_name)
        self.repo_key = ""
        self.sources: list[tuple[str, dict[str, Any]]] = []  # (file, source)
        self.models: list[tuple[str, dict[str, Any]]] = []
        self.assets: list[tuple[str, dict[str, Any]]] = []
        self.pipelines: list[tuple[str, dict[str, Any]]] = []
        self.source_mode: str | None = None
        self.env_values: dict[str, str] = {}
        self.ddl: list[tuple[str, st.DdlObject]] = []
        self.py_volume_defaults: set[str] = set()
        self.model_sql: list[tuple[str, str, str]] = []  # (path, layer, name)
        self.check_sql: list[str] = []
        self.bronze_layer = "BRONZE"
        self.lineage_stats = {"model_columns": 0, "traced": 0, "constant": 0, "failed": 0}
        self.declared_vs_parsed: list[str] = []
        self._modules: dict[str, str] | None = None

    # ================================================================== entry point
    def build(self) -> GraphBuild:
        self._repository_and_files()
        for path, text in self.files.items():
            low = path.lower()
            if low.endswith((".yml", ".yaml")):
                self._yaml(path, text)
            if ".env" in low and low.endswith((".example", ".sample", ".template")):
                self._env_example(path, text)
        for path, text in self.files.items():
            if path.lower().endswith(".py"):
                self._python(path, text)
            elif path.lower().endswith(".sql"):
                self._sql_file(path, text)
        self._pick_bronze_layer()
        self._source_tables()
        self._model_tables()
        self._control_tables_and_views()
        self._infrastructure()
        self._declared_lineage()
        self._parsed_model_lineage()
        self._checks()
        self._pipeline()
        self._ci()
        self._docs()
        return self.g

    # ================================================================== repository + files
    def _repository_and_files(self) -> None:
        info = self.info
        self.repo_key = self.g.node(
            "repository",
            info.full_name,
            display=info.full_name,
            ref=info.ref,
            sha=info.sha,
            url=info.url,
            description=info.description,
            default_branch=info.default_branch,
            languages=[f"{k}:{v}" for k, v in sorted(info.languages.items(), key=lambda kv: -kv[1])],
            files=len(self.files),
        )
        for path, text in self.files.items():
            p = PurePosixPath(path)
            props: dict[str, Any] = {
                "display": p.name,
                "path": path,
                "folder": str(p.parent) if str(p.parent) != "." else "",
                "role": file_role(path),
                "language": LANGUAGES.get(p.suffix.lower(), "text" if p.suffix else p.name.lower()),
                "size": self.sizes.get(path, len(text.encode("utf-8", errors="ignore"))),
                "lines": text.count("\n") + 1,
                "url": f"https://github.com/{info.full_name}/blob/{info.ref}/{path}",
            }
            if p.suffix.lower() in (".md", ".rst"):
                heading = re.search(r"^#\s+(.+)$", text, re.M)
                if heading:
                    props["title"] = heading.group(1).strip()
            key = self.g.node("file", path, **props)
            self.g.edge(self.repo_key, key, "CONTAINS", method="declared")

    def _file(self, path: str) -> str:
        return self.g.key("file", path)

    # ================================================================== YAML
    def _yaml(self, path: str, text: str) -> None:
        try:
            docs = [d for d in yaml.safe_load_all(text) if d is not None]
        except yaml.YAMLError as exc:
            self.g.warn(f"{path}: YAML not parseable ({str(exc).splitlines()[0]})")
            return
        for doc in docs:
            if not isinstance(doc, dict):
                continue
            if isinstance(doc.get("sources"), list) and any(isinstance(s, dict) and "columns" in s for s in doc["sources"]):
                self.source_mode = self.source_mode or doc.get("mode")
                self.sources += [(path, s) for s in doc["sources"] if isinstance(s, dict) and (s.get("id") or s.get("name"))]
            if isinstance(doc.get("models"), list):
                self.models += [(path, m) for m in doc["models"] if isinstance(m, dict) and m.get("name")]
            if isinstance(doc.get("assets"), list):
                self.assets += [(path, a) for a in doc["assets"] if isinstance(a, dict) and a.get("id")]
            if doc.get("pipeline_id"):
                self.pipelines.append((path, doc))
            if isinstance(doc.get("groups"), list):
                self._alerts(path, doc["groups"])
            if path.startswith(".github/workflows/") and isinstance(doc.get("jobs"), dict):
                self._workflow_jobs(path, doc["jobs"])

    def _env_example(self, path: str, text: str) -> None:
        keys: list[str] = []
        for key, value in _ENV_LINE.findall(text):
            keys.append(key)
            if key in _SAFE_ENV_VALUES and value.strip() and "REPLACE" not in value:
                self.env_values[key] = value.strip().strip("'\"")
        if keys:
            self.g.nodes[self._file(path)].props["env_keys"] = keys

    def _alerts(self, path: str, groups: list[Any]) -> None:
        for group in groups:
            if not isinstance(group, dict):
                continue
            for rule in group.get("rules") or []:
                if not isinstance(rule, dict) or not rule.get("alert"):
                    continue
                labels = rule.get("labels") or {}
                notes = rule.get("annotations") or {}
                key = self.g.node(
                    "alert",
                    str(rule["alert"]),
                    group=group.get("name"),
                    expr=str(rule.get("expr", "")).strip(),
                    duration=rule.get("for"),
                    severity=labels.get("severity"),
                    owner=labels.get("owner"),
                    summary=notes.get("summary"),
                    runbook=notes.get("runbook"),
                )
                self.g.edge(key, self._file(path), "DEFINED_IN", method="declared", evidence=path)

    def _workflow_jobs(self, path: str, jobs: dict[str, Any]) -> None:
        for name, job in jobs.items():
            key = self.g.node("ci_stage", f"{path}:{name}", display=str((job or {}).get("name") or name), tool="github-actions")
            self.g.edge(key, self._file(path), "DEFINED_IN", method="declared", evidence=path)
            needs = (job or {}).get("needs") or []
            for need in [needs] if isinstance(needs, str) else needs:
                self.g.edge(self.g.key("ci_stage", f"{path}:{need}"), key, "NEXT", method="declared", evidence=path)

    # ================================================================== Python
    def _python(self, path: str, text: str) -> None:
        joined = st.join_python_strings(text)
        for obj in st.ddl_objects(joined):
            self.ddl.append((path, obj))
        self.py_volume_defaults.update(_PY_VOLUME_DEFAULT.findall(text))
        try:
            tree = ast.parse(text)
        except SyntaxError as exc:
            self.g.warn(f"{path}: Python not parseable (line {exc.lineno})")
            return
        file_key = self._file(path)
        module = path[:-3].replace("/", ".").removesuffix(".__init__")
        doc = ast.get_docstring(tree)
        if doc:
            self.g.nodes[file_key].props["summary"] = doc.strip().splitlines()[0][:200]
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                self._symbol(path, file_key, module, node, "class" if isinstance(node, ast.ClassDef) else "function")
                if isinstance(node, ast.ClassDef):
                    for child in node.body:
                        if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)) and not child.name.startswith("__"):
                            self._symbol(path, file_key, f"{module}.{node.name}", child, "method")
        module_paths = self._module_paths()
        package = module.rsplit(".", 1)[0] if "." in module else ""
        is_test = file_role(path) == "test"
        for node_ in ast.walk(tree):
            targets: list[str] = []
            if isinstance(node_, ast.Import):
                targets = [a.name for a in node_.names]
            elif isinstance(node_, ast.ImportFrom):
                base = node_.module or ""
                if node_.level:
                    parts = package.split(".") if package else []
                    parts = parts[: len(parts) - (node_.level - 1)] if node_.level > 1 else parts
                    base = ".".join([*parts, base] if base else parts)
                targets = [base] + [f"{base}.{a.name}" for a in node_.names]
            for target in targets:
                hit = module_paths.get(target)
                if hit and hit != path:
                    self.g.edge(file_key, self._file(hit), "IMPORTS", method="parsed", evidence=path)
                    if is_test and file_role(hit) == "code":
                        self.g.edge(file_key, self._file(hit), "TESTS", method="parsed", evidence=path)
            if isinstance(node_, ast.Constant) and isinstance(node_.value, str):
                self._file_reference(path, node_.value)
            elif isinstance(node_, ast.JoinedStr):
                pattern = "".join(v.value if isinstance(v, ast.Constant) and isinstance(v.value, str) else "*" for v in node_.values)
                if "/" in pattern and "*" in pattern and "." in pattern:
                    self._file_reference(path, pattern, glob=True)

    def _symbol(self, path: str, file_key: str, owner: str, node: ast.FunctionDef | ast.AsyncFunctionDef | ast.ClassDef, kind: str) -> None:
        doc = ast.get_docstring(node)
        key = self.g.node(
            "symbol",
            f"{owner}.{node.name}",
            display=node.name,
            symbol_kind=kind,
            line=node.lineno,
            file=path,
            summary=doc.strip().splitlines()[0][:200] if doc else None,
        )
        self.g.edge(file_key, key, "DECLARES", method="parsed", evidence=path)

    def _module_paths(self) -> dict[str, str]:
        if self._modules is None:
            self._modules = {p[:-3].replace("/", ".").removesuffix(".__init__"): p for p in self.files if p.endswith(".py")}
        return self._modules

    def _file_reference(self, path: str, value: str, *, glob: bool = False) -> None:
        if len(value) > 200 or "\n" in value:
            return
        targets: list[str] = []
        if glob:
            targets = [p for p in self.files if fnmatch.fnmatch(p, value) or fnmatch.fnmatch(p, f"*/{value}")][:40]
        elif value in self.files:
            targets = [value]
        elif re.fullmatch(r"[\w.-]+\.(?:ya?ml|json|sql|toml|csv)", value):
            hits = [p for p in self.files if PurePosixPath(p).name == value]
            targets = hits if len(hits) == 1 else []
        for target in targets:
            if target != path:
                self.g.edge(self._file(path), self._file(target), "READS", method="parsed", evidence=path)

    # ================================================================== SQL files
    def _sql_file(self, path: str, text: str) -> None:
        for obj in st.ddl_objects(text):
            self.ddl.append((path, obj))
        name = PurePosixPath(path).name.lower()
        if re.search(r"check_name", text, re.I) and ("check" in path.lower() or "quality" in name or "test" in path.lower()):
            self.check_sql.append(path)
            return
        match = _MODEL_PATH.search(path)
        if match and match.group("layer").lower() in MODEL_LAYERS:
            if not re.match(r"\s*(?:--[^\n]*\n\s*)*(?:create|insert|merge|copy|grant)\b", text, re.I):
                self.model_sql.append((path, match.group("layer").lower(), match.group("name")))

    # ================================================================== tables
    def _pick_bronze_layer(self) -> None:
        refs = [str(d).upper() for _, a in self.assets for d in a.get("depends_on") or []]
        layers = {r.split(".")[0] for r in refs if "." in r}
        for candidate in ("BRONZE", "RAW", "LANDING", "STAGING"):
            if candidate in layers:
                self.bronze_layer = candidate
                return
        for _, obj in self.ddl:
            if obj.kind == "copy" and obj.props.get("layer"):
                self.bronze_layer = str(obj.props["layer"]).upper()
                return

    def _table(self, fqn: str, **props: Any) -> str:
        layer, _, name = fqn.partition(".")
        return self.g.node(
            "table", fqn, display=name or fqn, layer=layer.lower() if name else None, schema=layer if name else None, table=name or fqn, **props
        )

    def _column(self, table_fqn: str, column: str, *, method: str = "declared", **props: Any) -> str:
        table_key = self.g.key("table", table_fqn)
        key = self.g.node("column", f"{table_fqn}.{column}", display=column, table=table_fqn, column=column, **props)
        self.g.edge(table_key, key, "HAS_COLUMN", method=method)
        return key

    def _source_tables(self) -> None:
        for path, src in self.sources:
            sid = str(src.get("id") or src.get("name")).upper()
            system = src.get("source_system") or (str(src.get("source_path", "")).split("/")[0] or None)
            keys = [str(k).upper() for k in src.get("key") or []]
            columns = [c for c in src.get("columns") or [] if isinstance(c, dict) and c.get("name")]
            source_key = self.g.node(
                "source",
                sid,
                display=sid,
                format=src.get("format", "csv"),
                source_path=src.get("source_path"),
                source_system=system,
                key=keys,
                column_count=len(columns),
                required=[str(c["name"]).upper() for c in columns if c.get("required")],
                headers=[str(c.get("source") or c["name"]) for c in columns],
                mode=self.source_mode,
            )
            self.g.edge(source_key, self._file(path), "DEFINED_IN", method="declared", evidence=path)
            if system:
                sys_key = self.g.node("source_system", str(system), display=str(system))
                self.g.edge(source_key, sys_key, "FROM_SYSTEM", method="declared", evidence=path)
            fqn = f"{self.bronze_layer}.{sid}"
            table_key = self._table(fqn, key=keys, table_type="table", column_count=len(columns), contract=path)
            self.g.edge(table_key, source_key, "LOADED_FROM", method="declared", evidence=path)
            self.g.edge(table_key, self._file(path), "DEFINED_IN", method="declared", evidence=path, role="contract")
            for i, col in enumerate(columns):
                name = str(col["name"]).upper()
                self._column(
                    fqn,
                    name,
                    position=i + 1,
                    type="STRING",
                    source_header=col.get("source"),
                    value_kind=col.get("kind"),
                    required=bool(col.get("required")),
                    is_key=name in keys,
                )

    def _model_tables(self) -> None:
        sql_layers = {name.lower(): layer for _, layer, name in self.model_sql}
        for path, model in self.models:
            name = str(model["name"])
            layer = str(model.get("layer") or sql_layers.get(name.lower()) or "model").lower()
            fqn = _t(layer, name)
            keys = [str(k).upper() for k in model.get("key") or model.get("grain") or []]
            columns = [c for c in model.get("columns") or [] if isinstance(c, dict) and c.get("name")]
            table_key = self._table(fqn, key=keys, table_type="table", column_count=len(columns), contract=path, description=model.get("description"))
            self.g.edge(table_key, self._file(path), "DEFINED_IN", method="declared", evidence=path, role="contract")
            for i, col in enumerate(columns):
                cname = str(col["name"]).upper()
                self._column(fqn, cname, position=i + 1, type=col.get("type") or col.get("data_type"), description=col.get("description"), is_key=cname in keys)
        for path, asset in self.assets:
            fqn = str(asset["id"]).upper()
            table_key = self._table(fqn)
            node = self.g.nodes[table_key]
            for prop, value in (("grain", [str(g).upper() for g in asset.get("grain") or []]), ("owner", asset.get("owner")), ("definition", asset.get("definition"))):
                if value:
                    node.props[prop] = value
            definition = asset.get("definition")
            if isinstance(definition, str) and definition in self.files:
                self.g.edge(table_key, self._file(definition), "DEFINED_IN", method="declared", evidence=path, role="sql")
        for path, layer, name in self.model_sql:
            key = self._table(_t(layer, name), definition=path)
            self.g.edge(key, self._file(path), "DEFINED_IN", method="parsed", evidence=path, role="sql")

    def _control_tables_and_views(self) -> None:
        for path, obj in self.ddl:
            if obj.kind == "table" and "." in obj.name:
                key = self._table(obj.name, table_type="table", definition=path)
                self.g.edge(key, self._file(path), "DEFINED_IN", method="parsed", evidence=path, role="ddl")
                tree = st.parse(st.normalize_sql(f"create table {obj.name} {obj.body}"))
                for i, (cname, ctype) in enumerate(st.create_table_columns(tree) if tree else []):
                    self._column(obj.name, cname, position=i + 1, type=ctype, method="parsed")
            elif obj.kind == "iceberg_table" and "." in obj.name:
                key = self._table(obj.name, table_type="iceberg", catalog=obj.props.get("catalog"), definition=path)
                self.g.edge(key, self._file(path), "DEFINED_IN", method="parsed", evidence=path, role="ddl")
        for path, obj in self.ddl:
            if obj.kind != "view" or not obj.name:
                continue
            key = self._table(obj.name, table_type="secure_view" if obj.props.get("secure") else "view", definition=path)
            self.g.edge(key, self._file(path), "DEFINED_IN", method="parsed", evidence=path, role="ddl")
            body = st.normalize_sql(obj.body)
            start = re.search(r"\bas\s+(select|with)\b", body, re.I)
            if not start:
                continue
            tree = st.parse(body[start.start(1) :])
            if tree is None:
                self.g.warn(f"{path}: view {obj.name} not parseable")
                continue
            self._lineage_from_tree(path, obj.name, tree)

    # ================================================================== infrastructure
    def _s3(self, uri: str, purpose: str) -> str:
        return self.g.node("s3_location", uri, display=uri, purpose=purpose, bucket=uri[5:].split("/")[0] if uri.startswith("s3://") else None)

    def _infrastructure(self) -> None:
        integrations: dict[str, str] = {}
        volumes: dict[str, str] = {}
        stages: dict[str, str] = {}
        formats: dict[str, str] = {}
        for path, obj in self.ddl:
            p = obj.props
            if obj.kind == "storage_integration" and obj.name:
                key = self.g.node(
                    "storage_integration", obj.name, provider=p.get("storage_provider"), role_arn=p.get("role_arn"), allowed_locations=p.get("allowed_locations")
                )
                integrations[obj.name] = key
                self.g.edge(key, self._file(path), "DEFINED_IN", method="parsed", evidence=path)
                for uri in p.get("allowed_locations") or []:
                    self.g.edge(key, self._s3(uri, "landing"), "ALLOWS", method="parsed", evidence=path)
            elif obj.kind == "external_volume" and obj.name:
                key = self.g.node(
                    "external_volume", obj.name, provider=p.get("storage_provider"), base_url=p.get("base_url"), role_arn=p.get("role_arn"), encryption=p.get("encryption")
                )
                volumes[obj.name] = key
                self.g.edge(key, self._file(path), "DEFINED_IN", method="parsed", evidence=path)
                if p.get("base_url"):
                    self.g.edge(key, self._s3(p["base_url"], "iceberg"), "WRITES_TO", method="parsed", evidence=path)
            elif obj.kind == "file_format" and obj.name:
                key = self.g.node("file_format", obj.name, format_type=p.get("type"), skip_header=p.get("skip_header"))
                formats[obj.name] = key
                self.g.edge(key, self._file(path), "DEFINED_IN", method="parsed", evidence=path)
        for path, obj in self.ddl:
            p = obj.props
            if obj.kind != "stage" or not obj.name:
                continue
            key = self.g.node("stage", obj.name, url=p.get("url"), stage_type="external" if p.get("url") else "internal")
            stages[obj.name] = key
            self.g.edge(key, self._file(path), "DEFINED_IN", method="parsed", evidence=path)
            integration = p.get("storage_integration")
            if integration and integration in integrations:
                self.g.edge(key, integrations[integration], "USES", method="parsed", evidence=path)
            url = str(p.get("url") or "")
            if url and "{" not in url:
                self.g.edge(key, self._s3(url, "landing"), "READS_FROM", method="parsed", evidence=path)
            elif integration in integrations:
                allowed = self.g.nodes[integrations[integration]].props.get("allowed_locations") or []
                if len(allowed) == 1:
                    self.g.edge(key, self._s3(allowed[0], "landing"), "READS_FROM", method="inferred", evidence=path)
        # COPY INTO: which layer is loaded through which stage and file format
        for path, obj in self.ddl:
            if obj.kind != "copy":
                continue
            stage = obj.props.get("stage_ref")
            stage_key = stages.get(stage) if stage else None
            if stage_key is None and len(stages) == 1:
                stage_key = next(iter(stages.values()))
            fmt = obj.props.get("format_name")
            fmt_key = formats.get(fmt) if fmt else None
            if fmt_key is None and len(formats) == 1:
                fmt_key = next(iter(formats.values()))
            if stage_key and fmt_key:
                self.g.edge(stage_key, fmt_key, "USES", method="parsed" if fmt in formats else "inferred", evidence=path)
            layer = str(obj.props.get("layer") or (obj.name.split(".")[0] if "." in obj.name else "")).upper()
            if stage_key and layer:
                for source in self.g.of_kind("source"):
                    table = self.g.get("table", f"{layer}.{source.name}")
                    if table is not None:
                        self.g.edge(source.key, stage_key, "LANDS_IN", method="inferred", evidence=path)
                        table.props.setdefault("load_mode", obj.props.get("load_mode"))
                        table.props.setdefault("loaded_by", path)
        # Iceberg: a templated CREATE ICEBERG TABLE covers every contract table in the data layers
        templates = [(path, obj) for path, obj in self.ddl if obj.kind == "iceberg_table" and obj.templated and "." not in obj.name]
        if templates:
            path, obj = templates[0]
            volume = obj.props.get("external_volume") if not obj.props.get("external_volume_templated") else None
            candidates = [v for v in [volume, *sorted(self.py_volume_defaults), self.env_values.get("SNOWFLAKE_EXTERNAL_VOLUME")] if v]
            chosen = next((v.upper() for v in candidates if v.upper() in volumes), None)
            if chosen is None and len(volumes) == 1:
                chosen = next(iter(volumes))
            catalog = str(obj.props.get("catalog") or "SNOWFLAKE")
            layers = {self.bronze_layer.lower(), *(str(m.get("layer") or "").lower() for _, m in self.models)} - {""}
            for table in self.g.of_kind("table"):
                if table.props.get("layer") in layers and table.props.get("table_type") in (None, "table"):
                    table.props["table_type"] = "iceberg"
                    table.props["catalog"] = catalog
                    table.props["managed"] = catalog.upper() == "SNOWFLAKE"
                    if chosen:
                        table.props["external_volume"] = chosen
                        self.g.edge(table.key, volumes[chosen], "STORED_ON", method="inferred", evidence=path)
        for path, obj in self.ddl:
            if obj.kind == "iceberg_table" and "." in obj.name:
                volume = obj.props.get("external_volume")
                if volume in volumes:
                    self.g.edge(self.g.key("table", obj.name), volumes[volume], "STORED_ON", method="parsed", evidence=path)

    # ================================================================== lineage
    def _declared_lineage(self) -> None:
        for path, asset in self.assets:
            fqn = str(asset["id"]).upper()
            for dep in asset.get("depends_on") or []:
                self.g.edge(self.g.key("table", fqn), self._table(str(dep).upper()), "DERIVED_FROM", method="declared", evidence=path)

    def _schema(self) -> dict[str, dict[str, dict[str, str]]]:
        schema: dict[str, dict[str, dict[str, str]]] = {}
        for col in self.g.of_kind("column"):
            table = str(col.props.get("table", ""))
            if "." not in table:
                continue
            layer, name = table.split(".", 1)
            schema.setdefault(layer, {}).setdefault(name, {})[col.props["column"]] = "STRING"
        return schema

    def _parsed_model_lineage(self) -> None:
        for path, layer, name in self.model_sql:
            tree = st.parse(st.normalize_sql(self.files[path]))
            if tree is None:
                self.g.warn(f"{path}: SQL not parseable; table lineage comes from config only")
                continue
            self._lineage_from_tree(path, _t(layer, name), tree, model=True)
        declared = {(e.src, e.dst) for e in self.g.edges.values() if e.type == "DERIVED_FROM" and "declared" in e.methods}
        parsed = {(e.src, e.dst) for e in self.g.edges.values() if e.type == "DERIVED_FROM" and "parsed" in e.methods}
        tables = {n.key for n in self.g.of_kind("table")}
        with_sql = {self.g.key("table", _t(ly, n)) for _, ly, n in self.model_sql}
        with_assets = {self.g.key("table", str(a["id"]).upper()) for _, a in self.assets}
        for src, dst in sorted(declared - parsed):
            if src in with_sql and dst in tables:
                self.declared_vs_parsed.append(f"{self.g.nodes[src].name} declares {self.g.nodes[dst].name} but its SQL does not read it")
        for src, dst in sorted(parsed - declared):
            if src in with_assets and src in with_sql and dst in tables:
                self.declared_vs_parsed.append(f"{self.g.nodes[src].name} reads {self.g.nodes[dst].name} but the assets config does not declare it")
        for message in self.declared_vs_parsed:
            self.g.warn(message)

    def _lineage_from_tree(self, path: str, fqn: str, tree: Any, *, model: bool = False) -> None:
        table_key = self.g.key("table", fqn)
        for ref in sorted(st.table_refs(tree)):
            if "." in ref:
                self.g.edge(table_key, self._table(ref), "DERIVED_FROM", method="parsed", evidence=path)
        outputs = st.output_columns(tree)
        if not outputs:
            return
        existing = {c.props["column"] for c in self.g.of_kind("column") if c.props.get("table") == fqn}
        for i, column in enumerate(outputs):
            if column not in existing:
                self._column(fqn, column, position=len(existing) + i + 1, method="parsed")
        traced, failed = st.column_lineage(tree, outputs, self._schema())
        if model:
            self.lineage_stats["model_columns"] += len(outputs)
            self.lineage_stats["failed"] += len(failed)
        for column, leaves in traced.items():
            col_key = self.g.key("column", f"{fqn}.{column}")
            if not leaves:
                self.g.nodes[col_key].props["derivation"] = "constant"
                if model:
                    self.lineage_stats["constant"] += 1
                continue
            if model:
                self.lineage_stats["traced"] += 1
            for src_table, src_column in leaves:
                if "." not in src_table:
                    continue
                if not self.g.has("table", src_table):
                    self._table(src_table)
                src_key = self.g.key("column", f"{src_table}.{src_column}")
                if src_key not in self.g.nodes:
                    self._column(src_table, src_column, method="parsed", inferred=True)
                self.g.edge(col_key, src_key, "DERIVED_FROM", method="parsed", evidence=path)
        for column in failed:
            self.g.warn(f"{path}: could not trace {fqn}.{column}")

    # ================================================================== checks
    def _checks(self) -> None:
        tables = {n.name: n for n in self.g.of_kind("table")}
        short: dict[str, list[str]] = {}
        for n in tables.values():
            short.setdefault(str(n.props.get("table", n.name)).upper(), []).append(n.name)
        for path in self.check_sql:
            layer_hint = next((ly for ly in MODEL_LAYERS if ly in PurePosixPath(path).name.lower()), None)
            sql = st.normalize_sql(self.files[path])
            params = {name: st.sql_params(branch) for name, branch in _CHECK_BRANCH.findall(self.files[path])}
            count = 0
            for name, branch in _CHECK_BRANCH.findall(sql):
                refs = sorted({f"{a.upper()}.{b.upper()}" for a, b in _LAYER_REF.findall(branch)})
                parts = name.split(".")
                subject_short = parts[0].upper()
                subject = next((r for r in refs if r.split(".")[1] == subject_short), None)
                if subject is None and len(short.get(subject_short, [])) == 1:
                    subject = short[subject_short][0]
                key = self.g.node(
                    "check",
                    name,
                    display=name,
                    rule=parts[-1],
                    layer=layer_hint,
                    column=parts[1].upper() if len(parts) >= 3 else None,
                    subject=subject,
                    file=path,
                    sql=f"select '{name}' check_name{branch.split(';')[0]}".strip()[:4000],
                    params=params.get(name),
                )
                count += 1
                self.g.edge(key, self._file(path), "DEFINED_IN", method="parsed", evidence=path)
                for ref in refs:
                    if ref in tables:
                        self.g.edge(key, tables[ref].key, "CHECKS", method="parsed", evidence=path, role="subject" if ref == subject else "reference")
            self.g.nodes[self._file(path)].props["checks"] = count
        counts: dict[str, int] = {}
        for e in self.g.edges.values():
            if e.type == "CHECKS":
                counts[e.dst] = counts.get(e.dst, 0) + 1
        for key, total in counts.items():
            self.g.nodes[key].props["checks"] = total

    # ================================================================== pipeline
    def _pipeline(self) -> None:
        layer_tables = [n for n in self.g.of_kind("table") if n.props.get("layer") not in (None, "control", "ingestion")]
        configs: list[tuple[str | None, dict[str, Any]]] = list(self.pipelines)
        if not configs and (self.sources or self.model_sql):
            configs = [(None, {"pipeline_id": self.info.full_name.split("/")[-1]})]
        schedule = self.env_values.get("PIPELINE_SCHEDULE")
        for path, cfg in configs:
            pid = str(cfg["pipeline_id"])
            props = {k: v for k, v in cfg.items() if isinstance(v, (str, int, float, bool)) and k != "pipeline_id" and k not in _RESERVED_PROPS}
            key = self.g.node(
                "pipeline",
                pid,
                display=pid,
                mode=self.source_mode,
                schedule=schedule,
                layers=[ly for ly in ("bronze", "silver", "gold", "serving") if any(t.props.get("layer") == ly for t in layer_tables)],
                **props,
            )
            self.g.edge(self.repo_key, key, "DEFINES", method="declared", evidence=path)
            if path:
                self.g.edge(key, self._file(path), "DEFINED_IN", method="declared", evidence=path)
            for source in self.g.of_kind("source"):
                self.g.edge(key, source.key, "INGESTS", method="declared", evidence=path)
            for table in layer_tables:
                self.g.edge(key, table.key, "BUILDS", method="declared" if path else "inferred", evidence=path)
            for alert in self.g.of_kind("alert"):
                self.g.edge(alert.key, key, "MONITORS", method="inferred")

    # ================================================================== CI + docs
    def _ci(self) -> None:
        for path, text in self.files.items():
            if PurePosixPath(path).name != "Jenkinsfile":
                continue
            previous = None
            for i, name in enumerate(_JENKINS_STAGE.findall(text)):
                key = self.g.node("ci_stage", f"{path}:{name}", display=name, tool="jenkins", order=i + 1)
                self.g.edge(key, self._file(path), "DEFINED_IN", method="parsed", evidence=path)
                if previous:
                    self.g.edge(previous, key, "NEXT", method="parsed", evidence=path)
                previous = key
        for path, text in self.files.items():
            if PurePosixPath(path).name == "Dockerfile":
                base = re.search(r"^FROM\s+(\S+)", text, re.M)
                if base:
                    self.g.nodes[self._file(path)].props["base_image"] = base.group(1)

    def _docs(self) -> None:
        names: dict[str, list[str]] = {}
        for table in self.g.of_kind("table"):
            if table.props.get("layer") in ("silver", "gold", "serving", "mart", "marts"):
                names.setdefault(str(table.props.get("table", "")).upper(), []).append(table.key)
        for path, text in self.files.items():
            if file_role(path) != "doc":
                continue
            words = set(_WORD.findall(text))
            for key in [key for word in sorted(words & set(names)) for key in names[word]][:40]:
                self.g.edge(self._file(path), key, "DOCUMENTS", method="parsed", evidence=path)

    # ================================================================== summary
    def summary(self) -> dict[str, Any]:
        stats = self.g.stats()
        stats["lineage"] = dict(self.lineage_stats)
        stats["declared_vs_parsed"] = self.declared_vs_parsed[:50]
        by_layer: dict[str, int] = {}
        for table in self.g.of_kind("table"):
            layer = str(table.props.get("layer") or "other")
            by_layer[layer] = by_layer.get(layer, 0) + 1
        stats["tables_by_layer"] = by_layer
        return stats


def build_repo_graph(info: RepoInfo, files: dict[str, str], sizes: dict[str, int] | None = None) -> tuple[GraphBuild, dict[str, Any]]:
    extractor = RepoGraphExtractor(info, files, sizes)
    graph = extractor.build()
    return graph, extractor.summary()
