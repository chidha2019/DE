"""asyncpg connection pool with startup retries and JSONB codecs."""

from __future__ import annotations

import asyncio
import json
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

import asyncpg

from ech_core.config import Settings
from ech_core.exceptions import DependencyUnavailableError
from ech_core.logging import get_logger
from ech_core.metrics import DB_POOL_CONNECTIONS

log = get_logger(__name__)

_RETRYABLE = (
    OSError,
    ConnectionError,
    asyncio.TimeoutError,
    asyncpg.CannotConnectNowError,
    asyncpg.InterfaceError,
    asyncpg.PostgresConnectionError,
    asyncpg.InvalidCatalogNameError,  # database still being created by initdb
    asyncpg.InvalidPasswordError,  # role not created yet during init
)


def _json_encoder(value: Any) -> str:
    return json.dumps(value, default=str, separators=(",", ":"))


class PostgresDatabase:
    """Thin lifecycle wrapper around an :class:`asyncpg.Pool`.

    Usage::

        db = PostgresDatabase(settings)
        await db.connect()
        async with db.acquire() as conn: ...
        async with db.transaction() as conn: ...
        await db.close()
    """

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._pool: asyncpg.Pool | None = None

    # ------------------------------------------------------------------ lifecycle
    async def connect(self) -> None:
        if self._pool is not None:
            return
        s = self._settings
        delay = s.postgres_connect_backoff_seconds
        last_error: Exception | None = None
        for attempt in range(1, s.postgres_connect_retries + 1):
            try:
                self._pool = await asyncpg.create_pool(
                    dsn=s.postgres_dsn,
                    min_size=s.postgres_pool_min,
                    max_size=s.postgres_pool_max,
                    command_timeout=s.postgres_statement_timeout_ms / 1000,
                    max_inactive_connection_lifetime=300,
                    init=self._init_connection,
                    server_settings={
                        "application_name": s.service_name,
                        "statement_timeout": str(s.postgres_statement_timeout_ms),
                        "jit": "off",  # JIT hurts short OLTP-style queries
                    },
                )
                log.info("postgres.connected", attempt=attempt, pool_max=s.postgres_pool_max)
                return
            except _RETRYABLE as exc:  # pragma: no cover - timing dependent
                last_error = exc
                log.warning(
                    "postgres.connect_retry",
                    attempt=attempt,
                    max_attempts=s.postgres_connect_retries,
                    delay_seconds=round(delay, 2),
                    error=str(exc),
                )
                await asyncio.sleep(delay)
                delay = min(delay * 2, s.postgres_connect_backoff_max_seconds)
        raise DependencyUnavailableError(
            "Could not connect to PostgreSQL", details={"error": str(last_error)}
        )

    async def close(self) -> None:
        if self._pool is not None:
            await self._pool.close()
            self._pool = None
            log.info("postgres.closed")

    @staticmethod
    async def _init_connection(conn: asyncpg.Connection) -> None:
        # Transparent JSON/JSONB <-> dict conversion for every connection.
        for typename in ("json", "jsonb"):
            await conn.set_type_codec(
                typename, encoder=_json_encoder, decoder=json.loads, schema="pg_catalog"
            )

    # ------------------------------------------------------------------ accessors
    @property
    def pool(self) -> asyncpg.Pool:
        if self._pool is None:
            raise DependencyUnavailableError("PostgreSQL pool is not initialised")
        return self._pool

    @asynccontextmanager
    async def acquire(self) -> AsyncIterator[asyncpg.Connection]:
        async with self.pool.acquire() as conn:
            yield conn

    @asynccontextmanager
    async def transaction(self) -> AsyncIterator[asyncpg.Connection]:
        """Acquire a connection and open a transaction on it."""
        async with self.pool.acquire() as conn:
            async with conn.transaction():
                yield conn

    # ------------------------------------------------------------------ helpers
    async def fetch(self, query: str, *args: Any) -> list[asyncpg.Record]:
        async with self.acquire() as conn:
            return await conn.fetch(query, *args)

    async def fetchrow(self, query: str, *args: Any) -> asyncpg.Record | None:
        async with self.acquire() as conn:
            return await conn.fetchrow(query, *args)

    async def fetchval(self, query: str, *args: Any) -> Any:
        async with self.acquire() as conn:
            return await conn.fetchval(query, *args)

    async def execute(self, query: str, *args: Any) -> str:
        async with self.acquire() as conn:
            return await conn.execute(query, *args)

    async def ping(self) -> bool:
        """Readiness probe: ``SELECT 1`` with a short timeout."""
        try:
            async with asyncio.timeout(3):
                value = await self.fetchval("SELECT 1")
            return value == 1
        except Exception as exc:  # noqa: BLE001 - any failure means not ready
            log.warning("postgres.ping_failed", error=str(exc))
            return False

    def record_pool_metrics(self) -> None:
        """Export pool occupancy to Prometheus (call from a periodic task)."""
        if self._pool is None:
            return
        size = self._pool.get_size()
        idle = self._pool.get_idle_size()
        DB_POOL_CONNECTIONS.labels(self._settings.service_name, "idle").set(idle)
        DB_POOL_CONNECTIONS.labels(self._settings.service_name, "busy").set(size - idle)
