"""Async Neo4j driver wrapper with startup retries and managed transactions."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager
from typing import Any, TypeVar

from neo4j import (
    AsyncGraphDatabase,
    AsyncManagedTransaction,
    AsyncSession,
    NotificationDisabledCategory,
)
from neo4j.exceptions import (
    AuthError,
    ClientError,
    ServiceUnavailable,
    SessionExpired,
    TransientError,
)

from ech_core.config import Settings
from ech_core.exceptions import DependencyUnavailableError
from ech_core.logging import get_logger

log = get_logger(__name__)

T = TypeVar("T")
Records = list[dict[str, Any]]


class GraphDatabase:
    """Lifecycle + convenience wrapper around ``neo4j.AsyncDriver``.

    All work goes through *managed transactions* (``execute_read`` /
    ``execute_write``) so transient cluster errors are retried by the driver.
    """

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._driver = None

    # ------------------------------------------------------------------ lifecycle
    async def connect(self) -> None:
        if self._driver is not None:
            return
        s = self._settings
        driver = AsyncGraphDatabase.driver(
            s.neo4j_uri,
            auth=(s.neo4j_user, s.neo4j_password.get_secret_value()),
            max_connection_pool_size=s.neo4j_max_pool_size,
            connection_acquisition_timeout=30.0,
            connection_timeout=10.0,
            max_transaction_retry_time=15.0,
            user_agent=f"ech/{s.service_name}",
            # Stats/explorer queries legitimately reference labels and relationship
            # types that do not exist yet on an empty graph; the server-side
            # "unknown label" notices are noise, not errors.
            notifications_disabled_categories=[NotificationDisabledCategory.UNRECOGNIZED],
        )
        delay = s.neo4j_connect_backoff_seconds
        last_error: Exception | None = None
        for attempt in range(1, s.neo4j_connect_retries + 1):
            try:
                await driver.verify_connectivity()
                self._driver = driver
                log.info("neo4j.connected", attempt=attempt, uri=s.neo4j_uri)
                return
            except AuthError:
                await driver.close()
                raise
            except (TimeoutError, ServiceUnavailable, OSError, ClientError) as exc:
                last_error = exc
                log.warning(
                    "neo4j.connect_retry",
                    attempt=attempt,
                    max_attempts=s.neo4j_connect_retries,
                    delay_seconds=round(delay, 2),
                    error=str(exc),
                )
                await asyncio.sleep(delay)
                delay = min(delay * 2, s.neo4j_connect_backoff_max_seconds)
        await driver.close()
        raise DependencyUnavailableError(
            "Could not connect to Neo4j", details={"error": str(last_error)}
        )

    async def close(self) -> None:
        if self._driver is not None:
            await self._driver.close()
            self._driver = None
            log.info("neo4j.closed")

    # ------------------------------------------------------------------ accessors
    @property
    def driver(self):  # type: ignore[no-untyped-def]
        if self._driver is None:
            raise DependencyUnavailableError("Neo4j driver is not initialised")
        return self._driver

    @asynccontextmanager
    async def session(self) -> AsyncIterator[AsyncSession]:
        async with self.driver.session(database=self._settings.neo4j_database) as session:
            yield session

    # ------------------------------------------------------------------ execution
    @staticmethod
    async def _run_collect(
        tx: AsyncManagedTransaction, query: str, params: dict[str, Any]
    ) -> Records:
        result = await tx.run(query, **params)
        return await result.data()

    async def execute_read(self, query: str, **params: Any) -> Records:
        """Run a single read query in a managed (retrying) transaction."""
        try:
            async with self.session() as session:
                return await session.execute_read(self._run_collect, query, params)
        except (ServiceUnavailable, SessionExpired, TransientError) as exc:
            raise DependencyUnavailableError(
                "Neo4j read failed", details={"error": str(exc)}
            ) from exc

    async def execute_write(self, query: str, **params: Any) -> Records:
        """Run a single write query in a managed (retrying) transaction."""
        try:
            async with self.session() as session:
                return await session.execute_write(self._run_collect, query, params)
        except (ServiceUnavailable, SessionExpired, TransientError) as exc:
            raise DependencyUnavailableError(
                "Neo4j write failed", details={"error": str(exc)}
            ) from exc

    async def write_unit(self, work: Callable[[AsyncManagedTransaction], Awaitable[T]]) -> T:
        """Run several statements atomically inside one managed write transaction."""
        try:
            async with self.session() as session:
                return await session.execute_write(work)
        except (ServiceUnavailable, SessionExpired, TransientError) as exc:
            raise DependencyUnavailableError(
                "Neo4j write failed", details={"error": str(exc)}
            ) from exc

    async def read_unit(self, work: Callable[[AsyncManagedTransaction], Awaitable[T]]) -> T:
        """Run several statements inside one managed read transaction."""
        try:
            async with self.session() as session:
                return await session.execute_read(work)
        except (ServiceUnavailable, SessionExpired, TransientError) as exc:
            raise DependencyUnavailableError(
                "Neo4j read failed", details={"error": str(exc)}
            ) from exc

    async def ping(self) -> bool:
        try:
            async with asyncio.timeout(3):
                rows = await self.execute_read("RETURN 1 AS ok")
            return bool(rows and rows[0].get("ok") == 1)
        except Exception as exc:  # noqa: BLE001
            log.warning("neo4j.ping_failed", error=str(exc))
            return False
