"""Minimal, dependency-free SQL migration runner.

* Files live in ``infra/postgres/migrations/NNNN_name.sql`` and are applied in
  lexical order.
* Each file runs inside its own transaction and is recorded in
  ``schema_migrations`` together with a SHA-256 checksum.
* A Postgres advisory lock serialises concurrent runners (e.g. two replicas
  starting at once).
* Checksum drift on an already-applied file is logged loudly but does not
  fail: applied DDL is immutable by convention — write a new migration.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path

from ech_core.db.postgres import PostgresDatabase
from ech_core.logging import get_logger

log = get_logger(__name__)

_ADVISORY_LOCK_KEY = 0x45434831  # "ECH1"

_BOOTSTRAP_SQL = """
CREATE TABLE IF NOT EXISTS schema_migrations (
    version     TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    checksum    TEXT NOT NULL,
    applied_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
"""


@dataclass(frozen=True)
class MigrationFile:
    version: str
    name: str
    path: Path
    sql: str
    checksum: str

    @classmethod
    def load(cls, path: Path) -> MigrationFile:
        sql = path.read_text(encoding="utf-8")
        version, _, rest = path.stem.partition("_")
        return cls(
            version=version,
            name=rest or path.stem,
            path=path,
            sql=sql,
            checksum=hashlib.sha256(sql.encode("utf-8")).hexdigest(),
        )


def discover_migrations(directory: Path) -> list[MigrationFile]:
    if not directory.exists():
        raise FileNotFoundError(f"migrations directory not found: {directory}")
    return [MigrationFile.load(p) for p in sorted(directory.glob("*.sql"))]


class MigrationRunner:
    def __init__(self, db: PostgresDatabase, directory: Path) -> None:
        self._db = db
        self._directory = directory

    async def run(self) -> list[str]:
        """Apply pending migrations; return the versions applied in this call."""
        migrations = discover_migrations(self._directory)
        applied_now: list[str] = []

        async with self._db.acquire() as conn:
            await conn.execute(_BOOTSTRAP_SQL)
            await conn.execute("SELECT pg_advisory_lock($1)", _ADVISORY_LOCK_KEY)
            try:
                rows = await conn.fetch("SELECT version, checksum FROM schema_migrations")
                applied = {r["version"]: r["checksum"] for r in rows}

                for m in migrations:
                    if m.version in applied:
                        if applied[m.version] != m.checksum:
                            log.warning(
                                "migration.checksum_drift",
                                version=m.version,
                                name=m.name,
                                hint="applied migrations are immutable; add a new file",
                            )
                        continue

                    log.info("migration.apply", version=m.version, name=m.name)
                    async with conn.transaction():
                        await conn.execute(m.sql)
                        await conn.execute(
                            "INSERT INTO schema_migrations (version, name, checksum) "
                            "VALUES ($1, $2, $3)",
                            m.version,
                            m.name,
                            m.checksum,
                        )
                    applied_now.append(m.version)
            finally:
                await conn.execute("SELECT pg_advisory_unlock($1)", _ADVISORY_LOCK_KEY)

        log.info(
            "migration.complete",
            applied=applied_now,
            total=len(migrations),
            already_applied=len(migrations) - len(applied_now),
        )
        return applied_now
