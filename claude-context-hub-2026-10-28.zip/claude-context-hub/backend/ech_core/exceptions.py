"""Domain exception hierarchy.

Every exception carries an HTTP status and a stable machine-readable ``code``
so the error middleware can render a consistent envelope:

    {"error": {"code": "...", "message": "...", "details": {...}, "request_id": "..."}}
"""

from __future__ import annotations

from typing import Any


class ECHError(Exception):
    """Base class for all expected application errors."""

    status_code: int = 500
    code: str = "internal_error"

    def __init__(
        self, message: str | None = None, *, details: dict[str, Any] | None = None
    ) -> None:
        self.message = message or self.__class__.__doc__ or "Unexpected error"
        self.details = details or {}
        super().__init__(self.message)

    def to_dict(self) -> dict[str, Any]:
        return {"code": self.code, "message": self.message, "details": self.details}


class NotFoundError(ECHError):
    """The requested resource does not exist."""

    status_code = 404
    code = "not_found"


class ConflictError(ECHError):
    """The request conflicts with the current state of the resource."""

    status_code = 409
    code = "conflict"


class InvalidRunStateError(ConflictError):
    """The ingestion run is not in a state that permits this transition."""

    code = "invalid_run_state"


class InvalidRequestError(ECHError):
    """The request is syntactically valid but semantically unacceptable."""

    status_code = 422
    code = "invalid_request"


class DependencyUnavailableError(ECHError):
    """A backing service (Postgres, Neo4j, embedding API) is unavailable."""

    status_code = 503
    code = "dependency_unavailable"


class ConnectorError(ECHError):
    """A source connector failed while listing or fetching documents."""

    status_code = 502
    code = "connector_error"


class EmbeddingError(ECHError):
    """The embedding provider failed or returned malformed vectors."""

    status_code = 502
    code = "embedding_error"


class GraphSyncError(ECHError):
    """Writing the document graph to Neo4j failed."""

    status_code = 502
    code = "graph_sync_error"
