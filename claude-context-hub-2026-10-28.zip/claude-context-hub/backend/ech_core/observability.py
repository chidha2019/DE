"""In-process latency recorder backing the dashboard's API latency charts.

Prometheus histograms are the source of truth for alerting; this ring buffer
exists so the UI can show percentiles per minute without a Prometheus server.
"""

from __future__ import annotations

import math
import threading
import time
from collections import deque
from dataclasses import dataclass
from datetime import UTC, datetime

from ech_core.schemas.stats import LatencyPoint, LatencySeries


@dataclass(slots=True)
class LatencySample:
    ts: float
    path: str
    method: str
    status: int
    duration_ms: float


def _percentile(sorted_values: list[float], q: float) -> float:
    if not sorted_values:
        return 0.0
    idx = (len(sorted_values) - 1) * q
    lo = math.floor(idx)
    hi = math.ceil(idx)
    if lo == hi:
        return sorted_values[lo]
    frac = idx - lo
    return sorted_values[lo] * (1 - frac) + sorted_values[hi] * frac


def _point(bucket_start: datetime, samples: list[LatencySample]) -> LatencyPoint:
    durations = sorted(s.duration_ms for s in samples)
    errors = sum(1 for s in samples if s.status >= 500)
    return LatencyPoint(
        bucket_start=bucket_start,
        count=len(samples),
        p50_ms=round(_percentile(durations, 0.50), 3),
        p95_ms=round(_percentile(durations, 0.95), 3),
        p99_ms=round(_percentile(durations, 0.99), 3),
        avg_ms=round(sum(durations) / len(durations), 3) if durations else 0.0,
        error_rate=round(errors / len(samples), 4) if samples else 0.0,
    )


class LatencyRecorder:
    """Thread-safe bounded buffer of request samples."""

    def __init__(self, maxlen: int = 20_000) -> None:
        self._samples: deque[LatencySample] = deque(maxlen=maxlen)
        self._lock = threading.Lock()

    def record(self, *, path: str, method: str, status: int, duration_ms: float) -> None:
        with self._lock:
            self._samples.append(LatencySample(time.time(), path, method, status, duration_ms))

    def _window(self, window_minutes: int, path_prefix: str | None) -> list[LatencySample]:
        cutoff = time.time() - window_minutes * 60
        with self._lock:
            samples = list(self._samples)
        return [
            s
            for s in samples
            if s.ts >= cutoff and (path_prefix is None or s.path.startswith(path_prefix))
        ]

    def series(
        self,
        *,
        window_minutes: int = 30,
        bucket_seconds: int = 60,
        path_prefix: str | None = None,
    ) -> LatencySeries:
        samples = self._window(window_minutes, path_prefix)
        buckets: dict[int, list[LatencySample]] = {}
        for s in samples:
            key = int(s.ts // bucket_seconds) * bucket_seconds
            buckets.setdefault(key, []).append(s)

        now = int(time.time() // bucket_seconds) * bucket_seconds
        first = now - (window_minutes * 60 // bucket_seconds - 1) * bucket_seconds
        points: list[LatencyPoint] = []
        for start in range(first, now + bucket_seconds, bucket_seconds):
            bucket_dt = datetime.fromtimestamp(start, tz=UTC)
            group = buckets.get(start, [])
            if group:
                points.append(_point(bucket_dt, group))
            else:
                points.append(
                    LatencyPoint(
                        bucket_start=bucket_dt,
                        count=0,
                        p50_ms=0.0,
                        p95_ms=0.0,
                        p99_ms=0.0,
                        avg_ms=0.0,
                        error_rate=0.0,
                    )
                )

        overall = _point(datetime.fromtimestamp(first, tz=UTC), samples) if samples else None
        return LatencySeries(
            window_minutes=window_minutes,
            bucket_seconds=bucket_seconds,
            path_prefix=path_prefix,
            points=points,
            overall=overall,
        )
