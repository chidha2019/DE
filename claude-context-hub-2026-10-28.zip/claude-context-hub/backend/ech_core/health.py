"""Liveness / readiness endpoints.

Readiness checks are registered at runtime (inside the service lifespan) on
``app.state.readiness_checks`` as ``{name: async_callable_returning_bool}``.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from datetime import UTC, datetime

from fastapi import APIRouter, Request, Response, status

from ech_core.schemas.common import HealthStatus

ReadinessCheck = Callable[[], Awaitable[bool]]


def build_health_router(service_name: str, version: str) -> APIRouter:
    router = APIRouter(tags=["health"])

    @router.get("/health/live", response_model=HealthStatus, summary="Liveness probe")
    async def live() -> HealthStatus:
        return HealthStatus(
            status="ok", service=service_name, version=version, checks={}, timestamp=_now()
        )

    @router.get(
        "/health/ready",
        response_model=HealthStatus,
        summary="Readiness probe (checks datastores)",
        responses={503: {"model": HealthStatus}},
    )
    async def ready(request: Request, response: Response) -> HealthStatus:
        checks: dict[str, ReadinessCheck] = getattr(request.app.state, "readiness_checks", {})
        names = list(checks)
        results = await asyncio.gather(
            *(_guard(checks[name]) for name in names), return_exceptions=False
        )
        outcome = dict(zip(names, results, strict=True))
        all_ok = all(outcome.values()) if outcome else True
        if not all_ok:
            response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
        return HealthStatus(
            status="ok" if all_ok else "degraded",
            service=service_name,
            version=version,
            checks=outcome,
            timestamp=_now(),
        )

    return router


async def _guard(check: ReadinessCheck) -> bool:
    try:
        async with asyncio.timeout(5):
            return bool(await check())
    except Exception:  # noqa: BLE001 - a failing probe is simply "not ready"
        return False


def _now() -> datetime:
    return datetime.now(tz=UTC)
