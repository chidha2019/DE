"""Text utilities shared by chunking, hashing embeddings and reranking.

Tokenisation here is *approximate*: we count word and punctuation tokens,
which tracks GPT-style BPE counts within ~15% for English prose and is
dependency-free. Use a real tokenizer if exact budgets matter.
"""

from __future__ import annotations

import hashlib
import re
import unicodedata

_TOKEN_RE = re.compile(r"\w+|[^\w\s]", re.UNICODE)
_WORD_RE = re.compile(r"[\w']+", re.UNICODE)
_SPACES_RE = re.compile(r"[ \t\f\v]+")
_MULTI_NEWLINE_RE = re.compile(r"\n{3,}")
_SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?])\s+(?=[\"'(\[A-Z0-9])")

STOPWORDS: frozenset[str] = frozenset(
    """
    a an and are as at be by for from has he in is it its of on or that the to was were will
    with this these those we you they our your their i me my us them not no but if then than
    so such can could should would may might must do does did done have had having into onto
    about above below over under again further once here there when where why how all any both
    each few more most other some only own same too very s t just don now
    """.split()
)


def normalize_text(text: str) -> str:
    """Canonical whitespace/unicode form used before hashing and chunking."""
    text = unicodedata.normalize("NFKC", text or "")
    text = text.replace("\r\n", "\n").replace("\r", "\n").replace(" ", " ")
    lines = [_SPACES_RE.sub(" ", line).rstrip() for line in text.split("\n")]
    text = "\n".join(lines)
    text = _MULTI_NEWLINE_RE.sub("\n\n", text)
    return text.strip()


def content_hash(text: str) -> str:
    """SHA-256 hex digest of the normalised text."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def count_tokens(text: str) -> int:
    return len(_TOKEN_RE.findall(text))


def tokenize(text: str, *, drop_stopwords: bool = False) -> list[str]:
    """Lower-cased word tokens (apostrophes kept)."""
    words = [w.lower() for w in _WORD_RE.findall(text)]
    if drop_stopwords:
        words = [w for w in words if w not in STOPWORDS]
    return words


def split_sentences(paragraph: str) -> list[str]:
    """Heuristic sentence splitter good enough for enterprise prose."""
    parts = _SENTENCE_SPLIT_RE.split(paragraph.strip())
    return [p.strip() for p in parts if p.strip()]


def truncate(text: str, max_chars: int, *, suffix: str = "…") -> str:
    if len(text) <= max_chars:
        return text
    return text[: max(0, max_chars - len(suffix))].rstrip() + suffix
