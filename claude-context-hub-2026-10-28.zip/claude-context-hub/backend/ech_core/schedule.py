"""When a pipeline runs next. Pure functions over Schedule; every time is UTC."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

from ech_core.schemas.pipelines import Schedule

_DAYS = ("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
_SHORT = tuple(d[:3] for d in _DAYS)


def _at(day: datetime, hhmm: str) -> datetime:
    hour, minute = (int(part) for part in hhmm.split(":"))
    return day.replace(hour=hour, minute=minute, second=0, microsecond=0)


def next_run_at(schedule: Schedule, after: datetime) -> datetime | None:
    """The first run strictly after the given time; None for a manual pipeline."""
    after = after.astimezone(UTC) if after.tzinfo else after.replace(tzinfo=UTC)
    if schedule.type == "manual":
        return None
    if schedule.type == "interval":
        return after + timedelta(minutes=schedule.every_minutes or 60)
    assert schedule.time is not None
    if schedule.type == "daily":
        candidate = _at(after, schedule.time)
        return candidate if candidate > after else candidate + timedelta(days=1)
    for offset in range(0, 8):
        candidate = _at(after + timedelta(days=offset), schedule.time)
        if candidate > after and candidate.weekday() in schedule.days:
            return candidate
    return None  # unreachable for a validated weekly schedule


def describe(schedule: Schedule) -> str:
    """A short sentence for cards and the review step."""
    if schedule.type == "manual":
        return "Manual"
    if schedule.type == "interval":
        minutes = schedule.every_minutes or 60
        if minutes % 1440 == 0:
            days = minutes // 1440
            return "Every day" if days == 1 else f"Every {days} days"
        if minutes % 60 == 0:
            hours = minutes // 60
            return "Every hour" if hours == 1 else f"Every {hours} hours"
        return f"Every {minutes} minutes"
    if schedule.type == "daily":
        return f"Daily at {schedule.time} UTC"
    days = schedule.days
    if days == [0, 1, 2, 3, 4]:
        label = "Weekdays"
    elif len(days) == 1:
        label = f"{_DAYS[days[0]]}s"
    else:
        label = ", ".join(_SHORT[d] for d in days)
    return f"{label} at {schedule.time} UTC"
