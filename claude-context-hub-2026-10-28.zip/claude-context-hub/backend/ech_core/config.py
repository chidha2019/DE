"""Typed runtime configuration (pydantic-settings).

All variables are prefixed with ``ECH_`` (e.g. ``ECH_POSTGRES_DSN``). A local
``.env`` file in the backend directory is honoured for host development; in
Docker the values come from the compose environment.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import AliasChoices, Field, SecretStr, ValidationInfo, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# backend/ech_core/config.py -> parents[2] == repository root (both on host and in the image)
REPO_ROOT: Path = Path(__file__).resolve().parents[2]

EmbeddingProviderName = Literal["hashing", "openai", "local"]
RerankerProviderName = Literal["heuristic", "cross_encoder", "none"]
OverlapStrategy = Literal["sentence", "token", "none"]


# Defaults for the Data Engineer KPI targets; each is overridable as ECH_KPI_TARGET_<KEY>.
KPI_TARGET_DEFAULTS: dict[str, float] = {
    "run_success_rate": 95.0,  # % of finished runs that completed
    "runs_failed": 0.0,  # failed runs in the window
    "doc_failure_rate": 1.0,  # % of documents seen that failed
    "graph_sync_rate": 99.0,  # % of documents synced to Neo4j
    "graph_failed": 0.0,  # documents whose graph sync failed
    "graph_pending": 0.0,  # documents waiting for graph sync
    "assets_described_pct": 90.0,  # % of catalog assets with a description
    "assets_owned_pct": 95.0,  # % of catalog assets with an owner
    "facts_keyed_pct": 80.0,  # % of fact tables with a primary key
    "assets_connected_pct": 90.0,  # % of assets with a key, join or lineage edge
    "joins_declared_pct": 70.0,  # % of joins that are declared rather than inferred
    "columns_described_pct": 70.0,  # % of columns with a description
    "metrics_declared_pct": 50.0,  # % of metrics that are declared
    "assets_fresh_24h_pct": 95.0,  # % of assets synced in the last 24 hours
    "stale_assets_7d": 0.0,  # assets not refreshed in 7 days
    "catalog_sync_age_h": 24.0,  # hours since the last catalog sync
    # QA Engineer and SRE scorecards
    "review_backlog": 0.0,  # Claude suggestions waiting for a decision
    "unclassified_assets": 0.0,  # assets whose kind is still unknown
    "request_error_rate": 1.0,  # % of audited API requests that errored
    "retrieval_p95_ms": 1500.0,  # p95 latency of context retrieval, ms
    "runs_stale": 0.0,  # active runs with no progress for an hour
    # Business Analyst scorecard
    "genie_answered_pct": 80.0,  # % of the analyst's Genie questions answered and not marked unhelpful
    "intent_decision_h": 48.0,  # median hours from a request arriving to an approve/reject decision
    "intents_clarifying": 0.0,  # requests waiting on answers to the planner's questions
    "reporting_metrics_declared_pct": 80.0,  # % of metrics on reporting-layer (non-raw) assets that are declared
}


class Settings(BaseSettings):
    """Process-wide settings. Construct via :func:`get_settings`."""

    model_config = SettingsConfigDict(
        env_prefix="ECH_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
        populate_by_name=True,  # aliased fields (DATABRICKS_HOST) stay constructible by name
    )

    # --- service identity ---------------------------------------------------
    service_name: str = "ech"
    environment: Literal["development", "staging", "production"] = "development"
    log_level: str = "INFO"
    log_json: bool = False
    cors_origins: list[str] = Field(
        default_factory=lambda: ["http://localhost:5173", "http://localhost:3000"]
    )

    # --- PostgreSQL ------------------------------------------------------------
    postgres_dsn: str = "postgresql://ech:ech_dev_password@localhost:5432/ech"
    postgres_pool_min: int = Field(default=2, ge=1)
    postgres_pool_max: int = Field(default=10, ge=1)
    postgres_statement_timeout_ms: int = Field(default=30_000, ge=1_000)
    postgres_connect_retries: int = Field(default=15, ge=1)
    postgres_connect_backoff_seconds: float = Field(default=1.0, gt=0)
    postgres_connect_backoff_max_seconds: float = Field(default=15.0, gt=0)
    migrations_dir: Path = REPO_ROOT / "infra" / "postgres" / "migrations"

    # --- connection settings saved from the hub --------------------------------
    secrets_key: SecretStr | None = Field(
        default=None, description="Fernet key for credentials saved from the Connectors page; generated into state_dir when unset"
    )
    state_dir: Path = Field(default=REPO_ROOT / ".state", description="where the service keeps its generated secrets key")

    # --- Neo4j -----------------------------------------------------------------
    neo4j_uri: str = "bolt://localhost:7687"
    neo4j_user: str = "neo4j"
    neo4j_password: SecretStr = SecretStr("ech_dev_password")
    neo4j_database: str = "neo4j"
    neo4j_max_pool_size: int = Field(default=50, ge=1)
    neo4j_connect_retries: int = Field(default=20, ge=1)
    neo4j_connect_backoff_seconds: float = Field(default=1.5, gt=0)
    neo4j_connect_backoff_max_seconds: float = Field(default=15.0, gt=0)
    neo4j_schema_dir: Path = REPO_ROOT / "infra" / "neo4j" / "schema"

    # --- Embeddings ------------------------------------------------------------
    embedding_provider: EmbeddingProviderName = "hashing"
    embedding_model: str = "text-embedding-3-small"
    embedding_dimensions: int = Field(default=1536, ge=8, le=1536)
    embedding_batch_size: int = Field(default=64, ge=1, le=2048)
    embedding_max_concurrency: int = Field(default=4, ge=1, le=64)
    openai_api_key: SecretStr | None = None
    openai_base_url: str = "https://api.openai.com/v1"
    openai_timeout_seconds: float = Field(default=30.0, gt=0)
    local_embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"

    # --- GitHub live connector ---------------------------------------------------
    github_repos: str = Field(
        default="", description="Comma-separated repositories: owner/name[@ref] or GitHub URLs"
    )
    github_token: SecretStr | None = None
    github_api_url: str = "https://api.github.com"
    github_raw_url: str = "https://raw.githubusercontent.com"
    github_max_file_kb: int = Field(default=256, ge=1, le=4096)
    github_fetch_concurrency: int = Field(default=8, ge=1, le=32)

    # --- Grafana (observability connector + SRE workspace) -----------------------
    # Read by name from GRAFANA_URL / GRAFANA_TOKEN; a service-account token with Viewer is enough.
    grafana_url: str | None = Field(
        default=None,
        validation_alias=AliasChoices("GRAFANA_URL", "ECH_GRAFANA_URL"),
        description="Grafana Cloud stack or self-hosted URL, e.g. https://acme.grafana.net",
    )
    grafana_token: SecretStr | None = Field(
        default=None, validation_alias=AliasChoices("GRAFANA_TOKEN", "ECH_GRAFANA_TOKEN")
    )
    grafana_max_dashboards: int = Field(default=500, ge=1, le=5000)

    # --- Jira intents (query service) ---------------------------------------------
    # Read by name from JIRA_BASE_URL / JIRA_EMAIL / JIRA_API_TOKEN (Jira Cloud REST, basic auth).
    # When all three are set the query service polls the JQL for tickets, parses them into intents,
    # posts questions and specs back as comments, and reads /approve, /reject and /answer replies.
    jira_base_url: str | None = Field(
        default=None,
        validation_alias=AliasChoices("JIRA_BASE_URL", "ECH_JIRA_BASE_URL"),
        description="Jira Cloud site, e.g. https://acme.atlassian.net",
    )
    jira_email: str | None = Field(default=None, validation_alias=AliasChoices("JIRA_EMAIL", "ECH_JIRA_EMAIL"))
    jira_api_token: SecretStr | None = Field(
        default=None, validation_alias=AliasChoices("JIRA_API_TOKEN", "ECH_JIRA_API_TOKEN")
    )
    jira_intent_jql: str = Field(
        default='labels = "ech-intent" AND statusCategory != Done ORDER BY created DESC',
        description="which tickets are intents",
    )
    jira_poll_seconds: int = Field(default=60, ge=0, le=3600, description="how often imported tickets are checked for replies; 0 disables")
    # The same connection, saved from the Connectors page or set here, also ingests issues as documents.
    jira_ingest_jql: str = Field(
        default="updated >= -180d ORDER BY updated DESC", description="which issues the Jira connector ingests as documents"
    )
    jira_max_issues: int = Field(default=200, ge=1, le=5000, description="most issues one ingestion run reads")
    intent_workspace_dir: Path = Field(
        default=Path("workspace"), description="where generated pipelines are written (bind-mounted ./pipelines)"
    )
    intent_data_dir: Path = Field(
        default=Path("data"), description="root for CSV folders an intent may name (bind-mounted ./data)"
    )
    intent_repo: str | None = Field(
        default=None, description="owner/name of the pipeline repository for the agent path, if indexed in the hub"
    )
    intent_run_enabled: bool = Field(
        default=False, description="the hub runs approved CSV-to-Iceberg pipelines itself, with the ECH_RUN_* settings"
    )
    intent_autorun: bool = Field(default=True, description="approving a spec generates the pipeline and then runs it")
    intent_catalog_url: str | None = Field(
        default=None, description="the ingestion service, asked for a Snowflake sync of the target schema after a run"
    )
    # --- Digital workers ---------------------------------------------------------
    worker_enabled: bool = Field(default=True, description="run the Data Engineer digital worker's sweep loop")
    worker_tick_seconds: int = Field(default=20, ge=5, le=3600, description="seconds between the worker's sweeps of the hub's signals")

    # --- Databricks Unity Catalog connector (semantic layer) ---------------------
    # Host and token are the same pair Genie's model uses (no ECH_ prefix).
    databricks_host: str | None = Field(
        default=None, validation_alias=AliasChoices("DATABRICKS_HOST", "ECH_DATABRICKS_HOST")
    )
    databricks_token: SecretStr | None = Field(
        default=None, validation_alias=AliasChoices("DATABRICKS_TOKEN", "ECH_DATABRICKS_TOKEN")
    )
    databricks_catalogs: str = Field(default="", description="comma-separated catalogs to ingest")
    databricks_schemas: str = Field(
        default="", description="comma-separated catalog.schema filters"
    )
    databricks_include_lineage: bool = True
    databricks_max_tables: int = Field(default=2000, ge=1, le=50_000)
    databricks_fetch_concurrency: int = Field(default=8, ge=1, le=32)

    # --- Snowflake connector (semantic layer) ----------------------------------
    snowflake_account: str | None = Field(
        default=None, description="account identifier, e.g. xy12345.us-east-1 or myorg-myaccount"
    )
    snowflake_host: str | None = Field(
        default=None, description="override <account>.snowflakecomputing.com"
    )
    snowflake_user: str | None = None
    snowflake_token: SecretStr | None = Field(
        default=None,
        validation_alias=AliasChoices("ECH_SNOWFLAKE_TOKEN", "SNOWFLAKE_TOKEN"),
        description="PAT or OAuth token; SNOWFLAKE_TOKEN is the name generated pipelines use, so both are read",
    )
    snowflake_auth_scheme: Literal["PROGRAMMATIC_ACCESS_TOKEN", "OAUTH", "KEYPAIR_JWT"] = (
        "PROGRAMMATIC_ACCESS_TOKEN"
    )
    snowflake_private_key_path: Path | None = None
    snowflake_private_key_passphrase: SecretStr | None = None
    snowflake_warehouse: str | None = None
    snowflake_role: str | None = None
    snowflake_databases: str = Field(default="", description="comma-separated databases to ingest")
    snowflake_schemas: str = Field(
        default="", description="comma-separated DATABASE.SCHEMA filters"
    )
    snowflake_include_lineage: bool = True
    snowflake_include_tags: bool = True
    snowflake_max_tables: int = Field(default=2000, ge=1, le=50_000)
    snowflake_statement_timeout_seconds: int = Field(default=120, ge=10, le=3600)

    # --- Semantic layer --------------------------------------------------------------
    semantic_infer_joins: bool = True
    glossary_auto_map: bool = Field(
        default=True, description="after every successful Snowflake or Databricks sync, propose glossary links for review"
    )
    glossary_auto_map_seconds: int = Field(default=30, ge=10, le=3600, description="how often finished syncs are picked up")

    # KPI targets for the persona scorecards (ECH_KPI_TARGET_*); see KPI_TARGET_DEFAULTS.
    kpi_target_run_success_rate: float = 95.0
    kpi_target_runs_failed: float = 0.0
    kpi_target_doc_failure_rate: float = 1.0
    kpi_target_graph_sync_rate: float = 99.0
    kpi_target_graph_failed: float = 0.0
    kpi_target_graph_pending: float = 0.0
    kpi_target_assets_described_pct: float = 90.0
    kpi_target_assets_owned_pct: float = 95.0
    kpi_target_facts_keyed_pct: float = 80.0
    kpi_target_assets_connected_pct: float = 90.0
    kpi_target_joins_declared_pct: float = 70.0
    kpi_target_columns_described_pct: float = 70.0
    kpi_target_metrics_declared_pct: float = 50.0
    kpi_target_assets_fresh_24h_pct: float = 95.0
    kpi_target_stale_assets_7d: float = 0.0
    kpi_target_catalog_sync_age_h: float = 24.0
    kpi_target_review_backlog: float = 0.0
    kpi_target_unclassified_assets: float = 0.0
    kpi_target_request_error_rate: float = 1.0
    kpi_target_retrieval_p95_ms: float = 1500.0
    kpi_target_runs_stale: float = 0.0
    kpi_target_genie_answered_pct: float = 80.0
    kpi_target_intent_decision_h: float = 48.0
    kpi_target_intents_clarifying: float = 0.0
    kpi_target_reporting_metrics_declared_pct: float = 80.0

    @property
    def kpi_targets(self) -> dict[str, float]:
        """Active KPI targets keyed like the scorecard; defaults unless overridden by env."""
        return {key: float(getattr(self, f"kpi_target_{key}")) for key in KPI_TARGET_DEFAULTS}

    # --- Reranking -------------------------------------------------------------
    reranker_provider: RerankerProviderName = "heuristic"
    reranker_model: str = "cross-encoder/ms-marco-MiniLM-L-6-v2"
    reranker_weight: float = Field(default=0.6, ge=0.0, le=1.0)

    # --- Retrieval -------------------------------------------------------------
    retrieval_default_top_k: int = Field(default=8, ge=1, le=50)
    retrieval_vector_top_k: int = Field(default=40, ge=1, le=500)
    retrieval_keyword_top_k: int = Field(default=40, ge=1, le=500)
    retrieval_rerank_multiplier: int = Field(default=4, ge=1, le=20)
    retrieval_rrf_k: int = Field(default=60, ge=1)
    retrieval_vector_weight: float = Field(default=1.0, ge=0)
    retrieval_keyword_weight: float = Field(default=0.8, ge=0)
    retrieval_graph_boost_weight: float = Field(default=0.25, ge=0, le=1)
    retrieval_graph_max_expanded_chunks: int = Field(default=20, ge=0, le=200)
    retrieval_graph_max_entities: int = Field(default=60, ge=1, le=500)
    hnsw_ef_search: int = Field(default=100, ge=10, le=1000)

    # --- Chunking --------------------------------------------------------------
    chunk_target_tokens: int = Field(default=320, ge=32)
    chunk_max_tokens: int = Field(default=512, ge=64)
    chunk_min_tokens: int = Field(default=40, ge=1)
    chunk_overlap_tokens: int = Field(default=48, ge=0)
    chunk_overlap_strategy: OverlapStrategy = "sentence"

    # --- Ingestion -------------------------------------------------------------
    ingestion_concurrency: int = Field(default=4, ge=1, le=64)
    # Concurrent Neo4j subgraph writes. Documents share Entity nodes, so parallel
    # MERGEs deadlock and get retried by the driver; 1 keeps writes serial while
    # chunking/embedding/Postgres work still runs with `ingestion_concurrency`.
    graph_sync_concurrency: int = Field(default=1, ge=1, le=16)
    ingestion_stats_flush_interval_seconds: float = Field(default=0.75, gt=0)
    ingestion_event_history: int = Field(default=500, ge=10)
    # Saved pipelines with a schedule start by themselves; the ingestion service checks for due ones.
    pipeline_scheduler_enabled: bool = True
    pipeline_scheduler_interval_seconds: float = Field(default=30.0, ge=5, le=3600)

    # --- Genie / Claude --------------------------------------------------------
    # The model client reads credentials straight from the process environment:
    # DATABRICKS_HOST + DATABRICKS_TOKEN (Databricks-hosted Claude) or ANTHROPIC_API_KEY.
    genie_enabled: bool = True
    llm_provider: Literal["auto", "anthropic", "databricks"] = "auto"
    llm_model: str | None = Field(default=None, description="None: the provider's default")
    llm_base_url: str | None = None
    llm_effort: Literal["low", "medium", "high", "xhigh", "max"] = "medium"
    llm_max_tokens: int = Field(default=4096, ge=256, le=64_000)
    llm_fallbacks: bool = True  # server-side refusal fallbacks (first-party API only)
    genie_max_turns: int = Field(default=8, ge=1, le=20)
    genie_history_messages: int = Field(default=12, ge=0, le=60)
    genie_search_max_chars: int = Field(default=1500, ge=200, le=8000)
    genie_cypher_timeout_seconds: float = Field(default=10.0, gt=0, le=60)
    genie_cypher_row_limit: int = Field(default=50, ge=1, le=500)

    # --- Observability ---------------------------------------------------------
    metrics_enabled: bool = True
    latency_buffer_size: int = Field(default=20_000, ge=100)

    @field_validator("log_level")
    @classmethod
    def _upper(cls, value: str) -> str:
        return value.upper()

    @field_validator("snowflake_private_key_path", mode="before")
    @classmethod
    def _empty_path_is_none(cls, value: object) -> object:
        # docker-compose passes every variable, empty when unused; an empty string must not become Path(".").
        return None if isinstance(value, str) and not value.strip() else value

    @field_validator("chunk_max_tokens")
    @classmethod
    def _max_ge_target(cls, value: int, info: ValidationInfo) -> int:
        target = info.data.get("chunk_target_tokens")
        if target is not None and value < target:
            raise ValueError("chunk_max_tokens must be >= chunk_target_tokens")
        return value

    @property
    def is_production(self) -> bool:
        return self.environment == "production"

    @property
    def github_repo_list(self) -> list[str]:
        return _csv(self.github_repos)

    @property
    def databricks_catalog_list(self) -> list[str]:
        return _csv(self.databricks_catalogs)

    @property
    def databricks_schema_list(self) -> list[str]:
        return _csv(self.databricks_schemas)

    @property
    def snowflake_database_list(self) -> list[str]:
        return _csv(self.snowflake_databases)

    @property
    def snowflake_schema_list(self) -> list[str]:
        return _csv(self.snowflake_schemas)


def _csv(value: str) -> list[str]:
    return [item.strip() for item in value.split(",") if item.strip()]


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Cached settings singleton (tests may call ``get_settings.cache_clear()``)."""
    return Settings()
