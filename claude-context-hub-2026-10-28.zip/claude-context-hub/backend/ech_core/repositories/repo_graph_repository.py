"""Repo knowledge graph: Neo4j subgraphs of crawled repositories, and the Postgres crawl history.

The graph is written per repository in one managed transaction (delete the repository's
``:RepoGraph`` nodes, create nodes per kind label, create edges per relationship type), so a
reader never sees half a crawl. Labels and relationship types are interpolated only from the
whitelists in :mod:`ech_core.repo_graph.model`.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from neo4j import AsyncManagedTransaction

from ech_core.db.neo4j import GraphDatabase
from ech_core.db.postgres import PostgresDatabase
from ech_core.repo_graph.model import KIND_LABELS, REL_TYPES, GraphBuild

_SCHEMA = (
    "CREATE CONSTRAINT repo_graph_node_key_unique IF NOT EXISTS FOR (n:RepoGraph) REQUIRE n.node_key IS UNIQUE",
    "CREATE INDEX repo_graph_repo_idx IF NOT EXISTS FOR (n:RepoGraph) ON (n.repo)",
    "CREATE INDEX repo_graph_kind_idx IF NOT EXISTS FOR (n:RepoGraph) ON (n.kind)",
)

# What the lineage view draws: data movement and the infrastructure it runs on (no columns).
LINEAGE_KINDS = (
    "source_system", "source", "stage", "file_format", "storage_integration", "external_volume", "s3_location", "table", "pipeline",
)
LINEAGE_RELS = ("FROM_SYSTEM", "LANDS_IN", "USES", "READS_FROM", "ALLOWS", "WRITES_TO", "LOADED_FROM", "DERIVED_FROM", "STORED_ON")


def _chunks(rows: list[dict[str, Any]], size: int) -> list[list[dict[str, Any]]]:
    return [rows[i : i + size] for i in range(0, len(rows), size)]


def _payload_node(props: dict[str, Any]) -> dict[str, Any]:
    clean = {k: v for k, v in props.items() if k not in ("node_key", "repo")}
    return {
        "id": props["node_key"],
        "label": props.get("display") or props.get("name"),
        "type": props.get("kind"),
        "properties": clean,
        "degree": None,
    }


class RepoGraphRepository:
    def __init__(self, graph: GraphDatabase) -> None:
        self._graph = graph

    # ------------------------------------------------------------------ write
    async def ensure_schema(self) -> None:
        for statement in _SCHEMA:
            async with self._graph.session() as session:
                result = await session.run(statement)
                await result.consume()

    async def replace(self, build: GraphBuild) -> dict[str, int]:
        node_rows = build.node_rows()
        edge_rows = build.edge_rows()
        labels = set(KIND_LABELS.values())

        async def work(tx: AsyncManagedTransaction) -> dict[str, int]:
            deleted = await tx.run("MATCH (n:RepoGraph {repo: $repo}) DETACH DELETE n RETURN count(*) AS n", repo=build.repo)
            record = await deleted.single()
            removed = int(record["n"]) if record else 0
            nodes = edges = 0
            for label, rows in node_rows.items():
                if label not in labels:
                    raise ValueError(f"label {label!r} is not whitelisted")
                for chunk in _chunks(rows, 500):
                    res = await tx.run(f"UNWIND $rows AS r CREATE (n:RepoGraph:{label} {{node_key: r.key}}) SET n += r.props", rows=chunk)
                    nodes += (await res.consume()).counters.nodes_created
            for rel, rows in edge_rows.items():
                if rel not in REL_TYPES:
                    raise ValueError(f"relationship {rel!r} is not whitelisted")
                for chunk in _chunks(rows, 1000):
                    res = await tx.run(
                        f"UNWIND $rows AS r MATCH (a:RepoGraph {{node_key: r.src}}) MATCH (b:RepoGraph {{node_key: r.dst}}) "
                        f"CREATE (a)-[e:{rel}]->(b) SET e += r.props",
                        rows=chunk,
                    )
                    edges += (await res.consume()).counters.relationships_created
            return {"nodes": nodes, "edges": edges, "removed": removed}

        return await self._graph.write_unit(work)

    async def delete(self, repo: str) -> int:
        rows = await self._graph.execute_write("MATCH (n:RepoGraph {repo: $repo}) DETACH DELETE n RETURN count(*) AS n", repo=repo)
        return int(rows[0]["n"]) if rows else 0

    # ------------------------------------------------------------------ read
    async def repos(self) -> list[dict[str, Any]]:
        rows = await self._graph.execute_read(
            """
            MATCH (n:RepoGraph)
            WITH n.repo AS repo, n.kind AS kind, count(*) AS c
            WITH repo, collect([kind, c]) AS counts
            MATCH (r:Repository:RepoGraph {repo: repo})
            RETURN properties(r) AS props, counts
            ORDER BY repo
            """
        )
        out: list[dict[str, Any]] = []
        for row in rows:
            props = dict(row["props"])
            props["counts"] = {str(k): int(v) for k, v in row["counts"]}
            out.append(props)
        return out

    async def graph(
        self, repo: str, *, kinds: list[str] | None = None, rels: list[str] | None = None, limit: int = 2500
    ) -> dict[str, Any]:
        node_rows = await self._graph.execute_read(
            """
            MATCH (n:RepoGraph {repo: $repo})
            WHERE $kinds IS NULL OR n.kind IN $kinds
            RETURN properties(n) AS props
            ORDER BY n.kind, n.name
            LIMIT $limit
            """,
            repo=repo,
            kinds=kinds,
            limit=limit,
        )
        nodes = [_payload_node(dict(r["props"])) for r in node_rows]
        keys = [n["id"] for n in nodes]
        edge_rows = await self._graph.execute_read(
            """
            MATCH (a:RepoGraph {repo: $repo})-[e]->(b:RepoGraph {repo: $repo})
            WHERE a.node_key IN $keys AND b.node_key IN $keys AND ($rels IS NULL OR type(e) IN $rels)
            RETURN a.node_key AS source, b.node_key AS target, type(e) AS type, properties(e) AS props
            """,
            repo=repo,
            keys=keys,
            rels=rels,
        )
        degree: dict[str, int] = {}
        edges = []
        for r in edge_rows:
            props = {k: v for k, v in dict(r["props"]).items() if k != "repo"}
            edges.append({"source": r["source"], "target": r["target"], "type": r["type"], "properties": props})
            degree[r["source"]] = degree.get(r["source"], 0) + 1
            degree[r["target"]] = degree.get(r["target"], 0) + 1
        for n in nodes:
            n["degree"] = degree.get(n["id"], 0)
        return {"nodes": nodes, "edges": edges, "center_id": None, "chunk_entities": None, "truncated": len(nodes) >= limit}

    async def lineage(self, repo: str) -> dict[str, Any]:
        return await self.graph(repo, kinds=list(LINEAGE_KINDS), rels=list(LINEAGE_RELS))

    async def node(self, key: str) -> dict[str, Any] | None:
        rows = await self._graph.execute_read(
            """
            MATCH (n:RepoGraph {node_key: $key})
            OPTIONAL MATCH (n)-[e]-(m:RepoGraph)
            WITH n, e, m ORDER BY type(e), m.kind, m.name
            RETURN properties(n) AS node,
                   [x IN collect(CASE WHEN e IS NULL THEN NULL ELSE {
                       type: type(e), outgoing: startNode(e) = n, key: m.node_key, kind: m.kind, name: m.name,
                       display: coalesce(m.display, m.name), methods: e.methods, evidence: e.evidence, role: e.role
                   } END) WHERE x IS NOT NULL][..500] AS links
            """,
            key=key,
        )
        if not rows:
            return None
        node = dict(rows[0]["node"])
        detail: dict[str, Any] = {"node": node, "links": [dict(x) for x in rows[0]["links"]], "columns": [], "upstream": [], "downstream": [], "trace": []}
        if node.get("kind") == "table":
            detail["columns"] = await self._columns(key)
            impact = await self._graph.execute_read(
                """
                MATCH (t:RepoGraph {node_key: $key})
                OPTIONAL MATCH (t)-[:DERIVED_FROM*1..10]->(u:DataTable)
                WITH t, collect(DISTINCT u.name) AS upstream
                OPTIONAL MATCH (d:DataTable)-[:DERIVED_FROM*1..10]->(t)
                RETURN upstream, collect(DISTINCT d.name) AS downstream
                """,
                key=key,
            )
            if impact:
                detail["upstream"] = sorted(impact[0]["upstream"])
                detail["downstream"] = sorted(impact[0]["downstream"])
        elif node.get("kind") == "column":
            detail["trace"] = await self._column_trace(key)
        return detail

    async def _columns(self, table_key: str) -> list[dict[str, Any]]:
        rows = await self._graph.execute_read(
            """
            MATCH (:RepoGraph {node_key: $key})-[:HAS_COLUMN]->(c:DataColumn)
            OPTIONAL MATCH (c)-[:DERIVED_FROM]->(u:DataColumn)
            WITH c, collect(DISTINCT u.name) AS direct
            OPTIONAL MATCH (c)-[:DERIVED_FROM*1..10]->(o:DataColumn)
            WHERE NOT (o)-[:DERIVED_FROM]->()
            WITH c, direct, collect(DISTINCT {name: o.name, header: o.source_header, table: o.table}) AS origins
            OPTIONAL MATCH (d:DataColumn)-[:DERIVED_FROM]->(c)
            RETURN properties(c) AS column, direct, origins, collect(DISTINCT d.name) AS used_by,
                   coalesce(c.position, 999) AS pos, c.name AS cname
            ORDER BY pos, cname
            """,
            key=table_key,
        )
        out = []
        for r in rows:
            col = {k: v for k, v in dict(r["column"]).items() if k != "repo"}
            col["upstream"] = sorted(r["direct"])
            col["origins"] = [dict(o) for o in r["origins"] if o.get("name")]
            col["used_by"] = sorted(r["used_by"])
            out.append(col)
        return out

    async def _column_trace(self, column_key: str) -> list[dict[str, Any]]:
        rows = await self._graph.execute_read(
            """
            MATCH p = (:RepoGraph {node_key: $key})-[:DERIVED_FROM*1..10]->(o:DataColumn)
            WHERE NOT (o)-[:DERIVED_FROM]->()
            RETURN [n IN nodes(p) | n.name] AS path, o.source_header AS header
            LIMIT 50
            """,
            key=column_key,
        )
        return [{"path": list(r["path"]), "header": r["header"]} for r in rows]

    async def search(self, repo: str, q: str, limit: int = 20) -> list[dict[str, Any]]:
        rows = await self._graph.execute_read(
            """
            MATCH (n:RepoGraph {repo: $repo})
            WHERE toLower(n.name) CONTAINS toLower($q)
            RETURN properties(n) AS props
            ORDER BY CASE n.kind WHEN 'table' THEN 0 WHEN 'source' THEN 1 WHEN 'column' THEN 3 ELSE 2 END, size(n.name)
            LIMIT $limit
            """,
            repo=repo,
            q=q,
            limit=limit,
        )
        return [_payload_node(dict(r["props"])) for r in rows]

    async def declared_tables(self) -> list[dict[str, Any]]:
        """Every table a crawled repository declares, with the tables it derives from: the declared side of lineage."""
        rows = await self._graph.execute_read(
            """
            MATCH (t:DataTable:RepoGraph)
            OPTIONAL MATCH (t)-[:DERIVED_FROM]->(p:DataTable:RepoGraph)
            RETURN t.repo AS repo, t.name AS name, t.layer AS layer, t.catalog AS catalog, t.schema AS schema, t.table AS table,
                   collect(DISTINCT p.name) AS reads
            ORDER BY repo, name
            """
        )
        return [dict(r) for r in rows]

    async def conventions(self) -> list[dict[str, Any]]:
        """Per crawled repository: what a new ingestion pipeline should reuse and imitate."""
        repos = await self._graph.execute_read(
            """
            MATCH (r:Repository:RepoGraph)
            OPTIONAL MATCH (s:Stage:RepoGraph {repo: r.repo})
            OPTIONAL MATCH (s)-[:USES]->(i:StorageIntegration)
            OPTIONAL MATCH (s)-[:USES]->(f:FileFormat)
            OPTIONAL MATCH (s)-[:READS_FROM]->(l:S3Location)
            WITH r, collect(DISTINCT {stage: s.name, integration: i.name, file_format: f.name, format_type: f.format_type, location: l.name}) AS stages
            OPTIONAL MATCH (v:ExternalVolume:RepoGraph {repo: r.repo})
            WITH r, stages, collect(DISTINCT {name: v.name, base_url: v.base_url}) AS volumes
            OPTIONAL MATCH (p:Pipeline:RepoGraph {repo: r.repo})
            RETURN r.repo AS repo, r.ref AS ref, stages, volumes,
                   collect(DISTINCT {name: p.name, mode: p.mode, schedule: p.schedule, layers: p.layers}) AS pipelines
            """
        )
        sources = await self._graph.execute_read(
            """
            MATCH (t:DataTable:RepoGraph)-[:LOADED_FROM]->(s:DataSource)
            RETURN s.repo AS repo, s.name AS source, s.headers AS headers, s.source_path AS path, s.source_system AS system,
                   t.name AS table, t.table_type AS table_type, t.external_volume AS volume, t.load_mode AS load_mode
            """
        )
        tables = await self._graph.execute_read(
            "MATCH (t:DataTable:RepoGraph) RETURN t.repo AS repo, t.name AS name, t.layer AS layer, t.table_type AS table_type"
        )
        by_repo: dict[str, dict[str, Any]] = {}
        for r in repos:
            by_repo[r["repo"]] = {
                "repo": r["repo"],
                "ref": r["ref"],
                "stages": [dict(s) for s in r["stages"] if s.get("stage")],
                "volumes": [dict(v) for v in r["volumes"] if v.get("name")],
                "pipelines": [dict(p) for p in r["pipelines"] if p.get("name")],
                "sources": [],
                "tables": [],
            }
        for s in sources:
            if s["repo"] in by_repo:
                by_repo[s["repo"]]["sources"].append(dict(s))
        for t in tables:
            if t["repo"] in by_repo:
                by_repo[t["repo"]]["tables"].append(dict(t))
        return list(by_repo.values())

    async def exemplar(self, repo: str, table: str) -> dict[str, Any] | None:
        """What a new source modelled on `table` should copy and feed.

        The table's column contract and the quality checks whose subject it is (with their SQL and
        any other tables they join), and every model that reads it directly: that model's files, the
        tables it reads, its columns with their direct upstream columns, and what reads it in turn.
        """
        key = f"{repo}|table|{table}"
        rows = await self._graph.execute_read(
            """
            MATCH (t:DataTable:RepoGraph {node_key: $key})
            OPTIONAL MATCH (r:Repository:RepoGraph {repo: t.repo})
            OPTIONAL MATCH (k:QualityCheck:RepoGraph {repo: t.repo, subject: t.name})
            OPTIONAL MATCH (k)-[:CHECKS]->(o:DataTable) WHERE o <> t
            WITH t, r, k, collect(DISTINCT o.name) AS others
            ORDER BY k.name
            RETURN properties(t) AS table, r.url AS url, r.sha AS sha,
                   [x IN collect(CASE WHEN k IS NULL THEN NULL ELSE {
                       name: k.name, rule: k.rule, column: k.column, sql: k.sql, params: k.params, file: k.file, others: others
                   } END) WHERE x IS NOT NULL] AS checks
            """,
            key=key,
        )
        if not rows:
            return None
        readers = await self._graph.execute_read(
            """
            MATCH (t:DataTable:RepoGraph {node_key: $key})<-[:DERIVED_FROM]-(d:DataTable)
            OPTIONAL MATCH (d)-[:DEFINED_IN]->(f:RepoFile)
            OPTIONAL MATCH (d)-[:DERIVED_FROM]->(u:DataTable)
            WITH d, collect(DISTINCT f.name) AS files, collect(DISTINCT u.name) AS reads
            OPTIONAL MATCH (x:DataTable)-[:DERIVED_FROM*1..10]->(d)
            RETURN d.node_key AS key, d.name AS name, d.layer AS layer, files, reads, collect(DISTINCT x.name) AS affects
            ORDER BY name
            """,
            key=key,
        )
        downstream = []
        for d in readers:
            item = {k: d[k] for k in ("key", "name", "layer")}
            item.update(files=sorted(d["files"]), reads=sorted(d["reads"]), affects=sorted(d["affects"]), columns=await self._columns(d["key"]))
            downstream.append(item)
        head = rows[0]
        return {
            "repo": repo,
            "url": head["url"],
            "sha": head["sha"],
            "table": {k: v for k, v in dict(head["table"]).items() if k != "repo"},
            "columns": await self._columns(key),
            "checks": [dict(c) for c in head["checks"]],
            "downstream": downstream,
        }


class RepoCrawlRepository:
    """Postgres history of crawls (migration 0015)."""

    _COLUMNS = (
        "id, repo, ref, sha, status, phase, files_total, files_read, stats, warnings, error, index_text, "
        "index_run_id, requested_by, created_at, started_at, finished_at"
    )
    _UPDATABLE = {
        "ref": "text", "sha": "text", "status": "text", "phase": "text", "files_total": "integer", "files_read": "integer",
        "stats": "jsonb", "warnings": "jsonb", "error": "text", "index_run_id": "uuid", "started_at": "timestamptz",
        "finished_at": "timestamptz",
    }

    def __init__(self, db: PostgresDatabase) -> None:
        self._db = db

    async def create(self, *, repo: str, ref: str | None, index_text: bool, requested_by: str | None) -> UUID:
        value = await self._db.fetchval(
            "INSERT INTO repo_crawls (repo, ref, index_text, requested_by) VALUES ($1, $2, $3, $4) RETURNING id",
            repo,
            ref,
            index_text,
            requested_by,
        )
        return UUID(str(value))

    async def update(self, crawl_id: UUID, **fields: Any) -> None:
        sets: list[str] = []
        args: list[Any] = [crawl_id]
        for name, value in fields.items():
            cast = self._UPDATABLE.get(name)
            if cast is None:
                raise ValueError(f"repo_crawls.{name} is not updatable")
            args.append(value)
            sets.append(f"{name} = ${len(args)}::{cast}")
        if sets:
            await self._db.execute(f"UPDATE repo_crawls SET {', '.join(sets)} WHERE id = $1", *args)

    async def get(self, crawl_id: UUID) -> dict[str, Any] | None:
        row = await self._db.fetchrow(f"SELECT {self._COLUMNS} FROM repo_crawls WHERE id = $1", crawl_id)
        return dict(row) if row else None

    async def list(self, *, repo: str | None = None, limit: int = 20) -> list[dict[str, Any]]:
        if repo:
            rows = await self._db.fetch(
                f"SELECT {self._COLUMNS} FROM repo_crawls WHERE lower(repo) = lower($1) ORDER BY created_at DESC LIMIT $2", repo, limit
            )
        else:
            rows = await self._db.fetch(f"SELECT {self._COLUMNS} FROM repo_crawls ORDER BY created_at DESC LIMIT $1", limit)
        return [dict(r) for r in rows]

    async def active(self, repo: str) -> dict[str, Any] | None:
        row = await self._db.fetchrow(
            f"SELECT {self._COLUMNS} FROM repo_crawls WHERE lower(repo) = lower($1) AND status IN ('queued', 'running') "
            "ORDER BY created_at DESC LIMIT 1",
            repo,
        )
        return dict(row) if row else None

    async def fail_stale(self, reason: str, now: datetime) -> int:
        result = await self._db.execute(
            "UPDATE repo_crawls SET status = 'failed', phase = 'failed', error = $1, finished_at = $2 WHERE status IN ('queued', 'running')",
            reason,
            now,
        )
        tail = result.split()[-1] if result else "0"
        return int(tail) if tail.isdigit() else 0
