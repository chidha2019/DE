"""Postgres access for line of business (migration 0018): the term's values, the sync's inputs, the result."""

from __future__ import annotations

import json
from typing import Any
from uuid import UUID

from ech_core.db.postgres import PostgresDatabase
from ech_core.semantic.lines import LineEvidence, LineValue, LineVocabulary

LINE_TERM = "line_of_business"
# What a dataset inherits along: what it references and what it is built from.
INHERIT_KINDS = ("foreign_key", "join_declared", "lineage_upstream")


def _list(value: Any) -> list[str]:
    if isinstance(value, str):
        value = json.loads(value or "[]")
    return [str(v) for v in value or []]


class LinesRepository:
    def __init__(self, db: PostgresDatabase) -> None:
        self._db = db

    async def values(self) -> list[dict[str, Any]]:
        rows = await self._db.fetch(
            "SELECT key, name, description, aliases, sort_order FROM semantic_term_values WHERE term_key = $1 ORDER BY sort_order, name",
            LINE_TERM,
        )
        return [{**dict(r), "aliases": _list(r["aliases"])} for r in rows]

    async def vocabulary(self) -> LineVocabulary:
        term = await self._db.fetchrow("SELECT name, synonyms FROM semantic_terms WHERE key = $1", LINE_TERM)
        names = [term["name"], *_list(term["synonyms"])] if term else []
        values = [LineValue(v["key"], v["name"], tuple(v["aliases"])) for v in await self.values()]
        return LineVocabulary(values=values, names=names)

    async def inputs(self, source_system: str) -> dict[str, Any]:
        """Datasets of one source with their tags, columns, parents and the columns linked to the term."""
        assets = await self._db.fetch(
            "SELECT id, fqn, tags FROM semantic_assets WHERE source_system::text = $1 ORDER BY fqn", source_system
        )
        ids = [a["id"] for a in assets]
        fields = await self._db.fetch(
            "SELECT id, asset_id, name, tags FROM semantic_fields WHERE asset_id = ANY($1::uuid[]) ORDER BY asset_id, ordinal", ids
        )
        edges = await self._db.fetch(
            """
            SELECT source_asset_id, target_asset_id FROM semantic_relationships
             WHERE source_asset_id = ANY($1::uuid[]) AND target_asset_id IS NOT NULL AND kind = ANY($2::text[])
            """,
            ids,
            list(INHERIT_KINDS),
        )
        linked = await self._db.fetch(
            """
            SELECT l.target_id FROM semantic_term_links l JOIN semantic_terms t ON t.id = l.term_id
             WHERE t.key = $1 AND l.target_type = 'field' AND l.status = 'accepted'
            """,
            LINE_TERM,
        )
        return {
            "assets": [{"id": a["id"], "fqn": a["fqn"], "tags": _list(a["tags"])} for a in assets],
            "fields": [{"id": f["id"], "asset_id": f["asset_id"], "name": f["name"], "tags": _list(f["tags"])} for f in fields],
            "edges": [(e["source_asset_id"], e["target_asset_id"]) for e in edges],
            "linked": {r["target_id"] for r in linked},
        }

    async def pipeline_defaults(self, source_system: str) -> list[dict[str, Any]]:
        rows = await self._db.fetch(
            """
            SELECT name, line_of_business, scope FROM pipelines
             WHERE source_system::text = $1 AND line_of_business IS NOT NULL AND line_of_business <> ''
            """,
            source_system,
        )
        out = []
        for r in rows:
            scope = r["scope"] if not isinstance(r["scope"], str) else json.loads(r["scope"] or "[]")
            out.append({"name": r["name"], "line": r["line_of_business"], "paths": [list(i.get("path") or []) for i in scope or []]})
        return out

    async def replace(self, source_system: str, lines: dict[UUID, LineEvidence]) -> int:
        """The source's datasets get exactly these lines; earlier answers for them are dropped."""
        rows = [(asset_id, key, ev.source, ev.evidence[:500]) for asset_id, ev in lines.items() for key in sorted(ev.lines)]
        async with self._db.transaction() as conn:
            await conn.execute(
                """
                DELETE FROM semantic_asset_lines l USING semantic_assets a
                 WHERE a.id = l.asset_id AND a.source_system::text = $1
                """,
                source_system,
            )
            if rows:
                await conn.executemany(
                    "INSERT INTO semantic_asset_lines (asset_id, line_key, source, evidence) VALUES ($1, $2, $3, $4)", rows
                )
        return len(rows)
