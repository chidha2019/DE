"""Append-only audit trail."""

from __future__ import annotations

from typing import Any

from ech_core.db.postgres import PostgresDatabase
from ech_core.domain.models import AuditRecord
from ech_core.schemas.stats import LatencyPoint


class AuditRepository:
    def __init__(self, db: PostgresDatabase) -> None:
        self._db = db

    async def record(
        self,
        *,
        action: str,
        status: str = "ok",
        actor: str | None = None,
        resource_type: str | None = None,
        resource_id: str | None = None,
        request_id: str | None = None,
        latency_ms: float | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        await self._db.execute(
            """
            INSERT INTO audit_logs
                (request_id, actor, action, resource_type, resource_id, status, latency_ms, details)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8::jsonb)
            """,
            request_id,
            actor,
            action,
            resource_type,
            resource_id,
            status,
            latency_ms,
            details or {},
        )

    async def recent(
        self, *, limit: int = 50, action: str | None = None, status: str | None = None
    ) -> list[AuditRecord]:
        clauses: list[str] = []
        args: list[Any] = []
        if action:
            args.append(action)
            clauses.append(f"action = ${len(args)}")
        if status:
            args.append(status)
            clauses.append(f"status = ${len(args)}")
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        args.append(limit)
        rows = await self._db.fetch(
            f"SELECT * FROM audit_logs {where} ORDER BY id DESC LIMIT ${len(args)}", *args
        )
        return [AuditRecord.from_row(r) for r in rows]

    async def count_since(self, *, action: str, hours: int) -> int:
        return int(
            await self._db.fetchval(
                "SELECT count(*) FROM audit_logs WHERE action = $1 "
                "AND created_at >= now() - make_interval(hours => $2)",
                action,
                hours,
            )
            or 0
        )

    async def p95_since(self, *, action: str, hours: int) -> float | None:
        value = await self._db.fetchval(
            "SELECT percentile_cont(0.95) WITHIN GROUP (ORDER BY latency_ms) FROM audit_logs "
            "WHERE action = $1 AND latency_ms IS NOT NULL "
            "AND created_at >= now() - make_interval(hours => $2)",
            action,
            hours,
        )
        return round(float(value), 3) if value is not None else None

    async def latency_series(
        self, *, action: str, window_minutes: int = 60, bucket_seconds: int = 60
    ) -> list[LatencyPoint]:
        """Persisted percentiles per time bucket (survives restarts)."""
        rows = await self._db.fetch(
            """
            SELECT date_bin(make_interval(secs => $3), created_at, to_timestamp(0)) AS bucket,
                   count(*)::int AS count,
                   percentile_cont(0.50) WITHIN GROUP (ORDER BY latency_ms) AS p50,
                   percentile_cont(0.95) WITHIN GROUP (ORDER BY latency_ms) AS p95,
                   percentile_cont(0.99) WITHIN GROUP (ORDER BY latency_ms) AS p99,
                   avg(latency_ms) AS avg,
                   (count(*) FILTER (WHERE status <> 'ok'))::float8 / count(*) AS error_rate
              FROM audit_logs
             WHERE action = $1 AND latency_ms IS NOT NULL
               AND created_at >= now() - make_interval(mins => $2)
             GROUP BY 1 ORDER BY 1
            """,
            action,
            window_minutes,
            bucket_seconds,
        )
        return [
            LatencyPoint(
                bucket_start=r["bucket"],
                count=r["count"],
                p50_ms=round(float(r["p50"] or 0), 3),
                p95_ms=round(float(r["p95"] or 0), 3),
                p99_ms=round(float(r["p99"] or 0), 3),
                avg_ms=round(float(r["avg"] or 0), 3),
                error_rate=round(float(r["error_rate"] or 0), 4),
            )
            for r in rows
        ]

    async def request_rollup(self, *, hours: int) -> list[dict[str, Any]]:
        """Requests, errors and latency percentiles per audited action in the window."""
        rows = await self._db.fetch(
            """
            SELECT action,
                   count(*)::int AS requests,
                   count(*) FILTER (WHERE status <> 'ok')::int AS errors,
                   percentile_cont(0.5) WITHIN GROUP (ORDER BY latency_ms) AS p50_ms,
                   percentile_cont(0.95) WITHIN GROUP (ORDER BY latency_ms) AS p95_ms,
                   percentile_cont(0.99) WITHIN GROUP (ORDER BY latency_ms) AS p99_ms,
                   avg(latency_ms) AS avg_ms
              FROM audit_logs
             WHERE created_at >= now() - make_interval(hours => $1)
             GROUP BY action
             ORDER BY requests DESC
            """,
            hours,
        )
        return [dict(r) for r in rows]

    async def rows_per_day(self, *, days: int) -> float:
        value = await self._db.fetchval(
            "SELECT count(*)::float / $1::float FROM audit_logs "
            "WHERE created_at >= now() - make_interval(days => $2)",
            days,
            days,
        )
        return round(float(value or 0), 1)
