"""Postgres access for intents (migration 0013)."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from ech_core.db.postgres import PostgresDatabase

_COLUMNS = """
    id, source, jira_key, jira_url, title, text, reporter, status, intent, questions, answers, spec,
    spec_markdown, coder, branch, pr_url, error, posted, validation, route, run, created_at, updated_at, decided_at
"""
_JSON = ("intent", "questions", "answers", "spec", "coder", "posted", "validation", "route", "run")


def _entries(value: Any) -> list[dict[str, Any]]:
    """The posted log as a list of objects; entries an older append stored as JSON text are unpacked."""
    out: list[dict[str, Any]] = []
    for item in value if isinstance(value, list) else []:
        if isinstance(item, str):
            try:
                item = json.loads(item)
            except ValueError:
                continue
        if isinstance(item, dict):
            out.append(item)
        elif isinstance(item, list):
            out += _entries(item)
    return out


def _row(record: Any) -> dict[str, Any]:
    row = dict(record)
    for key in _JSON:
        value = row.get(key)
        if isinstance(value, str):
            try:
                row[key] = json.loads(value)
            except ValueError:
                row[key] = None
    if "posted" in row:
        row["posted"] = _entries(row["posted"])
    return row


class IntentRepository:
    def __init__(self, db: PostgresDatabase) -> None:
        self._db = db

    async def turnaround(self, *, days: int) -> dict[str, Any]:
        """Requests waiting on clarification (and their questions) now, and the median hours from
        arrival to an approve/reject decision for requests decided in the window."""
        row = await self._db.fetchrow(
            """
            SELECT count(*) FILTER (WHERE status = 'clarifying')::int AS clarifying,
                   coalesce(sum(jsonb_array_length(questions)) FILTER (WHERE status = 'clarifying'), 0)::int
                       AS questions,
                   count(*) FILTER (WHERE decided_at >= now() - make_interval(days => $1))::int AS decided,
                   percentile_cont(0.5) WITHIN GROUP (ORDER BY extract(epoch FROM decided_at - created_at) / 3600.0)
                       FILTER (WHERE decided_at >= now() - make_interval(days => $1)) AS decision_h
            FROM intents
            """,
            days,
        )
        return dict(row) if row else {}

    async def list(self, *, status: str | None, limit: int, offset: int) -> tuple[list[dict[str, Any]], int]:
        args: list[Any] = []
        where = ""
        if status:
            args.append(status)
            where = "WHERE status = $1"
        total = await self._db.fetchval(f"SELECT count(*) FROM intents {where}", *args)
        rows = await self._db.fetch(
            f"SELECT {_COLUMNS} FROM intents {where} ORDER BY created_at DESC LIMIT ${len(args) + 1} OFFSET ${len(args) + 2}",
            *args,
            limit,
            offset,
        )
        return [_row(r) for r in rows], int(total or 0)

    async def get(self, intent_id: UUID) -> dict[str, Any] | None:
        row = await self._db.fetchrow(f"SELECT {_COLUMNS} FROM intents WHERE id = $1", intent_id)
        return _row(row) if row else None

    async def by_jira_key(self, key: str) -> dict[str, Any] | None:
        row = await self._db.fetchrow(f"SELECT {_COLUMNS} FROM intents WHERE jira_key = $1", key)
        return _row(row) if row else None

    async def create(
        self, *, source: str, title: str, text: str, reporter: str, jira_key: str | None = None, jira_url: str | None = None
    ) -> dict[str, Any]:
        row = await self._db.fetchrow(
            """
            INSERT INTO intents (source, jira_key, jira_url, title, text, reporter)
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING id
            """,
            source,
            jira_key,
            jira_url,
            title,
            text,
            reporter,
        )
        assert row is not None
        found = await self.get(row["id"])
        assert found is not None
        return found

    async def update(self, intent_id: UUID, **fields: Any) -> dict[str, Any] | None:
        """Set columns by name; JSON columns take Python values."""
        sets: list[str] = ["updated_at = now()"]
        args: list[Any] = []
        for column, value in fields.items():
            args.append(json.dumps(value, default=str) if column in _JSON else value)
            sets.append(f"{column} = ${len(args)}" + ("::jsonb" if column in _JSON else ""))
        args.append(intent_id)
        await self._db.execute(f"UPDATE intents SET {', '.join(sets)} WHERE id = ${len(args)}", *args)
        return await self.get(intent_id)

    async def decide(self, intent_id: UUID, status: str, **fields: Any) -> dict[str, Any] | None:
        return await self.update(intent_id, status=status, decided_at=datetime.now(tz=UTC), **fields)

    async def append_posted(self, intent_id: UUID, entry: dict[str, Any]) -> None:
        """Add one entry to the posted log, written like every other JSON column (an in-SQL || appended it as text)."""
        row = await self.get(intent_id)
        if row is not None:
            await self.update(intent_id, posted=[*row["posted"], entry])

    async def by_status(self, status: str) -> list[dict[str, Any]]:
        rows = await self._db.fetch(f"SELECT {_COLUMNS} FROM intents WHERE status = $1 ORDER BY created_at", status)
        return [_row(r) for r in rows]

    async def counts(self) -> dict[str, int]:
        rows = await self._db.fetch("SELECT status, count(*)::int AS n FROM intents GROUP BY status")
        return {r["status"]: r["n"] for r in rows}
