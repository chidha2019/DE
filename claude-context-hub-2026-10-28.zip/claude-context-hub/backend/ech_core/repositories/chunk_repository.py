"""Postgres access for ``chunks`` including the full-text (keyword) search leg."""

from __future__ import annotations

import re
from typing import Any
from uuid import UUID

import asyncpg

from ech_core.db.postgres import PostgresDatabase
from ech_core.domain.enums import SourceSystem
from ech_core.domain.models import ChunkRecord, ChunkWithDocument, ScoredChunk
from ech_core.text import STOPWORDS

_TERM_RE = re.compile(r"[A-Za-z0-9]+")
_MAX_TERMS = 24


def keyword_terms(query: str) -> list[str]:
    """Distinct, lower-cased alphanumeric terms safe to join into a ``to_tsquery`` string."""
    seen: dict[str, None] = {}
    for term in _TERM_RE.findall(query.lower()):
        if len(term) > 1 and term not in STOPWORDS:
            seen.setdefault(term, None)
    return list(seen)[:_MAX_TERMS]


_CHUNK_COLUMNS = """
    c.id, c.document_id, c.chunk_index, c.content, c.token_count, c.char_start, c.char_end,
    c.section_path, c.metadata, c.created_at
"""

_INSERT_SQL = """
INSERT INTO chunks (id, document_id, chunk_index, content, token_count, char_start, char_end,
                    section_path, metadata)
VALUES ($1, $2, $3, $4, $5, $6, $7, $8::text[], $9::jsonb)
"""


def document_filter_sql(
    *,
    next_param: int,
    source_systems: list[SourceSystem] | None,
    document_ids: list[UUID] | None,
    attributes: dict[str, Any] | None,
) -> tuple[str, list[Any], int]:
    """Build the shared WHERE fragment for both retrieval legs.

    Returns ``(sql, args, next_param)``. ``d`` must alias ``documents``.
    """
    clauses = ["d.deleted_at IS NULL"]
    args: list[Any] = []
    n = next_param
    if source_systems:
        clauses.append(f"d.source_system::text = ANY(${n}::text[])")
        args.append([s.value for s in source_systems])
        n += 1
    if document_ids:
        clauses.append(f"d.id = ANY(${n}::uuid[])")
        args.append(list(document_ids))
        n += 1
    if attributes:
        clauses.append(f"d.attributes @> ${n}::jsonb")
        args.append(attributes)
        n += 1
    return " AND ".join(clauses), args, n


class ChunkRepository:
    def __init__(self, db: PostgresDatabase) -> None:
        self._db = db

    # ------------------------------------------------------------------ writes
    async def replace_for_document(
        self, conn: asyncpg.Connection, document_id: UUID, chunks: list[ChunkRecord]
    ) -> None:
        """Atomically replace all chunks of a document (embeddings cascade)."""
        await conn.execute("DELETE FROM chunks WHERE document_id = $1", document_id)
        if not chunks:
            return
        await conn.executemany(
            _INSERT_SQL,
            [
                (
                    c.id,
                    c.document_id,
                    c.chunk_index,
                    c.content,
                    c.token_count,
                    c.char_start,
                    c.char_end,
                    c.section_path,
                    c.metadata,
                )
                for c in chunks
            ],
        )

    # ------------------------------------------------------------------ reads
    async def list_for_document(self, document_id: UUID) -> list[ChunkRecord]:
        rows = await self._db.fetch(
            f"SELECT {_CHUNK_COLUMNS} FROM chunks c WHERE c.document_id = $1 "
            "ORDER BY c.chunk_index",
            document_id,
        )
        return [ChunkRecord.from_row(r) for r in rows]

    async def get_many_with_documents(self, chunk_ids: list[UUID]) -> list[ChunkWithDocument]:
        if not chunk_ids:
            return []
        rows = await self._db.fetch(
            f"""
            SELECT {_CHUNK_COLUMNS},
                   d.title AS document_title, d.source_system::text AS source_system, d.uri,
                   d.attributes AS document_attributes
              FROM chunks c
              JOIN documents d ON d.id = c.document_id
             WHERE c.id = ANY($1::uuid[]) AND d.deleted_at IS NULL
            """,
            list(chunk_ids),
        )
        return [ChunkWithDocument.from_row(r) for r in rows]

    async def count(self) -> int:
        return int(await self._db.fetchval("SELECT count(*) FROM chunks") or 0)

    async def keyword_search(
        self,
        query: str,
        *,
        limit: int,
        source_systems: list[SourceSystem] | None = None,
        document_ids: list[UUID] | None = None,
        attributes: dict[str, Any] | None = None,
    ) -> list[ScoredChunk]:
        """BM25-style lexical leg using Postgres full-text search.

        Natural-language questions are turned into an OR query of stemmed,
        stopword-free terms (``bronze | layer | quality | check``): an AND query
        (what ``websearch_to_tsquery`` builds) almost never matches a 7-term
        question. ``ts_rank_cd`` then rewards chunks covering more terms, and
        normalisation ``1|32`` divides by ``1 + log(doc_len)`` (BM25's length
        penalty) and maps the result into ``[0, 1)`` via ``rank / (rank + 1)``.
        """
        terms = keyword_terms(query)
        if not terms:
            return []
        where, args, n = document_filter_sql(
            next_param=2,
            source_systems=source_systems,
            document_ids=document_ids,
            attributes=attributes,
        )
        rows = await self._db.fetch(
            f"""
            WITH q AS (SELECT to_tsquery('english', $1) AS tsq)
            SELECT c.id AS chunk_id, c.document_id,
                   ts_rank_cd(c.content_tsv, q.tsq, 1 | 32)::float8 AS score
              FROM chunks c
              JOIN documents d ON d.id = c.document_id
              CROSS JOIN q
             WHERE c.content_tsv @@ q.tsq AND {where}
             ORDER BY score DESC, c.id
             LIMIT ${n}
            """,
            " | ".join(terms),
            *args,
            limit,
        )
        return [ScoredChunk(**dict(r)) for r in rows]
