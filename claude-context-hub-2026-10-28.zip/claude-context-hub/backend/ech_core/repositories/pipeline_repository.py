"""Postgres access for pipeline definitions (migration 0014)."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from ech_core.db.postgres import PostgresDatabase
from ech_core.domain.enums import SourceSystem

_SELECT = """
    SELECT p.id, p.name, p.description, p.connector_name, p.source_system::text AS source_system,
           p.scope, p.options, p.source_options, p.schedule, p.enabled, p.owner, p.tags, p.line_of_business,
           p.next_run_at, p.created_by, p.created_at, p.updated_at,
           lr.id AS lr_id, lr.status::text AS lr_status, lr.triggered_by AS lr_triggered_by,
           lr.started_at AS lr_started_at, lr.finished_at AS lr_finished_at,
           lr.created_at AS lr_created_at, lr.stats AS lr_stats, lr.error AS lr_error,
           (SELECT count(*) FROM ingestion_runs r WHERE r.pipeline_id = p.id)::int AS runs_total,
           (SELECT count(*) FROM ingestion_runs r
             WHERE r.pipeline_id = p.id AND r.status = 'failed')::int AS runs_failed
      FROM pipelines p
      LEFT JOIN LATERAL (
          SELECT r.id, r.status, r.triggered_by, r.started_at, r.finished_at, r.created_at,
                 r.stats, r.error
            FROM ingestion_runs r WHERE r.pipeline_id = p.id
           ORDER BY r.created_at DESC LIMIT 1
      ) lr ON true
"""

_UPDATABLE = {
    "name": "text",
    "description": "text",
    "scope": "jsonb",
    "options": "jsonb",
    "source_options": "jsonb",
    "schedule": "jsonb",
    "enabled": "boolean",
    "owner": "text",
    "tags": "jsonb",
    "line_of_business": "text",
    "next_run_at": "timestamptz",
}


class PipelineRepository:
    def __init__(self, db: PostgresDatabase) -> None:
        self._db = db

    async def create(
        self,
        *,
        name: str,
        description: str,
        connector_name: str,
        source_system: SourceSystem,
        scope: list[dict[str, Any]],
        options: dict[str, Any],
        source_options: dict[str, Any],
        schedule: dict[str, Any],
        enabled: bool,
        owner: str,
        tags: list[str],
        next_run_at: datetime | None,
        created_by: str | None,
        line_of_business: str | None = None,
    ) -> UUID:
        value = await self._db.fetchval(
            """
            INSERT INTO pipelines (name, description, connector_name, source_system, scope, options,
                                   source_options, schedule, enabled, owner, tags, next_run_at,
                                   created_by, line_of_business)
            VALUES ($1, $2, $3, $4::source_system, $5::jsonb, $6::jsonb, $7::jsonb, $8::jsonb,
                    $9, $10, $11::jsonb, $12, $13, $14)
            RETURNING id
            """,
            name,
            description,
            connector_name,
            source_system.value,
            scope,
            options,
            source_options,
            schedule,
            enabled,
            owner,
            tags,
            next_run_at,
            created_by,
            line_of_business,
        )
        return UUID(str(value))

    async def get(self, pipeline_id: UUID) -> dict[str, Any] | None:
        row = await self._db.fetchrow(f"{_SELECT} WHERE p.id = $1", pipeline_id)
        return dict(row) if row else None

    async def list(
        self, *, connector_name: str | None = None, search: str | None = None
    ) -> list[dict[str, Any]]:
        clauses: list[str] = []
        args: list[Any] = []
        if connector_name:
            args.append(connector_name)
            clauses.append(f"p.connector_name = ${len(args)}")
        if search and search.strip():
            args.append(search.strip())
            clauses.append(
                f"(p.name ILIKE '%' || ${len(args)} || '%' OR p.description ILIKE '%' || ${len(args)} || '%')"
            )
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        rows = await self._db.fetch(f"{_SELECT} {where} ORDER BY lower(p.name)", *args)
        return [dict(r) for r in rows]

    async def name_taken(self, name: str, *, except_id: UUID | None = None) -> bool:
        found = await self._db.fetchval(
            "SELECT id FROM pipelines WHERE lower(name) = lower($1) AND ($2::uuid IS NULL OR id <> $2)",
            name,
            except_id,
        )
        return found is not None

    async def update(self, pipeline_id: UUID, **fields: Any) -> bool:
        sets: list[str] = []
        args: list[Any] = [pipeline_id]
        for key, value in fields.items():
            cast = _UPDATABLE.get(key)
            if cast is None:
                raise ValueError(f"pipeline field {key!r} cannot be updated")
            args.append(value)
            sets.append(f"{key} = ${len(args)}::{cast}")
        if not sets:
            return True
        result = await self._db.execute(f"UPDATE pipelines SET {', '.join(sets)} WHERE id = $1", *args)
        return not str(result).endswith(" 0")

    async def delete(self, pipeline_id: UUID) -> bool:
        result = await self._db.execute("DELETE FROM pipelines WHERE id = $1", pipeline_id)
        return not str(result).endswith(" 0")

    async def due(self, now: datetime, *, limit: int = 50) -> list[dict[str, Any]]:
        rows = await self._db.fetch(
            f"{_SELECT} WHERE p.enabled AND p.next_run_at IS NOT NULL AND p.next_run_at <= $1 "
            "ORDER BY p.next_run_at LIMIT $2",
            now,
            limit,
        )
        return [dict(r) for r in rows]

    async def set_next_run(self, pipeline_id: UUID, next_run_at: datetime | None) -> None:
        await self._db.execute(
            "UPDATE pipelines SET next_run_at = $2 WHERE id = $1", pipeline_id, next_run_at
        )
