"""Postgres-level facts for the SRE workspace: table sizes and database size."""

from __future__ import annotations

from typing import Any

from ech_core.db.postgres import PostgresDatabase


class PlatformRepository:
    def __init__(self, db: PostgresDatabase) -> None:
        self._db = db

    async def table_sizes(self) -> list[dict[str, Any]]:
        """Row estimates and on-disk size (heap, indexes, TOAST) per hub table.

        ``n_live_tup`` is the cumulative-stats figure and ``reltuples`` the planner's; whichever
        is larger is the better estimate (both are 0 or -1 before the first ANALYZE).
        """
        rows = await self._db.fetch(
            """
            SELECT s.relname AS "table",
                   greatest(s.n_live_tup, c.reltuples, 0)::bigint AS rows,
                   pg_total_relation_size(s.relid)::bigint AS bytes
              FROM pg_stat_user_tables s
              JOIN pg_class c ON c.oid = s.relid
             WHERE s.schemaname NOT IN ('pg_catalog', 'information_schema')
             ORDER BY bytes DESC, s.relname
            """
        )
        return [dict(r) for r in rows]

    async def database_bytes(self) -> int:
        return int(await self._db.fetchval("SELECT pg_database_size(current_database())") or 0)
