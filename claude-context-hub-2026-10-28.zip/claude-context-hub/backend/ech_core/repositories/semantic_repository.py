"""Postgres access for the semantic layer (migration 0005)."""

from __future__ import annotations

import re
from collections import defaultdict
from typing import Any
from uuid import UUID

import asyncpg

from ech_core.db.postgres import PostgresDatabase
from ech_core.domain.enums import SourceSystem
from ech_core.semantic.models import (
    AssetKind,
    AssetType,
    FieldRole,
    MetricSource,
    Platform,
    RelationshipKind,
    SemanticAsset,
    SemanticField,
    SemanticMetric,
    SemanticRelationship,
)

_ASSET_COLUMNS = """
    a.id, a.document_id, a.source_system::text AS source_system, a.platform, a.fqn,
    a.database_name, a.schema_name, a.name, a.asset_type, a.kind, a.description, a.owner,
    a.display_name, a.summary, a.name_source, a.kind_source, a.enrichment,
    a.tags, a.properties, a.definition, a.uri, a.field_count, a.row_count, a.bytes,
    a.source_created_at, a.source_updated_at, a.synced_at, a.updated_at,
    (SELECT count(*) FROM semantic_metrics m WHERE m.asset_id = a.id)::int AS metric_count,
    (SELECT count(*) FROM semantic_relationships r
      WHERE r.source_asset_id = a.id OR r.target_asset_id = a.id)::int AS relationship_count
"""

_RELATIONSHIP_SQL = """
    SELECT r.id, r.source_asset_id, r.target_asset_id, r.target_fqn, r.kind, r.source_columns,
           r.target_columns, r.confidence, r.evidence, 'out' AS direction,
           t.id AS other_asset_id, COALESCE(t.fqn, r.target_fqn) AS other_fqn,
           t.name AS other_name, t.asset_type AS other_asset_type, t.kind AS other_kind
    FROM semantic_relationships r
    LEFT JOIN semantic_assets t ON t.id = r.target_asset_id
    WHERE r.source_asset_id = $1
    UNION ALL
    SELECT r.id, r.source_asset_id, r.target_asset_id, r.target_fqn, r.kind, r.source_columns,
           r.target_columns, r.confidence, r.evidence, 'in' AS direction,
           s.id AS other_asset_id, s.fqn AS other_fqn,
           s.name AS other_name, s.asset_type AS other_asset_type, s.kind AS other_kind
    FROM semantic_relationships r
    JOIN semantic_assets s ON s.id = r.source_asset_id
    WHERE r.target_asset_id = $1
    ORDER BY direction, kind, other_fqn
"""


class SemanticRepository:
    def __init__(self, db: PostgresDatabase) -> None:
        self._db = db

    # ------------------------------------------------------------------ writes
    async def upsert_asset(
        self,
        conn: asyncpg.Connection,
        *,
        document_id: UUID,
        source_system: SourceSystem,
        asset: SemanticAsset,
    ) -> UUID:
        """Replace the asset and all its fields / relationships / metrics (same transaction)."""
        await conn.execute(
            """
            INSERT INTO semantic_assets AS a (
                id, document_id, source_system, platform, fqn, database_name, schema_name, name,
                asset_type, kind, description, owner, tags, properties, definition, uri,
                field_count, row_count, bytes, source_created_at, source_updated_at, synced_at,
                display_name, summary, name_source, kind_source
            ) VALUES (
                $1, $1, $2::source_system, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12::jsonb,
                $13::jsonb, $14, $15, $16, $17, $18, $19, $20, now(), $21, $22, $23, $24
            )
            ON CONFLICT (id) DO UPDATE SET
                platform = EXCLUDED.platform, fqn = EXCLUDED.fqn,
                database_name = EXCLUDED.database_name, schema_name = EXCLUDED.schema_name,
                name = EXCLUDED.name, asset_type = EXCLUDED.asset_type,
                -- a sync never overwrites what a model suggested and a person accepted
                kind = CASE WHEN a.kind_source IN ('model', 'curated') THEN a.kind
                            ELSE EXCLUDED.kind END,
                kind_source = CASE WHEN a.kind_source IN ('model', 'curated') THEN a.kind_source
                                   ELSE EXCLUDED.kind_source END,
                display_name = CASE WHEN a.name_source IN ('model', 'curated') THEN a.display_name
                                    ELSE EXCLUDED.display_name END,
                summary = CASE WHEN a.name_source IN ('model', 'curated') THEN a.summary
                               ELSE EXCLUDED.summary END,
                name_source = CASE WHEN a.name_source IN ('model', 'curated') THEN a.name_source
                                   ELSE EXCLUDED.name_source END,
                description = EXCLUDED.description, owner = EXCLUDED.owner, tags = EXCLUDED.tags,
                properties = EXCLUDED.properties, definition = EXCLUDED.definition,
                uri = EXCLUDED.uri, field_count = EXCLUDED.field_count,
                row_count = EXCLUDED.row_count, bytes = EXCLUDED.bytes,
                source_created_at = EXCLUDED.source_created_at,
                source_updated_at = EXCLUDED.source_updated_at, synced_at = now()
            """,
            document_id,
            source_system.value,
            asset.platform.value,
            asset.fqn,
            asset.database,
            asset.schema_name,
            asset.name,
            asset.asset_type.value,
            asset.kind.value,
            asset.description,
            asset.owner,
            asset.tags,
            asset.properties,
            asset.definition,
            asset.uri,
            len(asset.fields),
            asset.row_count,
            asset.bytes,
            asset.source_created_at,
            asset.source_updated_at,
            asset.display_name,
            asset.summary,
            asset.name_source,
            asset.kind_source,
        )
        # Columns are upserted by name so their ids stay stable across syncs: glossary term links
        # point at them and accepted synonyms live on them. Only columns gone from the source go.
        await conn.execute(
            "DELETE FROM semantic_fields WHERE asset_id = $1 AND NOT (name = ANY($2::text[]))",
            document_id,
            [f.name for f in asset.fields],
        )
        if asset.fields:
            await conn.executemany(
                """
                INSERT INTO semantic_fields (
                    asset_id, name, ordinal, data_type, description, nullable, is_primary_key,
                    is_partition, role, role_confidence, aggregation, tags, synonyms, display_name
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12::jsonb, $13::jsonb, $14)
                ON CONFLICT (asset_id, name) DO UPDATE SET
                    ordinal = EXCLUDED.ordinal, data_type = EXCLUDED.data_type,
                    description = EXCLUDED.description, nullable = EXCLUDED.nullable,
                    is_primary_key = EXCLUDED.is_primary_key, is_partition = EXCLUDED.is_partition,
                    role = EXCLUDED.role, role_confidence = EXCLUDED.role_confidence,
                    aggregation = EXCLUDED.aggregation, tags = EXCLUDED.tags,
                    synonyms = (SELECT coalesce(jsonb_agg(DISTINCT v), '[]'::jsonb)
                                  FROM jsonb_array_elements(semantic_fields.synonyms || EXCLUDED.synonyms) v),
                    display_name = CASE WHEN semantic_fields.display_name <> '' THEN semantic_fields.display_name
                                        ELSE EXCLUDED.display_name END
                """,
                [
                    (
                        document_id,
                        f.name,
                        f.ordinal,
                        f.data_type,
                        f.description,
                        f.nullable,
                        f.is_primary_key,
                        f.is_partition,
                        f.role.value,
                        float(f.role_confidence),
                        f.aggregation,
                        f.tags,
                        f.synonyms,
                        f.display_name,
                    )
                    for f in asset.fields
                ],
            )
        await conn.execute(
            "DELETE FROM semantic_relationships WHERE source_asset_id = $1 AND kind <> 'join_inferred'",
            document_id,
        )
        await self._insert_relationships(conn, document_id, source_system, asset.relationships)
        # Metrics likewise keep their ids; curated ones are never overwritten by the catalog.
        await conn.execute(
            "DELETE FROM semantic_metrics WHERE asset_id = $1 AND source <> 'curated' AND NOT (name = ANY($2::text[]))",
            document_id,
            [m.name for m in asset.metrics],
        )
        if asset.metrics:
            await conn.executemany(
                """
                INSERT INTO semantic_metrics (
                    asset_id, name, expression, aggregation, description, source, dimensions,
                    fields, synonyms, display_name
                ) VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb, $8::jsonb, $9::jsonb, $10)
                ON CONFLICT (asset_id, name) DO UPDATE SET
                    expression = EXCLUDED.expression, aggregation = EXCLUDED.aggregation,
                    description = EXCLUDED.description, source = EXCLUDED.source,
                    dimensions = EXCLUDED.dimensions, fields = EXCLUDED.fields,
                    synonyms = (SELECT coalesce(jsonb_agg(DISTINCT v), '[]'::jsonb)
                                  FROM jsonb_array_elements(semantic_metrics.synonyms || EXCLUDED.synonyms) v),
                    display_name = CASE WHEN semantic_metrics.display_name <> '' THEN semantic_metrics.display_name
                                        ELSE EXCLUDED.display_name END
                WHERE semantic_metrics.source <> 'curated'
                """,
                [
                    (
                        document_id,
                        m.name,
                        m.expression,
                        m.aggregation,
                        m.description,
                        m.source.value,
                        m.dimensions,
                        m.fields,
                        m.synonyms,
                        m.display_name,
                    )
                    for m in asset.metrics
                ],
            )
        return document_id

    async def _insert_relationships(
        self,
        conn: asyncpg.Connection,
        asset_id: UUID,
        source_system: SourceSystem,
        relationships: list[SemanticRelationship],
    ) -> None:
        # target_asset_id is left NULL on purpose: resolving it here takes a FOR KEY SHARE lock
        # on the target asset, which deadlocks against that asset's own in-flight upsert when
        # documents are processed in parallel. ``resolve_relationship_targets`` fills it in
        # once per run. ``source_system`` is kept for the call sites' symmetry.
        del source_system
        if not relationships:
            return
        await conn.executemany(
            """
            INSERT INTO semantic_relationships (
                source_asset_id, target_fqn, target_asset_id, kind, source_columns,
                target_columns, confidence, evidence
            ) VALUES ($1, $2, NULL, $3, $4::jsonb, $5::jsonb, $6, $7)
            ON CONFLICT (source_asset_id, target_fqn, kind, source_columns) DO UPDATE SET
                target_columns = EXCLUDED.target_columns, confidence = EXCLUDED.confidence,
                evidence = EXCLUDED.evidence
            """,
            [
                (
                    asset_id,
                    r.target_fqn,
                    r.kind.value,
                    r.source_columns,
                    r.target_columns,
                    float(r.confidence),
                    r.evidence,
                )
                for r in relationships
            ],
        )

    async def resolve_relationship_targets(self, source_system: SourceSystem) -> int:
        """Point relationships at assets ingested after them.

        Runs once per connector run (not inside every document's transaction): doing it per
        document made parallel workers lock each other's relationship rows and deadlock.
        """
        result = await self._db.execute(
            """
            UPDATE semantic_relationships r SET target_asset_id = t.id
            FROM semantic_assets s, semantic_assets t
            WHERE r.source_asset_id = s.id AND s.source_system = $1::source_system
              AND t.source_system = s.source_system AND t.fqn = r.target_fqn
              AND r.target_asset_id IS NULL
            """,
            source_system.value,
        )
        tail = str(result).rsplit(" ", 1)[-1]
        return int(tail) if tail.isdigit() else 0

    async def replace_inferred_joins(
        self, source_system: SourceSystem, joins: dict[UUID, list[SemanticRelationship]]
    ) -> int:
        """Store name-based join candidates for the given assets (replacing earlier ones)."""
        total = 0
        async with self._db.transaction() as conn:
            for asset_id, relationships in joins.items():
                await conn.execute(
                    "DELETE FROM semantic_relationships WHERE source_asset_id = $1 AND kind = 'join_inferred'",
                    asset_id,
                )
                await self._insert_relationships(conn, asset_id, source_system, relationships)
                total += len(relationships)
        return total

    # ------------------------------------------------------------------ reads
    async def list_assets(
        self,
        *,
        search: str | None = None,
        source_system: SourceSystem | None = None,
        database: str | None = None,
        schema: str | None = None,
        asset_type: str | None = None,
        kind: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> tuple[list[dict[str, Any]], int]:
        clauses: list[str] = []
        args: list[Any] = []
        if search:
            args.append(search)
            clauses.append(
                f"(a.fqn ILIKE '%' || ${len(args)} || '%' OR a.display_name ILIKE '%' || ${len(args)} || '%' "
                f"OR a.description ILIKE '%' || ${len(args)} || '%')"
            )
        for clause, value in (
            ("a.source_system = $N::source_system", source_system.value if source_system else None),
            ("a.database_name = $N", database),
            ("a.schema_name = $N", schema),
            ("a.asset_type = $N", asset_type),
            ("a.kind = $N", kind),
        ):
            if value:
                args.append(value)
                clauses.append(clause.replace("$N", f"${len(args)}"))
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        rows = await self._db.fetch(
            f"""
            SELECT {_ASSET_COLUMNS} FROM semantic_assets a {where}
            ORDER BY a.database_name, a.schema_name, a.name
            LIMIT ${len(args) + 1} OFFSET ${len(args) + 2}
            """,
            *args,
            limit,
            offset,
        )
        total = await self._db.fetchval(f"SELECT count(*) FROM semantic_assets a {where}", *args)
        return [dict(r) for r in rows], int(total or 0)

    async def get_asset_row(self, asset_id: UUID) -> dict[str, Any] | None:
        row = await self._db.fetchrow(
            f"SELECT {_ASSET_COLUMNS} FROM semantic_assets a WHERE a.id = $1", asset_id
        )
        return dict(row) if row else None

    async def find_asset_row(self, fqn: str) -> dict[str, Any] | None:
        row = await self._db.fetchrow(
            f"""
            SELECT {_ASSET_COLUMNS} FROM semantic_assets a
            WHERE lower(a.fqn) = lower($1) OR lower(a.fqn) LIKE '%.' || lower($1)
            ORDER BY length(a.fqn) LIMIT 1
            """,
            fqn,
        )
        return dict(row) if row else None

    async def fields(self, asset_id: UUID) -> list[dict[str, Any]]:
        rows = await self._db.fetch(
            "SELECT * FROM semantic_fields WHERE asset_id = $1 ORDER BY ordinal, name", asset_id
        )
        return [dict(r) for r in rows]

    async def relationships(self, asset_id: UUID) -> list[dict[str, Any]]:
        rows = await self._db.fetch(_RELATIONSHIP_SQL, asset_id)
        return [dict(r) for r in rows]

    async def metrics(self, asset_id: UUID) -> list[dict[str, Any]]:
        rows = await self._db.fetch(
            "SELECT * FROM semantic_metrics WHERE asset_id = $1 ORDER BY source, name", asset_id
        )
        return [dict(r) for r in rows]

    async def overview(self) -> dict[str, Any]:
        async with self._db.acquire() as conn:
            totals = await conn.fetchrow(
                """
                SELECT
                    (SELECT count(*) FROM semantic_assets)::int AS assets,
                    (SELECT count(*) FROM semantic_fields)::int AS fields,
                    (SELECT count(*) FROM semantic_relationships)::int AS relationships,
                    (SELECT count(*) FROM semantic_metrics)::int AS metrics,
                    (SELECT count(*) FROM semantic_metrics WHERE source = 'declared')::int
                        AS declared_metrics,
                    (SELECT max(synced_at) FROM semantic_assets) AS last_synced_at
                """
            )
            by_platform = await conn.fetch(
                "SELECT platform, count(*)::int AS n FROM semantic_assets GROUP BY platform"
            )
            by_type = await conn.fetch(
                "SELECT asset_type, count(*)::int AS n FROM semantic_assets GROUP BY asset_type"
            )
            by_kind = await conn.fetch(
                "SELECT kind, count(*)::int AS n FROM semantic_assets GROUP BY kind"
            )
            by_role = await conn.fetch(
                "SELECT role, count(*)::int AS n FROM semantic_fields GROUP BY role"
            )
            scopes = await conn.fetch(
                """
                SELECT source_system::text AS source_system, platform, database_name, schema_name,
                       count(*)::int AS assets,
                       sum(CASE WHEN kind = 'fact' THEN 1 ELSE 0 END)::int AS facts,
                       sum(CASE WHEN kind = 'dimension' THEN 1 ELSE 0 END)::int AS dimensions,
                       sum(CASE WHEN asset_type IN ('metric_view', 'semantic_view') THEN 1 ELSE 0 END)::int
                           AS metric_views,
                       max(synced_at) AS synced_at
                FROM semantic_assets
                GROUP BY 1, 2, 3, 4 ORDER BY 2, 3, 4
                """
            )
        return {
            **dict(totals),
            "by_platform": {r["platform"]: r["n"] for r in by_platform},
            "by_asset_type": {r["asset_type"]: r["n"] for r in by_type},
            "by_kind": {r["kind"]: r["n"] for r in by_kind},
            "by_role": {r["role"]: r["n"] for r in by_role},
            "scopes": [dict(r) for r in scopes],
        }

    # ------------------------------------------------------------------ persona reports
    async def relationship_kinds(self) -> dict[str, int]:
        rows = await self._db.fetch(
            "SELECT kind, count(*)::int AS n FROM semantic_relationships GROUP BY kind"
        )
        return {r["kind"]: r["n"] for r in rows}

    async def metrics_by_source(self) -> dict[str, int]:
        rows = await self._db.fetch(
            "SELECT source, count(*)::int AS n FROM semantic_metrics GROUP BY source"
        )
        return {r["source"]: r["n"] for r in rows}

    async def platform_summary(self) -> list[dict[str, Any]]:
        """Databases, schemas, assets and kinds per platform (the Architect's landscape)."""
        async with self._db.acquire() as conn:
            totals = await conn.fetch(
                """
                SELECT platform,
                       count(DISTINCT database_name)::int AS databases,
                       count(DISTINCT database_name || '.' || schema_name)::int AS schemas,
                       count(*)::int AS assets,
                       sum(CASE WHEN asset_type IN ('metric_view', 'semantic_view')
                                THEN 1 ELSE 0 END)::int AS metric_views,
                       max(synced_at) AS last_synced_at
                  FROM semantic_assets
                 GROUP BY platform ORDER BY platform
                """
            )
            kinds = await conn.fetch(
                "SELECT platform, kind, count(*)::int AS n FROM semantic_assets GROUP BY 1, 2"
            )
            types = await conn.fetch(
                "SELECT platform, asset_type, count(*)::int AS n FROM semantic_assets GROUP BY 1, 2"
            )
        out: dict[str, dict[str, Any]] = {
            r["platform"]: {**dict(r), "by_kind": {}, "by_asset_type": {}} for r in totals
        }
        for r in kinds:
            out[r["platform"]]["by_kind"][r["kind"]] = r["n"]
        for r in types:
            out[r["platform"]]["by_asset_type"][r["asset_type"]] = r["n"]
        return list(out.values())

    async def shared_dimensions(self, *, limit: int = 12) -> list[dict[str, Any]]:
        """Dimensions joined from two or more facts: the conformed dimensions of the model."""
        rows = await self._db.fetch(
            """
            SELECT t.id, t.fqn, t.display_name, count(DISTINCT r.source_asset_id)::int AS facts
              FROM semantic_relationships r
              JOIN semantic_assets s ON s.id = r.source_asset_id
              JOIN semantic_assets t ON t.id = r.target_asset_id
             WHERE r.kind IN ('foreign_key', 'join_declared', 'join_inferred')
               AND s.kind = 'fact' AND t.kind = 'dimension'
             GROUP BY t.id, t.fqn, t.display_name
            HAVING count(DISTINCT r.source_asset_id) >= 2
             ORDER BY facts DESC, t.fqn
             LIMIT $1
            """,
            limit,
        )
        return [dict(r) for r in rows]

    async def cross_platform_links(self) -> int:
        return int(
            await self._db.fetchval(
                """
                SELECT count(*) FROM semantic_relationships r
                  JOIN semantic_assets s ON s.id = r.source_asset_id
                  JOIN semantic_assets t ON t.id = r.target_asset_id
                 WHERE s.platform <> t.platform
                """
            )
            or 0
        )

    async def review_counts(self) -> dict[str, int]:
        """Enrichment decisions outstanding and taken, plus assets still unclassified."""
        row = await self._db.fetchrow(
            """
            SELECT count(*) FILTER (WHERE enrichment->>'status' = 'suggested')::int AS suggested,
                   count(*) FILTER (WHERE enrichment->>'status' = 'accepted')::int AS accepted,
                   count(*) FILTER (WHERE enrichment->>'status' = 'rejected')::int AS rejected,
                   count(*) FILTER (WHERE kind = 'unknown')::int AS unclassified,
                   count(*)::int AS assets
              FROM semantic_assets
            """
        )
        return dict(row) if row else {}

    async def review_queue(self, *, limit: int = 50) -> list[dict[str, Any]]:
        """Suggestions awaiting a decision, least confident first."""
        rows = await self._db.fetch(
            """
            SELECT id, fqn, display_name, kind, enrichment
              FROM semantic_assets
             WHERE enrichment->>'status' = 'suggested'
             ORDER BY (enrichment->>'confidence')::float ASC NULLS LAST, fqn
             LIMIT $1
            """,
            limit,
        )
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------ business model
    async def scope_relationships(self, asset_ids: list[UUID]) -> list[dict[str, Any]]:
        rows = await self._db.fetch(
            """
            SELECT r.id, r.source_asset_id, r.target_asset_id, r.target_fqn, r.kind,
                   r.source_columns, r.target_columns, r.confidence, r.evidence,
                   t.kind AS target_kind, t.display_name AS target_display_name,
                   t.name AS target_name
            FROM semantic_relationships r
            LEFT JOIN semantic_assets t ON t.id = r.target_asset_id
            WHERE r.source_asset_id = ANY($1::uuid[])
            ORDER BY r.confidence DESC, r.target_fqn
            """,
            asset_ids,
        )
        return [dict(r) for r in rows]

    async def scope_metrics(self, asset_ids: list[UUID]) -> list[dict[str, Any]]:
        rows = await self._db.fetch(
            """
            SELECT * FROM semantic_metrics WHERE asset_id = ANY($1::uuid[])
            ORDER BY (source = 'declared') DESC, (source = 'curated') DESC, name
            """,
            asset_ids,
        )
        return [dict(r) for r in rows]

    async def scope_role_fields(self, asset_ids: list[UUID]) -> list[dict[str, Any]]:
        rows = await self._db.fetch(
            """
            SELECT asset_id, name, display_name, role FROM semantic_fields
            WHERE asset_id = ANY($1::uuid[]) ORDER BY asset_id, ordinal
            """,
            asset_ids,
        )
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------ enrichment
    async def set_enrichment(self, asset_id: UUID, payload: dict[str, Any]) -> None:
        await self._db.execute(
            "UPDATE semantic_assets SET enrichment = $2::jsonb, updated_at = now() WHERE id = $1",
            asset_id,
            payload,
        )

    async def apply_enrichment(
        self,
        asset_id: UUID,
        *,
        display_name: str,
        summary: str,
        kind: str,
        name_source: str,
        kind_source: str,
    ) -> None:
        await self._db.execute(
            """
            UPDATE semantic_assets
               SET display_name = $2, summary = $3, kind = $4, name_source = $5, kind_source = $6,
                   updated_at = now()
             WHERE id = $1
            """,
            asset_id,
            display_name,
            summary,
            kind,
            name_source,
            kind_source,
        )

    async def add_metric(
        self,
        asset_id: UUID,
        *,
        name: str,
        display_name: str,
        expression: str,
        description: str,
        dimensions: list[str],
        source: str = "curated",
    ) -> None:
        match = re.match(r"^\s*(COUNT|SUM|AVG|MIN|MAX)\s*\(", expression, re.I)
        await self._db.execute(
            """
            INSERT INTO semantic_metrics (
                asset_id, name, display_name, expression, aggregation, description, source,
                dimensions, fields, synonyms
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8::jsonb, '[]'::jsonb, '[]'::jsonb)
            ON CONFLICT (asset_id, name) DO UPDATE SET
                display_name = EXCLUDED.display_name, expression = EXCLUDED.expression,
                aggregation = EXCLUDED.aggregation, description = EXCLUDED.description,
                source = EXCLUDED.source, dimensions = EXCLUDED.dimensions
            """,
            asset_id,
            name,
            display_name,
            expression,
            match.group(1).lower() if match else None,
            description,
            source,
            dimensions,
        )

    # ------------------------------------------------------------------ KPIs
    async def coverage_kpis(self) -> dict[str, Any]:
        """Catalog coverage and freshness counters for the Data Engineer scorecard."""
        has_pk = (
            "EXISTS (SELECT 1 FROM semantic_fields f WHERE f.asset_id = a.id AND f.is_primary_key)"
        )
        linked = """EXISTS (SELECT 1 FROM semantic_relationships r
                            WHERE r.source_asset_id = a.id OR r.target_asset_id = a.id)"""
        # Reports read curated layers; raw landing schemas (BRONZE, RAW, STAGING...) are not a report's source.
        reporting = "a.schema_name !~* '(^|_)(bronze|raw|landing|staging|stage|stg)(_|$)'"
        row = await self._db.fetchrow(
            f"""
            SELECT
                (SELECT count(*) FROM semantic_assets)::int AS assets,
                (SELECT count(*) FROM semantic_assets
                  WHERE coalesce(description, '') <> '')::int AS described,
                (SELECT count(*) FROM semantic_assets WHERE coalesce(owner, '') <> '')::int AS owned,
                (SELECT count(*) FROM semantic_assets WHERE kind = 'fact')::int AS facts,
                (SELECT count(*) FROM semantic_assets a
                  WHERE a.kind = 'fact' AND {has_pk})::int AS keyed_facts,
                (SELECT count(*) FROM semantic_assets a WHERE {linked})::int AS connected,
                (SELECT count(*) FROM semantic_fields)::int AS fields,
                (SELECT count(*) FROM semantic_fields
                  WHERE coalesce(description, '') <> '')::int AS fields_described,
                (SELECT count(*) FROM semantic_relationships
                  WHERE kind IN ('foreign_key', 'join_declared'))::int AS joins_declared,
                (SELECT count(*) FROM semantic_relationships
                  WHERE kind = 'join_inferred')::int AS joins_inferred,
                (SELECT count(*) FROM semantic_metrics)::int AS metrics,
                (SELECT count(*) FROM semantic_metrics WHERE source = 'declared')::int
                    AS metrics_declared,
                (SELECT count(*) FROM semantic_metrics m JOIN semantic_assets a ON a.id = m.asset_id
                  WHERE {reporting})::int AS reporting_metrics,
                (SELECT count(*) FROM semantic_metrics m JOIN semantic_assets a ON a.id = m.asset_id
                  WHERE {reporting} AND m.source = 'declared')::int AS reporting_metrics_declared,
                (SELECT count(*) FROM semantic_assets
                  WHERE synced_at >= now() - interval '24 hours')::int AS fresh_24h,
                (SELECT count(*) FROM semantic_assets
                  WHERE synced_at < now() - interval '7 days')::int AS stale_7d,
                (SELECT max(synced_at) FROM semantic_assets) AS last_synced_at
            """
        )
        return dict(row) if row else {}

    # ------------------------------------------------------------------ persona views
    async def metrics_catalog(
        self,
        *,
        search: str | None,
        source: str | None,
        database: str | None,
        schema: str | None,
        limit: int,
        offset: int,
    ) -> tuple[list[dict[str, Any]], int]:
        """Metrics across assets, declared first; every search token must match."""
        clauses: list[str] = []
        args: list[Any] = []
        tokens = _tokens(search)
        if tokens:
            args.append(tokens)
            clauses.append(f"""NOT EXISTS (
                SELECT 1 FROM unnest(${len(args)}::text[]) AS t(tok)
                WHERE NOT (m.name ILIKE '%' || t.tok || '%'
                           OR m.description ILIKE '%' || t.tok || '%'
                           OR a.fqn ILIKE '%' || t.tok || '%'))""")
        if source:
            args.append(source)
            clauses.append(f"m.source = ${len(args)}")
        if database:
            args.append(database)
            clauses.append(f"a.database_name = ${len(args)}")
        if schema:
            args.append(schema)
            clauses.append(f"a.schema_name = ${len(args)}")
        where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
        base = f"FROM semantic_metrics m JOIN semantic_assets a ON a.id = m.asset_id {where}"
        async with self._db.acquire() as conn:
            total = await conn.fetchval(f"SELECT count(*) {base}", *args)
            rows = await conn.fetch(
                f"""
                SELECT m.id, m.name, m.display_name, m.expression, m.aggregation, m.description,
                       m.source, m.dimensions, m.synonyms,
                       a.id AS asset_id, a.fqn AS asset_fqn, a.name AS asset_name, a.asset_type,
                       a.kind AS asset_kind, a.platform, a.database_name, a.schema_name, a.uri
                {base}
                ORDER BY (m.source = 'declared') DESC,
                         (a.asset_type IN ('metric_view', 'semantic_view')) DESC, m.name, a.fqn
                LIMIT ${len(args) + 1} OFFSET ${len(args) + 2}
                """,
                *args,
                limit,
                offset,
            )
        return [dict(r) for r in rows], int(total or 0)

    async def glossary(
        self, *, search: str | None, role: str | None, limit: int, offset: int
    ) -> tuple[list[dict[str, Any]], int]:
        """Column names grouped across assets: the most common role, the best description."""
        clauses: list[str] = []
        args: list[Any] = []
        tokens = _tokens(search)
        if tokens:
            args.append(tokens)
            clauses.append(f"""NOT EXISTS (
                SELECT 1 FROM unnest(${len(args)}::text[]) AS t(tok)
                WHERE NOT (g.term ILIKE '%' || t.tok || '%'
                           OR g.description ILIKE '%' || t.tok || '%'))""")
        if role:
            args.append(role)
            clauses.append(f"g.role = ${len(args)}")
        where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
        cte = """
            WITH g AS (
                SELECT lower(f.name) AS term,
                       mode() WITHIN GROUP (ORDER BY f.role) AS role,
                       array_remove(array_agg(DISTINCT lower(f.data_type)), '') AS data_types,
                       coalesce((array_agg(f.description ORDER BY length(f.description) DESC)
                                 FILTER (WHERE f.description <> ''))[1], '') AS description,
                       count(DISTINCT f.asset_id)::int AS asset_count,
                       bool_or(f.role_confidence >= 1) AS declared,
                       jsonb_agg(jsonb_build_object('id', a.id, 'fqn', a.fqn) ORDER BY a.fqn)
                           AS assets
                FROM semantic_fields f JOIN semantic_assets a ON a.id = f.asset_id
                GROUP BY lower(f.name)
            )
        """
        async with self._db.acquire() as conn:
            total = await conn.fetchval(f"{cte} SELECT count(*) FROM g {where}", *args)
            rows = await conn.fetch(
                f"""{cte}
                SELECT * FROM g {where}
                ORDER BY g.asset_count DESC, g.term
                LIMIT ${len(args) + 1} OFFSET ${len(args) + 2}
                """,
                *args,
                limit,
                offset,
            )
        return [dict(r) for r in rows], int(total or 0)

    async def health(self, *, list_limit: int = 25) -> dict[str, Any]:
        """Catalog gaps for the Data Engineer workspace."""
        asset_cols = "a.id, a.fqn, a.asset_type, a.kind, a.field_count, a.owner, a.platform"
        has_pk = (
            "EXISTS (SELECT 1 FROM semantic_fields f WHERE f.asset_id = a.id AND f.is_primary_key)"
        )
        linked = """EXISTS (SELECT 1 FROM semantic_relationships r
                            WHERE r.source_asset_id = a.id OR r.target_asset_id = a.id)"""
        async with self._db.acquire() as conn:
            totals = await conn.fetchrow(
                f"""
                SELECT
                    (SELECT count(*) FROM semantic_assets)::int AS assets,
                    (SELECT count(*) FROM semantic_assets
                      WHERE coalesce(description, '') <> '')::int AS described,
                    (SELECT count(*) FROM semantic_assets
                      WHERE coalesce(owner, '') <> '')::int AS owned,
                    (SELECT count(*) FROM semantic_assets WHERE kind = 'fact')::int AS facts,
                    (SELECT count(*) FROM semantic_assets a
                      WHERE a.kind = 'fact' AND {has_pk})::int AS keyed_facts,
                    (SELECT count(*) FROM semantic_assets a WHERE {linked})::int
                        AS with_relationships,
                    (SELECT count(*) FROM semantic_assets a WHERE NOT {linked})::int AS isolated,
                    (SELECT count(*) FROM semantic_relationships
                      WHERE kind = 'join_inferred')::int AS inferred_joins,
                    (SELECT count(*) FROM semantic_relationships
                      WHERE kind = 'join_inferred' AND confidence < 0.8)::int
                        AS low_confidence_joins,
                    (SELECT count(*) FROM semantic_assets
                      WHERE synced_at < now() - interval '7 days')::int AS stale_assets,
                    (SELECT max(synced_at) FROM semantic_assets) AS last_synced_at
                """
            )
            undocumented = await conn.fetch(
                f"""SELECT {asset_cols} FROM semantic_assets a
                    WHERE coalesce(a.description, '') = ''
                    ORDER BY a.field_count DESC, a.fqn LIMIT $1""",
                list_limit,
            )
            unowned = await conn.fetch(
                f"""SELECT {asset_cols} FROM semantic_assets a
                    WHERE coalesce(a.owner, '') = ''
                    ORDER BY a.field_count DESC, a.fqn LIMIT $1""",
                list_limit,
            )
            keyless = await conn.fetch(
                f"""SELECT {asset_cols} FROM semantic_assets a
                    WHERE a.kind = 'fact' AND NOT {has_pk}
                    ORDER BY a.field_count DESC, a.fqn LIMIT $1""",
                list_limit,
            )
            orphans = await conn.fetch(
                f"""SELECT {asset_cols} FROM semantic_assets a
                    WHERE NOT {linked}
                    ORDER BY a.field_count DESC, a.fqn LIMIT $1""",
                list_limit,
            )
            joins = await conn.fetch(
                """
                SELECT r.id, r.source_asset_id, s.fqn AS source_fqn, r.target_asset_id,
                       r.target_fqn, r.source_columns, r.target_columns, r.confidence, r.evidence
                FROM semantic_relationships r JOIN semantic_assets s ON s.id = r.source_asset_id
                WHERE r.kind = 'join_inferred'
                ORDER BY r.confidence ASC, s.fqn, r.target_fqn LIMIT $1
                """,
                list_limit * 2,
            )
            coverage = await conn.fetch(
                f"""
                SELECT a.platform, a.database_name, a.schema_name, count(*)::int AS assets,
                       sum(CASE WHEN coalesce(a.description, '') <> '' THEN 1 ELSE 0 END)::int
                           AS described,
                       sum(CASE WHEN coalesce(a.owner, '') <> '' THEN 1 ELSE 0 END)::int AS owned,
                       sum(CASE WHEN a.kind = 'fact' THEN 1 ELSE 0 END)::int AS facts,
                       sum(CASE WHEN a.kind = 'fact' AND {has_pk} THEN 1 ELSE 0 END)::int
                           AS keyed_facts,
                       max(a.synced_at) AS synced_at
                FROM semantic_assets a
                GROUP BY 1, 2, 3 ORDER BY 1, 2, 3
                """
            )
        return {
            **dict(totals),
            "undocumented": [dict(r) for r in undocumented],
            "unowned": [dict(r) for r in unowned],
            "keyless_facts": [dict(r) for r in keyless],
            "orphans": [dict(r) for r in orphans],
            "review_joins": [dict(r) for r in joins],
            "coverage": [dict(r) for r in coverage],
        }

    async def search(self, query: str, *, limit: int = 20) -> dict[str, list[dict[str, Any]]]:
        """Assets, fields and metrics matching every token of the query.

        Natural-language queries ("policy premium") rarely appear verbatim in a name, so each
        whitespace token must match the name or description independently; trigram similarity
        on the full query orders the hits and also admits near-misses on asset names.
        """
        q = query.strip()
        tokens = [t for t in re.split(r"[\s,;/]+", q) if t] or [q]
        # "Every token matches" expressed as "no token fails to match".
        asset_match = """NOT EXISTS (
                SELECT 1 FROM unnest($1::text[]) AS t(tok)
                WHERE NOT (a.fqn ILIKE '%' || t.tok || '%'
                           OR a.display_name ILIKE '%' || t.tok || '%'
                           OR coalesce(a.description, '') ILIKE '%' || t.tok || '%'))"""
        assets = await self._db.fetch(
            f"""
            SELECT {_ASSET_COLUMNS}, similarity(a.name, $2) AS sim
            FROM semantic_assets a
            WHERE {asset_match} OR a.name % $2
            ORDER BY sim DESC, a.fqn LIMIT $3
            """,
            tokens,
            q,
            limit,
        )
        fields = await self._db.fetch(
            """
            SELECT f.name, f.display_name, f.data_type, f.role, f.description, f.is_primary_key,
                   a.id AS asset_id, a.fqn AS asset_fqn, a.asset_type, a.platform, a.uri
            FROM semantic_fields f JOIN semantic_assets a ON a.id = f.asset_id
            WHERE NOT EXISTS (
                SELECT 1 FROM unnest($1::text[]) AS t(tok)
                WHERE NOT (f.name ILIKE '%' || t.tok || '%'
                           OR coalesce(f.description, '') ILIKE '%' || t.tok || '%'
                           OR a.name ILIKE '%' || t.tok || '%'))
            ORDER BY (lower(f.name) = lower($2)) DESC, similarity(f.name, $2) DESC, a.fqn
            LIMIT $3
            """,
            tokens,
            q,
            limit,
        )
        metrics = await self._db.fetch(
            """
            SELECT m.name, m.expression, m.aggregation, m.description, m.source,
                   a.id AS asset_id, a.fqn AS asset_fqn, a.platform, a.uri
            FROM semantic_metrics m JOIN semantic_assets a ON a.id = m.asset_id
            WHERE NOT EXISTS (
                SELECT 1 FROM unnest($1::text[]) AS t(tok)
                WHERE NOT (m.name ILIKE '%' || t.tok || '%'
                           OR coalesce(m.description, '') ILIKE '%' || t.tok || '%'
                           OR a.name ILIKE '%' || t.tok || '%'))
            ORDER BY (m.source = 'declared') DESC, similarity(m.name, $2) DESC LIMIT $3
            """,
            tokens,
            q,
            limit,
        )
        return {
            "assets": [dict(r) for r in assets],
            "fields": [dict(r) for r in fields],
            "metrics": [dict(r) for r in metrics],
        }

    async def load_assets(
        self,
        *,
        source_system: SourceSystem | None = None,
        database: str | None = None,
        schema: str | None = None,
        asset_ids: list[UUID] | None = None,
    ) -> list[tuple[UUID, SemanticAsset]]:
        """Full :class:`SemanticAsset` objects for a scope (exports, join inference)."""
        clauses: list[str] = []
        args: list[Any] = []
        if source_system:
            args.append(source_system.value)
            clauses.append(f"a.source_system = ${len(args)}::source_system")
        if database:
            args.append(database)
            clauses.append(f"a.database_name = ${len(args)}")
        if schema:
            args.append(schema)
            clauses.append(f"a.schema_name = ${len(args)}")
        if asset_ids:
            args.append(list(asset_ids))
            clauses.append(f"a.id = ANY(${len(args)}::uuid[])")
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        async with self._db.acquire() as conn:
            assets = await conn.fetch(
                f"SELECT {_ASSET_COLUMNS} FROM semantic_assets a {where} ORDER BY a.fqn", *args
            )
            if not assets:
                return []
            ids = [r["id"] for r in assets]
            fields = await conn.fetch(
                "SELECT * FROM semantic_fields WHERE asset_id = ANY($1::uuid[]) ORDER BY ordinal",
                ids,
            )
            rels = await conn.fetch(
                "SELECT * FROM semantic_relationships WHERE source_asset_id = ANY($1::uuid[])", ids
            )
            metrics = await conn.fetch(
                "SELECT * FROM semantic_metrics WHERE asset_id = ANY($1::uuid[]) ORDER BY name", ids
            )
        by_asset: dict[UUID, dict[str, list[dict[str, Any]]]] = defaultdict(
            lambda: {"fields": [], "relationships": [], "metrics": []}
        )
        for r in fields:
            by_asset[r["asset_id"]]["fields"].append(dict(r))
        for r in rels:
            by_asset[r["source_asset_id"]]["relationships"].append(dict(r))
        for r in metrics:
            by_asset[r["asset_id"]]["metrics"].append(dict(r))
        return [(r["id"], asset_from_rows(dict(r), **by_asset[r["id"]])) for r in assets]

    async def neighborhood(self, asset_id: UUID, *, depth: int = 1) -> dict[str, Any]:
        """Assets connected through relationships, up to ``depth`` hops, as nodes and edges."""
        nodes: dict[UUID, dict[str, Any]] = {}
        edges: dict[tuple[Any, ...], dict[str, Any]] = {}
        frontier = [asset_id]
        for _ in range(max(1, depth)):
            if not frontier:
                break
            rows = await self._db.fetch(
                """
                SELECT r.kind, r.confidence, r.source_columns, r.target_columns, r.target_fqn,
                       s.id AS source_id, s.fqn AS source_fqn, s.name AS source_name,
                       s.asset_type AS source_type, s.kind AS source_kind,
                       t.id AS target_id, t.fqn AS target_resolved_fqn, t.name AS target_name,
                       t.asset_type AS target_type, t.kind AS target_kind
                FROM semantic_relationships r
                JOIN semantic_assets s ON s.id = r.source_asset_id
                LEFT JOIN semantic_assets t ON t.id = r.target_asset_id
                WHERE r.source_asset_id = ANY($1::uuid[]) OR r.target_asset_id = ANY($1::uuid[])
                """,
                frontier,
            )
            next_frontier: list[UUID] = []
            for r in rows:
                for prefix, fqn_key in (
                    ("source", "source_fqn"),
                    ("target", "target_resolved_fqn"),
                ):
                    nid = r[f"{prefix}_id"]
                    if nid is None or nid in nodes:
                        continue
                    nodes[nid] = {
                        "id": nid,
                        "fqn": r[fqn_key],
                        "name": r[f"{prefix}_name"],
                        "asset_type": r[f"{prefix}_type"],
                        "kind": r[f"{prefix}_kind"],
                    }
                    next_frontier.append(nid)
                key = (r["source_id"], r["target_id"] or r["target_fqn"], r["kind"])
                edges[key] = {
                    "source": r["source_id"],
                    "target": r["target_id"],
                    "target_fqn": r["target_fqn"],
                    "kind": r["kind"],
                    "confidence": r["confidence"],
                    "source_columns": r["source_columns"],
                    "target_columns": r["target_columns"],
                }
            frontier = next_frontier
        if asset_id not in nodes:
            row = await self.get_asset_row(asset_id)
            if row:
                nodes[asset_id] = {
                    "id": asset_id,
                    "fqn": row["fqn"],
                    "name": row["name"],
                    "asset_type": row["asset_type"],
                    "kind": row["kind"],
                }
        return {"nodes": list(nodes.values()), "edges": list(edges.values())}


def asset_from_rows(
    row: dict[str, Any],
    *,
    fields: list[dict[str, Any]],
    relationships: list[dict[str, Any]],
    metrics: list[dict[str, Any]],
) -> SemanticAsset:
    return SemanticAsset(
        platform=Platform(row["platform"]),
        fqn=row["fqn"],
        database=row["database_name"],
        schema_name=row["schema_name"],
        name=row["name"],
        asset_type=AssetType(row["asset_type"]),
        kind=AssetKind(row["kind"]),
        display_name=row.get("display_name") or "",
        summary=row.get("summary") or "",
        name_source=row.get("name_source") or "derived",
        kind_source=row.get("kind_source") or "inferred",
        description=row["description"] or "",
        owner=row.get("owner"),
        tags=list(row.get("tags") or []),
        properties=dict(row.get("properties") or {}),
        definition=row.get("definition"),
        row_count=row.get("row_count"),
        bytes=row.get("bytes"),
        source_created_at=row.get("source_created_at"),
        source_updated_at=row.get("source_updated_at"),
        uri=row.get("uri"),
        fields=[
            SemanticField(
                name=f["name"],
                display_name=f.get("display_name") or "",
                ordinal=f["ordinal"],
                data_type=f["data_type"],
                description=f["description"],
                nullable=f["nullable"],
                is_primary_key=f["is_primary_key"],
                is_partition=f["is_partition"],
                role=FieldRole(f["role"]),
                role_confidence=f["role_confidence"],
                aggregation=f["aggregation"],
                tags=list(f["tags"] or []),
                synonyms=list(f["synonyms"] or []),
            )
            for f in fields
        ],
        relationships=[
            SemanticRelationship(
                target_fqn=r["target_fqn"],
                kind=RelationshipKind(r["kind"]),
                source_columns=list(r["source_columns"] or []),
                target_columns=list(r["target_columns"] or []),
                confidence=r["confidence"],
                evidence=r["evidence"],
            )
            for r in relationships
        ],
        metrics=[
            SemanticMetric(
                name=m["name"],
                display_name=m.get("display_name") or "",
                expression=m["expression"],
                aggregation=m["aggregation"],
                description=m["description"],
                source=MetricSource(m["source"]),
                dimensions=list(m["dimensions"] or []),
                fields=list(m["fields"] or []),
                synonyms=list(m["synonyms"] or []),
            )
            for m in metrics
        ],
    )


def _tokens(search: str | None) -> list[str]:
    """Whitespace tokens of a free-text query; every one must match independently."""
    if not search or not search.strip():
        return []
    return [t for t in re.split(r"[\s,;/]+", search.strip()) if t]
