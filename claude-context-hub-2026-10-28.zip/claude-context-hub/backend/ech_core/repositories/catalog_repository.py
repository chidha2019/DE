"""Postgres reads for the Semantic Catalog: one snapshot of everything the projection needs.

The catalog is a projection, not a table: it is rebuilt from the semantic layer and the glossary on
every request (a few thousand rows today), so nothing here writes.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ech_core.db.postgres import PostgresDatabase


@dataclass
class CatalogSnapshot:
    assets: list[dict[str, Any]] = field(default_factory=list)
    fields: list[dict[str, Any]] = field(default_factory=list)
    metrics: list[dict[str, Any]] = field(default_factory=list)
    relationships: list[dict[str, Any]] = field(default_factory=list)
    domains: list[dict[str, Any]] = field(default_factory=list)
    term_links: list[dict[str, Any]] = field(default_factory=list)
    kpis: list[dict[str, Any]] = field(default_factory=list)
    lines: list[dict[str, Any]] = field(default_factory=list)
    line_values: list[dict[str, Any]] = field(default_factory=list)


class CatalogRepository:
    def __init__(self, db: PostgresDatabase) -> None:
        self._db = db

    async def snapshot(self) -> CatalogSnapshot:
        async with self._db.acquire() as conn:
            assets = await conn.fetch(
                """
                SELECT a.id, a.platform, a.fqn, a.database_name, a.schema_name, a.name, a.asset_type,
                       a.kind, a.display_name, a.summary, a.description, a.owner, a.name_source,
                       a.domain_key, a.source_updated_at, a.synced_at, a.updated_at
                  FROM semantic_assets a
                 ORDER BY a.fqn
                """
            )
            fields = await conn.fetch(
                """
                SELECT f.id, f.asset_id, f.name, f.display_name, f.ordinal, f.data_type, f.description,
                       f.is_primary_key, f.role, f.role_confidence, f.aggregation
                  FROM semantic_fields f
                 ORDER BY f.asset_id, f.ordinal, f.name
                """
            )
            metrics = await conn.fetch(
                """
                SELECT m.id, m.asset_id, m.name, m.display_name, m.expression, m.aggregation,
                       m.description, m.source, m.dimensions
                  FROM semantic_metrics m
                 ORDER BY m.asset_id, m.name
                """
            )
            relationships = await conn.fetch(
                """
                SELECT r.id, r.source_asset_id, r.target_asset_id, r.target_fqn, r.kind,
                       r.source_columns, r.target_columns, r.confidence, r.evidence
                  FROM semantic_relationships r
                 ORDER BY r.source_asset_id, r.kind, r.target_fqn
                """
            )
            domains = await conn.fetch(
                """
                SELECT d.key, d.name, d.parent_key, d.description, d.standard, d.sort_order
                  FROM semantic_domains d
                 ORDER BY d.sort_order, d.name
                """
            )
            # Only accepted links place objects; the most confident link per target wins downstream.
            term_links = await conn.fetch(
                """
                SELECT l.target_type, l.target_id, l.confidence,
                       t.name AS term_name, t.kind AS term_kind, t.domain_key
                  FROM semantic_term_links l
                  JOIN semantic_terms t ON t.id = l.term_id
                 WHERE l.status = 'accepted'
                 ORDER BY l.confidence DESC, t.name
                """
            )
            kpis = await conn.fetch(
                """
                SELECT k.id, k.key, k.name, k.domain_key, k.term_id, k.metric_id, k.definition,
                       k.formula, k.grain, k.period, k.unit, k.direction, k.target_value, k.owner,
                       k.updated_at, t.name AS term_name
                  FROM semantic_kpis k
                  LEFT JOIN semantic_terms t ON t.id = k.term_id
                 ORDER BY k.name
                """
            )
            lines = await conn.fetch("SELECT asset_id, line_key, source, evidence FROM semantic_asset_lines ORDER BY asset_id, line_key")
            line_values = await conn.fetch(
                "SELECT key, name, description FROM semantic_term_values WHERE term_key = 'line_of_business' ORDER BY sort_order, name"
            )
        return CatalogSnapshot(
            assets=[dict(r) for r in assets],
            fields=[dict(r) for r in fields],
            metrics=[dict(r) for r in metrics],
            relationships=[dict(r) for r in relationships],
            domains=[dict(r) for r in domains],
            term_links=[dict(r) for r in term_links],
            kpis=[dict(r) for r in kpis],
            lines=[dict(r) for r in lines],
            line_values=[dict(r) for r in line_values],
        )
