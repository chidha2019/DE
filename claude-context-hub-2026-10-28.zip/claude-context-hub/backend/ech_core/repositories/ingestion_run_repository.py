"""Postgres access for ``ingestion_runs`` and ``ingestion_run_events``."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from ech_core.db.postgres import PostgresDatabase
from ech_core.domain.enums import RunStatus, SourceSystem
from ech_core.domain.models import IngestionRunRecord, RunEventRecord
from ech_core.schemas.stats import RunActivityPoint

_RUN_COLUMNS = """
    r.id, r.connector_name, r.source_system::text AS source_system, r.status::text AS status,
    r.config, r.stats, r.triggered_by, r.pipeline_id, r.error, r.started_at, r.finished_at,
    r.created_at, r.updated_at
"""


class IngestionRunRepository:
    def __init__(self, db: PostgresDatabase) -> None:
        self._db = db

    # ------------------------------------------------------------------ runs
    async def create(
        self,
        *,
        connector_name: str,
        source_system: SourceSystem,
        config: dict[str, Any],
        triggered_by: str | None,
        pipeline_id: UUID | None = None,
    ) -> IngestionRunRecord:
        row = await self._db.fetchrow(
            f"""
            INSERT INTO ingestion_runs AS r (connector_name, source_system, config, triggered_by, pipeline_id)
            VALUES ($1, $2::source_system, $3::jsonb, $4, $5)
            RETURNING {_RUN_COLUMNS}
            """,
            connector_name,
            source_system.value,
            config,
            triggered_by,
            pipeline_id,
        )
        assert row is not None
        return IngestionRunRecord.from_row(row)

    async def get(self, run_id: UUID) -> IngestionRunRecord | None:
        row = await self._db.fetchrow(
            f"SELECT {_RUN_COLUMNS} FROM ingestion_runs r WHERE r.id = $1", run_id
        )
        return IngestionRunRecord.from_row(row) if row else None

    async def list(
        self,
        *,
        status: RunStatus | None = None,
        connector_name: str | None = None,
        pipeline_id: UUID | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> tuple[list[IngestionRunRecord], int]:
        clauses: list[str] = []
        args: list[Any] = []
        if status:
            args.append(status.value)
            clauses.append(f"r.status::text = ${len(args)}")
        if connector_name:
            args.append(connector_name)
            clauses.append(f"r.connector_name = ${len(args)}")
        if pipeline_id:
            args.append(pipeline_id)
            clauses.append(f"r.pipeline_id = ${len(args)}")
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        total = await self._db.fetchval(f"SELECT count(*) FROM ingestion_runs r {where}", *args)
        args.extend([limit, offset])
        rows = await self._db.fetch(
            f"""
            SELECT {_RUN_COLUMNS} FROM ingestion_runs r {where}
            ORDER BY r.created_at DESC
            LIMIT ${len(args) - 1} OFFSET ${len(args)}
            """,
            *args,
        )
        return [IngestionRunRecord.from_row(r) for r in rows], int(total or 0)

    async def set_status(
        self,
        run_id: UUID,
        status: RunStatus,
        *,
        error: str | None = None,
        mark_started: bool = False,
        mark_finished: bool = False,
    ) -> IngestionRunRecord | None:
        row = await self._db.fetchrow(
            f"""
            UPDATE ingestion_runs AS r
               SET status      = $2::ingestion_run_status,
                   error       = COALESCE($3, r.error),
                   started_at  = CASE WHEN $4 THEN COALESCE(r.started_at, now())
                                      ELSE r.started_at END,
                   finished_at = CASE WHEN $5 THEN now() ELSE r.finished_at END
             WHERE r.id = $1
            RETURNING {_RUN_COLUMNS}
            """,
            run_id,
            status.value,
            error[:4000] if error else None,
            mark_started,
            mark_finished,
        )
        return IngestionRunRecord.from_row(row) if row else None

    async def merge_stats(self, run_id: UUID, stats: dict[str, Any]) -> None:
        """Shallow-merge counters into ``stats`` (JSONB ``||``)."""
        await self._db.execute(
            "UPDATE ingestion_runs SET stats = stats || $2::jsonb WHERE id = $1", run_id, stats
        )

    async def fail_stale_runs(self, reason: str) -> int:
        """Crash recovery: runs left active by a previous process are failed."""
        result = await self._db.execute(
            """
            UPDATE ingestion_runs
               SET status = 'failed', error = $1, finished_at = now()
             WHERE status IN ('queued', 'running', 'paused')
            """,
            reason,
        )
        return int(result.split()[-1]) if result else 0

    async def count(self) -> int:
        return int(await self._db.fetchval("SELECT count(*) FROM ingestion_runs") or 0)

    async def count_active(self) -> int:
        return int(
            await self._db.fetchval(
                "SELECT count(*) FROM ingestion_runs WHERE status IN ('queued','running','paused')"
            )
            or 0
        )

    async def last_run_at(self) -> datetime | None:
        return await self._db.fetchval("SELECT max(created_at) FROM ingestion_runs")

    async def activity(
        self, *, hours: int = 24, bucket_minutes: int = 60
    ) -> list[RunActivityPoint]:
        rows = await self._db.fetch(
            """
            SELECT date_bin(make_interval(mins => $2), coalesce(finished_at, created_at),
                            to_timestamp(0)) AS bucket,
                   count(*) FILTER (WHERE status = 'completed')::int AS completed,
                   count(*) FILTER (WHERE status = 'failed')::int    AS failed,
                   count(*) FILTER (WHERE status = 'cancelled')::int AS cancelled,
                   coalesce(sum((stats->>'documents_upserted')::int), 0)::int AS documents
              FROM ingestion_runs
             WHERE created_at >= now() - make_interval(hours => $1)
             GROUP BY 1 ORDER BY 1
            """,
            hours,
            bucket_minutes,
        )
        return [
            RunActivityPoint(
                bucket_start=r["bucket"],
                completed=r["completed"],
                failed=r["failed"],
                cancelled=r["cancelled"],
                documents=r["documents"],
            )
            for r in rows
        ]

    # ------------------------------------------------------------------ KPIs
    async def kpi_rollup(self, *, days: int) -> dict[str, Any]:
        """Run outcomes, document counters and busy time over the last ``days`` days."""
        row = await self._db.fetchrow(
            """
            SELECT count(*) FILTER (WHERE status = 'completed')::int AS completed,
                   count(*) FILTER (WHERE status = 'failed')::int    AS failed,
                   count(*) FILTER (WHERE status = 'cancelled')::int AS cancelled,
                   coalesce(sum((stats->>'documents_seen')::int), 0)::int     AS documents_seen,
                   coalesce(sum((stats->>'documents_upserted')::int), 0)::int AS documents_upserted,
                   coalesce(sum((stats->>'documents_failed')::int), 0)::int   AS documents_failed,
                   coalesce(sum((stats->>'graph_failed')::int), 0)::int       AS graph_failed,
                   avg(EXTRACT(EPOCH FROM (finished_at - started_at)))
                       FILTER (WHERE status = 'completed' AND started_at IS NOT NULL
                               AND finished_at IS NOT NULL) AS avg_duration_s,
                   coalesce(sum(EXTRACT(EPOCH FROM (finished_at - started_at)))
                       FILTER (WHERE status = 'completed' AND started_at IS NOT NULL
                               AND finished_at IS NOT NULL), 0) AS busy_seconds
              FROM ingestion_runs
             WHERE created_at >= now() - make_interval(days => $1)
            """,
            days,
        )
        return dict(row) if row else {}

    async def connector_freshness(self, *, days: int) -> list[dict[str, Any]]:
        """Per connector: last successful run, latest status, and activity in the window."""
        rows = await self._db.fetch(
            """
            SELECT connector_name, source_system::text AS source_system,
                   max(finished_at) FILTER (WHERE status = 'completed') AS last_success_at,
                   (array_agg(status::text ORDER BY created_at DESC))[1] AS last_status,
                   count(*) FILTER (WHERE created_at >= now() - make_interval(days => $1))::int
                       AS runs,
                   count(*) FILTER (WHERE status = 'failed'
                                    AND created_at >= now() - make_interval(days => $1))::int
                       AS failed,
                   coalesce(sum((stats->>'documents_upserted')::int)
                       FILTER (WHERE created_at >= now() - make_interval(days => $1)), 0)::int
                       AS documents_upserted
              FROM ingestion_runs
             GROUP BY 1, 2
             ORDER BY last_success_at DESC NULLS LAST, 1
            """,
            days,
        )
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------ events
    async def append_event(
        self,
        run_id: UUID,
        *,
        level: str,
        event_type: str,
        message: str,
        payload: dict[str, Any] | None = None,
    ) -> RunEventRecord:
        row = await self._db.fetchrow(
            """
            INSERT INTO ingestion_run_events (run_id, level, event_type, message, payload)
            VALUES ($1, $2, $3, $4, $5::jsonb)
            RETURNING id, run_id, level, event_type, message, payload, created_at
            """,
            run_id,
            level,
            event_type,
            message[:4000],
            payload or {},
        )
        assert row is not None
        return RunEventRecord.from_row(row)

    async def list_events(
        self, run_id: UUID, *, after_id: int = 0, limit: int = 200
    ) -> list[RunEventRecord]:
        rows = await self._db.fetch(
            """
            SELECT id, run_id, level, event_type, message, payload, created_at
              FROM ingestion_run_events
             WHERE run_id = $1 AND id > $2
             ORDER BY id
             LIMIT $3
            """,
            run_id,
            after_id,
            limit,
        )
        return [RunEventRecord.from_row(r) for r in rows]

    async def recent_failures(self, *, days: int, limit: int = 20) -> list[dict[str, Any]]:
        """Failed runs in the window, newest first, with their error text."""
        rows = await self._db.fetch(
            """
            SELECT id, connector_name, source_system::text AS source_system,
                   status::text AS status, error, started_at, finished_at,
                   coalesce((stats->>'documents_failed')::int, 0)::int AS documents_failed
              FROM ingestion_runs
             WHERE status = 'failed' AND created_at >= now() - make_interval(days => $1)
             ORDER BY created_at DESC
             LIMIT $2
            """,
            days,
            limit,
        )
        return [dict(r) for r in rows]

    async def count_stale_active(self, *, hours: int) -> int:
        """Runs that claim to be active but have not reported progress for ``hours``."""
        return int(
            await self._db.fetchval(
                "SELECT count(*) FROM ingestion_runs "
                "WHERE status IN ('queued', 'running', 'paused') "
                "AND updated_at < now() - make_interval(hours => $1)",
                hours,
            )
            or 0
        )
