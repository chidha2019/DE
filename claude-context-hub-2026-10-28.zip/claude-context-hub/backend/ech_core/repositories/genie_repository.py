"""Postgres access for Genie spaces, conversations and messages (migration 0004)."""

from __future__ import annotations

from typing import Any
from uuid import UUID

from ech_core.db.postgres import PostgresDatabase

_SPACE_COLUMNS = """
    s.id, s.name, s.description, s.instructions, s.filters, s.sample_questions, s.is_default,
    s.persona,
    s.created_at, s.updated_at,
    (SELECT count(*) FROM genie_conversations c WHERE c.space_id = s.id)::int AS conversation_count
"""

_CONVERSATION_COLUMNS = """
    c.id, c.space_id, c.title, c.created_at, c.updated_at,
    (SELECT count(*) FROM genie_messages m WHERE m.conversation_id = c.id)::int AS message_count,
    (SELECT max(m.created_at) FROM genie_messages m WHERE m.conversation_id = c.id)
        AS last_message_at
"""

_MESSAGE_COLUMNS = """
    m.id, m.conversation_id, m.role, m.content, m.status, m.error, m.citations, m.trace,
    m.follow_ups, m.usage, m.model, m.latency_ms, m.feedback, m.created_at
"""

_SPACE_UPDATABLE = {"name", "description", "instructions", "filters", "sample_questions"}
_JSONB_COLUMNS = {"filters", "sample_questions"}


class GenieRepository:
    def __init__(self, db: PostgresDatabase) -> None:
        self._db = db

    # ------------------------------------------------------------------ spaces
    async def list_spaces(self) -> list[dict[str, Any]]:
        rows = await self._db.fetch(
            f"SELECT {_SPACE_COLUMNS} FROM genie_spaces s ORDER BY s.is_default DESC, s.name"
        )
        return [dict(r) for r in rows]

    async def get_space(self, space_id: UUID) -> dict[str, Any] | None:
        row = await self._db.fetchrow(
            f"SELECT {_SPACE_COLUMNS} FROM genie_spaces s WHERE s.id = $1", space_id
        )
        return dict(row) if row else None

    async def create_space(
        self,
        *,
        name: str,
        description: str,
        instructions: str,
        filters: dict[str, Any],
        sample_questions: list[str],
    ) -> dict[str, Any]:
        space_id = await self._db.fetchval(
            """
            INSERT INTO genie_spaces (name, description, instructions, filters, sample_questions)
            VALUES ($1, $2, $3, $4::jsonb, $5::jsonb)
            RETURNING id
            """,
            name,
            description,
            instructions,
            filters,
            sample_questions,
        )
        created = await self.get_space(space_id)
        assert created is not None
        return created

    async def update_space(self, space_id: UUID, fields: dict[str, Any]) -> dict[str, Any] | None:
        updates = {k: v for k, v in fields.items() if k in _SPACE_UPDATABLE}
        if not updates:
            return await self.get_space(space_id)
        assignments: list[str] = []
        args: list[Any] = [space_id]
        for column, value in updates.items():
            args.append(value)
            cast = "::jsonb" if column in _JSONB_COLUMNS else ""
            assignments.append(f"{column} = ${len(args)}{cast}")
        updated = await self._db.fetchval(
            f"UPDATE genie_spaces SET {', '.join(assignments)} WHERE id = $1 RETURNING id", *args
        )
        return await self.get_space(space_id) if updated else None

    async def delete_space(self, space_id: UUID) -> bool:
        deleted = await self._db.fetchval(
            "DELETE FROM genie_spaces WHERE id = $1 AND NOT is_default AND persona IS NULL RETURNING id",
            space_id,
        )
        return deleted is not None

    # ------------------------------------------------------------------ conversations
    async def create_conversation(self, space_id: UUID, title: str) -> dict[str, Any]:
        conversation_id = await self._db.fetchval(
            "INSERT INTO genie_conversations (space_id, title) VALUES ($1, $2) RETURNING id",
            space_id,
            title,
        )
        created = await self.get_conversation(conversation_id)
        assert created is not None
        return created

    async def get_conversation(self, conversation_id: UUID) -> dict[str, Any] | None:
        row = await self._db.fetchrow(
            f"SELECT {_CONVERSATION_COLUMNS} FROM genie_conversations c WHERE c.id = $1",
            conversation_id,
        )
        return dict(row) if row else None

    async def list_conversations(
        self, space_id: UUID, *, limit: int = 50, offset: int = 0
    ) -> tuple[list[dict[str, Any]], int]:
        rows = await self._db.fetch(
            f"""
            SELECT {_CONVERSATION_COLUMNS} FROM genie_conversations c
            WHERE c.space_id = $1
            ORDER BY c.updated_at DESC
            LIMIT $2 OFFSET $3
            """,
            space_id,
            limit,
            offset,
        )
        total = await self._db.fetchval(
            "SELECT count(*) FROM genie_conversations WHERE space_id = $1", space_id
        )
        return [dict(r) for r in rows], int(total or 0)

    async def touch_conversation(self, conversation_id: UUID) -> None:
        await self._db.execute(
            "UPDATE genie_conversations SET updated_at = now() WHERE id = $1", conversation_id
        )

    async def delete_conversation(self, conversation_id: UUID) -> bool:
        deleted = await self._db.fetchval(
            "DELETE FROM genie_conversations WHERE id = $1 RETURNING id", conversation_id
        )
        return deleted is not None

    # ------------------------------------------------------------------ messages
    async def add_message(
        self,
        conversation_id: UUID,
        *,
        role: str,
        content: str,
        status: str = "complete",
        error: str | None = None,
        citations: list[dict[str, Any]] | None = None,
        trace: list[dict[str, Any]] | None = None,
        follow_ups: list[str] | None = None,
        usage: dict[str, Any] | None = None,
        model: str | None = None,
        latency_ms: int | None = None,
    ) -> dict[str, Any]:
        row = await self._db.fetchrow(
            f"""
            INSERT INTO genie_messages AS m (
                conversation_id, role, content, status, error, citations, trace, follow_ups,
                usage, model, latency_ms
            ) VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7::jsonb, $8::jsonb, $9::jsonb, $10, $11)
            RETURNING {_MESSAGE_COLUMNS}
            """,
            conversation_id,
            role,
            content,
            status,
            error,
            citations or [],
            trace or [],
            follow_ups or [],
            usage or {},
            model,
            latency_ms,
        )
        assert row is not None
        await self.touch_conversation(conversation_id)
        return dict(row)

    async def list_messages(self, conversation_id: UUID) -> list[dict[str, Any]]:
        rows = await self._db.fetch(
            f"""
            SELECT {_MESSAGE_COLUMNS} FROM genie_messages m
            WHERE m.conversation_id = $1
            ORDER BY m.created_at, m.id
            """,
            conversation_id,
        )
        return [dict(r) for r in rows]

    async def set_feedback(self, message_id: UUID, value: int | None) -> dict[str, Any] | None:
        row = await self._db.fetchrow(
            f"""
            UPDATE genie_messages AS m SET feedback = $2
            WHERE m.id = $1 AND m.role = 'assistant'
            RETURNING {_MESSAGE_COLUMNS}
            """,
            message_id,
            value,
        )
        return dict(row) if row else None

    async def answer_counts(self, *, persona: str, days: int) -> dict[str, int]:
        """Answers in one persona's space over the window: asked (not cancelled), answered and not
        marked unhelpful, marked unhelpful, failed."""
        row = await self._db.fetchrow(
            """
            SELECT count(*) FILTER (WHERE m.status <> 'cancelled')::int AS asked,
                   count(*) FILTER (WHERE m.status = 'complete' AND coalesce(m.feedback, 0) >= 0)::int AS answered,
                   count(*) FILTER (WHERE m.feedback = -1)::int AS unhelpful,
                   count(*) FILTER (WHERE m.status = 'error')::int AS failed
            FROM genie_messages m
            JOIN genie_conversations c ON c.id = m.conversation_id
            JOIN genie_spaces s ON s.id = c.space_id
            WHERE m.role = 'assistant' AND s.persona = $1 AND m.created_at >= now() - make_interval(days => $2)
            """,
            persona,
            days,
        )
        return dict(row) if row else {}
