"""Postgres store of digital workers (migration 0023): their work items, their hash-chained journal, their pause state."""

from __future__ import annotations

import hashlib
import json
from datetime import UTC, date, datetime
from typing import Any

from ech_core.db.postgres import PostgresDatabase

OPEN_STATUSES = ("detected", "diagnosed", "waiting", "running")
_ITEM_COLUMNS = "key, worker, skill, title, detail, status, tier, action, evidence, created_at, updated_at, decided_by, decided_at"
_JOURNAL_COLUMNS = "id, worker, at, kind, item_key, skill, message, evidence, prev_hash, record_hash"


def _plain(value: Any) -> Any:
    """Evidence as plain JSON values, so what is hashed is exactly what is stored and read back."""

    def default(v: Any) -> Any:
        if isinstance(v, datetime | date):
            return v.isoformat()
        return str(v)

    return json.loads(json.dumps(value or {}, default=default))


def record_hash(prev_hash: str | None, entry: dict[str, Any]) -> str:
    """SHA-256 over the previous entry's hash and this entry's canonical JSON."""
    body = json.dumps(entry, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(((prev_hash or "") + body).encode("utf-8")).hexdigest()


def entry_body(row: dict[str, Any]) -> dict[str, Any]:
    at = row["at"]
    return {
        "worker": row["worker"],
        "at": at.isoformat() if isinstance(at, datetime) else str(at),
        "kind": row["kind"],
        "item_key": row.get("item_key"),
        "skill": row.get("skill"),
        "message": row["message"],
        "evidence": row.get("evidence") or {},
    }


def chain_ok(rows_newest_first: list[dict[str, Any]]) -> bool:
    """Each entry hashes to its own record_hash and links to the entry before it."""
    for i, row in enumerate(rows_newest_first):
        if record_hash(row.get("prev_hash"), entry_body(row)) != row["record_hash"]:
            return False
        older = rows_newest_first[i + 1] if i + 1 < len(rows_newest_first) else None
        if older is not None and row.get("prev_hash") != older["record_hash"]:
            return False
    return True


class WorkerRepository:
    def __init__(self, db: PostgresDatabase) -> None:
        self._db = db

    # ------------------------------------------------------------------ items
    async def item(self, key: str) -> dict[str, Any] | None:
        row = await self._db.fetchrow(f"SELECT {_ITEM_COLUMNS} FROM worker_items WHERE key = $1", key)
        return dict(row) if row else None

    async def items(self, worker: str, *, closed_since: datetime | None = None, limit: int = 120) -> list[dict[str, Any]]:
        """Open items, and those closed since `closed_since`; newest change first."""
        rows = await self._db.fetch(
            f"""
            SELECT {_ITEM_COLUMNS} FROM worker_items
             WHERE worker = $1 AND (status = ANY($2::text[]) OR ($3::timestamptz IS NOT NULL AND updated_at >= $3))
             ORDER BY updated_at DESC
             LIMIT $4
            """,
            worker,
            list(OPEN_STATUSES),
            closed_since,
            limit,
        )
        return [dict(r) for r in rows]

    async def open_keys(self, worker: str) -> dict[str, dict[str, Any]]:
        rows = await self._db.fetch(f"SELECT {_ITEM_COLUMNS} FROM worker_items WHERE worker = $1 AND status = ANY($2::text[])", worker, list(OPEN_STATUSES))
        return {r["key"]: dict(r) for r in rows}

    async def upsert(
        self,
        *,
        key: str,
        worker: str,
        skill: str,
        title: str,
        detail: str,
        status: str,
        tier: str,
        action: dict[str, Any] | None,
        evidence: dict[str, Any],
    ) -> tuple[dict[str, Any], bool]:
        """Insert or refresh an item; returns it and whether it was new."""
        row = await self._db.fetchrow(
            f"""
            INSERT INTO worker_items (key, worker, skill, title, detail, status, tier, action, evidence)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
            ON CONFLICT (key) DO UPDATE SET
                skill = EXCLUDED.skill, title = EXCLUDED.title, detail = EXCLUDED.detail, status = EXCLUDED.status,
                tier = EXCLUDED.tier, action = EXCLUDED.action, evidence = EXCLUDED.evidence, updated_at = now()
            RETURNING {_ITEM_COLUMNS}, (xmax = 0) AS inserted
            """,
            key,
            worker,
            skill,
            title,
            detail,
            status,
            tier,
            _plain(action) if action else None,
            _plain(evidence),
        )
        assert row is not None
        out = dict(row)
        inserted = bool(out.pop("inserted"))
        return out, inserted

    async def update(self, key: str, **fields: Any) -> dict[str, Any] | None:
        if not fields:
            return await self.item(key)
        allowed = {"title", "detail", "status", "tier", "action", "evidence", "decided_by", "decided_at"}
        sets, args = [], [key]
        for name, value in fields.items():
            if name not in allowed:
                raise ValueError(f"unknown worker item field {name}")
            args.append(_plain(value) if name in ("action", "evidence") and value is not None else value)
            sets.append(f"{name} = ${len(args)}")
        row = await self._db.fetchrow(
            f"UPDATE worker_items SET {', '.join(sets)}, updated_at = now() WHERE key = $1 RETURNING {_ITEM_COLUMNS}", *args
        )
        return dict(row) if row else None

    # ------------------------------------------------------------------ journal
    async def append(
        self, worker: str, kind: str, message: str, *, item_key: str | None = None, skill: str | None = None, evidence: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Append one entry, hashed over the last one; a transaction lock keeps the chain in order."""
        plain = _plain(evidence)
        async with self._db.transaction() as conn:
            await conn.execute("SELECT pg_advisory_xact_lock(hashtext($1))", f"worker-journal:{worker}")
            prev = await conn.fetchval("SELECT record_hash FROM worker_journal WHERE worker = $1 ORDER BY id DESC LIMIT 1", worker)
            at = datetime.now(UTC)
            digest = record_hash(prev, entry_body({"worker": worker, "at": at, "kind": kind, "item_key": item_key, "skill": skill, "message": message, "evidence": plain}))
            row = await conn.fetchrow(
                f"""
                INSERT INTO worker_journal (worker, at, kind, item_key, skill, message, evidence, prev_hash, record_hash)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                RETURNING {_JOURNAL_COLUMNS}
                """,
                worker,
                at,
                kind,
                item_key,
                skill,
                message,
                plain,
                prev,
                digest,
            )
        assert row is not None
        return dict(row)

    async def journal(self, worker: str, *, limit: int = 40) -> list[dict[str, Any]]:
        rows = await self._db.fetch(f"SELECT {_JOURNAL_COLUMNS} FROM worker_journal WHERE worker = $1 ORDER BY id DESC LIMIT $2", worker, limit)
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------ the observed side
    async def catalog_tables(self) -> list[dict[str, Any]]:
        """What the catalog observed in the warehouses: every table and view, with its row count when synced."""
        rows = await self._db.fetch(
            """
            SELECT platform, fqn, database_name, schema_name, name, asset_type, row_count, synced_at
              FROM semantic_assets
             WHERE asset_type NOT IN ('metric_view', 'semantic_view')
            """
        )
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------ counts and state
    async def counts(self, worker: str) -> dict[str, Any]:
        row = await self._db.fetchrow(
            """
            SELECT count(*) FILTER (WHERE status = ANY($2::text[]))::int AS open,
                   count(*) FILTER (WHERE status = 'waiting')::int AS waiting,
                   count(*) FILTER (WHERE status = 'running')::int AS running,
                   count(*) FILTER (WHERE status = 'done' AND updated_at >= date_trunc('day', now()))::int AS done_today,
                   count(*) FILTER (WHERE status = 'failed' AND updated_at >= date_trunc('day', now()))::int AS failed_today
              FROM worker_items WHERE worker = $1
            """,
            worker,
            list(OPEN_STATUSES),
        )
        return dict(row) if row else {}

    async def skill_counts(self, worker: str) -> dict[str, dict[str, Any]]:
        rows = await self._db.fetch(
            """
            SELECT skill,
                   count(*) FILTER (WHERE status IN ('done', 'failed'))::int AS handled,
                   count(*) FILTER (WHERE status = 'done')::int AS succeeded,
                   count(*) FILTER (WHERE status = ANY($2::text[]))::int AS open,
                   max(updated_at) AS last_at
              FROM worker_items WHERE worker = $1
             GROUP BY skill
            """,
            worker,
            list(OPEN_STATUSES),
        )
        return {r["skill"]: dict(r) for r in rows}

    async def state(self, worker: str) -> dict[str, Any]:
        row = await self._db.fetchrow(
            """
            INSERT INTO worker_state (worker) VALUES ($1)
            ON CONFLICT (worker) DO UPDATE SET worker = EXCLUDED.worker
            RETURNING worker, paused, last_tick
            """,
            worker,
        )
        assert row is not None
        return dict(row)

    async def set_paused(self, worker: str, paused: bool) -> None:
        await self._db.execute(
            "INSERT INTO worker_state (worker, paused) VALUES ($1, $2) ON CONFLICT (worker) DO UPDATE SET paused = $2, updated_at = now()",
            worker,
            paused,
        )

    async def touch(self, worker: str) -> None:
        await self._db.execute(
            "INSERT INTO worker_state (worker, last_tick) VALUES ($1, now()) ON CONFLICT (worker) DO UPDATE SET last_tick = now(), updated_at = now()",
            worker,
        )
