"""Postgres access for the ``documents`` table."""

from __future__ import annotations

from typing import Any
from uuid import UUID

import asyncpg

from ech_core.db.postgres import PostgresDatabase
from ech_core.domain.enums import DocumentKind, GraphSyncStatus, SourceSystem
from ech_core.domain.models import DocumentRecord, DocumentUpsert

# Enum columns are cast to text so asyncpg does not need custom codecs.
_COLUMNS = """
    d.id, d.source_id, d.source_system::text AS source_system, d.external_id, d.title, d.uri,
    d.author, d.mime_type, d.language, d.content_hash, d.content_length, d.version,
    d.attributes, d.graph_sync_status::text AS graph_sync_status, d.graph_node_id,
    d.graph_synced_at, d.graph_sync_error, d.source_created_at, d.source_updated_at,
    d.ingested_at, d.updated_at, d.deleted_at, d.last_run_id, d.kind
"""

_COUNTS = """
    (SELECT count(*) FROM chunks c WHERE c.document_id = d.id)::int AS chunk_count,
    (SELECT count(*) FROM embeddings e JOIN chunks c2 ON c2.id = e.chunk_id
      WHERE c2.document_id = d.id)::int AS embedding_count
"""

_UPSERT_SQL = f"""
INSERT INTO documents AS d (
    id, source_system, external_id, title, uri, author, mime_type, language,
    content_hash, content_length, attributes, source_created_at, source_updated_at, last_run_id,
    kind
) VALUES (
    $1, $2::source_system, $3, $4, $5, $6, $7, $8, $9, $10, $11::jsonb, $12, $13, $14, $16
)
ON CONFLICT (id) DO UPDATE SET
    title             = EXCLUDED.title,
    uri               = EXCLUDED.uri,
    author            = EXCLUDED.author,
    mime_type         = EXCLUDED.mime_type,
    language          = EXCLUDED.language,
    content_hash      = EXCLUDED.content_hash,
    content_length    = EXCLUDED.content_length,
    attributes        = EXCLUDED.attributes,
    kind              = EXCLUDED.kind,
    source_created_at = COALESCE(EXCLUDED.source_created_at, d.source_created_at),
    source_updated_at = EXCLUDED.source_updated_at,
    last_run_id       = EXCLUDED.last_run_id,
    deleted_at        = NULL,
    version           = d.version + CASE WHEN $15::boolean THEN 1 ELSE 0 END,
    graph_sync_status = CASE WHEN $15::boolean THEN 'pending'::graph_sync_status
                             ELSE d.graph_sync_status END
RETURNING {_COLUMNS}
"""


class DocumentRepository:
    def __init__(self, db: PostgresDatabase) -> None:
        self._db = db

    # ------------------------------------------------------------------ reads
    async def get(self, document_id: UUID, *, include_counts: bool = True) -> DocumentRecord | None:
        counts = f", {_COUNTS}" if include_counts else ""
        row = await self._db.fetchrow(
            f"SELECT {_COLUMNS}{counts} FROM documents d WHERE d.id = $1", document_id
        )
        return DocumentRecord.from_row(row) if row else None

    async def get_for_update(
        self, conn: asyncpg.Connection, document_id: UUID
    ) -> DocumentRecord | None:
        row = await conn.fetchrow(
            f"SELECT {_COLUMNS} FROM documents d WHERE d.id = $1 FOR UPDATE", document_id
        )
        return DocumentRecord.from_row(row) if row else None

    async def list(
        self,
        *,
        source_systems: list[SourceSystem] | None = None,
        search: str | None = None,
        graph_sync_status: GraphSyncStatus | None = None,
        kind: DocumentKind | None = None,
        include_deleted: bool = False,
        limit: int = 50,
        offset: int = 0,
    ) -> tuple[list[DocumentRecord], int]:
        clauses: list[str] = []
        args: list[Any] = []
        if not include_deleted:
            clauses.append("d.deleted_at IS NULL")
        if source_systems:
            args.append([s.value for s in source_systems])
            clauses.append(f"d.source_system::text = ANY(${len(args)}::text[])")
        if graph_sync_status:
            args.append(graph_sync_status.value)
            clauses.append(f"d.graph_sync_status::text = ${len(args)}")
        if kind:
            args.append(kind.value)
            clauses.append(f"d.kind = ${len(args)}")
        if search and search.strip():
            args.append(search.strip())
            n = len(args)
            clauses.append(
                f"(d.title ILIKE '%' || ${n} || '%' OR d.external_id ILIKE '%' || ${n} || '%' "
                f"OR d.title_tsv @@ plainto_tsquery('english', ${n}))"
            )
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""

        total = await self._db.fetchval(f"SELECT count(*) FROM documents d {where}", *args)
        args.extend([limit, offset])
        rows = await self._db.fetch(
            f"""
            SELECT {_COLUMNS}, {_COUNTS}
            FROM documents d {where}
            ORDER BY d.ingested_at DESC, d.title
            LIMIT ${len(args) - 1} OFFSET ${len(args)}
            """,
            *args,
        )
        return [DocumentRecord.from_row(r) for r in rows], int(total or 0)

    async def count(self, *, include_deleted: bool = False) -> int:
        where = "" if include_deleted else "WHERE deleted_at IS NULL"
        return int(await self._db.fetchval(f"SELECT count(*) FROM documents {where}") or 0)

    async def counts_by_source(self) -> dict[str, int]:
        rows = await self._db.fetch(
            "SELECT source_system::text AS s, count(*)::int AS c FROM documents "
            "WHERE deleted_at IS NULL GROUP BY 1 ORDER BY 1"
        )
        return {r["s"]: r["c"] for r in rows}

    async def counts_by_kind(self) -> dict[str, int]:
        rows = await self._db.fetch(
            "SELECT kind, count(*)::int AS c FROM documents WHERE deleted_at IS NULL GROUP BY 1"
        )
        return {r["kind"]: r["c"] for r in rows}

    async def graph_sync_breakdown(self) -> dict[str, int]:
        rows = await self._db.fetch(
            "SELECT graph_sync_status::text AS s, count(*)::int AS c FROM documents "
            "WHERE deleted_at IS NULL GROUP BY 1"
        )
        return {r["s"]: r["c"] for r in rows}

    async def count_graph_unsynced(self) -> int:
        return int(
            await self._db.fetchval(
                "SELECT count(*) FROM documents "
                "WHERE deleted_at IS NULL AND graph_sync_status <> 'synced'"
            )
            or 0
        )

    async def list_graph_unsynced(self, limit: int = 100) -> list[DocumentRecord]:
        rows = await self._db.fetch(
            f"""
            SELECT {_COLUMNS} FROM documents d
            WHERE d.deleted_at IS NULL AND d.graph_sync_status <> 'synced'
            ORDER BY d.updated_at ASC
            LIMIT $1
            """,
            limit,
        )
        return [DocumentRecord.from_row(r) for r in rows]

    # ------------------------------------------------------------------ writes
    async def upsert(
        self, conn: asyncpg.Connection, data: DocumentUpsert, *, content_changed: bool
    ) -> DocumentRecord:
        """Insert or update a document.

        ``content_changed`` bumps ``version`` and resets ``graph_sync_status`` to
        ``pending`` so the reconciliation job knows the graph is stale.
        """
        row = await conn.fetchrow(
            _UPSERT_SQL,
            data.id,
            data.source_system.value,
            data.external_id,
            data.title,
            data.uri,
            data.author,
            data.mime_type,
            data.language,
            data.content_hash,
            data.content_length,
            data.attributes,
            data.source_created_at,
            data.source_updated_at,
            data.last_run_id,
            content_changed,
            data.kind.value,
        )
        assert row is not None
        return DocumentRecord.from_row(row)

    async def set_graph_pending(self, conn: asyncpg.Connection, document_id: UUID) -> None:
        await conn.execute(
            "UPDATE documents SET graph_sync_status = 'pending', graph_sync_error = NULL "
            "WHERE id = $1",
            document_id,
        )

    async def mark_graph_synced(self, document_id: UUID, node_id: str | None) -> None:
        await self._db.execute(
            """
            UPDATE documents
               SET graph_sync_status = 'synced', graph_node_id = $2,
                   graph_synced_at = now(), graph_sync_error = NULL
             WHERE id = $1
            """,
            document_id,
            node_id,
        )

    async def mark_graph_failed(self, document_id: UUID, error: str) -> None:
        await self._db.execute(
            "UPDATE documents SET graph_sync_status = 'failed', graph_sync_error = $2 "
            "WHERE id = $1",
            document_id,
            error[:2000],
        )

    async def delete(self, document_id: UUID) -> bool:
        """Hard delete (chunks + embeddings cascade). Graph cleanup is the caller's job."""
        result = await self._db.execute("DELETE FROM documents WHERE id = $1", document_id)
        return result.endswith("1")

    async def soft_delete(self, document_id: UUID) -> bool:
        result = await self._db.execute(
            "UPDATE documents SET deleted_at = now() WHERE id = $1 AND deleted_at IS NULL",
            document_id,
        )
        return result.endswith("1")
