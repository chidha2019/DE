"""Postgres/pgvector access for ``embeddings`` including the dense search leg."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any
from uuid import UUID

import asyncpg

from ech_core.db.postgres import PostgresDatabase
from ech_core.domain.enums import SourceSystem
from ech_core.domain.models import EmbeddingRecord, ScoredChunk
from ech_core.repositories.chunk_repository import document_filter_sql

_UPSERT_SQL = """
INSERT INTO embeddings (chunk_id, model, dimensions, embedding)
VALUES ($1, $2, $3, $4::text::vector)
ON CONFLICT (chunk_id) DO UPDATE SET
    model = EXCLUDED.model,
    dimensions = EXCLUDED.dimensions,
    embedding = EXCLUDED.embedding,
    created_at = now()
"""


def vector_literal(vector: Sequence[float]) -> str:
    """Serialise to pgvector's text input form ``[x1,x2,...]``.

    We pass vectors as text and cast ``$n::text::vector`` so asyncpg needs no
    custom codec for the ``vector`` type.
    """
    return "[" + ",".join(f"{float(x):.8g}" for x in vector) + "]"


class EmbeddingRepository:
    def __init__(self, db: PostgresDatabase) -> None:
        self._db = db

    async def upsert_many(self, conn: asyncpg.Connection, records: list[EmbeddingRecord]) -> None:
        if not records:
            return
        await conn.executemany(
            _UPSERT_SQL,
            [(r.chunk_id, r.model, r.dimensions, vector_literal(r.vector)) for r in records],
        )

    async def count(self) -> int:
        return int(await self._db.fetchval("SELECT count(*) FROM embeddings") or 0)

    async def vector_search(
        self,
        query_vector: Sequence[float],
        *,
        limit: int,
        ef_search: int = 100,
        source_systems: list[SourceSystem] | None = None,
        document_ids: list[UUID] | None = None,
        attributes: dict[str, Any] | None = None,
    ) -> list[ScoredChunk]:
        """Approximate nearest neighbours by cosine distance via the HNSW index.

        ``hnsw.ef_search`` is raised per query for recall; when filters are
        present we additionally enable pgvector 0.8+'s iterative scan so the
        index keeps searching until ``limit`` rows satisfy the WHERE clause
        (older servers silently ignore it thanks to the savepoint).
        """
        where, args, n = document_filter_sql(
            next_param=2,
            source_systems=source_systems,
            document_ids=document_ids,
            attributes=attributes,
        )
        sql = f"""
            SELECT c.id AS chunk_id, c.document_id,
                   (1 - (e.embedding <=> $1::text::vector))::float8 AS score
              FROM embeddings e
              JOIN chunks c ON c.id = e.chunk_id
              JOIN documents d ON d.id = c.document_id
             WHERE {where}
             ORDER BY e.embedding <=> $1::text::vector
             LIMIT ${n}
        """
        literal = vector_literal(query_vector)
        async with self._db.acquire() as conn:
            async with conn.transaction():
                await conn.execute(f"SET LOCAL hnsw.ef_search = {int(ef_search)}")
                if args:
                    try:
                        async with conn.transaction():  # savepoint: GUC may not exist
                            await conn.execute("SET LOCAL hnsw.iterative_scan = relaxed_order")
                    except asyncpg.PostgresError:
                        pass
                rows = await conn.fetch(sql, literal, *args, limit)
        return [ScoredChunk(**dict(r)) for r in rows]
