"""Postgres access for the business glossary, domains, term links and KPIs (migration 0011)."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from ech_core.db.postgres import PostgresDatabase

_TERM_COLUMNS = """
    t.id, t.key, t.name, t.definition, t.domain_key, d.name AS domain_name, t.kind,
    t.synonyms, t.standard, t.standard_ref, t.status, t.proposed_by, t.rationale, t.updated_at,
    (SELECT count(*) FROM semantic_term_links l WHERE l.term_id = t.id AND l.status = 'accepted' AND l.target_type = 'asset')::int AS linked_assets,
    (SELECT count(*) FROM semantic_term_links l WHERE l.term_id = t.id AND l.status = 'accepted' AND l.target_type = 'field')::int AS linked_fields,
    (SELECT count(*) FROM semantic_term_links l WHERE l.term_id = t.id AND l.status = 'accepted' AND l.target_type = 'metric')::int AS linked_metrics,
    (SELECT count(*) FROM semantic_term_links l WHERE l.term_id = t.id AND l.status = 'suggested')::int AS suggested
"""

# A link with the label of what it points at, whatever the target type.
_LINK_SQL = """
    SELECT l.id, l.term_id, t.key AS term_key, t.name AS term_name, t.domain_key,
           l.target_type, l.target_id, l.confidence, l.source, l.status, l.rationale, l.model,
           l.created_at, l.decided_at,
           CASE l.target_type
             WHEN 'asset'  THEN coalesce(nullif(a.display_name, ''), a.name)
             WHEN 'field'  THEN f.name
             WHEN 'metric' THEN coalesce(nullif(m.display_name, ''), m.name)
           END AS target_label,
           CASE l.target_type
             WHEN 'asset'  THEN a.fqn
             WHEN 'field'  THEN fa.fqn
             WHEN 'metric' THEN ma.fqn
           END AS target_context,
           CASE l.target_type
             WHEN 'asset'  THEN a.id
             WHEN 'field'  THEN f.asset_id
             WHEN 'metric' THEN m.asset_id
           END AS asset_id
      FROM semantic_term_links l
      JOIN semantic_terms t ON t.id = l.term_id
      LEFT JOIN semantic_assets a  ON l.target_type = 'asset'  AND a.id = l.target_id
      LEFT JOIN semantic_fields f  ON l.target_type = 'field'  AND f.id = l.target_id
      LEFT JOIN semantic_assets fa ON fa.id = f.asset_id
      LEFT JOIN semantic_metrics m ON l.target_type = 'metric' AND m.id = l.target_id
      LEFT JOIN semantic_assets ma ON ma.id = m.asset_id
"""


def _jsonb_list(value: Any) -> list[str]:
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except ValueError:
            return []
    return [str(v) for v in value] if isinstance(value, list) else []


def _row(record: Any) -> dict[str, Any]:
    row = dict(record)
    if "synonyms" in row:
        row["synonyms"] = _jsonb_list(row["synonyms"])
    return row


class GlossaryRepository:
    def __init__(self, db: PostgresDatabase) -> None:
        self._db = db

    # ------------------------------------------------------------------ domains
    async def domains(self) -> list[dict[str, Any]]:
        rows = await self._db.fetch(
            """
            SELECT d.key, d.name, d.parent_key, d.description, d.standard, d.standard_ref, d.sort_order,
                   (SELECT count(*) FROM semantic_terms t WHERE t.domain_key = d.key AND t.status <> 'proposed')::int AS term_count,
                   (SELECT count(*) FROM semantic_assets a WHERE a.domain_key = d.key)::int AS asset_count,
                   (SELECT count(*) FROM semantic_kpis k WHERE k.domain_key = d.key)::int AS kpi_count
              FROM semantic_domains d
             ORDER BY d.sort_order, d.name
            """
        )
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------ terms
    async def terms(
        self,
        *,
        search: str | None,
        domain: str | None,
        kind: str | None,
        standard: str | None,
        limit: int,
        offset: int,
        status: str | None = None,
        include_proposed: bool = True,
    ) -> tuple[list[dict[str, Any]], int]:
        clauses: list[str] = []
        args: list[Any] = []
        if status:
            args.append(status)
            clauses.append(f"t.status = ${len(args)}")
        elif not include_proposed:
            clauses.append("t.status <> 'proposed'")
        if search:
            args.append(f"%{search.strip()}%")
            n = len(args)
            clauses.append(f"(t.name ILIKE ${n} OR t.definition ILIKE ${n} OR t.synonyms::text ILIKE ${n})")
        if domain:
            args.append(domain)
            clauses.append(f"(t.domain_key = ${len(args)} OR d.parent_key = ${len(args)})")
        if kind:
            args.append(kind)
            clauses.append(f"t.kind = ${len(args)}")
        if standard:
            args.append(standard)
            clauses.append(f"t.standard = ${len(args)}")
        where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
        total = await self._db.fetchval(
            f"SELECT count(*) FROM semantic_terms t LEFT JOIN semantic_domains d ON d.key = t.domain_key {where}", *args
        )
        rows = await self._db.fetch(
            f"""
            SELECT {_TERM_COLUMNS}
              FROM semantic_terms t
              LEFT JOIN semantic_domains d ON d.key = t.domain_key
            {where}
             ORDER BY t.name
             LIMIT ${len(args) + 1} OFFSET ${len(args) + 2}
            """,
            *args,
            limit,
            offset,
        )
        return [_row(r) for r in rows], int(total or 0)

    async def term(self, term_id: UUID) -> dict[str, Any] | None:
        row = await self._db.fetchrow(
            f"SELECT {_TERM_COLUMNS} FROM semantic_terms t LEFT JOIN semantic_domains d ON d.key = t.domain_key WHERE t.id = $1",
            term_id,
        )
        return _row(row) if row else None

    async def catalog(self, *, include_proposed: bool = False) -> list[dict[str, Any]]:
        """Every reviewed term, compact: what the matcher and the model prompt need. Proposed ones only on request."""
        where = "" if include_proposed else "WHERE t.status <> 'proposed'"
        rows = await self._db.fetch(
            f"SELECT t.id, t.key, t.name, t.domain_key, t.kind, t.synonyms, t.definition, t.status FROM semantic_terms t {where} ORDER BY t.name"
        )
        return [_row(r) for r in rows]

    async def term_by_key(self, key: str) -> dict[str, Any] | None:
        row = await self._db.fetchrow("SELECT id FROM semantic_terms WHERE key = $1", key)
        return await self.term(row["id"]) if row else None

    async def create_proposed_term(
        self,
        *,
        key: str,
        name: str,
        definition: str,
        domain_key: str | None,
        kind: str,
        synonyms: list[str],
        proposed_by: str | None,
        rationale: str,
    ) -> dict[str, Any] | None:
        """A candidate term from Claude; None when the key is already taken (the caller links to that term instead)."""
        row = await self._db.fetchrow(
            """
            INSERT INTO semantic_terms (key, name, definition, domain_key, kind, synonyms, standard, status, proposed_by, rationale)
            VALUES ($1, $2, $3, $4, $5, $6::jsonb, 'hub', 'proposed', $7, $8)
            ON CONFLICT (key) DO NOTHING
            RETURNING id
            """,
            key,
            name,
            definition,
            domain_key,
            kind,
            json.dumps(synonyms),
            proposed_by,
            rationale[:500],
        )
        return await self.term(row["id"]) if row else None

    async def decide_term(self, term_id: UUID, *, accept: bool) -> bool:
        """Accept a proposed term (it becomes curated) or reject it (deleted with its links). False when not proposed."""
        if accept:
            status = await self._db.execute(
                "UPDATE semantic_terms SET status = 'curated', updated_at = now() WHERE id = $1 AND status = 'proposed'", term_id
            )
        else:
            status = await self._db.execute("DELETE FROM semantic_terms WHERE id = $1 AND status = 'proposed'", term_id)
        return status.endswith(" 1")

    async def suggested_link_ids(self, term_id: UUID) -> list[UUID]:
        rows = await self._db.fetch("SELECT id FROM semantic_term_links WHERE term_id = $1 AND status = 'suggested'", term_id)
        return [r["id"] for r in rows]

    async def create_term(
        self, *, key: str, name: str, definition: str, domain_key: str | None, kind: str, synonyms: list[str]
    ) -> dict[str, Any]:
        row = await self._db.fetchrow(
            """
            INSERT INTO semantic_terms (key, name, definition, domain_key, kind, synonyms, standard, status)
            VALUES ($1, $2, $3, $4, $5, $6::jsonb, 'hub', 'curated')
            RETURNING id
            """,
            key,
            name,
            definition,
            domain_key,
            kind,
            json.dumps(synonyms),
        )
        assert row is not None
        found = await self.term(row["id"])
        assert found is not None
        return found

    async def update_term(self, term_id: UUID, **fields: Any) -> dict[str, Any] | None:
        sets: list[str] = ["status = 'curated'", "updated_at = now()"]
        args: list[Any] = []
        for column in ("name", "definition", "domain_key", "kind"):
            if column in fields:
                args.append(fields[column])
                sets.append(f"{column} = ${len(args)}")
        if "synonyms" in fields:
            args.append(json.dumps(fields["synonyms"]))
            sets.append(f"synonyms = ${len(args)}::jsonb")
        args.append(term_id)
        await self._db.execute(f"UPDATE semantic_terms SET {', '.join(sets)} WHERE id = ${len(args)}", *args)
        return await self.term(term_id)

    # ------------------------------------------------------------------ links
    async def links(
        self,
        *,
        status: str | None,
        target_type: str | None,
        target_id: UUID | None,
        term_id: UUID | None,
        asset_id: UUID | None = None,
        term_status: str | None = None,
        limit: int,
        offset: int,
    ) -> tuple[list[dict[str, Any]], int]:
        clauses: list[str] = []
        args: list[Any] = []
        if status:
            args.append(status)
            clauses.append(f"l.status = ${len(args)}")
        if term_status == "proposed":
            clauses.append("t.status = 'proposed'")
        elif term_status == "reviewed":
            clauses.append("t.status <> 'proposed'")
        if target_type:
            args.append(target_type)
            clauses.append(f"l.target_type = ${len(args)}")
        if target_id:
            args.append(target_id)
            clauses.append(f"l.target_id = ${len(args)}")
        if term_id:
            args.append(term_id)
            clauses.append(f"l.term_id = ${len(args)}")
        if asset_id:
            args.append(asset_id)
            clauses.append(f"(a.id = ${len(args)} OR f.asset_id = ${len(args)} OR m.asset_id = ${len(args)})")
        where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
        total = await self._db.fetchval(f"SELECT count(*) FROM ({_LINK_SQL} {where}) q", *args)
        rows = await self._db.fetch(
            f"{_LINK_SQL} {where} ORDER BY l.status = 'suggested' DESC, l.confidence DESC, l.created_at DESC "
            f"LIMIT ${len(args) + 1} OFFSET ${len(args) + 2}",
            *args,
            limit,
            offset,
        )
        return [dict(r) for r in rows], int(total or 0)

    async def link(self, link_id: UUID) -> dict[str, Any] | None:
        row = await self._db.fetchrow(f"{_LINK_SQL} WHERE l.id = $1", link_id)
        return dict(row) if row else None

    async def upsert_link(
        self,
        *,
        term_id: UUID,
        target_type: str,
        target_id: UUID,
        confidence: float,
        source: str,
        rationale: str,
        model: str | None = None,
    ) -> tuple[dict[str, Any] | None, bool]:
        """Insert a suggestion, or raise the confidence of an existing undecided one. Decided links are left alone.

        Returns (row, created).
        """
        row = await self._db.fetchrow(
            """
            INSERT INTO semantic_term_links (term_id, target_type, target_id, confidence, source, rationale, model)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            ON CONFLICT (term_id, target_type, target_id) DO UPDATE
               SET confidence = GREATEST(semantic_term_links.confidence, EXCLUDED.confidence),
                   rationale  = CASE WHEN EXCLUDED.confidence > semantic_term_links.confidence
                                     THEN EXCLUDED.rationale ELSE semantic_term_links.rationale END,
                   source     = CASE WHEN EXCLUDED.confidence > semantic_term_links.confidence
                                     THEN EXCLUDED.source ELSE semantic_term_links.source END,
                   model      = coalesce(EXCLUDED.model, semantic_term_links.model)
             WHERE semantic_term_links.status = 'suggested'
            RETURNING id, (xmax = 0) AS created
            """,
            term_id,
            target_type,
            target_id,
            float(confidence),
            source,
            rationale[:500],
            model,
        )
        if row is None:
            return None, False
        return await self.link(row["id"]), bool(row["created"])

    async def create_curated_link(self, *, term_id: UUID, target_type: str, target_id: UUID) -> dict[str, Any] | None:
        """A link a person made directly: accepted at once."""
        row = await self._db.fetchrow(
            """
            INSERT INTO semantic_term_links (term_id, target_type, target_id, confidence, source, status, rationale, decided_at)
            VALUES ($1, $2, $3, 1.0, 'curated', 'accepted', 'linked by a person', now())
            ON CONFLICT (term_id, target_type, target_id) DO UPDATE
               SET status = 'accepted', source = 'curated', confidence = 1.0, decided_at = now()
            RETURNING id
            """,
            term_id,
            target_type,
            target_id,
        )
        if row is None:
            return None
        await self._apply_accepted(row["id"])
        return await self.link(row["id"])

    async def decide_link(self, link_id: UUID, status: str) -> dict[str, Any] | None:
        await self._db.execute(
            "UPDATE semantic_term_links SET status = $2, decided_at = $3 WHERE id = $1", link_id, status, datetime.now(tz=UTC)
        )
        if status == "accepted":
            await self._apply_accepted(link_id)
        return await self.link(link_id)

    async def _apply_accepted(self, link_id: UUID) -> None:
        """Copy the term's synonyms onto the column or metric; give the dataset the term's domain."""
        await self._db.execute(
            """
            UPDATE semantic_fields f
               SET synonyms = (SELECT coalesce(jsonb_agg(DISTINCT v), '[]'::jsonb)
                                 FROM jsonb_array_elements(f.synonyms || t.synonyms || to_jsonb(ARRAY[t.name])) v)
              FROM semantic_term_links l JOIN semantic_terms t ON t.id = l.term_id
             WHERE l.id = $1 AND l.target_type = 'field' AND f.id = l.target_id
            """,
            link_id,
        )
        await self._db.execute(
            """
            UPDATE semantic_metrics m
               SET synonyms = (SELECT coalesce(jsonb_agg(DISTINCT v), '[]'::jsonb)
                                 FROM jsonb_array_elements(m.synonyms || t.synonyms || to_jsonb(ARRAY[t.name])) v)
              FROM semantic_term_links l JOIN semantic_terms t ON t.id = l.term_id
             WHERE l.id = $1 AND l.target_type = 'metric' AND m.id = l.target_id
            """,
            link_id,
        )
        await self._db.execute(
            """
            UPDATE semantic_assets a
               SET domain_key = coalesce(a.domain_key, coalesce(d.parent_key, d.key))
              FROM semantic_term_links l
              JOIN semantic_terms t ON t.id = l.term_id
              LEFT JOIN semantic_domains d ON d.key = t.domain_key
             WHERE l.id = $1 AND l.target_type = 'asset' AND a.id = l.target_id AND t.domain_key IS NOT NULL
            """,
            link_id,
        )
        # A KPI bound to the same term adopts the metric when it has none yet.
        await self._db.execute(
            """
            UPDATE semantic_kpis k
               SET metric_id = l.target_id, updated_at = now()
              FROM semantic_term_links l
             WHERE l.id = $1 AND l.target_type = 'metric' AND k.term_id = l.term_id AND k.metric_id IS NULL
            """,
            link_id,
        )

    # ------------------------------------------------------------------ kpis
    async def kpis(self, *, domain: str | None) -> list[dict[str, Any]]:
        args: list[Any] = []
        where = ""
        if domain:
            args.append(domain)
            where = "WHERE (k.domain_key = $1 OR d.parent_key = $1)"
        rows = await self._db.fetch(
            f"""
            SELECT k.id, k.key, k.name, k.domain_key, d.name AS domain_name, k.term_id, t.name AS term_name,
                   k.metric_id, coalesce(nullif(m.display_name, ''), m.name) AS metric_name,
                   m.asset_id AS metric_asset_id, ma.fqn AS metric_asset_fqn,
                   k.definition, k.formula, k.grain, k.period, k.unit, k.direction, k.target_value, k.warn_value,
                   k.owner, k.standard_ref, k.status, k.updated_at
              FROM semantic_kpis k
              LEFT JOIN semantic_domains d ON d.key = k.domain_key
              LEFT JOIN semantic_terms t ON t.id = k.term_id
              LEFT JOIN semantic_metrics m ON m.id = k.metric_id
              LEFT JOIN semantic_assets ma ON ma.id = m.asset_id
            {where}
             ORDER BY d.sort_order NULLS LAST, k.name
            """,
            *args,
        )
        return [dict(r) for r in rows]

    async def kpi(self, kpi_id: UUID) -> dict[str, Any] | None:
        rows = await self.kpis(domain=None)
        return next((r for r in rows if r["id"] == kpi_id), None)

    async def update_kpi(self, kpi_id: UUID, **fields: Any) -> dict[str, Any] | None:
        sets: list[str] = ["status = 'curated'", "updated_at = now()"]
        args: list[Any] = []
        for column in ("metric_id", "target_value", "warn_value", "owner", "definition", "formula", "grain", "period", "unit", "direction"):
            if column in fields:
                args.append(fields[column])
                sets.append(f"{column} = ${len(args)}")
        args.append(kpi_id)
        await self._db.execute(f"UPDATE semantic_kpis SET {', '.join(sets)} WHERE id = ${len(args)}", *args)
        return await self.kpi(kpi_id)

    # ------------------------------------------------------------------ mapping inputs
    async def mapping_targets(self, asset_ids: list[UUID]) -> dict[str, list[dict[str, Any]]]:
        """Datasets, their columns and their metrics, with what the matcher and the prompt need."""
        assets = await self._db.fetch(
            """
            SELECT a.id, a.fqn, a.name, a.display_name, a.summary, a.description, a.kind, a.domain_key
              FROM semantic_assets a WHERE a.id = ANY($1::uuid[]) ORDER BY a.fqn
            """,
            asset_ids,
        )
        fields = await self._db.fetch(
            """
            SELECT f.id, f.asset_id, f.name, f.display_name, f.role, f.data_type, f.description, f.synonyms
              FROM semantic_fields f WHERE f.asset_id = ANY($1::uuid[]) ORDER BY f.asset_id, f.ordinal
            """,
            asset_ids,
        )
        metrics = await self._db.fetch(
            """
            SELECT m.id, m.asset_id, m.name, m.display_name, m.expression, m.description, m.synonyms
              FROM semantic_metrics m WHERE m.asset_id = ANY($1::uuid[]) ORDER BY m.asset_id, m.name
            """,
            asset_ids,
        )
        return {
            "assets": [dict(r) for r in assets],
            "fields": [_row(r) for r in fields],
            "metrics": [_row(r) for r in metrics],
        }

    async def unmapped_targets(self, asset_ids: list[UUID]) -> dict[str, list[dict[str, Any]]]:
        """Columns and metrics in the scope with no accepted or pending term link (rejected ones count as unmapped)."""
        assets = await self._db.fetch(
            """
            SELECT a.id, a.fqn, a.name, a.display_name, a.summary, a.description, a.kind, a.domain_key
              FROM semantic_assets a WHERE a.id = ANY($1::uuid[]) ORDER BY a.fqn
            """,
            asset_ids,
        )
        fields = await self._db.fetch(
            """
            SELECT f.id, f.asset_id, f.name, f.display_name, f.role, f.data_type, f.description, f.synonyms
              FROM semantic_fields f
             WHERE f.asset_id = ANY($1::uuid[])
               AND NOT EXISTS (SELECT 1 FROM semantic_term_links l
                                WHERE l.target_type = 'field' AND l.target_id = f.id AND l.status IN ('accepted', 'suggested'))
             ORDER BY f.asset_id, f.ordinal
            """,
            asset_ids,
        )
        metrics = await self._db.fetch(
            """
            SELECT m.id, m.asset_id, m.name, m.display_name, m.expression, m.description, m.synonyms
              FROM semantic_metrics m
             WHERE m.asset_id = ANY($1::uuid[])
               AND NOT EXISTS (SELECT 1 FROM semantic_term_links l
                                WHERE l.target_type = 'metric' AND l.target_id = m.id AND l.status IN ('accepted', 'suggested'))
             ORDER BY m.asset_id, m.name
            """,
            asset_ids,
        )
        return {
            "assets": [dict(r) for r in assets],
            "fields": [_row(r) for r in fields],
            "metrics": [_row(r) for r in metrics],
        }

    async def scope_asset_ids(
        self, *, source_system: str | None, database: str | None, schema: str | None, limit: int
    ) -> list[UUID]:
        clauses: list[str] = []
        args: list[Any] = []
        if source_system:
            args.append(source_system)
            clauses.append(f"a.source_system::text = ${len(args)}")
        if database:
            args.append(database)
            clauses.append(f"a.database_name = ${len(args)}")
        if schema:
            args.append(schema)
            clauses.append(f"a.schema_name = ${len(args)}")
        where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
        args.append(limit)
        rows = await self._db.fetch(f"SELECT a.id FROM semantic_assets a {where} ORDER BY a.fqn LIMIT ${len(args)}", *args)
        return [r["id"] for r in rows]

    # ------------------------------------------------------------------ coverage
    async def coverage(self) -> dict[str, Any]:
        row = await self._db.fetchrow(
            """
            SELECT
              (SELECT count(*) FROM semantic_terms WHERE status <> 'proposed')::int AS terms_total,
              (SELECT count(*) FROM semantic_terms WHERE status = 'proposed')::int AS terms_proposed,
              (SELECT count(DISTINCT term_id) FROM semantic_term_links WHERE status = 'accepted')::int AS terms_linked,
              (SELECT count(*) FROM semantic_domains)::int AS domains_total,
              (SELECT count(*) FROM semantic_assets)::int AS assets_total,
              (SELECT count(*) FROM semantic_assets WHERE domain_key IS NOT NULL)::int AS assets_with_domain,
              (SELECT count(DISTINCT target_id) FROM semantic_term_links WHERE status = 'accepted' AND target_type = 'asset')::int AS assets_with_terms,
              (SELECT count(*) FROM semantic_fields)::int AS fields_total,
              (SELECT count(DISTINCT target_id) FROM semantic_term_links WHERE status = 'accepted' AND target_type = 'field')::int AS fields_with_terms,
              (SELECT count(*) FROM semantic_fields WHERE jsonb_array_length(synonyms) > 0)::int AS fields_with_synonyms,
              (SELECT count(*) FROM semantic_metrics)::int AS metrics_total,
              (SELECT count(DISTINCT target_id) FROM semantic_term_links WHERE status = 'accepted' AND target_type = 'metric')::int AS metrics_with_terms,
              (SELECT count(*) FROM semantic_kpis)::int AS kpis_total,
              (SELECT count(*) FROM semantic_kpis WHERE metric_id IS NOT NULL)::int AS kpis_with_metric,
              (SELECT count(*) FROM semantic_kpis WHERE target_value IS NOT NULL)::int AS kpis_with_target,
              (SELECT count(*) FROM semantic_term_links WHERE status = 'suggested')::int AS links_suggested,
              (SELECT count(*) FROM semantic_term_links WHERE status = 'accepted')::int AS links_accepted,
              (SELECT count(*) FROM semantic_term_links WHERE status = 'rejected')::int AS links_rejected
            """
        )
        return dict(row) if row else {}

    # ------------------------------------------------------------------ mapping after syncs (migration 0017)
    async def map_fingerprints(self, asset_ids: list[UUID]) -> dict[UUID, str]:
        """What Claude last saw of each dataset; a missing entry means Claude never mapped it."""
        rows = await self._db.fetch("SELECT asset_id, fingerprint FROM glossary_map_state WHERE asset_id = ANY($1::uuid[])", asset_ids)
        return {r["asset_id"]: r["fingerprint"] for r in rows}

    async def save_map_fingerprint(self, asset_id: UUID, fingerprint: str, model: str | None) -> None:
        await self._db.execute(
            """
            INSERT INTO glossary_map_state (asset_id, fingerprint, model, mapped_at) VALUES ($1, $2, $3, now())
            ON CONFLICT (asset_id) DO UPDATE SET fingerprint = EXCLUDED.fingerprint, model = EXCLUDED.model, mapped_at = now()
            """,
            asset_id,
            fingerprint,
            model,
        )

    async def pending_syncs(self) -> list[dict[str, Any]]:
        """Successful Snowflake and Databricks syncs that finished since the cursor and no mapping pass covers yet."""
        rows = await self._db.fetch(
            """
            SELECT r.id, r.source_system::text AS source_system, r.finished_at
              FROM ingestion_runs r, glossary_auto_cursor c
             WHERE r.status = 'completed'
               AND r.source_system IN ('snowflake', 'databricks')
               AND r.finished_at >= c.since
               AND NOT EXISTS (SELECT 1 FROM glossary_auto_runs g WHERE r.id = ANY(g.ingestion_run_ids))
             ORDER BY r.finished_at
            """
        )
        return [dict(r) for r in rows]

    async def start_auto_run(self, source_system: str, ingestion_run_ids: list[UUID]) -> UUID:
        return await self._db.fetchval(
            "INSERT INTO glossary_auto_runs (source_system, ingestion_run_ids) VALUES ($1::source_system, $2::uuid[]) RETURNING id",
            source_system,
            ingestion_run_ids,
        )

    async def finish_auto_run(self, run_id: UUID, *, status: str, counts: dict[str, int], message: str | None, error: str | None) -> None:
        await self._db.execute(
            """
            UPDATE glossary_auto_runs
               SET status = $2, datasets = $3, model_datasets = $4, unchanged = $5, model_failed = $6,
                   rule_links = $7, model_links = $8, message = $9, error = $10, finished_at = now()
             WHERE id = $1
            """,
            run_id,
            status,
            counts.get("datasets", 0),
            counts.get("model_datasets", 0),
            counts.get("unchanged", 0),
            counts.get("model_failed", 0),
            counts.get("rule_links", 0),
            counts.get("model_links", 0),
            message,
            error,
        )

    async def drop_unfinished_auto_runs(self) -> int:
        """Passes a restart interrupted: dropping them puts their syncs back in the queue."""
        result = await self._db.execute("DELETE FROM glossary_auto_runs WHERE status = 'running'")
        return int(result.split()[-1]) if result else 0

    async def auto_runs(self, limit: int = 10) -> list[dict[str, Any]]:
        rows = await self._db.fetch(
            """
            SELECT id, source_system::text AS source_system, ingestion_run_ids, status, datasets, model_datasets, unchanged,
                   model_failed, rule_links, model_links, message, error, started_at, finished_at
              FROM glossary_auto_runs ORDER BY started_at DESC LIMIT $1
            """,
            limit,
        )
        return [dict(r) for r in rows]
