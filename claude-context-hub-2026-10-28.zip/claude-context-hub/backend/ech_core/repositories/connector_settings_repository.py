"""Connection settings saved from the hub (migration 0016): one row per connector."""

from __future__ import annotations

from typing import Any

from ech_core.db.postgres import PostgresDatabase


class ConnectorSettingsRepository:
    def __init__(self, db: PostgresDatabase) -> None:
        self._db = db

    async def all(self) -> list[dict[str, Any]]:
        rows = await self._db.fetch("SELECT connector, settings, secrets, updated_by, updated_at FROM connector_settings")
        return [dict(r) for r in rows]

    async def get(self, connector: str) -> dict[str, Any] | None:
        row = await self._db.fetchrow(
            "SELECT connector, settings, secrets, updated_by, updated_at FROM connector_settings WHERE connector = $1", connector
        )
        return dict(row) if row else None

    async def upsert(self, connector: str, settings: dict[str, Any], secrets: bytes | None, updated_by: str | None) -> None:
        await self._db.execute(
            """
            INSERT INTO connector_settings (connector, settings, secrets, updated_by, updated_at)
            VALUES ($1, $2, $3, $4, now())
            ON CONFLICT (connector) DO UPDATE
               SET settings = EXCLUDED.settings, secrets = EXCLUDED.secrets,
                   updated_by = EXCLUDED.updated_by, updated_at = now()
            """,
            connector,
            settings,
            secrets,
            updated_by,
        )

    async def delete(self, connector: str) -> None:
        await self._db.execute("DELETE FROM connector_settings WHERE connector = $1", connector)
