"""Neo4j access: document subgraph sync, GraphRAG expansion, explorer & lineage queries.

Consistency contract with Postgres
----------------------------------
* ``Document.document_id`` == ``documents.id`` and ``Chunk.chunk_id`` == ``chunks.id``
  (both deterministic uuid5 values, see :mod:`ech_core.ids`).
* :meth:`GraphRepository.sync_document` rewrites one document's subgraph inside a
  single managed write transaction: either the whole subgraph (document, chunks,
  mentions, contributors, references, dependencies) is committed or nothing is.
* The caller flips ``documents.graph_sync_status`` to ``synced``/``failed``
  afterwards; ``pending``/``failed`` rows are retried by the reconciliation job.
"""

from __future__ import annotations

import re
from collections import defaultdict
from typing import Any
from uuid import UUID

from neo4j import AsyncManagedTransaction

from ech_core.db.neo4j import GraphDatabase
from ech_core.domain.enums import EntityType
from ech_core.domain.models import (
    ExpandedChunk,
    GraphDocumentPayload,
    GraphEntityRef,
    GraphExpansion,
)

_ALLOWED_ENTITY_LABELS = {e.value for e in EntityType}
_LUCENE_SPECIAL_RE = re.compile(r'([+\-!(){}\[\]^"~*?:\\/]|&&|\|\|)')

# ----------------------------------------------------------------------------- write cypher
_MERGE_DOCUMENT = """
MERGE (d:Document {document_id: $document_id})
ON CREATE SET d.created_at = datetime()
SET d.external_id = $external_id, d.source_system = $source_system, d.title = $title,
    d.uri = $uri, d.author = $author, d.version = $version, d.mime_type = $mime_type,
    d.stub = false, d.updated_at = datetime()
RETURN elementId(d) AS node_id
"""

_DELETE_CHUNKS = """
MATCH (:Document {document_id: $document_id})-[:HAS_CHUNK]->(c:Chunk)
DETACH DELETE c
"""

_DELETE_DOC_RELS = """
MATCH (:Document {document_id: $document_id})-[r:REFERENCES|CONTRIBUTED_BY]->()
DELETE r
"""

# Retract this document's contribution from entity->entity DEPENDS_ON edges.
# Each edge keeps parallel lists `evidence` (document ids) and `weights`, so a
# re-sync subtracts exactly what the previous version added and edges with no
# remaining evidence disappear (their entities then become reconcilable orphans).
# Scans DEPENDS_ON edges once per document sync; fine for graphs with up to ~10^5
# such edges — beyond that, model evidence as nodes.
_RETRACT_DEPENDENCIES = """
MATCH (:Entity)-[r:DEPENDS_ON]->(:Entity)
WHERE $document_id IN coalesce(r.evidence, [])
WITH r, [i IN range(0, size(r.evidence) - 1) WHERE r.evidence[i] <> $document_id] AS keep
SET r.evidence = [i IN keep | r.evidence[i]],
    r.weights  = [i IN keep | coalesce(coalesce(r.weights, [])[i], 1.0)]
SET r.weight = reduce(s = 0.0, w IN r.weights | s + w)
WITH r WHERE size(r.evidence) = 0
DELETE r
"""

_CREATE_CHUNKS = """
MATCH (d:Document {document_id: $document_id})
UNWIND $chunks AS ch
MERGE (c:Chunk {chunk_id: ch.chunk_id})
SET c.document_id = $document_id, c.chunk_index = ch.chunk_index,
    c.token_count = ch.token_count, c.section_path = ch.section_path, c.preview = ch.preview
MERGE (d)-[:HAS_CHUNK]->(c)
"""

# %(label)s is interpolated from a whitelist (EntityType values only).
_CREATE_MENTIONS = """
UNWIND $mentions AS m
MATCH (c:Chunk {chunk_id: m.chunk_id})
MERGE (e:Entity {entity_key: m.key})
ON CREATE SET e.name = m.name, e.entity_type = m.entity_type,
              e.normalized_name = m.normalized_name, e.created_at = datetime(), e.aliases = []
SET e:%(label)s,
    e.last_seen_at = datetime(),
    e.aliases = CASE WHEN m.name <> e.name AND NOT m.name IN coalesce(e.aliases, [])
                     THEN coalesce(e.aliases, []) + m.name ELSE coalesce(e.aliases, []) END
MERGE (c)-[r:MENTIONS]->(e)
SET r.confidence = m.confidence
"""

_CREATE_CONTRIBUTORS = """
MATCH (d:Document {document_id: $document_id})
UNWIND $contributors AS p
MERGE (e:Entity {entity_key: p.key})
ON CREATE SET e.name = p.name, e.entity_type = 'Person', e.normalized_name = p.normalized_name,
              e.created_at = datetime(), e.aliases = []
SET e:Person, e.last_seen_at = datetime()
MERGE (d)-[r:CONTRIBUTED_BY]->(e)
SET r.role = p.role
"""

_CREATE_REFERENCES = """
MATCH (d:Document {document_id: $document_id})
UNWIND $references AS ref
MERGE (t:Document {document_id: ref.document_id})
ON CREATE SET t.stub = true, t.external_id = ref.external_id, t.source_system = ref.source_system,
              t.title = coalesce(ref.title, ref.external_id), t.created_at = datetime()
MERGE (d)-[r:REFERENCES]->(t)
SET r.kind = ref.kind
"""

_CREATE_DEPENDENCIES = """
UNWIND $dependencies AS dep
MATCH (a:Entity {entity_key: dep.from_key}), (b:Entity {entity_key: dep.to_key})
MERGE (a)-[r:DEPENDS_ON]->(b)
ON CREATE SET r.evidence = [], r.weights = []
SET r.evidence = coalesce(r.evidence, []) + $document_id,
    r.weights  = coalesce(r.weights, []) + dep.weight
SET r.weight = reduce(s = 0.0, w IN r.weights | s + w)
"""

_DELETE_DOCUMENT = """
MATCH (d:Document {document_id: $document_id})
OPTIONAL MATCH (d)-[:HAS_CHUNK]->(c:Chunk)
DETACH DELETE c
WITH DISTINCT d
DETACH DELETE d
"""

_PRUNE_DANGLING_DEPENDENCIES = """
MATCH ()-[r:DEPENDS_ON]->()
WITH r, [id IN coalesce(r.evidence, [])
         WHERE EXISTS { MATCH (:Document {document_id: id}) }] AS live
WHERE size(live) < size(coalesce(r.evidence, []))
WITH r, [i IN range(0, size(r.evidence) - 1) WHERE r.evidence[i] IN live] AS keep
SET r.evidence = [i IN keep | r.evidence[i]],
    r.weights  = [i IN keep | coalesce(coalesce(r.weights, [])[i], 1.0)]
SET r.weight = reduce(s = 0.0, w IN r.weights | s + w)
WITH r WHERE size(r.evidence) = 0
DELETE r
RETURN count(*) AS pruned
"""

_DELETE_ORPHAN_ENTITIES = """
MATCH (e:Entity) WHERE NOT (e)--()
WITH e LIMIT 5000
DELETE e
RETURN count(*) AS removed
"""

# ----------------------------------------------------------------------------- read cypher
_FIRST_DEGREE = """
MATCH (c:Chunk)-[m:MENTIONS]->(e:Entity)
WHERE c.chunk_id IN $chunk_ids
WITH e, collect({chunk_id: c.chunk_id, confidence: m.confidence}) AS mentions
ORDER BY size(mentions) DESC, e.name
LIMIT $max_entities
RETURN e.entity_key AS key, e.name AS name, e.entity_type AS entity_type, mentions
"""

_SEED_DOCUMENTS = """
MATCH (d:Document)-[:HAS_CHUNK]->(c:Chunk)
WHERE c.chunk_id IN $chunk_ids
WITH DISTINCT d
OPTIONAL MATCH (d)-[r:REFERENCES|CONTRIBUTED_BY]->(x)
RETURN d.document_id AS document_id, d.title AS title, d.source_system AS source_system,
       d.uri AS uri,
       collect(CASE WHEN x IS NULL THEN null ELSE {
           type: type(r), target_id: coalesce(x.document_id, x.entity_key),
           name: coalesce(x.title, x.name), labels: labels(x),
           entity_type: x.entity_type, kind: r.kind, role: r.role
       } END) AS links
"""

_CHUNK_DOCUMENTS = """
MATCH (d:Document)-[:HAS_CHUNK]->(c:Chunk) WHERE c.chunk_id IN $ids
RETURN c.chunk_id AS chunk_id, d.document_id AS document_id
"""

_SECOND_DEGREE = """
MATCH (e:Entity)-[r:DEPENDS_ON]-(e2:Entity)
WHERE e.entity_key IN $entity_keys
RETURN startNode(r).entity_key AS source, endNode(r).entity_key AS target,
       coalesce(r.weight, 1.0) AS weight,
       e2.entity_key AS key, e2.name AS name, e2.entity_type AS entity_type
LIMIT $limit
"""

_EXPAND_CHUNKS = """
UNWIND $entities AS ent
MATCH (e:Entity {entity_key: ent.key})<-[m:MENTIONS]-(c:Chunk)
WHERE NOT c.chunk_id IN $seed_chunk_ids
WITH c, sum(ent.weight * coalesce(m.confidence, 1.0)) AS score, collect(DISTINCT ent.key) AS via
ORDER BY score DESC
LIMIT $limit
MATCH (d:Document)-[:HAS_CHUNK]->(c)
RETURN c.chunk_id AS chunk_id, d.document_id AS document_id, score, via
"""

_DOCUMENT_ENTITY_GRAPH = """
MATCH (d:Document {document_id: $document_id})
OPTIONAL MATCH (d)-[:HAS_CHUNK]->(c:Chunk)-[m:MENTIONS]->(e:Entity)
WITH d, collect(DISTINCT e) AS ents,
     collect(CASE WHEN e IS NULL THEN null ELSE
        {chunk_id: c.chunk_id, key: e.entity_key, confidence: m.confidence} END) AS mentions
OPTIONAL MATCH (a:Entity)-[r:DEPENDS_ON]->(b:Entity) WHERE a IN ents AND b IN ents
WITH d, ents, mentions,
     collect(CASE WHEN r IS NULL THEN null ELSE
        {source: a.entity_key, target: b.entity_key, weight: r.weight} END) AS deps
OPTIONAL MATCH (d)-[r2:REFERENCES|CONTRIBUTED_BY]->(x)
RETURN d.document_id AS document_id, d.title AS title, d.source_system AS source_system,
       d.uri AS uri,
       [e IN ents | {key: e.entity_key, name: e.name, entity_type: e.entity_type}] AS entities,
       mentions, deps,
       collect(CASE WHEN x IS NULL THEN null ELSE {
           type: type(r2), target_id: coalesce(x.document_id, x.entity_key),
           name: coalesce(x.title, x.name), labels: labels(x), entity_type: x.entity_type,
           kind: r2.kind, role: r2.role, stub: coalesce(x.stub, false)
       } END) AS links
"""

_ENTITY_NEIGHBORHOOD = """
MATCH (e:Entity {entity_key: $entity_key})
OPTIONAL MATCH (e)-[r:DEPENDS_ON]-(e2:Entity)
WITH e, collect(CASE WHEN e2 IS NULL THEN null ELSE {
        source: startNode(r).entity_key, target: endNode(r).entity_key, weight: r.weight,
        key: e2.entity_key, name: e2.name, entity_type: e2.entity_type } END) AS deps
OPTIONAL MATCH (e)<-[m:MENTIONS]-(c:Chunk)<-[:HAS_CHUNK]-(d:Document)
WITH e, deps, d, count(DISTINCT c) AS mention_count
ORDER BY mention_count DESC
LIMIT $max_documents
OPTIONAL MATCH (d)-[cb:CONTRIBUTED_BY]->(p:Entity)
WITH e, deps, d, mention_count,
     collect(CASE WHEN p IS NULL THEN null ELSE
        {key: p.entity_key, name: p.name, role: cb.role} END) AS contributors
RETURN e.entity_key AS key, e.name AS name, e.entity_type AS entity_type, deps,
       collect(CASE WHEN d IS NULL THEN null ELSE {
           document_id: d.document_id, title: d.title, source_system: d.source_system,
           uri: d.uri, mention_count: mention_count, contributors: contributors
       } END) AS documents
"""

_LINEAGE = """
MATCH (d:Document {document_id: $document_id})
CALL {
    WITH d
    OPTIONAL MATCH p = (d)-[:REFERENCES*1..%(depth)d]-(other:Document)
    RETURN p LIMIT $max_paths
}
WITH d, [p IN collect(p) WHERE p IS NOT NULL] AS paths
WITH d, reduce(ns = [d], p IN paths | ns + nodes(p)) AS ns,
        reduce(rs = [], p IN paths | rs + relationships(p)) AS rs
UNWIND ns AS n
WITH d, rs, collect(DISTINCT n) AS docs
UNWIND (CASE WHEN size(rs) = 0 THEN [null] ELSE rs END) AS r
WITH d, docs, collect(DISTINCT r) AS rels
UNWIND docs AS doc
OPTIONAL MATCH (doc)-[cb:CONTRIBUTED_BY]->(p:Entity)
WITH d, docs, rels,
     collect(CASE WHEN p IS NULL THEN null ELSE
        {source: doc.document_id, target: p.entity_key, name: p.name, role: cb.role} END) AS contribs
RETURN [x IN docs | {id: x.document_id, title: x.title, source_system: x.source_system,
                     uri: x.uri, stub: coalesce(x.stub, false), version: x.version}] AS documents,
       [r IN rels WHERE r IS NOT NULL |
            {source: startNode(r).document_id, target: endNode(r).document_id, kind: r.kind}]
            AS references,
       [c IN contribs WHERE c IS NOT NULL] AS contributors
"""

_KNOWLEDGE_MAP = """
MATCH (d:Document)
WHERE NOT coalesce(d.stub, false)
WITH d ORDER BY d.title LIMIT $max_documents
WITH collect(d) AS docs
CALL {
    WITH docs
    UNWIND docs AS d
    MATCH (d)-[:HAS_CHUNK]->(:Chunk)-[m:MENTIONS]->(e:Entity)
    WITH d, e, count(m) AS n
    RETURN collect({document_id: d.document_id, key: e.entity_key, name: e.name,
                    entity_type: e.entity_type, mentions: n}) AS mentions
}
CALL {
    WITH docs
    UNWIND docs AS a
    MATCH (a)-[r:REFERENCES]->(b:Document)
    RETURN collect({source: a.document_id, target: b.document_id, title: b.title,
                    source_system: b.source_system, stub: coalesce(b.stub, false), kind: r.kind}) AS refs
}
CALL {
    WITH docs
    UNWIND docs AS d
    MATCH (d)-[cb:CONTRIBUTED_BY]->(p:Entity)
    RETURN collect({source: d.document_id, key: p.entity_key, name: p.name, role: cb.role}) AS contributors
}
CALL {
    WITH docs
    UNWIND docs AS d
    MATCH (d)-[:HAS_CHUNK]->(:Chunk)-[:MENTIONS]->(e:Entity)
    WITH collect(DISTINCT e) AS ents
    UNWIND ents AS a
    MATCH (a)-[r:DEPENDS_ON]->(b:Entity)
    WHERE b IN ents
    RETURN collect({source: a.entity_key, target: b.entity_key, weight: r.weight}) AS deps
}
RETURN [d IN docs | {id: d.document_id, title: d.title, source_system: d.source_system, uri: d.uri}] AS documents,
       mentions, refs, contributors, deps
"""

_SEARCH_ENTITIES_FULLTEXT = """
CALL db.index.fulltext.queryNodes('entity_name_fulltext', $q) YIELD node, score
WHERE ($entity_type IS NULL OR node.entity_type = $entity_type)
WITH node, score
OPTIONAL MATCH (node)<-[:MENTIONS]-(c:Chunk)
RETURN node.entity_key AS key, node.name AS name, node.entity_type AS entity_type,
       score, count(c) AS mention_count
ORDER BY score DESC
LIMIT $limit
"""

_SEARCH_ENTITIES_CONTAINS = """
MATCH (node:Entity)
WHERE toLower(node.name) CONTAINS toLower($q)
  AND ($entity_type IS NULL OR node.entity_type = $entity_type)
OPTIONAL MATCH (node)<-[:MENTIONS]-(c:Chunk)
RETURN node.entity_key AS key, node.name AS name, node.entity_type AS entity_type,
       1.0 AS score, count(c) AS mention_count
ORDER BY mention_count DESC, name
LIMIT $limit
"""

_LIST_ENTITIES = """
MATCH (e:Entity)
WHERE $entity_type IS NULL OR e.entity_type = $entity_type
OPTIONAL MATCH (e)<-[:MENTIONS]-(c:Chunk)<-[:HAS_CHUNK]-(d:Document)
WITH e, count(DISTINCT c) AS mention_count, count(DISTINCT d) AS document_count
ORDER BY mention_count DESC, e.name
SKIP $offset LIMIT $limit
RETURN e.entity_key AS key, e.name AS name, e.entity_type AS entity_type,
       mention_count, document_count
"""

_ENTITIES_FOR_CHUNKS = """
MATCH (c:Chunk)-[m:MENTIONS]->(e:Entity)
WHERE c.chunk_id IN $chunk_ids
RETURN c.chunk_id AS chunk_id, e.entity_key AS key, e.name AS name,
       e.entity_type AS entity_type, m.confidence AS confidence
ORDER BY confidence DESC
"""


def _lucene_prefix_query(text: str) -> str:
    """Escape Lucene syntax and turn each term into a prefix query."""
    terms = [_LUCENE_SPECIAL_RE.sub(r"\\\1", t) for t in text.split() if t.strip()]
    return " ".join(f"{t}*" for t in terms) if terms else "*"


async def _data(tx: AsyncManagedTransaction, query: str, **params: Any) -> list[dict[str, Any]]:
    result = await tx.run(query, **params)
    return await result.data()


class GraphRepository:
    def __init__(self, graph: GraphDatabase) -> None:
        self._graph = graph

    # ================================================================== writes
    async def sync_document(self, payload: GraphDocumentPayload) -> str:
        """Atomically (re)write one document's subgraph. Returns the node elementId."""
        doc_id = str(payload.document_id)

        mentions_by_label: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for m in payload.mentions:
            label = m.entity_type.value
            if label not in _ALLOWED_ENTITY_LABELS:  # defensive: label is interpolated
                continue
            mentions_by_label[label].append(
                {
                    "chunk_id": str(m.chunk_id),
                    "key": m.key,
                    "name": m.name,
                    "entity_type": label,
                    "normalized_name": m.normalized_name,
                    "confidence": float(m.confidence),
                }
            )

        async def work(tx: AsyncManagedTransaction) -> str:
            result = await tx.run(
                _MERGE_DOCUMENT,
                document_id=doc_id,
                external_id=payload.external_id,
                source_system=payload.source_system.value,
                title=payload.title,
                uri=payload.uri,
                author=payload.author,
                version=payload.version,
                mime_type=payload.mime_type,
            )
            record = await result.single()
            node_id = str(record["node_id"]) if record else ""

            await tx.run(_DELETE_CHUNKS, document_id=doc_id)
            await tx.run(_DELETE_DOC_RELS, document_id=doc_id)
            await tx.run(_RETRACT_DEPENDENCIES, document_id=doc_id)

            if payload.chunks:
                await tx.run(
                    _CREATE_CHUNKS,
                    document_id=doc_id,
                    chunks=[
                        {
                            "chunk_id": str(c.chunk_id),
                            "chunk_index": c.chunk_index,
                            "token_count": c.token_count,
                            "section_path": c.section_path,
                            "preview": c.preview,
                        }
                        for c in payload.chunks
                    ],
                )
            for label, mentions in mentions_by_label.items():
                await tx.run(_CREATE_MENTIONS % {"label": label}, mentions=mentions)
            if payload.contributors:
                await tx.run(
                    _CREATE_CONTRIBUTORS,
                    document_id=doc_id,
                    contributors=[c.model_dump() for c in payload.contributors],
                )
            if payload.references:
                await tx.run(
                    _CREATE_REFERENCES,
                    document_id=doc_id,
                    references=[
                        {
                            "document_id": str(r.document_id),
                            "external_id": r.external_id,
                            "source_system": r.source_system.value,
                            "title": r.title,
                            "kind": r.kind,
                        }
                        for r in payload.references
                    ],
                )
            if payload.dependencies:
                await tx.run(
                    _CREATE_DEPENDENCIES,
                    document_id=doc_id,
                    dependencies=[d.model_dump() for d in payload.dependencies],
                )
            return node_id

        return await self._graph.write_unit(work)

    async def delete_document(self, document_id: UUID) -> None:
        """Remove the document subgraph and its share of DEPENDS_ON evidence, atomically."""
        doc_id = str(document_id)

        async def work(tx: AsyncManagedTransaction) -> None:
            await tx.run(_RETRACT_DEPENDENCIES, document_id=doc_id)
            await tx.run(_DELETE_DOCUMENT, document_id=doc_id)

        await self._graph.write_unit(work)

    async def prune_dangling_dependencies(self) -> int:
        """Drop DEPENDS_ON evidence that points at documents no longer in the graph.

        Normal operation never leaves such evidence behind (sync and delete both
        retract first); this is the reconciliation safety net after crashes or
        manual graph edits. Returns the number of edges deleted outright.
        """
        rows = await self._graph.execute_write(_PRUNE_DANGLING_DEPENDENCIES)
        return int(rows[0]["pruned"]) if rows else 0

    async def delete_orphan_entities(self) -> int:
        rows = await self._graph.execute_write(_DELETE_ORPHAN_ENTITIES)
        return int(rows[0]["removed"]) if rows else 0

    # ================================================================== GraphRAG
    async def expand_from_chunks(
        self,
        seed_chunk_ids: list[UUID],
        *,
        hops: int = 2,
        max_entities: int = 60,
        max_expanded_chunks: int = 20,
    ) -> GraphExpansion:
        """1st/2nd-degree expansion around the hybrid-search hits.

        1. Entities mentioned by the seed chunks (1st degree) + their documents,
           references and contributors.
        2. Entities connected via ``DEPENDS_ON`` to 1st-degree entities (2nd degree).
        3. Other chunks that mention those entities, scored by shared entity mass —
           these are injected into the candidate pool with a graph boost.
        """
        if not seed_chunk_ids:
            return GraphExpansion()
        ids = [str(c) for c in seed_chunk_ids]

        async def work(tx: AsyncManagedTransaction) -> GraphExpansion:
            first_rows = await _data(tx, _FIRST_DEGREE, chunk_ids=ids, max_entities=max_entities)
            doc_rows = await _data(tx, _SEED_DOCUMENTS, chunk_ids=ids)

            nodes: dict[str, dict[str, Any]] = {}
            edges: dict[tuple[str, str, str], dict[str, Any]] = {}
            chunk_entities: dict[str, list[GraphEntityRef]] = defaultdict(list)

            def add_node(nid: str, label: str, ntype: str, **props: Any) -> None:
                existing = nodes.get(nid)
                if existing is None:
                    nodes[nid] = {"id": nid, "label": label, "type": ntype, "properties": props}
                else:
                    existing["properties"].update({k: v for k, v in props.items() if v is not None})

            def add_edge(src: str, dst: str, etype: str, **props: Any) -> None:
                key = (src, dst, etype)
                if key in edges:
                    e = edges[key]
                    if "weight" in props:
                        e["properties"]["weight"] = (
                            e["properties"].get("weight", 0) + props["weight"]
                        )
                else:
                    edges[key] = {"source": src, "target": dst, "type": etype, "properties": props}

            # seed documents + their references / contributors
            for row in doc_rows:
                did = row["document_id"]
                add_node(
                    did,
                    row["title"],
                    "Document",
                    source_system=row["source_system"],
                    uri=row["uri"],
                    seed=True,
                )
                for link in row["links"] or []:
                    if not link:
                        continue
                    if link["type"] == "REFERENCES":
                        add_node(link["target_id"], link["name"], "Document")
                        add_edge(did, link["target_id"], "REFERENCES", kind=link.get("kind"))
                    elif link["type"] == "CONTRIBUTED_BY":
                        add_node(link["target_id"], link["name"], "Person")
                        add_edge(did, link["target_id"], "CONTRIBUTED_BY", role=link.get("role"))

            # 1st degree entities
            first_keys: list[str] = []
            for row in first_rows:
                key = row["key"]
                first_keys.append(key)
                add_node(key, row["name"], row["entity_type"], degree=1)
                for m in row["mentions"]:
                    chunk_entities[m["chunk_id"]].append(
                        GraphEntityRef(key=key, name=row["name"], entity_type=row["entity_type"])
                    )
            # MENTIONS edges aggregated at document level
            if first_keys:
                map_rows = await _data(tx, _CHUNK_DOCUMENTS, ids=ids)
                chunk_to_doc = {r["chunk_id"]: r["document_id"] for r in map_rows}
                for row in first_rows:
                    for m in row["mentions"]:
                        did = chunk_to_doc.get(m["chunk_id"])
                        if did:
                            add_edge(
                                did,
                                row["key"],
                                "MENTIONS",
                                weight=float(m["confidence"] or 1.0),
                            )

            # 2nd degree
            second_keys: list[str] = []
            if hops >= 2 and first_keys:
                second_rows = await _data(
                    tx, _SECOND_DEGREE, entity_keys=first_keys, limit=max_entities * 3
                )
                for row in second_rows:
                    if row["key"] not in first_keys and row["key"] not in second_keys:
                        second_keys.append(row["key"])
                    add_node(row["key"], row["name"], row["entity_type"], degree=2)
                    add_edge(
                        row["source"], row["target"], "DEPENDS_ON", weight=float(row["weight"])
                    )

            # expansion chunks
            expanded: list[ExpandedChunk] = []
            if max_expanded_chunks > 0 and (first_keys or second_keys):
                ents = [{"key": k, "weight": 1.0} for k in first_keys] + [
                    {"key": k, "weight": 0.5} for k in second_keys
                ]
                exp_rows = await _data(
                    tx,
                    _EXPAND_CHUNKS,
                    entities=ents,
                    seed_chunk_ids=ids,
                    limit=max_expanded_chunks,
                )
                for row in exp_rows:
                    expanded.append(
                        ExpandedChunk(
                            chunk_id=UUID(row["chunk_id"]),
                            document_id=UUID(row["document_id"]),
                            score=float(row["score"]),
                            via=list(row["via"]),
                        )
                    )

            return GraphExpansion(
                nodes=list(nodes.values()),
                edges=list(edges.values()),
                chunk_entities=dict(chunk_entities),
                expanded_chunks=expanded,
                first_degree_keys=first_keys,
                second_degree_keys=second_keys,
            )

        return await self._graph.read_unit(work)

    async def entities_for_chunks(self, chunk_ids: list[UUID]) -> dict[str, list[GraphEntityRef]]:
        if not chunk_ids:
            return {}
        rows = await self._graph.execute_read(
            _ENTITIES_FOR_CHUNKS, chunk_ids=[str(c) for c in chunk_ids]
        )
        out: dict[str, list[GraphEntityRef]] = defaultdict(list)
        for r in rows:
            out[r["chunk_id"]].append(
                GraphEntityRef(key=r["key"], name=r["name"], entity_type=r["entity_type"])
            )
        return dict(out)

    # ================================================================== explorer
    async def document_entity_graph(self, document_id: UUID) -> dict[str, Any] | None:
        rows = await self._graph.execute_read(_DOCUMENT_ENTITY_GRAPH, document_id=str(document_id))
        if not rows:
            return None
        row = rows[0]
        row["mentions"] = [m for m in (row.get("mentions") or []) if m]
        row["deps"] = [d for d in (row.get("deps") or []) if d]
        row["links"] = [link for link in (row.get("links") or []) if link]
        return row

    async def entity_neighborhood(
        self, entity_key: str, *, max_documents: int = 25
    ) -> dict[str, Any] | None:
        rows = await self._graph.execute_read(
            _ENTITY_NEIGHBORHOOD, entity_key=entity_key, max_documents=max_documents
        )
        if not rows:
            return None
        row = rows[0]
        row["deps"] = [d for d in (row.get("deps") or []) if d]
        docs = []
        for d in row.get("documents") or []:
            if not d:
                continue
            d["contributors"] = [c for c in (d.get("contributors") or []) if c]
            docs.append(d)
        row["documents"] = docs
        return row

    async def knowledge_map(self, *, max_documents: int = 150) -> dict[str, Any]:
        """Every document (up to a cap), the entities its chunks mention, and the links between them."""
        rows = await self._graph.execute_read(_KNOWLEDGE_MAP, max_documents=max_documents)
        row = rows[0] if rows else {}
        return {key: [x for x in (row.get(key) or []) if x] for key in ("documents", "mentions", "refs", "contributors", "deps")}

    async def lineage(
        self, document_id: UUID, *, depth: int = 3, max_paths: int = 300
    ) -> dict[str, Any] | None:
        depth = max(1, min(int(depth), 6))
        rows = await self._graph.execute_read(
            _LINEAGE % {"depth": depth}, document_id=str(document_id), max_paths=max_paths
        )
        return rows[0] if rows else None

    async def search_entities(
        self, query: str, *, entity_type: str | None = None, limit: int = 20
    ) -> list[dict[str, Any]]:
        q = query.strip()
        if not q:
            return []
        try:
            rows = await self._graph.execute_read(
                _SEARCH_ENTITIES_FULLTEXT,
                q=_lucene_prefix_query(q),
                entity_type=entity_type,
                limit=limit,
            )
            if rows:
                return rows
        except Exception:  # noqa: BLE001 - index missing / unparsable query -> fallback
            pass
        return await self._graph.execute_read(
            _SEARCH_ENTITIES_CONTAINS, q=q, entity_type=entity_type, limit=limit
        )

    async def list_entities(
        self, *, entity_type: str | None = None, limit: int = 50, offset: int = 0
    ) -> list[dict[str, Any]]:
        return await self._graph.execute_read(
            _LIST_ENTITIES, entity_type=entity_type, limit=limit, offset=offset
        )

    # ================================================================== stats
    async def stats(self) -> dict[str, Any]:
        """Node/edge counts (count-store backed, cheap)."""
        labels = ["Document", "Chunk", "Entity", *(e.value for e in EntityType)]
        rel_types = ["HAS_CHUNK", "MENTIONS", "REFERENCES", "DEPENDS_ON", "CONTRIBUTED_BY"]

        async def work(tx: AsyncManagedTransaction) -> dict[str, Any]:
            nodes_by_label: dict[str, int] = {}
            for label in labels:
                rows = await _data(tx, f"MATCH (n:{label}) RETURN count(n) AS c")
                nodes_by_label[label] = int(rows[0]["c"]) if rows else 0
            edges_by_type: dict[str, int] = {}
            for rt in rel_types:
                rows = await _data(tx, f"MATCH ()-[r:{rt}]->() RETURN count(r) AS c")
                edges_by_type[rt] = int(rows[0]["c"]) if rows else 0
            n_rows = await _data(tx, "MATCH (n) RETURN count(n) AS c")
            e_rows = await _data(tx, "MATCH ()-[r]->() RETURN count(r) AS c")
            n = int(n_rows[0]["c"]) if n_rows else 0
            e = int(e_rows[0]["c"]) if e_rows else 0
            return {
                "nodes_total": n,
                "edges_total": e,
                "nodes_by_label": nodes_by_label,
                "edges_by_type": edges_by_type,
                "density": round(e / n, 4) if n else 0.0,
            }

        return await self._graph.read_unit(work)
