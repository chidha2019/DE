"""A small Jira Cloud REST client (v3) for the intent service: search, read, comment, label, transition.

Credentials are basic auth (email + API token) read by name from settings; they are never logged.
Comment bodies are Atlassian Document Format; ``text_to_adf`` / ``adf_to_text`` convert plain paragraphs.
"""

from __future__ import annotations

import asyncio
import hashlib
import re
from collections.abc import Awaitable, Callable
from typing import Any

import httpx

from ech_core.config import Settings
from ech_core.exceptions import ConnectorError

_COMMAND = re.compile(r"^\s*/(approve|reject|answer|done)\b(.*)$", re.I | re.S)
_FIELDS = ["summary", "description", "reporter", "assignee", "status", "labels", "created", "updated", "issuetype", "priority", "project"]


def adf_to_text(node: Any) -> str:
    """Flatten an ADF document (or any nested node) to plain text with paragraph breaks."""
    if node is None:
        return ""
    if isinstance(node, str):
        return node
    if isinstance(node, list):
        return "".join(adf_to_text(n) for n in node)
    if not isinstance(node, dict):
        return str(node)
    kind = node.get("type")
    if kind == "text":
        return str(node.get("text", ""))
    if kind == "hardBreak":
        return "\n"
    inner = adf_to_text(node.get("content"))
    if kind == "listItem":
        # Keep the bullet, so an "Acceptance criteria" list still reads as a list once flattened.
        return "- " + inner.lstrip()
    if kind in ("paragraph", "heading", "codeBlock", "blockquote"):
        return inner + "\n"
    return inner


def _paragraph(lines: list[str]) -> dict[str, Any]:
    content: list[dict[str, Any]] = []
    for i, line in enumerate(lines):
        if i:
            content.append({"type": "hardBreak"})
        content.append({"type": "text", "text": line})
    return {"type": "paragraph", "content": content}


def _bullets(lines: list[str]) -> dict[str, Any]:
    return {
        "type": "bulletList",
        "content": [{"type": "listItem", "content": [_paragraph([ln.lstrip()[2:]])]} for ln in lines],
    }


def text_to_adf(text: str) -> dict[str, Any]:
    """Plain text → ADF: blank lines separate paragraphs; runs of '- ' lines become bullet lists."""
    blocks: list[dict[str, Any]] = []
    for para in re.split(r"\n\s*\n", text.strip()):
        run: list[str] = []
        bullet = False
        for line in (ln for ln in para.splitlines() if ln.strip()):
            is_bullet = line.lstrip().startswith("- ")
            if run and is_bullet != bullet:
                blocks.append(_bullets(run) if bullet else _paragraph(run))
                run = []
            bullet = is_bullet
            run.append(line)
        if run:
            blocks.append(_bullets(run) if bullet else _paragraph(run))
    return {"type": "doc", "version": 1, "content": blocks or [{"type": "paragraph", "content": []}]}


def parse_command(text: str) -> tuple[str, str] | None:
    """``/approve``, ``/reject note``, ``/answer ...`` or ``/done`` at the start of a comment."""
    match = _COMMAND.match(text or "")
    if not match:
        return None
    return match.group(1).lower(), match.group(2).strip()


class JiraClient:
    def __init__(self, base_url: str, email: str, token: str, *, client: httpx.AsyncClient | None = None, timeout: float = 30.0) -> None:
        self.base_url = base_url.strip().rstrip("/")
        if "://" not in self.base_url:
            self.base_url = f"https://{self.base_url}"
        self._client = client or httpx.AsyncClient(
            base_url=self.base_url, auth=(email, token), headers={"Accept": "application/json"}, timeout=timeout
        )

    async def aclose(self) -> None:
        await self._client.aclose()

    def issue_url(self, key: str) -> str:
        return f"{self.base_url}/browse/{key}"

    async def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        response = await self._client.request(method, path, **kwargs)
        if response.status_code >= 400:
            raise ConnectorError(f"Jira {method} {path} failed with HTTP {response.status_code}: {response.text[:200]}")
        if response.status_code == 204 or not response.content:
            return None
        return response.json()

    async def health(self) -> dict[str, Any]:
        me = await self._request("GET", "/rest/api/3/myself")
        return {"account": me.get("displayName") or me.get("emailAddress") or "?", "ok": True}

    async def search(self, jql: str, *, max_results: int = 50) -> list[dict[str, Any]]:
        """Issues matching the JQL, flattened: key, url, summary, description (text), reporter, status, labels, created, updated."""
        return await self.search_all(jql, limit=max_results)

    async def search_all(self, jql: str, *, limit: int) -> list[dict[str, Any]]:
        """Up to `limit` issues matching the JQL, page by page: the enhanced search first, the legacy one where it is missing."""
        out: list[dict[str, Any]] = []
        token: str | None = None
        try:
            while len(out) < limit:
                body: dict[str, Any] = {"jql": jql, "maxResults": min(100, limit - len(out)), "fields": _FIELDS}
                if token:
                    body["nextPageToken"] = token
                data = await self._request("POST", "/rest/api/3/search/jql", json=body) or {}
                issues = data.get("issues", [])
                out += [self._flatten(issue) for issue in issues]
                token = data.get("nextPageToken")
                if not issues or not token or data.get("isLast"):
                    break
            return out[:limit]
        except ConnectorError as exc:
            if "HTTP 404" not in str(exc) and "HTTP 410" not in str(exc):
                raise
        out, start = [], 0
        while len(out) < limit:
            params = {"jql": jql, "startAt": start, "maxResults": min(100, limit - len(out)), "fields": ",".join(_FIELDS)}
            data = await self._request("GET", "/rest/api/3/search", params=params) or {}
            issues = data.get("issues", [])
            out += [self._flatten(issue) for issue in issues]
            start += len(issues)
            if not issues or start >= int(data.get("total") or 0):
                break
        return out[:limit]

    async def issue(self, key: str) -> dict[str, Any]:
        data = await self._request("GET", f"/rest/api/3/issue/{key}", params={"fields": ",".join(_FIELDS)})
        return self._flatten(data)

    def _flatten(self, issue: dict[str, Any]) -> dict[str, Any]:
        fields = issue.get("fields") or {}
        reporter = fields.get("reporter") or {}
        assignee = fields.get("assignee") or {}
        project = fields.get("project") or {}
        return {
            "key": issue.get("key"),
            "url": self.issue_url(str(issue.get("key"))),
            "summary": fields.get("summary") or "",
            "description": adf_to_text(fields.get("description")).strip(),
            "reporter": reporter.get("displayName") or reporter.get("emailAddress") or "",
            "assignee": assignee.get("displayName") or "",
            "status": (fields.get("status") or {}).get("name") or "",
            "issue_type": (fields.get("issuetype") or {}).get("name") or "",
            "priority": (fields.get("priority") or {}).get("name") or "",
            "project": project.get("key") or "",
            "project_name": project.get("name") or "",
            "labels": list(fields.get("labels") or []),
            "created": fields.get("created"),
            "updated": fields.get("updated"),
        }

    async def comments(self, key: str) -> list[dict[str, Any]]:
        data = await self._request("GET", f"/rest/api/3/issue/{key}/comment", params={"orderBy": "created", "maxResults": 100})
        out = []
        for c in (data or {}).get("comments", []):
            author = c.get("author") or {}
            out.append(
                {
                    "id": str(c.get("id")),
                    "author": author.get("displayName") or author.get("emailAddress") or "",
                    "account_id": author.get("accountId"),
                    "text": adf_to_text(c.get("body")).strip(),
                    "created": c.get("created"),
                }
            )
        return out

    async def add_comment(self, key: str, text: str) -> str:
        data = await self._request("POST", f"/rest/api/3/issue/{key}/comment", json={"body": text_to_adf(text)})
        return str((data or {}).get("id", ""))

    async def add_labels(self, key: str, labels: list[str]) -> None:
        await self._request("PUT", f"/rest/api/3/issue/{key}", json={"update": {"labels": [{"add": label} for label in labels]}})

    async def transitions(self, key: str) -> list[dict[str, str]]:
        data = await self._request("GET", f"/rest/api/3/issue/{key}/transitions")
        return [{"id": str(t.get("id")), "name": str(t.get("name"))} for t in (data or {}).get("transitions", [])]

    async def transition(self, key: str, name: str) -> bool:
        """Move the issue through the transition called `name` (case-insensitive); False when the workflow lacks it."""
        for t in await self.transitions(key):
            if t["name"].lower() == name.lower():
                await self._request("POST", f"/rest/api/3/issue/{key}/transitions", json={"transition": {"id": t["id"]}})
                return True
        return False


def jira_identity(settings: Settings) -> tuple[str, str, str] | None:
    """Site, email and a digest of the token when all three are set; the token itself is never kept."""
    token = settings.jira_api_token.get_secret_value().strip() if settings.jira_api_token else ""
    site, email = (settings.jira_base_url or "").strip(), (settings.jira_email or "").strip()
    if not (site and email and token):
        return None
    return site, email, hashlib.sha256(token.encode()).hexdigest()


class JiraLink:
    """The Jira client for whichever connection is current: the environment, or one saved on the Connectors page.

    The client is rebuilt when the site, email or token changes and is None while the connection is incomplete,
    so saving Jira in the hub takes effect without a restart.
    """

    def __init__(self, settings: Callable[[], Awaitable[Settings]], current: Callable[[], Settings]) -> None:
        self._settings = settings
        self._current = current
        self._client: JiraClient | None = None
        self._identity: tuple[str, str, str] | None = None
        self._lock = asyncio.Lock()

    def configured(self) -> bool:
        return jira_identity(self._current()) is not None

    def jql(self) -> str:
        return self._current().jira_intent_jql

    def poll_seconds(self) -> int:
        return self._current().jira_poll_seconds

    async def client(self) -> JiraClient | None:
        settings = await self._settings()
        identity = jira_identity(settings)
        async with self._lock:
            if identity != self._identity:
                if self._client is not None:
                    await self._client.aclose()
                token = settings.jira_api_token.get_secret_value() if settings.jira_api_token else ""
                self._client = JiraClient(identity[0], identity[1], token) if identity else None
                self._identity = identity
            return self._client

    async def aclose(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None
            self._identity = None
