"""Read-only Grafana HTTP client, shared by the ingestion connector and the SRE workspace.

Talks to Grafana Cloud or a self-hosted Grafana with a service-account token (Viewer role is
enough). Besides the thin endpoint wrappers it carries the pure helpers that turn a dashboard
JSON into the queries its panels run, and a query into the tables or metrics it references,
which is what links a dashboard to the semantic layer.
"""

from __future__ import annotations

import re
from collections.abc import Iterator
from dataclasses import dataclass, field
from typing import Any

import httpx

from ech_core.exceptions import ConnectorError

USER_AGENT = "enterprise-context-hub/0.1"

_SQL_TABLE = re.compile(r"\b(?:from|join)\s+([a-zA-Z_][\w$]*(?:\.[a-zA-Z_][\w$]*){0,2})", re.IGNORECASE)
# The trailing \b stops the engine backtracking into "histogram_quantil" when "histogram_quantile(" is a function.
_PROM_IDENT = re.compile(r"\b[a-zA-Z_:][a-zA-Z0-9_:]*\b(?!\s*\()")
_PROM_KEYWORDS = frozenset(
    "by without on ignoring group_left group_right and or unless offset bool nan inf".split()
)


@dataclass(frozen=True)
class PanelQuery:
    panel: str
    panel_type: str
    datasource: str | None
    kind: str
    """promql | sql | other"""
    expr: str


@dataclass
class GrafanaSnapshot:
    """What the SRE workspace shows and the connector ingests: dashboards and alert rules."""

    version: str | None
    org: str | None
    dashboards: list[dict[str, Any]] = field(default_factory=list)
    rules: list[dict[str, Any]] = field(default_factory=list)

    @property
    def firing(self) -> int:
        return sum(r.get("state") == "firing" for r in self.rules)

    @property
    def pending(self) -> int:
        return sum(r.get("state") == "pending" for r in self.rules)


# ----------------------------------------------------------------------------- pure helpers
def iter_panels(dashboard: dict[str, Any]) -> Iterator[dict[str, Any]]:
    """Every panel, including those inside collapsed rows and legacy row layouts."""
    for panel in dashboard.get("panels") or []:
        if not isinstance(panel, dict):
            continue
        yield panel
        for sub in panel.get("panels") or []:
            if isinstance(sub, dict):
                yield sub
    for row in dashboard.get("rows") or []:
        if isinstance(row, dict):
            for panel in row.get("panels") or []:
                if isinstance(panel, dict):
                    yield panel


def _datasource_type(value: Any) -> str | None:
    if isinstance(value, dict):
        return value.get("type") or value.get("uid")
    return value if isinstance(value, str) else None


def _target_query(target: dict[str, Any]) -> tuple[str, str] | None:
    for key, kind in (("expr", "promql"), ("rawSql", "sql"), ("query", "other"), ("rawQuery", "other")):
        value = target.get(key)
        if isinstance(value, str) and value.strip():
            return kind, value.strip()
    return None


def panel_queries(dashboard: dict[str, Any]) -> list[PanelQuery]:
    """The queries a dashboard runs, panel by panel, with the datasource type when known."""
    found: list[PanelQuery] = []
    for panel in iter_panels(dashboard):
        if panel.get("type") == "row":
            continue
        panel_ds = _datasource_type(panel.get("datasource"))
        for target in panel.get("targets") or []:
            if not isinstance(target, dict):
                continue
            query = _target_query(target)
            if query is None:
                continue
            kind, expr = query
            found.append(
                PanelQuery(
                    panel=str(panel.get("title") or f"panel {panel.get('id', '?')}"),
                    panel_type=str(panel.get("type") or "unknown"),
                    datasource=_datasource_type(target.get("datasource")) or panel_ds,
                    kind=kind,
                    expr=expr,
                )
            )
    return found


def rule_queries(rule: dict[str, Any]) -> list[PanelQuery]:
    """The queries behind a Grafana-managed alert rule (provisioning API shape)."""
    found: list[PanelQuery] = []
    for item in rule.get("data") or []:
        if not isinstance(item, dict):
            continue
        model = item.get("model") or {}
        query = _target_query(model) if isinstance(model, dict) else None
        if query is None:
            continue
        kind, expr = query
        found.append(
            PanelQuery(
                panel=str(rule.get("title") or "rule"),
                panel_type="alert",
                datasource=_datasource_type(model.get("datasource")) or item.get("datasourceUid"),
                kind=kind,
                expr=expr,
            )
        )
    return found


def referenced_tables(sql: str) -> list[str]:
    """Table names after FROM and JOIN, lower-cased, in first-seen order."""
    seen: list[str] = []
    for match in _SQL_TABLE.finditer(sql):
        name = match.group(1).lower().strip("`\"")
        if name not in seen and name not in {"select", "lateral", "unnest"}:
            seen.append(name)
    return seen


def metric_names(expr: str) -> list[str]:
    """Metric identifiers in a PromQL expression: functions, label matchers and ranges dropped."""
    text = re.sub(r"\{[^}]*\}", "", expr)
    text = re.sub(r"\[[^\]]*\]", "", text)
    text = re.sub(r"\b(?:by|without|on|ignoring|group_left|group_right)\s*\([^)]*\)", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\"[^\"]*\"|'[^']*'", "", text)
    seen: list[str] = []
    for token in _PROM_IDENT.findall(text):
        if token.lower() in _PROM_KEYWORDS or ("_" not in token and ":" not in token):
            continue
        if token not in seen:
            seen.append(token)
    return seen


def references_of(queries: list[PanelQuery]) -> tuple[list[str], list[str]]:
    """(tables, metrics) referenced across a set of queries."""
    tables: list[str] = []
    metrics: list[str] = []
    for q in queries:
        items = referenced_tables(q.expr) if q.kind == "sql" else metric_names(q.expr) if q.kind == "promql" else []
        target = tables if q.kind == "sql" else metrics
        for item in items:
            if item not in target:
                target.append(item)
    return tables, metrics


def merge_rule_states(rules: list[dict[str, Any]], states: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Attach state/health/active alert counts from the Prometheus-style rules API to provisioning rules."""
    by_uid: dict[str, dict[str, Any]] = {}
    by_title: dict[str, dict[str, Any]] = {}
    for group in states:
        for rule in group.get("rules") or []:
            if not isinstance(rule, dict):
                continue
            if rule.get("uid"):
                by_uid[str(rule["uid"])] = rule
            if rule.get("name"):
                by_title[str(rule["name"])] = rule
    merged: list[dict[str, Any]] = []
    for rule in rules:
        state = by_uid.get(str(rule.get("uid"))) or by_title.get(str(rule.get("title"))) or {}
        labels = dict(rule.get("labels") or {})
        annotations = dict(rule.get("annotations") or {})
        merged.append(
            {
                "uid": rule.get("uid"),
                "title": rule.get("title"),
                "folder": rule.get("folderUID") or rule.get("folderUid"),
                "group": rule.get("ruleGroup"),
                "state": str(state.get("state") or "unknown").lower(),
                "health": state.get("health"),
                "active_alerts": len(state.get("alerts") or []),
                "for": rule.get("for"),
                "labels": labels,
                "annotations": annotations,
                "severity": labels.get("severity"),
                "summary": annotations.get("summary") or annotations.get("description"),
                "data": rule.get("data") or [],
                "updated": rule.get("updated"),
            }
        )
    return merged


# ----------------------------------------------------------------------------- client
class GrafanaClient:
    def __init__(self, url: str, token: str | None, *, client: httpx.AsyncClient | None = None, timeout: float = 20.0) -> None:
        self.base = url.rstrip("/")
        self._token = token
        self._client = client
        self._timeout = timeout

    def _http(self) -> httpx.AsyncClient:
        if self._client is None:
            headers = {"Accept": "application/json", "User-Agent": USER_AGENT}
            if self._token:
                headers["Authorization"] = f"Bearer {self._token}"
            self._client = httpx.AsyncClient(base_url=self.base, headers=headers, timeout=httpx.Timeout(self._timeout, connect=10.0))
        return self._client

    async def aclose(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def _get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        try:
            response = await self._http().get(path, params=params)
        except httpx.HTTPError as exc:
            raise ConnectorError(f"Grafana unreachable at {self.base}", details={"path": path, "error": str(exc)}) from exc
        if response.status_code >= 400:
            hint = "token rejected" if response.status_code in (401, 403) else "request failed"
            raise ConnectorError(f"Grafana {hint} ({response.status_code}) for {path}", details={"path": path, "status": response.status_code})
        try:
            return response.json()
        except ValueError as exc:
            raise ConnectorError(f"Grafana returned a non-JSON body for {path}", details={"path": path}) from exc

    async def _post(self, path: str, body: Any) -> Any:
        try:
            response = await self._http().post(path, json=body)
        except httpx.HTTPError as exc:
            raise ConnectorError(f"Grafana unreachable at {self.base}", details={"path": path, "error": str(exc)}) from exc
        if response.status_code >= 400:
            hint = "token rejected" if response.status_code in (401, 403) else "request failed"
            detail: Any = None
            try:
                detail = response.json().get("message")
            except ValueError:
                detail = None
            raise ConnectorError(f"Grafana {hint} ({response.status_code}) for {path}", details={"path": path, "status": response.status_code, "message": detail})
        try:
            return response.json()
        except ValueError as exc:
            raise ConnectorError(f"Grafana returned a non-JSON body for {path}", details={"path": path}) from exc

    async def import_dashboard(self, dashboard: dict[str, Any], *, overwrite: bool = True, message: str = "Provisioned by the Enterprise Context Hub", folder_uid: str | None = None) -> dict[str, Any]:
        """Create or update a dashboard by uid (needs a token with the Editor role)."""
        payload: dict[str, Any] = {"dashboard": dashboard, "overwrite": overwrite, "message": message}
        if folder_uid:
            payload["folderUid"] = folder_uid
        return await self._post("/api/dashboards/db", payload)

    async def health(self) -> dict[str, Any]:
        return await self._get("/api/health")

    async def org(self) -> dict[str, Any]:
        return await self._get("/api/org")

    async def search_dashboards(self, *, limit: int = 500) -> list[dict[str, Any]]:
        result = await self._get("/api/search", {"type": "dash-db", "limit": limit})
        return [d for d in result if isinstance(d, dict)] if isinstance(result, list) else []

    async def dashboard(self, uid: str) -> dict[str, Any]:
        return await self._get(f"/api/dashboards/uid/{uid}")

    async def alert_rules(self) -> list[dict[str, Any]]:
        result = await self._get("/api/v1/provisioning/alert-rules")
        return [r for r in result if isinstance(r, dict)] if isinstance(result, list) else []

    async def rule_states(self) -> list[dict[str, Any]]:
        result = await self._get("/api/prometheus/grafana/api/v1/rules")
        data = result.get("data") if isinstance(result, dict) else None
        groups = data.get("groups") if isinstance(data, dict) else None
        return [g for g in groups if isinstance(g, dict)] if isinstance(groups, list) else []

    def dashboard_url(self, path_or_url: str | None) -> str | None:
        if not path_or_url:
            return None
        return path_or_url if path_or_url.startswith("http") else f"{self.base}{path_or_url}"

    def rule_url(self, uid: str | None) -> str | None:
        return f"{self.base}/alerting/grafana/{uid}/view" if uid else None

    async def snapshot(self, *, max_dashboards: int = 500) -> GrafanaSnapshot:
        """Version, org, dashboard summaries and alert rules with their current state."""
        health = await self.health()
        try:
            org = (await self.org()).get("name")
        except ConnectorError:
            org = None
        dashboards = await self.search_dashboards(limit=max_dashboards)
        for d in dashboards:
            d["url"] = self.dashboard_url(d.get("url"))
        try:
            rules = await self.alert_rules()
        except ConnectorError:
            rules = []
        try:
            states = await self.rule_states()
        except ConnectorError:
            states = []
        merged = merge_rule_states(rules, states)
        for r in merged:
            r["url"] = self.rule_url(r.get("uid"))
        return GrafanaSnapshot(version=health.get("version") if isinstance(health, dict) else None, org=org, dashboards=dashboards, rules=merged)
