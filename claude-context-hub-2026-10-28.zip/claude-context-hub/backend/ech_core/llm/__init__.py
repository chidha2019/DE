"""Claude access shared by the query service (Genie) and the pipeline agent.

One client, several providers: the first-party Claude API or an Anthropic-compatible
gateway such as Databricks Mosaic AI Gateway. See :mod:`ech_core.llm.client`.
"""

from ech_core.llm.client import (
    DEFAULT_MODEL,
    PRICING,
    PROVIDERS,
    AnthropicModelClient,
    LLMConfig,
    ModelClient,
    ModelConfigError,
    ModelTurn,
    ProviderProfile,
    StreamEvent,
    detect_provider,
    resolve_base_url,
)
from ech_core.llm.schema import strict_tool_schema

__all__ = [
    "DEFAULT_MODEL",
    "PRICING",
    "PROVIDERS",
    "AnthropicModelClient",
    "LLMConfig",
    "ModelClient",
    "ModelConfigError",
    "ModelTurn",
    "ProviderProfile",
    "StreamEvent",
    "detect_provider",
    "resolve_base_url",
    "strict_tool_schema",
]
