"""pydantic input models -> strict Claude tool schemas.

Strict tool use (``strict: true``) guarantees schema-valid arguments but accepts only a
subset of JSON Schema: no numeric, string or array constraints (the API answers 400 on
``minimum``, ``maxLength``, ``maxItems`` and friends). Those bounds stay enforced
client-side by validating the tool input with the pydantic model before execution; on
the wire they become part of the field description so the model still knows them.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel

UNSUPPORTED_KEYWORDS = (
    "minimum",
    "maximum",
    "exclusiveMinimum",
    "exclusiveMaximum",
    "multipleOf",
    "minLength",
    "maxLength",
    "pattern",
    "minItems",
    "maxItems",
    "uniqueItems",
)


def strict_tool_schema(model: type[BaseModel]) -> dict[str, Any]:
    """Every field required, closed object, strict-mode JSON Schema subset only."""
    raw = model.model_json_schema()
    props = raw.get("properties", {})
    for prop in props.values():
        prop.pop("title", None)
        prop.pop("default", None)
        _strip_constraints(prop)
    return {
        "type": "object",
        "properties": props,
        "required": list(props),
        "additionalProperties": False,
    }


def _strip_constraints(prop: dict[str, Any]) -> None:
    hints: list[str] = []
    lo, hi = prop.get("minimum"), prop.get("maximum")
    if lo is not None and hi is not None:
        hints.append(f"{lo} to {hi}")
    elif lo is not None:
        hints.append(f"at least {lo}")
    elif hi is not None:
        hints.append(f"at most {hi}")
    if prop.get("minLength"):
        hints.append(f"at least {prop['minLength']} characters")
    if prop.get("maxLength"):
        hints.append(f"at most {prop['maxLength']} characters")
    if prop.get("minItems"):
        hints.append(f"at least {prop['minItems']} items")
    if prop.get("maxItems"):
        hints.append(f"at most {prop['maxItems']} items")
    for key in UNSUPPORTED_KEYWORDS:
        prop.pop(key, None)
    items = prop.get("items")
    if isinstance(items, dict):
        _strip_constraints(items)
    for sub in prop.get("anyOf", []):
        if isinstance(sub, dict):
            _strip_constraints(sub)
    if hints:
        existing = prop.get("description", "").rstrip()
        prop["description"] = (f"{existing} " if existing else "") + f"({'; '.join(hints)})"
