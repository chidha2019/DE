"""The Claude model client behind Genie and the pipeline agent.

API conventions (Claude Opus 5.5 family)
---------------------------------------
* thinking is adaptive by default - the ``thinking`` parameter is omitted; depth is
  controlled with ``output_config.effort`` (set explicitly: the model default is medium);
* responses are streamed; :meth:`AnthropicModelClient.stream` yields text deltas as they
  arrive and the final message last, :meth:`AnthropicModelClient.complete` collects them;
* every client tool is strict (schema-valid arguments) and, on the first-party API, uses
  eager input streaming; callers validate tool inputs client-side regardless;
* no forced ``tool_choice`` (rejected on this family) - the prompt steers;
* full ``content`` blocks (incl. thinking) go back into the history unchanged.

Providers
---------
The same SDK reaches Claude on the first-party API or through an Anthropic-compatible
gateway (Databricks Mosaic AI Gateway, ``/ai-gateway/anthropic``, token sent as
``Authorization: Bearer``). A gateway lacks the first-party beta surface, so its profile
uses the GA ``client.messages`` namespace, no server-side fallbacks, no eager input
streaming, and strips any optional request field the gateway rejects with a 400 before
retrying (logged, kept for the rest of the process).
"""

from __future__ import annotations

import inspect
import os
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Any, Literal, Protocol
from urllib.parse import urlsplit

from ech_core.logging import get_logger

log = get_logger(__name__)

DEFAULT_MODEL = "claude-opus-5-5"
_FALLBACK_BETA = "server-side-fallback-2026-07-01"
# $/MTok, first-party list prices: input, output, cache write (1.25x), cache read.
PRICING: dict[str, tuple[float, float, float, float]] = {
    "claude-opus-5-5": (4.0, 20.0, 5.0, 0.20),
}
# Request fields a gateway may not know, in the order they are given up after a 400.
_OPTIONAL_FIELDS = ("eager_input_streaming", "strict", "cache_control", "output_config")


@dataclass(frozen=True)
class ProviderProfile:
    """Where the Messages API is served and which request surface it accepts."""

    name: str
    default_model: str
    beta_namespace: bool  # client.beta.messages (betas, fallbacks) vs GA client.messages
    eager_input_streaming: bool
    token_env: tuple[str, ...] = ()  # bearer-token variables checked before the SDK's own
    host_env: str | None = None  # workspace host variable, completed with ``base_path``
    base_path: str = ""


PROVIDERS: dict[str, ProviderProfile] = {
    "anthropic": ProviderProfile(
        name="anthropic",
        default_model=DEFAULT_MODEL,
        beta_namespace=True,
        eager_input_streaming=True,
    ),
    "databricks": ProviderProfile(
        name="databricks",
        default_model="system.ai.claude-opus-5-5",
        beta_namespace=False,
        eager_input_streaming=False,
        token_env=("DATABRICKS_TOKEN",),
        host_env="DATABRICKS_HOST",
        base_path="/ai-gateway/anthropic",
    ),
}


class ModelConfigError(RuntimeError):
    """The model client cannot be built from the configuration and environment given."""


def _is_gateway_url(url: str) -> bool:
    parts = urlsplit(url if "://" in url else f"https://{url}")
    return (
        "databricks" in parts.netloc
        or "/ai-gateway/" in parts.path
        or "/serving-endpoints" in parts.path
    )


def detect_provider(base_url: str | None = None) -> str:
    """Pick a provider profile from the environment when configured as ``auto``."""
    url = base_url or os.environ.get("ANTHROPIC_BASE_URL") or ""
    if url and _is_gateway_url(url):
        return "databricks"
    if base_url:  # an explicit URL that is not a gateway is first-party
        return "anthropic"
    databricks = os.environ.get("DATABRICKS_HOST") and os.environ.get("DATABRICKS_TOKEN")
    if databricks and not os.environ.get("ANTHROPIC_API_KEY"):
        return "databricks"
    return "anthropic"


def resolve_base_url(profile: ProviderProfile, explicit: str | None) -> str | None:
    """Flag > the profile's host variable > ``ANTHROPIC_BASE_URL``; a bare host gets its path."""
    url = explicit or ""
    if not url and profile.host_env:  # the provider's own variable beats the generic one
        url = os.environ.get(profile.host_env, "")
    if not url:
        env_url = os.environ.get("ANTHROPIC_BASE_URL", "")
        # A gateway profile ignores a first-party URL inherited from the environment:
        # its token must never travel to api.anthropic.com.
        if env_url and (profile.name == "anthropic" or _is_gateway_url(env_url)):
            url = env_url
    url = url.strip().rstrip("/")
    if not url:
        return None
    if "://" not in url:
        url = f"https://{url}"
    if profile.base_path and urlsplit(url).path in ("", "/"):
        url += profile.base_path
    return url


class LLMConfig(Protocol):
    """What the client needs to know; satisfied by any object with these attributes."""

    model: str | None  # None: the provider's default model
    effort: str
    max_tokens: int
    fallbacks: bool
    provider: str  # "auto" is resolved by the caller; here a key of PROVIDERS
    base_url: str | None


@dataclass
class ModelTurn:
    """Provider-agnostic view of one assistant response (content blocks as plain dicts)."""

    content: list[dict[str, Any]]
    stop_reason: str | None
    usage: dict[str, Any] = field(default_factory=dict)
    stop_details: dict[str, Any] | None = None
    model: str | None = None

    @property
    def text(self) -> str:
        return "".join(b.get("text", "") for b in self.content if b.get("type") == "text")

    @property
    def tool_uses(self) -> list[dict[str, Any]]:
        return [b for b in self.content if b.get("type") == "tool_use"]


@dataclass
class StreamEvent:
    """``text``: a delta of the assistant's text; ``message``: the completed turn (last)."""

    kind: Literal["text", "message"]
    text: str = ""
    turn: ModelTurn | None = None


class ModelClient(Protocol):
    async def complete(
        self, *, system: str, tools: list[dict[str, Any]], messages: list[dict[str, Any]]
    ) -> ModelTurn: ...

    def stream(
        self, *, system: str, tools: list[dict[str, Any]], messages: list[dict[str, Any]]
    ) -> AsyncIterator[StreamEvent]: ...


class AnthropicModelClient:
    """Real model client over the official SDK (``anthropic``), for any provider profile."""

    def __init__(self, config: LLMConfig) -> None:
        import anthropic  # imported lazily: optional at import time, required to run

        if config.provider not in PROVIDERS:
            raise ModelConfigError(
                f"unknown provider {config.provider!r}; choose from {', '.join(PROVIDERS)}"
            )
        self._anthropic = anthropic
        self._config = config
        self.profile = PROVIDERS[config.provider]
        self.model = config.model or self.profile.default_model
        self.base_url = resolve_base_url(self.profile, config.base_url)
        self.degraded: list[str] = []  # optional request fields the provider rejected

        kwargs: dict[str, Any] = {}
        if self.base_url:
            kwargs["base_url"] = self.base_url
        if self.profile.name != "anthropic":
            if not self.base_url:
                raise ModelConfigError(
                    f"{self.profile.name}: set {self.profile.host_env} (or pass a base URL); "
                    f"the SDK then calls {self.profile.base_path}/v1/messages on it"
                )
            # The gateway's own token only: an ANTHROPIC_* credential in the environment
            # belongs to the first-party API and must never be sent to another host.
            source = next((v for v in self.profile.token_env if os.environ.get(v)), None)
            if source is None:
                raise ModelConfigError(
                    f"{self.profile.name}: set {' or '.join(self.profile.token_env)} "
                    "to a workspace access token"
                )
            self.token_source = source
            kwargs["auth_token"] = os.environ[source]  # sent as `Authorization: Bearer`
        else:
            self.token_source = next(
                (v for v in ("ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN") if os.environ.get(v)),
                "SDK credential discovery",
            )
        self._client = anthropic.AsyncAnthropic(**kwargs)
        params = inspect.signature(self._client.beta.messages.stream).parameters
        self._native_fallbacks = "fallbacks" in params

    # ------------------------------------------------------------------ introspection
    @property
    def host(self) -> str:
        return urlsplit(self.base_url).netloc if self.base_url else "api.anthropic.com"

    def describe(self) -> str:
        """Model, provider, host and which variable supplies the credential - never its value."""
        return (
            f"{self.model} via {self.profile.name} ({self.host}; credential: {self.token_source})"
        )

    # ------------------------------------------------------------------ requests
    def _request(
        self, system: str, tools: list[dict[str, Any]], messages: list[dict[str, Any]]
    ) -> dict[str, Any]:
        tool_extras: dict[str, Any] = {"strict": True}
        if self.profile.eager_input_streaming:
            tool_extras["eager_input_streaming"] = True
        kwargs: dict[str, Any] = {
            "model": self.model,
            "max_tokens": self._config.max_tokens,
            "system": [{"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}],
            "tools": [{**tool, **tool_extras} for tool in tools],
            "messages": messages,
            "output_config": {"effort": self._config.effort},
        }
        if self.profile.beta_namespace and self._config.fallbacks:
            kwargs["betas"] = [_FALLBACK_BETA]
            if self._native_fallbacks:
                kwargs["fallbacks"] = "default"
            else:
                kwargs["extra_body"] = {"fallbacks": "default"}
        for name in self.degraded:
            _strip_field(kwargs, name)
        return kwargs

    def _rejected_field(self, exc: Exception) -> str | None:
        text = f"{exc} {getattr(exc, 'body', '')}".lower()
        return next((f for f in _OPTIONAL_FIELDS if f not in self.degraded and f in text), None)

    def _no_stream_error(self, stream: Any) -> ModelConfigError:
        # The SDK asserts when the stream closes before any `message_start` event: the URL
        # answered with something that is not a Messages SSE stream (a wrong gateway path,
        # a sign-in or portal page, a misrouted model id).
        try:
            response = stream.response
            detail = (
                f" (HTTP {response.status_code}, content-type "
                f"{response.headers.get('content-type', 'unknown')})"
            )
        except Exception:  # noqa: BLE001 - the detail is best-effort
            detail = ""
        return ModelConfigError(
            f"{self.profile.name} returned no Messages stream{detail}: check the base URL "
            f"{self.base_url or 'default'} and the model id {self.model!r}"
        )

    async def stream(
        self, *, system: str, tools: list[dict[str, Any]], messages: list[dict[str, Any]]
    ) -> AsyncIterator[StreamEvent]:
        """Yield text deltas as they arrive, then the completed turn as the last event."""
        kwargs = self._request(system, tools, messages)
        resource = (
            self._client.beta.messages if self.profile.beta_namespace else self._client.messages
        )
        yielded = False
        while True:  # bounded: every retry removes one of the finite _OPTIONAL_FIELDS
            try:
                async with resource.stream(**kwargs) as stream:
                    async for event in stream:
                        if getattr(event, "type", None) == "text" and event.text:
                            yielded = True
                            yield StreamEvent("text", text=event.text)
                    try:
                        message = await stream.get_final_message()
                    except AssertionError as exc:
                        raise self._no_stream_error(stream) from exc
                break
            except self._anthropic.BadRequestError as exc:
                name = self._rejected_field(exc)
                if name is None or yielded:
                    raise
                self.degraded.append(name)
                _strip_field(kwargs, name)
                log.warning("llm.field_rejected", provider=self.profile.name, field=name)
        data = message.to_dict()
        yield StreamEvent(
            "message",
            turn=ModelTurn(
                content=list(data.get("content", [])),
                stop_reason=data.get("stop_reason"),
                usage=dict(data.get("usage") or {}),
                stop_details=data.get("stop_details"),
                model=data.get("model"),
            ),
        )

    async def complete(
        self, *, system: str, tools: list[dict[str, Any]], messages: list[dict[str, Any]]
    ) -> ModelTurn:
        turn: ModelTurn | None = None
        async for event in self.stream(system=system, tools=tools, messages=messages):
            if event.kind == "message":
                turn = event.turn
        assert turn is not None  # the stream always ends with the message event
        return turn


def _strip_field(kwargs: dict[str, Any], name: str) -> None:
    if name in ("eager_input_streaming", "strict"):
        for tool in kwargs["tools"]:
            tool.pop(name, None)
    elif name == "cache_control":
        for block in kwargs["system"]:
            block.pop("cache_control", None)
    elif name == "output_config":
        kwargs.pop("output_config", None)
