"""The hub's own Grafana dashboard, built from the metrics both services export.

Grafana Cloud has no file provisioning, so the dashboard is a JSON model the query service can
POST to ``/api/dashboards/db`` on demand (the Observability tab's "Provision" button). It uses a
datasource variable so it binds to whichever Prometheus the stack has.
"""

from __future__ import annotations

from typing import Any

HUB_DASHBOARD_UID = "ech-context-hub"
HUB_DASHBOARD_TITLE = "Enterprise Context Hub"

_DS = {"type": "prometheus", "uid": "${datasource}"}
_RATE = "[$__rate_interval]"


def _target(expr: str, legend: str = "", ref: str = "A") -> dict[str, Any]:
    return {"refId": ref, "datasource": _DS, "expr": expr, "legendFormat": legend, "range": True}


def _thresholds(*steps: tuple[str, float | None]) -> dict[str, Any]:
    return {"mode": "absolute", "steps": [{"color": color, "value": value} for color, value in steps]}


def _stat(pid: int, title: str, expr: str, x: int, y: int, *, w: int = 6, h: int = 4, unit: str = "short", decimals: int | None = None, thresholds: dict[str, Any] | None = None, description: str = "") -> dict[str, Any]:
    defaults: dict[str, Any] = {"unit": unit, "thresholds": thresholds or _thresholds(("green", None))}
    if decimals is not None:
        defaults["decimals"] = decimals
    return {
        "id": pid,
        "type": "stat",
        "title": title,
        "description": description,
        "datasource": _DS,
        "gridPos": {"x": x, "y": y, "w": w, "h": h},
        "targets": [_target(expr)],
        "fieldConfig": {"defaults": defaults, "overrides": []},
        "options": {"reduceOptions": {"calcs": ["lastNotNull"], "fields": "", "values": False}, "colorMode": "value", "graphMode": "area", "textMode": "value", "orientation": "auto"},
    }


def _timeseries(pid: int, title: str, targets: list[dict[str, Any]], x: int, y: int, *, w: int = 12, h: int = 8, unit: str = "short", description: str = "", stack: bool = False) -> dict[str, Any]:
    custom: dict[str, Any] = {"lineWidth": 2, "fillOpacity": 12, "showPoints": "never", "spanNulls": True}
    if stack:
        custom["stacking"] = {"mode": "normal", "group": "A"}
    return {
        "id": pid,
        "type": "timeseries",
        "title": title,
        "description": description,
        "datasource": _DS,
        "gridPos": {"x": x, "y": y, "w": w, "h": h},
        "targets": targets,
        "fieldConfig": {"defaults": {"unit": unit, "custom": custom}, "overrides": []},
        "options": {"legend": {"displayMode": "list", "placement": "bottom", "showLegend": True}, "tooltip": {"mode": "multi", "sort": "desc"}},
    }


def _row(pid: int, title: str, y: int) -> dict[str, Any]:
    return {"id": pid, "type": "row", "title": title, "collapsed": False, "gridPos": {"x": 0, "y": y, "w": 24, "h": 1}, "panels": []}


def hub_dashboard() -> dict[str, Any]:
    """Serving, retrieval and ingestion of the hub, from the ech_* metrics."""
    req = f"rate(ech_http_requests_total{_RATE})"
    dur_bucket = f"rate(ech_http_request_duration_seconds_bucket{_RATE})"
    panels: list[dict[str, Any]] = [
        _row(100, "Serving", 0),
        _stat(1, "Requests / s", f"sum({req})", 0, 1, unit="reqps", decimals=2, description="All HTTP requests across both services."),
        _stat(
            2,
            "Error rate",
            f'100 * sum(rate(ech_http_requests_total{{status=~"5.."}}{_RATE})) / clamp_min(sum({req}), 1e-9)',
            6,
            1,
            unit="percent",
            decimals=2,
            thresholds=_thresholds(("green", None), ("yellow", 1), ("red", 5)),
            description="Share of 5xx responses; the hub's SLO target is 1%.",
        ),
        _stat(
            3,
            "p95 latency",
            f"histogram_quantile(0.95, sum by (le) ({dur_bucket}))",
            12,
            1,
            unit="s",
            decimals=3,
            thresholds=_thresholds(("green", None), ("yellow", 1.0), ("red", 1.5)),
            description="95th percentile across all routes; the hub's retrieval target is 1.5 s.",
        ),
        _stat(4, "In flight", "sum(ech_http_requests_in_flight)", 18, 1, unit="short", decimals=0, description="Requests being served right now."),
        _timeseries(5, "Requests by service", [_target(f"sum by (service) ({req})", "{{service}}")], 0, 5, unit="reqps", stack=True),
        _timeseries(6, "p95 latency by route", [_target(f"histogram_quantile(0.95, sum by (le, path) ({dur_bucket}))", "{{path}}")], 12, 5, unit="s"),
        _timeseries(7, "5xx responses by route", [_target(f'sum by (service, path) (rate(ech_http_requests_total{{status=~"5.."}}{_RATE}))', "{{service}} {{path}}")], 0, 13, unit="reqps", stack=True),
        _timeseries(8, "Database pool", [_target("sum by (service, state) (ech_db_pool_connections)", "{{service}} {{state}}")], 12, 13, unit="short", stack=True),
        _row(101, "Retrieval and Genie", 21),
        _timeseries(9, "Retrieval requests by outcome", [_target(f"sum by (outcome) (rate(ech_retrieval_requests_total{_RATE}))", "{{outcome}}")], 0, 22, unit="reqps", stack=True),
        _timeseries(10, "Retrieval stage p95", [_target(f"histogram_quantile(0.95, sum by (le, stage) (rate(ech_retrieval_stage_duration_seconds_bucket{_RATE})))", "{{stage}}")], 12, 22, unit="s"),
        _timeseries(
            11,
            "Candidates before ranking",
            [
                _target(f"histogram_quantile(0.50, sum by (le) (rate(ech_retrieval_candidates_bucket{_RATE})))", "p50", "A"),
                _target(f"histogram_quantile(0.95, sum by (le) (rate(ech_retrieval_candidates_bucket{_RATE})))", "p95", "B"),
            ],
            0,
            30,
            unit="short",
        ),
        _timeseries(
            12,
            "Embeddings",
            [
                _target(f"sum by (provider) (rate(ech_embedding_texts_total{_RATE}))", "texts/s {{provider}}", "A"),
                _target(f"histogram_quantile(0.95, sum by (le, provider) (rate(ech_embedding_batch_duration_seconds_bucket{_RATE})))", "batch p95 {{provider}}", "B"),
            ],
            12,
            30,
            unit="short",
        ),
        _row(102, "Ingestion", 38),
        _stat(13, "Active runs", "sum(ech_ingestion_runs_active)", 0, 39, unit="short", decimals=0, thresholds=_thresholds(("green", None), ("yellow", 1))),
        _stat(14, "Documents / min", f"60 * sum(rate(ech_ingestion_documents_total{_RATE}))", 6, 39, unit="short", decimals=1),
        _stat(15, "Failed documents / min", f'60 * sum(rate(ech_ingestion_documents_total{{outcome="failed"}}{_RATE}))', 12, 39, unit="short", decimals=1, thresholds=_thresholds(("green", None), ("red", 0.01))),
        _stat(16, "Graph sync failures / min", f'60 * sum(rate(ech_graph_sync_total{{outcome="failed"}}{_RATE}))', 18, 39, unit="short", decimals=1, thresholds=_thresholds(("green", None), ("red", 0.01))),
        _timeseries(17, "Documents by connector and outcome", [_target(f"sum by (connector, outcome) (rate(ech_ingestion_documents_total{_RATE}))", "{{connector}} {{outcome}}")], 0, 43, unit="ops", stack=True),
        _timeseries(18, "Chunks by connector", [_target(f"sum by (connector) (rate(ech_ingestion_chunks_total{_RATE}))", "{{connector}}")], 12, 43, unit="ops", stack=True),
        _timeseries(19, "Graph sync by outcome", [_target(f"sum by (outcome) (rate(ech_graph_sync_total{_RATE}))", "{{outcome}}")], 0, 51, unit="ops", stack=True),
    ]
    return {
        "uid": HUB_DASHBOARD_UID,
        "title": HUB_DASHBOARD_TITLE,
        "description": "Serving, retrieval and ingestion health of the Enterprise Context Hub, from the metrics both services export. Provisioned by the hub itself.",
        "tags": ["context-hub", "ech"],
        "timezone": "browser",
        "editable": True,
        "graphTooltip": 1,
        "refresh": "30s",
        "schemaVersion": 39,
        "time": {"from": "now-6h", "to": "now"},
        "templating": {
            "list": [
                {
                    "name": "datasource",
                    "label": "Prometheus",
                    "type": "datasource",
                    "query": "prometheus",
                    "current": {},
                    "hide": 0,
                    "refresh": 1,
                }
            ]
        },
        "panels": panels,
    }
