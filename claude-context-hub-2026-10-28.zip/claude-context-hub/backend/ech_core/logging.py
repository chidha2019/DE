"""structlog configuration shared by both services.

* JSON output in containers (``ECH_LOG_JSON=true``), coloured console locally.
* Standard-library loggers (uvicorn, asyncpg, neo4j) are routed through the
  same processor chain so every line has the same shape.
* Request-scoped context (request_id, path, ...) is injected through
  ``structlog.contextvars`` by the observability middleware.
"""

from __future__ import annotations

import logging
import sys
from typing import Any

import structlog
from structlog.types import EventDict, Processor


def _add_service(service_name: str) -> Processor:
    def processor(_: Any, __: str, event_dict: EventDict) -> EventDict:
        event_dict.setdefault("service", service_name)
        return event_dict

    return processor


def _drop_color_message_key(_: Any, __: str, event_dict: EventDict) -> EventDict:
    # uvicorn adds a duplicate "color_message" key that we never want in JSON.
    event_dict.pop("color_message", None)
    return event_dict


def configure_logging(
    *, level: str = "INFO", json_output: bool = False, service_name: str = "ech"
) -> None:
    """Configure structlog + stdlib logging. Idempotent."""
    numeric_level = logging.getLevelName(level.upper())
    if not isinstance(numeric_level, int):
        numeric_level = logging.INFO

    shared: list[Processor] = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_log_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso", utc=True),
        structlog.processors.StackInfoRenderer(),
        _drop_color_message_key,
        _add_service(service_name),
    ]

    if json_output:
        shared.append(structlog.processors.format_exc_info)
        renderer: Processor = structlog.processors.JSONRenderer()
    else:
        renderer = structlog.dev.ConsoleRenderer(colors=sys.stdout.isatty())

    structlog.configure(
        processors=[*shared, structlog.stdlib.ProcessorFormatter.wrap_for_formatter],
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.make_filtering_bound_logger(numeric_level),
        cache_logger_on_first_use=False,
    )

    formatter = structlog.stdlib.ProcessorFormatter(
        foreign_pre_chain=shared,
        processors=[structlog.stdlib.ProcessorFormatter.remove_processors_meta, renderer],
    )
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(formatter)

    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(numeric_level)

    # Route third-party loggers through our handler; silence the noisiest.
    for name in ("uvicorn", "uvicorn.error", "uvicorn.access", "asyncpg", "neo4j", "httpx"):
        lg = logging.getLogger(name)
        lg.handlers.clear()
        lg.propagate = True
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)  # we emit our own access log
    logging.getLogger("neo4j").setLevel(max(numeric_level, logging.WARNING))
    logging.getLogger("httpx").setLevel(max(numeric_level, logging.WARNING))


def get_logger(name: str | None = None) -> structlog.stdlib.BoundLogger:
    """Return a bound structlog logger (typed for editor support)."""
    return structlog.get_logger(name)  # type: ignore[no-any-return]
