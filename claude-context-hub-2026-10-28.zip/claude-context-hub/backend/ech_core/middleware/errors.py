"""Exception handlers producing one consistent error envelope.

{"error": {"code": "...", "message": "...", "details": ..., "request_id": "..."}}
"""

from __future__ import annotations

from typing import Any

import asyncpg
from fastapi import FastAPI, Request
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from neo4j.exceptions import Neo4jError, ServiceUnavailable, SessionExpired
from starlette.exceptions import HTTPException as StarletteHTTPException

from ech_core.exceptions import ECHError
from ech_core.logging import get_logger

log = get_logger(__name__)

_HTTP_CODES = {
    401: "unauthorized",
    403: "forbidden",
    404: "not_found",
    405: "method_not_allowed",
}


def _request_id(request: Request) -> str | None:
    return getattr(request.state, "request_id", None)


def _envelope(
    request: Request, *, status: int, code: str, message: str, details: Any = None
) -> JSONResponse:
    return JSONResponse(
        status_code=status,
        content={
            "error": {
                "code": code,
                "message": message,
                "details": jsonable_encoder(details) if details is not None else {},
                "request_id": _request_id(request),
            }
        },
    )


def register_exception_handlers(app: FastAPI) -> None:
    @app.exception_handler(ECHError)
    async def _ech_error(request: Request, exc: ECHError) -> JSONResponse:
        level = log.warning if exc.status_code < 500 else log.error
        level("request.error", code=exc.code, status=exc.status_code, message=exc.message)
        return _envelope(
            request,
            status=exc.status_code,
            code=exc.code,
            message=exc.message,
            details=exc.details,
        )

    @app.exception_handler(RequestValidationError)
    async def _validation(request: Request, exc: RequestValidationError) -> JSONResponse:
        return _envelope(
            request,
            status=422,
            code="validation_error",
            message="Request validation failed",
            details=exc.errors(),
        )

    @app.exception_handler(StarletteHTTPException)
    async def _http(request: Request, exc: StarletteHTTPException) -> JSONResponse:
        return _envelope(
            request,
            status=exc.status_code,
            code=_HTTP_CODES.get(exc.status_code, "http_error"),
            message=str(exc.detail),
        )

    @app.exception_handler(asyncpg.PostgresError)
    async def _postgres(request: Request, exc: asyncpg.PostgresError) -> JSONResponse:
        connection_issue = isinstance(
            exc, asyncpg.PostgresConnectionError | asyncpg.CannotConnectNowError
        )
        log.error("postgres.error", error=str(exc), sqlstate=getattr(exc, "sqlstate", None))
        return _envelope(
            request,
            status=503 if connection_issue else 500,
            code="dependency_unavailable" if connection_issue else "database_error",
            message="PostgreSQL unavailable" if connection_issue else "Database error",
        )

    @app.exception_handler(asyncpg.InterfaceError)
    async def _postgres_interface(request: Request, exc: asyncpg.InterfaceError) -> JSONResponse:
        log.error("postgres.interface_error", error=str(exc))
        return _envelope(
            request, status=503, code="dependency_unavailable", message="PostgreSQL unavailable"
        )

    @app.exception_handler(Neo4jError)
    async def _neo4j(request: Request, exc: Neo4jError) -> JSONResponse:
        unavailable = isinstance(exc, ServiceUnavailable | SessionExpired)
        log.error("neo4j.error", error=str(exc), code=getattr(exc, "code", None))
        return _envelope(
            request,
            status=503 if unavailable else 500,
            code="dependency_unavailable" if unavailable else "graph_error",
            message="Neo4j unavailable" if unavailable else "Graph database error",
        )

    @app.exception_handler(Exception)
    async def _unhandled(request: Request, exc: Exception) -> JSONResponse:
        log.exception("request.unhandled_exception", error=str(exc))
        return _envelope(
            request, status=500, code="internal_error", message="An unexpected error occurred"
        )
