"""Pure-ASGI middleware: request id, structured access log, Prometheus, latency buffer.

Implemented at the ASGI level (not ``BaseHTTPMiddleware``) so streaming
responses such as the SSE event feed are not buffered and contextvars behave.
"""

from __future__ import annotations

import re
import time
import uuid

import structlog
from starlette.datastructures import MutableHeaders
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from ech_core.logging import get_logger
from ech_core.metrics import (
    HTTP_REQUEST_DURATION,
    HTTP_REQUESTS_IN_FLIGHT,
    HTTP_REQUESTS_TOTAL,
)
from ech_core.observability import LatencyRecorder

log = get_logger("ech.access")

_UUID_RE = re.compile(
    r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"
)
_INT_RE = re.compile(r"/\d+(?=/|$)")
_QUIET_PATHS = {"/metrics", "/health/live", "/health/ready"}


def route_group(path: str) -> str:
    """Collapse identifiers so Prometheus label cardinality stays bounded."""
    return _INT_RE.sub("/{id}", _UUID_RE.sub("{id}", path))


class ObservabilityMiddleware:
    def __init__(
        self,
        app: ASGIApp,
        *,
        service_name: str,
        latency_recorder: LatencyRecorder | None = None,
    ) -> None:
        self.app = app
        self.service_name = service_name
        self.recorder = latency_recorder

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        headers = {
            k.decode("latin-1").lower(): v.decode("latin-1") for k, v in scope.get("headers", [])
        }
        request_id = headers.get("x-request-id") or uuid.uuid4().hex
        method: str = scope.get("method", "GET")
        path: str = scope.get("path", "/")
        group = route_group(path)
        scope.setdefault("state", {})["request_id"] = request_id

        structlog.contextvars.clear_contextvars()
        structlog.contextvars.bind_contextvars(request_id=request_id, method=method, path=path)

        started = time.perf_counter()
        status_code = 500
        HTTP_REQUESTS_IN_FLIGHT.labels(self.service_name).inc()

        async def send_wrapper(message: Message) -> None:
            nonlocal status_code
            if message["type"] == "http.response.start":
                status_code = message["status"]
                response_headers = MutableHeaders(scope=message)
                response_headers.append("X-Request-ID", request_id)
                response_headers.append(
                    "X-Response-Time-ms", f"{(time.perf_counter() - started) * 1000:.2f}"
                )
            await send(message)

        try:
            await self.app(scope, receive, send_wrapper)
        finally:
            duration = time.perf_counter() - started
            HTTP_REQUESTS_IN_FLIGHT.labels(self.service_name).dec()
            if path not in _QUIET_PATHS:
                HTTP_REQUESTS_TOTAL.labels(self.service_name, method, group, str(status_code)).inc()
                HTTP_REQUEST_DURATION.labels(self.service_name, method, group).observe(duration)
                if self.recorder is not None:
                    self.recorder.record(
                        path=path, method=method, status=status_code, duration_ms=duration * 1000
                    )
                log.info(
                    "http.request",
                    status=status_code,
                    duration_ms=round(duration * 1000, 2),
                    client=(scope.get("client") or ("-",))[0],
                )
            structlog.contextvars.clear_contextvars()
