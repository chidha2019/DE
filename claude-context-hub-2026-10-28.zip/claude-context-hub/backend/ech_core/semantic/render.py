"""Render a semantic asset as the markdown document the hub indexes.

The document is what hybrid retrieval, the entity extractor and Genie's
``search_knowledge`` see, so it spells out the business meaning in prose and tables:
one heading per concern so the semantic chunker keeps columns, keys and metrics as
separate, retrievable chunks.
"""

from __future__ import annotations

import re

from ech_core.semantic.models import (
    AssetKind,
    FieldRole,
    MetricSource,
    RelationshipKind,
    SemanticAsset,
)

_ROLE_LABEL = {
    FieldRole.IDENTIFIER: "identifier",
    FieldRole.DIMENSION: "dimension",
    FieldRole.TIME: "time",
    FieldRole.MEASURE: "measure",
    FieldRole.ATTRIBUTE: "attribute",
}
_KIND_LABEL = {
    AssetKind.FACT: "fact table",
    AssetKind.DIMENSION: "dimension table",
    AssetKind.BRIDGE: "bridge table",
    AssetKind.METRIC: "metric definition",
    AssetKind.REFERENCE: "reference table",
    AssetKind.UNKNOWN: "dataset",
}
_PLATFORM_LABEL = {"snowflake": "Snowflake", "databricks": "Databricks Unity Catalog"}
_REL_LABEL = {
    RelationshipKind.FOREIGN_KEY: "Foreign key to",
    RelationshipKind.JOIN_DECLARED: "Joins",
    RelationshipKind.JOIN_INFERRED: "Probably joins",
    RelationshipKind.LINEAGE_UPSTREAM: "Reads from",
    RelationshipKind.LINEAGE_DOWNSTREAM: "Feeds",
    RelationshipKind.METRIC_SOURCE: "Defined over",
}


_UUID_LIKE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-", re.I)
_SYSTEM_OWNERS = {"system user", "system", "root", "admin", "administrator", "service principal"}


def owner_is_person(owner: str | None) -> bool:
    """Owners that look like people (emails, 'First Last'), not roles or service principals."""
    if not owner:
        return False
    value = owner.strip()
    if value.lower() in _SYSTEM_OWNERS or _UUID_LIKE.match(value):
        return False
    if "@" in value:
        return True
    words = value.replace("_", " ").split()
    return len(words) >= 2 and all(w[:1].isupper() for w in words) and not value.isupper()


def asset_title(asset: SemanticAsset) -> str:
    return asset.fqn


def render_asset_markdown(asset: SemanticAsset) -> str:
    platform = _PLATFORM_LABEL.get(asset.platform.value, asset.platform.value)
    kind = _KIND_LABEL[asset.kind]
    facts = [
        f"**{asset.asset_type.value.replace('_', ' ').title()}** ({kind}) in {platform}",
        f"database `{asset.database}`, schema `{asset.schema_name}`",
    ]
    if asset.owner:
        facts.append(f"owner {asset.owner}")
    if asset.row_count is not None:
        facts.append(f"{asset.row_count:,} rows")
    fmt = asset.properties.get("format")
    if fmt:
        facts.append(f"format {fmt}")
    lines = [f"# {asset.fqn}", "", " · ".join(facts), ""]
    if asset.description:
        lines += [asset.description.strip(), ""]
    if asset.tags:
        lines += ["Tags: " + ", ".join(asset.tags), ""]

    if asset.fields:
        lines += [
            "## Columns",
            "",
            "| # | Column | Type | Role | Key | Description |",
            "| --- | --- | --- | --- | --- | --- |",
        ]
        for f in sorted(asset.fields, key=lambda x: x.ordinal):
            key = "PK" if f.is_primary_key else ("partition" if f.is_partition else "")
            role = _ROLE_LABEL[f.role] + (f" ({f.aggregation})" if f.aggregation else "")
            lines.append(
                f"| {f.ordinal} | `{f.name}` | {f.data_type or '-'} | {role} | {key} | "
                f"{_cell(f.description)} |"
            )
        lines.append("")
        by_role = {
            role: [f.name for f in asset.fields if f.role is role]
            for role in (
                FieldRole.IDENTIFIER,
                FieldRole.TIME,
                FieldRole.MEASURE,
                FieldRole.DIMENSION,
            )
        }
        summary = [
            f"{_ROLE_LABEL[role]}s: {', '.join(names)}" for role, names in by_role.items() if names
        ]
        if summary:
            lines += ["Grain and roles: " + "; ".join(summary) + ".", ""]

    keys = asset.primary_key
    if keys or asset.relationships:
        lines += ["## Keys and relationships", ""]
        if keys:
            lines.append(f"- Primary key: {', '.join(f'`{k}`' for k in keys)}")
        for r in asset.relationships:
            cols = ""
            if r.source_columns:
                targets = r.target_columns or [""] * len(r.source_columns)
                cols = " on " + ", ".join(
                    f"`{s}` = `{t}`" if t else f"`{s}`"
                    for s, t in zip(r.source_columns, targets, strict=False)
                )
            suffix = (
                f" ({r.evidence}, confidence {r.confidence:.2f})"
                if r.kind is RelationshipKind.JOIN_INFERRED
                else ""
            )
            lines.append(f"- {_REL_LABEL[r.kind]} `{r.target_fqn}`{cols}{suffix}")
        lines.append("")

    if asset.metrics:
        declared = [m for m in asset.metrics if m.source is not MetricSource.INFERRED]
        inferred = [m for m in asset.metrics if m.source is MetricSource.INFERRED]
        lines += ["## Metrics", ""]
        for title, group in (("Declared", declared), ("Inferred", inferred)):
            if not group:
                continue
            lines.append(f"{title}:")
            for m in group:
                dims = f" by {', '.join(m.dimensions)}" if m.dimensions else ""
                lines.append(
                    f"- **{m.name}** = `{m.expression or m.aggregation or '?'}`{dims}"
                    + (f" — {m.description}" if m.description else "")
                )
            lines.append("")

    if asset.definition:
        fence = "yaml" if asset.asset_type.value in ("metric_view", "semantic_view") else "sql"
        lines += ["## Definition", "", f"```{fence}", asset.definition.strip()[:6000], "```", ""]

    consumers = asset.properties.get("consumers")
    if consumers:
        lines += ["## Consumers", ""] + [f"- {c}" for c in consumers[:20]] + [""]
    return "\n".join(lines).strip() + "\n"


def _cell(text: str) -> str:
    return (text or "").replace("|", "\\|").replace("\n", " ").strip()
