"""Vocabulary of the semantic layer (pydantic; also the wire format between services)."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any, Literal

from pydantic import BaseModel, Field


class Platform(StrEnum):
    SNOWFLAKE = "snowflake"
    DATABRICKS = "databricks"


class AssetType(StrEnum):
    TABLE = "table"
    VIEW = "view"
    MATERIALIZED_VIEW = "materialized_view"
    STREAMING_TABLE = "streaming_table"
    DYNAMIC_TABLE = "dynamic_table"
    METRIC_VIEW = "metric_view"  # Databricks Unity Catalog metric view
    SEMANTIC_VIEW = "semantic_view"  # Snowflake semantic view
    EXTERNAL_TABLE = "external_table"
    FOREIGN_TABLE = "foreign_table"  # Lakehouse Federation / Iceberg REST catalogs
    OTHER = "other"


class AssetKind(StrEnum):
    """What the asset *means* in a dimensional model (inferred unless declared)."""

    FACT = "fact"
    DIMENSION = "dimension"
    BRIDGE = "bridge"
    METRIC = "metric"
    REFERENCE = "reference"
    UNKNOWN = "unknown"


class FieldRole(StrEnum):
    IDENTIFIER = "identifier"
    DIMENSION = "dimension"
    TIME = "time"
    MEASURE = "measure"
    ATTRIBUTE = "attribute"


class RelationshipKind(StrEnum):
    FOREIGN_KEY = "foreign_key"  # declared constraint
    JOIN_DECLARED = "join_declared"  # a join written down in a metric/semantic view
    JOIN_INFERRED = "join_inferred"  # name-based inference, see ``inference.infer_joins``
    LINEAGE_UPSTREAM = "lineage_upstream"  # this asset reads from the target
    LINEAGE_DOWNSTREAM = "lineage_downstream"  # the target reads from this asset
    METRIC_SOURCE = "metric_source"  # a metric view over the target


class MetricSource(StrEnum):
    DECLARED = "declared"
    INFERRED = "inferred"
    CURATED = "curated"  # accepted from a model suggestion or written by a person


NameSource = Literal["derived", "declared", "model", "curated"]
KindSource = Literal["inferred", "declared", "model", "curated"]


class SemanticField(BaseModel):
    name: str
    display_name: str = Field(default="", description="business name; derived when empty")
    ordinal: int = 0
    data_type: str = ""
    description: str = ""
    nullable: bool | None = None
    is_primary_key: bool = False
    is_partition: bool = False
    role: FieldRole = FieldRole.ATTRIBUTE
    role_confidence: float = Field(
        default=0.0, ge=0.0, le=1.0, description="0 = not classified yet; 1 = declared"
    )
    aggregation: str | None = Field(
        default=None, description="measures: sum | avg | count | min | max"
    )
    tags: list[str] = Field(default_factory=list)
    synonyms: list[str] = Field(default_factory=list)


class SemanticRelationship(BaseModel):
    target_fqn: str
    kind: RelationshipKind
    source_columns: list[str] = Field(default_factory=list)
    target_columns: list[str] = Field(default_factory=list)
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    evidence: str = ""


class SemanticMetric(BaseModel):
    name: str
    display_name: str = ""
    expression: str = ""
    aggregation: str | None = None
    description: str = ""
    source: MetricSource = MetricSource.INFERRED
    dimensions: list[str] = Field(default_factory=list)
    fields: list[str] = Field(default_factory=list, description="columns the expression uses")
    synonyms: list[str] = Field(default_factory=list)


class SemanticAsset(BaseModel):
    platform: Platform
    fqn: str = Field(description="database.schema.name as the platform spells it")
    database: str
    schema_name: str
    name: str
    asset_type: AssetType = AssetType.TABLE
    kind: AssetKind = AssetKind.UNKNOWN
    display_name: str = Field(default="", description="business name shown to readers")
    summary: str = Field(default="", description="one line in business language")
    name_source: NameSource = "derived"
    kind_source: KindSource = "inferred"
    description: str = ""
    owner: str | None = None
    tags: list[str] = Field(default_factory=list)
    properties: dict[str, Any] = Field(default_factory=dict)
    definition: str | None = Field(
        default=None, description="view SQL or metric/semantic view spec"
    )
    row_count: int | None = None
    bytes: int | None = None
    source_created_at: datetime | None = None
    source_updated_at: datetime | None = None
    uri: str | None = None
    fields: list[SemanticField] = Field(default_factory=list)
    relationships: list[SemanticRelationship] = Field(default_factory=list)
    metrics: list[SemanticMetric] = Field(default_factory=list)

    @property
    def primary_key(self) -> list[str]:
        return [f.name for f in self.fields if f.is_primary_key]

    def field(self, name: str) -> SemanticField | None:
        wanted = name.casefold()
        return next((f for f in self.fields if f.name.casefold() == wanted), None)

    def fields_with_role(self, role: FieldRole) -> list[SemanticField]:
        return [f for f in self.fields if f.role is role]
