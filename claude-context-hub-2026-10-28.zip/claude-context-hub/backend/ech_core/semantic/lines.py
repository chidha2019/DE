"""Line of business as a facet of the catalog: which lines a dataset holds, and how the sync knows.

The sync asks in a fixed order and the first source that answers wins: a Snowflake tag on the table or
one of its columns, the default of a pipeline whose scope covers the dataset, the distinct values of a
line-of-business column, and last the datasets it references (foreign keys, declared joins, upstream
lineage), nearest first: POLICY -> PRODUCT_VERSION -> PRODUCT. A dataset none of these reach is shared
across lines. Nothing here touches a database; the caller loads the inputs and stores the result.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from dataclasses import dataclass, field
from typing import Literal
from uuid import UUID

LineSource = Literal["tag", "pipeline", "values", "inherited"]
_NON_WORD = re.compile("[^a-z0-9]+")
_SPLIT = re.compile("[,;|/]+")


def norm(text: str) -> str:
    return _NON_WORD.sub(" ", text.lower()).strip()


@dataclass(frozen=True)
class LineValue:
    key: str
    name: str
    aliases: tuple[str, ...] = ()


@dataclass
class LineEvidence:
    lines: set[str]
    source: LineSource
    evidence: str


@dataclass
class LineVocabulary:
    """The values of the Line of Business term and the names a column or tag carrying one goes by."""

    values: list[LineValue]
    names: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        self._by_alias = {norm(a): v.key for v in self.values for a in (v.key, v.name, *v.aliases)}
        self._names = {norm(n) for n in self.names} | {"line of business", "lob"}

    def is_line_name(self, name: str) -> bool:
        """LINE_OF_BUSINESS, Lob, or a qualified tag such as GOVERNANCE.TAGS.LINE_OF_BUSINESS."""
        return norm(name.rsplit(".", 1)[-1]) in self._names

    def match(self, raw: str) -> tuple[set[str], list[str]]:
        """The line keys in a value such as 'LIFE' or 'Life, Annuity', and the parts no alias knows."""
        keys: set[str] = set()
        unknown: list[str] = []
        for part in _SPLIT.split(raw or ""):
            if not part.strip():
                continue
            key = self._by_alias.get(norm(part))
            if key:
                keys.add(key)
            else:
                unknown.append(part.strip())
        return keys, unknown


def from_tags(labels: Iterable[str], vocab: LineVocabulary) -> LineEvidence | None:
    """Tags arrive as NAME=VALUE, from the table and from its columns."""
    lines: set[str] = set()
    seen: list[str] = []
    for label in labels:
        name, _, value = label.partition("=")
        if value and vocab.is_line_name(name):
            keys, _ = vocab.match(value)
            if keys:
                lines |= keys
                seen.append(label)
    return LineEvidence(lines, "tag", "tag " + ", ".join(seen)) if lines else None


def line_columns(fields: Iterable[dict], vocab: LineVocabulary, linked: set[UUID]) -> list[str]:
    """Columns that hold a line of business: named like one, or linked to the term by an accepted link."""
    return [f["name"] for f in fields if vocab.is_line_name(f["name"]) or f.get("id") in linked]


def from_values(column: str, values: Iterable[str], vocab: LineVocabulary) -> tuple[LineEvidence | None, list[str]]:
    lines: set[str] = set()
    unknown: list[str] = []
    for value in values:
        keys, rest = vocab.match(str(value))
        lines |= keys
        unknown += rest
    found = sorted(lines)
    return (LineEvidence(lines, "values", f"values of {column}: {', '.join(found)}") if lines else None), sorted(set(unknown))


def inherit(
    direct: dict[UUID, LineEvidence],
    parents: dict[UUID, list[UUID]],
    names: dict[UUID, str],
    *,
    max_hops: int = 4,
) -> dict[UUID, LineEvidence]:
    """Datasets without lines take the union of what the datasets they reference hold, nearest first.

    Each round only reads what earlier rounds settled, so a dataset is resolved at its shortest distance.
    """
    resolved: dict[UUID, LineEvidence] = dict(direct)
    paths: dict[UUID, list[str]] = {k: [names.get(k, str(k))] for k in direct}
    for _ in range(max_hops):
        found: dict[UUID, tuple[set[str], list[str]]] = {}
        for child, refs in parents.items():
            if child in resolved:
                continue
            lines: set[str] = set()
            path: list[str] = []
            for parent in refs:
                if parent in resolved and parent != child:
                    lines |= resolved[parent].lines
                    path = path or paths[parent]
            if lines:
                found[child] = (lines, path)
        if not found:
            break
        for child, (lines, path) in found.items():
            paths[child] = [names.get(child, str(child)), *path]
            resolved[child] = LineEvidence(lines, "inherited", "inherited via " + " → ".join(path))
    return {k: v for k, v in resolved.items() if k not in direct}


def from_defaults(fqn: str, defaults: Iterable[dict], vocab: LineVocabulary) -> LineEvidence | None:
    """The default of the most specific pipeline whose scope covers the dataset; an empty scope covers the source."""
    parts = [p.upper() for p in fqn.split(".")]
    best: dict | None = None
    depth = -1
    for d in defaults:
        for path in d.get("paths") or [[]]:
            prefix = [str(p).upper() for p in path]
            if parts[: len(prefix)] == prefix and len(prefix) > depth:
                best, depth = d, len(prefix)
    if best is None:
        return None
    keys, _ = vocab.match(str(best.get("line") or ""))
    return LineEvidence(keys, "pipeline", f"default of pipeline {best.get('name')}") if keys else None
