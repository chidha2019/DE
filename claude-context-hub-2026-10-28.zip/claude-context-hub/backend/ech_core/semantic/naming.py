"""Business names and one-line meanings derived from technical catalog names.

``fact_claim_payment_v1`` reads as "Claim Payment", ``cust_acct_id`` as "Customer Account ID".
These are the *derived* names; declared names (metric-view labels), model suggestions and
curated edits take precedence and are tracked through ``name_source``.
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ech_core.semantic.models import SemanticAsset

PREFIXES = re.compile(
    r"^(fact|fct|dim|dims|dimension|mv|bridge|brg|ref|lkp|lookup|stg|raw|src|tbl|vw|v|agg|rpt)_",
    re.I,
)
SUFFIXES = re.compile(r"(_v\d+|_draft|_tbl|_table|_view|_vw|_dim|_fact|_final|_curated)+$", re.I)
_CAMEL = re.compile(r"(?<=[a-z0-9])(?=[A-Z])")
_SPLIT = re.compile(r"[_\s\-./]+")
_SENTENCE_END = re.compile(r"(?<=[.!?])\s+")

ABBREVIATIONS: dict[str, str] = {
    "id": "ID",
    "ids": "IDs",
    "amt": "Amount",
    "dt": "Date",
    "cnt": "Count",
    "num": "Number",
    "nbr": "Number",
    "qty": "Quantity",
    "desc": "Description",
    "pct": "Percent",
    "avg": "Average",
    "tot": "Total",
    "txn": "Transaction",
    "trx": "Transaction",
    "acct": "Account",
    "cust": "Customer",
    "addr": "Address",
    "ts": "Timestamp",
    "yr": "Year",
    "mth": "Month",
    "wk": "Week",
    "cd": "Code",
    "nm": "Name",
    "sk": "Key",
    "fk": "Key",
    "pk": "Key",
    "kyc": "KYC",
    "api": "API",
    "url": "URL",
    "sla": "SLA",
    "ssn": "SSN",
    "dob": "Date of Birth",
    "ytd": "YTD",
    "mtd": "MTD",
    "edw": "EDW",
    "crm": "CRM",
    "erp": "ERP",
    "uw": "Underwriting",
    "lob": "Line of Business",
    "eff": "Effective",
    "exp": "Expiry",
    "curr": "Current",
    "prev": "Previous",
    "src": "Source",
    "sys": "System",
    "seq": "Sequence",
    "fx": "FX",
}
SMALL_WORDS = {
    "of",
    "and",
    "or",
    "the",
    "a",
    "an",
    "to",
    "in",
    "on",
    "by",
    "per",
    "for",
    "with",
    "at",
}


def business_name(technical: str) -> str:
    """Title-case business name for a technical identifier; the last part of a dotted name."""
    base = technical.strip()
    if not base:
        return ""
    if "." in base:
        base = base.rsplit(".", 1)[-1]
    stripped = SUFFIXES.sub("", PREFIXES.sub("", base)) or base
    if stripped.isupper():
        stripped = stripped.lower()  # ALL_CAPS identifiers carry no acronym information
    words = [w for w in _SPLIT.split(_CAMEL.sub(" ", stripped)) if w]
    out: list[str] = []
    for index, word in enumerate(words):
        lowered = word.lower()
        if lowered in ABBREVIATIONS:
            out.append(ABBREVIATIONS[lowered])
        elif index > 0 and lowered in SMALL_WORDS:
            out.append(lowered)
        elif word.isupper() and len(word) <= 4:
            out.append(word)
        else:
            out.append(word[:1].upper() + word[1:].lower())
    return " ".join(out) or technical


def first_sentence(text: str, limit: int = 180) -> str:
    """The first sentence of a description, trimmed to ``limit`` characters."""
    cleaned = " ".join(text.split())
    if not cleaned:
        return ""
    sentence = _SENTENCE_END.split(cleaned, maxsplit=1)[0]
    if len(sentence) <= limit:
        return sentence
    cut = sentence[: limit - 1].rsplit(" ", 1)[0]
    return cut + "…"


def summary_for(asset: SemanticAsset) -> str:
    """One line a business reader understands: the catalog comment, else what the columns say."""
    from ech_core.semantic.models import AssetKind, AssetType, FieldRole  # local: avoid a cycle

    if asset.description.strip():
        return first_sentence(asset.description)
    name = asset.display_name or business_name(asset.name)
    measures = asset.fields_with_role(FieldRole.MEASURE)
    dims = asset.fields_with_role(FieldRole.DIMENSION)
    times = asset.fields_with_role(FieldRole.TIME)
    keys = asset.primary_key
    if asset.asset_type in (AssetType.METRIC_VIEW, AssetType.SEMANTIC_VIEW):
        names = ", ".join(m.display_name or m.name for m in asset.metrics[:4])
        return f"Governed metrics: {names}" if names else "Governed metric definitions."
    parts: list[str] = []
    if asset.kind is AssetKind.FACT:
        parts.append(f"{name} records")
    elif asset.kind is AssetKind.DIMENSION:
        parts.append(f"{name} reference data")
    elif asset.kind is AssetKind.BRIDGE:
        parts.append(f"Links between {name.lower()} records")
    elif asset.kind is AssetKind.REFERENCE:
        parts.append(f"{name} codes and labels")
    else:
        parts.append(name)
    if keys:
        parts.append(f"keyed by {', '.join(keys[:2])}")
    facets: list[str] = []
    if measures:
        facets.append(f"{len(measures)} measure{'s' if len(measures) != 1 else ''}")
    if dims:
        facets.append(f"{len(dims)} dimension{'s' if len(dims) != 1 else ''}")
    if times:
        facets.append(f"{len(times)} time column{'s' if len(times) != 1 else ''}")
    if facets:
        parts.append("with " + ", ".join(facets))
    return " ".join(parts) + "."
