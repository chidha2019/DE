"""The semantic layer: business meaning over physical data assets.

Snowflake and Databricks connectors emit one :class:`SemanticAsset` per table-like
object (columns with inferred roles, keys, relationships, declared and inferred
metrics). The ingestion pipeline stores it next to the rendered document, the query
service serves, exports and hands it to Genie. See ``models`` for the vocabulary,
``inference`` for the heuristics, ``render`` for the document text and ``exports`` for
Snowflake Cortex Analyst / Databricks metric-view output.
"""

from ech_core.semantic.models import (
    AssetKind,
    AssetType,
    FieldRole,
    MetricSource,
    Platform,
    RelationshipKind,
    SemanticAsset,
    SemanticField,
    SemanticMetric,
    SemanticRelationship,
)

__all__ = [
    "AssetKind",
    "AssetType",
    "FieldRole",
    "MetricSource",
    "Platform",
    "RelationshipKind",
    "SemanticAsset",
    "SemanticField",
    "SemanticMetric",
    "SemanticRelationship",
]
