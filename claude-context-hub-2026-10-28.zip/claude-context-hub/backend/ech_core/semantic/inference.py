"""Heuristics that turn catalog metadata into a semantic model.

Everything here is deterministic and explainable: each decision carries a confidence
and the joins carry evidence. Declared facts from the platform (primary keys, foreign
keys, metric-view measures, Snowflake semantic views) always win over inference; the
connectors mark those with ``role_confidence=1.0`` / ``source=declared`` and the
functions below leave them untouched.
"""

from __future__ import annotations

import re
from collections import defaultdict
from collections.abc import Iterable

from ech_core.semantic.models import (
    AssetKind,
    AssetType,
    FieldRole,
    MetricSource,
    RelationshipKind,
    SemanticAsset,
    SemanticField,
    SemanticMetric,
    SemanticRelationship,
)
from ech_core.semantic.naming import business_name, summary_for

# --- type families ------------------------------------------------------------------
NUMERIC_TYPE = re.compile(
    r"^(number|numeric|decimal|dec|int|integer|bigint|smallint|tinyint|float|float4|float8"
    r"|double|double precision|real|long|short|byte)\b",
    re.I,
)
TIME_TYPE = re.compile(
    r"^(date|datetime|timestamp|timestamp_ntz|timestamp_ltz|timestamp_tz|time|interval)\b", re.I
)
TEXT_TYPE = re.compile(r"^(varchar|string|text|char|character|nvarchar|nchar|boolean|bool)\b", re.I)
COMPLEX_TYPE = re.compile(
    r"^(variant|object|array|struct|map|binary|geography|geometry|json|vector)\b", re.I
)

# --- name cues ----------------------------------------------------------------------
IDENTIFIER_NAME = re.compile(
    r"(^id$|_id$|_key$|_sk$|_pk$|_fk$|_uuid$|_guid$|_code$|_cd$|_no$|_num$|_number$|identifier$)",
    re.I,
)
TIME_NAME = re.compile(
    r"(_date$|_dt$|_ts$|_time$|_at$|_timestamp$|^date$|_month$|_year$|_quarter$|_week$|_day$"
    r"|_period$|_datetime$)",
    re.I,
)
MEASURE_NAME = re.compile(
    r"(amount|amt|total|sum|count|cnt|qty|quantity|price|cost|revenue|premium|balance|rate|pct"
    r"|percent|ratio|score|value|_val$|fee|loss|paid|incurred|reserve|exposure|units|weight"
    r"|volume|duration|days|hours|minutes|seconds|avg|mean|_min$|_max$|number_of|_bps|margin"
    r"|discount|tax|interest|benefit|payout|salary|income|limit|deductible|measure|metric)",
    re.I,
)
DIMENSION_NAME = re.compile(
    r"(status|type|category|segment|tier|region|country|state|province|city|zip|postal|name"
    r"|flag|^is_|^has_|gender|channel|product|plan|group|class|level|bucket|band|method|source"
    r"|reason|currency|lob|line_of_business|industry|description|label|title)",
    re.I,
)
AVERAGE_NAME = re.compile(r"(rate|pct|percent|ratio|score|avg|mean|age$|price|margin|_bps)", re.I)

FACT_TABLE = re.compile(
    r"(^fct_|^fact_|_fact$|_facts$|^f_|metrics|^agg_|_agg$|summary|snapshot|^mv_|_mv$"
    r"|transaction|event|payment|claim|order|sale)",
    re.I,
)
DIMENSION_TABLE = re.compile(r"(^dim_|^dimension_|_dim$|^d_|lookup|^lkp_)", re.I)
REFERENCE_TABLE = re.compile(r"(^ref_|reference|^code_|_codes$|_types$|calendar|currency)", re.I)
BRIDGE_TABLE = re.compile(r"(^bridge_|^brg_|_bridge$|xref|_map$|^map_|crosswalk|_link$)", re.I)

THREE_PART_NAME = re.compile(
    r"(?<![\w.`\"])([A-Za-z_][\w$]*|`[^`]+`|\"[^\"]+\")\.([A-Za-z_][\w$]*|`[^`]+`|\"[^\"]+\")"
    r"\.([A-Za-z_][\w$]*|`[^`]+`|\"[^\"]+\")(?![\w.])"
)


def type_family(data_type: str) -> str:
    base = (data_type or "").strip()
    if TIME_TYPE.match(base):
        return "time"
    if NUMERIC_TYPE.match(base):
        return "numeric"
    if TEXT_TYPE.match(base):
        return "text"
    if COMPLEX_TYPE.match(base):
        return "complex"
    return "unknown"


def classify_asset(name: str, asset_type: AssetType, description: str = "") -> AssetKind:
    if asset_type in (AssetType.METRIC_VIEW, AssetType.SEMANTIC_VIEW):
        return AssetKind.METRIC
    if BRIDGE_TABLE.search(name):
        return AssetKind.BRIDGE
    if DIMENSION_TABLE.search(name):
        return AssetKind.DIMENSION
    if REFERENCE_TABLE.search(name):
        return AssetKind.REFERENCE
    if FACT_TABLE.search(name) or re.search(r"\bgrain\b", description, re.I):
        return AssetKind.FACT
    return AssetKind.UNKNOWN


def infer_field_role(
    field: SemanticField, *, asset_kind: AssetKind
) -> tuple[FieldRole, float, str | None]:
    """Role, confidence and (for measures) the default aggregation of one column."""
    name = field.name
    family = type_family(field.data_type)
    if field.is_primary_key:
        return FieldRole.IDENTIFIER, 0.98, None
    if family == "time" or (TIME_NAME.search(name) and family != "text"):
        return FieldRole.TIME, 0.9 if family == "time" else 0.7, None
    if IDENTIFIER_NAME.search(name):
        return FieldRole.IDENTIFIER, 0.85, None
    if family == "complex":
        return FieldRole.ATTRIBUTE, 0.8, None
    if family == "numeric":
        if MEASURE_NAME.search(name):
            return FieldRole.MEASURE, 0.85, "avg" if AVERAGE_NAME.search(name) else "sum"
        if DIMENSION_NAME.search(name):
            return FieldRole.DIMENSION, 0.65, None
        if asset_kind is AssetKind.FACT:
            return FieldRole.MEASURE, 0.6, "sum"
        return FieldRole.DIMENSION, 0.5, None
    if family == "text":
        if DIMENSION_NAME.search(name) or name.lower().startswith(("is_", "has_")):
            return FieldRole.DIMENSION, 0.8, None
        if re.search(r"(comment|note|text|body|payload|message|json)", name, re.I):
            return FieldRole.ATTRIBUTE, 0.7, None
        return FieldRole.DIMENSION, 0.55, None
    return FieldRole.ATTRIBUTE, 0.4, None


def infer_asset(asset: SemanticAsset) -> SemanticAsset:
    """Fill in kind, field roles and inferred metrics; declared information is kept."""
    if asset.kind is AssetKind.UNKNOWN:
        asset.kind = classify_asset(asset.name, asset.asset_type, asset.description)
    for field in asset.fields:
        if field.role_confidence >= 1.0:
            continue  # declared by the platform (metric-view dimension, semantic-view fact, ...)
        role, confidence, aggregation = infer_field_role(field, asset_kind=asset.kind)
        field.role, field.role_confidence = role, confidence
        field.aggregation = aggregation if role is FieldRole.MEASURE else None
    structural = refine_kind(asset)
    if asset.kind is AssetKind.UNKNOWN:
        asset.kind = structural
    elif (
        asset.kind is AssetKind.FACT
        and structural in (AssetKind.REFERENCE, AssetKind.BRIDGE)
        and not asset.fields_with_role(FieldRole.MEASURE)
    ):
        asset.kind = structural  # the name sounded like a fact; the columns say lookup or link
    if asset.asset_type in (AssetType.METRIC_VIEW, AssetType.SEMANTIC_VIEW):
        asset.kind_source = "declared"
    declared = {m.name.casefold() for m in asset.metrics}
    if asset.kind in (AssetKind.FACT, AssetKind.UNKNOWN, AssetKind.BRIDGE):
        for field in asset.fields_with_role(FieldRole.MEASURE):
            metric = _inferred_metric(field)
            if metric.name.casefold() not in declared:
                asset.metrics.append(metric)
                declared.add(metric.name.casefold())
        if asset.kind is AssetKind.FACT and "record_count" not in declared:
            asset.metrics.append(
                SemanticMetric(
                    name="record_count",
                    expression="COUNT(*)",
                    aggregation="count",
                    description=f"Number of rows in {asset.name}",
                    source=MetricSource.INFERRED,
                    dimensions=[f.name for f in asset.fields_with_role(FieldRole.DIMENSION)][:12],
                )
            )
    apply_names(asset)
    return asset


def refine_kind(asset: SemanticAsset) -> AssetKind:
    """Classify an asset whose name says nothing, from what its columns do."""
    fields = asset.fields
    if not fields:
        return AssetKind.UNKNOWN
    measures = len(asset.fields_with_role(FieldRole.MEASURE))
    times = len(asset.fields_with_role(FieldRole.TIME))
    ids = len(asset.fields_with_role(FieldRole.IDENTIFIER))
    dims = len(asset.fields_with_role(FieldRole.DIMENSION))
    attrs = len(asset.fields_with_role(FieldRole.ATTRIBUTE))
    total = len(fields)
    if measures >= 2 and times >= 1:
        return AssetKind.FACT
    if ids >= 2 and measures == 0 and total - ids <= 2:
        return AssetKind.BRIDGE
    if (
        total <= 4
        and measures == 0
        and ids <= 1
        and any(re.search(r"(code|name|description|label)$", f.name, re.I) for f in fields)
    ):
        return AssetKind.REFERENCE
    if ids >= 1 and measures == 0 and dims + attrs >= 2:
        return AssetKind.DIMENSION
    if measures >= 1 and (times >= 1 or ids >= 1):
        return AssetKind.FACT
    return AssetKind.UNKNOWN


def apply_names(asset: SemanticAsset) -> None:
    """Derived business names and a summary wherever nothing declared or curated exists."""
    if not asset.display_name.strip():
        asset.display_name = business_name(asset.name)
        asset.name_source = "derived"
    for field in asset.fields:
        if not field.display_name.strip():
            field.display_name = business_name(field.name)
    for metric in asset.metrics:
        if not metric.display_name.strip():
            metric.display_name = business_name(metric.name)
    if not asset.summary.strip():
        asset.summary = summary_for(asset)


def _inferred_metric(field: SemanticField) -> SemanticMetric:
    aggregation = field.aggregation or "sum"
    prefix = {"sum": "total", "avg": "average", "count": "count", "min": "min", "max": "max"}[
        aggregation
    ]
    lowered = field.name.lower()
    name = lowered if lowered.startswith((prefix, aggregation)) else f"{prefix}_{lowered}"
    return SemanticMetric(
        name=name,
        expression=f"{aggregation.upper()}({field.name})",
        aggregation=aggregation,
        description=(
            f"{prefix.capitalize()} of {field.name}"
            + (f": {field.description}" if field.description else "")
        ),
        source=MetricSource.INFERRED,
        fields=[field.name],
    )


def infer_joins(assets: Iterable[SemanticAsset]) -> dict[str, list[SemanticRelationship]]:
    """Name-based join candidates between assets of one scope, keyed by source fqn.

    Rules, strongest first:
    * a column that *is* the primary key of exactly one other asset (0.85);
    * ``<base>_id|_key|_sk`` pointing at a dimension named ``dim_<base>`` / ``<base>`` (0.75);
    * the same identifier column name on a dimension or reference asset (0.6).
    Declared keys already present on the asset are never duplicated.
    """
    assets = list(assets)
    by_fqn = {a.fqn: a for a in assets}
    pk_index: dict[str, list[SemanticAsset]] = defaultdict(list)
    ident_index: dict[str, list[SemanticAsset]] = defaultdict(list)
    base_index: dict[str, list[SemanticAsset]] = defaultdict(list)
    for asset in assets:
        for column in asset.primary_key:
            pk_index[column.casefold()].append(asset)
        for field in asset.fields:
            if field.role is FieldRole.IDENTIFIER:
                ident_index[field.name.casefold()].append(asset)
        base_index[_base_name(asset.name)].append(asset)

    found: dict[str, list[SemanticRelationship]] = defaultdict(list)
    for asset in assets:
        declared = {
            (r.target_fqn, tuple(c.casefold() for c in r.source_columns))
            for r in asset.relationships
            if r.kind in (RelationshipKind.FOREIGN_KEY, RelationshipKind.JOIN_DECLARED)
        }
        own_pk = {c.casefold() for c in asset.primary_key}
        for field in asset.fields:
            column = field.name.casefold()
            if field.role is not FieldRole.IDENTIFIER or column in own_pk:
                continue
            candidate: tuple[SemanticAsset, float, str] | None = None
            owners = [a for a in pk_index.get(column, []) if a.fqn != asset.fqn]
            if len(owners) == 1:
                candidate = (
                    owners[0],
                    0.85,
                    f"{field.name} is the primary key of {owners[0].name}",
                )
            if candidate is None:
                stem = re.sub(r"_(id|key|sk|pk|fk|code|cd)$", "", column)
                dims = [
                    a
                    for a in base_index.get(stem, [])
                    if a.fqn != asset.fqn
                    and a.kind in (AssetKind.DIMENSION, AssetKind.REFERENCE, AssetKind.UNKNOWN)
                    and a.field(field.name) is not None
                ]
                if len(dims) == 1:
                    candidate = (dims[0], 0.75, f"{field.name} matches dimension {dims[0].name}")
            if candidate is None:
                same = [
                    a
                    for a in ident_index.get(column, [])
                    if a.fqn != asset.fqn and a.kind in (AssetKind.DIMENSION, AssetKind.REFERENCE)
                ]
                if len(same) == 1:
                    candidate = (
                        same[0],
                        0.6,
                        f"{field.name} also identifies rows of {same[0].name}",
                    )
            if candidate is None:
                continue
            target, confidence, evidence = candidate
            if (target.fqn, (column,)) in declared or target.fqn not in by_fqn:
                continue
            target_field = target.field(field.name)
            found[asset.fqn].append(
                SemanticRelationship(
                    target_fqn=target.fqn,
                    kind=RelationshipKind.JOIN_INFERRED,
                    source_columns=[field.name],
                    target_columns=[target_field.name if target_field else field.name],
                    confidence=confidence,
                    evidence=evidence,
                )
            )
    return dict(found)


def _base_name(table_name: str) -> str:
    stem = re.sub(
        r"^(dim|dimension|d|fct|fact|f|ref|lkp|bridge|brg|mv|agg)_", "", table_name.casefold()
    )
    stem = re.sub(r"_(dim|fact|v\d+|current|hist|history|snapshot)$", "", stem)
    return stem


def referenced_fqns(sql: str) -> list[str]:
    """Three-part names mentioned in a SQL definition (used when lineage APIs are silent)."""
    seen: list[str] = []
    for match in THREE_PART_NAME.finditer(sql or ""):
        parts = [p.strip('`"') for p in match.groups()]
        fqn = ".".join(parts)
        if fqn not in seen:
            seen.append(fqn)
    return seen
