"""Export the semantic layer in the formats the platforms consume.

* ``cortex`` - a Snowflake Cortex Analyst semantic model (YAML): tables with
  dimensions / time dimensions / facts / metrics and relationships;
* ``databricks_metric_view`` - one Unity Catalog metric view spec (YAML) per fact
  asset: ``source``, ``joins`` to its dimensions, ``dimensions`` and ``measures``;
* ``hub`` - the hub's own JSON (the :class:`SemanticAsset` models verbatim).

Only what the metadata supports is emitted; inferred items are marked in descriptions
so a reviewer can promote or drop them before publishing the model.
"""

from __future__ import annotations

import json
import re
from typing import Any

from ech_core.semantic.inference import type_family
from ech_core.semantic.models import (
    AssetKind,
    FieldRole,
    MetricSource,
    RelationshipKind,
    SemanticAsset,
)

FORMATS = ("cortex", "databricks_metric_view", "hub")
_JOIN_KINDS = (
    RelationshipKind.FOREIGN_KEY,
    RelationshipKind.JOIN_DECLARED,
    RelationshipKind.JOIN_INFERRED,
)


def dump_yaml(data: Any) -> str:
    import yaml  # provided by uvicorn[standard]; imported lazily to keep ech_core light

    return yaml.safe_dump(data, sort_keys=False, allow_unicode=True, width=100)


def _cortex_type(data_type: str) -> str:
    family = type_family(data_type)
    base = (data_type or "").upper()
    if family == "time":
        return "DATE" if base.startswith("DATE") and "TIME" not in base else "TIMESTAMP_NTZ"
    if family == "numeric":
        return "NUMBER"
    if base.startswith("BOOL"):
        return "BOOLEAN"
    return "TEXT"


def _identifier(name: str) -> str:
    return re.sub(r"\W+", "_", name.strip()).strip("_").lower() or "unnamed"


def _metric_expression(m: Any) -> str | None:
    if m.expression:
        return m.expression
    if m.fields:
        return f"{(m.aggregation or 'sum').upper()}({m.fields[0]})"
    return None


def cortex_semantic_model(assets: list[SemanticAsset], *, name: str, description: str = "") -> str:
    """Snowflake Cortex Analyst semantic model for the given assets."""
    by_fqn = {a.fqn: a for a in assets}
    tables: list[dict[str, Any]] = []
    relationships: list[dict[str, Any]] = []
    for asset in assets:
        table: dict[str, Any] = {
            "name": _identifier(asset.name),
            "description": asset.description or f"{asset.kind.value} {asset.fqn}",
            "base_table": {
                "database": asset.database,
                "schema": asset.schema_name,
                "table": asset.name,
            },
        }
        if asset.primary_key:
            table["primary_key"] = {"columns": asset.primary_key}
        dimensions, time_dimensions, facts = [], [], []
        for f in asset.fields:
            entry: dict[str, Any] = {
                "name": _identifier(f.name),
                "expr": f.name,
                "data_type": _cortex_type(f.data_type),
            }
            if f.description:
                entry["description"] = f.description
            if f.synonyms:
                entry["synonyms"] = f.synonyms
            if f.role is FieldRole.TIME:
                time_dimensions.append(entry)
            elif f.role is FieldRole.MEASURE:
                facts.append(entry)
            elif f.role in (FieldRole.DIMENSION, FieldRole.IDENTIFIER):
                if f.role is FieldRole.IDENTIFIER:
                    entry["unique"] = f.is_primary_key
                dimensions.append(entry)
        if dimensions:
            table["dimensions"] = dimensions
        if time_dimensions:
            table["time_dimensions"] = time_dimensions
        if facts:
            table["facts"] = facts
        metrics = []
        for m in asset.metrics:
            expr = _metric_expression(m)
            if expr:
                metrics.append(
                    {
                        "name": _identifier(m.name),
                        "expr": expr,
                        "description": m.description
                        + (" [inferred]" if m.source is MetricSource.INFERRED else ""),
                    }
                )
        if metrics:
            table["metrics"] = metrics
        tables.append(table)

        for r in asset.relationships:
            target = by_fqn.get(r.target_fqn)
            if target is None or not r.source_columns or r.kind not in _JOIN_KINDS:
                continue
            relationships.append(
                {
                    "name": f"{_identifier(asset.name)}_to_{_identifier(target.name)}",
                    "left_table": _identifier(asset.name),
                    "right_table": _identifier(target.name),
                    "relationship_columns": [
                        {"left_column": s, "right_column": t}
                        for s, t in zip(
                            r.source_columns, r.target_columns or r.source_columns, strict=False
                        )
                    ],
                    "join_type": "left_outer",
                    "relationship_type": "many_to_one",
                }
            )
    model: dict[str, Any] = {
        "name": _identifier(name),
        "description": description or name,
        "tables": tables,
    }
    if relationships:
        model["relationships"] = relationships
    return dump_yaml(model)


def databricks_metric_view(asset: SemanticAsset, dimensions_from: list[SemanticAsset]) -> str:
    """A Unity Catalog metric view spec over one fact asset and the dimensions it joins."""
    by_fqn = {a.fqn: a for a in dimensions_from}
    joins: list[dict[str, Any]] = []
    for r in asset.relationships:
        target = by_fqn.get(r.target_fqn)
        if target is None or not r.source_columns or r.kind not in _JOIN_KINDS:
            continue
        alias = _identifier(target.name)
        on = " AND ".join(
            f"source.{s} = {alias}.{t}"
            for s, t in zip(r.source_columns, r.target_columns or r.source_columns, strict=False)
        )
        joins.append({"name": alias, "source": target.fqn, "on": on})
    dimensions: list[dict[str, Any]] = [
        {"name": _identifier(f.name), "expr": f.name}
        for f in asset.fields
        if f.role in (FieldRole.DIMENSION, FieldRole.TIME)
    ]
    for join in joins:
        target = by_fqn[join["source"]]
        for f in target.fields_with_role(FieldRole.DIMENSION)[:10]:
            dimensions.append(
                {
                    "name": f"{join['name']}_{_identifier(f.name)}",
                    "expr": f"{join['name']}.{f.name}",
                }
            )
    measures: list[dict[str, Any]] = []
    for m in asset.metrics:
        expr = _metric_expression(m)
        if not expr:
            continue
        entry: dict[str, Any] = {"name": _identifier(m.name), "expr": expr}
        if m.description:
            entry["comment"] = m.description + (
                " [inferred]" if m.source is MetricSource.INFERRED else ""
            )
        measures.append(entry)
    spec: dict[str, Any] = {"version": 0.1, "source": asset.fqn}
    if asset.description:
        spec["comment"] = asset.description
    if joins:
        spec["joins"] = joins
    spec["dimensions"] = dimensions
    spec["measures"] = measures
    return dump_yaml(spec)


def hub_json(assets: list[SemanticAsset]) -> str:
    return json.dumps([a.model_dump(mode="json") for a in assets], indent=2, default=str)


def export(assets: list[SemanticAsset], *, fmt: str, name: str) -> tuple[str, str]:
    """Return ``(content, media_type)`` for one of :data:`FORMATS`."""
    if fmt == "cortex":
        return cortex_semantic_model(assets, name=name), "application/yaml"
    if fmt == "databricks_metric_view":
        facts = [
            a
            for a in assets
            if a.kind in (AssetKind.FACT, AssetKind.UNKNOWN, AssetKind.METRIC) and a.metrics
        ]
        parts = [
            f"# metric view for {a.fqn}\n{databricks_metric_view(a, assets)}"
            for a in (facts or assets)
        ]
        return "\n---\n".join(parts), "application/yaml"
    if fmt == "hub":
        return hub_json(assets), "application/json"
    raise ValueError(f"unknown export format {fmt!r}; choose from {', '.join(FORMATS)}")
