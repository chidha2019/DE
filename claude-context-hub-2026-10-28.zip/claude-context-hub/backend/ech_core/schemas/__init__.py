"""Public API schemas (Pydantic v2). Mirrored by ``frontend/src/api/types.ts``."""
