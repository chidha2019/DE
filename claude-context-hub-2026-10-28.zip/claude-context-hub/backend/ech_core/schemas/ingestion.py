"""Ingestion pipeline API schemas (connectors, runs, events)."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import Field, field_validator

from ech_core.domain.enums import RunStatus, SourceSystem
from ech_core.domain.models import IngestionRunRecord, RunEventRecord
from ech_core.schemas.common import APIModel


class ConnectorInfo(APIModel):
    name: str
    source_system: SourceSystem
    display_name: str
    description: str
    healthy: bool
    details: dict[str, Any] = Field(default_factory=dict)
    estimated_documents: int | None = None
    discoverable: bool = False
    scope_levels: list[str] = Field(default_factory=list)
    option_keys: list[str] = Field(default_factory=list)
    latency_ms: int | None = Field(default=None, description="how long the health check took")


class RunOptions(APIModel):
    full_refresh: bool = Field(
        default=False, description="Re-process documents even if content is unchanged."
    )
    limit: int | None = Field(default=None, ge=1, le=100_000)
    chunk_target_tokens: int | None = Field(default=None, ge=32, le=4096)
    chunk_overlap_tokens: int | None = Field(default=None, ge=0, le=1024)
    simulate_failures: bool = Field(
        default=False, description="Mock connectors inject transient failures (demo/testing)."
    )


class ScopeItem(APIModel):
    """One selected node of the source hierarchy; selecting a node includes everything below it."""

    path: list[str] = Field(min_length=1, max_length=8)
    kind: str = Field(default="", max_length=32, description="database, schema, table, repo, folder ...")

    @field_validator("path")
    @classmethod
    def _clean(cls, value: list[str]) -> list[str]:
        cleaned = [segment.strip() for segment in value]
        if any(not segment for segment in cleaned):
            raise ValueError("scope path segments must not be empty")
        return cleaned


class SourceOptions(APIModel):
    """Connector-specific switches; None keeps the default configured on the server."""

    include_lineage: bool | None = Field(default=None, description="Snowflake and Databricks lineage")
    include_tags: bool | None = Field(default=None, description="Snowflake tag references")
    include_alert_rules: bool | None = Field(default=None, description="Grafana alert rules")
    include_extensions: list[str] | None = Field(default=None, description="GitHub file extensions")
    exclude_globs: list[str] | None = Field(default=None, description="GitHub path patterns to skip")

    @field_validator("include_extensions", "exclude_globs")
    @classmethod
    def _tidy(cls, value: list[str] | None) -> list[str] | None:
        if value is None:
            return None
        return [v.strip() for v in value if v and v.strip()][:60]


class TriggerRunRequest(APIModel):
    connector: str = Field(min_length=1, max_length=64)
    options: RunOptions = Field(default_factory=RunOptions)
    triggered_by: str | None = Field(default=None, max_length=128)
    scope: list[ScopeItem] = Field(default_factory=list, description="selected paths; empty = everything the connection exposes")
    source_options: SourceOptions = Field(default_factory=SourceOptions)
    pipeline_id: UUID | None = Field(default=None, description="the pipeline definition this run belongs to")


class RunStats(APIModel):
    documents_seen: int = 0
    documents_upserted: int = 0
    documents_skipped: int = 0
    documents_failed: int = 0
    chunks_created: int = 0
    embeddings_created: int = 0
    entities_linked: int = 0
    graph_synced: int = 0
    graph_failed: int = 0
    estimated_total: int | None = None


class IngestionRunOut(APIModel):
    id: UUID
    connector_name: str
    source_system: SourceSystem
    status: RunStatus
    config: dict[str, Any] = Field(default_factory=dict)
    stats: RunStats
    pipeline_id: UUID | None = None
    triggered_by: str | None = None
    error: str | None = None
    started_at: datetime | None = None
    finished_at: datetime | None = None
    created_at: datetime
    updated_at: datetime
    progress: float | None = Field(default=None, ge=0, le=1)
    duration_seconds: float | None = None

    @classmethod
    def from_record(cls, record: IngestionRunRecord) -> IngestionRunOut:
        stats = RunStats.model_validate(record.stats or {})
        progress: float | None = None
        if stats.estimated_total:
            progress = min(1.0, stats.documents_seen / stats.estimated_total)
        elif record.status.is_terminal:
            progress = 1.0
        duration: float | None = None
        if record.started_at:
            end = record.finished_at or datetime.now(tz=record.started_at.tzinfo)
            duration = round((end - record.started_at).total_seconds(), 3)
        return cls(
            id=record.id,
            connector_name=record.connector_name,
            source_system=record.source_system,
            status=record.status,
            config=record.config,
            stats=stats,
            pipeline_id=record.pipeline_id,
            triggered_by=record.triggered_by,
            error=record.error,
            started_at=record.started_at,
            finished_at=record.finished_at,
            created_at=record.created_at,
            updated_at=record.updated_at,
            progress=progress,
            duration_seconds=duration,
        )


class RunEventOut(APIModel):
    id: int | None = None
    run_id: UUID
    level: str
    event_type: str
    message: str
    payload: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime

    @classmethod
    def from_record(cls, record: RunEventRecord) -> RunEventOut:
        return cls.model_validate(record.model_dump())


class ReconcileResult(APIModel):
    scanned: int
    synced: int
    failed: int
    orphan_entities_removed: int = 0
