"""Document and chunk API schemas."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import Field

from ech_core.domain.enums import DocumentKind, GraphSyncStatus, SourceSystem
from ech_core.domain.models import ChunkRecord, DocumentRecord
from ech_core.schemas.common import APIModel


class DocumentSummary(APIModel):
    id: UUID
    source_system: SourceSystem
    kind: DocumentKind = DocumentKind.DOCUMENT
    external_id: str
    title: str
    uri: str | None = None
    author: str | None = None
    mime_type: str
    language: str
    version: int
    content_length: int
    attributes: dict[str, Any] = Field(default_factory=dict)
    graph_sync_status: GraphSyncStatus
    graph_synced_at: datetime | None = None
    source_updated_at: datetime | None = None
    ingested_at: datetime
    updated_at: datetime
    chunk_count: int | None = None
    embedding_count: int | None = None

    @classmethod
    def from_record(cls, record: DocumentRecord) -> DocumentSummary:
        return cls.model_validate(record.model_dump())


class DocumentDetail(DocumentSummary):
    content_hash: str
    graph_node_id: str | None = None
    graph_sync_error: str | None = None
    last_run_id: UUID | None = None
    source_created_at: datetime | None = None

    @classmethod
    def from_record(cls, record: DocumentRecord) -> DocumentDetail:
        return cls.model_validate(record.model_dump())


class ChunkOut(APIModel):
    id: UUID
    document_id: UUID
    chunk_index: int
    content: str
    token_count: int
    char_start: int
    char_end: int
    section_path: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime | None = None

    @classmethod
    def from_record(cls, record: ChunkRecord) -> ChunkOut:
        return cls.model_validate(record.model_dump())


class ManualDocumentIn(APIModel):
    """Body for ad-hoc ingestion through the API (source_system = manual)."""

    title: str = Field(min_length=1, max_length=512)
    content: str = Field(min_length=1, max_length=2_000_000)
    external_id: str | None = Field(
        default=None,
        max_length=512,
        description="Stable identifier; defaults to a slug of the title.",
    )
    uri: str | None = None
    author: str | None = None
    attributes: dict[str, Any] = Field(default_factory=dict)
    contributors: list[str] = Field(default_factory=list)
    references: list[str] = Field(
        default_factory=list, description="external_ids of referenced manual documents"
    )


class DocumentIngestResult(APIModel):
    document_id: UUID
    changed: bool
    chunks: int
    embeddings: int
    entities: int
    graph_sync_status: GraphSyncStatus
