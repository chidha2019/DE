"""The Semantic Catalog: business objects projected from the semantic layer and grouped by domain.

The Data Catalog (``/semantic/assets``) lists what the platforms hold: tables, views and their
columns. The Semantic Catalog reads the same rows as business objects: an entity per dataset, a
dimension or measure per role-bearing column, a metric per declared, curated or inferred metric
and per KPI, a relationship per key, join or lineage edge, and the hierarchies inferred from
column patterns. Every object is placed in a glossary domain through its own accepted term link,
its dataset's domain or the plurality of its columns' terms, and carries a quality score from the
checks that apply to its type.
"""

from __future__ import annotations

from datetime import datetime
from typing import Literal
from uuid import UUID

from pydantic import Field

from ech_core.schemas.common import APIModel

ObjectType = Literal["entity", "dimension", "measure", "metric", "relationship", "hierarchy"]
OBJECT_TYPES: tuple[ObjectType, ...] = (
    "entity",
    "dimension",
    "measure",
    "metric",
    "relationship",
    "hierarchy",
)
DomainSource = Literal["dataset", "term", "columns", "kpi", "none"]
CatalogSort = Literal["type", "name", "domain", "model", "owner", "quality", "updated"]
UNASSIGNED_KEY = "__unassigned__"
UNASSIGNED_NAME = "Unassigned"
SHARED_LINE = "__shared__"
SHARED_LINE_NAME = "Shared across lines"


class CatalogCounts(APIModel):
    entities: int = 0
    dimensions: int = 0
    measures: int = 0
    metrics: int = 0
    relationships: int = 0
    hierarchies: int = 0
    total: int = 0


class CatalogDomain(APIModel):
    key: str
    name: str
    parent_key: str | None = None
    description: str = ""
    standard: str = "hub"
    sort_order: int = 0
    counts: CatalogCounts = Field(default_factory=CatalogCounts)
    quality: int | None = Field(
        default=None, description="mean quality of the objects placed here, sub-domains included, 0-100"
    )


class CatalogDomainNode(CatalogDomain):
    children: list[CatalogDomain] = Field(default_factory=list)


class QualityCheck(APIModel):
    name: str
    ok: bool


class CatalogObject(APIModel):
    id: str = Field(description="'<type>:<id>', stable across requests")
    type: ObjectType
    subtype: str = ""
    name: str
    technical_name: str
    description: str = ""
    domain_key: str | None = None
    domain_name: str | None = None
    domain_source: DomainSource = "none"
    model: str = Field(description="the subject area the object belongs to: database.schema")
    model_label: str
    platform: str
    asset_id: UUID | None = None
    asset_name: str | None = None
    owner: str | None = None
    quality: int = Field(ge=0, le=100)
    checks: list[QualityCheck] = Field(default_factory=list)
    term: str | None = Field(default=None, description="the accepted glossary term, when one is linked")
    lines: list[str] = Field(default_factory=list, description="line-of-business keys of the dataset; empty when shared across lines")
    lines_note: str = Field(default="", description="how the sync knows: a tag, a pipeline default, column values or inheritance")
    detail: str = Field(default="", description="type-specific: data type, expression, join columns, levels")
    updated_at: datetime | None = None


class CatalogSource(APIModel):
    """A model (database.schema) with the objects read from it: the group-by-source tree."""

    model: str
    model_label: str
    platform: str
    database: str = Field(description="empty for glossary KPIs bound to no dataset")
    schema_name: str = ""
    counts: CatalogCounts = Field(default_factory=CatalogCounts)
    quality: int | None = None


class CatalogDomainModel(APIModel):
    """Objects placed directly in one domain (sub-domains not rolled up) that come from one model."""

    domain_key: str = Field(description=f"'{UNASSIGNED_KEY}' for objects no domain holds")
    model: str
    counts: CatalogCounts = Field(default_factory=CatalogCounts)
    quality: int | None = None


class CatalogLineDomain(APIModel):
    domain_key: str = Field(description=f"a top-level domain, or '{UNASSIGNED_KEY}'")
    counts: CatalogCounts = Field(default_factory=CatalogCounts)


class CatalogLine(APIModel):
    """A line of business with the objects it holds, per top-level domain: the tree grouped by line."""

    key: str = Field(description=f"a value of the Line of Business term, or '{SHARED_LINE}'")
    name: str
    description: str = ""
    counts: CatalogCounts = Field(default_factory=CatalogCounts)
    quality: int | None = None
    domains: list[CatalogLineDomain] = Field(default_factory=list)


class SemanticCatalog(APIModel):
    domains: list[CatalogDomainNode]
    counts: CatalogCounts
    placed: int = Field(description="objects that have a business domain")
    entities_placed: int
    quality: int | None = Field(default=None, description="mean quality across every object, 0-100")
    models: list[str]
    sources: list[CatalogSource] = Field(default_factory=list)
    domain_models: list[CatalogDomainModel] = Field(default_factory=list)
    lines: list[CatalogLine] = Field(default_factory=list)
    owners: list[str]
    hierarchy_note: str
    generated_at: datetime
