"""Graph API schemas (Knowledge Hub documents and entities, GraphRAG context)."""

from __future__ import annotations

from typing import Any

from pydantic import Field

from ech_core.schemas.common import APIModel


class GraphNode(APIModel):
    id: str = Field(description="document_id, chunk_id or entity_key")
    label: str = Field(description="Human-readable label")
    type: str = Field(description="Document | Chunk | Person | Project | Technology | Concept")
    properties: dict[str, Any] = Field(default_factory=dict)
    degree: int | None = None


class GraphEdge(APIModel):
    source: str
    target: str
    type: str
    properties: dict[str, Any] = Field(default_factory=dict)


class GraphPayload(APIModel):
    nodes: list[GraphNode] = Field(default_factory=list)
    edges: list[GraphEdge] = Field(default_factory=list)
    center_id: str | None = None
    chunk_entities: dict[str, list[str]] | None = Field(
        default=None, description="chunk_id -> entity keys mentioned (explorer highlighting)"
    )


class EntitySearchHit(APIModel):
    key: str
    name: str
    entity_type: str
    score: float | None = None
    mention_count: int | None = None


class EntityListItem(APIModel):
    key: str
    name: str
    entity_type: str
    mention_count: int
    document_count: int


class GraphStats(APIModel):
    nodes_total: int
    edges_total: int
    nodes_by_label: dict[str, int] = Field(default_factory=dict)
    edges_by_type: dict[str, int] = Field(default_factory=dict)
    density: float = Field(description="edges / nodes (average out-degree)")
