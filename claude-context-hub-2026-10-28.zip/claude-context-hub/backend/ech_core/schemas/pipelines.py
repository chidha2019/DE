"""Pipeline definitions: a saved connection, a scope picked from its schema, options and a schedule.

A pipeline never stores credentials. It names a connector (the connection configured on the server),
lists what to ingest from it as paths in the hierarchy of the source (database, schema, table; repo,
folder; Grafana folder, dashboard) and carries the options and schedule every run starts with.
"""

from __future__ import annotations

import re
from datetime import datetime
from typing import Any, Literal
from uuid import UUID

from pydantic import Field, field_validator, model_validator

from ech_core.domain.enums import RunStatus, SourceSystem
from ech_core.schemas.common import APIModel
from ech_core.schemas.ingestion import RunOptions, ScopeItem, SourceOptions

_TIME = re.compile(r"^([01][0-9]|2[0-3]):[0-5][0-9]$")
MAX_SCOPE_ITEMS = 500

ScheduleType = Literal["manual", "interval", "daily", "weekly"]


class Schedule(APIModel):
    """When a pipeline runs by itself. Times are UTC."""

    type: ScheduleType = "manual"
    every_minutes: int | None = Field(default=None, ge=5, le=10_080)
    time: str | None = Field(default=None, description="HH:MM, UTC")
    days: list[int] = Field(default_factory=list, description="0 = Monday ... 6 = Sunday")

    @model_validator(mode="after")
    def _complete(self) -> Schedule:
        if self.type == "interval" and not self.every_minutes:
            raise ValueError("an interval schedule needs every_minutes (5 to 10080)")
        if self.type in ("daily", "weekly") and not (self.time and _TIME.match(self.time)):
            raise ValueError(f"a {self.type} schedule needs time as HH:MM (UTC)")
        if self.type == "weekly":
            days = sorted(set(self.days))
            if not days or any(d < 0 or d > 6 for d in days):
                raise ValueError("a weekly schedule needs days between 0 (Monday) and 6 (Sunday)")
            self.days = days
        return self


class PipelineIn(APIModel):
    name: str = Field(min_length=2, max_length=80)
    description: str = Field(default="", max_length=1000)
    connector: str = Field(min_length=1, max_length=64)
    scope: list[ScopeItem] = Field(default_factory=list, max_length=MAX_SCOPE_ITEMS)
    options: RunOptions = Field(default_factory=RunOptions)
    source_options: SourceOptions = Field(default_factory=SourceOptions)
    schedule: Schedule = Field(default_factory=Schedule)
    enabled: bool = True
    owner: str = Field(default="", max_length=120)
    tags: list[str] = Field(default_factory=list, max_length=12)
    line_of_business: str | None = Field(
        default=None, max_length=64, description="default line of business for what this pipeline syncs when no tag says otherwise"
    )
    run_now: bool = Field(default=False, description="Start a run right after creating the pipeline")

    @field_validator("name")
    @classmethod
    def _name(cls, value: str) -> str:
        value = " ".join(value.split())
        if len(value) < 2:
            raise ValueError("name must have at least two characters")
        return value

    @field_validator("tags")
    @classmethod
    def _tags(cls, value: list[str]) -> list[str]:
        return list(dict.fromkeys(t.strip().lower() for t in value if t and t.strip()))[:12]


class PipelineUpdate(APIModel):
    """Every field optional: what is sent changes, the rest stays. The connector cannot change."""

    name: str | None = Field(default=None, min_length=2, max_length=80)
    description: str | None = Field(default=None, max_length=1000)
    scope: list[ScopeItem] | None = Field(default=None, max_length=MAX_SCOPE_ITEMS)
    options: RunOptions | None = None
    source_options: SourceOptions | None = None
    schedule: Schedule | None = None
    enabled: bool | None = None
    owner: str | None = Field(default=None, max_length=120)
    tags: list[str] | None = Field(default=None, max_length=12)
    line_of_business: str | None = Field(default=None, max_length=64, description="an empty string clears the default")


class ScheduleToggle(APIModel):
    enabled: bool


class PipelineRunSummary(APIModel):
    id: UUID
    status: RunStatus
    triggered_by: str | None = None
    started_at: datetime | None = None
    finished_at: datetime | None = None
    created_at: datetime
    documents_seen: int = 0
    documents_upserted: int = 0
    documents_skipped: int = 0
    documents_failed: int = 0
    estimated_total: int | None = None
    progress: float | None = Field(default=None, ge=0, le=1)
    duration_seconds: float | None = None
    error: str | None = None


class PipelineOut(APIModel):
    id: UUID
    name: str
    description: str = ""
    connector: str
    source_system: SourceSystem
    connector_label: str = ""
    scope: list[ScopeItem] = Field(default_factory=list)
    options: RunOptions = Field(default_factory=RunOptions)
    source_options: SourceOptions = Field(default_factory=SourceOptions)
    schedule: Schedule = Field(default_factory=Schedule)
    schedule_label: str = "Manual"
    enabled: bool = True
    owner: str = ""
    tags: list[str] = Field(default_factory=list)
    line_of_business: str | None = None
    next_run_at: datetime | None = None
    created_by: str | None = None
    created_at: datetime
    updated_at: datetime
    last_run: PipelineRunSummary | None = None
    runs_total: int = 0
    runs_failed: int = 0
    connection_available: bool = Field(default=True, description="the connector is still registered")


class DiscoveryNode(APIModel):
    """One child of a node in the source hierarchy, as shown in the schema browser."""

    name: str
    label: str | None = None
    path: list[str]
    kind: str
    selectable: bool = True
    expandable: bool = False
    description: str = ""
    detail: str = Field(default="", description="data type for a column, table type and rows for a table")
    child_count: int | None = None
    row_count: int | None = None


class DiscoveryResult(APIModel):
    connector: str
    path: list[str]
    nodes: list[DiscoveryNode]
    truncated: bool = False
    note: str | None = None


class PreviewRequest(APIModel):
    connector: str = Field(min_length=1, max_length=64)
    scope: list[ScopeItem] = Field(default_factory=list, max_length=MAX_SCOPE_ITEMS)
    options: RunOptions = Field(default_factory=RunOptions)
    source_options: SourceOptions = Field(default_factory=SourceOptions)


class PreviewResult(APIModel):
    connector: str
    scope_items: int
    estimated_documents: int | None = None
    whole_connection: bool = False
    note: str | None = None


def scope_dump(scope: list[ScopeItem]) -> list[dict[str, Any]]:
    return [item.model_dump() for item in scope]
