"""An entity-relationship diagram of a modelled layer: its tables, their keys, and how they reference each other."""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from ech_core.schemas.common import APIModel

EntityKind = Literal["dimension", "fact", "bridge", "reference", "aggregate", "table", "external"]


class ErColumn(APIModel):
    name: str
    type: str = ""
    pk: bool = False
    fk: str | None = Field(default=None, description="the TABLE.COLUMN it references")
    nullable: bool = True
    description: str = ""


class ErEntity(APIModel):
    name: str
    schema_name: str = ""
    kind: EntityKind
    description: str = ""
    grain: str = ""
    concept: str = Field(default="", description="the ontology concept the design names, e.g. ACORD Party")
    columns: list[ErColumn] = Field(default_factory=list)
    rows: int | None = Field(default=None, description="rows the read-only dry run returned, for a plan")
    findings: list[str] = Field(default_factory=list)


class ErRelationship(APIModel):
    """One foreign key: the referencing table's columns to the referenced table's."""

    from_table: str
    from_columns: list[str]
    to_table: str
    to_columns: list[str] = Field(default_factory=list)
    cardinality: Literal["many_to_one", "one_to_one"] = "many_to_one"
    required: bool = Field(default=False, description="every referencing column is NOT NULL")


class ErDiagram(APIModel):
    key: str = Field(description="design:<folder> or intent:<id>")
    title: str
    source: Literal["design", "plan"]
    origin: str = Field(description="the folder the documents are in, or the ticket")
    files: list[str] = Field(default_factory=list)
    entities: list[ErEntity] = Field(default_factory=list)
    relationships: list[ErRelationship] = Field(default_factory=list)
    problems: list[str] = Field(default_factory=list)
    mermaid: str = Field(default="", description="the same diagram as Mermaid erDiagram text")
