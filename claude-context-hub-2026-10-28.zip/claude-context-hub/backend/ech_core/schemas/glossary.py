"""Business glossary, domain taxonomy, term links and KPIs (migration 0011)."""

from __future__ import annotations

from datetime import datetime
from typing import Literal
from uuid import UUID

from pydantic import Field

from ech_core.schemas.common import APIModel

Standard = Literal["acord", "fibo", "hub"]
TermKind = Literal["entity", "attribute", "measure", "event", "code"]
TargetType = Literal["asset", "field", "metric"]
LinkStatus = Literal["suggested", "accepted", "rejected"]
LinkSource = Literal["rule", "model", "curated"]
TermStatus = Literal["seeded", "curated", "proposed"]


class Domain(APIModel):
    key: str
    name: str
    parent_key: str | None = None
    description: str = ""
    standard: Standard = "hub"
    standard_ref: str = ""
    sort_order: int = 0
    term_count: int = 0
    asset_count: int = Field(default=0, description="datasets whose domain is this one")
    kpi_count: int = 0


class DomainNode(Domain):
    children: list[Domain] = Field(default_factory=list)


class TermRow(APIModel):
    id: UUID
    key: str
    name: str
    definition: str = ""
    domain_key: str | None = None
    domain_name: str | None = None
    kind: TermKind = "entity"
    synonyms: list[str] = Field(default_factory=list)
    standard: Standard = "hub"
    standard_ref: str = ""
    status: TermStatus = "seeded"
    proposed_by: str | None = Field(default=None, description="the model that proposed a 'proposed' term")
    rationale: str = Field(default="", description="why a proposed term was proposed")
    linked_assets: int = 0
    linked_fields: int = 0
    linked_metrics: int = 0
    suggested: int = Field(default=0, description="links awaiting review")
    updated_at: datetime


class TermCreate(APIModel):
    name: str = Field(min_length=1, max_length=120)
    definition: str = Field(default="", max_length=2000)
    domain_key: str | None = None
    kind: TermKind = "entity"
    synonyms: list[str] = Field(default_factory=list)


class TermUpdate(APIModel):
    name: str | None = Field(default=None, min_length=1, max_length=120)
    definition: str | None = Field(default=None, max_length=2000)
    domain_key: str | None = None
    kind: TermKind | None = None
    synonyms: list[str] | None = None


class TermLink(APIModel):
    id: UUID
    term_id: UUID
    term_key: str
    term_name: str
    domain_key: str | None = None
    target_type: TargetType
    target_id: UUID
    target_label: str | None = Field(default=None, description="dataset name, column name or metric name")
    target_context: str | None = Field(default=None, description="the dataset the column or metric belongs to")
    asset_id: UUID | None = Field(default=None, description="the dataset to open for this target")
    confidence: float = 0.0
    source: LinkSource
    status: LinkStatus
    rationale: str = ""
    model: str | None = None
    created_at: datetime
    decided_at: datetime | None = None


class TermDetail(TermRow):
    links: list[TermLink] = Field(default_factory=list)


class LinkDecision(APIModel):
    decision: Literal["accept", "reject"]


class TermLinkGroup(APIModel):
    """One proposal repeated across tables: the same term for the same column, metric or dataset name."""

    key: str = Field(description="term id, target type and lower-cased target name")
    term_id: UUID
    term_key: str
    term_name: str
    domain_key: str | None = None
    target_type: TargetType
    target_label: str
    count: int = Field(description="how many links the group holds, usually one per table")
    min_confidence: float = 0.0
    max_confidence: float = 0.0
    sources: list[LinkSource] = Field(default_factory=list)
    links: list[TermLink] = Field(default_factory=list)


class LinksDecision(APIModel):
    ids: list[UUID] = Field(min_length=1, max_length=500)
    decision: Literal["accept", "reject"]


class LinksDecisionResult(APIModel):
    decision: Literal["accept", "reject"]
    decided: int = 0
    missing: int = Field(default=0, description="ids that matched no link")


class TermDecision(APIModel):
    decision: Literal["accept", "reject"]
    accept_links: bool = Field(default=False, description="on accept, also accept the term's pending links")


class TermDecisionResult(APIModel):
    id: UUID
    decision: Literal["accept", "reject"]
    links_accepted: int = 0


class LinkCreate(APIModel):
    term_id: UUID
    target_type: TargetType
    target_id: UUID


class Kpi(APIModel):
    id: UUID
    key: str
    name: str
    domain_key: str | None = None
    domain_name: str | None = None
    term_id: UUID | None = None
    term_name: str | None = None
    metric_id: UUID | None = None
    metric_name: str | None = None
    metric_asset_id: UUID | None = None
    metric_asset_fqn: str | None = None
    definition: str = ""
    formula: str = ""
    grain: str = ""
    period: str = "monthly"
    unit: str = "ratio"
    direction: Literal["higher", "lower"] = "higher"
    target_value: float | None = None
    warn_value: float | None = None
    owner: str = ""
    standard_ref: str = ""
    status: Literal["seeded", "curated"] = "seeded"
    updated_at: datetime


class KpiUpdate(APIModel):
    metric_id: UUID | None = None
    clear_metric: bool = False
    target_value: float | None = None
    warn_value: float | None = None
    owner: str | None = Field(default=None, max_length=120)
    definition: str | None = Field(default=None, max_length=2000)
    formula: str | None = Field(default=None, max_length=500)
    grain: str | None = Field(default=None, max_length=60)
    period: str | None = Field(default=None, max_length=30)
    unit: str | None = Field(default=None, max_length=30)
    direction: Literal["higher", "lower"] | None = None


class MapRequest(APIModel):
    source_system: str | None = None
    database: str | None = Field(default=None, max_length=255)
    schema_name: str | None = Field(default=None, max_length=255, alias="schema")
    asset_ids: list[UUID] | None = None
    use_model: bool = Field(default=True, description="ask Claude after the name rules")
    limit: int = Field(default=200, ge=1, le=2000)


class ProposeTermsRequest(APIModel):
    source_system: str | None = None
    database: str | None = Field(default=None, max_length=255)
    schema_name: str | None = Field(default=None, max_length=255, alias="schema")
    asset_ids: list[UUID] | None = None
    limit: int = Field(default=200, ge=1, le=2000, description="datasets in scope")
    batch_size: int = Field(default=24, ge=5, le=120, description="unmapped columns and metrics per Claude call; a failing batch is halved and retried")


class MapRun(APIModel):
    id: UUID
    mode: Literal["map", "propose"] = Field(default="map", description="map: terms to targets; propose: new terms from unmapped targets")
    trigger: Literal["manual", "sync"] = Field(default="manual", description="sync: started by a successful Snowflake or Databricks sync")
    status: Literal["running", "completed", "failed", "cancelled"]
    total: int = Field(default=0, description="datasets (map) or batches (propose) handed to Claude")
    done: int = 0
    failed: int = 0
    rule_links: int = Field(default=0, description="suggestions from name rules")
    model_links: int = Field(default=0, description="suggestions from Claude")
    terms_proposed: int = Field(default=0, description="new candidate terms Claude proposed")
    skipped: int = Field(default=0, description="datasets not sent to Claude because nothing changed since it last mapped them")
    message: str | None = None
    started_at: datetime
    finished_at: datetime | None = None
    error: str | None = None
    current: str | None = None


class GlossaryCoverage(APIModel):
    model_available: bool = Field(default=False, description="Claude is configured, so a mapping run goes beyond name rules")
    terms_total: int = Field(default=0, description="seeded and curated terms")
    terms_proposed: int = Field(default=0, description="candidate terms waiting for review")
    terms_linked: int = Field(default=0, description="terms with at least one accepted link")
    domains_total: int = 0
    assets_total: int = 0
    assets_with_domain: int = 0
    assets_with_terms: int = 0
    fields_total: int = 0
    fields_with_terms: int = 0
    fields_with_synonyms: int = 0
    metrics_total: int = 0
    metrics_with_terms: int = 0
    kpis_total: int = 0
    kpis_with_metric: int = 0
    kpis_with_target: int = 0
    links_suggested: int = 0
    links_accepted: int = 0
    links_rejected: int = 0


class AutoMapRun(APIModel):
    """One automatic mapping pass after a sync: name rules on every dataset, Claude on new or changed ones."""

    id: UUID
    source_system: str
    ingestion_run_ids: list[UUID] = Field(default_factory=list, description="the syncs this pass covers")
    status: Literal["running", "completed", "failed"]
    datasets: int = Field(default=0, description="datasets the name rules looked at")
    model_datasets: int = Field(default=0, description="new or changed datasets sent to Claude")
    unchanged: int = Field(default=0, description="datasets Claude had already mapped as they are")
    model_failed: int = 0
    rule_links: int = 0
    model_links: int = 0
    message: str | None = None
    error: str | None = None
    started_at: datetime
    finished_at: datetime | None = None


class AutoMapStatus(APIModel):
    enabled: bool = Field(description="mapping runs after every successful Snowflake or Databricks sync")
    interval_seconds: int = Field(description="how often finished syncs are picked up")
    model_available: bool = Field(description="Claude is configured; without it only the name rules run")
    runs: list[AutoMapRun] = Field(default_factory=list)
