"""What the SRE workspace shows from Grafana: dashboards and alert rules with their state."""

from __future__ import annotations

from datetime import datetime

from pydantic import Field

from ech_core.schemas.common import APIModel


class GrafanaDashboardSummary(APIModel):
    uid: str
    title: str
    url: str | None = None
    folder: str | None = None
    tags: list[str] = Field(default_factory=list)


class GrafanaAlertRule(APIModel):
    uid: str | None = None
    title: str
    folder: str | None = None
    group: str | None = None
    state: str = Field(description="firing | pending | inactive | unknown")
    health: str | None = None
    severity: str | None = None
    summary: str | None = None
    active_alerts: int = 0
    labels: dict[str, str] = Field(default_factory=dict)
    url: str | None = None


class GrafanaObservability(APIModel):
    configured: bool
    healthy: bool = False
    reason: str | None = Field(default=None, description="why nothing is shown: not configured, or the last error")
    url: str | None = None
    org: str | None = None
    version: str | None = None
    dashboards: list[GrafanaDashboardSummary] = Field(default_factory=list)
    alert_rules: list[GrafanaAlertRule] = Field(default_factory=list)
    rules_total: int = 0
    firing: int = 0
    pending: int = 0
    documents: int = Field(default=0, description="Grafana documents already ingested into the hub")
    hub_dashboard_url: str | None = Field(default=None, description="the hub's own dashboard, once provisioned on the stack")
    generated_at: datetime


class DashboardProvisionResult(APIModel):
    ok: bool
    uid: str | None = None
    url: str | None = None
    version: int | None = None
    reason: str | None = None
