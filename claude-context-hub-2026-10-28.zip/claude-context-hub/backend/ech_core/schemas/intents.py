"""Intents: a request (from Jira or the UI) parsed into structure, planned into a pipeline spec, coded into files."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal
from uuid import UUID

from pydantic import Field

from ech_core.schemas.common import APIModel

IntentStatus = Literal[
    "received", "clarifying", "planning", "waiting", "modeling", "spec_proposed", "approved", "coding", "pr_open", "running", "loaded", "done",
    "rejected", "failed",
]
IntentKind = Literal["ingest_csv_to_iceberg", "model_layer", "gold_fact", "other"]
Layer = Literal["bronze", "silver", "gold"]


# --------------------------------------------------------------------------- structured intent (parser output)
class IntentSource(APIModel):
    folder: str | None = Field(default=None, description="local folder or S3 prefix holding the files")
    file_pattern: str = Field(default="*.csv")
    s3_bucket: str | None = None
    s3_prefix: str | None = None
    storage_provider: Literal["s3", "azure"] = Field(default="s3", description="where the files land before Snowflake reads them")
    azure_account: str | None = Field(default=None, description="Azure storage account the files land in")
    azure_container: str | None = Field(default=None, description="Azure Blob container the files land in")
    azure_prefix: str | None = Field(default=None, description="folder (virtual directory) in the container")
    storage_integration: str | None = Field(default=None, description="the Snowflake storage integration the landing stage reads S3 through")
    stage: str | None = Field(default=None, description="an existing Snowflake stage on the landing folder to load through, as DB.SCHEMA.NAME")
    file_format: str | None = Field(default=None, description="an existing Snowflake file format the ticket names")
    mapping_files: list[str] = Field(
        default_factory=list, description="design files a modelled layer is compiled from: a source-to-target mapping, a data model, DDL"
    )
    delimiter: str = ","
    header: bool = True
    encoding: str = "utf-8"
    database: str | None = Field(default=None, description="model_layer: the database the source tables are in")
    schema_name: str | None = Field(default=None, alias="schema", description="model_layer: the schema (layer) read from")


class IntentTarget(APIModel):
    platform: Literal["snowflake", "databricks"] = "snowflake"
    database: str | None = None
    schema_name: str | None = Field(default=None, alias="schema")
    table: str | None = None
    table_pattern: str | None = Field(default=None, description="how a table set names its tables, e.g. <FILE>_ICEBERG (city.csv -> CITY_ICEBERG)")
    table_format: Literal["iceberg", "native"] = "iceberg"
    external_volume: str | None = Field(default=None, description="Snowflake external volume on S3")
    base_location: str | None = Field(default=None, description="folder under the external volume")
    load_mode: Literal["append", "full_refresh", "merge"] = "append"
    merge_keys: list[str] = Field(default_factory=list)


class StructuredIntent(APIModel):
    kind: IntentKind = "other"
    summary: str = ""
    source: IntentSource = Field(default_factory=IntentSource)
    target: IntentTarget = Field(default_factory=IntentTarget)
    grain: str = Field(default="", description="what one row of the target is")
    business_terms: list[str] = Field(default_factory=list)
    columns_hint: list[str] = Field(default_factory=list, description="column names the ticket mentions")
    freshness: str = Field(default="daily", description="how often the pipeline must run")
    owner: str = ""
    acceptance_criteria: list[str] = Field(default_factory=list, description="what the ticket says must hold when the work is done")
    layer: Layer | None = Field(default=None, description="the medallion layer the work builds")
    depends_on: list[str] = Field(default_factory=list, description="tickets whose tables must exist first, e.g. KAN-3")
    open_questions: list[str] = Field(default_factory=list)
    confidence: float = 0.0


# --------------------------------------------------------------------------- review and workflow (derived on read)
class ReviewCheck(APIModel):
    """One thing a pipeline ticket needs, and whether this one has it."""

    key: str
    label: str
    status: Literal["ok", "warn", "missing"]
    detail: str = ""
    blocking: bool = Field(default=False, description="the plan cannot be written while this is missing")


class IntentReview(APIModel):
    """How ready the ticket is to plan: a score, a verdict and the checklist behind them."""

    score: int = Field(ge=0, le=100)
    verdict: Literal["ready", "needs_answers", "thin"]
    headline: str
    checks: list[ReviewCheck] = Field(default_factory=list)


class WorkflowMetric(APIModel):
    label: str
    value: str


class WorkflowStep(APIModel):
    """One step of the planned pipeline, in the order it runs."""

    key: str
    kind: Literal["prepare", "source", "land", "stage", "table", "model", "load", "validate", "schedule", "govern", "relate", "downstream"]
    title: str
    summary: str
    items: list[str] = Field(default_factory=list)
    metrics: list[WorkflowMetric] = Field(default_factory=list)
    status: Literal["ready", "attention"] = "ready"
    note: str = Field(default="", description="why the step needs attention")


# --------------------------------------------------------------------------- validation and route
class ValidatedObject(APIModel):
    """One object the intent reads, writes or needs, and whether Snowflake has it."""

    kind: Literal["database", "schema", "table", "external_volume", "integration", "stage"]
    name: str
    role: Literal["source", "target", "prerequisite"]
    exists: bool
    rows: int | None = None
    columns: list[str] = Field(default_factory=list)
    detail: str = ""
    properties: dict[str, str] = Field(default_factory=dict, description="what DESCRIBE showed: storage provider, allowed locations, consent URL")


class IntentValidation(APIModel):
    """What a read-only look at Snowflake found for this intent; nothing is created or changed by it."""

    checked_at: datetime
    reachable: bool
    error: str = ""
    objects: list[ValidatedObject] = Field(default_factory=list)
    summary: str = ""

    def find(self, kind: str, name: str) -> ValidatedObject | None:
        return next((o for o in self.objects if o.kind == kind and o.name.upper() == name.upper()), None)


RouteKey = Literal["ingest_new", "ingest_existing", "model_new", "model_existing", "wait_upstream", "manual"]


class RouteStage(APIModel):
    key: str
    label: str
    status: Literal["done", "current", "pending", "blocked", "skipped"] = "pending"
    detail: str = ""


class IntentRoute(APIModel):
    """The path this intent takes, chosen from what it asks for and what validation found."""

    key: RouteKey
    title: str
    reason: str
    waits_on: list[str] = Field(default_factory=list, description="tables or tickets that must land before it can go on")
    stages: list[RouteStage] = Field(default_factory=list, description="derived on read from the route and the status")


# --------------------------------------------------------------------------- pipeline spec (planner output)
class SpecColumn(APIModel):
    name: str
    type: str = Field(description="Snowflake type, e.g. NUMBER(18,2), VARCHAR, DATE, TIMESTAMP_NTZ, BOOLEAN")
    nullable: bool = True
    description: str = ""
    term_key: str | None = Field(default=None, description="glossary term the column carries")
    term_name: str | None = None
    source_header: str | None = Field(default=None, description="the CSV header it comes from")
    sample: str | None = None
    catalog_type: str | None = Field(default=None, description="the type the matching catalog table gives this column")


class SpecTest(APIModel):
    name: str
    kind: Literal["row_count", "not_null", "unique", "accepted_values", "freshness", "file_count", "condition", "query"]
    columns: list[str] = Field(default_factory=list)
    detail: str = ""
    condition: str | None = Field(
        default=None,
        description="kind 'condition': a SQL predicate over the target; kind 'query': a SELECT across tables; every row it matches or returns is a failure",
    )
    origin: str | None = Field(default=None, description="the exemplar check this test was copied from")
    sample_failures: int | None = Field(default=None, description="failing rows when the test was run against the sampled CSV rows")
    sample_examples: list[str] = Field(default_factory=list)


class SpecExemplarCheck(APIModel):
    """One quality check of the exemplar table and what the planner did with it."""

    name: str
    outcome: Literal["copied", "covered", "skipped"]
    test: str | None = Field(default=None, description="the spec test it became, when copied")
    detail: str = ""


class SpecDownstreamColumn(APIModel):
    column: str
    status: Literal["mapped", "constant", "needs", "missing", "untraced"]
    sources: list[str] = Field(default_factory=list, description="the upstream columns it derives from today")
    provided_by: list[str] = Field(default_factory=list, description="the new feed's columns that supply it")


class SpecDownstream(APIModel):
    """A model that reads the exemplar and would need to read the new table too."""

    table: str
    layer: str | None = None
    repo: str
    files: list[str] = Field(default_factory=list)
    file_url: str | None = None
    link: str | None = None
    reads: list[str] = Field(default_factory=list)
    affects: list[str] = Field(default_factory=list)
    columns: list[SpecDownstreamColumn] = Field(default_factory=list)


class SpecMatch(APIModel):
    """An existing dataset or glossary term the planner related the intent to."""

    kind: Literal["dataset", "term", "exemplar"]
    name: str
    detail: str = ""
    link: str | None = None
    score: float | None = None


class SpecJoin(APIModel):
    """A way the new table joins the catalog: a shared identifier, or a join the matching table declares."""

    columns: list[str] = Field(description="columns of the new table")
    to_table: str
    to_columns: list[str] = Field(default_factory=list)
    kind: str = Field(description="shared_key | foreign_key | join_declared | join_inferred")
    confidence: float = 1.0
    via: str = ""
    link: str | None = None


class SpecCatalogMatch(APIModel):
    """The semantic-layer table the feed most resembles, and what the plan took from it."""

    fqn: str
    asset_id: str | None = None
    link: str | None = None
    kind: str | None = None
    asset_type: str | None = None
    coverage: float = Field(description="share of the feed's columns the table has")
    similarity: float = Field(description="Jaccard similarity of the two column sets")
    matched_columns: list[str] = Field(default_factory=list)
    feed_columns: int = 0
    table_columns: int = 0
    key: list[str] = Field(default_factory=list, description="the table's declared primary key")
    key_in_feed: bool = False
    types_adopted: int = 0
    type_conflicts: int = 0
    duplicate: bool = False
    duplicate_reason: str = ""


class SpecTable(APIModel):
    """One table of a table set: a source file loaded into its own table, shaped by the repository's contract."""

    name: str = Field(description="table name, e.g. A_CLAIM")
    source_file: str = Field(description="path under the source folder, e.g. vantage_core/claim.csv")
    source_system: str = ""
    columns: list[SpecColumn] = Field(default_factory=list)
    keys: list[str] = Field(default_factory=list, description="the identifier, from the contract")
    tests: list[SpecTest] = Field(default_factory=list)
    rows: int = 0
    base_location: str = ""
    exemplar: str | None = Field(default=None, description="the repository table whose contract this follows")
    exemplar_checks: list[SpecExemplarCheck] = Field(default_factory=list)
    missing_columns: list[str] = Field(default_factory=list, description="contract columns the file does not have")
    extra_columns: list[str] = Field(default_factory=list, description="file columns the contract does not have")
    exists: bool = Field(default=False, description="Snowflake already has the table")


class ModelColumn(APIModel):
    name: str
    type: str
    expression: str = Field(description="how the value is computed, in SQL over the model's sources")
    nullable: bool = True
    description: str = ""
    sources: list[str] = Field(default_factory=list, description="source columns it reads, e.g. BRONZE.A_CLAIM.CLAIM_ID")
    term_key: str | None = None
    term_name: str | None = None


class ModelRelationship(APIModel):
    columns: list[str]
    to_table: str
    to_columns: list[str] = Field(default_factory=list)


class ModelTable(APIModel):
    """A table the data modeler proposes for the target layer."""

    name: str
    kind: Literal["dimension", "fact", "bridge", "reference", "aggregate"]
    grain: str
    description: str = ""
    keys: list[str] = Field(default_factory=list, description="the business key: one row per value")
    load_mode: Literal["full_refresh", "merge"] = "full_refresh"
    sources: list[str] = Field(default_factory=list, description="the tables it reads")
    sql: str = Field(description="a SELECT producing the table's rows, columns in order")
    columns: list[ModelColumn] = Field(default_factory=list)
    relationships: list[ModelRelationship] = Field(default_factory=list)
    tests: list[SpecTest] = Field(default_factory=list)
    exemplar: str | None = Field(default=None, description="the repository model it follows")
    deviations: list[str] = Field(default_factory=list, description="where it differs from the exemplar, and why")
    findings: list[str] = Field(default_factory=list, description="what the deterministic checks found")
    exists: bool = False
    # A table compiled from a mapping: created by its own DDL, loaded through a stage with rejects and a CDC merge.
    ddl: str = Field(default="", description="the CREATE and COMMENT statements the design's DDL gives this table")
    hash_column: str | None = Field(default=None, description="the column whose change triggers an update (CDC)")
    created_column: str | None = None
    updated_column: str | None = None
    rows: int | None = Field(default=None, description="rows the compiled SELECT returned in the read-only dry run")
    duplicates: int | None = Field(default=None, description="rows beyond the first per key in the dry run; they are rejected")
    nulls: dict[str, int] = Field(default_factory=dict, description="NOT NULL columns that were null in the dry run, with counts")
    waiting_on: list[str] = Field(default_factory=list, description="mapping sources not in the layer below yet")


class PipelineSpec(APIModel):
    name: str = Field(description="pipeline slug, e.g. ingest_policy_csv")
    kind: IntentKind
    summary: str
    source: IntentSource
    target: IntentTarget
    columns: list[SpecColumn] = Field(default_factory=list)
    sampled_files: list[str] = Field(default_factory=list)
    sampled_rows: int = 0
    stage_name: str = ""
    file_format_name: str = ""
    transformations: list[str] = Field(default_factory=list)
    tests: list[SpecTest] = Field(default_factory=list)
    schedule: str = Field(default="daily", description="cron or Snowflake task schedule")
    matches: list[SpecMatch] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)
    assumptions: list[str] = Field(default_factory=list)
    exemplar_checks: list[SpecExemplarCheck] = Field(default_factory=list)
    downstream: list[SpecDownstream] = Field(default_factory=list)
    catalog_match: SpecCatalogMatch | None = None
    joins: list[SpecJoin] = Field(default_factory=list)
    tables: list[SpecTable] = Field(default_factory=list, description="a table set: one table per source file; empty for a single table")
    models: list[ModelTable] = Field(default_factory=list, description="model_layer: the tables the data modeler proposes")
    blockers: list[str] = Field(
        default_factory=list, description="source tables that hold no rows (missing, or created and never loaded): the plan cannot be approved"
    )
    create: list[Literal["database", "schema"]] = Field(default_factory=list, description="objects validation found missing; the setup creates them")


# --------------------------------------------------------------------------- coder output
class GeneratedFile(APIModel):
    path: str
    bytes: int
    reason: str = ""


class CoderResult(APIModel):
    generator: Literal["template", "agent"]
    workspace: str
    files: list[GeneratedFile] = Field(default_factory=list)
    tests_passed: bool | None = None
    test_output: str = ""
    branch: str | None = None
    pr_url: str | None = None
    summary: str = ""


# --------------------------------------------------------------------------- running the generated pipeline
RunStepKey = Literal["preflight", "upload", "apply", "load", "catalog"]


class RunStep(APIModel):
    """One step of a pipeline run in the hub: what it ran, how it went, and the tail of its output."""

    key: RunStepKey
    label: str
    status: Literal["pending", "running", "ok", "failed", "skipped"] = "pending"
    started_at: datetime | None = None
    finished_at: datetime | None = None
    detail: str = ""
    log: str = Field(default="", description="the last lines the step printed, secrets masked")
    metrics: list[WorkflowMetric] = Field(default_factory=list)


class RunCheck(APIModel):
    name: str
    failures: int
    passed: bool
    severity: Literal["error", "warn"] = Field(default="error", description="a warning is reported but does not fail the run")


class RunModel(APIModel):
    """One table of a modelled layer as the load built it: rows staged from the layer below, kept, rejected, merged."""

    name: str
    staged: int = 0
    rejected: int = 0
    inserted: int = 0
    updated: int = 0
    rows: int = Field(default=0, description="rows in the table after the load")


class RunReconciliation(APIModel):
    """One table's source against its target after a load: its rows, its keys or a total."""

    table: str
    measure: str = Field(description="rows, keys, or sum:<COLUMN>")
    source: float
    target: float
    explained: float = Field(default=0, description="rows or keys the load rejected with a reason")
    gap: float = Field(default=0, description="source - target - explained; 0 when they reconcile")
    status: Literal["match", "explained", "warn", "gap"] = Field(description="a gap fails the load; a total that differs only warns")


class PipelineRun(APIModel):
    """The approved pipeline run by the hub: upload the files, create the objects, load, check, refresh the catalog."""

    status: Literal["running", "succeeded", "failed"]
    triggered_by: Literal["approval", "manual"] = "manual"
    started_at: datetime
    finished_at: datetime | None = None
    role: str | None = Field(default=None, description="the Snowflake role the statements ran as")
    warnings: list[str] = Field(default_factory=list)
    steps: list[RunStep] = Field(default_factory=list)
    checks: list[RunCheck] = Field(default_factory=list)
    models: list[RunModel] = Field(default_factory=list, description="model_layer: what the load did to each table")
    reconciliation: list[RunReconciliation] = Field(default_factory=list, description="each loaded table's source against its target")
    files_uploaded: int = 0
    statements: int = 0
    catalog_run_id: str | None = Field(default=None, description="the ingestion run that refreshed the catalog after the load")
    error: str = ""


# --------------------------------------------------------------------------- records and requests
class IntentRecord(APIModel):
    id: UUID
    source: Literal["manual", "jira"]
    jira_key: str | None = None
    jira_url: str | None = None
    title: str
    text: str = ""
    reporter: str = ""
    status: IntentStatus
    intent: StructuredIntent | None = None
    questions: list[str] = Field(default_factory=list)
    answers: list[str] = Field(default_factory=list)
    spec: PipelineSpec | None = None
    spec_markdown: str = ""
    coder: CoderResult | None = None
    branch: str | None = None
    pr_url: str | None = None
    error: str | None = None
    posted: list[dict[str, Any]] = Field(default_factory=list)
    validation: IntentValidation | None = None
    route: IntentRoute | None = None
    run: PipelineRun | None = Field(default=None, description="the latest run of the generated pipeline in the hub")
    run_missing: list[str] = Field(default_factory=list, description="runtime settings (names only) a run of this spec still needs; derived on read")
    created_at: datetime
    updated_at: datetime
    decided_at: datetime | None = None
    review: IntentReview | None = Field(default=None, description="derived on read from the intent and the spec")
    workflow: list[WorkflowStep] = Field(default_factory=list, description="the spec as the steps the pipeline runs, derived on read")


class IntentCreate(APIModel):
    title: str = Field(min_length=3, max_length=200)
    text: str = Field(default="", max_length=20_000)
    reporter: str = Field(default="", max_length=120)
    jira_key: str | None = Field(default=None, max_length=40, description="the ticket's key when its text was pasted from Jira")
    jira_url: str | None = Field(default=None, max_length=500)


class JiraImport(APIModel):
    issue: str = Field(min_length=2, max_length=500, description="an issue key such as DATA-123, or its browse URL")


class IntentAnswer(APIModel):
    answers: list[str] = Field(min_length=1)


class IntentDecision(APIModel):
    decision: Literal["approve", "reject", "done"]
    note: str = Field(default="", max_length=2000)


class IntentFile(APIModel):
    path: str
    content: str


class IntentsConfig(APIModel):
    jira_configured: bool
    jira_jql: str | None = None
    poll_seconds: int = 0
    workspace: str
    data_dir: str
    snowflake_configured: bool
    model_available: bool
    run_enabled: bool = Field(default=False, description="the hub runs an approved pipeline itself")
    autorun: bool = Field(default=False, description="approval generates and then runs the pipeline")
    run_role: str | None = Field(default=None, description="the Snowflake role pipeline runs use")
    run_missing: list[str] = Field(default_factory=list, description="runtime settings (names only) a run still needs")
    kinds: list[str] = Field(default_factory=lambda: ["ingest_csv_to_iceberg", "model_layer", "gold_fact", "other"])


class JiraSyncResult(APIModel):
    fetched: int = 0
    created: int = 0
    answered: int = 0
    approved: int = 0
    rejected: int = 0
    errors: list[str] = Field(default_factory=list)
