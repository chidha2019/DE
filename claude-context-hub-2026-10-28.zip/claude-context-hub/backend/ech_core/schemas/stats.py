"""Dashboard statistics schemas."""

from __future__ import annotations

from datetime import datetime
from typing import Literal
from uuid import UUID

from pydantic import Field

from ech_core.domain.models import AuditRecord
from ech_core.schemas.common import APIModel


class LatencyPoint(APIModel):
    bucket_start: datetime
    count: int
    p50_ms: float
    p95_ms: float
    p99_ms: float
    avg_ms: float
    error_rate: float


class LatencySeries(APIModel):
    window_minutes: int
    bucket_seconds: int
    path_prefix: str | None = None
    points: list[LatencyPoint]
    overall: LatencyPoint | None = None


class RunActivityPoint(APIModel):
    bucket_start: datetime
    completed: int = 0
    failed: int = 0
    cancelled: int = 0
    documents: int = 0


KpiStatus = Literal["ok", "warn", "bad", "info", "na"]
KpiUnit = Literal["percent", "count", "hours", "seconds", "per_minute", "ms"]


class KpiValue(APIModel):
    """One KPI with its target and the verdict against it."""

    key: str
    label: str
    value: float | None = None
    unit: KpiUnit = "count"
    target: float | None = None
    direction: Literal["higher", "lower"] = "higher"
    status: KpiStatus = "na"
    detail: str = ""


class KpiGroup(APIModel):
    key: str
    label: str
    description: str = ""
    kpis: list[KpiValue] = Field(default_factory=list)


class ConnectorFreshness(APIModel):
    connector: str
    source_system: str
    last_success_at: datetime | None = None
    age_hours: float | None = None
    last_status: str | None = None
    runs: int = 0
    failed: int = 0
    documents_upserted: int = 0


class KpiTarget(APIModel):
    """An active KPI target, where it comes from and whether it differs from the default."""

    key: str
    label: str
    env_var: str
    unit: KpiUnit = "count"
    direction: Literal["higher", "lower"] = "higher"
    value: float
    default: float
    overridden: bool = False


class EngineeringKpis(APIModel):
    """The Data Engineer scorecard: pipelines, graph consistency, catalog coverage, freshness."""

    window_days: int
    generated_at: datetime
    targets: list[KpiTarget] = Field(default_factory=list)
    groups: list[KpiGroup] = Field(default_factory=list)
    connectors: list[ConnectorFreshness] = Field(default_factory=list)


class OverviewStats(APIModel):
    documents_total: int
    documents_by_source: dict[str, int] = Field(default_factory=dict)
    documents_by_kind: dict[str, int] = Field(default_factory=dict)
    documents_graph_pending: int
    chunks_total: int
    embeddings_total: int
    embedding_model: str
    vector_dimensions: int
    graph_nodes_total: int
    graph_edges_total: int
    graph_nodes_by_label: dict[str, int] = Field(default_factory=dict)
    graph_edges_by_type: dict[str, int] = Field(default_factory=dict)
    graph_density: float
    runs_total: int
    runs_active: int
    last_run_at: datetime | None = None
    retrieval_requests_24h: int
    retrieval_p95_ms_24h: float | None = None
    generated_at: datetime


# ----------------------------------------------------------------------------- QA Engineer
class RunFailure(APIModel):
    id: UUID
    connector: str
    source_system: str
    status: str
    error: str | None = None
    started_at: datetime | None = None
    finished_at: datetime | None = None
    documents_failed: int = 0


class ReviewItem(APIModel):
    """A Claude suggestion still waiting for a person's decision."""

    asset_id: UUID
    fqn: str
    display_name: str
    kind: str
    proposed_name: str
    proposed_kind: str
    confidence: float
    metrics: int = 0
    generated_at: datetime | None = None


class QualityReport(APIModel):
    """The QA Engineer scorecard: every gate carries its target and verdict."""

    window_days: int
    generated_at: datetime
    gates_total: int = 0
    gates_passed: int = 0
    targets: list[KpiTarget] = Field(default_factory=list)
    groups: list[KpiGroup] = Field(default_factory=list)
    failed_runs: list[RunFailure] = Field(default_factory=list)
    review_queue: list[ReviewItem] = Field(default_factory=list)
    recent_errors: list[AuditRecord] = Field(default_factory=list)


# ----------------------------------------------------------------------------- Business Analyst
class AnalystReport(APIModel):
    """The Business Analyst scorecard: self-serve answers, request turnaround, certified numbers."""

    window_days: int
    generated_at: datetime
    targets: list[KpiTarget] = Field(default_factory=list)
    groups: list[KpiGroup] = Field(default_factory=list)


# ----------------------------------------------------------------------------- SRE
class RequestRollup(APIModel):
    action: str
    requests: int = 0
    errors: int = 0
    error_rate: float | None = None
    p50_ms: float | None = None
    p95_ms: float | None = None
    p99_ms: float | None = None
    avg_ms: float | None = None


class ErrorBudget(APIModel):
    """How much of the allowed error rate the window has used up."""

    target_error_rate: float
    requests: int = 0
    errors: int = 0
    allowed_errors: float = 0.0
    consumed_pct: float | None = None


class TableSize(APIModel):
    table: str
    rows: int = 0
    bytes: int = 0


class PlatformReport(APIModel):
    """The SRE view: request health, error budget, pipeline state, storage."""

    window_hours: int
    generated_at: datetime
    targets: list[KpiTarget] = Field(default_factory=list)
    groups: list[KpiGroup] = Field(default_factory=list)
    requests: list[RequestRollup] = Field(default_factory=list)
    error_budget: ErrorBudget
    storage: list[TableSize] = Field(default_factory=list)
    database_bytes: int = 0
    embeddings_total: int = 0
    vector_dimensions: int = 0
    embeddings_bytes_estimate: int = 0
    graph_nodes: int = 0
    graph_edges: int = 0
    audit_rows_per_day: float = 0.0
    runs_active: int = 0
    runs_stale: int = 0
    recent_errors: list[AuditRecord] = Field(default_factory=list)


# ----------------------------------------------------------------------------- Architect
class PlatformSummary(APIModel):
    platform: str
    databases: int = 0
    schemas: int = 0
    assets: int = 0
    metric_views: int = 0
    by_kind: dict[str, int] = Field(default_factory=dict)
    by_asset_type: dict[str, int] = Field(default_factory=dict)
    last_synced_at: datetime | None = None


class SharedDimension(APIModel):
    """A dimension joined from two or more facts: conformed across the model."""

    id: UUID
    fqn: str
    display_name: str
    facts: int


class Integration(APIModel):
    key: str
    label: str
    kind: Literal["source", "store", "model", "export", "api", "assistant"]
    status: Literal["configured", "available", "missing"]
    detail: str = ""
    href: str | None = None


class ArchitectureReport(APIModel):
    """The Architect landscape: platforms, model composition, integration surface."""

    generated_at: datetime
    platforms: list[PlatformSummary] = Field(default_factory=list)
    document_sources: dict[str, int] = Field(default_factory=dict)
    documents_by_kind: dict[str, int] = Field(default_factory=dict)
    assets_by_kind: dict[str, int] = Field(default_factory=dict)
    fields_by_role: dict[str, int] = Field(default_factory=dict)
    relationships_by_kind: dict[str, int] = Field(default_factory=dict)
    metrics_by_source: dict[str, int] = Field(default_factory=dict)
    graph_nodes_by_label: dict[str, int] = Field(default_factory=dict)
    graph_edges_by_type: dict[str, int] = Field(default_factory=dict)
    graph_density: float = 0.0
    subject_areas: int = 0
    facts: int = 0
    dimensions: int = 0
    metric_views: int = 0
    governed_metrics: int = 0
    cross_platform_links: int = 0
    shared_dimensions: list[SharedDimension] = Field(default_factory=list)
    integrations: list[Integration] = Field(default_factory=list)
    embedding_model: str = ""
    vector_dimensions: int = 0
    genie_provider: str | None = None
    genie_model: str | None = None
    reranker: str = ""
