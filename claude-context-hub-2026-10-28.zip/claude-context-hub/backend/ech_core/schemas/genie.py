"""Schemas for Genie (``/api/v1/genie``): spaces, conversations, messages, streaming."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal
from uuid import UUID

from pydantic import Field

from ech_core.schemas.common import APIModel
from ech_core.schemas.context import RetrievalFilters

MessageRole = Literal["user", "assistant"]
MessageStatus = Literal["complete", "error", "cancelled"]


# ----------------------------------------------------------------------------- spaces
class GenieSpaceIn(APIModel):
    name: str = Field(min_length=1, max_length=120)
    description: str = Field(default="", max_length=2000)
    instructions: str = Field(
        default="", max_length=6000, description="standing guidance added to the system prompt"
    )
    filters: RetrievalFilters = Field(default_factory=RetrievalFilters)
    sample_questions: list[str] = Field(default_factory=list, max_length=12)


class GenieSpaceUpdate(APIModel):
    name: str | None = Field(default=None, min_length=1, max_length=120)
    description: str | None = Field(default=None, max_length=2000)
    instructions: str | None = Field(default=None, max_length=6000)
    filters: RetrievalFilters | None = None
    sample_questions: list[str] | None = Field(default=None, max_length=12)


PersonaKey = Literal[
    "data_engineer",
    "business_analyst",
    "qa_engineer",
    "architect",
    "sre",
    "devops",
    "devsecops",
    "data_steward",
    "data_scientist",
    "compliance",
]


class GenieSpaceOut(GenieSpaceIn):
    id: UUID
    is_default: bool = False
    persona: PersonaKey | None = Field(
        default=None, description="set on the space a persona workspace asks through"
    )
    conversation_count: int = 0
    created_at: datetime
    updated_at: datetime


# ----------------------------------------------------------------------------- conversations
class GenieConversationOut(APIModel):
    id: UUID
    space_id: UUID
    title: str
    message_count: int = 0
    last_message_at: datetime | None = None
    created_at: datetime
    updated_at: datetime


class GenieCitation(APIModel):
    marker: str = Field(description="inline marker used in the answer, e.g. S3")
    chunk_id: UUID
    document_id: UUID
    title: str
    path: str | None = None
    source_system: str
    uri: str | None = None
    score: float = 0.0
    chunk_index: int = 0
    snippet: str = ""
    kind: Literal["chunk", "asset"] = Field(
        default="chunk",
        description="chunk: a document chunk; asset: a semantic-layer asset (table, view, metric view)",
    )


class GenieTraceStep(APIModel):
    step: int
    tool: str
    summary: str
    input: dict[str, Any] = Field(default_factory=dict)
    detail: str | None = Field(default=None, description="e.g. the Cypher that ran")
    ok: bool = True
    duration_ms: float = 0.0
    rows: int | None = None
    narration: str | None = Field(
        default=None, description="assistant text that preceded this tool call"
    )


class GenieMessageOut(APIModel):
    id: UUID
    conversation_id: UUID
    role: MessageRole
    content: str
    status: MessageStatus = "complete"
    error: str | None = None
    citations: list[GenieCitation] = Field(default_factory=list)
    trace: list[GenieTraceStep] = Field(default_factory=list)
    follow_ups: list[str] = Field(default_factory=list)
    usage: dict[str, int] = Field(default_factory=dict)
    model: str | None = None
    latency_ms: int | None = None
    feedback: int | None = None
    created_at: datetime


class GenieConversationDetail(GenieConversationOut):
    messages: list[GenieMessageOut] = Field(default_factory=list)


# ----------------------------------------------------------------------------- ask / feedback
class GenieAskRequest(APIModel):
    question: str = Field(min_length=1, max_length=4000)
    conversation_id: UUID | None = Field(
        default=None, description="continue this conversation; omitted: start a new one"
    )


class GenieFeedbackIn(APIModel):
    value: Literal[-1, 1] | None = Field(description="thumbs down, thumbs up, or clear")


class GenieStatus(APIModel):
    enabled: bool
    configured: bool
    provider: str | None = None
    model: str | None = None
    host: str | None = None
    credential: str | None = Field(default=None, description="which variable supplies it")
    reason: str | None = Field(default=None, description="why Genie is unavailable")
    degraded_fields: list[str] = Field(
        default_factory=list, description="optional request fields the provider rejected"
    )


class GenieStreamEvent(APIModel):
    """One SSE frame of ``POST /genie/spaces/{id}/ask`` (``event:`` = ``type``).

    * ``conversation`` - ``{conversation, user_message}`` once, first.
    * ``delta`` - ``{text}`` a piece of the assistant's text as it streams.
    * ``turn_reset`` - ``{text}`` the streamed text was narration before a tool call;
      the UI moves it into the trace and clears the live bubble.
    * ``step`` / ``step_done`` - a tool call started / finished (GenieTraceStep fields).
    * ``message`` - the persisted assistant GenieMessageOut; the stream ends after it.
    * ``error`` - ``{error, message}`` the run failed; ``message`` is the persisted record.
    """

    type: Literal["conversation", "delta", "turn_reset", "step", "step_done", "message", "error"]
    data: dict[str, Any] = Field(default_factory=dict)
