"""A persona's digital worker: the skills it has, the work it picked up, what it did, and what waits for a person."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import Field

from ech_core.schemas.common import APIModel

Tier = Literal["T0", "T1", "T2", "T3"]
ItemStatus = Literal["detected", "diagnosed", "waiting", "running", "done", "failed", "dismissed"]
JournalKind = Literal["shift", "observed", "diagnosed", "proposed", "approved", "acted", "done", "failed", "dismissed"]


class WorkerPlaybook(APIModel):
    name: str
    package: str = Field(description="the SKILL.md it was loaded from")
    description: str = ""
    rules: list[str] = Field(default_factory=list)
    red_flags: list[str] = Field(default_factory=list, description="signs the work is going wrong")
    checks: list[str] = Field(default_factory=list, description="what is true when the work is done")


class WorkerSkill(APIModel):
    key: str
    name: str
    description: str
    tier: Tier = Field(description="the most the worker may do with it alone: T0 watch, T1 diagnose and propose, T2 act once approved, T3 act alone")
    gate: str = Field(default="", description="what must hold before the skill's output is used")
    stops: list[str] = Field(default_factory=list, description="conditions that stop it")
    actions: list[str] = Field(default_factory=list, description="what it may touch")
    rules: list[str] = Field(default_factory=list, description="the governing package's own rules, by section")
    source: Literal["hub", "package"] = "hub"
    package: str | None = Field(default=None, description="the SKILL.md package it was loaded from")
    red_flags: list[str] = Field(default_factory=list, description="a reference-only playbook's own red flags")
    checks: list[str] = Field(default_factory=list, description="a reference-only playbook's own done-when checks")
    playbooks: list[WorkerPlaybook] = Field(default_factory=list, description="playbook packages bound to the skill")
    where: str = Field(default="", description="the hub page where its work shows")
    handled: int = 0
    succeeded: int = 0
    open: int = 0
    last_at: datetime | None = None


class WorkerAction(APIModel):
    kind: Literal["rerun", "sync", "crawl", "approve_intent", "open"]
    label: str
    params: dict[str, Any] = Field(default_factory=dict)
    link: str | None = None


class WorkerItem(APIModel):
    key: str
    skill: str
    title: str
    detail: str = ""
    status: ItemStatus
    tier: Tier
    action: WorkerAction | None = None
    evidence: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime
    updated_at: datetime
    decided_by: str | None = None
    decided_at: datetime | None = None


class WorkerJournalEntry(APIModel):
    id: int
    at: datetime
    kind: JournalKind
    item_key: str | None = None
    skill: str | None = None
    message: str
    evidence: dict[str, Any] = Field(default_factory=dict)
    record_hash: str


class IntegrityTable(APIModel):
    """One declared table against the warehouse: live, empty (created, never loaded), exists, or planned only."""

    origin: str = Field(description="the repository or design folder that declares it")
    kind: Literal["repo", "design"]
    layer: str | None = None
    table: str = Field(description="SCHEMA.NAME as declared")
    status: Literal["live", "empty", "exists", "planned_only"]
    observed: str | None = Field(default=None, description="the warehouse table it matched")
    loaded_as: str | None = Field(default=None, description="the name it was loaded under, when not the declared one")
    rows: int | None = None
    synced_at: datetime | None = None
    readers: list[str] = Field(default_factory=list, description="what reads it: derived models, foreign keys, plans")


class IntegrityOrigin(APIModel):
    origin: str
    kind: Literal["repo", "design"]
    declared: int = 0
    live: int = 0
    empty: int = 0
    exists: int = 0
    planned_only: int = 0
    aliases: int = 0


class WorkerIntegrity(APIModel):
    """Declared against live: what repositories and design documents declare, checked against the catalog."""

    available: bool = True
    problem: str = Field(default="", description="why it could not be checked; nothing is reported then")
    checked_at: datetime | None = None
    origins: list[IntegrityOrigin] = Field(default_factory=list)
    tables: list[IntegrityTable] = Field(default_factory=list)
    observed: int = Field(default=0, description="tables the catalog holds")
    undeclared: int = Field(default=0, description="catalog tables no repository or design declares")


Readiness = Literal["available", "missing_connection", "missing_rules", "tool_unavailable"]


class CapabilityNeed(APIModel):
    """One connection, set of rules or tool a capability needs, as the hub found it."""

    key: str
    kind: Literal["connection", "rules", "tool"]
    label: str
    ok: bool
    detail: str = ""


class CapabilityAbility(APIModel):
    label: str
    status: Readiness
    reason: str = Field(default="", description="the first missing need, when it is not available")
    headline: bool = Field(default=False, description="one way to deliver the outcome; any available one makes the capability available")
    optional: bool = Field(default=False, description="shown, but never decides the capability's readiness")


class WorkerCapability(APIModel):
    """An outcome the worker can deliver, ready only when its headline ability's needs are all in place."""

    key: str
    title: str
    outcome: str
    readiness: Readiness
    reason: str = ""
    action: str
    link: str
    more_action: str = Field(default="", description="a second action, when the capability has one")
    more_link: str = ""
    needs_input: str = ""
    skills: list[str] = Field(default_factory=list, description="the hub skills that deliver it")
    tools: list[str] = Field(default_factory=list)
    abilities: list[CapabilityAbility] = Field(default_factory=list)
    context: list[CapabilityNeed] = Field(default_factory=list)


class WorkerCounts(APIModel):
    open: int = 0
    waiting: int = 0
    running: int = 0
    done_today: int = 0
    failed_today: int = 0
    signals: int = Field(default=0, description="signals read in the last sweep")


class WorkerSnapshot(APIModel):
    worker: str
    title: str
    autonomy: Tier = Field(description="the ceiling this worker runs under")
    paused: bool = False
    last_tick: datetime | None = None
    tick_seconds: int = 20
    now: str = Field(default="", description="what it is doing, in one line")
    counts: WorkerCounts = Field(default_factory=WorkerCounts)
    items: list[WorkerItem] = Field(default_factory=list)
    journal: list[WorkerJournalEntry] = Field(default_factory=list)
    chain_ok: bool = Field(default=True, description="every journal entry shown hashes to the one after it")
    skills: list[WorkerSkill] = Field(default_factory=list)
    integrity: WorkerIntegrity | None = None
    capabilities: list[WorkerCapability] = Field(default_factory=list)


class WorkerDecision(APIModel):
    decision: Literal["approve", "dismiss", "done"]
    note: str = ""
    checks: list[str] = Field(default_factory=list, description="on approve: the done-when checks of the skill's playbooks the person confirmed")


class WorkerPause(APIModel):
    paused: bool
