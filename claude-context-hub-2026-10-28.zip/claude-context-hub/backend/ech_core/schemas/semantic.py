"""Schemas for ``/api/v1/semantic`` - the semantic layer as the UI and Genie see it."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal
from uuid import UUID

from pydantic import Field

from ech_core.domain.enums import SourceSystem
from ech_core.schemas.common import APIModel

ExportFormat = Literal["cortex", "databricks_metric_view", "hub"]


class SemanticScope(APIModel):
    source_system: str
    platform: str
    database_name: str
    schema_name: str
    assets: int
    facts: int = 0
    dimensions: int = 0
    metric_views: int = 0
    synced_at: datetime | None = None


class SemanticOverview(APIModel):
    assets: int
    fields: int
    relationships: int
    metrics: int
    declared_metrics: int
    last_synced_at: datetime | None = None
    by_platform: dict[str, int] = Field(default_factory=dict)
    by_asset_type: dict[str, int] = Field(default_factory=dict)
    by_kind: dict[str, int] = Field(default_factory=dict)
    by_role: dict[str, int] = Field(default_factory=dict)
    scopes: list[SemanticScope] = Field(default_factory=list)


class SemanticAssetSummary(APIModel):
    id: UUID
    document_id: UUID
    source_system: str
    platform: str
    fqn: str
    database_name: str
    schema_name: str
    name: str
    asset_type: str
    kind: str
    display_name: str = ""
    summary: str = ""
    name_source: str = "derived"
    kind_source: str = "inferred"
    enrichment: dict[str, Any] = Field(default_factory=dict)
    description: str = ""
    owner: str | None = None
    tags: list[str] = Field(default_factory=list)
    field_count: int = 0
    metric_count: int = 0
    relationship_count: int = 0
    row_count: int | None = None
    uri: str | None = None
    source_updated_at: datetime | None = None
    synced_at: datetime


class SemanticFieldOut(APIModel):
    id: UUID
    name: str
    display_name: str = ""
    ordinal: int
    data_type: str = ""
    description: str = ""
    nullable: bool | None = None
    is_primary_key: bool = False
    is_partition: bool = False
    role: str
    role_confidence: float = 0.0
    aggregation: str | None = None
    tags: list[str] = Field(default_factory=list)
    synonyms: list[str] = Field(default_factory=list)


class SemanticRelationshipOut(APIModel):
    id: UUID
    direction: Literal["out", "in"]
    kind: str
    source_asset_id: UUID
    target_asset_id: UUID | None = None
    target_fqn: str
    other_asset_id: UUID | None = Field(default=None, description="the asset at the other end")
    other_fqn: str
    other_name: str | None = None
    other_asset_type: str | None = None
    other_kind: str | None = None
    source_columns: list[str] = Field(default_factory=list)
    target_columns: list[str] = Field(default_factory=list)
    confidence: float = 1.0
    evidence: str = ""


class SemanticMetricOut(APIModel):
    id: UUID
    name: str
    display_name: str = ""
    expression: str = ""
    aggregation: str | None = None
    description: str = ""
    source: str
    dimensions: list[str] = Field(default_factory=list)
    fields: list[str] = Field(default_factory=list)
    synonyms: list[str] = Field(default_factory=list)


class SemanticAssetDetail(SemanticAssetSummary):
    properties: dict[str, Any] = Field(default_factory=dict)
    definition: str | None = None
    bytes: int | None = None
    source_created_at: datetime | None = None
    fields: list[SemanticFieldOut] = Field(default_factory=list)
    relationships: list[SemanticRelationshipOut] = Field(default_factory=list)
    metrics: list[SemanticMetricOut] = Field(default_factory=list)


class SemanticFieldHit(APIModel):
    name: str
    display_name: str = ""
    data_type: str = ""
    role: str
    description: str = ""
    is_primary_key: bool = False
    asset_id: UUID
    asset_fqn: str
    asset_type: str
    platform: str = ""
    uri: str | None = None


class SemanticMetricHit(APIModel):
    name: str
    expression: str = ""
    aggregation: str | None = None
    description: str = ""
    source: str
    asset_id: UUID
    asset_fqn: str
    platform: str = ""
    uri: str | None = None


class SemanticSearchResponse(APIModel):
    query: str
    assets: list[SemanticAssetSummary] = Field(default_factory=list)
    fields: list[SemanticFieldHit] = Field(default_factory=list)
    metrics: list[SemanticMetricHit] = Field(default_factory=list)


class SemanticGraphNode(APIModel):
    id: UUID
    fqn: str
    name: str
    asset_type: str
    kind: str


class SemanticGraphEdge(APIModel):
    source: UUID
    target: UUID | None = None
    target_fqn: str
    kind: str
    confidence: float = 1.0
    source_columns: list[str] = Field(default_factory=list)
    target_columns: list[str] = Field(default_factory=list)


class SemanticGraph(APIModel):
    center_id: UUID
    nodes: list[SemanticGraphNode] = Field(default_factory=list)
    edges: list[SemanticGraphEdge] = Field(default_factory=list)


# ----------------------------------------------------------------------------- persona views
class SemanticMetricRow(APIModel):
    """One metric with the dataset it is defined on (the analyst's metrics catalog)."""

    id: UUID
    name: str
    display_name: str = ""
    expression: str = ""
    aggregation: str | None = None
    description: str = ""
    source: str
    dimensions: list[str] = Field(default_factory=list)
    synonyms: list[str] = Field(default_factory=list)
    asset_id: UUID
    asset_fqn: str
    asset_name: str
    asset_type: str
    asset_kind: str
    platform: str
    database_name: str
    schema_name: str
    uri: str | None = None


class GlossaryAssetRef(APIModel):
    id: UUID
    fqn: str


class GlossaryTerm(APIModel):
    """A column name across every dataset that carries it, with the best description found."""

    term: str
    role: str
    data_types: list[str] = Field(default_factory=list)
    description: str = ""
    asset_count: int
    declared: bool = False
    assets: list[GlossaryAssetRef] = Field(default_factory=list)


class HealthAssetRef(APIModel):
    id: UUID
    fqn: str
    asset_type: str
    kind: str
    field_count: int = 0
    owner: str | None = None
    platform: str


class HealthJoinRef(APIModel):
    id: UUID
    source_asset_id: UUID
    source_fqn: str
    target_asset_id: UUID | None = None
    target_fqn: str
    source_columns: list[str] = Field(default_factory=list)
    target_columns: list[str] = Field(default_factory=list)
    confidence: float
    evidence: str = ""


class HealthCoverage(APIModel):
    platform: str
    database_name: str
    schema_name: str
    assets: int
    described: int
    owned: int
    facts: int
    keyed_facts: int
    synced_at: datetime | None = None


class SemanticHealth(APIModel):
    """What a data engineer fixes first: gaps in documentation, ownership, keys and joins."""

    assets: int
    described: int
    owned: int
    facts: int
    keyed_facts: int
    with_relationships: int
    isolated: int
    inferred_joins: int
    low_confidence_joins: int
    stale_assets: int
    last_synced_at: datetime | None = None
    undocumented: list[HealthAssetRef] = Field(default_factory=list)
    unowned: list[HealthAssetRef] = Field(default_factory=list)
    keyless_facts: list[HealthAssetRef] = Field(default_factory=list)
    orphans: list[HealthAssetRef] = Field(default_factory=list)
    review_joins: list[HealthJoinRef] = Field(default_factory=list)
    coverage: list[HealthCoverage] = Field(default_factory=list)


# ----------------------------------------------------------------------------- enrichment
class EnrichmentMetric(APIModel):
    name: str
    display_name: str = ""
    expression: str = ""
    description: str = ""
    dimensions: list[str] = Field(default_factory=list)


class EnrichmentSuggestion(APIModel):
    """What the model proposed for one asset, and what happened to it."""

    status: Literal["suggested", "accepted", "rejected"] = "suggested"
    display_name: str
    summary: str = ""
    kind: str
    metrics: list[EnrichmentMetric] = Field(default_factory=list)
    confidence: float = 0.0
    rationale: str = ""
    model: str | None = None
    generated_at: datetime
    decided_at: datetime | None = None


class EnrichmentDecision(APIModel):
    action: Literal["accept", "reject"]
    display_name: str | None = Field(default=None, max_length=120)
    summary: str | None = Field(default=None, max_length=300)
    kind: str | None = Field(default=None, max_length=20)
    metric_names: list[str] | None = Field(
        default=None, description="which suggested metrics to add; all of them when omitted"
    )


class EnrichRequest(APIModel):
    source_system: SourceSystem | None = None
    database: str | None = Field(default=None, max_length=255)
    schema_name: str | None = Field(default=None, max_length=255, alias="schema")
    asset_ids: list[UUID] | None = None
    only_undocumented: bool = Field(
        default=True, description="assets without a description, kind or non-derived name"
    )
    redo: bool = Field(default=False, description="re-suggest assets that already have one")
    limit: int = Field(default=50, ge=1, le=500)


class EnrichRun(APIModel):
    id: UUID
    status: Literal["running", "completed", "failed", "cancelled"]
    total: int = 0
    done: int = 0
    failed: int = 0
    skipped_proposed: int = Field(
        default=0, description="in scope but left out: Claude already proposed (awaiting review or accepted)"
    )
    skipped_documented: int = Field(
        default=0, description="in scope but left out: already described, classified and named"
    )
    message: str | None = Field(default=None, description="why the run had nothing to do")
    started_at: datetime
    finished_at: datetime | None = None
    error: str | None = None
    current: str | None = None


# ----------------------------------------------------------------------------- business model
class StarDimension(APIModel):
    asset: SemanticAssetSummary | None = None
    fqn: str
    display_name: str
    kind: str = "unknown"
    relationship: str
    join_columns: list[str] = Field(default_factory=list)
    confidence: float = 1.0


class FactStar(APIModel):
    asset: SemanticAssetSummary
    measures: list[str] = Field(default_factory=list)
    time: list[str] = Field(default_factory=list)
    roles: dict[str, int] = Field(default_factory=dict)
    dimensions: list[StarDimension] = Field(default_factory=list)
    metrics: list[SemanticMetricOut] = Field(default_factory=list)


class MetricViewCard(APIModel):
    asset: SemanticAssetSummary
    source_fqn: str | None = None
    dimensions: list[str] = Field(default_factory=list)
    metrics: list[SemanticMetricOut] = Field(default_factory=list)


class SubjectArea(APIModel):
    platform: str
    database_name: str
    schema_name: str
    label: str
    assets: int = 0
    described: int = 0
    named: int = Field(
        default=0, description="assets whose name is declared, curated or accepted from the model"
    )
    facts: list[FactStar] = Field(default_factory=list)
    metric_views: list[MetricViewCard] = Field(default_factory=list)
    dimensions: list[SemanticAssetSummary] = Field(default_factory=list)
    other: list[SemanticAssetSummary] = Field(default_factory=list)


class BusinessModel(APIModel):
    """The semantic layer as a business reader sees it: subject areas, stars, governed KPIs."""

    subject_areas: list[SubjectArea] = Field(default_factory=list)
    assets: int = 0
    facts: int = 0
    dimensions: int = 0
    metric_views: int = 0
    governed_metrics: int = 0
    enrichment_available: bool = False
