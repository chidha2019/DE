"""The connector catalogue: every source the hub can read, or plans to, with its live state."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import Field

from ech_core.schemas.common import APIModel

CatalogAvailability = Literal["configured", "available", "planned"]
"""configured: an adapter exists and its settings are present; available: an adapter exists
but nothing is configured; planned: on the roadmap, no adapter yet."""

CatalogFeeds = Literal["semantic", "documents", "both"]
"""What the connector contributes: catalog assets for the semantic layer, documents for
retrieval, or both."""


class ConnectorCatalogEntry(APIModel):
    key: str
    name: str
    vendor: str = Field(description="one-line tagline under the name, e.g. 'Unity Catalog'")
    category: str
    description: str
    feeds: CatalogFeeds
    capabilities: list[str]
    env_vars: list[str] = Field(default_factory=list, description="setting names only, never values")
    availability: CatalogAvailability
    adapter: str | None = Field(default=None, description="registry name when an adapter exists")
    source_system: str | None = None
    healthy: bool | None = Field(default=None, description="only known for configured connectors")
    health_details: dict[str, Any] = Field(default_factory=dict)
    estimated_documents: int | None = None
    documents: int = Field(default=0, description="documents in the hub from this source")
    last_success_at: datetime | None = None
    last_status: str | None = None
    runs_7d: int = 0
    failed_7d: int = 0
    docs_url: str | None = None
    accent: str = Field(description="HSL triplet ('h s% l%') for the card's icon tile")
    icon: str = Field(description="icon key the UI maps to a glyph")
    editable: bool = Field(default=False, description="its connection can be edited and tested from the hub")
    settings_source: Literal["env", "hub"] | None = Field(default=None, description="hub: some settings were saved from the UI")
    health_latency_ms: int | None = None


class ConnectorCatalogCategory(APIModel):
    key: str
    label: str
    tagline: str
    count: int


class ConnectorCatalog(APIModel):
    generated_at: datetime
    total: int
    configured: int
    available: int
    planned: int
    categories: list[ConnectorCatalogCategory]
    entries: list[ConnectorCatalogEntry]


ConnectionFieldKind = Literal["text", "url", "secret", "list", "number", "bool", "select"]


class ConnectionField(APIModel):
    """One setting of a connection. Secret values are never sent: only whether one is set, and where."""

    name: str
    label: str
    kind: ConnectionFieldKind
    group: str = "Connection"
    help: str = ""
    placeholder: str = ""
    required: bool = False
    options: list[str] = Field(default_factory=list)
    value: Any = None
    secret_set: bool = False
    source: Literal["hub", "env", "default"] = "default"


class ConnectionOut(APIModel):
    connector: str
    display_name: str
    registered: bool = Field(description="the adapter is live with these settings")
    fields: list[ConnectionField]
    updated_at: datetime | None = None
    updated_by: str | None = None
    can_store_secrets: bool = True


class ConnectionDraft(APIModel):
    """Changes to a connection. Unlisted fields keep their value; a secret set to null goes back to the environment."""

    values: dict[str, Any] = Field(default_factory=dict)
    secrets: dict[str, str | None] = Field(default_factory=dict)
    updated_by: str = Field(default="", max_length=120)


class ConnectionTestResult(APIModel):
    connector: str
    ok: bool
    latency_ms: int
    details: dict[str, Any] = Field(default_factory=dict)
    error: str | None = None
    tested_at: datetime
    draft: bool = Field(description="the settings tested include unsaved changes")
