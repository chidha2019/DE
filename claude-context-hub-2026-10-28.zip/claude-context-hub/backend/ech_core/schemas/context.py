"""Schemas for ``POST /api/v1/context/retrieve`` — the contract AI agents consume."""

from __future__ import annotations

from typing import Any
from uuid import UUID

from pydantic import Field, model_validator

from ech_core.domain.enums import SourceSystem
from ech_core.schemas.common import APIModel
from ech_core.schemas.graph import GraphEdge, GraphNode


class RetrievalFilters(APIModel):
    source_systems: list[SourceSystem] | None = None
    document_ids: list[UUID] | None = Field(default=None, max_length=200)
    attributes: dict[str, Any] | None = Field(
        default=None, description="JSONB containment filter on documents.attributes"
    )


class RetrievalOptions(APIModel):
    use_vector: bool = True
    use_keyword: bool = True
    use_graph: bool = True
    use_rerank: bool = True
    graph_hops: int = Field(default=2, ge=1, le=2)
    vector_top_k: int | None = Field(default=None, ge=1, le=500)
    keyword_top_k: int | None = Field(default=None, ge=1, le=500)
    rerank_candidates: int | None = Field(default=None, ge=1, le=400)
    include_graph_context: bool = True
    include_debug: bool = False
    max_content_chars: int | None = Field(default=None, ge=64, le=20_000)


class AgentState(APIModel):
    """Structured agent context; used to synthesise a query when none is given."""

    goal: str | None = Field(default=None, max_length=2000)
    current_task: str | None = Field(default=None, max_length=2000)
    recent_messages: list[str] = Field(default_factory=list, max_length=20)
    entities: list[str] = Field(default_factory=list, max_length=50)
    metadata: dict[str, Any] = Field(default_factory=dict)

    def to_query(self) -> str:
        parts: list[str] = []
        if self.current_task:
            parts.append(self.current_task)
        if self.goal:
            parts.append(self.goal)
        parts.extend(self.recent_messages[-3:])
        parts.extend(self.entities)
        return " ".join(p.strip() for p in parts if p and p.strip())


class ContextRetrieveRequest(APIModel):
    query: str | None = Field(default=None, max_length=8000)
    agent_state: AgentState | None = None
    top_k: int = Field(default=8, ge=1, le=50)
    filters: RetrievalFilters = Field(default_factory=RetrievalFilters)
    options: RetrievalOptions = Field(default_factory=RetrievalOptions)

    @model_validator(mode="after")
    def _require_query_or_state(self) -> ContextRetrieveRequest:
        text = (self.query or "").strip()
        if not text and self.agent_state is not None:
            text = self.agent_state.to_query()
        if not text:
            raise ValueError("Provide `query` or a non-empty `agent_state`.")
        if not self.options.use_vector and not self.options.use_keyword:
            raise ValueError("At least one of use_vector / use_keyword must be true.")
        return self

    def effective_query(self) -> str:
        text = (self.query or "").strip()
        if text:
            return text
        assert self.agent_state is not None
        return self.agent_state.to_query()


class ScoreBreakdown(APIModel):
    vector: float | None = Field(default=None, description="cosine similarity in [0,1]")
    keyword: float | None = Field(default=None, description="normalised ts_rank_cd in [0,1]")
    fused: float = Field(description="reciprocal-rank-fusion score (normalised)")
    graph_boost: float = 0.0
    rerank: float | None = Field(default=None, description="reranker score in [0,1]")
    final: float


class EntityRef(APIModel):
    key: str
    name: str
    entity_type: str


class ContextChunk(APIModel):
    chunk_id: UUID
    document_id: UUID
    document_title: str
    source_system: SourceSystem
    uri: str | None = None
    chunk_index: int
    section_path: list[str] = Field(default_factory=list)
    content: str
    token_count: int
    scores: ScoreBreakdown
    retrieval_paths: list[str] = Field(
        default_factory=list, description="subset of [vector, keyword, graph]"
    )
    entities: list[EntityRef] = Field(default_factory=list)
    document_attributes: dict[str, Any] = Field(default_factory=dict)


class GraphContext(APIModel):
    nodes: list[GraphNode] = Field(default_factory=list)
    edges: list[GraphEdge] = Field(default_factory=list)
    seed_chunk_ids: list[UUID] = Field(default_factory=list)
    expanded_chunk_ids: list[UUID] = Field(default_factory=list)
    first_degree_entities: list[str] = Field(default_factory=list)
    second_degree_entities: list[str] = Field(default_factory=list)


class StageTimings(APIModel):
    embed_ms: float = 0.0
    vector_ms: float = 0.0
    keyword_ms: float = 0.0
    fusion_ms: float = 0.0
    graph_ms: float = 0.0
    hydrate_ms: float = 0.0
    rerank_ms: float = 0.0
    total_ms: float = 0.0


class ContextRetrieveResponse(APIModel):
    request_id: str | None = None
    query: str
    top_k: int
    results: list[ContextChunk]
    graph_context: GraphContext | None = None
    timings: StageTimings
    candidates_considered: int
    reranker: str
    embedding_model: str
    debug: dict[str, Any] | None = None
