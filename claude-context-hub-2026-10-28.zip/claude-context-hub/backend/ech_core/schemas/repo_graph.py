"""API models for the Knowledge Hub repository graphs: crawls, crawled repositories, graph payloads and node detail."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal
from uuid import UUID

from pydantic import Field

from ech_core.schemas.common import APIModel

CrawlStatus = Literal["queued", "running", "completed", "failed"]


class RepoCrawlCreate(APIModel):
    repo: str = Field(min_length=3, max_length=300, description="owner/name, owner/name@branch or a github.com URL")
    ref: str | None = Field(default=None, max_length=200, description="branch, tag or commit; default branch when empty")
    index_text: bool = Field(
        default=False, description="also index the files' text for search and Genie (repository must be in ECH_GITHUB_REPOS)"
    )
    requested_by: str | None = Field(default=None, max_length=128)


class RepoCrawlOut(APIModel):
    id: UUID
    repo: str
    ref: str | None = None
    sha: str | None = None
    status: CrawlStatus
    phase: str
    files_total: int = 0
    files_read: int = 0
    stats: dict[str, Any] = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)
    error: str | None = None
    index_text: bool = False
    index_run_id: UUID | None = None
    requested_by: str | None = None
    created_at: datetime
    started_at: datetime | None = None
    finished_at: datetime | None = None


class CrawledRepo(APIModel):
    repo: str
    ref: str | None = None
    sha: str | None = None
    url: str | None = None
    description: str | None = None
    crawled_at: str | None = None
    crawl_id: str | None = None
    files: int | None = None
    counts: dict[str, int] = Field(default_factory=dict)
    configured: bool = Field(default=False, description="listed in ECH_GITHUB_REPOS, so its text can be indexed too")


class RepoGraphRepos(APIModel):
    crawled: list[CrawledRepo]
    configured: list[str] = Field(default_factory=list, description="repositories in ECH_GITHUB_REPOS")


class RepoGraphNodeOut(APIModel):
    id: str
    label: str
    type: str
    properties: dict[str, Any] = Field(default_factory=dict)
    degree: int | None = None


class RepoGraphEdgeOut(APIModel):
    source: str
    target: str
    type: str
    properties: dict[str, Any] = Field(default_factory=dict)


class RepoGraphPayload(APIModel):
    nodes: list[RepoGraphNodeOut]
    edges: list[RepoGraphEdgeOut]
    center_id: str | None = None
    chunk_entities: dict[str, list[str]] | None = None
    truncated: bool = False


class RepoNodeLink(APIModel):
    type: str
    outgoing: bool
    key: str
    kind: str | None = None
    name: str | None = None
    display: str | None = None
    methods: list[str] = Field(default_factory=list)
    evidence: list[str] = Field(default_factory=list)
    role: str | None = None


class RepoNodeDetail(APIModel):
    node: dict[str, Any]
    links: list[RepoNodeLink] = Field(default_factory=list)
    columns: list[dict[str, Any]] = Field(default_factory=list)
    upstream: list[str] = Field(default_factory=list)
    downstream: list[str] = Field(default_factory=list)
    trace: list[dict[str, Any]] = Field(default_factory=list)
