"""Envelope and utility schemas shared by every endpoint."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Generic, Literal, TypeVar

from pydantic import BaseModel, ConfigDict, Field

T = TypeVar("T")


class APIModel(BaseModel):
    """Base for all response/request models."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True, extra="ignore")


class Page(APIModel, Generic[T]):
    items: list[T]
    total: int = Field(ge=0)
    limit: int = Field(ge=1)
    offset: int = Field(ge=0)


class MessageResponse(APIModel):
    message: str
    details: dict[str, Any] = Field(default_factory=dict)


class ErrorDetail(APIModel):
    code: str
    message: str
    details: dict[str, Any] | list[Any] = Field(default_factory=dict)
    request_id: str | None = None


class ErrorResponse(APIModel):
    error: ErrorDetail


class HealthStatus(APIModel):
    status: Literal["ok", "degraded", "down"]
    service: str
    version: str
    checks: dict[str, bool] = Field(default_factory=dict)
    timestamp: datetime
