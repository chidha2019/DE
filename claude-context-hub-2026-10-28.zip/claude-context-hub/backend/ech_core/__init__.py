"""Shared kernel for the Enterprise Context Hub services.

`ech_core` contains everything both microservices need: configuration,
logging, database adapters, domain models, repositories, API schemas,
embedding providers and HTTP middleware. Service packages
(`ingestion_service`, `query_service`) depend on this package, never on
each other.
"""

__version__ = "0.1.0"
