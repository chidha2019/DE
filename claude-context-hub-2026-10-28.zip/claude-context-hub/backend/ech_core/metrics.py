"""Prometheus metrics (process-local registry).

Both services import this module; metric names are namespaced with ``ech_``
and carry a ``service`` label where the same metric is emitted by both.
"""

from __future__ import annotations

from prometheus_client import (
    CONTENT_TYPE_LATEST,
    REGISTRY,
    Counter,
    Gauge,
    Histogram,
    generate_latest,
)
from starlette.responses import Response

_LATENCY_BUCKETS = (0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0)

HTTP_REQUESTS_TOTAL = Counter(
    "ech_http_requests_total",
    "HTTP requests by service, method, route group and status.",
    ["service", "method", "path", "status"],
)
HTTP_REQUEST_DURATION = Histogram(
    "ech_http_request_duration_seconds",
    "HTTP request latency by service, method and route group.",
    ["service", "method", "path"],
    buckets=_LATENCY_BUCKETS,
)
HTTP_REQUESTS_IN_FLIGHT = Gauge(
    "ech_http_requests_in_flight",
    "In-flight HTTP requests.",
    ["service"],
)

RETRIEVAL_STAGE_DURATION = Histogram(
    "ech_retrieval_stage_duration_seconds",
    "Latency of each hybrid-retrieval stage.",
    ["stage"],
    buckets=_LATENCY_BUCKETS,
)
RETRIEVAL_REQUESTS_TOTAL = Counter(
    "ech_retrieval_requests_total",
    "Context retrieval requests by outcome.",
    ["outcome"],
)
RETRIEVAL_CANDIDATES = Histogram(
    "ech_retrieval_candidates",
    "Number of candidates considered before final ranking.",
    buckets=(5, 10, 20, 40, 80, 160, 320),
)

EMBEDDING_BATCH_DURATION = Histogram(
    "ech_embedding_batch_duration_seconds",
    "Embedding provider batch latency.",
    ["provider"],
    buckets=_LATENCY_BUCKETS,
)
EMBEDDING_TEXTS_TOTAL = Counter(
    "ech_embedding_texts_total",
    "Texts embedded, by provider.",
    ["provider"],
)

INGESTION_DOCUMENTS_TOTAL = Counter(
    "ech_ingestion_documents_total",
    "Documents processed by connector and outcome (upserted|skipped|failed).",
    ["connector", "outcome"],
)
INGESTION_CHUNKS_TOTAL = Counter(
    "ech_ingestion_chunks_total",
    "Chunks written by connector.",
    ["connector"],
)
INGESTION_RUNS_ACTIVE = Gauge(
    "ech_ingestion_runs_active",
    "Runs currently running or paused.",
)
GRAPH_SYNC_TOTAL = Counter(
    "ech_graph_sync_total",
    "Neo4j document sync attempts by outcome (synced|failed).",
    ["outcome"],
)

DB_POOL_CONNECTIONS = Gauge(
    "ech_db_pool_connections",
    "asyncpg pool connections by state.",
    ["service", "state"],
)


def metrics_response() -> Response:
    """Render the registry in the Prometheus text exposition format."""
    return Response(content=generate_latest(REGISTRY), media_type=CONTENT_TYPE_LATEST)
