"""FastAPI application factory used by both services.

Wires the cross-cutting concerns once: CORS, request-id/metrics middleware,
exception envelope, health probes and the Prometheus endpoint.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable
from contextlib import AbstractAsyncContextManager
from typing import Any

from fastapi import APIRouter, FastAPI
from fastapi.middleware.cors import CORSMiddleware

from ech_core.config import Settings
from ech_core.health import build_health_router
from ech_core.metrics import metrics_response
from ech_core.middleware.errors import register_exception_handlers
from ech_core.middleware.observability import ObservabilityMiddleware
from ech_core.observability import LatencyRecorder
from ech_core.schemas.common import ErrorResponse

Lifespan = Callable[[FastAPI], AbstractAsyncContextManager[Any]]

_COMMON_ERROR_RESPONSES: dict[int | str, dict[str, Any]] = {
    422: {"model": ErrorResponse, "description": "Validation error"},
    500: {"model": ErrorResponse, "description": "Unexpected error"},
    503: {"model": ErrorResponse, "description": "Dependency unavailable"},
}


def create_app(
    *,
    settings: Settings,
    title: str,
    description: str,
    version: str,
    lifespan: Lifespan,
    routers: Iterable[APIRouter] = (),
    latency_recorder: LatencyRecorder | None = None,
) -> FastAPI:
    app = FastAPI(
        title=title,
        description=description,
        version=version,
        lifespan=lifespan,
        docs_url="/docs",
        redoc_url=None,
        openapi_url="/openapi.json",
        responses=_COMMON_ERROR_RESPONSES,
    )
    app.state.settings = settings
    app.state.latency_recorder = latency_recorder
    app.state.readiness_checks = {}

    # Middleware order: the last one added is the outermost. We want the
    # observability layer to wrap CORS so even pre-flight requests are counted.
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
        expose_headers=["X-Request-ID", "X-Response-Time-ms"],
    )
    app.add_middleware(
        ObservabilityMiddleware,
        service_name=settings.service_name,
        latency_recorder=latency_recorder,
    )

    register_exception_handlers(app)

    app.include_router(build_health_router(settings.service_name, version))
    if settings.metrics_enabled:
        app.add_api_route("/metrics", metrics_response, methods=["GET"], include_in_schema=False)

    for router in routers:
        app.include_router(router)

    return app
