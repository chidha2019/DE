// =============================================================================
// Repo knowledge graph (crawled GitHub repositories)
//
// Every node: (:RepoGraph:<Kind> {node_key, repo, kind, name, display, ...})
//   node_key = "<owner/name>|<kind>|<name>", e.g. "acme/lakehouse|table|SILVER.DIM_PARTY"
//   Kinds: Repository, RepoFile, CodeSymbol, Pipeline, SourceSystem, DataSource, DataTable,
//          DataColumn, QualityCheck, StorageIntegration, ExternalVolume, Stage, FileFormat,
//          S3Location, CiStage, Alert
// Every edge carries methods (declared | parsed | inferred), evidence (file paths) and repo.
// A crawl replaces one repository's subgraph in a single transaction.
// =============================================================================

CREATE CONSTRAINT repo_graph_node_key_unique IF NOT EXISTS
FOR (n:RepoGraph) REQUIRE n.node_key IS UNIQUE;

CREATE INDEX repo_graph_repo_idx IF NOT EXISTS
FOR (n:RepoGraph) ON (n.repo);

CREATE INDEX repo_graph_kind_idx IF NOT EXISTS
FOR (n:RepoGraph) ON (n.kind);
