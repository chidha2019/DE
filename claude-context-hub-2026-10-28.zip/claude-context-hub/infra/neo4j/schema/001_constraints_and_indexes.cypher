// =============================================================================
// Neo4j schema — Enterprise Context Hub
//
// Executed statement-by-statement (split on ';') by backend/scripts/neo4j_schema.py.
// Community edition: only single-property uniqueness constraints are available,
// so composite keys are materialised into a single `*_key` property.
//
// Node labels
//   (:Document {document_id, external_id, source_system, title, uri, version})
//        document_id == Postgres documents.id (deterministic uuid5)
//   (:Chunk    {chunk_id, document_id, chunk_index, token_count, section_path})
//        chunk_id    == Postgres chunks.id
//   (:Entity:<Type> {entity_key, entity_type, name, normalized_name, aliases})
//        <Type> in {Person, Project, Technology, Concept}
//        entity_key = "<entity_type>:<normalized_name>"
//
// Relationships
//   (Document)-[:HAS_CHUNK]->(Chunk)
//   (Chunk)-[:MENTIONS {confidence}]->(Entity)
//   (Document)-[:REFERENCES {kind}]->(Document)
//   (Document)-[:CONTRIBUTED_BY {role}]->(Entity:Person)
//   (Entity)-[:DEPENDS_ON {weight, evidence}]->(Entity)
// =============================================================================

// --- Uniqueness constraints (also create backing indexes) --------------------
CREATE CONSTRAINT document_id_unique IF NOT EXISTS
FOR (d:Document) REQUIRE d.document_id IS UNIQUE;

CREATE CONSTRAINT chunk_id_unique IF NOT EXISTS
FOR (c:Chunk) REQUIRE c.chunk_id IS UNIQUE;

CREATE CONSTRAINT entity_key_unique IF NOT EXISTS
FOR (e:Entity) REQUIRE e.entity_key IS UNIQUE;

// --- Lookup indexes -----------------------------------------------------------
CREATE INDEX document_source_system_idx IF NOT EXISTS
FOR (d:Document) ON (d.source_system);

CREATE INDEX document_external_id_idx IF NOT EXISTS
FOR (d:Document) ON (d.external_id);

CREATE INDEX chunk_document_id_idx IF NOT EXISTS
FOR (c:Chunk) ON (c.document_id);

CREATE INDEX entity_type_idx IF NOT EXISTS
FOR (e:Entity) ON (e.entity_type);

CREATE INDEX entity_normalized_name_idx IF NOT EXISTS
FOR (e:Entity) ON (e.normalized_name);

// --- Full-text indexes (Knowledge Explorer entity search) ---------------------
CREATE FULLTEXT INDEX entity_name_fulltext IF NOT EXISTS
FOR (e:Entity) ON EACH [e.name, e.aliases];

CREATE FULLTEXT INDEX document_title_fulltext IF NOT EXISTS
FOR (d:Document) ON EACH [d.title];
