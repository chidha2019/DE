-- =============================================================================
-- Snowflake side of the CSV -> Azure Blob Storage -> Snowflake-managed Iceberg pipeline (KAN-3).
-- Run it yourself, top to bottom, as ACCOUNTADMIN; the hub never runs it. Steps 3 and 4 happen in the
-- Azure portal between the Snowflake statements.
--
-- Replace before running (all four appear more than once):
--   <AZURE_TENANT_ID>     the Microsoft Entra tenant (directory) ID that owns the storage account
--   <STORAGE_ACCOUNT>     the storage account name, lower case (e.g. omniclaimlake)
--   <LANDING_CONTAINER>   the container the CSV files are uploaded to (e.g. landing)
--   <ICEBERG_CONTAINER>   the container the Iceberg tables keep their data in (e.g. iceberg)
--
-- Two containers keep read and write apart: Snowflake only reads the landing container (Storage Blob Data
-- Reader) and only writes table data to the Iceberg one (Storage Blob Data Contributor). The landing
-- integration allows the whole container, so the hub's default folder per pipeline (for KAN-3:
-- ingest_omniclaim_bronze/) is covered.
-- =============================================================================

USE ROLE ACCOUNTADMIN;

-- 1. The integration that lets stages read the landing container.
CREATE STORAGE INTEGRATION IF NOT EXISTS ECH_AZURE_INT
  TYPE = EXTERNAL_STAGE
  STORAGE_PROVIDER = 'AZURE'
  ENABLED = TRUE
  AZURE_TENANT_ID = '<AZURE_TENANT_ID>'
  STORAGE_ALLOWED_LOCATIONS = ('azure://<STORAGE_ACCOUNT>.blob.core.windows.net/<LANDING_CONTAINER>/')
  COMMENT = 'Enterprise Context Hub: CSV landing container for the bronze loads';

-- 2. The external volume the Iceberg tables store their data in.
CREATE EXTERNAL VOLUME IF NOT EXISTS ECH_AZURE_ICEBERG_VOL
  STORAGE_LOCATIONS = (
    (
      NAME = 'ech-azure-iceberg'
      STORAGE_PROVIDER = 'AZURE'
      STORAGE_BASE_URL = 'azure://<STORAGE_ACCOUNT>.blob.core.windows.net/<ICEBERG_CONTAINER>/'
      AZURE_TENANT_ID = '<AZURE_TENANT_ID>'
    )
  )
  ALLOW_WRITES = TRUE
  COMMENT = 'Enterprise Context Hub: data of the Snowflake-managed Iceberg tables';

-- 3. Grant the integration's app access to the landing container.
--    a. Run the DESC below and copy AZURE_CONSENT_URL and AZURE_MULTI_TENANT_APP_NAME.
--    b. Open AZURE_CONSENT_URL in a browser as an admin of the tenant and accept.
--    c. Azure portal -> storage account <STORAGE_ACCOUNT> -> Containers -> <LANDING_CONTAINER> -> Access control (IAM)
--       -> Add role assignment -> Storage Blob Data Reader -> Members: search for the service principal named
--       AZURE_MULTI_TENANT_APP_NAME up to the underscore.
DESC STORAGE INTEGRATION ECH_AZURE_INT;

-- 4. Grant the volume's app write access to the Iceberg container.
--    a. Run the DESC below: the STORAGE_LOCATION_1 value is JSON with AZURE_CONSENT_URL and AZURE_MULTI_TENANT_APP_NAME
--       (often the same app as in step 3, in which case the consent is already given).
--    b. Open AZURE_CONSENT_URL as a tenant admin and accept, if it is a different app.
--    c. Container <ICEBERG_CONTAINER> -> Access control (IAM) -> Add role assignment -> Storage Blob Data Contributor
--       -> the service principal named AZURE_MULTI_TENANT_APP_NAME up to the underscore.
--    Role assignments can take a few minutes to apply.
DESC EXTERNAL VOLUME ECH_AZURE_ICEBERG_VOL;

-- 5. Let the hub's role use both (the hub's read-only validation and the generated pipeline both need USAGE).
GRANT USAGE ON INTEGRATION ECH_AZURE_INT TO ROLE ECH_HUB_ROLE;
GRANT USAGE ON EXTERNAL VOLUME ECH_AZURE_ICEBERG_VOL TO ROLE ECH_HUB_ROLE;

-- 6. Once the role assignments are in place: both must succeed before the pipeline's apply and load.
SELECT SYSTEM$VALIDATE_STORAGE_INTEGRATION(
  'ECH_AZURE_INT', 'azure://<STORAGE_ACCOUNT>.blob.core.windows.net/<LANDING_CONTAINER>/', 'validate_ech.txt', 'list'
);
SELECT SYSTEM$VERIFY_EXTERNAL_VOLUME('ECH_AZURE_ICEBERG_VOL');

-- 7. Optional: only if the generated pipeline will run as ECH_HUB_ROLE. Its setup creates the OMNICLAIM database
--    and BRONZE schema when they are missing, and its schedule step resumes a task.
-- GRANT CREATE DATABASE ON ACCOUNT TO ROLE ECH_HUB_ROLE;
-- GRANT EXECUTE TASK ON ACCOUNT TO ROLE ECH_HUB_ROLE;

-- 8. Then answer KAN-3 in Jira with the names, so the hub plans against them (an Azure container name has
--    lower-case letters, digits and hyphens only):
--    /answer storage account <STORAGE_ACCOUNT>, container named <LANDING_CONTAINER>,
--            storage integration ECH_AZURE_INT, external volume ECH_AZURE_ICEBERG_VOL
