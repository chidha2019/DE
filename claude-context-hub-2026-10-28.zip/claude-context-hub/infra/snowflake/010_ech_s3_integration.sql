-- =============================================================================
-- Snowflake side of the CSV -> S3 -> Snowflake-managed Iceberg pipeline. Run as ACCOUNTADMIN.
-- Bucket de-context-hub-bucket (us-east-2, the account's own region, AWS_US_EAST_2):
--   policies/   landing prefix for the CSV files (external stage)
--   iceberg/    data of Snowflake-managed Iceberg tables (external volume); INSURANCE.BRONZE.POLICY
--               lands under iceberg/bronze/policy/
-- Replace <AWS_ACCOUNT_ID> and the role name with the IAM role created from infra/aws/*.json.
-- =============================================================================

-- 1. The integration that lets stages read the landing prefix.
CREATE STORAGE INTEGRATION IF NOT EXISTS ECH_S3_INT
  TYPE = EXTERNAL_STAGE
  STORAGE_PROVIDER = 'S3'
  ENABLED = TRUE
  STORAGE_AWS_ROLE_ARN = 'arn:aws:iam::<AWS_ACCOUNT_ID>:role/snowflake-ech-role'
  STORAGE_ALLOWED_LOCATIONS = ('s3://de-context-hub-bucket/policies/');

-- 2. The external volume Iceberg tables store their data in.
CREATE EXTERNAL VOLUME IF NOT EXISTS ECH_ICEBERG_VOL
  STORAGE_LOCATIONS = (
    (
      NAME = 'ech-iceberg-us-east-2'
      STORAGE_PROVIDER = 'S3'
      STORAGE_BASE_URL = 's3://de-context-hub-bucket/iceberg/'
      STORAGE_AWS_ROLE_ARN = 'arn:aws:iam::<AWS_ACCOUNT_ID>:role/snowflake-ech-role'
    )
  );

-- 3. What AWS must trust: copy STORAGE_AWS_IAM_USER_ARN and STORAGE_AWS_EXTERNAL_ID from both
--    results into infra/aws/snowflake-trust-policy.json, then update the role's trust policy.
DESC STORAGE INTEGRATION ECH_S3_INT;
DESC EXTERNAL VOLUME ECH_ICEBERG_VOL;   -- the STORAGE_LOCATION_1 value is JSON with the same two fields

-- 4. Let the hub's role use both.
GRANT USAGE ON INTEGRATION ECH_S3_INT TO ROLE ECH_HUB_ROLE;
GRANT USAGE ON EXTERNAL VOLUME ECH_ICEBERG_VOL TO ROLE ECH_HUB_ROLE;

-- 5. After the trust policy is in place: both must succeed before the pipeline's apply/load.
SELECT SYSTEM$VERIFY_EXTERNAL_VOLUME('ECH_ICEBERG_VOL');
SELECT SYSTEM$VALIDATE_STORAGE_INTEGRATION('ECH_S3_INT', 's3://de-context-hub-bucket/policies/', 'validate_all.txt', 'all');
