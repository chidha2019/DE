#!/bin/sh
# Refuse to start without the three Grafana Cloud settings, with a message that says what to set.
# (A compose-level `${VAR:?}` would break every compose command while the vars are unset, even
# though the alloy service sits behind the "observability" profile; this keeps the check local.)
set -eu

missing=""
for name in GRAFANA_CLOUD_PROM_URL GRAFANA_CLOUD_PROM_USER GRAFANA_CLOUD_PROM_TOKEN; do
  eval "value=\${$name:-}"
  if [ -z "$value" ]; then
    missing="$missing $name"
  fi
done

if [ -n "$missing" ]; then
  echo "alloy: not starting; set$missing in .env (see .env.example, section 'Ship the hub's own metrics to Grafana Cloud')." >&2
  exit 1
fi

exec alloy run \
  --server.http.listen-addr=0.0.0.0:12345 \
  --storage.path=/var/lib/alloy/data \
  /etc/alloy/config.alloy
