-- 0023: a persona's digital worker. worker_items holds the work it picked up from the hub's own signals, one row
-- per signal (a signal seen again is the same item); worker_journal is its append-only log, each entry hashed over
-- the one before it so an edited entry breaks the chain; worker_state remembers whether it is paused.
CREATE TABLE IF NOT EXISTS worker_items (
    key         TEXT PRIMARY KEY,
    worker      TEXT NOT NULL,
    skill       TEXT NOT NULL,
    title       TEXT NOT NULL,
    detail      TEXT NOT NULL DEFAULT '',
    status      TEXT NOT NULL CHECK (status IN ('detected', 'diagnosed', 'waiting', 'running', 'done', 'failed', 'dismissed')),
    tier        TEXT NOT NULL CHECK (tier IN ('T0', 'T1', 'T2', 'T3')),
    action      JSONB,
    evidence    JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    decided_by  TEXT,
    decided_at  TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS worker_items_by_status ON worker_items (worker, status, updated_at DESC);

CREATE TABLE IF NOT EXISTS worker_journal (
    id          BIGSERIAL PRIMARY KEY,
    worker      TEXT NOT NULL,
    at          TIMESTAMPTZ NOT NULL,
    kind        TEXT NOT NULL CHECK (kind IN ('shift', 'observed', 'diagnosed', 'proposed', 'approved', 'acted', 'done', 'failed', 'dismissed')),
    item_key    TEXT,
    skill       TEXT,
    message     TEXT NOT NULL,
    evidence    JSONB NOT NULL DEFAULT '{}'::jsonb,
    prev_hash   TEXT,
    record_hash TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS worker_journal_recent ON worker_journal (worker, id DESC);

CREATE TABLE IF NOT EXISTS worker_state (
    worker     TEXT PRIMARY KEY,
    paused     BOOLEAN NOT NULL DEFAULT false,
    last_tick  TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
