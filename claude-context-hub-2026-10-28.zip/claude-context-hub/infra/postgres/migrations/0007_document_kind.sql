-- =============================================================================
-- Migration 0007 — Document kind
--
-- Every catalog asset is stored as a document so it can be chunked, embedded,
-- graphed and cited, but to a reader a table is a dataset, not a page. `kind`
-- makes the distinction explicit: 'document' (pages, files, code) or 'dataset'
-- (tables, views, metric views that also have a row in semantic_assets).
-- The pipeline sets it on every upsert; this backfills what is already indexed.
-- =============================================================================

ALTER TABLE documents
    ADD COLUMN IF NOT EXISTS kind TEXT NOT NULL DEFAULT 'document'
        CHECK (kind IN ('document', 'dataset'));

UPDATE documents d
   SET kind = 'dataset'
 WHERE d.kind <> 'dataset'
   AND EXISTS (SELECT 1 FROM semantic_assets a WHERE a.id = d.id);

CREATE INDEX IF NOT EXISTS documents_kind_idx ON documents (kind) WHERE deleted_at IS NULL;
