-- =============================================================================
-- Migration 0002 — vector embeddings (pgvector)
--
-- One embedding per chunk. The dimension is fixed at 1536 to match
-- OpenAI text-embedding-3-small; other providers must project/pad to 1536
-- (zero-padding preserves cosine similarity, see ech_core.embeddings).
--
-- Index: HNSW with cosine distance. Parameters:
--   m = 16              connections per layer (recall/memory trade-off)
--   ef_construction=128 build-time candidate list (higher = better graph)
-- Query time: SET LOCAL hnsw.ef_search = N (set by the repository per query).
-- =============================================================================

CREATE TABLE IF NOT EXISTS embeddings (
    chunk_id    UUID PRIMARY KEY REFERENCES chunks(id) ON DELETE CASCADE,
    model       TEXT NOT NULL,                 -- provider:model identifier
    dimensions  INTEGER NOT NULL CHECK (dimensions > 0 AND dimensions <= 1536),
    embedding   vector(1536) NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS embeddings_hnsw_cosine_idx
    ON embeddings USING hnsw (embedding vector_cosine_ops)
    WITH (m = 16, ef_construction = 128);

CREATE INDEX IF NOT EXISTS embeddings_model_idx ON embeddings (model);

COMMENT ON TABLE embeddings IS 'Dense vectors for chunks; cosine HNSW index. 1 row per chunk.';
