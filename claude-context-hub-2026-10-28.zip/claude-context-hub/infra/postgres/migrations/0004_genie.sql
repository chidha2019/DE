-- =============================================================================
-- Migration 0004 — Genie: curated spaces, conversations and messages
--
-- A *space* scopes what Genie may read (RetrievalFilters as JSONB), adds standing
-- instructions and sample questions, like a Databricks Genie space curates tables.
-- Conversations and messages persist every answer with its citations, trace
-- (tool calls, Cypher executed), follow-ups, token usage and user feedback.
-- =============================================================================

CREATE TABLE IF NOT EXISTS genie_spaces (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name             TEXT NOT NULL,
    description      TEXT NOT NULL DEFAULT '',
    -- standing guidance appended to the system prompt for this space
    instructions     TEXT NOT NULL DEFAULT '',
    -- ech_core.schemas.context.RetrievalFilters: {source_systems, document_ids, attributes}
    filters          JSONB NOT NULL DEFAULT '{}'::jsonb,
    sample_questions JSONB NOT NULL DEFAULT '[]'::jsonb,
    is_default       BOOLEAN NOT NULL DEFAULT false,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- at most one default space
CREATE UNIQUE INDEX IF NOT EXISTS genie_spaces_default_idx ON genie_spaces (is_default)
    WHERE is_default;

DROP TRIGGER IF EXISTS trg_genie_spaces_updated_at ON genie_spaces;
CREATE TRIGGER trg_genie_spaces_updated_at
    BEFORE UPDATE ON genie_spaces
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS genie_conversations (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    space_id    UUID NOT NULL REFERENCES genie_spaces (id) ON DELETE CASCADE,
    title       TEXT NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS genie_conversations_space_idx
    ON genie_conversations (space_id, updated_at DESC);

DROP TRIGGER IF EXISTS trg_genie_conversations_updated_at ON genie_conversations;
CREATE TRIGGER trg_genie_conversations_updated_at
    BEFORE UPDATE ON genie_conversations
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS genie_messages (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id  UUID NOT NULL REFERENCES genie_conversations (id) ON DELETE CASCADE,
    role             TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
    content          TEXT NOT NULL,
    status           TEXT NOT NULL DEFAULT 'complete'
                     CHECK (status IN ('complete', 'error', 'cancelled')),
    error            TEXT,
    -- [{marker, chunk_id, document_id, title, path, source_system, uri, score, chunk_index, snippet}]
    citations        JSONB NOT NULL DEFAULT '[]'::jsonb,
    -- [{step, tool, summary, input, detail, ok, duration_ms, rows, narration}]
    trace            JSONB NOT NULL DEFAULT '[]'::jsonb,
    follow_ups       JSONB NOT NULL DEFAULT '[]'::jsonb,
    usage            JSONB NOT NULL DEFAULT '{}'::jsonb,
    model            TEXT,
    latency_ms       INTEGER,
    feedback         SMALLINT CHECK (feedback IN (-1, 1)),
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS genie_messages_conversation_idx
    ON genie_messages (conversation_id, created_at, id);

-- -----------------------------------------------------------------------------
-- The default space: everything the hub has indexed.
-- -----------------------------------------------------------------------------
INSERT INTO genie_spaces (id, name, description, instructions, filters, sample_questions, is_default)
VALUES (
    '00000000-0000-4000-8000-000000000001',
    'Everything in the hub',
    'Every source the hub has indexed: documents, code, their entities and lineage.',
    '',
    '{}'::jsonb,
    '["Which technologies does the knowledge base mention most, and where?",
      "Who are the main contributors and what did they work on?",
      "Summarise the architecture described in the indexed documents.",
      "Which documents reference each other the most?"]'::jsonb,
    true
)
ON CONFLICT (id) DO NOTHING;
