-- =============================================================================
-- Migration 0011 — Business glossary, insurance domain taxonomy and KPIs
--
-- semantic_domains     a two-level taxonomy of business domains, aligned to the ACORD
--                      capability model for insurance; party, contract and money concepts
--                      reference FIBO. `standard` says where a node comes from.
-- semantic_terms       canonical business terms with definitions and synonyms; seeded here,
--                      curated in the UI (status). `kind` says what a term names.
-- semantic_term_links  a term applied to a dataset, a column or a metric, with confidence,
--                      provenance (rule | model | curated) and the same review states as
--                      enrichment. Accepting a link copies the term's synonyms onto the
--                      column or metric and sets the dataset's domain.
-- semantic_kpis        business KPI definitions: grain, period, unit, direction and targets,
--                      optionally bound to a governed metric.
-- semantic_assets.domain_key  the business domain a dataset belongs to.
-- Everything here is reference vocabulary: idempotent and safe to re-run.
-- =============================================================================

CREATE TABLE IF NOT EXISTS semantic_domains (
    key          TEXT PRIMARY KEY,
    name         TEXT NOT NULL,
    parent_key   TEXT REFERENCES semantic_domains(key) ON DELETE SET NULL,
    description  TEXT NOT NULL DEFAULT '',
    standard     TEXT NOT NULL DEFAULT 'hub' CHECK (standard IN ('acord', 'fibo', 'hub')),
    standard_ref TEXT NOT NULL DEFAULT '',
    sort_order   INT  NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS semantic_terms (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    key          TEXT NOT NULL UNIQUE,
    name         TEXT NOT NULL,
    definition   TEXT NOT NULL DEFAULT '',
    domain_key   TEXT REFERENCES semantic_domains(key) ON DELETE SET NULL,
    kind         TEXT NOT NULL DEFAULT 'entity'
                 CHECK (kind IN ('entity', 'attribute', 'measure', 'event', 'code')),
    synonyms     JSONB NOT NULL DEFAULT '[]'::jsonb,
    standard     TEXT NOT NULL DEFAULT 'hub' CHECK (standard IN ('acord', 'fibo', 'hub')),
    standard_ref TEXT NOT NULL DEFAULT '',
    status       TEXT NOT NULL DEFAULT 'seeded' CHECK (status IN ('seeded', 'curated')),
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS semantic_terms_domain_idx ON semantic_terms (domain_key);

CREATE TABLE IF NOT EXISTS semantic_term_links (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    term_id     UUID NOT NULL REFERENCES semantic_terms(id) ON DELETE CASCADE,
    target_type TEXT NOT NULL CHECK (target_type IN ('asset', 'field', 'metric')),
    target_id   UUID NOT NULL,
    confidence  REAL NOT NULL DEFAULT 0,
    source      TEXT NOT NULL CHECK (source IN ('rule', 'model', 'curated')),
    status      TEXT NOT NULL DEFAULT 'suggested'
                CHECK (status IN ('suggested', 'accepted', 'rejected')),
    rationale   TEXT NOT NULL DEFAULT '',
    model       TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    decided_at  TIMESTAMPTZ,
    UNIQUE (term_id, target_type, target_id)
);
CREATE INDEX IF NOT EXISTS semantic_term_links_target_idx ON semantic_term_links (target_type, target_id);
CREATE INDEX IF NOT EXISTS semantic_term_links_status_idx ON semantic_term_links (status);

CREATE TABLE IF NOT EXISTS semantic_kpis (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    key          TEXT NOT NULL UNIQUE,
    name         TEXT NOT NULL,
    domain_key   TEXT REFERENCES semantic_domains(key) ON DELETE SET NULL,
    term_id      UUID REFERENCES semantic_terms(id) ON DELETE SET NULL,
    metric_id    UUID REFERENCES semantic_metrics(id) ON DELETE SET NULL,
    definition   TEXT NOT NULL DEFAULT '',
    formula      TEXT NOT NULL DEFAULT '',
    grain        TEXT NOT NULL DEFAULT '',
    period       TEXT NOT NULL DEFAULT 'monthly',
    unit         TEXT NOT NULL DEFAULT 'ratio',
    direction    TEXT NOT NULL DEFAULT 'higher' CHECK (direction IN ('higher', 'lower')),
    target_value DOUBLE PRECISION,
    warn_value   DOUBLE PRECISION,
    owner        TEXT NOT NULL DEFAULT '',
    standard_ref TEXT NOT NULL DEFAULT '',
    status       TEXT NOT NULL DEFAULT 'seeded' CHECK (status IN ('seeded', 'curated')),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE semantic_assets
    ADD COLUMN IF NOT EXISTS domain_key TEXT REFERENCES semantic_domains(key) ON DELETE SET NULL;

-- ---------------------------------------------------------------------------
-- Domains: ACORD capability-model areas, two levels deep.
-- ---------------------------------------------------------------------------
INSERT INTO semantic_domains (key, name, parent_key, description, standard, standard_ref, sort_order) VALUES
  ('party',        'Party & Customer',               NULL, 'People and organisations the insurer deals with: customers, insureds, beneficiaries, applicants.', 'acord', 'ACORD IM: Party; FIBO FND Parties', 10),
  ('customer',     'Customer',                       'party', 'The party that buys and owns insurance contracts.', 'acord', 'ACORD IM: Customer', 11),
  ('applicant',    'Applicant & Risk Profile',       'party', 'People applying for cover and the risk information gathered about them.', 'acord', 'ACORD IM: Applicant', 12),
  ('product',      'Product & Coverage',             NULL, 'Insurance products, plans, coverages and riders as designed and priced.', 'acord', 'ACORD capability: Product Development', 20),
  ('distribution', 'Distribution & Sales',           NULL, 'Producers, agencies, channels, quotes and the commissions they earn.', 'acord', 'ACORD capability: Distribution', 30),
  ('underwriting', 'Underwriting & New Business',    NULL, 'Applications, risk assessment, underwriting decisions and issue.', 'acord', 'ACORD capability: Underwriting', 40),
  ('policy',       'Policy Administration',          NULL, 'The in-force contract through its life: issue, changes, renewal, lapse, surrender, maturity.', 'acord', 'ACORD capability: Policy Administration; FIBO FND Contracts', 50),
  ('policy_lifecycle', 'Policy Lifecycle Events',    'policy', 'Issue, endorsement, renewal, reinstatement, lapse, surrender and termination events.', 'acord', 'ACORD IM: Policy events', 51),
  ('inforce',      'In-force Portfolio',             'policy', 'The book of active contracts and its values at a point in time.', 'acord', 'ACORD IM: Policy', 52),
  ('billing',      'Billing & Collections',          NULL, 'Invoicing, premium collection, payment allocation and arrears.', 'acord', 'ACORD capability: Billing', 60),
  ('claims',       'Claims',                         NULL, 'Notification, adjudication, reserving and payment of claims.', 'acord', 'ACORD capability: Claims', 70),
  ('fnol',         'Notification & Intake',          'claims', 'First notice of loss and claim registration.', 'acord', 'ACORD IM: Claim notification', 71),
  ('adjudication', 'Adjudication & Payment',         'claims', 'Assessment, decision and settlement of claims, including service lines.', 'acord', 'ACORD IM: Claim settlement', 72),
  ('claims_reserving', 'Claim Reserves',             'claims', 'Case and incurred-but-not-reported reserves held for open claims.', 'acord', 'ACORD IM: Claim reserve', 73),
  ('reinsurance',  'Reinsurance',                    NULL, 'Treaties, cessions and retentions with reinsurers.', 'acord', 'ACORD capability: Reinsurance', 80),
  ('actuarial',    'Actuarial, Valuation & Experience', NULL, 'Reserving, valuation and experience studies such as lapse and mortality.', 'acord', 'ACORD capability: Actuarial', 90),
  ('valuation',    'Valuation & Reserving',          'actuarial', 'Statutory and economic reserves, cash values and the assumptions behind them.', 'acord', 'ACORD capability: Actuarial', 91),
  ('experience',   'Experience Studies',             'actuarial', 'Actual-to-expected analysis of lapse, mortality and other decrements.', 'hub', '', 92),
  ('finance',      'Finance & Accounting',           NULL, 'Premium and claims accounting, expenses, ratios and currency.', 'acord', 'ACORD capability: Finance; FIBO FND Accounting', 100),
  ('service',      'Customer Service & Operations',  NULL, 'Service cases, complaints and interactions.', 'acord', 'ACORD capability: Customer Service', 110),
  ('risk',         'Risk & Compliance',              NULL, 'Personal data, identity verification and regulatory obligations.', 'hub', '', 120),
  ('data_platform','Data Platform',                  NULL, 'Technical columns and datasets that exist for ingestion, lineage and control, not for the business.', 'hub', '', 130)
ON CONFLICT (key) DO NOTHING;

-- ---------------------------------------------------------------------------
-- Terms: canonical insurance vocabulary with synonyms. Apostrophes avoided on purpose.
-- ---------------------------------------------------------------------------
INSERT INTO semantic_terms (key, name, domain_key, kind, synonyms, definition, standard, standard_ref)
SELECT v.key, v.name, v.domain_key, v.kind, v.synonyms::jsonb, v.definition, v.standard, v.standard_ref
FROM (VALUES
  ('party', 'Party', 'party', 'entity', '["party","legal entity","person or organisation"]', 'A person or organisation that plays a role in an insurance relationship.', 'fibo', 'fibo-fnd-pty-pty:Party'),
  ('customer', 'Customer', 'customer', 'entity', '["customer","client","account holder","policy owner"]', 'The party that buys insurance and owns the relationship with the insurer.', 'acord', 'ACORD IM: Customer'),
  ('policyholder', 'Policyholder', 'customer', 'entity', '["policyholder","policy owner","owner","contract owner","contract holder"]', 'The party that owns a policy and holds its rights and obligations.', 'acord', 'ACORD IM: Policyholder'),
  ('insured', 'Insured', 'party', 'entity', '["insured","life assured","life insured","covered person","member"]', 'The person or object whose life, health or property the policy covers.', 'acord', 'ACORD IM: Insured'),
  ('beneficiary', 'Beneficiary', 'party', 'entity', '["beneficiary","payee","nominee"]', 'The party entitled to receive benefits when a covered event occurs.', 'acord', 'ACORD IM: Beneficiary'),
  ('applicant', 'Applicant', 'applicant', 'entity', '["applicant","proposer","prospect"]', 'A person applying for cover before a policy is issued.', 'acord', 'ACORD IM: Applicant'),
  ('household', 'Household', 'customer', 'entity', '["household","family unit"]', 'A group of customers who live together and are treated as one relationship.', 'hub', ''),
  ('employer_group', 'Employer Group', 'customer', 'entity', '["employer","group","plan sponsor","group policyholder"]', 'An employer or association that sponsors group insurance for its members.', 'acord', 'ACORD IM: Group'),
  ('member', 'Member', 'party', 'entity', '["member","plan member","certificate holder","enrollee"]', 'A person covered under a group policy, usually holding a certificate.', 'acord', 'ACORD IM: Member'),
  ('product', 'Product', 'product', 'entity', '["product","insurance product","plan"]', 'A designed and priced insurance offering that policies are issued under.', 'acord', 'ACORD IM: Product'),
  ('line_of_business', 'Line of Business', 'product', 'code', '["line of business","lob","business line","product line"]', 'The top-level grouping of products, such as life, health, annuity or property.', 'acord', 'ACORD IM: LineOfBusiness'),
  ('coverage', 'Coverage', 'product', 'entity', '["coverage","cover","benefit","protection"]', 'A specific promise within a policy: what is covered, for how much, under which conditions.', 'acord', 'ACORD IM: Coverage'),
  ('rider', 'Rider', 'product', 'entity', '["rider","optional benefit","supplementary benefit","endorsement benefit"]', 'An optional coverage attached to a base policy.', 'acord', 'ACORD IM: Rider'),
  ('plan_code', 'Plan Code', 'product', 'code', '["plan code","product code","plan id"]', 'The code identifying a product or plan on the administration system.', 'hub', ''),
  ('benefit_amount', 'Benefit Amount', 'product', 'measure', '["benefit amount","sum assured","face amount","face value","death benefit","coverage amount","sum insured"]', 'The amount payable when the covered event occurs.', 'acord', 'ACORD IM: CoverageAmount'),
  ('producer', 'Producer', 'distribution', 'entity', '["producer","agent","broker","advisor","adviser","intermediary"]', 'The licensed person or firm that sells and services policies.', 'acord', 'ACORD IM: Producer'),
  ('agency', 'Agency', 'distribution', 'entity', '["agency","brokerage","distributor","firm"]', 'The organisation a producer belongs to.', 'acord', 'ACORD IM: Agency'),
  ('channel', 'Channel', 'distribution', 'code', '["channel","distribution channel","sales channel"]', 'How a policy was sold: agent, broker, direct, bank or online.', 'acord', 'ACORD IM: DistributionChannel'),
  ('commission', 'Commission', 'distribution', 'measure', '["commission","producer compensation","commission amount"]', 'Compensation paid to a producer for selling or servicing a policy.', 'acord', 'ACORD IM: Commission'),
  ('bank_branch', 'Bank Branch', 'distribution', 'entity', '["bank branch","branch","branch directory"]', 'A bank branch acting as a distribution point for bancassurance.', 'hub', ''),
  ('application', 'Application', 'underwriting', 'entity', '["application","proposal","proposal form"]', 'The request for cover submitted by an applicant, with the information needed to underwrite it.', 'acord', 'ACORD IM: Application'),
  ('quote', 'Quote', 'underwriting', 'entity', '["quote","quotation","illustration"]', 'A priced offer of cover before an application is bound.', 'acord', 'ACORD IM: Quote'),
  ('underwriting_decision', 'Underwriting Decision', 'underwriting', 'event', '["underwriting decision","decision","approval","decline","rating decision"]', 'The outcome of risk assessment: approve, rate, postpone or decline.', 'acord', 'ACORD IM: UnderwritingDecision'),
  ('risk_class', 'Risk Class', 'applicant', 'code', '["risk class","rate class","underwriting class","applicant risk","risk rating"]', 'The underwriting classification that determines the premium rate.', 'acord', 'ACORD IM: RiskClass'),
  ('medical_exam', 'Medical Exam', 'underwriting', 'event', '["medical exam","paramedical","medical requirement"]', 'A medical requirement gathered to underwrite an application.', 'acord', 'ACORD IM: MedicalRequirement'),
  ('policy', 'Policy', 'policy', 'entity', '["policy","contract","policy contract","certificate","insurance contract"]', 'The contract between the insurer and the policyholder that sets out cover, premium and term.', 'acord', 'ACORD IM: Policy; fibo-fnd-agr-ctr:Contract'),
  ('policy_number', 'Policy Number', 'policy', 'attribute', '["policy number","policy id","policy no","contract number","contract id"]', 'The identifier of a policy on the administration system.', 'acord', 'ACORD IM: PolicyNumber'),
  ('policy_status', 'Policy Status', 'policy', 'attribute', '["policy status","contract status","status"]', 'Where the contract is in its life: pending, in force, lapsed, surrendered, matured, terminated.', 'acord', 'ACORD IM: PolicyStatus'),
  ('effective_date', 'Effective Date', 'policy', 'attribute', '["effective date","issue date","inception date","start date","commencement date"]', 'The date cover under the policy begins.', 'acord', 'ACORD IM: EffectiveDate'),
  ('expiry_date', 'Expiry Date', 'policy', 'attribute', '["expiry date","expiration date","maturity date","end date","termination date"]', 'The date cover under the policy ends.', 'acord', 'ACORD IM: ExpirationDate'),
  ('policy_term', 'Policy Term', 'policy', 'attribute', '["policy term","term","duration","coverage period"]', 'The length of time the policy provides cover.', 'acord', 'ACORD IM: PolicyTerm'),
  ('inforce_policy', 'In-force Policy', 'inforce', 'entity', '["in-force","inforce","active policy","in force"]', 'A policy whose cover is currently active.', 'acord', 'ACORD IM: Policy (in force)'),
  ('lapse', 'Lapse', 'policy_lifecycle', 'event', '["lapse","lapsed","lapsed policy","non-payment termination"]', 'Termination of a policy because premiums stopped being paid.', 'acord', 'ACORD IM: Lapse'),
  ('surrender', 'Surrender', 'policy_lifecycle', 'event', '["surrender","cash surrender","voluntary termination"]', 'Termination of a policy at the policyholder request, usually for its cash value.', 'acord', 'ACORD IM: Surrender'),
  ('renewal', 'Renewal', 'policy_lifecycle', 'event', '["renewal","policy renewal","renewed"]', 'Continuation of a policy into a new term.', 'acord', 'ACORD IM: Renewal'),
  ('endorsement', 'Endorsement', 'policy_lifecycle', 'event', '["endorsement","policy change","amendment","mid-term change"]', 'A change to the terms of a policy during its life.', 'acord', 'ACORD IM: Endorsement'),
  ('reinstatement', 'Reinstatement', 'policy_lifecycle', 'event', '["reinstatement","reinstated"]', 'Restoring a lapsed policy to in-force status.', 'acord', 'ACORD IM: Reinstatement'),
  ('premium', 'Premium', 'policy', 'measure', '["premium","gross premium","modal premium","premium amount","premium due"]', 'The amount the policyholder pays for cover.', 'acord', 'ACORD IM: Premium; fibo-fnd-acc-cur:MonetaryAmount'),
  ('annualized_premium', 'Annualized Premium', 'policy', 'measure', '["annualized premium","annualised premium","ape","annual premium equivalent"]', 'The premium expressed on an annual basis, used to compare policies with different payment modes.', 'acord', 'ACORD IM: AnnualizedPremium'),
  ('premium_mode', 'Premium Mode', 'billing', 'code', '["premium mode","payment frequency","billing frequency","payment mode"]', 'How often premium is paid: monthly, quarterly, annually or single.', 'acord', 'ACORD IM: PaymentMode'),
  ('cash_value', 'Cash Value', 'inforce', 'measure', '["cash value","surrender value","account value","fund value"]', 'The savings element of a policy available on surrender.', 'acord', 'ACORD IM: CashValue'),
  ('reserve', 'Reserve', 'valuation', 'measure', '["reserve","statutory reserve","policy reserve","liability","technical provision"]', 'The amount held to meet future obligations under in-force policies.', 'acord', 'ACORD IM: Reserve'),
  ('invoice', 'Invoice', 'billing', 'entity', '["invoice","bill","billing statement","premium notice"]', 'A request for premium payment sent to the payer.', 'acord', 'ACORD IM: Invoice'),
  ('payment', 'Payment', 'billing', 'event', '["payment","premium payment","receipt","remittance","collection"]', 'Money received against a premium due.', 'acord', 'ACORD IM: Payment'),
  ('payment_due_date', 'Payment Due Date', 'billing', 'attribute', '["due date","payment due date","bill due date"]', 'The date by which a premium must be paid.', 'acord', 'ACORD IM: DueDate'),
  ('arrears', 'Arrears', 'billing', 'measure', '["arrears","overdue","past due","outstanding balance","outstanding premium"]', 'Premium that is due and unpaid.', 'acord', 'ACORD IM: Arrears'),
  ('claim', 'Claim', 'claims', 'entity', '["claim","loss","claim case","benefit claim"]', 'A request for payment under a policy following a covered event.', 'acord', 'ACORD IM: Claim'),
  ('claim_number', 'Claim Number', 'claims', 'attribute', '["claim number","claim id","claim no","claim reference"]', 'The identifier of a claim on the claims system.', 'acord', 'ACORD IM: ClaimNumber'),
  ('claim_status', 'Claim Status', 'claims', 'attribute', '["claim status","claim state"]', 'Where the claim is in its life: reported, open, approved, paid, denied, closed.', 'acord', 'ACORD IM: ClaimStatus'),
  ('loss_date', 'Loss Date', 'fnol', 'attribute', '["loss date","date of loss","event date","incident date","date of death"]', 'The date the covered event happened.', 'acord', 'ACORD IM: LossDate'),
  ('notification_date', 'Notification Date', 'fnol', 'attribute', '["notification date","fnol date","reported date","report date","submitted date"]', 'The date the insurer was told about the claim.', 'acord', 'ACORD IM: ReportedDate'),
  ('claim_reserve', 'Claim Reserve', 'claims_reserving', 'measure', '["claim reserve","case reserve","outstanding claim","outstanding reserve"]', 'The amount set aside for an open claim.', 'acord', 'ACORD IM: ClaimReserve'),
  ('claim_payment', 'Claim Payment', 'adjudication', 'measure', '["claim payment","benefit payment","indemnity","settlement amount","paid amount","claim paid"]', 'Money paid to settle all or part of a claim.', 'acord', 'ACORD IM: ClaimPayment'),
  ('claim_adjuster', 'Claim Adjuster', 'adjudication', 'entity', '["adjuster","claims handler","claims examiner","assessor"]', 'The person who assesses and decides a claim.', 'acord', 'ACORD IM: Adjuster'),
  ('cause_of_loss', 'Cause of Loss', 'fnol', 'code', '["cause of loss","peril","cause of death","loss cause","diagnosis"]', 'What caused the covered event.', 'acord', 'ACORD IM: CauseOfLoss'),
  ('service_line', 'Service Line', 'adjudication', 'entity', '["service line","claim line","line item","procedure line"]', 'One service or item within a claim, with its own amount and decision.', 'hub', ''),
  ('decision_days', 'Decision Days', 'adjudication', 'measure', '["decision days","days to decision","cycle time","turnaround time","time to decision"]', 'Elapsed days between claim submission and decision.', 'hub', ''),
  ('reinsurance_treaty', 'Reinsurance Treaty', 'reinsurance', 'entity', '["treaty","reinsurance treaty","reinsurance agreement"]', 'An agreement under which a reinsurer takes on part of the insurer risk.', 'acord', 'ACORD IM: ReinsuranceAgreement'),
  ('cession', 'Cession', 'reinsurance', 'measure', '["cession","ceded","ceded amount","ceded premium"]', 'The part of a risk or premium passed to a reinsurer.', 'acord', 'ACORD IM: Cession'),
  ('retention', 'Retention', 'reinsurance', 'measure', '["retention","retained amount","net retention"]', 'The part of a risk the insurer keeps.', 'acord', 'ACORD IM: Retention'),
  ('reinsurer', 'Reinsurer', 'reinsurance', 'entity', '["reinsurer","assuming company"]', 'The company that accepts ceded risk.', 'acord', 'ACORD IM: Reinsurer'),
  ('valuation_date', 'Valuation Date', 'valuation', 'attribute', '["valuation date","as-of date","as of date","reporting date","snapshot date"]', 'The date at which reserves and values are measured.', 'acord', 'ACORD IM: ValuationDate'),
  ('policy_year', 'Policy Year', 'actuarial', 'attribute', '["policy year","duration year","policy anniversary year","policy duration"]', 'Years since the policy was issued, counted from each anniversary.', 'hub', ''),
  ('study_year', 'Study Year', 'experience', 'attribute', '["study year","experience year","observation year","exposure year"]', 'The calendar or policy year an experience study observes.', 'hub', ''),
  ('exposure', 'Exposure', 'experience', 'measure', '["exposure","exposed to risk","policy years exposed","exposure count","lives exposed"]', 'The amount of risk observed, usually in policy-years or lives.', 'hub', ''),
  ('expected_claims', 'Expected Claims', 'experience', 'measure', '["expected claims","expected deaths","expected lapses","expected"]', 'Claims predicted by the assumption basis for the exposure.', 'hub', ''),
  ('actual_claims', 'Actual Claims', 'experience', 'measure', '["actual claims","actual deaths","observed claims","actual lapses","actual"]', 'Claims actually observed in the study period.', 'hub', ''),
  ('ae_ratio', 'A/E Ratio', 'experience', 'measure', '["a/e ratio","ae ratio","actual to expected","actual over expected","a to e"]', 'Actual divided by expected, the core measure of an experience study.', 'hub', ''),
  ('mortality_rate', 'Mortality Rate', 'experience', 'measure', '["mortality rate","death rate","qx","mortality"]', 'Deaths per unit of exposure.', 'hub', ''),
  ('lapse_rate', 'Lapse Rate', 'experience', 'measure', '["lapse rate","termination rate","decrement rate","lapse ratio"]', 'Lapses per unit of exposure.', 'hub', ''),
  ('persistency', 'Persistency', 'inforce', 'measure', '["persistency","persistency rate","policy retention","retention rate"]', 'The share of policies still in force after a period.', 'acord', 'ACORD IM: Persistency'),
  ('decrement', 'Decrement', 'experience', 'event', '["decrement","termination","exit"]', 'An event that removes a policy from the in-force block: death, lapse, surrender, maturity.', 'hub', ''),
  ('mortality_table', 'Mortality Table', 'valuation', 'code', '["mortality table","mortality basis","assumption table","table"]', 'The table of mortality rates used as an assumption basis.', 'hub', ''),
  ('discount_rate', 'Discount Rate', 'valuation', 'attribute', '["discount rate","valuation interest rate","interest rate"]', 'The rate used to discount future cash flows in a valuation.', 'hub', ''),
  ('earned_premium', 'Earned Premium', 'finance', 'measure', '["earned premium"]', 'The part of written premium that belongs to the cover already provided.', 'acord', 'ACORD IM: EarnedPremium'),
  ('written_premium', 'Written Premium', 'finance', 'measure', '["written premium","gross written premium","gwp"]', 'Premium on policies written in the period, regardless of when it is earned.', 'acord', 'ACORD IM: WrittenPremium'),
  ('incurred_claims', 'Incurred Claims', 'finance', 'measure', '["incurred claims","incurred losses","claims incurred"]', 'Paid claims plus the change in claim reserves for the period.', 'acord', 'ACORD IM: IncurredClaims'),
  ('expense', 'Expense', 'finance', 'measure', '["expense","operating expense","acquisition expense","expenses"]', 'Costs of acquiring and administering policies.', 'acord', 'ACORD IM: Expense'),
  ('loss_ratio', 'Loss Ratio', 'finance', 'measure', '["loss ratio","claims ratio"]', 'Incurred claims divided by earned premium.', 'acord', 'ACORD IM: LossRatio'),
  ('combined_ratio', 'Combined Ratio', 'finance', 'measure', '["combined ratio"]', 'Loss ratio plus expense ratio.', 'acord', 'ACORD IM: CombinedRatio'),
  ('currency', 'Currency', 'finance', 'code', '["currency","currency code","ccy"]', 'The currency an amount is expressed in.', 'fibo', 'fibo-fnd-acc-cur:Currency'),
  ('monetary_amount', 'Monetary Amount', 'finance', 'measure', '["amount","monetary amount","value"]', 'A quantity of money in a currency.', 'fibo', 'fibo-fnd-acc-cur:MonetaryAmount'),
  ('personal_data', 'Personal Data', 'risk', 'attribute', '["pii","personal data","personally identifiable information","sensitive data"]', 'Data that identifies or could identify a person, subject to privacy obligations.', 'hub', ''),
  ('kyc_record', 'KYC Record', 'risk', 'entity', '["kyc","know your customer","identity verification","customer due diligence"]', 'Evidence that a customer identity was verified.', 'hub', ''),
  ('service_case', 'Service Case', 'service', 'entity', '["case","service request","ticket","interaction","service case"]', 'A tracked request from a customer or producer.', 'hub', ''),
  ('complaint', 'Complaint', 'service', 'entity', '["complaint","grievance"]', 'A formal expression of dissatisfaction that must be handled and reported.', 'hub', ''),
  ('source_system', 'Source System', 'data_platform', 'attribute', '["source system","origin system","source system id","source system name"]', 'The system a record was ingested from.', 'hub', ''),
  ('ingestion_timestamp', 'Ingestion Timestamp', 'data_platform', 'attribute', '["ingested at","load timestamp","loaded at","bronze ingested at","ingestion timestamp"]', 'When the platform loaded the record.', 'hub', ''),
  ('record_identifier', 'Record Identifier', 'data_platform', 'attribute', '["object id","record id","surrogate key","row id"]', 'A technical identifier with no business meaning.', 'hub', ''),
  ('source_file', 'Source File', 'data_platform', 'attribute', '["source file","file name","input file"]', 'The file a record was loaded from.', 'hub', '')
) AS v(key, name, domain_key, kind, synonyms, definition, standard, standard_ref)
ON CONFLICT (key) DO NOTHING;

-- ---------------------------------------------------------------------------
-- KPIs: definitions with grain, period, unit, direction and targets.
-- ---------------------------------------------------------------------------
INSERT INTO semantic_kpis (key, name, domain_key, term_id, definition, formula, grain, period, unit, direction, target_value, warn_value, standard_ref)
SELECT v.key, v.name, v.domain_key, t.id, v.definition, v.formula, v.grain, v.period, v.unit, v.direction, v.target_value, v.warn_value, v.standard_ref
FROM (VALUES
  ('loss_ratio', 'Loss Ratio', 'finance', 'loss_ratio', 'Share of earned premium consumed by claims.', 'incurred claims / earned premium', 'portfolio', 'monthly', 'percent', 'lower', 65.0, 75.0, 'ACORD IM: LossRatio'),
  ('combined_ratio', 'Combined Ratio', 'finance', 'combined_ratio', 'Claims plus expenses as a share of earned premium; above 100 the book loses money before investment income.', '(incurred claims + expenses) / earned premium', 'portfolio', 'quarterly', 'percent', 'lower', 100.0, 105.0, 'ACORD IM: CombinedRatio'),
  ('expense_ratio', 'Expense Ratio', 'finance', 'expense', 'Operating and acquisition expenses as a share of earned premium.', 'expenses / earned premium', 'portfolio', 'quarterly', 'percent', 'lower', 30.0, 35.0, ''),
  ('lapse_rate', 'Lapse Rate', 'experience', 'lapse_rate', 'Policies lapsing per unit of exposure in the study year.', 'lapses / exposure', 'policy', 'annual', 'percent', 'lower', 8.0, 10.0, ''),
  ('persistency_13m', '13-Month Persistency', 'inforce', 'persistency', 'Share of policies issued that are still in force after 13 months.', 'policies in force at month 13 / policies issued', 'issue cohort', 'monthly', 'percent', 'higher', 85.0, 80.0, 'ACORD IM: Persistency'),
  ('mortality_ae', 'Mortality A/E Ratio', 'experience', 'ae_ratio', 'Actual deaths against the expected deaths of the assumption basis.', 'actual deaths / expected deaths', 'study', 'annual', 'ratio', 'lower', 1.0, 1.1, ''),
  ('claim_settlement_days', 'Claim Settlement Days', 'adjudication', 'decision_days', 'Average elapsed days from notification to payment.', 'avg(payment date - notification date)', 'claim', 'monthly', 'days', 'lower', 30.0, 45.0, ''),
  ('claims_frequency', 'Claims Frequency', 'claims', 'claim', 'Claims per unit of exposure.', 'claims / exposure', 'policy', 'annual', 'ratio', 'lower', NULL, NULL, ''),
  ('claims_severity', 'Average Claim Severity', 'adjudication', 'claim_payment', 'Average amount paid per claim.', 'claim payments / claims paid', 'claim', 'monthly', 'currency', 'lower', NULL, NULL, ''),
  ('new_business_ape', 'New Business APE', 'distribution', 'annualized_premium', 'Annual premium equivalent of policies issued in the period.', 'sum(annualized premium of new policies)', 'policy', 'monthly', 'currency', 'higher', NULL, NULL, 'ACORD IM: AnnualizedPremium'),
  ('inforce_policies', 'In-force Policy Count', 'inforce', 'inforce_policy', 'Number of policies with active cover at the valuation date.', 'count(policies where status = in force)', 'point-in-time', 'monthly', 'count', 'higher', NULL, NULL, ''),
  ('premium_growth', 'Premium Growth', 'finance', 'written_premium', 'Change in written premium against the prior period.', '(written premium - prior written premium) / prior written premium', 'portfolio', 'quarterly', 'percent', 'higher', 5.0, 0.0, ''),
  ('surrender_rate', 'Surrender Rate', 'policy_lifecycle', 'surrender', 'Policies surrendered as a share of the in-force block.', 'surrenders / in-force policies', 'policy', 'annual', 'percent', 'lower', 5.0, 7.0, ''),
  ('renewal_rate', 'Renewal Rate', 'policy_lifecycle', 'renewal', 'Policies renewed as a share of those due for renewal.', 'renewed / due for renewal', 'policy', 'monthly', 'percent', 'higher', 90.0, 85.0, ''),
  ('commission_ratio', 'Commission Ratio', 'distribution', 'commission', 'Commission paid as a share of written premium.', 'commission / written premium', 'portfolio', 'quarterly', 'percent', 'lower', 15.0, 20.0, ''),
  ('quote_to_bind', 'Quote-to-Bind Ratio', 'underwriting', 'quote', 'Share of quotes that become issued policies.', 'policies issued / quotes', 'quote', 'monthly', 'percent', 'higher', 25.0, 20.0, ''),
  ('reserve_adequacy', 'Reserve Adequacy', 'valuation', 'reserve', 'Reserves held against the liabilities the valuation expects.', 'reserves held / expected liabilities', 'point-in-time', 'quarterly', 'ratio', 'higher', 1.0, 0.95, ''),
  ('arrears_rate', 'Premium Arrears Rate', 'billing', 'arrears', 'Share of in-force policies with premium past due.', 'policies in arrears / in-force policies', 'policy', 'monthly', 'percent', 'lower', 3.0, 5.0, '')
) AS v(key, name, domain_key, term_key, definition, formula, grain, period, unit, direction, target_value, warn_value, standard_ref)
LEFT JOIN semantic_terms t ON t.key = v.term_key
ON CONFLICT (key) DO NOTHING;
