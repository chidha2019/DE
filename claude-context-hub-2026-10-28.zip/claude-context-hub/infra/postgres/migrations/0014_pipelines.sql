-- =============================================================================
-- Pipelines: saved, configurable ingestion definitions on top of a connection.
--
-- A pipeline is a connector (the saved connection, with the credentials configured on the server)
-- plus what to ingest from it (a scope picked in the source's own schema browser), the options a
-- run starts with and a schedule. Runs stay in ingestion_runs and now remember their pipeline.
-- =============================================================================

CREATE TABLE IF NOT EXISTS pipelines (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name           TEXT NOT NULL,
    description    TEXT NOT NULL DEFAULT '',
    connector_name TEXT NOT NULL,
    source_system  source_system NOT NULL,
    -- [{"path": ["INSURANCE", "BRONZE"], "kind": "schema"}, ...]; empty = everything the connection exposes
    scope          JSONB NOT NULL DEFAULT '[]'::jsonb,
    -- run options: full_refresh, limit, chunk_target_tokens, chunk_overlap_tokens
    options        JSONB NOT NULL DEFAULT '{}'::jsonb,
    -- connector-specific switches: include_lineage, include_tags, include_alert_rules, ...
    source_options JSONB NOT NULL DEFAULT '{}'::jsonb,
    -- {"type": "manual" | "interval" | "daily" | "weekly", "every_minutes", "time", "days"}
    schedule       JSONB NOT NULL DEFAULT '{"type": "manual"}'::jsonb,
    enabled        BOOLEAN NOT NULL DEFAULT true,
    owner          TEXT NOT NULL DEFAULT '',
    tags           JSONB NOT NULL DEFAULT '[]'::jsonb,
    next_run_at    TIMESTAMPTZ,
    created_by     TEXT,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS pipelines_name_key ON pipelines (lower(name));
CREATE INDEX IF NOT EXISTS pipelines_connector_idx ON pipelines (connector_name);
CREATE INDEX IF NOT EXISTS pipelines_due_idx ON pipelines (next_run_at)
    WHERE enabled AND next_run_at IS NOT NULL;

DROP TRIGGER IF EXISTS trg_pipelines_updated_at ON pipelines;
CREATE TRIGGER trg_pipelines_updated_at
    BEFORE UPDATE ON pipelines
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

ALTER TABLE ingestion_runs
    ADD COLUMN IF NOT EXISTS pipeline_id UUID REFERENCES pipelines(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS ingestion_runs_pipeline_idx ON ingestion_runs (pipeline_id, created_at DESC)
    WHERE pipeline_id IS NOT NULL;
