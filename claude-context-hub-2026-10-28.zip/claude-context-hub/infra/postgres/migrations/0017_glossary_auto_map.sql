-- =============================================================================
-- Glossary mapping after every successful Snowflake or Databricks sync.
-- glossary_map_state    what Claude last saw of a dataset (a hash of its source metadata), so a
--                       sync sends only new or changed datasets to Claude again.
-- glossary_auto_runs    one automatic mapping pass per source system, with the syncs it covers.
-- glossary_auto_cursor  syncs that finished before this migration are not mapped retroactively.
-- Proposals land in the review queue as before; nothing applies until a person accepts it.
-- =============================================================================

CREATE TABLE IF NOT EXISTS glossary_map_state (
    asset_id     UUID PRIMARY KEY REFERENCES semantic_assets(id) ON DELETE CASCADE,
    fingerprint  TEXT NOT NULL,
    model        TEXT,
    mapped_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS glossary_auto_runs (
    id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_system      source_system NOT NULL,
    ingestion_run_ids  UUID[] NOT NULL,
    status             TEXT NOT NULL DEFAULT 'running' CHECK (status IN ('running', 'completed', 'failed')),
    datasets           INT NOT NULL DEFAULT 0,
    model_datasets     INT NOT NULL DEFAULT 0,
    unchanged          INT NOT NULL DEFAULT 0,
    model_failed       INT NOT NULL DEFAULT 0,
    rule_links         INT NOT NULL DEFAULT 0,
    model_links        INT NOT NULL DEFAULT 0,
    message            TEXT,
    error              TEXT,
    started_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at        TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS glossary_auto_runs_started_idx ON glossary_auto_runs (started_at DESC);

CREATE TABLE IF NOT EXISTS glossary_auto_cursor (
    id     BOOLEAN PRIMARY KEY DEFAULT true CHECK (id),
    since  TIMESTAMPTZ NOT NULL DEFAULT now()
);
INSERT INTO glossary_auto_cursor (id) VALUES (true) ON CONFLICT (id) DO NOTHING;
