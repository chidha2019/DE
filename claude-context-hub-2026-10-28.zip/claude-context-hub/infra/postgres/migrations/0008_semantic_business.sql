-- =============================================================================
-- Migration 0008 — Business names, meanings and model-assisted enrichment
--
-- Assets, columns and metrics carry a business-friendly display name and a
-- one-line summary next to their technical name. `name_source` / `kind_source`
-- say where a name or classification came from: derived (naming rules),
-- declared (the platform), model (accepted Claude suggestion) or curated (edited
-- by a person). `enrichment` holds the latest model suggestion with its status.
-- The pipeline recomputes derived names on every sync but never overwrites
-- model or curated ones; the backfill below names what is already indexed.
-- =============================================================================

ALTER TABLE semantic_assets
    ADD COLUMN IF NOT EXISTS display_name TEXT NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS summary      TEXT NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS name_source  TEXT NOT NULL DEFAULT 'derived'
        CHECK (name_source IN ('derived', 'declared', 'model', 'curated')),
    ADD COLUMN IF NOT EXISTS kind_source  TEXT NOT NULL DEFAULT 'inferred'
        CHECK (kind_source IN ('inferred', 'declared', 'model', 'curated')),
    ADD COLUMN IF NOT EXISTS enrichment   JSONB NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE semantic_fields  ADD COLUMN IF NOT EXISTS display_name TEXT NOT NULL DEFAULT '';
ALTER TABLE semantic_metrics ADD COLUMN IF NOT EXISTS display_name TEXT NOT NULL DEFAULT '';

-- Backfill derived names for everything already indexed (Python naming rules are richer;
-- the next connector run replaces these).
UPDATE semantic_assets
   SET display_name = initcap(replace(
           regexp_replace(
               regexp_replace(name, '^(fact|fct|dim|dims|dimension|mv|bridge|brg|ref|lkp|lookup|stg|raw|src|tbl|vw|v)_', '', 'i'),
               '(_v[0-9]+|_draft|_tbl|_table|_view|_vw)+$', '', 'i'),
           '_', ' '))
 WHERE display_name = '';

UPDATE semantic_assets
   SET summary = left(split_part(description, '. ', 1), 180)
 WHERE summary = '' AND coalesce(description, '') <> '';

UPDATE semantic_assets SET kind_source = 'declared' WHERE asset_type IN ('metric_view', 'semantic_view');

UPDATE semantic_fields  SET display_name = initcap(replace(name, '_', ' ')) WHERE display_name = '';
UPDATE semantic_metrics SET display_name = initcap(replace(name, '_', ' ')) WHERE display_name = '';

CREATE INDEX IF NOT EXISTS semantic_assets_display_name_trgm_idx
    ON semantic_assets USING gin (display_name gin_trgm_ops);
