-- 0020: Jira joins the sources (issues as documents; the same connection feeds the intent service).
-- ALTER TYPE ... ADD VALUE is idempotent with IF NOT EXISTS, like 0010 did for Grafana.
ALTER TYPE source_system ADD VALUE IF NOT EXISTS 'jira';
