-- =============================================================================
-- Line of business as a catalog facet, decided at sync time.
-- semantic_term_values         the values a code term takes. Line of Business: Life and Annuity; aliases
--                              are the spellings found in tags and data (LIFE, ANNUITY ...).
-- semantic_asset_lines         the lines of business a dataset holds and how the sync knows it, first
--                              source that answers wins: a Snowflake tag, the pipeline's default, the
--                              distinct values of a line-of-business column, or inherited from the
--                              datasets it references (POLICY -> PRODUCT_VERSION -> PRODUCT).
--                              A dataset with no row is shared across lines.
-- pipelines.line_of_business   the default for what a pipeline syncs when no tag says otherwise.
-- =============================================================================

CREATE TABLE IF NOT EXISTS semantic_term_values (
    term_key     TEXT NOT NULL REFERENCES semantic_terms(key) ON DELETE CASCADE ON UPDATE CASCADE,
    key          TEXT NOT NULL,
    name         TEXT NOT NULL,
    description  TEXT NOT NULL DEFAULT '',
    aliases      JSONB NOT NULL DEFAULT '[]'::jsonb,
    sort_order   INT NOT NULL DEFAULT 0,
    PRIMARY KEY (term_key, key)
);

INSERT INTO semantic_term_values (term_key, key, name, description, aliases, sort_order)
SELECT 'line_of_business', v.key, v.name, v.description, v.aliases::jsonb, v.sort_order
  FROM (VALUES
        ('life', 'Life', 'Life insurance: term, whole and universal life.', '["life", "life insurance"]', 10),
        ('annuity', 'Annuity', 'Fixed and indexed annuities.', '["annuity", "annuities"]', 20)
       ) AS v(key, name, description, aliases, sort_order)
 WHERE EXISTS (SELECT 1 FROM semantic_terms WHERE key = 'line_of_business')
ON CONFLICT (term_key, key) DO NOTHING;

CREATE TABLE IF NOT EXISTS semantic_asset_lines (
    asset_id    UUID NOT NULL REFERENCES semantic_assets(id) ON DELETE CASCADE,
    line_key    TEXT NOT NULL,
    source      TEXT NOT NULL CHECK (source IN ('tag', 'pipeline', 'values', 'inherited')),
    evidence    TEXT NOT NULL DEFAULT '',
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (asset_id, line_key)
);
CREATE INDEX IF NOT EXISTS semantic_asset_lines_line_idx ON semantic_asset_lines (line_key);

ALTER TABLE pipelines ADD COLUMN IF NOT EXISTS line_of_business TEXT;
