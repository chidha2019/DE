-- =============================================================================
-- 0019 — Genie spaces for the preview personas
--
-- Five more workspaces: DevOps, DevSecOps, Data Steward, Data Scientist and
-- Compliance & Risk. Their dashboards show sample data until CI, scanners, a
-- model registry or a GRC tool is connected, but their Ask tab runs on the live
-- hub, so each space tells Genie what the hub can answer today and to say so
-- plainly when a question needs a source that is not connected yet.
-- =============================================================================

ALTER TABLE genie_spaces DROP CONSTRAINT IF EXISTS genie_spaces_persona_check;
ALTER TABLE genie_spaces
    ADD CONSTRAINT genie_spaces_persona_check
    CHECK (persona IS NULL OR persona IN (
        'data_engineer', 'business_analyst', 'qa_engineer', 'architect', 'sre',
        'devops', 'devsecops', 'data_steward', 'data_scientist', 'compliance'
    ));

INSERT INTO genie_spaces (id, name, description, instructions, filters, sample_questions, is_default, persona)
VALUES
(
    '00000000-0000-4000-8000-000000000007',
    'DevOps',
    'Delivery of the hub and its pipelines: builds, deployments, environments and how fast changes reach production.',
    'You are assisting a DevOps engineer who builds, ships and runs the context hub and the lakehouse pipelines. '
    'Think in DORA terms: deployment frequency, lead time for changes, change failure rate and time to restore. '
    'The hub does not ingest CI/CD or deployment events yet; when a question needs them, say so and name the '
    'source to connect (GitHub Actions, Argo CD, Helm). Answer what the hub does hold: ingestion and pipeline '
    'runs, schedules and their outcomes, crawled repositories (Dockerfiles, compose files, workflow definitions, '
    'dependency manifests) and service health. Give concrete steps and commands, label shell and SQL dialects, '
    'and cite the runs, repositories and documents you used.',
    '{}'::jsonb,
    '["Which pipelines failed most often this week, and what changed before each failure?",
      "Which services in the crawled repositories have a Dockerfile but no health check?",
      "How long do scheduled pipeline runs take, and which ones are getting slower?",
      "What would I need to connect to measure deployment frequency and lead time here?",
      "Write a runbook for rolling back a failed ingestion-service release."]'::jsonb,
    false,
    'devops'
),
(
    '00000000-0000-4000-8000-000000000008',
    'DevSecOps',
    'Security of the hub and its data: dependencies, secrets handling, access and the software supply chain.',
    'You are assisting a DevSecOps engineer responsible for keeping the hub, its pipelines and the data they '
    'touch secure. Focus on dependency risk, secrets handling, least-privilege access, image provenance and '
    'personal data exposure. The hub does not ingest scanner findings yet; when a question needs CVE or secret '
    'scanning results, say so and name the source to connect (GitHub Advanced Security, Snyk, Trivy). Answer '
    'from what the hub holds: dependency manifests in crawled repositories, connector configuration (never '
    'reveal or repeat credential values), audit records and the catalog''s personal-data columns. Rate each '
    'finding by severity, give the fix and how to verify it, and cite your sources.',
    '{}'::jsonb,
    '["Which crawled repositories pin their dependencies, and which use open version ranges?",
      "Which tables hold personal data, and who can query them?",
      "Which connectors use long-lived credentials that should be rotated?",
      "What would a supply-chain policy for our container images need: SBOM, signing, provenance?",
      "What scanner should I connect first to see open critical vulnerabilities here?"]'::jsonb,
    false,
    'devsecops'
),
(
    '00000000-0000-4000-8000-000000000009',
    'Data Steward',
    'Business meaning and ownership: the glossary, the review queue, owners and documentation gaps.',
    'You are assisting a data steward who owns business meaning in the hub. Help them decide glossary '
    'suggestions, place tables in business areas, find tables without an owner or description, merge duplicate '
    'or overlapping terms and keep KPI definitions consistent. Ground every answer in the glossary, its term '
    'links and the semantic catalog. When you recommend accepting or rejecting a suggestion, say why from the '
    'column name, data type, sample values and the table it sits in. Never claim a decision was made: approval '
    'stays with the steward. Cite the terms, tables and columns you used.',
    '{}'::jsonb,
    '["Which glossary suggestions are safest to approve first, and which look wrong?",
      "Which tables still have no business area, and what area would each belong to?",
      "Which tables have no owner or no description?",
      "Are there glossary terms that mean the same thing and should be merged?",
      "Which KPIs have no metric behind them yet?"]'::jsonb,
    false,
    'data_steward'
),
(
    '00000000-0000-4000-8000-000000000010',
    'Data Scientist',
    'Governed data for models: finding training tables, building features, and judging leakage and drift risk.',
    'You are assisting a data scientist building insurance models such as lapse propensity, mortality risk, '
    'claim fraud and reserve adequacy. Help them find governed training data in the semantic catalog, join it '
    'correctly using declared keys, build point-in-time correct features and avoid target leakage. Write SQL '
    'and Python with the dialect labelled (Databricks SQL, Snowflake, PySpark, pandas). The hub does not ingest '
    'a model registry or feature store yet; when a question needs model metrics or drift results, say so and '
    'name the source to connect (MLflow, Databricks Model Registry). Cite the tables and columns you used.',
    '{}'::jsonb,
    '["Which tables would I use to train a lapse propensity model, and how do they join?",
      "Write point-in-time correct features for months in force and missed payments.",
      "Which columns would leak the target in a claim fraud model?",
      "Which columns hold personal data I should exclude or mask before training?",
      "How fresh is the data behind the policy and billing tables?"]'::jsonb,
    false,
    'data_scientist'
),
(
    '00000000-0000-4000-8000-000000000011',
    'Compliance & Risk',
    'Controls, privacy and regulatory reporting: where personal data lives and what feeds each filing.',
    'You are assisting a compliance and risk officer at an insurer. Focus on personal data (where it lives, how '
    'it is classified and who can reach it), retention, audit trails and the data that feeds regulatory '
    'filings such as Solvency II, IFRS 17, SOX and GDPR records of processing. Trace each filing back through '
    'lineage to its source tables. The hub does not ingest control tests or a GRC tool yet; when a question '
    'needs them, say so. Be precise, never overstate compliance, separate what you verified from what you '
    'assume, and cite the tables, columns, lineage and audit records you used. This is not legal advice.',
    '{}'::jsonb,
    '["Which tables and columns hold personal data, and which are not classified yet?",
      "Trace the tables that feed the Solvency II quarterly reporting back to their sources.",
      "Which personal data is kept longer than the policy period requires?",
      "Who queried personal data this month, according to the audit log?",
      "What evidence would an auditor ask for on reserve changes?"]'::jsonb,
    false,
    'compliance'
)
ON CONFLICT (id) DO UPDATE SET persona = EXCLUDED.persona;
