-- =============================================================================
-- Migration 0001 — core metadata schema
--
-- Applied by backend/scripts/migrate.py inside a single transaction and
-- recorded in schema_migrations. Every statement is idempotent so the file can
-- be re-applied safely on a partially-migrated database.
--
-- ID strategy (critical for Postgres <-> Neo4j consistency)
--   documents.id is NOT random. The application derives it as
--       uuid5(ECH_NAMESPACE, f"{source_system}:{external_id}")
--   so the same source object always maps to the same UUID, and the Neo4j
--   Document node uses the identical value as its `document_id` property.
--   Re-ingesting a document therefore upserts the same row and the same node.
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- -----------------------------------------------------------------------------
-- Enumerations
-- -----------------------------------------------------------------------------
DO $$ BEGIN
    CREATE TYPE source_system AS ENUM ('confluence', 'sharepoint', 'github', 'manual');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
    -- Tracks the outbox-style saga between Postgres (system of record for
    -- documents) and Neo4j (system of record for relationships).
    CREATE TYPE graph_sync_status AS ENUM ('pending', 'synced', 'failed');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- -----------------------------------------------------------------------------
-- Helpers
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END $$;

-- -----------------------------------------------------------------------------
-- sources — configured connector instances
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sources (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name        TEXT NOT NULL UNIQUE,
    system      source_system NOT NULL,
    -- connector-specific settings (space keys, site URLs, repo filters, ...)
    config      JSONB NOT NULL DEFAULT '{}'::jsonb,
    enabled     BOOLEAN NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

DROP TRIGGER IF EXISTS trg_sources_updated_at ON sources;
CREATE TRIGGER trg_sources_updated_at
    BEFORE UPDATE ON sources
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
-- documents — one row per source object (page, file, README, issue, ...)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS documents (
    id                  UUID PRIMARY KEY,                  -- deterministic uuid5, see header
    source_id           UUID REFERENCES sources(id) ON DELETE SET NULL,
    source_system       source_system NOT NULL,
    external_id         TEXT NOT NULL,                     -- id inside the source system
    title               TEXT NOT NULL,
    uri                 TEXT,
    author              TEXT,
    mime_type           TEXT NOT NULL DEFAULT 'text/markdown',
    language            TEXT NOT NULL DEFAULT 'en',
    content_hash        TEXT NOT NULL,                     -- sha256 of normalised content
    content_length      INTEGER NOT NULL DEFAULT 0,
    version             INTEGER NOT NULL DEFAULT 1,        -- incremented when content_hash changes
    -- Schema-agnostic attributes (space, labels, repo, path, custom fields...)
    attributes          JSONB NOT NULL DEFAULT '{}'::jsonb,
    -- Graph synchronisation state (see graph_sync_status comment above)
    graph_sync_status   graph_sync_status NOT NULL DEFAULT 'pending',
    graph_node_id       TEXT,                              -- Neo4j elementId for traceability
    graph_synced_at     TIMESTAMPTZ,
    graph_sync_error    TEXT,
    source_created_at   TIMESTAMPTZ,
    source_updated_at   TIMESTAMPTZ,
    ingested_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at          TIMESTAMPTZ,                       -- soft delete
    title_tsv           TSVECTOR GENERATED ALWAYS AS (to_tsvector('english', coalesce(title, ''))) STORED,
    CONSTRAINT documents_source_external_unique UNIQUE (source_system, external_id),
    CONSTRAINT documents_content_length_nonneg CHECK (content_length >= 0)
);

CREATE INDEX IF NOT EXISTS documents_source_system_idx   ON documents (source_system);
CREATE INDEX IF NOT EXISTS documents_attributes_gin_idx  ON documents USING GIN (attributes jsonb_path_ops);
CREATE INDEX IF NOT EXISTS documents_title_tsv_idx       ON documents USING GIN (title_tsv);
CREATE INDEX IF NOT EXISTS documents_title_trgm_idx      ON documents USING GIN (title gin_trgm_ops);
CREATE INDEX IF NOT EXISTS documents_ingested_at_idx     ON documents (ingested_at DESC);
-- Partial index: the reconciliation job only scans rows that are not synced.
CREATE INDEX IF NOT EXISTS documents_graph_pending_idx   ON documents (graph_sync_status, updated_at)
    WHERE graph_sync_status <> 'synced';
CREATE INDEX IF NOT EXISTS documents_live_idx            ON documents (id) WHERE deleted_at IS NULL;

DROP TRIGGER IF EXISTS trg_documents_updated_at ON documents;
CREATE TRIGGER trg_documents_updated_at
    BEFORE UPDATE ON documents
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
-- chunks — semantic chunks of a document; the retrieval unit
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS chunks (
    id              UUID PRIMARY KEY,                      -- uuid5(document_id, chunk_index)
    document_id     UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    chunk_index     INTEGER NOT NULL,
    content         TEXT NOT NULL,
    token_count     INTEGER NOT NULL,
    char_start      INTEGER NOT NULL,
    char_end        INTEGER NOT NULL,
    -- heading hierarchy the chunk belongs to, e.g. {"Architecture","Storage"}
    section_path    TEXT[] NOT NULL DEFAULT '{}',
    metadata        JSONB NOT NULL DEFAULT '{}'::jsonb,
    -- Full-text search vector for the BM25-style keyword leg of hybrid search.
    content_tsv     TSVECTOR GENERATED ALWAYS AS (to_tsvector('english', content)) STORED,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT chunks_document_index_unique UNIQUE (document_id, chunk_index),
    CONSTRAINT chunks_span_valid CHECK (char_end >= char_start),
    CONSTRAINT chunks_token_count_positive CHECK (token_count > 0)
);

CREATE INDEX IF NOT EXISTS chunks_document_id_idx  ON chunks (document_id, chunk_index);
CREATE INDEX IF NOT EXISTS chunks_content_tsv_idx  ON chunks USING GIN (content_tsv);
CREATE INDEX IF NOT EXISTS chunks_metadata_gin_idx ON chunks USING GIN (metadata jsonb_path_ops);

COMMENT ON TABLE documents IS 'Canonical document metadata. id == Neo4j Document.document_id.';
COMMENT ON TABLE chunks    IS 'Retrieval units. id == Neo4j Chunk.chunk_id.';
COMMENT ON COLUMN documents.graph_sync_status IS 'pending -> synced | failed; reconciled by ingestion-service';
