-- 0021: intents are validated against Snowflake (read-only) and routed by what that finds.
-- `validation` holds IntentValidation, `route` the chosen IntentRoute; 'waiting' parks an intent on its upstream
-- tables, 'modeling' is the data modeler at work.
ALTER TABLE intents ADD COLUMN IF NOT EXISTS validation JSONB;
ALTER TABLE intents ADD COLUMN IF NOT EXISTS route JSONB;
ALTER TABLE intents DROP CONSTRAINT IF EXISTS intents_status_check;
ALTER TABLE intents ADD CONSTRAINT intents_status_check
    CHECK (status IN ('received', 'clarifying', 'planning', 'waiting', 'modeling', 'spec_proposed', 'approved',
                      'coding', 'pr_open', 'done', 'rejected', 'failed'));
