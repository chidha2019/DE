-- =============================================================================
-- Migration 0006 — Personas: one Genie space per persona
--
-- The admin UI has a Data Engineer and a Business Analyst workspace. Each asks
-- Genie through its own space so the standing instructions and sample questions
-- match the audience: technical (keys, joins, lineage, SQL) versus business
-- (what a metric means, how it is defined, what it can be broken down by).
-- =============================================================================

ALTER TABLE genie_spaces
    ADD COLUMN IF NOT EXISTS persona TEXT
        CHECK (persona IS NULL OR persona IN ('data_engineer', 'business_analyst'));

-- at most one space per persona
CREATE UNIQUE INDEX IF NOT EXISTS genie_spaces_persona_idx ON genie_spaces (persona)
    WHERE persona IS NOT NULL;

INSERT INTO genie_spaces (id, name, description, instructions, filters, sample_questions, is_default, persona)
VALUES
(
    '00000000-0000-4000-8000-000000000002',
    'Data Engineer',
    'Schemas, keys, joins, lineage, pipelines and SQL over the catalog metadata and the code that builds it.',
    'You are assisting a data engineer. Answer with technical precision: fully qualified names, '
    'column data types, primary and foreign keys, declared versus inferred joins with their '
    'confidence, upstream and downstream lineage, and the pipeline code that builds an asset. '
    'When asked how to query or join, write the SQL (state the dialect: Databricks SQL or '
    'Snowflake) and name every key you rely on. Call out missing keys, undocumented columns, '
    'inferred-only joins and stale syncs as risks. Prefer describe_asset and get_lineage over '
    'guessing, and cite the assets and files you used.',
    '{}'::jsonb,
    '["Which fact tables have no primary key, and what would you key them on?",
      "Which joins are only inferred and need review before anyone relies on them?",
      "Show the lineage of the claims fact: what feeds it and what reads from it?",
      "Write Databricks SQL that joins claim payments to claims and names every key it relies on.",
      "What did the last catalog sync ingest, and which assets have no description or owner?"]'::jsonb,
    false,
    'data_engineer'
),
(
    '00000000-0000-4000-8000-000000000003',
    'Business Analyst',
    'Business questions answered in plain language from governed metrics and their definitions.',
    'You are assisting a business analyst who does not read SQL unless they ask for it. Answer '
    'in business language: what a metric means, how it is calculated in words, which dimensions '
    'it can be broken down by, where the governed definition lives and whether it is declared '
    '(governed) or inferred. Prefer declared metrics and metric views; say plainly when a number '
    'is not certified or a definition is still a draft. Avoid table and column jargon unless the '
    'user asks; when you must name a dataset, say what it represents. Offer SQL only when asked, '
    'labelled with its dialect, and cite the assets you used.',
    '{}'::jsonb,
    '["Which metrics are governed, and what does each one measure?",
      "How is claim count defined, and what can I break it down by?",
      "Which business domains does the catalog cover, and how complete is each?",
      "Is there a certified measure of premium collected, or only a record count?",
      "What can the members metric view tell me, and what can it not?"]'::jsonb,
    false,
    'business_analyst'
)
ON CONFLICT (id) DO UPDATE SET persona = EXCLUDED.persona;
