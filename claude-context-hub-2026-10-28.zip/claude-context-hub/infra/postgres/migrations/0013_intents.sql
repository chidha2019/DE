-- =============================================================================
-- Migration 0013 — Intents: Jira (or manual) requests that become pipeline specs and code
--
-- One row per intent. `status` is the state machine:
--   received      the ticket arrived and is being parsed
--   clarifying    the parser found open questions; they were posted back, answers awaited
--   planning      the planner is resolving terms, datasets and schema into a spec
--   spec_proposed the spec is posted for review (Jira comment / UI)
--   approved      a person approved the spec; the coder is about to run
--   coding        the coder is generating the pipeline into the workspace
--   pr_open       files are written (and pushed as a branch / pull request when possible)
--   done          the change landed; closed by a person
--   rejected      the spec was rejected
--   failed        parsing, planning or coding failed (error says why)
-- `intent`, `spec` and `coder` are JSON documents (StructuredIntent, PipelineSpec, CoderResult).
-- =============================================================================

CREATE TABLE IF NOT EXISTS intents (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source        TEXT NOT NULL DEFAULT 'manual' CHECK (source IN ('manual', 'jira')),
    jira_key      TEXT UNIQUE,
    jira_url      TEXT,
    title         TEXT NOT NULL,
    text          TEXT NOT NULL DEFAULT '',
    reporter      TEXT NOT NULL DEFAULT '',
    status        TEXT NOT NULL DEFAULT 'received'
                  CHECK (status IN ('received', 'clarifying', 'planning', 'spec_proposed', 'approved',
                                    'coding', 'pr_open', 'done', 'rejected', 'failed')),
    intent        JSONB,
    questions     JSONB NOT NULL DEFAULT '[]'::jsonb,
    answers       JSONB NOT NULL DEFAULT '[]'::jsonb,
    spec          JSONB,
    spec_markdown TEXT NOT NULL DEFAULT '',
    coder         JSONB,
    branch        TEXT,
    pr_url        TEXT,
    error         TEXT,
    posted        JSONB NOT NULL DEFAULT '[]'::jsonb,   -- what was written back to Jira: [{kind, at, comment_id}]
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    decided_at    TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS intents_status_idx ON intents (status);
CREATE INDEX IF NOT EXISTS intents_created_idx ON intents (created_at DESC);
