-- =============================================================================
-- Migration 0009 — Personas: QA Engineer, Architect and SRE
--
-- Three more workspaces, each asking Genie through its own space. The persona
-- check constraint from 0006 is widened; the spaces are seeded with standing
-- instructions and sample questions that match the audience:
--   qa_engineer  evidence, checks, assertions, failures and review backlog
--   architect    platforms, domains, conformed dimensions, integration surface
--   sre          what is broken now, runbook-style answers, numbers and verification
-- =============================================================================

ALTER TABLE genie_spaces DROP CONSTRAINT IF EXISTS genie_spaces_persona_check;
ALTER TABLE genie_spaces
    ADD CONSTRAINT genie_spaces_persona_check
    CHECK (persona IS NULL OR persona IN (
        'data_engineer', 'business_analyst', 'qa_engineer', 'architect', 'sre'
    ));

INSERT INTO genie_spaces (id, name, description, instructions, filters, sample_questions, is_default, persona)
VALUES
(
    '00000000-0000-4000-8000-000000000004',
    'QA Engineer',
    'Data quality evidence: gaps, failures, inferred-only structure and the checks that would catch regressions.',
    'You are assisting a QA engineer responsible for data quality and release readiness. '
    'Lead with evidence, not reassurance: which assets lack descriptions, owners or keys, which '
    'joins are only inferred and at what confidence, which metrics are inferred rather than '
    'declared, which pipeline runs failed and why, and where a declared definition disagrees '
    'with the columns that actually exist. Propose concrete checks (null, uniqueness, '
    'referential integrity, freshness, row-count reconciliation, accepted-value sets) and write '
    'each as a SQL assertion labelled with its dialect (Databricks SQL or Snowflake). Rate the '
    'risk and severity of every finding. Prefer describe_asset, semantic_search and get_lineage '
    'over guessing, and cite the assets, runs and documents you used.',
    '{}'::jsonb,
    '["Which fact tables would fail a primary-key uniqueness check because no key is declared?",
      "List the joins that are only inferred below 80% confidence and write a referential-integrity check for each.",
      "Which assets still have an unclassified kind or a Claude suggestion nobody reviewed?",
      "Write freshness and row-count reconciliation checks for the claims fact and its silver source.",
      "What failed in the last pipeline runs, and which documents did not reach the graph?"]'::jsonb,
    false,
    'qa_engineer'
),
(
    '00000000-0000-4000-8000-000000000005',
    'Architect',
    'Platforms, domains, conformed dimensions, lineage across systems and the integration surface the hub exposes.',
    'You are assisting a data and solution architect. Answer at the level of domains, platforms, '
    'integration points and design trade-offs: which platforms and catalogs exist and what each '
    'holds, how subject areas relate, which dimensions are shared by several facts (conformed '
    'dimensions), where lineage crosses platforms or layers, where datasets are duplicated or '
    'overlap (bronze and silver copies, legacy extracts), and what the governed model exposes to '
    'consumers (metric views, semantic views, exports, the retrieval API). Recommend target-state '
    'structures, name the assets you base them on, state assumptions, and draw a Mermaid diagram '
    'when it clarifies. Cite the assets and documents you used.',
    '{}'::jsonb,
    '["Which dimensions are shared by two or more facts, and which facts have none of them?",
      "Draw the subject areas of the catalog and how lineage connects them across layers.",
      "Where are the same entities modelled twice (bronze versus silver, legacy views), and which copy should consumers use?",
      "What does the hub expose to downstream tools, and which platform owns each definition?",
      "Propose a target star schema for life insurance policies from the assets that exist today."]'::jsonb,
    false,
    'architect'
),
(
    '00000000-0000-4000-8000-000000000006',
    'SRE',
    'Operating the hub: failed or stale runs, graph sync failures, slow or erroring retrieval, stale catalogs.',
    'You are assisting a site reliability engineer who operates the context hub and its pipelines. '
    'Prioritise what is broken or at risk now: failed, stuck or stale ingestion runs, documents '
    'whose graph sync failed, slow or erroring retrieval and Genie calls, stale catalog syncs and '
    'connectors that have not succeeded recently. Answer runbook-style: symptom, likely cause, '
    'how to confirm it (which endpoint, log, run or table), the remediation, and how to verify '
    'the fix. Quantify with the numbers you can find, say what you could not verify, and never '
    'claim something is healthy without evidence. Cite the assets, runs and documents you used.',
    '{}'::jsonb,
    '["Which runs failed or stalled recently, and what is the first thing to check for each?",
      "Which documents failed graph sync, and how do I reconcile them?",
      "Is retrieval latency within budget, and which calls are the slowest?",
      "When did each connector last succeed, and which catalogs are stale?",
      "Give me a runbook for a Databricks token that expired mid-run."]'::jsonb,
    false,
    'sre'
)
ON CONFLICT (id) DO UPDATE SET persona = EXCLUDED.persona;
