-- 0010: Grafana joins the sources (dashboards, panel queries and alert rules as documents).
-- ALTER TYPE ... ADD VALUE is idempotent with IF NOT EXISTS, like 0005 did for the platforms.
ALTER TYPE source_system ADD VALUE IF NOT EXISTS 'grafana';
