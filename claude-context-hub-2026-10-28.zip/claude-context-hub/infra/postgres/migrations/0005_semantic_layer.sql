-- =============================================================================
-- Migration 0005 — semantic layer over Snowflake / Databricks catalog metadata
--
-- Each ingested table-like object is both a hub document (rendered markdown, chunked,
-- embedded, in the graph) and a structured semantic asset with fields (roles),
-- relationships (keys, joins, lineage) and metrics (declared and inferred).
-- semantic_assets.id == documents.id (uuid5 of source_system:fqn).
-- =============================================================================

ALTER TYPE source_system ADD VALUE IF NOT EXISTS 'snowflake';
ALTER TYPE source_system ADD VALUE IF NOT EXISTS 'databricks';

CREATE TABLE IF NOT EXISTS semantic_assets (
    id                 UUID PRIMARY KEY,
    document_id        UUID NOT NULL UNIQUE REFERENCES documents (id) ON DELETE CASCADE,
    source_system      source_system NOT NULL,
    platform           TEXT NOT NULL,                      -- snowflake | databricks
    fqn                TEXT NOT NULL,                      -- database.schema.name
    database_name      TEXT NOT NULL,
    schema_name        TEXT NOT NULL,
    name               TEXT NOT NULL,
    asset_type         TEXT NOT NULL,                      -- table | view | metric_view | ...
    kind               TEXT NOT NULL DEFAULT 'unknown',    -- fact | dimension | bridge | metric | reference
    description        TEXT NOT NULL DEFAULT '',
    owner              TEXT,
    tags               JSONB NOT NULL DEFAULT '[]'::jsonb,
    properties         JSONB NOT NULL DEFAULT '{}'::jsonb,
    definition         TEXT,
    uri                TEXT,
    field_count        INTEGER NOT NULL DEFAULT 0,
    row_count          BIGINT,
    bytes              BIGINT,
    source_created_at  TIMESTAMPTZ,
    source_updated_at  TIMESTAMPTZ,
    synced_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (source_system, fqn)
);

CREATE INDEX IF NOT EXISTS semantic_assets_scope_idx
    ON semantic_assets (source_system, database_name, schema_name, name);
CREATE INDEX IF NOT EXISTS semantic_assets_kind_idx ON semantic_assets (kind, asset_type);
CREATE INDEX IF NOT EXISTS semantic_assets_fqn_trgm_idx
    ON semantic_assets USING gin (fqn gin_trgm_ops);
CREATE INDEX IF NOT EXISTS semantic_assets_fts_idx
    ON semantic_assets USING gin (to_tsvector('english', fqn || ' ' || description));

DROP TRIGGER IF EXISTS trg_semantic_assets_updated_at ON semantic_assets;
CREATE TRIGGER trg_semantic_assets_updated_at
    BEFORE UPDATE ON semantic_assets
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS semantic_fields (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    asset_id         UUID NOT NULL REFERENCES semantic_assets (id) ON DELETE CASCADE,
    name             TEXT NOT NULL,
    ordinal          INTEGER NOT NULL DEFAULT 0,
    data_type        TEXT NOT NULL DEFAULT '',
    description      TEXT NOT NULL DEFAULT '',
    nullable         BOOLEAN,
    is_primary_key   BOOLEAN NOT NULL DEFAULT false,
    is_partition     BOOLEAN NOT NULL DEFAULT false,
    role             TEXT NOT NULL DEFAULT 'attribute',   -- identifier | dimension | time | measure | attribute
    role_confidence  REAL NOT NULL DEFAULT 0,
    aggregation      TEXT,
    tags             JSONB NOT NULL DEFAULT '[]'::jsonb,
    synonyms         JSONB NOT NULL DEFAULT '[]'::jsonb,
    UNIQUE (asset_id, name)
);

CREATE INDEX IF NOT EXISTS semantic_fields_name_trgm_idx
    ON semantic_fields USING gin (name gin_trgm_ops);
CREATE INDEX IF NOT EXISTS semantic_fields_role_idx ON semantic_fields (role);

-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS semantic_relationships (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_asset_id   UUID NOT NULL REFERENCES semantic_assets (id) ON DELETE CASCADE,
    target_fqn        TEXT NOT NULL,                       -- kept even when the target is not ingested
    target_asset_id   UUID REFERENCES semantic_assets (id) ON DELETE SET NULL,
    kind              TEXT NOT NULL,                       -- foreign_key | join_declared | join_inferred | lineage_* | metric_source
    source_columns    JSONB NOT NULL DEFAULT '[]'::jsonb,
    target_columns    JSONB NOT NULL DEFAULT '[]'::jsonb,
    confidence        REAL NOT NULL DEFAULT 1,
    evidence          TEXT NOT NULL DEFAULT '',
    UNIQUE (source_asset_id, target_fqn, kind, source_columns)
);

CREATE INDEX IF NOT EXISTS semantic_relationships_target_idx
    ON semantic_relationships (target_asset_id);
CREATE INDEX IF NOT EXISTS semantic_relationships_target_fqn_idx
    ON semantic_relationships (target_fqn);

-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS semantic_metrics (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    asset_id      UUID NOT NULL REFERENCES semantic_assets (id) ON DELETE CASCADE,
    name          TEXT NOT NULL,
    expression    TEXT NOT NULL DEFAULT '',
    aggregation   TEXT,
    description   TEXT NOT NULL DEFAULT '',
    source        TEXT NOT NULL DEFAULT 'inferred',       -- declared | inferred
    dimensions    JSONB NOT NULL DEFAULT '[]'::jsonb,
    fields        JSONB NOT NULL DEFAULT '[]'::jsonb,
    synonyms      JSONB NOT NULL DEFAULT '[]'::jsonb,
    UNIQUE (asset_id, name)
);

CREATE INDEX IF NOT EXISTS semantic_metrics_name_trgm_idx
    ON semantic_metrics USING gin (name gin_trgm_ops);
