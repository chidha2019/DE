-- =============================================================================
-- Repo crawls: each time a GitHub repository is crawled into the repo knowledge graph.
--
-- The graph itself lives in Neo4j (:RepoGraph nodes, replaced per repository on every crawl);
-- this table keeps the history, progress and outcome of each crawl for the Repo Graph tab.
-- =============================================================================

CREATE TABLE IF NOT EXISTS repo_crawls (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    repo          TEXT NOT NULL,
    ref           TEXT,
    sha           TEXT,
    status        TEXT NOT NULL DEFAULT 'queued'
                  CHECK (status IN ('queued', 'running', 'completed', 'failed')),
    phase         TEXT NOT NULL DEFAULT 'queued',
    files_total   INTEGER NOT NULL DEFAULT 0,
    files_read    INTEGER NOT NULL DEFAULT 0,
    stats         JSONB NOT NULL DEFAULT '{}'::jsonb,
    warnings      JSONB NOT NULL DEFAULT '[]'::jsonb,
    error         TEXT,
    index_text    BOOLEAN NOT NULL DEFAULT false,
    index_run_id  UUID,
    requested_by  TEXT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    started_at    TIMESTAMPTZ,
    finished_at   TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS repo_crawls_repo_created_idx ON repo_crawls (repo, created_at DESC);
CREATE INDEX IF NOT EXISTS repo_crawls_status_idx ON repo_crawls (status) WHERE status IN ('queued', 'running');
