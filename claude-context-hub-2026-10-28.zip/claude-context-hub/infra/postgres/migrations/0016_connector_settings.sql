-- Connection settings saved from the hub's Connectors page. They override the environment for one
-- connector; secrets are Fernet-encrypted (key from ECH_SECRETS_KEY or the service's state directory)
-- and never returned by the API.
create table if not exists connector_settings (
    connector   text primary key,
    settings    jsonb not null default '{}'::jsonb,
    secrets     bytea,
    updated_by  text,
    updated_at  timestamptz not null default now()
);
