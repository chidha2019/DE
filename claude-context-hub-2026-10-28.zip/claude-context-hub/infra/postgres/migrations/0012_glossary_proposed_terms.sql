-- =============================================================================
-- Migration 0012 — Claude-proposed glossary terms
--
-- semantic_terms.status gains 'proposed': a candidate term Claude derived from columns and
-- metrics no existing term covers. It waits in the review queue next to its evidence links;
-- accepting makes it 'curated', rejecting deletes it (its links go with it). proposed_by and
-- rationale record which model proposed it and why.
-- =============================================================================

ALTER TABLE semantic_terms DROP CONSTRAINT IF EXISTS semantic_terms_status_check;
ALTER TABLE semantic_terms
    ADD CONSTRAINT semantic_terms_status_check CHECK (status IN ('seeded', 'curated', 'proposed'));
ALTER TABLE semantic_terms
    ADD COLUMN IF NOT EXISTS proposed_by TEXT,
    ADD COLUMN IF NOT EXISTS rationale   TEXT NOT NULL DEFAULT '';
CREATE INDEX IF NOT EXISTS semantic_terms_status_idx ON semantic_terms (status);
