-- =============================================================================
-- Migration 0003 — ingestion pipeline state + audit trail
-- =============================================================================

DO $$ BEGIN
    CREATE TYPE ingestion_run_status AS ENUM
        ('queued', 'running', 'paused', 'completed', 'failed', 'cancelled');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- -----------------------------------------------------------------------------
-- ingestion_runs — one row per pipeline execution
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ingestion_runs (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    connector_name  TEXT NOT NULL,                 -- registry key, e.g. "confluence"
    source_system   source_system NOT NULL,
    status          ingestion_run_status NOT NULL DEFAULT 'queued',
    -- run-time options (full_refresh, limit, chunking overrides, ...)
    config          JSONB NOT NULL DEFAULT '{}'::jsonb,
    -- counters updated as the run progresses:
    -- {documents_seen, documents_upserted, documents_skipped, chunks_created,
    --  embeddings_created, entities_linked, graph_synced, graph_failed}
    stats           JSONB NOT NULL DEFAULT '{}'::jsonb,
    triggered_by    TEXT,
    error           TEXT,
    started_at      TIMESTAMPTZ,
    finished_at     TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ingestion_runs_created_at_idx ON ingestion_runs (created_at DESC);
CREATE INDEX IF NOT EXISTS ingestion_runs_status_idx     ON ingestion_runs (status)
    WHERE status IN ('queued', 'running', 'paused');

DROP TRIGGER IF EXISTS trg_ingestion_runs_updated_at ON ingestion_runs;
CREATE TRIGGER trg_ingestion_runs_updated_at
    BEFORE UPDATE ON ingestion_runs
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
-- ingestion_run_events — append-only progress log (also streamed over SSE)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ingestion_run_events (
    id          BIGSERIAL PRIMARY KEY,
    run_id      UUID NOT NULL REFERENCES ingestion_runs(id) ON DELETE CASCADE,
    level       TEXT NOT NULL DEFAULT 'info',   -- debug | info | warning | error
    event_type  TEXT NOT NULL,                  -- run.started, document.upserted, ...
    message     TEXT NOT NULL,
    payload     JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ingestion_run_events_run_idx ON ingestion_run_events (run_id, id);

-- Link documents back to the run that last touched them.
ALTER TABLE documents
    ADD COLUMN IF NOT EXISTS last_run_id UUID REFERENCES ingestion_runs(id) ON DELETE SET NULL;

-- -----------------------------------------------------------------------------
-- audit_logs — who did what, when, how long it took
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_logs (
    id              BIGSERIAL PRIMARY KEY,
    request_id      TEXT,
    actor           TEXT,                       -- api key id / user / "system"
    action          TEXT NOT NULL,              -- context.retrieve, pipeline.trigger, ...
    resource_type   TEXT,
    resource_id     TEXT,
    status          TEXT NOT NULL DEFAULT 'ok', -- ok | error
    latency_ms      DOUBLE PRECISION,
    details         JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS audit_logs_created_at_idx ON audit_logs (created_at DESC);
CREATE INDEX IF NOT EXISTS audit_logs_action_idx     ON audit_logs (action, created_at DESC);

COMMENT ON TABLE ingestion_runs       IS 'Pipeline executions; stats JSONB holds live counters.';
COMMENT ON TABLE ingestion_run_events IS 'Append-only run log; mirrored to SSE subscribers.';
COMMENT ON TABLE audit_logs           IS 'Immutable audit trail for API and pipeline actions.';
