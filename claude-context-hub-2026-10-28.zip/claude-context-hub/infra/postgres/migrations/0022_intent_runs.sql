-- 0022: the hub runs an approved pipeline itself (upload the files, create the objects, load, check, refresh the
-- catalog). `run` holds the latest PipelineRun; 'running' is a run in progress, 'loaded' a run that finished with
-- every check passing, waiting for a person to close the intent.
ALTER TABLE intents ADD COLUMN IF NOT EXISTS run JSONB;
ALTER TABLE intents DROP CONSTRAINT IF EXISTS intents_status_check;
ALTER TABLE intents ADD CONSTRAINT intents_status_check
    CHECK (status IN ('received', 'clarifying', 'planning', 'waiting', 'modeling', 'spec_proposed', 'approved',
                      'coding', 'pr_open', 'running', 'loaded', 'done', 'rejected', 'failed'));
