-- Runs once at cluster initialisation (docker-entrypoint-initdb.d).
-- Extensions require superuser; the migration runner connects as the app role,
-- so we create them here. Migrations still guard with IF NOT EXISTS.
CREATE EXTENSION IF NOT EXISTS vector;     -- pgvector: vector type, HNSW/IVFFlat
CREATE EXTENSION IF NOT EXISTS pg_trgm;    -- trigram similarity for fuzzy title search
CREATE EXTENSION IF NOT EXISTS pgcrypto;   -- digest() for content hashing in SQL if needed
