-- claude-context-hub Postgres schema: the init script and every migration, in the order the migrate job
-- applies them. The migrations under infra/postgres/migrations stay the source of truth; this file is a
-- convenience to read or apply the whole schema at once. It holds no application data, only the reference
-- seeds the migrations themselves insert.

-- ============================================================ init/00_extensions.sql
-- Runs once at cluster initialisation (docker-entrypoint-initdb.d).
-- Extensions require superuser; the migration runner connects as the app role,
-- so we create them here. Migrations still guard with IF NOT EXISTS.
CREATE EXTENSION IF NOT EXISTS vector;     -- pgvector: vector type, HNSW/IVFFlat
CREATE EXTENSION IF NOT EXISTS pg_trgm;    -- trigram similarity for fuzzy title search
CREATE EXTENSION IF NOT EXISTS pgcrypto;   -- digest() for content hashing in SQL if needed

-- ============================================================ migrations/0001_initial_schema.sql
-- =============================================================================
-- Migration 0001 — core metadata schema
--
-- Applied by backend/scripts/migrate.py inside a single transaction and
-- recorded in schema_migrations. Every statement is idempotent so the file can
-- be re-applied safely on a partially-migrated database.
--
-- ID strategy (critical for Postgres <-> Neo4j consistency)
--   documents.id is NOT random. The application derives it as
--       uuid5(ECH_NAMESPACE, f"{source_system}:{external_id}")
--   so the same source object always maps to the same UUID, and the Neo4j
--   Document node uses the identical value as its `document_id` property.
--   Re-ingesting a document therefore upserts the same row and the same node.
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- -----------------------------------------------------------------------------
-- Enumerations
-- -----------------------------------------------------------------------------
DO $$ BEGIN
    CREATE TYPE source_system AS ENUM ('confluence', 'sharepoint', 'github', 'manual');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
    -- Tracks the outbox-style saga between Postgres (system of record for
    -- documents) and Neo4j (system of record for relationships).
    CREATE TYPE graph_sync_status AS ENUM ('pending', 'synced', 'failed');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- -----------------------------------------------------------------------------
-- Helpers
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END $$;

-- -----------------------------------------------------------------------------
-- sources — configured connector instances
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sources (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name        TEXT NOT NULL UNIQUE,
    system      source_system NOT NULL,
    -- connector-specific settings (space keys, site URLs, repo filters, ...)
    config      JSONB NOT NULL DEFAULT '{}'::jsonb,
    enabled     BOOLEAN NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

DROP TRIGGER IF EXISTS trg_sources_updated_at ON sources;
CREATE TRIGGER trg_sources_updated_at
    BEFORE UPDATE ON sources
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
-- documents — one row per source object (page, file, README, issue, ...)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS documents (
    id                  UUID PRIMARY KEY,                  -- deterministic uuid5, see header
    source_id           UUID REFERENCES sources(id) ON DELETE SET NULL,
    source_system       source_system NOT NULL,
    external_id         TEXT NOT NULL,                     -- id inside the source system
    title               TEXT NOT NULL,
    uri                 TEXT,
    author              TEXT,
    mime_type           TEXT NOT NULL DEFAULT 'text/markdown',
    language            TEXT NOT NULL DEFAULT 'en',
    content_hash        TEXT NOT NULL,                     -- sha256 of normalised content
    content_length      INTEGER NOT NULL DEFAULT 0,
    version             INTEGER NOT NULL DEFAULT 1,        -- incremented when content_hash changes
    -- Schema-agnostic attributes (space, labels, repo, path, custom fields...)
    attributes          JSONB NOT NULL DEFAULT '{}'::jsonb,
    -- Graph synchronisation state (see graph_sync_status comment above)
    graph_sync_status   graph_sync_status NOT NULL DEFAULT 'pending',
    graph_node_id       TEXT,                              -- Neo4j elementId for traceability
    graph_synced_at     TIMESTAMPTZ,
    graph_sync_error    TEXT,
    source_created_at   TIMESTAMPTZ,
    source_updated_at   TIMESTAMPTZ,
    ingested_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at          TIMESTAMPTZ,                       -- soft delete
    title_tsv           TSVECTOR GENERATED ALWAYS AS (to_tsvector('english', coalesce(title, ''))) STORED,
    CONSTRAINT documents_source_external_unique UNIQUE (source_system, external_id),
    CONSTRAINT documents_content_length_nonneg CHECK (content_length >= 0)
);

CREATE INDEX IF NOT EXISTS documents_source_system_idx   ON documents (source_system);
CREATE INDEX IF NOT EXISTS documents_attributes_gin_idx  ON documents USING GIN (attributes jsonb_path_ops);
CREATE INDEX IF NOT EXISTS documents_title_tsv_idx       ON documents USING GIN (title_tsv);
CREATE INDEX IF NOT EXISTS documents_title_trgm_idx      ON documents USING GIN (title gin_trgm_ops);
CREATE INDEX IF NOT EXISTS documents_ingested_at_idx     ON documents (ingested_at DESC);
-- Partial index: the reconciliation job only scans rows that are not synced.
CREATE INDEX IF NOT EXISTS documents_graph_pending_idx   ON documents (graph_sync_status, updated_at)
    WHERE graph_sync_status <> 'synced';
CREATE INDEX IF NOT EXISTS documents_live_idx            ON documents (id) WHERE deleted_at IS NULL;

DROP TRIGGER IF EXISTS trg_documents_updated_at ON documents;
CREATE TRIGGER trg_documents_updated_at
    BEFORE UPDATE ON documents
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
-- chunks — semantic chunks of a document; the retrieval unit
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS chunks (
    id              UUID PRIMARY KEY,                      -- uuid5(document_id, chunk_index)
    document_id     UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    chunk_index     INTEGER NOT NULL,
    content         TEXT NOT NULL,
    token_count     INTEGER NOT NULL,
    char_start      INTEGER NOT NULL,
    char_end        INTEGER NOT NULL,
    -- heading hierarchy the chunk belongs to, e.g. {"Architecture","Storage"}
    section_path    TEXT[] NOT NULL DEFAULT '{}',
    metadata        JSONB NOT NULL DEFAULT '{}'::jsonb,
    -- Full-text search vector for the BM25-style keyword leg of hybrid search.
    content_tsv     TSVECTOR GENERATED ALWAYS AS (to_tsvector('english', content)) STORED,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT chunks_document_index_unique UNIQUE (document_id, chunk_index),
    CONSTRAINT chunks_span_valid CHECK (char_end >= char_start),
    CONSTRAINT chunks_token_count_positive CHECK (token_count > 0)
);

CREATE INDEX IF NOT EXISTS chunks_document_id_idx  ON chunks (document_id, chunk_index);
CREATE INDEX IF NOT EXISTS chunks_content_tsv_idx  ON chunks USING GIN (content_tsv);
CREATE INDEX IF NOT EXISTS chunks_metadata_gin_idx ON chunks USING GIN (metadata jsonb_path_ops);

COMMENT ON TABLE documents IS 'Canonical document metadata. id == Neo4j Document.document_id.';
COMMENT ON TABLE chunks    IS 'Retrieval units. id == Neo4j Chunk.chunk_id.';
COMMENT ON COLUMN documents.graph_sync_status IS 'pending -> synced | failed; reconciled by ingestion-service';

-- ============================================================ migrations/0002_embeddings.sql
-- =============================================================================
-- Migration 0002 — vector embeddings (pgvector)
--
-- One embedding per chunk. The dimension is fixed at 1536 to match
-- OpenAI text-embedding-3-small; other providers must project/pad to 1536
-- (zero-padding preserves cosine similarity, see ech_core.embeddings).
--
-- Index: HNSW with cosine distance. Parameters:
--   m = 16              connections per layer (recall/memory trade-off)
--   ef_construction=128 build-time candidate list (higher = better graph)
-- Query time: SET LOCAL hnsw.ef_search = N (set by the repository per query).
-- =============================================================================

CREATE TABLE IF NOT EXISTS embeddings (
    chunk_id    UUID PRIMARY KEY REFERENCES chunks(id) ON DELETE CASCADE,
    model       TEXT NOT NULL,                 -- provider:model identifier
    dimensions  INTEGER NOT NULL CHECK (dimensions > 0 AND dimensions <= 1536),
    embedding   vector(1536) NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS embeddings_hnsw_cosine_idx
    ON embeddings USING hnsw (embedding vector_cosine_ops)
    WITH (m = 16, ef_construction = 128);

CREATE INDEX IF NOT EXISTS embeddings_model_idx ON embeddings (model);

COMMENT ON TABLE embeddings IS 'Dense vectors for chunks; cosine HNSW index. 1 row per chunk.';

-- ============================================================ migrations/0003_pipeline_and_audit.sql
-- =============================================================================
-- Migration 0003 — ingestion pipeline state + audit trail
-- =============================================================================

DO $$ BEGIN
    CREATE TYPE ingestion_run_status AS ENUM
        ('queued', 'running', 'paused', 'completed', 'failed', 'cancelled');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- -----------------------------------------------------------------------------
-- ingestion_runs — one row per pipeline execution
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ingestion_runs (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    connector_name  TEXT NOT NULL,                 -- registry key, e.g. "confluence"
    source_system   source_system NOT NULL,
    status          ingestion_run_status NOT NULL DEFAULT 'queued',
    -- run-time options (full_refresh, limit, chunking overrides, ...)
    config          JSONB NOT NULL DEFAULT '{}'::jsonb,
    -- counters updated as the run progresses:
    -- {documents_seen, documents_upserted, documents_skipped, chunks_created,
    --  embeddings_created, entities_linked, graph_synced, graph_failed}
    stats           JSONB NOT NULL DEFAULT '{}'::jsonb,
    triggered_by    TEXT,
    error           TEXT,
    started_at      TIMESTAMPTZ,
    finished_at     TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ingestion_runs_created_at_idx ON ingestion_runs (created_at DESC);
CREATE INDEX IF NOT EXISTS ingestion_runs_status_idx     ON ingestion_runs (status)
    WHERE status IN ('queued', 'running', 'paused');

DROP TRIGGER IF EXISTS trg_ingestion_runs_updated_at ON ingestion_runs;
CREATE TRIGGER trg_ingestion_runs_updated_at
    BEFORE UPDATE ON ingestion_runs
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
-- ingestion_run_events — append-only progress log (also streamed over SSE)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ingestion_run_events (
    id          BIGSERIAL PRIMARY KEY,
    run_id      UUID NOT NULL REFERENCES ingestion_runs(id) ON DELETE CASCADE,
    level       TEXT NOT NULL DEFAULT 'info',   -- debug | info | warning | error
    event_type  TEXT NOT NULL,                  -- run.started, document.upserted, ...
    message     TEXT NOT NULL,
    payload     JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ingestion_run_events_run_idx ON ingestion_run_events (run_id, id);

-- Link documents back to the run that last touched them.
ALTER TABLE documents
    ADD COLUMN IF NOT EXISTS last_run_id UUID REFERENCES ingestion_runs(id) ON DELETE SET NULL;

-- -----------------------------------------------------------------------------
-- audit_logs — who did what, when, how long it took
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_logs (
    id              BIGSERIAL PRIMARY KEY,
    request_id      TEXT,
    actor           TEXT,                       -- api key id / user / "system"
    action          TEXT NOT NULL,              -- context.retrieve, pipeline.trigger, ...
    resource_type   TEXT,
    resource_id     TEXT,
    status          TEXT NOT NULL DEFAULT 'ok', -- ok | error
    latency_ms      DOUBLE PRECISION,
    details         JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS audit_logs_created_at_idx ON audit_logs (created_at DESC);
CREATE INDEX IF NOT EXISTS audit_logs_action_idx     ON audit_logs (action, created_at DESC);

COMMENT ON TABLE ingestion_runs       IS 'Pipeline executions; stats JSONB holds live counters.';
COMMENT ON TABLE ingestion_run_events IS 'Append-only run log; mirrored to SSE subscribers.';
COMMENT ON TABLE audit_logs           IS 'Immutable audit trail for API and pipeline actions.';

-- ============================================================ migrations/0004_genie.sql
-- =============================================================================
-- Migration 0004 — Genie: curated spaces, conversations and messages
--
-- A *space* scopes what Genie may read (RetrievalFilters as JSONB), adds standing
-- instructions and sample questions, like a Databricks Genie space curates tables.
-- Conversations and messages persist every answer with its citations, trace
-- (tool calls, Cypher executed), follow-ups, token usage and user feedback.
-- =============================================================================

CREATE TABLE IF NOT EXISTS genie_spaces (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name             TEXT NOT NULL,
    description      TEXT NOT NULL DEFAULT '',
    -- standing guidance appended to the system prompt for this space
    instructions     TEXT NOT NULL DEFAULT '',
    -- ech_core.schemas.context.RetrievalFilters: {source_systems, document_ids, attributes}
    filters          JSONB NOT NULL DEFAULT '{}'::jsonb,
    sample_questions JSONB NOT NULL DEFAULT '[]'::jsonb,
    is_default       BOOLEAN NOT NULL DEFAULT false,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- at most one default space
CREATE UNIQUE INDEX IF NOT EXISTS genie_spaces_default_idx ON genie_spaces (is_default)
    WHERE is_default;

DROP TRIGGER IF EXISTS trg_genie_spaces_updated_at ON genie_spaces;
CREATE TRIGGER trg_genie_spaces_updated_at
    BEFORE UPDATE ON genie_spaces
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS genie_conversations (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    space_id    UUID NOT NULL REFERENCES genie_spaces (id) ON DELETE CASCADE,
    title       TEXT NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS genie_conversations_space_idx
    ON genie_conversations (space_id, updated_at DESC);

DROP TRIGGER IF EXISTS trg_genie_conversations_updated_at ON genie_conversations;
CREATE TRIGGER trg_genie_conversations_updated_at
    BEFORE UPDATE ON genie_conversations
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS genie_messages (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id  UUID NOT NULL REFERENCES genie_conversations (id) ON DELETE CASCADE,
    role             TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
    content          TEXT NOT NULL,
    status           TEXT NOT NULL DEFAULT 'complete'
                     CHECK (status IN ('complete', 'error', 'cancelled')),
    error            TEXT,
    -- [{marker, chunk_id, document_id, title, path, source_system, uri, score, chunk_index, snippet}]
    citations        JSONB NOT NULL DEFAULT '[]'::jsonb,
    -- [{step, tool, summary, input, detail, ok, duration_ms, rows, narration}]
    trace            JSONB NOT NULL DEFAULT '[]'::jsonb,
    follow_ups       JSONB NOT NULL DEFAULT '[]'::jsonb,
    usage            JSONB NOT NULL DEFAULT '{}'::jsonb,
    model            TEXT,
    latency_ms       INTEGER,
    feedback         SMALLINT CHECK (feedback IN (-1, 1)),
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS genie_messages_conversation_idx
    ON genie_messages (conversation_id, created_at, id);

-- -----------------------------------------------------------------------------
-- The default space: everything the hub has indexed.
-- -----------------------------------------------------------------------------
INSERT INTO genie_spaces (id, name, description, instructions, filters, sample_questions, is_default)
VALUES (
    '00000000-0000-4000-8000-000000000001',
    'Everything in the hub',
    'Every source the hub has indexed: documents, code, their entities and lineage.',
    '',
    '{}'::jsonb,
    '["Which technologies does the knowledge base mention most, and where?",
      "Who are the main contributors and what did they work on?",
      "Summarise the architecture described in the indexed documents.",
      "Which documents reference each other the most?"]'::jsonb,
    true
)
ON CONFLICT (id) DO NOTHING;

-- ============================================================ migrations/0005_semantic_layer.sql
-- =============================================================================
-- Migration 0005 — semantic layer over Snowflake / Databricks catalog metadata
--
-- Each ingested table-like object is both a hub document (rendered markdown, chunked,
-- embedded, in the graph) and a structured semantic asset with fields (roles),
-- relationships (keys, joins, lineage) and metrics (declared and inferred).
-- semantic_assets.id == documents.id (uuid5 of source_system:fqn).
-- =============================================================================

ALTER TYPE source_system ADD VALUE IF NOT EXISTS 'snowflake';
ALTER TYPE source_system ADD VALUE IF NOT EXISTS 'databricks';

CREATE TABLE IF NOT EXISTS semantic_assets (
    id                 UUID PRIMARY KEY,
    document_id        UUID NOT NULL UNIQUE REFERENCES documents (id) ON DELETE CASCADE,
    source_system      source_system NOT NULL,
    platform           TEXT NOT NULL,                      -- snowflake | databricks
    fqn                TEXT NOT NULL,                      -- database.schema.name
    database_name      TEXT NOT NULL,
    schema_name        TEXT NOT NULL,
    name               TEXT NOT NULL,
    asset_type         TEXT NOT NULL,                      -- table | view | metric_view | ...
    kind               TEXT NOT NULL DEFAULT 'unknown',    -- fact | dimension | bridge | metric | reference
    description        TEXT NOT NULL DEFAULT '',
    owner              TEXT,
    tags               JSONB NOT NULL DEFAULT '[]'::jsonb,
    properties         JSONB NOT NULL DEFAULT '{}'::jsonb,
    definition         TEXT,
    uri                TEXT,
    field_count        INTEGER NOT NULL DEFAULT 0,
    row_count          BIGINT,
    bytes              BIGINT,
    source_created_at  TIMESTAMPTZ,
    source_updated_at  TIMESTAMPTZ,
    synced_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (source_system, fqn)
);

CREATE INDEX IF NOT EXISTS semantic_assets_scope_idx
    ON semantic_assets (source_system, database_name, schema_name, name);
CREATE INDEX IF NOT EXISTS semantic_assets_kind_idx ON semantic_assets (kind, asset_type);
CREATE INDEX IF NOT EXISTS semantic_assets_fqn_trgm_idx
    ON semantic_assets USING gin (fqn gin_trgm_ops);
CREATE INDEX IF NOT EXISTS semantic_assets_fts_idx
    ON semantic_assets USING gin (to_tsvector('english', fqn || ' ' || description));

DROP TRIGGER IF EXISTS trg_semantic_assets_updated_at ON semantic_assets;
CREATE TRIGGER trg_semantic_assets_updated_at
    BEFORE UPDATE ON semantic_assets
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS semantic_fields (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    asset_id         UUID NOT NULL REFERENCES semantic_assets (id) ON DELETE CASCADE,
    name             TEXT NOT NULL,
    ordinal          INTEGER NOT NULL DEFAULT 0,
    data_type        TEXT NOT NULL DEFAULT '',
    description      TEXT NOT NULL DEFAULT '',
    nullable         BOOLEAN,
    is_primary_key   BOOLEAN NOT NULL DEFAULT false,
    is_partition     BOOLEAN NOT NULL DEFAULT false,
    role             TEXT NOT NULL DEFAULT 'attribute',   -- identifier | dimension | time | measure | attribute
    role_confidence  REAL NOT NULL DEFAULT 0,
    aggregation      TEXT,
    tags             JSONB NOT NULL DEFAULT '[]'::jsonb,
    synonyms         JSONB NOT NULL DEFAULT '[]'::jsonb,
    UNIQUE (asset_id, name)
);

CREATE INDEX IF NOT EXISTS semantic_fields_name_trgm_idx
    ON semantic_fields USING gin (name gin_trgm_ops);
CREATE INDEX IF NOT EXISTS semantic_fields_role_idx ON semantic_fields (role);

-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS semantic_relationships (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_asset_id   UUID NOT NULL REFERENCES semantic_assets (id) ON DELETE CASCADE,
    target_fqn        TEXT NOT NULL,                       -- kept even when the target is not ingested
    target_asset_id   UUID REFERENCES semantic_assets (id) ON DELETE SET NULL,
    kind              TEXT NOT NULL,                       -- foreign_key | join_declared | join_inferred | lineage_* | metric_source
    source_columns    JSONB NOT NULL DEFAULT '[]'::jsonb,
    target_columns    JSONB NOT NULL DEFAULT '[]'::jsonb,
    confidence        REAL NOT NULL DEFAULT 1,
    evidence          TEXT NOT NULL DEFAULT '',
    UNIQUE (source_asset_id, target_fqn, kind, source_columns)
);

CREATE INDEX IF NOT EXISTS semantic_relationships_target_idx
    ON semantic_relationships (target_asset_id);
CREATE INDEX IF NOT EXISTS semantic_relationships_target_fqn_idx
    ON semantic_relationships (target_fqn);

-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS semantic_metrics (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    asset_id      UUID NOT NULL REFERENCES semantic_assets (id) ON DELETE CASCADE,
    name          TEXT NOT NULL,
    expression    TEXT NOT NULL DEFAULT '',
    aggregation   TEXT,
    description   TEXT NOT NULL DEFAULT '',
    source        TEXT NOT NULL DEFAULT 'inferred',       -- declared | inferred
    dimensions    JSONB NOT NULL DEFAULT '[]'::jsonb,
    fields        JSONB NOT NULL DEFAULT '[]'::jsonb,
    synonyms      JSONB NOT NULL DEFAULT '[]'::jsonb,
    UNIQUE (asset_id, name)
);

CREATE INDEX IF NOT EXISTS semantic_metrics_name_trgm_idx
    ON semantic_metrics USING gin (name gin_trgm_ops);

-- ============================================================ migrations/0006_personas.sql
-- =============================================================================
-- Migration 0006 — Personas: one Genie space per persona
--
-- The admin UI has a Data Engineer and a Business Analyst workspace. Each asks
-- Genie through its own space so the standing instructions and sample questions
-- match the audience: technical (keys, joins, lineage, SQL) versus business
-- (what a metric means, how it is defined, what it can be broken down by).
-- =============================================================================

ALTER TABLE genie_spaces
    ADD COLUMN IF NOT EXISTS persona TEXT
        CHECK (persona IS NULL OR persona IN ('data_engineer', 'business_analyst'));

-- at most one space per persona
CREATE UNIQUE INDEX IF NOT EXISTS genie_spaces_persona_idx ON genie_spaces (persona)
    WHERE persona IS NOT NULL;

INSERT INTO genie_spaces (id, name, description, instructions, filters, sample_questions, is_default, persona)
VALUES
(
    '00000000-0000-4000-8000-000000000002',
    'Data Engineer',
    'Schemas, keys, joins, lineage, pipelines and SQL over the catalog metadata and the code that builds it.',
    'You are assisting a data engineer. Answer with technical precision: fully qualified names, '
    'column data types, primary and foreign keys, declared versus inferred joins with their '
    'confidence, upstream and downstream lineage, and the pipeline code that builds an asset. '
    'When asked how to query or join, write the SQL (state the dialect: Databricks SQL or '
    'Snowflake) and name every key you rely on. Call out missing keys, undocumented columns, '
    'inferred-only joins and stale syncs as risks. Prefer describe_asset and get_lineage over '
    'guessing, and cite the assets and files you used.',
    '{}'::jsonb,
    '["Which fact tables have no primary key, and what would you key them on?",
      "Which joins are only inferred and need review before anyone relies on them?",
      "Show the lineage of the claims fact: what feeds it and what reads from it?",
      "Write Databricks SQL that joins claim payments to claims and names every key it relies on.",
      "What did the last catalog sync ingest, and which assets have no description or owner?"]'::jsonb,
    false,
    'data_engineer'
),
(
    '00000000-0000-4000-8000-000000000003',
    'Business Analyst',
    'Business questions answered in plain language from governed metrics and their definitions.',
    'You are assisting a business analyst who does not read SQL unless they ask for it. Answer '
    'in business language: what a metric means, how it is calculated in words, which dimensions '
    'it can be broken down by, where the governed definition lives and whether it is declared '
    '(governed) or inferred. Prefer declared metrics and metric views; say plainly when a number '
    'is not certified or a definition is still a draft. Avoid table and column jargon unless the '
    'user asks; when you must name a dataset, say what it represents. Offer SQL only when asked, '
    'labelled with its dialect, and cite the assets you used.',
    '{}'::jsonb,
    '["Which metrics are governed, and what does each one measure?",
      "How is claim count defined, and what can I break it down by?",
      "Which business domains does the catalog cover, and how complete is each?",
      "Is there a certified measure of premium collected, or only a record count?",
      "What can the members metric view tell me, and what can it not?"]'::jsonb,
    false,
    'business_analyst'
)
ON CONFLICT (id) DO UPDATE SET persona = EXCLUDED.persona;

-- ============================================================ migrations/0007_document_kind.sql
-- =============================================================================
-- Migration 0007 — Document kind
--
-- Every catalog asset is stored as a document so it can be chunked, embedded,
-- graphed and cited, but to a reader a table is a dataset, not a page. `kind`
-- makes the distinction explicit: 'document' (pages, files, code) or 'dataset'
-- (tables, views, metric views that also have a row in semantic_assets).
-- The pipeline sets it on every upsert; this backfills what is already indexed.
-- =============================================================================

ALTER TABLE documents
    ADD COLUMN IF NOT EXISTS kind TEXT NOT NULL DEFAULT 'document'
        CHECK (kind IN ('document', 'dataset'));

UPDATE documents d
   SET kind = 'dataset'
 WHERE d.kind <> 'dataset'
   AND EXISTS (SELECT 1 FROM semantic_assets a WHERE a.id = d.id);

CREATE INDEX IF NOT EXISTS documents_kind_idx ON documents (kind) WHERE deleted_at IS NULL;

-- ============================================================ migrations/0008_semantic_business.sql
-- =============================================================================
-- Migration 0008 — Business names, meanings and model-assisted enrichment
--
-- Assets, columns and metrics carry a business-friendly display name and a
-- one-line summary next to their technical name. `name_source` / `kind_source`
-- say where a name or classification came from: derived (naming rules),
-- declared (the platform), model (accepted Claude suggestion) or curated (edited
-- by a person). `enrichment` holds the latest model suggestion with its status.
-- The pipeline recomputes derived names on every sync but never overwrites
-- model or curated ones; the backfill below names what is already indexed.
-- =============================================================================

ALTER TABLE semantic_assets
    ADD COLUMN IF NOT EXISTS display_name TEXT NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS summary      TEXT NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS name_source  TEXT NOT NULL DEFAULT 'derived'
        CHECK (name_source IN ('derived', 'declared', 'model', 'curated')),
    ADD COLUMN IF NOT EXISTS kind_source  TEXT NOT NULL DEFAULT 'inferred'
        CHECK (kind_source IN ('inferred', 'declared', 'model', 'curated')),
    ADD COLUMN IF NOT EXISTS enrichment   JSONB NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE semantic_fields  ADD COLUMN IF NOT EXISTS display_name TEXT NOT NULL DEFAULT '';
ALTER TABLE semantic_metrics ADD COLUMN IF NOT EXISTS display_name TEXT NOT NULL DEFAULT '';

-- Backfill derived names for everything already indexed (Python naming rules are richer;
-- the next connector run replaces these).
UPDATE semantic_assets
   SET display_name = initcap(replace(
           regexp_replace(
               regexp_replace(name, '^(fact|fct|dim|dims|dimension|mv|bridge|brg|ref|lkp|lookup|stg|raw|src|tbl|vw|v)_', '', 'i'),
               '(_v[0-9]+|_draft|_tbl|_table|_view|_vw)+$', '', 'i'),
           '_', ' '))
 WHERE display_name = '';

UPDATE semantic_assets
   SET summary = left(split_part(description, '. ', 1), 180)
 WHERE summary = '' AND coalesce(description, '') <> '';

UPDATE semantic_assets SET kind_source = 'declared' WHERE asset_type IN ('metric_view', 'semantic_view');

UPDATE semantic_fields  SET display_name = initcap(replace(name, '_', ' ')) WHERE display_name = '';
UPDATE semantic_metrics SET display_name = initcap(replace(name, '_', ' ')) WHERE display_name = '';

CREATE INDEX IF NOT EXISTS semantic_assets_display_name_trgm_idx
    ON semantic_assets USING gin (display_name gin_trgm_ops);

-- ============================================================ migrations/0009_personas_ops.sql
-- =============================================================================
-- Migration 0009 — Personas: QA Engineer, Architect and SRE
--
-- Three more workspaces, each asking Genie through its own space. The persona
-- check constraint from 0006 is widened; the spaces are seeded with standing
-- instructions and sample questions that match the audience:
--   qa_engineer  evidence, checks, assertions, failures and review backlog
--   architect    platforms, domains, conformed dimensions, integration surface
--   sre          what is broken now, runbook-style answers, numbers and verification
-- =============================================================================

ALTER TABLE genie_spaces DROP CONSTRAINT IF EXISTS genie_spaces_persona_check;
ALTER TABLE genie_spaces
    ADD CONSTRAINT genie_spaces_persona_check
    CHECK (persona IS NULL OR persona IN (
        'data_engineer', 'business_analyst', 'qa_engineer', 'architect', 'sre'
    ));

INSERT INTO genie_spaces (id, name, description, instructions, filters, sample_questions, is_default, persona)
VALUES
(
    '00000000-0000-4000-8000-000000000004',
    'QA Engineer',
    'Data quality evidence: gaps, failures, inferred-only structure and the checks that would catch regressions.',
    'You are assisting a QA engineer responsible for data quality and release readiness. '
    'Lead with evidence, not reassurance: which assets lack descriptions, owners or keys, which '
    'joins are only inferred and at what confidence, which metrics are inferred rather than '
    'declared, which pipeline runs failed and why, and where a declared definition disagrees '
    'with the columns that actually exist. Propose concrete checks (null, uniqueness, '
    'referential integrity, freshness, row-count reconciliation, accepted-value sets) and write '
    'each as a SQL assertion labelled with its dialect (Databricks SQL or Snowflake). Rate the '
    'risk and severity of every finding. Prefer describe_asset, semantic_search and get_lineage '
    'over guessing, and cite the assets, runs and documents you used.',
    '{}'::jsonb,
    '["Which fact tables would fail a primary-key uniqueness check because no key is declared?",
      "List the joins that are only inferred below 80% confidence and write a referential-integrity check for each.",
      "Which assets still have an unclassified kind or a Claude suggestion nobody reviewed?",
      "Write freshness and row-count reconciliation checks for the claims fact and its silver source.",
      "What failed in the last pipeline runs, and which documents did not reach the graph?"]'::jsonb,
    false,
    'qa_engineer'
),
(
    '00000000-0000-4000-8000-000000000005',
    'Architect',
    'Platforms, domains, conformed dimensions, lineage across systems and the integration surface the hub exposes.',
    'You are assisting a data and solution architect. Answer at the level of domains, platforms, '
    'integration points and design trade-offs: which platforms and catalogs exist and what each '
    'holds, how subject areas relate, which dimensions are shared by several facts (conformed '
    'dimensions), where lineage crosses platforms or layers, where datasets are duplicated or '
    'overlap (bronze and silver copies, legacy extracts), and what the governed model exposes to '
    'consumers (metric views, semantic views, exports, the retrieval API). Recommend target-state '
    'structures, name the assets you base them on, state assumptions, and draw a Mermaid diagram '
    'when it clarifies. Cite the assets and documents you used.',
    '{}'::jsonb,
    '["Which dimensions are shared by two or more facts, and which facts have none of them?",
      "Draw the subject areas of the catalog and how lineage connects them across layers.",
      "Where are the same entities modelled twice (bronze versus silver, legacy views), and which copy should consumers use?",
      "What does the hub expose to downstream tools, and which platform owns each definition?",
      "Propose a target star schema for life insurance policies from the assets that exist today."]'::jsonb,
    false,
    'architect'
),
(
    '00000000-0000-4000-8000-000000000006',
    'SRE',
    'Operating the hub: failed or stale runs, graph sync failures, slow or erroring retrieval, stale catalogs.',
    'You are assisting a site reliability engineer who operates the context hub and its pipelines. '
    'Prioritise what is broken or at risk now: failed, stuck or stale ingestion runs, documents '
    'whose graph sync failed, slow or erroring retrieval and Genie calls, stale catalog syncs and '
    'connectors that have not succeeded recently. Answer runbook-style: symptom, likely cause, '
    'how to confirm it (which endpoint, log, run or table), the remediation, and how to verify '
    'the fix. Quantify with the numbers you can find, say what you could not verify, and never '
    'claim something is healthy without evidence. Cite the assets, runs and documents you used.',
    '{}'::jsonb,
    '["Which runs failed or stalled recently, and what is the first thing to check for each?",
      "Which documents failed graph sync, and how do I reconcile them?",
      "Is retrieval latency within budget, and which calls are the slowest?",
      "When did each connector last succeed, and which catalogs are stale?",
      "Give me a runbook for a Databricks token that expired mid-run."]'::jsonb,
    false,
    'sre'
)
ON CONFLICT (id) DO UPDATE SET persona = EXCLUDED.persona;

-- ============================================================ migrations/0010_grafana_source.sql
-- 0010: Grafana joins the sources (dashboards, panel queries and alert rules as documents).
-- ALTER TYPE ... ADD VALUE is idempotent with IF NOT EXISTS, like 0005 did for the platforms.
ALTER TYPE source_system ADD VALUE IF NOT EXISTS 'grafana';

-- ============================================================ migrations/0011_glossary_domains_kpis.sql
-- =============================================================================
-- Migration 0011 — Business glossary, insurance domain taxonomy and KPIs
--
-- semantic_domains     a two-level taxonomy of business domains, aligned to the ACORD
--                      capability model for insurance; party, contract and money concepts
--                      reference FIBO. `standard` says where a node comes from.
-- semantic_terms       canonical business terms with definitions and synonyms; seeded here,
--                      curated in the UI (status). `kind` says what a term names.
-- semantic_term_links  a term applied to a dataset, a column or a metric, with confidence,
--                      provenance (rule | model | curated) and the same review states as
--                      enrichment. Accepting a link copies the term's synonyms onto the
--                      column or metric and sets the dataset's domain.
-- semantic_kpis        business KPI definitions: grain, period, unit, direction and targets,
--                      optionally bound to a governed metric.
-- semantic_assets.domain_key  the business domain a dataset belongs to.
-- Everything here is reference vocabulary: idempotent and safe to re-run.
-- =============================================================================

CREATE TABLE IF NOT EXISTS semantic_domains (
    key          TEXT PRIMARY KEY,
    name         TEXT NOT NULL,
    parent_key   TEXT REFERENCES semantic_domains(key) ON DELETE SET NULL,
    description  TEXT NOT NULL DEFAULT '',
    standard     TEXT NOT NULL DEFAULT 'hub' CHECK (standard IN ('acord', 'fibo', 'hub')),
    standard_ref TEXT NOT NULL DEFAULT '',
    sort_order   INT  NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS semantic_terms (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    key          TEXT NOT NULL UNIQUE,
    name         TEXT NOT NULL,
    definition   TEXT NOT NULL DEFAULT '',
    domain_key   TEXT REFERENCES semantic_domains(key) ON DELETE SET NULL,
    kind         TEXT NOT NULL DEFAULT 'entity'
                 CHECK (kind IN ('entity', 'attribute', 'measure', 'event', 'code')),
    synonyms     JSONB NOT NULL DEFAULT '[]'::jsonb,
    standard     TEXT NOT NULL DEFAULT 'hub' CHECK (standard IN ('acord', 'fibo', 'hub')),
    standard_ref TEXT NOT NULL DEFAULT '',
    status       TEXT NOT NULL DEFAULT 'seeded' CHECK (status IN ('seeded', 'curated')),
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS semantic_terms_domain_idx ON semantic_terms (domain_key);

CREATE TABLE IF NOT EXISTS semantic_term_links (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    term_id     UUID NOT NULL REFERENCES semantic_terms(id) ON DELETE CASCADE,
    target_type TEXT NOT NULL CHECK (target_type IN ('asset', 'field', 'metric')),
    target_id   UUID NOT NULL,
    confidence  REAL NOT NULL DEFAULT 0,
    source      TEXT NOT NULL CHECK (source IN ('rule', 'model', 'curated')),
    status      TEXT NOT NULL DEFAULT 'suggested'
                CHECK (status IN ('suggested', 'accepted', 'rejected')),
    rationale   TEXT NOT NULL DEFAULT '',
    model       TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    decided_at  TIMESTAMPTZ,
    UNIQUE (term_id, target_type, target_id)
);
CREATE INDEX IF NOT EXISTS semantic_term_links_target_idx ON semantic_term_links (target_type, target_id);
CREATE INDEX IF NOT EXISTS semantic_term_links_status_idx ON semantic_term_links (status);

CREATE TABLE IF NOT EXISTS semantic_kpis (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    key          TEXT NOT NULL UNIQUE,
    name         TEXT NOT NULL,
    domain_key   TEXT REFERENCES semantic_domains(key) ON DELETE SET NULL,
    term_id      UUID REFERENCES semantic_terms(id) ON DELETE SET NULL,
    metric_id    UUID REFERENCES semantic_metrics(id) ON DELETE SET NULL,
    definition   TEXT NOT NULL DEFAULT '',
    formula      TEXT NOT NULL DEFAULT '',
    grain        TEXT NOT NULL DEFAULT '',
    period       TEXT NOT NULL DEFAULT 'monthly',
    unit         TEXT NOT NULL DEFAULT 'ratio',
    direction    TEXT NOT NULL DEFAULT 'higher' CHECK (direction IN ('higher', 'lower')),
    target_value DOUBLE PRECISION,
    warn_value   DOUBLE PRECISION,
    owner        TEXT NOT NULL DEFAULT '',
    standard_ref TEXT NOT NULL DEFAULT '',
    status       TEXT NOT NULL DEFAULT 'seeded' CHECK (status IN ('seeded', 'curated')),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE semantic_assets
    ADD COLUMN IF NOT EXISTS domain_key TEXT REFERENCES semantic_domains(key) ON DELETE SET NULL;

-- ---------------------------------------------------------------------------
-- Domains: ACORD capability-model areas, two levels deep.
-- ---------------------------------------------------------------------------
INSERT INTO semantic_domains (key, name, parent_key, description, standard, standard_ref, sort_order) VALUES
  ('party',        'Party & Customer',               NULL, 'People and organisations the insurer deals with: customers, insureds, beneficiaries, applicants.', 'acord', 'ACORD IM: Party; FIBO FND Parties', 10),
  ('customer',     'Customer',                       'party', 'The party that buys and owns insurance contracts.', 'acord', 'ACORD IM: Customer', 11),
  ('applicant',    'Applicant & Risk Profile',       'party', 'People applying for cover and the risk information gathered about them.', 'acord', 'ACORD IM: Applicant', 12),
  ('product',      'Product & Coverage',             NULL, 'Insurance products, plans, coverages and riders as designed and priced.', 'acord', 'ACORD capability: Product Development', 20),
  ('distribution', 'Distribution & Sales',           NULL, 'Producers, agencies, channels, quotes and the commissions they earn.', 'acord', 'ACORD capability: Distribution', 30),
  ('underwriting', 'Underwriting & New Business',    NULL, 'Applications, risk assessment, underwriting decisions and issue.', 'acord', 'ACORD capability: Underwriting', 40),
  ('policy',       'Policy Administration',          NULL, 'The in-force contract through its life: issue, changes, renewal, lapse, surrender, maturity.', 'acord', 'ACORD capability: Policy Administration; FIBO FND Contracts', 50),
  ('policy_lifecycle', 'Policy Lifecycle Events',    'policy', 'Issue, endorsement, renewal, reinstatement, lapse, surrender and termination events.', 'acord', 'ACORD IM: Policy events', 51),
  ('inforce',      'In-force Portfolio',             'policy', 'The book of active contracts and its values at a point in time.', 'acord', 'ACORD IM: Policy', 52),
  ('billing',      'Billing & Collections',          NULL, 'Invoicing, premium collection, payment allocation and arrears.', 'acord', 'ACORD capability: Billing', 60),
  ('claims',       'Claims',                         NULL, 'Notification, adjudication, reserving and payment of claims.', 'acord', 'ACORD capability: Claims', 70),
  ('fnol',         'Notification & Intake',          'claims', 'First notice of loss and claim registration.', 'acord', 'ACORD IM: Claim notification', 71),
  ('adjudication', 'Adjudication & Payment',         'claims', 'Assessment, decision and settlement of claims, including service lines.', 'acord', 'ACORD IM: Claim settlement', 72),
  ('claims_reserving', 'Claim Reserves',             'claims', 'Case and incurred-but-not-reported reserves held for open claims.', 'acord', 'ACORD IM: Claim reserve', 73),
  ('reinsurance',  'Reinsurance',                    NULL, 'Treaties, cessions and retentions with reinsurers.', 'acord', 'ACORD capability: Reinsurance', 80),
  ('actuarial',    'Actuarial, Valuation & Experience', NULL, 'Reserving, valuation and experience studies such as lapse and mortality.', 'acord', 'ACORD capability: Actuarial', 90),
  ('valuation',    'Valuation & Reserving',          'actuarial', 'Statutory and economic reserves, cash values and the assumptions behind them.', 'acord', 'ACORD capability: Actuarial', 91),
  ('experience',   'Experience Studies',             'actuarial', 'Actual-to-expected analysis of lapse, mortality and other decrements.', 'hub', '', 92),
  ('finance',      'Finance & Accounting',           NULL, 'Premium and claims accounting, expenses, ratios and currency.', 'acord', 'ACORD capability: Finance; FIBO FND Accounting', 100),
  ('service',      'Customer Service & Operations',  NULL, 'Service cases, complaints and interactions.', 'acord', 'ACORD capability: Customer Service', 110),
  ('risk',         'Risk & Compliance',              NULL, 'Personal data, identity verification and regulatory obligations.', 'hub', '', 120),
  ('data_platform','Data Platform',                  NULL, 'Technical columns and datasets that exist for ingestion, lineage and control, not for the business.', 'hub', '', 130)
ON CONFLICT (key) DO NOTHING;

-- ---------------------------------------------------------------------------
-- Terms: canonical insurance vocabulary with synonyms. Apostrophes avoided on purpose.
-- ---------------------------------------------------------------------------
INSERT INTO semantic_terms (key, name, domain_key, kind, synonyms, definition, standard, standard_ref)
SELECT v.key, v.name, v.domain_key, v.kind, v.synonyms::jsonb, v.definition, v.standard, v.standard_ref
FROM (VALUES
  ('party', 'Party', 'party', 'entity', '["party","legal entity","person or organisation"]', 'A person or organisation that plays a role in an insurance relationship.', 'fibo', 'fibo-fnd-pty-pty:Party'),
  ('customer', 'Customer', 'customer', 'entity', '["customer","client","account holder","policy owner"]', 'The party that buys insurance and owns the relationship with the insurer.', 'acord', 'ACORD IM: Customer'),
  ('policyholder', 'Policyholder', 'customer', 'entity', '["policyholder","policy owner","owner","contract owner","contract holder"]', 'The party that owns a policy and holds its rights and obligations.', 'acord', 'ACORD IM: Policyholder'),
  ('insured', 'Insured', 'party', 'entity', '["insured","life assured","life insured","covered person","member"]', 'The person or object whose life, health or property the policy covers.', 'acord', 'ACORD IM: Insured'),
  ('beneficiary', 'Beneficiary', 'party', 'entity', '["beneficiary","payee","nominee"]', 'The party entitled to receive benefits when a covered event occurs.', 'acord', 'ACORD IM: Beneficiary'),
  ('applicant', 'Applicant', 'applicant', 'entity', '["applicant","proposer","prospect"]', 'A person applying for cover before a policy is issued.', 'acord', 'ACORD IM: Applicant'),
  ('household', 'Household', 'customer', 'entity', '["household","family unit"]', 'A group of customers who live together and are treated as one relationship.', 'hub', ''),
  ('employer_group', 'Employer Group', 'customer', 'entity', '["employer","group","plan sponsor","group policyholder"]', 'An employer or association that sponsors group insurance for its members.', 'acord', 'ACORD IM: Group'),
  ('member', 'Member', 'party', 'entity', '["member","plan member","certificate holder","enrollee"]', 'A person covered under a group policy, usually holding a certificate.', 'acord', 'ACORD IM: Member'),
  ('product', 'Product', 'product', 'entity', '["product","insurance product","plan"]', 'A designed and priced insurance offering that policies are issued under.', 'acord', 'ACORD IM: Product'),
  ('line_of_business', 'Line of Business', 'product', 'code', '["line of business","lob","business line","product line"]', 'The top-level grouping of products, such as life, health, annuity or property.', 'acord', 'ACORD IM: LineOfBusiness'),
  ('coverage', 'Coverage', 'product', 'entity', '["coverage","cover","benefit","protection"]', 'A specific promise within a policy: what is covered, for how much, under which conditions.', 'acord', 'ACORD IM: Coverage'),
  ('rider', 'Rider', 'product', 'entity', '["rider","optional benefit","supplementary benefit","endorsement benefit"]', 'An optional coverage attached to a base policy.', 'acord', 'ACORD IM: Rider'),
  ('plan_code', 'Plan Code', 'product', 'code', '["plan code","product code","plan id"]', 'The code identifying a product or plan on the administration system.', 'hub', ''),
  ('benefit_amount', 'Benefit Amount', 'product', 'measure', '["benefit amount","sum assured","face amount","face value","death benefit","coverage amount","sum insured"]', 'The amount payable when the covered event occurs.', 'acord', 'ACORD IM: CoverageAmount'),
  ('producer', 'Producer', 'distribution', 'entity', '["producer","agent","broker","advisor","adviser","intermediary"]', 'The licensed person or firm that sells and services policies.', 'acord', 'ACORD IM: Producer'),
  ('agency', 'Agency', 'distribution', 'entity', '["agency","brokerage","distributor","firm"]', 'The organisation a producer belongs to.', 'acord', 'ACORD IM: Agency'),
  ('channel', 'Channel', 'distribution', 'code', '["channel","distribution channel","sales channel"]', 'How a policy was sold: agent, broker, direct, bank or online.', 'acord', 'ACORD IM: DistributionChannel'),
  ('commission', 'Commission', 'distribution', 'measure', '["commission","producer compensation","commission amount"]', 'Compensation paid to a producer for selling or servicing a policy.', 'acord', 'ACORD IM: Commission'),
  ('bank_branch', 'Bank Branch', 'distribution', 'entity', '["bank branch","branch","branch directory"]', 'A bank branch acting as a distribution point for bancassurance.', 'hub', ''),
  ('application', 'Application', 'underwriting', 'entity', '["application","proposal","proposal form"]', 'The request for cover submitted by an applicant, with the information needed to underwrite it.', 'acord', 'ACORD IM: Application'),
  ('quote', 'Quote', 'underwriting', 'entity', '["quote","quotation","illustration"]', 'A priced offer of cover before an application is bound.', 'acord', 'ACORD IM: Quote'),
  ('underwriting_decision', 'Underwriting Decision', 'underwriting', 'event', '["underwriting decision","decision","approval","decline","rating decision"]', 'The outcome of risk assessment: approve, rate, postpone or decline.', 'acord', 'ACORD IM: UnderwritingDecision'),
  ('risk_class', 'Risk Class', 'applicant', 'code', '["risk class","rate class","underwriting class","applicant risk","risk rating"]', 'The underwriting classification that determines the premium rate.', 'acord', 'ACORD IM: RiskClass'),
  ('medical_exam', 'Medical Exam', 'underwriting', 'event', '["medical exam","paramedical","medical requirement"]', 'A medical requirement gathered to underwrite an application.', 'acord', 'ACORD IM: MedicalRequirement'),
  ('policy', 'Policy', 'policy', 'entity', '["policy","contract","policy contract","certificate","insurance contract"]', 'The contract between the insurer and the policyholder that sets out cover, premium and term.', 'acord', 'ACORD IM: Policy; fibo-fnd-agr-ctr:Contract'),
  ('policy_number', 'Policy Number', 'policy', 'attribute', '["policy number","policy id","policy no","contract number","contract id"]', 'The identifier of a policy on the administration system.', 'acord', 'ACORD IM: PolicyNumber'),
  ('policy_status', 'Policy Status', 'policy', 'attribute', '["policy status","contract status","status"]', 'Where the contract is in its life: pending, in force, lapsed, surrendered, matured, terminated.', 'acord', 'ACORD IM: PolicyStatus'),
  ('effective_date', 'Effective Date', 'policy', 'attribute', '["effective date","issue date","inception date","start date","commencement date"]', 'The date cover under the policy begins.', 'acord', 'ACORD IM: EffectiveDate'),
  ('expiry_date', 'Expiry Date', 'policy', 'attribute', '["expiry date","expiration date","maturity date","end date","termination date"]', 'The date cover under the policy ends.', 'acord', 'ACORD IM: ExpirationDate'),
  ('policy_term', 'Policy Term', 'policy', 'attribute', '["policy term","term","duration","coverage period"]', 'The length of time the policy provides cover.', 'acord', 'ACORD IM: PolicyTerm'),
  ('inforce_policy', 'In-force Policy', 'inforce', 'entity', '["in-force","inforce","active policy","in force"]', 'A policy whose cover is currently active.', 'acord', 'ACORD IM: Policy (in force)'),
  ('lapse', 'Lapse', 'policy_lifecycle', 'event', '["lapse","lapsed","lapsed policy","non-payment termination"]', 'Termination of a policy because premiums stopped being paid.', 'acord', 'ACORD IM: Lapse'),
  ('surrender', 'Surrender', 'policy_lifecycle', 'event', '["surrender","cash surrender","voluntary termination"]', 'Termination of a policy at the policyholder request, usually for its cash value.', 'acord', 'ACORD IM: Surrender'),
  ('renewal', 'Renewal', 'policy_lifecycle', 'event', '["renewal","policy renewal","renewed"]', 'Continuation of a policy into a new term.', 'acord', 'ACORD IM: Renewal'),
  ('endorsement', 'Endorsement', 'policy_lifecycle', 'event', '["endorsement","policy change","amendment","mid-term change"]', 'A change to the terms of a policy during its life.', 'acord', 'ACORD IM: Endorsement'),
  ('reinstatement', 'Reinstatement', 'policy_lifecycle', 'event', '["reinstatement","reinstated"]', 'Restoring a lapsed policy to in-force status.', 'acord', 'ACORD IM: Reinstatement'),
  ('premium', 'Premium', 'policy', 'measure', '["premium","gross premium","modal premium","premium amount","premium due"]', 'The amount the policyholder pays for cover.', 'acord', 'ACORD IM: Premium; fibo-fnd-acc-cur:MonetaryAmount'),
  ('annualized_premium', 'Annualized Premium', 'policy', 'measure', '["annualized premium","annualised premium","ape","annual premium equivalent"]', 'The premium expressed on an annual basis, used to compare policies with different payment modes.', 'acord', 'ACORD IM: AnnualizedPremium'),
  ('premium_mode', 'Premium Mode', 'billing', 'code', '["premium mode","payment frequency","billing frequency","payment mode"]', 'How often premium is paid: monthly, quarterly, annually or single.', 'acord', 'ACORD IM: PaymentMode'),
  ('cash_value', 'Cash Value', 'inforce', 'measure', '["cash value","surrender value","account value","fund value"]', 'The savings element of a policy available on surrender.', 'acord', 'ACORD IM: CashValue'),
  ('reserve', 'Reserve', 'valuation', 'measure', '["reserve","statutory reserve","policy reserve","liability","technical provision"]', 'The amount held to meet future obligations under in-force policies.', 'acord', 'ACORD IM: Reserve'),
  ('invoice', 'Invoice', 'billing', 'entity', '["invoice","bill","billing statement","premium notice"]', 'A request for premium payment sent to the payer.', 'acord', 'ACORD IM: Invoice'),
  ('payment', 'Payment', 'billing', 'event', '["payment","premium payment","receipt","remittance","collection"]', 'Money received against a premium due.', 'acord', 'ACORD IM: Payment'),
  ('payment_due_date', 'Payment Due Date', 'billing', 'attribute', '["due date","payment due date","bill due date"]', 'The date by which a premium must be paid.', 'acord', 'ACORD IM: DueDate'),
  ('arrears', 'Arrears', 'billing', 'measure', '["arrears","overdue","past due","outstanding balance","outstanding premium"]', 'Premium that is due and unpaid.', 'acord', 'ACORD IM: Arrears'),
  ('claim', 'Claim', 'claims', 'entity', '["claim","loss","claim case","benefit claim"]', 'A request for payment under a policy following a covered event.', 'acord', 'ACORD IM: Claim'),
  ('claim_number', 'Claim Number', 'claims', 'attribute', '["claim number","claim id","claim no","claim reference"]', 'The identifier of a claim on the claims system.', 'acord', 'ACORD IM: ClaimNumber'),
  ('claim_status', 'Claim Status', 'claims', 'attribute', '["claim status","claim state"]', 'Where the claim is in its life: reported, open, approved, paid, denied, closed.', 'acord', 'ACORD IM: ClaimStatus'),
  ('loss_date', 'Loss Date', 'fnol', 'attribute', '["loss date","date of loss","event date","incident date","date of death"]', 'The date the covered event happened.', 'acord', 'ACORD IM: LossDate'),
  ('notification_date', 'Notification Date', 'fnol', 'attribute', '["notification date","fnol date","reported date","report date","submitted date"]', 'The date the insurer was told about the claim.', 'acord', 'ACORD IM: ReportedDate'),
  ('claim_reserve', 'Claim Reserve', 'claims_reserving', 'measure', '["claim reserve","case reserve","outstanding claim","outstanding reserve"]', 'The amount set aside for an open claim.', 'acord', 'ACORD IM: ClaimReserve'),
  ('claim_payment', 'Claim Payment', 'adjudication', 'measure', '["claim payment","benefit payment","indemnity","settlement amount","paid amount","claim paid"]', 'Money paid to settle all or part of a claim.', 'acord', 'ACORD IM: ClaimPayment'),
  ('claim_adjuster', 'Claim Adjuster', 'adjudication', 'entity', '["adjuster","claims handler","claims examiner","assessor"]', 'The person who assesses and decides a claim.', 'acord', 'ACORD IM: Adjuster'),
  ('cause_of_loss', 'Cause of Loss', 'fnol', 'code', '["cause of loss","peril","cause of death","loss cause","diagnosis"]', 'What caused the covered event.', 'acord', 'ACORD IM: CauseOfLoss'),
  ('service_line', 'Service Line', 'adjudication', 'entity', '["service line","claim line","line item","procedure line"]', 'One service or item within a claim, with its own amount and decision.', 'hub', ''),
  ('decision_days', 'Decision Days', 'adjudication', 'measure', '["decision days","days to decision","cycle time","turnaround time","time to decision"]', 'Elapsed days between claim submission and decision.', 'hub', ''),
  ('reinsurance_treaty', 'Reinsurance Treaty', 'reinsurance', 'entity', '["treaty","reinsurance treaty","reinsurance agreement"]', 'An agreement under which a reinsurer takes on part of the insurer risk.', 'acord', 'ACORD IM: ReinsuranceAgreement'),
  ('cession', 'Cession', 'reinsurance', 'measure', '["cession","ceded","ceded amount","ceded premium"]', 'The part of a risk or premium passed to a reinsurer.', 'acord', 'ACORD IM: Cession'),
  ('retention', 'Retention', 'reinsurance', 'measure', '["retention","retained amount","net retention"]', 'The part of a risk the insurer keeps.', 'acord', 'ACORD IM: Retention'),
  ('reinsurer', 'Reinsurer', 'reinsurance', 'entity', '["reinsurer","assuming company"]', 'The company that accepts ceded risk.', 'acord', 'ACORD IM: Reinsurer'),
  ('valuation_date', 'Valuation Date', 'valuation', 'attribute', '["valuation date","as-of date","as of date","reporting date","snapshot date"]', 'The date at which reserves and values are measured.', 'acord', 'ACORD IM: ValuationDate'),
  ('policy_year', 'Policy Year', 'actuarial', 'attribute', '["policy year","duration year","policy anniversary year","policy duration"]', 'Years since the policy was issued, counted from each anniversary.', 'hub', ''),
  ('study_year', 'Study Year', 'experience', 'attribute', '["study year","experience year","observation year","exposure year"]', 'The calendar or policy year an experience study observes.', 'hub', ''),
  ('exposure', 'Exposure', 'experience', 'measure', '["exposure","exposed to risk","policy years exposed","exposure count","lives exposed"]', 'The amount of risk observed, usually in policy-years or lives.', 'hub', ''),
  ('expected_claims', 'Expected Claims', 'experience', 'measure', '["expected claims","expected deaths","expected lapses","expected"]', 'Claims predicted by the assumption basis for the exposure.', 'hub', ''),
  ('actual_claims', 'Actual Claims', 'experience', 'measure', '["actual claims","actual deaths","observed claims","actual lapses","actual"]', 'Claims actually observed in the study period.', 'hub', ''),
  ('ae_ratio', 'A/E Ratio', 'experience', 'measure', '["a/e ratio","ae ratio","actual to expected","actual over expected","a to e"]', 'Actual divided by expected, the core measure of an experience study.', 'hub', ''),
  ('mortality_rate', 'Mortality Rate', 'experience', 'measure', '["mortality rate","death rate","qx","mortality"]', 'Deaths per unit of exposure.', 'hub', ''),
  ('lapse_rate', 'Lapse Rate', 'experience', 'measure', '["lapse rate","termination rate","decrement rate","lapse ratio"]', 'Lapses per unit of exposure.', 'hub', ''),
  ('persistency', 'Persistency', 'inforce', 'measure', '["persistency","persistency rate","policy retention","retention rate"]', 'The share of policies still in force after a period.', 'acord', 'ACORD IM: Persistency'),
  ('decrement', 'Decrement', 'experience', 'event', '["decrement","termination","exit"]', 'An event that removes a policy from the in-force block: death, lapse, surrender, maturity.', 'hub', ''),
  ('mortality_table', 'Mortality Table', 'valuation', 'code', '["mortality table","mortality basis","assumption table","table"]', 'The table of mortality rates used as an assumption basis.', 'hub', ''),
  ('discount_rate', 'Discount Rate', 'valuation', 'attribute', '["discount rate","valuation interest rate","interest rate"]', 'The rate used to discount future cash flows in a valuation.', 'hub', ''),
  ('earned_premium', 'Earned Premium', 'finance', 'measure', '["earned premium"]', 'The part of written premium that belongs to the cover already provided.', 'acord', 'ACORD IM: EarnedPremium'),
  ('written_premium', 'Written Premium', 'finance', 'measure', '["written premium","gross written premium","gwp"]', 'Premium on policies written in the period, regardless of when it is earned.', 'acord', 'ACORD IM: WrittenPremium'),
  ('incurred_claims', 'Incurred Claims', 'finance', 'measure', '["incurred claims","incurred losses","claims incurred"]', 'Paid claims plus the change in claim reserves for the period.', 'acord', 'ACORD IM: IncurredClaims'),
  ('expense', 'Expense', 'finance', 'measure', '["expense","operating expense","acquisition expense","expenses"]', 'Costs of acquiring and administering policies.', 'acord', 'ACORD IM: Expense'),
  ('loss_ratio', 'Loss Ratio', 'finance', 'measure', '["loss ratio","claims ratio"]', 'Incurred claims divided by earned premium.', 'acord', 'ACORD IM: LossRatio'),
  ('combined_ratio', 'Combined Ratio', 'finance', 'measure', '["combined ratio"]', 'Loss ratio plus expense ratio.', 'acord', 'ACORD IM: CombinedRatio'),
  ('currency', 'Currency', 'finance', 'code', '["currency","currency code","ccy"]', 'The currency an amount is expressed in.', 'fibo', 'fibo-fnd-acc-cur:Currency'),
  ('monetary_amount', 'Monetary Amount', 'finance', 'measure', '["amount","monetary amount","value"]', 'A quantity of money in a currency.', 'fibo', 'fibo-fnd-acc-cur:MonetaryAmount'),
  ('personal_data', 'Personal Data', 'risk', 'attribute', '["pii","personal data","personally identifiable information","sensitive data"]', 'Data that identifies or could identify a person, subject to privacy obligations.', 'hub', ''),
  ('kyc_record', 'KYC Record', 'risk', 'entity', '["kyc","know your customer","identity verification","customer due diligence"]', 'Evidence that a customer identity was verified.', 'hub', ''),
  ('service_case', 'Service Case', 'service', 'entity', '["case","service request","ticket","interaction","service case"]', 'A tracked request from a customer or producer.', 'hub', ''),
  ('complaint', 'Complaint', 'service', 'entity', '["complaint","grievance"]', 'A formal expression of dissatisfaction that must be handled and reported.', 'hub', ''),
  ('source_system', 'Source System', 'data_platform', 'attribute', '["source system","origin system","source system id","source system name"]', 'The system a record was ingested from.', 'hub', ''),
  ('ingestion_timestamp', 'Ingestion Timestamp', 'data_platform', 'attribute', '["ingested at","load timestamp","loaded at","bronze ingested at","ingestion timestamp"]', 'When the platform loaded the record.', 'hub', ''),
  ('record_identifier', 'Record Identifier', 'data_platform', 'attribute', '["object id","record id","surrogate key","row id"]', 'A technical identifier with no business meaning.', 'hub', ''),
  ('source_file', 'Source File', 'data_platform', 'attribute', '["source file","file name","input file"]', 'The file a record was loaded from.', 'hub', '')
) AS v(key, name, domain_key, kind, synonyms, definition, standard, standard_ref)
ON CONFLICT (key) DO NOTHING;

-- ---------------------------------------------------------------------------
-- KPIs: definitions with grain, period, unit, direction and targets.
-- ---------------------------------------------------------------------------
INSERT INTO semantic_kpis (key, name, domain_key, term_id, definition, formula, grain, period, unit, direction, target_value, warn_value, standard_ref)
SELECT v.key, v.name, v.domain_key, t.id, v.definition, v.formula, v.grain, v.period, v.unit, v.direction, v.target_value, v.warn_value, v.standard_ref
FROM (VALUES
  ('loss_ratio', 'Loss Ratio', 'finance', 'loss_ratio', 'Share of earned premium consumed by claims.', 'incurred claims / earned premium', 'portfolio', 'monthly', 'percent', 'lower', 65.0, 75.0, 'ACORD IM: LossRatio'),
  ('combined_ratio', 'Combined Ratio', 'finance', 'combined_ratio', 'Claims plus expenses as a share of earned premium; above 100 the book loses money before investment income.', '(incurred claims + expenses) / earned premium', 'portfolio', 'quarterly', 'percent', 'lower', 100.0, 105.0, 'ACORD IM: CombinedRatio'),
  ('expense_ratio', 'Expense Ratio', 'finance', 'expense', 'Operating and acquisition expenses as a share of earned premium.', 'expenses / earned premium', 'portfolio', 'quarterly', 'percent', 'lower', 30.0, 35.0, ''),
  ('lapse_rate', 'Lapse Rate', 'experience', 'lapse_rate', 'Policies lapsing per unit of exposure in the study year.', 'lapses / exposure', 'policy', 'annual', 'percent', 'lower', 8.0, 10.0, ''),
  ('persistency_13m', '13-Month Persistency', 'inforce', 'persistency', 'Share of policies issued that are still in force after 13 months.', 'policies in force at month 13 / policies issued', 'issue cohort', 'monthly', 'percent', 'higher', 85.0, 80.0, 'ACORD IM: Persistency'),
  ('mortality_ae', 'Mortality A/E Ratio', 'experience', 'ae_ratio', 'Actual deaths against the expected deaths of the assumption basis.', 'actual deaths / expected deaths', 'study', 'annual', 'ratio', 'lower', 1.0, 1.1, ''),
  ('claim_settlement_days', 'Claim Settlement Days', 'adjudication', 'decision_days', 'Average elapsed days from notification to payment.', 'avg(payment date - notification date)', 'claim', 'monthly', 'days', 'lower', 30.0, 45.0, ''),
  ('claims_frequency', 'Claims Frequency', 'claims', 'claim', 'Claims per unit of exposure.', 'claims / exposure', 'policy', 'annual', 'ratio', 'lower', NULL, NULL, ''),
  ('claims_severity', 'Average Claim Severity', 'adjudication', 'claim_payment', 'Average amount paid per claim.', 'claim payments / claims paid', 'claim', 'monthly', 'currency', 'lower', NULL, NULL, ''),
  ('new_business_ape', 'New Business APE', 'distribution', 'annualized_premium', 'Annual premium equivalent of policies issued in the period.', 'sum(annualized premium of new policies)', 'policy', 'monthly', 'currency', 'higher', NULL, NULL, 'ACORD IM: AnnualizedPremium'),
  ('inforce_policies', 'In-force Policy Count', 'inforce', 'inforce_policy', 'Number of policies with active cover at the valuation date.', 'count(policies where status = in force)', 'point-in-time', 'monthly', 'count', 'higher', NULL, NULL, ''),
  ('premium_growth', 'Premium Growth', 'finance', 'written_premium', 'Change in written premium against the prior period.', '(written premium - prior written premium) / prior written premium', 'portfolio', 'quarterly', 'percent', 'higher', 5.0, 0.0, ''),
  ('surrender_rate', 'Surrender Rate', 'policy_lifecycle', 'surrender', 'Policies surrendered as a share of the in-force block.', 'surrenders / in-force policies', 'policy', 'annual', 'percent', 'lower', 5.0, 7.0, ''),
  ('renewal_rate', 'Renewal Rate', 'policy_lifecycle', 'renewal', 'Policies renewed as a share of those due for renewal.', 'renewed / due for renewal', 'policy', 'monthly', 'percent', 'higher', 90.0, 85.0, ''),
  ('commission_ratio', 'Commission Ratio', 'distribution', 'commission', 'Commission paid as a share of written premium.', 'commission / written premium', 'portfolio', 'quarterly', 'percent', 'lower', 15.0, 20.0, ''),
  ('quote_to_bind', 'Quote-to-Bind Ratio', 'underwriting', 'quote', 'Share of quotes that become issued policies.', 'policies issued / quotes', 'quote', 'monthly', 'percent', 'higher', 25.0, 20.0, ''),
  ('reserve_adequacy', 'Reserve Adequacy', 'valuation', 'reserve', 'Reserves held against the liabilities the valuation expects.', 'reserves held / expected liabilities', 'point-in-time', 'quarterly', 'ratio', 'higher', 1.0, 0.95, ''),
  ('arrears_rate', 'Premium Arrears Rate', 'billing', 'arrears', 'Share of in-force policies with premium past due.', 'policies in arrears / in-force policies', 'policy', 'monthly', 'percent', 'lower', 3.0, 5.0, '')
) AS v(key, name, domain_key, term_key, definition, formula, grain, period, unit, direction, target_value, warn_value, standard_ref)
LEFT JOIN semantic_terms t ON t.key = v.term_key
ON CONFLICT (key) DO NOTHING;

-- ============================================================ migrations/0012_glossary_proposed_terms.sql
-- =============================================================================
-- Migration 0012 — Claude-proposed glossary terms
--
-- semantic_terms.status gains 'proposed': a candidate term Claude derived from columns and
-- metrics no existing term covers. It waits in the review queue next to its evidence links;
-- accepting makes it 'curated', rejecting deletes it (its links go with it). proposed_by and
-- rationale record which model proposed it and why.
-- =============================================================================

ALTER TABLE semantic_terms DROP CONSTRAINT IF EXISTS semantic_terms_status_check;
ALTER TABLE semantic_terms
    ADD CONSTRAINT semantic_terms_status_check CHECK (status IN ('seeded', 'curated', 'proposed'));
ALTER TABLE semantic_terms
    ADD COLUMN IF NOT EXISTS proposed_by TEXT,
    ADD COLUMN IF NOT EXISTS rationale   TEXT NOT NULL DEFAULT '';
CREATE INDEX IF NOT EXISTS semantic_terms_status_idx ON semantic_terms (status);

-- ============================================================ migrations/0013_intents.sql
-- =============================================================================
-- Migration 0013 — Intents: Jira (or manual) requests that become pipeline specs and code
--
-- One row per intent. `status` is the state machine:
--   received      the ticket arrived and is being parsed
--   clarifying    the parser found open questions; they were posted back, answers awaited
--   planning      the planner is resolving terms, datasets and schema into a spec
--   spec_proposed the spec is posted for review (Jira comment / UI)
--   approved      a person approved the spec; the coder is about to run
--   coding        the coder is generating the pipeline into the workspace
--   pr_open       files are written (and pushed as a branch / pull request when possible)
--   done          the change landed; closed by a person
--   rejected      the spec was rejected
--   failed        parsing, planning or coding failed (error says why)
-- `intent`, `spec` and `coder` are JSON documents (StructuredIntent, PipelineSpec, CoderResult).
-- =============================================================================

CREATE TABLE IF NOT EXISTS intents (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source        TEXT NOT NULL DEFAULT 'manual' CHECK (source IN ('manual', 'jira')),
    jira_key      TEXT UNIQUE,
    jira_url      TEXT,
    title         TEXT NOT NULL,
    text          TEXT NOT NULL DEFAULT '',
    reporter      TEXT NOT NULL DEFAULT '',
    status        TEXT NOT NULL DEFAULT 'received'
                  CHECK (status IN ('received', 'clarifying', 'planning', 'spec_proposed', 'approved',
                                    'coding', 'pr_open', 'done', 'rejected', 'failed')),
    intent        JSONB,
    questions     JSONB NOT NULL DEFAULT '[]'::jsonb,
    answers       JSONB NOT NULL DEFAULT '[]'::jsonb,
    spec          JSONB,
    spec_markdown TEXT NOT NULL DEFAULT '',
    coder         JSONB,
    branch        TEXT,
    pr_url        TEXT,
    error         TEXT,
    posted        JSONB NOT NULL DEFAULT '[]'::jsonb,   -- what was written back to Jira: [{kind, at, comment_id}]
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    decided_at    TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS intents_status_idx ON intents (status);
CREATE INDEX IF NOT EXISTS intents_created_idx ON intents (created_at DESC);

-- ============================================================ migrations/0014_pipelines.sql
-- =============================================================================
-- Pipelines: saved, configurable ingestion definitions on top of a connection.
--
-- A pipeline is a connector (the saved connection, with the credentials configured on the server)
-- plus what to ingest from it (a scope picked in the source's own schema browser), the options a
-- run starts with and a schedule. Runs stay in ingestion_runs and now remember their pipeline.
-- =============================================================================

CREATE TABLE IF NOT EXISTS pipelines (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name           TEXT NOT NULL,
    description    TEXT NOT NULL DEFAULT '',
    connector_name TEXT NOT NULL,
    source_system  source_system NOT NULL,
    -- [{"path": ["INSURANCE", "BRONZE"], "kind": "schema"}, ...]; empty = everything the connection exposes
    scope          JSONB NOT NULL DEFAULT '[]'::jsonb,
    -- run options: full_refresh, limit, chunk_target_tokens, chunk_overlap_tokens
    options        JSONB NOT NULL DEFAULT '{}'::jsonb,
    -- connector-specific switches: include_lineage, include_tags, include_alert_rules, ...
    source_options JSONB NOT NULL DEFAULT '{}'::jsonb,
    -- {"type": "manual" | "interval" | "daily" | "weekly", "every_minutes", "time", "days"}
    schedule       JSONB NOT NULL DEFAULT '{"type": "manual"}'::jsonb,
    enabled        BOOLEAN NOT NULL DEFAULT true,
    owner          TEXT NOT NULL DEFAULT '',
    tags           JSONB NOT NULL DEFAULT '[]'::jsonb,
    next_run_at    TIMESTAMPTZ,
    created_by     TEXT,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS pipelines_name_key ON pipelines (lower(name));
CREATE INDEX IF NOT EXISTS pipelines_connector_idx ON pipelines (connector_name);
CREATE INDEX IF NOT EXISTS pipelines_due_idx ON pipelines (next_run_at)
    WHERE enabled AND next_run_at IS NOT NULL;

DROP TRIGGER IF EXISTS trg_pipelines_updated_at ON pipelines;
CREATE TRIGGER trg_pipelines_updated_at
    BEFORE UPDATE ON pipelines
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

ALTER TABLE ingestion_runs
    ADD COLUMN IF NOT EXISTS pipeline_id UUID REFERENCES pipelines(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS ingestion_runs_pipeline_idx ON ingestion_runs (pipeline_id, created_at DESC)
    WHERE pipeline_id IS NOT NULL;

-- ============================================================ migrations/0015_repo_crawls.sql
-- =============================================================================
-- Repo crawls: each time a GitHub repository is crawled into the repo knowledge graph.
--
-- The graph itself lives in Neo4j (:RepoGraph nodes, replaced per repository on every crawl);
-- this table keeps the history, progress and outcome of each crawl for the Repo Graph tab.
-- =============================================================================

CREATE TABLE IF NOT EXISTS repo_crawls (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    repo          TEXT NOT NULL,
    ref           TEXT,
    sha           TEXT,
    status        TEXT NOT NULL DEFAULT 'queued'
                  CHECK (status IN ('queued', 'running', 'completed', 'failed')),
    phase         TEXT NOT NULL DEFAULT 'queued',
    files_total   INTEGER NOT NULL DEFAULT 0,
    files_read    INTEGER NOT NULL DEFAULT 0,
    stats         JSONB NOT NULL DEFAULT '{}'::jsonb,
    warnings      JSONB NOT NULL DEFAULT '[]'::jsonb,
    error         TEXT,
    index_text    BOOLEAN NOT NULL DEFAULT false,
    index_run_id  UUID,
    requested_by  TEXT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    started_at    TIMESTAMPTZ,
    finished_at   TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS repo_crawls_repo_created_idx ON repo_crawls (repo, created_at DESC);
CREATE INDEX IF NOT EXISTS repo_crawls_status_idx ON repo_crawls (status) WHERE status IN ('queued', 'running');

-- ============================================================ migrations/0016_connector_settings.sql
-- Connection settings saved from the hub's Connectors page. They override the environment for one
-- connector; secrets are Fernet-encrypted (key from ECH_SECRETS_KEY or the service's state directory)
-- and never returned by the API.
create table if not exists connector_settings (
    connector   text primary key,
    settings    jsonb not null default '{}'::jsonb,
    secrets     bytea,
    updated_by  text,
    updated_at  timestamptz not null default now()
);

-- ============================================================ migrations/0017_glossary_auto_map.sql
-- =============================================================================
-- Glossary mapping after every successful Snowflake or Databricks sync.
-- glossary_map_state    what Claude last saw of a dataset (a hash of its source metadata), so a
--                       sync sends only new or changed datasets to Claude again.
-- glossary_auto_runs    one automatic mapping pass per source system, with the syncs it covers.
-- glossary_auto_cursor  syncs that finished before this migration are not mapped retroactively.
-- Proposals land in the review queue as before; nothing applies until a person accepts it.
-- =============================================================================

CREATE TABLE IF NOT EXISTS glossary_map_state (
    asset_id     UUID PRIMARY KEY REFERENCES semantic_assets(id) ON DELETE CASCADE,
    fingerprint  TEXT NOT NULL,
    model        TEXT,
    mapped_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS glossary_auto_runs (
    id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_system      source_system NOT NULL,
    ingestion_run_ids  UUID[] NOT NULL,
    status             TEXT NOT NULL DEFAULT 'running' CHECK (status IN ('running', 'completed', 'failed')),
    datasets           INT NOT NULL DEFAULT 0,
    model_datasets     INT NOT NULL DEFAULT 0,
    unchanged          INT NOT NULL DEFAULT 0,
    model_failed       INT NOT NULL DEFAULT 0,
    rule_links         INT NOT NULL DEFAULT 0,
    model_links        INT NOT NULL DEFAULT 0,
    message            TEXT,
    error              TEXT,
    started_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at        TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS glossary_auto_runs_started_idx ON glossary_auto_runs (started_at DESC);

CREATE TABLE IF NOT EXISTS glossary_auto_cursor (
    id     BOOLEAN PRIMARY KEY DEFAULT true CHECK (id),
    since  TIMESTAMPTZ NOT NULL DEFAULT now()
);
INSERT INTO glossary_auto_cursor (id) VALUES (true) ON CONFLICT (id) DO NOTHING;

-- ============================================================ migrations/0018_lines_of_business.sql
-- =============================================================================
-- Line of business as a catalog facet, decided at sync time.
-- semantic_term_values         the values a code term takes. Line of Business: Life and Annuity; aliases
--                              are the spellings found in tags and data (LIFE, ANNUITY ...).
-- semantic_asset_lines         the lines of business a dataset holds and how the sync knows it, first
--                              source that answers wins: a Snowflake tag, the pipeline's default, the
--                              distinct values of a line-of-business column, or inherited from the
--                              datasets it references (POLICY -> PRODUCT_VERSION -> PRODUCT).
--                              A dataset with no row is shared across lines.
-- pipelines.line_of_business   the default for what a pipeline syncs when no tag says otherwise.
-- =============================================================================

CREATE TABLE IF NOT EXISTS semantic_term_values (
    term_key     TEXT NOT NULL REFERENCES semantic_terms(key) ON DELETE CASCADE ON UPDATE CASCADE,
    key          TEXT NOT NULL,
    name         TEXT NOT NULL,
    description  TEXT NOT NULL DEFAULT '',
    aliases      JSONB NOT NULL DEFAULT '[]'::jsonb,
    sort_order   INT NOT NULL DEFAULT 0,
    PRIMARY KEY (term_key, key)
);

INSERT INTO semantic_term_values (term_key, key, name, description, aliases, sort_order)
SELECT 'line_of_business', v.key, v.name, v.description, v.aliases::jsonb, v.sort_order
  FROM (VALUES
        ('life', 'Life', 'Life insurance: term, whole and universal life.', '["life", "life insurance"]', 10),
        ('annuity', 'Annuity', 'Fixed and indexed annuities.', '["annuity", "annuities"]', 20)
       ) AS v(key, name, description, aliases, sort_order)
 WHERE EXISTS (SELECT 1 FROM semantic_terms WHERE key = 'line_of_business')
ON CONFLICT (term_key, key) DO NOTHING;

CREATE TABLE IF NOT EXISTS semantic_asset_lines (
    asset_id    UUID NOT NULL REFERENCES semantic_assets(id) ON DELETE CASCADE,
    line_key    TEXT NOT NULL,
    source      TEXT NOT NULL CHECK (source IN ('tag', 'pipeline', 'values', 'inherited')),
    evidence    TEXT NOT NULL DEFAULT '',
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (asset_id, line_key)
);
CREATE INDEX IF NOT EXISTS semantic_asset_lines_line_idx ON semantic_asset_lines (line_key);

ALTER TABLE pipelines ADD COLUMN IF NOT EXISTS line_of_business TEXT;

-- ============================================================ migrations/0019_personas_preview.sql
-- =============================================================================
-- 0019 — Genie spaces for the preview personas
--
-- Five more workspaces: DevOps, DevSecOps, Data Steward, Data Scientist and
-- Compliance & Risk. Their dashboards show sample data until CI, scanners, a
-- model registry or a GRC tool is connected, but their Ask tab runs on the live
-- hub, so each space tells Genie what the hub can answer today and to say so
-- plainly when a question needs a source that is not connected yet.
-- =============================================================================

ALTER TABLE genie_spaces DROP CONSTRAINT IF EXISTS genie_spaces_persona_check;
ALTER TABLE genie_spaces
    ADD CONSTRAINT genie_spaces_persona_check
    CHECK (persona IS NULL OR persona IN (
        'data_engineer', 'business_analyst', 'qa_engineer', 'architect', 'sre',
        'devops', 'devsecops', 'data_steward', 'data_scientist', 'compliance'
    ));

INSERT INTO genie_spaces (id, name, description, instructions, filters, sample_questions, is_default, persona)
VALUES
(
    '00000000-0000-4000-8000-000000000007',
    'DevOps',
    'Delivery of the hub and its pipelines: builds, deployments, environments and how fast changes reach production.',
    'You are assisting a DevOps engineer who builds, ships and runs the context hub and the lakehouse pipelines. '
    'Think in DORA terms: deployment frequency, lead time for changes, change failure rate and time to restore. '
    'The hub does not ingest CI/CD or deployment events yet; when a question needs them, say so and name the '
    'source to connect (GitHub Actions, Argo CD, Helm). Answer what the hub does hold: ingestion and pipeline '
    'runs, schedules and their outcomes, crawled repositories (Dockerfiles, compose files, workflow definitions, '
    'dependency manifests) and service health. Give concrete steps and commands, label shell and SQL dialects, '
    'and cite the runs, repositories and documents you used.',
    '{}'::jsonb,
    '["Which pipelines failed most often this week, and what changed before each failure?",
      "Which services in the crawled repositories have a Dockerfile but no health check?",
      "How long do scheduled pipeline runs take, and which ones are getting slower?",
      "What would I need to connect to measure deployment frequency and lead time here?",
      "Write a runbook for rolling back a failed ingestion-service release."]'::jsonb,
    false,
    'devops'
),
(
    '00000000-0000-4000-8000-000000000008',
    'DevSecOps',
    'Security of the hub and its data: dependencies, secrets handling, access and the software supply chain.',
    'You are assisting a DevSecOps engineer responsible for keeping the hub, its pipelines and the data they '
    'touch secure. Focus on dependency risk, secrets handling, least-privilege access, image provenance and '
    'personal data exposure. The hub does not ingest scanner findings yet; when a question needs CVE or secret '
    'scanning results, say so and name the source to connect (GitHub Advanced Security, Snyk, Trivy). Answer '
    'from what the hub holds: dependency manifests in crawled repositories, connector configuration (never '
    'reveal or repeat credential values), audit records and the catalog''s personal-data columns. Rate each '
    'finding by severity, give the fix and how to verify it, and cite your sources.',
    '{}'::jsonb,
    '["Which crawled repositories pin their dependencies, and which use open version ranges?",
      "Which tables hold personal data, and who can query them?",
      "Which connectors use long-lived credentials that should be rotated?",
      "What would a supply-chain policy for our container images need: SBOM, signing, provenance?",
      "What scanner should I connect first to see open critical vulnerabilities here?"]'::jsonb,
    false,
    'devsecops'
),
(
    '00000000-0000-4000-8000-000000000009',
    'Data Steward',
    'Business meaning and ownership: the glossary, the review queue, owners and documentation gaps.',
    'You are assisting a data steward who owns business meaning in the hub. Help them decide glossary '
    'suggestions, place tables in business areas, find tables without an owner or description, merge duplicate '
    'or overlapping terms and keep KPI definitions consistent. Ground every answer in the glossary, its term '
    'links and the semantic catalog. When you recommend accepting or rejecting a suggestion, say why from the '
    'column name, data type, sample values and the table it sits in. Never claim a decision was made: approval '
    'stays with the steward. Cite the terms, tables and columns you used.',
    '{}'::jsonb,
    '["Which glossary suggestions are safest to approve first, and which look wrong?",
      "Which tables still have no business area, and what area would each belong to?",
      "Which tables have no owner or no description?",
      "Are there glossary terms that mean the same thing and should be merged?",
      "Which KPIs have no metric behind them yet?"]'::jsonb,
    false,
    'data_steward'
),
(
    '00000000-0000-4000-8000-000000000010',
    'Data Scientist',
    'Governed data for models: finding training tables, building features, and judging leakage and drift risk.',
    'You are assisting a data scientist building insurance models such as lapse propensity, mortality risk, '
    'claim fraud and reserve adequacy. Help them find governed training data in the semantic catalog, join it '
    'correctly using declared keys, build point-in-time correct features and avoid target leakage. Write SQL '
    'and Python with the dialect labelled (Databricks SQL, Snowflake, PySpark, pandas). The hub does not ingest '
    'a model registry or feature store yet; when a question needs model metrics or drift results, say so and '
    'name the source to connect (MLflow, Databricks Model Registry). Cite the tables and columns you used.',
    '{}'::jsonb,
    '["Which tables would I use to train a lapse propensity model, and how do they join?",
      "Write point-in-time correct features for months in force and missed payments.",
      "Which columns would leak the target in a claim fraud model?",
      "Which columns hold personal data I should exclude or mask before training?",
      "How fresh is the data behind the policy and billing tables?"]'::jsonb,
    false,
    'data_scientist'
),
(
    '00000000-0000-4000-8000-000000000011',
    'Compliance & Risk',
    'Controls, privacy and regulatory reporting: where personal data lives and what feeds each filing.',
    'You are assisting a compliance and risk officer at an insurer. Focus on personal data (where it lives, how '
    'it is classified and who can reach it), retention, audit trails and the data that feeds regulatory '
    'filings such as Solvency II, IFRS 17, SOX and GDPR records of processing. Trace each filing back through '
    'lineage to its source tables. The hub does not ingest control tests or a GRC tool yet; when a question '
    'needs them, say so. Be precise, never overstate compliance, separate what you verified from what you '
    'assume, and cite the tables, columns, lineage and audit records you used. This is not legal advice.',
    '{}'::jsonb,
    '["Which tables and columns hold personal data, and which are not classified yet?",
      "Trace the tables that feed the Solvency II quarterly reporting back to their sources.",
      "Which personal data is kept longer than the policy period requires?",
      "Who queried personal data this month, according to the audit log?",
      "What evidence would an auditor ask for on reserve changes?"]'::jsonb,
    false,
    'compliance'
)
ON CONFLICT (id) DO UPDATE SET persona = EXCLUDED.persona;

-- ============================================================ migrations/0020_jira_source.sql
-- 0020: Jira joins the sources (issues as documents; the same connection feeds the intent service).
-- ALTER TYPE ... ADD VALUE is idempotent with IF NOT EXISTS, like 0010 did for Grafana.
ALTER TYPE source_system ADD VALUE IF NOT EXISTS 'jira';

-- ============================================================ migrations/0021_intent_routes.sql
-- 0021: intents are validated against Snowflake (read-only) and routed by what that finds.
-- `validation` holds IntentValidation, `route` the chosen IntentRoute; 'waiting' parks an intent on its upstream
-- tables, 'modeling' is the data modeler at work.
ALTER TABLE intents ADD COLUMN IF NOT EXISTS validation JSONB;
ALTER TABLE intents ADD COLUMN IF NOT EXISTS route JSONB;
ALTER TABLE intents DROP CONSTRAINT IF EXISTS intents_status_check;
ALTER TABLE intents ADD CONSTRAINT intents_status_check
    CHECK (status IN ('received', 'clarifying', 'planning', 'waiting', 'modeling', 'spec_proposed', 'approved',
                      'coding', 'pr_open', 'done', 'rejected', 'failed'));

-- ============================================================ migrations/0022_intent_runs.sql
-- 0022: the hub runs an approved pipeline itself (upload the files, create the objects, load, check, refresh the
-- catalog). `run` holds the latest PipelineRun; 'running' is a run in progress, 'loaded' a run that finished with
-- every check passing, waiting for a person to close the intent.
ALTER TABLE intents ADD COLUMN IF NOT EXISTS run JSONB;
ALTER TABLE intents DROP CONSTRAINT IF EXISTS intents_status_check;
ALTER TABLE intents ADD CONSTRAINT intents_status_check
    CHECK (status IN ('received', 'clarifying', 'planning', 'waiting', 'modeling', 'spec_proposed', 'approved',
                      'coding', 'pr_open', 'running', 'loaded', 'done', 'rejected', 'failed'));

-- ============================================================ migrations/0023_digital_worker.sql
-- 0023: a persona's digital worker. worker_items holds the work it picked up from the hub's own signals, one row
-- per signal (a signal seen again is the same item); worker_journal is its append-only log, each entry hashed over
-- the one before it so an edited entry breaks the chain; worker_state remembers whether it is paused.
CREATE TABLE IF NOT EXISTS worker_items (
    key         TEXT PRIMARY KEY,
    worker      TEXT NOT NULL,
    skill       TEXT NOT NULL,
    title       TEXT NOT NULL,
    detail      TEXT NOT NULL DEFAULT '',
    status      TEXT NOT NULL CHECK (status IN ('detected', 'diagnosed', 'waiting', 'running', 'done', 'failed', 'dismissed')),
    tier        TEXT NOT NULL CHECK (tier IN ('T0', 'T1', 'T2', 'T3')),
    action      JSONB,
    evidence    JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    decided_by  TEXT,
    decided_at  TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS worker_items_by_status ON worker_items (worker, status, updated_at DESC);

CREATE TABLE IF NOT EXISTS worker_journal (
    id          BIGSERIAL PRIMARY KEY,
    worker      TEXT NOT NULL,
    at          TIMESTAMPTZ NOT NULL,
    kind        TEXT NOT NULL CHECK (kind IN ('shift', 'observed', 'diagnosed', 'proposed', 'approved', 'acted', 'done', 'failed', 'dismissed')),
    item_key    TEXT,
    skill       TEXT,
    message     TEXT NOT NULL,
    evidence    JSONB NOT NULL DEFAULT '{}'::jsonb,
    prev_hash   TEXT,
    record_hash TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS worker_journal_recent ON worker_journal (worker, id DESC);

CREATE TABLE IF NOT EXISTS worker_state (
    worker     TEXT PRIMARY KEY,
    paused     BOOLEAN NOT NULL DEFAULT false,
    last_tick  TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
