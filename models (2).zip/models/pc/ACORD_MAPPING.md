# ACORD P&C Data Model Mapping

## P&C Insurance Intelligence Platform — Semantic Model Alignment

This document maps the platform's P&C semantic domains to ACORD Property & Casualty Data Model standards and IRO (Insurance Regulation Ontology) references. The physical tables reside in the `pc` PostgreSQL schema within the `insurance_core` database, exposed via Trino as `insurance_core.pc.<table_name>`.

---

## 1. Domain-to-ACORD Mapping

### Core Functional Domains

| Platform Domain | ACORD P&C Standard | IRO Reference | Description |
|----------------|-------------------|---------------|-------------|
| `policy` | Policy Administration | IRO/InsuranceContract/PropertyCasualtyPolicy | Agreement, Policy, Coverage, Product, Line of Business, Policy Events (new business, renewal, endorsement, cancellation) |
| `claims` | Claims Management | IRO/Claim/PropertyCasualtyClaim | Claim lifecycle, reserves, payments, recoveries, fraud, litigation, catastrophe, occurrence |
| `party` | Party/Customer | IRO/Party/InsuredParty | Persons, organizations, households, party relationships, customer scoring, roles |
| `underwriting` | Underwriting & Rating | IRO/Underwriting/RiskAssessment | Premium amounts, assessments, rating territories, risk scores, financial valuations, deductibles, limits |
| `distribution` | Distribution/Agency | IRO/Party/InsuranceAgent | Agency contracts, brokerage relationships, organizational hierarchy, territories, accounts |
| `analytics` | Actuarial & Analytics | IRO/Financial/InsuranceAnalytics | Insurance Lake time-series: loss triangles, premium history, reserve development, experience rating |

### LOB Branch Models

| Platform LOB | ACORD P&C Standard | IRO Reference | Description |
|-------------|-------------------|---------------|-------------|
| `personal_auto` | Personal Auto | IRO/InsuranceContract/AutomobilePolicy | Vehicle-specific views, auto coverage types (BI, PD, Collision, Comprehensive, UM/UIM), auto-specific KPIs |
| `homeowners` | Homeowners | IRO/InsuranceContract/PropertyPolicy | Structure-specific views, catastrophe exposure, property perils, dwelling coverage, replacement cost |
| `commercial_lines` | Commercial Lines | IRO/InsuranceContract/CommercialPolicy | Multi-LOB commercial (CA, GL, WC, CP): commercial auto, general liability, workers compensation, commercial property |

---

## 2. Cross-Cutting ACORD Concepts Coverage

### Claims (ACORD P&C — Claims)

Claims in P&C are managed as a standalone domain with full lifecycle tracking:

| Concept | Physical Table(s) | Key Fields | Domain Assignment |
|---------|------------------|------------|-------------------|
| Claim Record | `Claim` | Claim_Identifier, Claim_Status_Code, Claim_Open_Date, Claim_Close_Date | claims |
| Claim Amount | `Claim_Amount` | Claim_Amount_Identifier, Amount_Type_Code, Claim_Amount | claims |
| Loss Reserve | `Claim_Reserve`, `Loss_Reserve` | Claim_Amount_Identifier (subtype chain) | claims |
| Expense Reserve | `Claim_Reserve`, `Expense_Reserve` | Claim_Amount_Identifier (subtype chain) | claims |
| Claim Payment | `Claim_Payment`, `Loss_Payment`, `Expense_Payment` | Claim_Amount_Identifier | claims |
| Recovery | `Recovery`, `Subrogation`, `Salvage` | Claim_Amount_Identifier | claims |
| Claim Party Role | `Claim_Party_Role` | Claim_Identifier, Party_Identifier, Party_Role_Code | claims |
| Claim Coverage | `Claim_Coverage` | Claim_Identifier, Policy_Coverage_Detail_Identifier | claims |
| Claim Folder | `Claim_Folder`, `Claim_Folder_Document` | Claim_Identifier, Document_Link_Value | claims |
| Occurrence | `Occurrence` | Occurrence_Identifier, Catastrophic_Event_Indicator | claims |
| Catastrophe | `Catastrophe` | Catastrophe_Identifier, Catastrophe_Type_Code | claims |
| Fraud Assessment | `Fraud_Assessment` | Assessment_Result_Identifier | claims |
| Litigation | `Litigation`, `Claim_Litigation` | Litigation_Identifier, Claim_Identifier | claims |
| Arbitration | `Arbitration`, `Claim_Arbitration` | Arbitration_Identifier, Claim_Identifier | claims |
| Claim Offer | `Claim_Offer` | Claim_Offer_Identifier, Settlement_Offer_Amount | claims |
| Claim Assessment | `Claim_Assessment` | Claim_Identifier, Assessment_Identifier | claims |

### Underwriting (ACORD P&C — Underwriting & Rating)

Underwriting in P&C is an ongoing process covering premium calculation, risk assessment, and financial valuation:

| Concept | Physical Table(s) | Key Fields | Domain Assignment |
|---------|------------------|------------|-------------------|
| Policy Amount | `Policy_Amount` | Policy_Amount_Identifier, Amount_Type_Code, Policy_Amount | underwriting |
| Premium | `Premium` | Policy_Amount_Identifier (subtype of Policy_Amount) | underwriting |
| Fee | `Fee` | Policy_Amount_Identifier (subtype of Policy_Amount) | underwriting |
| Tax | `Tax` | Policy_Amount_Identifier (subtype of Policy_Amount) | underwriting |
| Surcharge | `Surcharge` | Policy_Amount_Identifier (subtype of Policy_Amount) | underwriting |
| Direct Policy Amount | `Direct_Policy_Amount` | Policy_Amount_Identifier | underwriting |
| Ceded Policy Amount | `Ceded_Policy_Amount` | Policy_Amount_Identifier | underwriting |
| Assumed Policy Amount | `Assumed_Policy_Amount` | Policy_Amount_Identifier | underwriting |
| Policy Deductible | `Policy_Deductible` | Policy_Deductible_Identifier, Deductible_Type_Code | underwriting |
| Policy Limit | `Policy_Limit` | Policy_Limit_Identifier, Limit_Type_Code, Limit_Value | underwriting |
| Underwriting Assessment | `Underwriting_Assessment` | Assessment_Result_Identifier | underwriting |
| Financial Valuation | `Financial_Valuation` | Assessment_Result_Identifier | underwriting |
| Risk Factor Score | `Risk_Factor_Score` | Assessment_Result_Identifier | underwriting |
| Rating Territory | `Rating_Territory`, `Rating_Territory_Geographic_Location` | Rating_Territory_Identifier, Geographic_Location_Identifier | underwriting |

### Coverage (ACORD P&C — Coverage)

Coverage is embedded within the policy domain with cross-references to LOB branches:

| Coverage Concept | Physical Table(s) | Key Fields | Domain Assignment |
|-----------------|------------------|------------|-------------------|
| Coverage Definition | `Coverage` | Coverage_Identifier, Coverage_Name, Coverage_Type_Identifier | policy |
| Coverage Type | `Coverage_Type` | Coverage_Type_Identifier, Coverage_Type_Name | policy |
| Coverage Group | `Coverage_Group` | Coverage_Group_Identifier, Coverage_Group_Name | policy |
| Coverage Part | `Coverage_Part` | Coverage_Part_Code, Coverage_Part_Name | policy |
| Policy Coverage Part | `Policy_Coverage_Part` | Coverage_Part_Code, Policy_Identifier | policy |
| Policy Coverage Detail | `Policy_Coverage_Detail` | Policy_Coverage_Detail_Identifier, Coverage_Identifier, Insurable_Object_Identifier | policy |
| Coverage Level/Limits | `Coverage_Level`, `Coverage_Limit_Type` | Coverage_Level_Identifier, Maximum_Per_Person_Amount, Aggregate_Limit_Amount | policy |
| Product Coverage | `Product_Coverage` | Product_Identifier, Coverage_Identifier | policy |

### Reinsurance (ACORD P&C — Reinsurance)

Reinsurance is captured through policy amount subtypes and claim amount subtypes:

| Concept | Physical Table(s) | Key Fields | Domain Assignment |
|---------|------------------|------------|-------------------|
| Ceded Premium | `Ceded_Policy_Amount` | Policy_Amount_Identifier (subtype of Policy_Amount) | underwriting |
| Assumed Premium | `Assumed_Policy_Amount` | Policy_Amount_Identifier (subtype of Policy_Amount) | underwriting |
| Direct Premium | `Direct_Policy_Amount` | Policy_Amount_Identifier (subtype of Policy_Amount) | underwriting |
| Ceded Claim Amount | `Ceded_Claim_Amount` | Claim_Amount_Identifier | claims |
| Assumed Claim Amount | `Assumed_Claim_Amount` | Claim_Amount_Identifier | claims |
| Direct Claim Amount | `Direct_Claim_Amount` | Claim_Amount_Identifier | claims |
| Reinsurance Recovery | `Reinsurance_Recovery` | Claim_Amount_Identifier (subtype of Recovery) | claims |
| Commutation Agreement | `Commutation_Agreement` | Agreement_Identifier | policy |

### Party (ACORD P&C — Party/Customer)

Party management covers all participants in the insurance value chain:

| Concept | Physical Table(s) | Key Fields | Domain Assignment |
|---------|------------------|------------|-------------------|
| Party | `Party` | Party_Identifier, Party_Type_Code | party |
| Person | `Person` | Person_Identifier, First_Name, Last_Name, Birth_Date | party |
| Organization | `Organization` | Organization_Identifier, Organization_Name, Industry_Code | party |
| Household | `Grouping`, `Household`, `Household_Person` | Household_Identifier, Person_Identifier | party |
| Household Person Role | `Household_Person_Role` | Household_Identifier, Person_Identifier, Party_Role_Code | party |
| Party Relationship | `Party_Relationship` | Party_Identifier, Related_Party_Identifier, Relationship_Type_Code | party |
| Party Role | `Party_Role` | Party_Role_Code, Party_Role_Name | party |
| Agreement Party Role | `Agreement_Party_Role` | Agreement_Identifier, Party_Identifier, Party_Role_Code | party |
| Account Party Role | `Account_Party_Role` | Account_Identifier, Party_Identifier, Party_Role_Code | party |
| Insurable Object Party Role | `Insurable_Object_Party_Role` | Insurable_Object_Identifier, Party_Identifier, Party_Role_Code | party |
| Party Preference | `Party_Preference` | Party_Identifier, Preferred_Language_Code | party |
| Customer Score | `Customer_Score` | Assessment_Result_Identifier | party |
| Demographic Score | `Demographic_Score` | Assessment_Result_Identifier | party |
| Channel Score | `Channel_Score` | Assessment_Result_Identifier | party |
| Party Communication | `Party_Communication`, `Communication_Identity` | Party_Identifier, Communication_Identifier | party |

### Insurable Object (ACORD P&C — Insurable Object)

Insurable objects represent the physical items being insured, organized in a type hierarchy:

| Object Type | Physical Table(s) | Key Fields | LOB Assignment |
|------------|------------------|------------|----------------|
| Base Object | `Insurable_Object` | Insurable_Object_Identifier, Insurable_Object_Type_Code | shared |
| Vehicle (generic) | `Vehicle` | Insurable_Object_Identifier, Vehicle_Make_Name, Vehicle_Model_Year | personal_auto, commercial_lines |
| Automobile | `Automobile` | Insurable_Object_Identifier (subtype of Vehicle) | personal_auto |
| Boat | `Boat` | Insurable_Object_Identifier (subtype of Vehicle) | personal_auto |
| Motorcycle | `Motorcycle` | Insurable_Object_Identifier (subtype of Vehicle) | personal_auto |
| Bus | `Bus` | Insurable_Object_Identifier (subtype of Vehicle) | commercial_lines |
| Truck | `Truck` | Insurable_Object_Identifier (subtype of Vehicle) | commercial_lines |
| Trailer | `Trailer` | Insurable_Object_Identifier (subtype of Vehicle) | commercial_lines |
| Construction Vehicle | `Construction_Vehicle` | Insurable_Object_Identifier (subtype of Vehicle) | commercial_lines |
| Recreational Vehicle | `Recreational_Vehicle` | Insurable_Object_Identifier (subtype of Vehicle) | personal_auto |
| Van | `Van` | Insurable_Object_Identifier (subtype of Vehicle) | commercial_lines |
| Watercraft | `Watercraft` | Insurable_Object_Identifier (subtype of Vehicle) | personal_auto |
| Structure (generic) | `Structure` | Insurable_Object_Identifier (subtype of Insurable_Object) | homeowners, commercial_lines |
| Residential Structure | `Residential_Structure` | Insurable_Object_Identifier (subtype of Structure) | homeowners |
| Dwelling | `Dwelling` | Insurable_Object_Identifier (subtype of Residential_Structure) | homeowners |
| Mobile Home | `Mobile_Home` | Insurable_Object_Identifier (subtype of Residential_Structure) | homeowners |
| Commercial Structure | `Commercial_Structure` | Insurable_Object_Identifier (subtype of Structure) | commercial_lines |
| Combination Structure | `Combination_Structure` | Insurable_Object_Identifier (subtype of Structure) | commercial_lines |
| Workers Comp Class | `Workers_Comp_Class` | Insurable_Object_Identifier | commercial_lines |
| Household Content | `Household_Content` | Insurable_Object_Identifier, Household_Identifier | homeowners |
| Body Object | `Body_Object` | Insurable_Object_Identifier | commercial_lines |
| Farm Equipment | `Farm_Equipment`, `Tractor`, `Combine`, `Milking_Machine` | Insurable_Object_Identifier | commercial_lines |
| Transportation Class | `Transportation_Class` | Insurable_Object_Identifier | commercial_lines |
| Manufactured Object | `Manufactured_Object` | Insurable_Object_Identifier | commercial_lines |
| Scheduled Item | `Scheduled_Item` | Insurable_Object_Identifier | homeowners, commercial_lines |
| Property In Transit | `Property_In_Transit` | Insurable_Object_Identifier | commercial_lines |

---

## 3. ACORD Entity Mapping to Physical Tables

| ACORD P&C Entity | Physical Table | Semantic Model Domain | Dataset Name |
|-----------------|----------------|----------------------|--------------|
| State | `insurance_core.pc.State` | _shared | state |
| Location Address | `insurance_core.pc.Location_Address` | _shared | location_address |
| Physical Location | `insurance_core.pc.Physical_Location` | _shared | physical_location |
| Geographic Location | `insurance_core.pc.Geographic_Location` | _shared | geographic_location |
| Insurable Object | `insurance_core.pc.Insurable_Object` | _shared | insurable_object |
| Vehicle | `insurance_core.pc.Vehicle` | personal_auto | vehicle |
| Automobile | `insurance_core.pc.Automobile` | personal_auto | automobile |
| Boat | `insurance_core.pc.Boat` | personal_auto | boat |
| Motorcycle | `insurance_core.pc.Motorcycle` | personal_auto | motorcycle |
| Recreational Vehicle | `insurance_core.pc.Recreational_Vehicle` | personal_auto | recreational_vehicle |
| Watercraft | `insurance_core.pc.Watercraft` | personal_auto | watercraft |
| Bus | `insurance_core.pc.Bus` | commercial_lines | bus |
| Truck | `insurance_core.pc.Truck` | commercial_lines | truck |
| Trailer | `insurance_core.pc.Trailer` | commercial_lines | trailer |
| Van | `insurance_core.pc.Van` | commercial_lines | van |
| Construction Vehicle | `insurance_core.pc.Construction_Vehicle` | commercial_lines | construction_vehicle |
| Line of Business Group | `insurance_core.pc.Line_Of_Business_Group` | policy | line_of_business_group |
| Insurance Class | `insurance_core.pc.Insurance_Class` | policy | insurance_class |
| Line of Business | `insurance_core.pc.Line_Of_Business` | policy | line_of_business |
| Product | `insurance_core.pc.Product` | policy | product |
| Agreement | `insurance_core.pc.Agreement` | policy | agreement |
| Policy | `insurance_core.pc.Policy` | policy | policy |
| Policy Event | `insurance_core.pc.Policy_Event` | policy | policy_event |
| Endorsement | `insurance_core.pc.Endorsement` | policy | endorsement |
| Audit | `insurance_core.pc.Audit` | policy | audit |
| New Business | `insurance_core.pc.New_Business` | policy | new_business |
| Renewal | `insurance_core.pc.Renewal` | policy | renewal |
| Quote | `insurance_core.pc.Quote` | policy | quote |
| Binding | `insurance_core.pc.Binding` | policy | binding |
| Cancel | `insurance_core.pc.Cancel` | policy | cancel |
| Flat Cancel | `insurance_core.pc.Flat` | policy | flat_cancel |
| Pro Rata Cancel | `insurance_core.pc.Pro_Rata` | policy | pro_rata_cancel |
| Short Rate Cancel | `insurance_core.pc.Short_Rate` | policy | short_rate_cancel |
| Reinstatement | `insurance_core.pc.Reinstatement` | policy | reinstatement |
| Mid Term Endorsement | `insurance_core.pc.Mid_Term` | policy | mid_term |
| Full Term Endorsement | `insurance_core.pc.Full_Term` | policy | full_term |
| Coverage Type | `insurance_core.pc.Coverage_Type` | policy | coverage_type |
| Coverage Group | `insurance_core.pc.Coverage_Group` | policy | coverage_group |
| Coverage Part | `insurance_core.pc.Coverage_Part` | policy | coverage_part |
| Coverage | `insurance_core.pc.Coverage` | policy | coverage |
| Policy Coverage Part | `insurance_core.pc.Policy_Coverage_Part` | policy | policy_coverage_part |
| Policy Coverage Detail | `insurance_core.pc.Policy_Coverage_Detail` | policy | policy_coverage_detail |
| Coverage Limit Type | `insurance_core.pc.Coverage_Limit_Type` | policy | coverage_limit_type |
| Coverage Level | `insurance_core.pc.Coverage_Level` | policy | coverage_level |
| Product Coverage | `insurance_core.pc.Product_Coverage` | policy | product_coverage |
| Policy Form | `insurance_core.pc.Policy_Form` | policy | policy_form |
| Policy Relationship | `insurance_core.pc.Policy_Relationship` | policy | policy_relationship |
| Policy Amount | `insurance_core.pc.Policy_Amount` | underwriting | policy_amount |
| Premium | `insurance_core.pc.Premium` | underwriting | premium |
| Fee | `insurance_core.pc.Fee` | underwriting | fee |
| Tax | `insurance_core.pc.Tax` | underwriting | tax |
| Surcharge | `insurance_core.pc.Surcharge` | underwriting | surcharge |
| Direct Policy Amount | `insurance_core.pc.Direct_Policy_Amount` | underwriting | direct_policy_amount |
| Ceded Policy Amount | `insurance_core.pc.Ceded_Policy_Amount` | underwriting | ceded_policy_amount |
| Assumed Policy Amount | `insurance_core.pc.Assumed_Policy_Amount` | underwriting | assumed_policy_amount |
| Debit Policy Amount | `insurance_core.pc.Debit_Policy_Amount` | underwriting | debit_policy_amount |
| Credit Policy Amount | `insurance_core.pc.Credit_Policy_Amount` | underwriting | credit_policy_amount |
| Policy Deductible | `insurance_core.pc.Policy_Deductible` | underwriting | policy_deductible |
| Policy Limit | `insurance_core.pc.Policy_Limit` | underwriting | policy_limit |
| Assessment | `insurance_core.pc.Assessment` | underwriting | assessment |
| Assessment Result | `insurance_core.pc.Assessment_Result` | underwriting | assessment_result |
| Underwriting Assessment | `insurance_core.pc.Underwriting_Assessment` | underwriting | underwriting_assessment |
| Financial Valuation | `insurance_core.pc.Financial_Valuation` | underwriting | financial_valuation |
| Risk Factor Score | `insurance_core.pc.Risk_Factor_Score` | underwriting | risk_factor_score |
| Rating Territory | `insurance_core.pc.Rating_Territory` | underwriting | rating_territory |
| Rating Territory Location | `insurance_core.pc.Rating_Territory_Geographic_Location` | underwriting | rating_territory_geographic_location |
| Object Assessment | `insurance_core.pc.Object_Assessment` | underwriting | object_assessment |
| Physical Object Assessment | `insurance_core.pc.Physical_Object_Assessment` | underwriting | physical_object_assessment |
| Place Assessment | `insurance_core.pc.Place_Assessment` | underwriting | place_assessment |
| Approval | `insurance_core.pc.Approval` | underwriting | approval |
| Financial Services Assessment | `insurance_core.pc.Financial_Services_Assessment` | underwriting | financial_services_assessment |
| Claim Evaluation Result | `insurance_core.pc.Claim_Evaluation_Result` | claims | claim_evaluation_result |
| Party | `insurance_core.pc.Party` | party | party |
| Person | `insurance_core.pc.Person` | party | person |
| Organization | `insurance_core.pc.Organization` | party | organization |
| For Profit Organization | `insurance_core.pc.For_Profit_Organization` | party | for_profit_organization |
| Not For Profit Organization | `insurance_core.pc.Not_For_Profit_Organization` | party | not_for_profit_organization |
| Government Organization | `insurance_core.pc.vernment_Organization` | party | government_organization |
| Grouping | `insurance_core.pc.Grouping` | party | grouping |
| Household | `insurance_core.pc.Household` | party | household |
| Household Person | `insurance_core.pc.Household_Person` | party | household_person |
| Household Person Role | `insurance_core.pc.Household_Person_Role` | party | household_person_role |
| Professional Group | `insurance_core.pc.Professional_Group` | party | professional_group |
| Team | `insurance_core.pc.Team` | party | team |
| Project | `insurance_core.pc.Project` | party | project |
| Party Relationship | `insurance_core.pc.Party_Relationship` | party | party_relationship |
| Party Relationship Role | `insurance_core.pc.Party_Relationship_Role` | party | party_relationship_role |
| Party Role | `insurance_core.pc.Party_Role` | party | party_role |
| Agreement Party Role | `insurance_core.pc.Agreement_Party_Role` | party | agreement_party_role |
| Account Party Role | `insurance_core.pc.Account_Party_Role` | party | account_party_role |
| Insurable Object Party Role | `insurance_core.pc.Insurable_Object_Party_Role` | party | insurable_object_party_role |
| Party Preference | `insurance_core.pc.Party_Preference` | party | party_preference |
| Customer Score | `insurance_core.pc.Customer_Score` | party | customer_score |
| Demographic Score | `insurance_core.pc.Demographic_Score` | party | demographic_score |
| Channel Score | `insurance_core.pc.Channel_Score` | party | channel_score |
| Party Assessment | `insurance_core.pc.Party_Assessment` | party | party_assessment |
| Assessment Party Role | `insurance_core.pc.Assesment_Party_Role` | party | assessment_party_role |
| Person Profession | `insurance_core.pc.Person_Profession` | party | person_profession |
| Communication Identity | `insurance_core.pc.Communication_Identity` | party | communication_identity |
| Party Communication | `insurance_core.pc.Party_Communication` | party | party_communication |
| Legal Jurisdiction | `insurance_core.pc.Legal_Jurisdiction` | party | legal_jurisdiction |
| Legal Jurisdiction Party Identity | `insurance_core.pc.Legal_Jurisdiction_Party_Identity` | party | legal_jurisdiction_party_identity |
| Staff Classification | `insurance_core.pc.Staff_Classification` | party | staff_classification |
| Staff Position | `insurance_core.pc.Staff_Position` | party | staff_position |
| Staff Position Assignment | `insurance_core.pc.Staff_Position_Assignment` | party | staff_position_assignment |
| Claim | `insurance_core.pc.Claim` | claims | claim |
| Claim Amount | `insurance_core.pc.Claim_Amount` | claims | claim_amount |
| Claim Reserve | `insurance_core.pc.Claim_Reserve` | claims | claim_reserve |
| Loss Reserve | `insurance_core.pc.Loss_Reserve` | claims | loss_reserve |
| Expense Reserve | `insurance_core.pc.Expense_Reserve` | claims | expense_reserve |
| Claim Payment | `insurance_core.pc.Claim_Payment` | claims | claim_payment |
| Loss Payment | `insurance_core.pc.Loss_Payment` | claims | loss_payment |
| Expense Payment | `insurance_core.pc.Expense_Payment` | claims | expense_payment |
| Recovery | `insurance_core.pc.Recovery` | claims | recovery |
| Subrogation | `insurance_core.pc.Subrogation` | claims | subrogation |
| Salvage | `insurance_core.pc.Salvage` | claims | salvage |
| Deductible Recovery | `insurance_core.pc.Deductible_Recovery` | claims | deductible_recovery |
| Expense Recovery | `insurance_core.pc.Expense_Recovery` | claims | expense_recovery |
| Loss Recovery | `insurance_core.pc.Loss_Recovery` | claims | loss_recovery |
| Reinsurance Recovery | `insurance_core.pc.Reinsurance_Recovery` | claims | reinsurance_recovery |
| Ceded Claim Amount | `insurance_core.pc.Ceded_Claim_Amount` | claims | ceded_claim_amount |
| Assumed Claim Amount | `insurance_core.pc.Assumed_Claim_Amount` | claims | assumed_claim_amount |
| Direct Claim Amount | `insurance_core.pc.Direct_Claim_Amount` | claims | direct_claim_amount |
| Debit Claim Amount | `insurance_core.pc.Debit_Claim_Amount` | claims | debit_claim_amount |
| Credit Claim Amount | `insurance_core.pc.Credit_Claim_Amount` | claims | credit_claim_amount |
| Claim Party Role | `insurance_core.pc.Claim_Party_Role` | claims | claim_party_role |
| Claim Coverage | `insurance_core.pc.Claim_Coverage` | claims | claim_coverage |
| Claim Folder | `insurance_core.pc.Claim_Folder` | claims | claim_folder |
| Claim Folder Document | `insurance_core.pc.Claim_Folder_Document` | claims | claim_folder_document |
| Claim Offer | `insurance_core.pc.Claim_Offer` | claims | claim_offer |
| Claim Assessment | `insurance_core.pc.Claim_Assessment` | claims | claim_assessment |
| Occurrence | `insurance_core.pc.Occurrence` | claims | occurrence |
| Catastrophe | `insurance_core.pc.Catastrophe` | claims | catastrophe |
| Fraud Assessment | `insurance_core.pc.Fraud_Assessment` | claims | fraud_assessment |
| Medical Condition | `insurance_core.pc.Medical_Condition` | claims | medical_condition |
| Litigation | `insurance_core.pc.Litigation` | claims | litigation |
| Claim Litigation | `insurance_core.pc.Claim_Litigation` | claims | claim_litigation |
| Litigation Party Role | `insurance_core.pc.Litigation_Party_Role` | claims | litigation_party_role |
| Arbitration | `insurance_core.pc.Arbitration` | claims | arbitration |
| Claim Arbitration | `insurance_core.pc.Claim_Arbitration` | claims | claim_arbitration |
| Arbitration Party Role | `insurance_core.pc.Arbitration_Party_Role` | claims | arbitration_party_role |
| Court Jurisdiction | `insurance_core.pc.Court_Jurisdiction` | claims | court_jurisdiction |
| Agency Contract | `insurance_core.pc.Agency_Contract` | distribution | agency_contract |
| Brokerage Contract | `insurance_core.pc.Brokerage_Contract` | distribution | brokerage_contract |
| Organization Unit | `insurance_core.pc.Organization_Unit` | distribution | organization_unit |
| Field Organization Unit | `insurance_core.pc.Field_Organization_Unit` | distribution | field_organization_unit |
| Administrative Organization Unit | `insurance_core.pc.Administrative_Organization_Unit` | distribution | administrative_organization_unit |
| Department | `insurance_core.pc.Department` | distribution | department |
| Territory | `insurance_core.pc.Territory` | distribution | territory |
| Regional Office | `insurance_core.pc.Regional_Office` | distribution | regional_office |
| Branch Office | `insurance_core.pc.Branch_Office` | distribution | branch_office |
| Account | `insurance_core.pc.Account` | distribution | account |
| Account Agreement | `insurance_core.pc.Account_Agreement` | distribution | account_agreement |
| Insured Account | `insurance_core.pc.Insured_Account` | distribution | insured_account |
| Company | `insurance_core.pc.Company` | distribution | company |
| Company Jurisdiction | `insurance_core.pc.Company_Jurisdiction` | distribution | company_jurisdiction |
| Product License | `insurance_core.pc.Product_License` | distribution | product_license |
| Structure | `insurance_core.pc.Structure` | homeowners | structure |
| Residential Structure | `insurance_core.pc.Residential_Structure` | homeowners | residential_structure |
| Dwelling | `insurance_core.pc.Dwelling` | homeowners | dwelling |
| Mobile Home | `insurance_core.pc.Mobile_Home` | homeowners | mobile_home |
| Combination Structure | `insurance_core.pc.Combination_Structure` | homeowners | combination_structure |
| Commercial Structure | `insurance_core.pc.Commercial_Structure` | commercial_lines | commercial_structure |
| Workers Comp Class | `insurance_core.pc.Workers_Comp_Class` | commercial_lines | workers_comp_class |
| Household Content | `insurance_core.pc.Household_Content` | homeowners | household_content |
| Body Object | `insurance_core.pc.Body_Object` | commercial_lines | body_object |
| Animal | `insurance_core.pc.Animal` | commercial_lines | animal |
| Farm Equipment | `insurance_core.pc.Farm_Equipment` | commercial_lines | farm_equipment |
| Tractor | `insurance_core.pc.Tractor` | commercial_lines | tractor |
| Combine | `insurance_core.pc.Combine` | commercial_lines | combine |
| Milking Machine | `insurance_core.pc.Milking_Machine` | commercial_lines | milking_machine |
| Transportation Class | `insurance_core.pc.Transportation_Class` | commercial_lines | transportation_class |
| Freight Group | `insurance_core.pc.Freight_Group` | commercial_lines | freight_group |
| Manufactured Object | `insurance_core.pc.Manufactured_Object` | commercial_lines | manufactured_object |
| Scheduled Item | `insurance_core.pc.Scheduled_Item` | commercial_lines | scheduled_item |
| Property In Transit | `insurance_core.pc.Property_In_Transit` | commercial_lines | property_in_transit |
| Event | `insurance_core.pc.Event` | policy | event |
| Business Event | `insurance_core.pc.Business_Event` | policy | business_event |
| Life Event | `insurance_core.pc.Life_Event` | policy | life_event |
| Claim Event | `insurance_core.pc.Claim_Event` | claims | claim_event |
| Auto Repair Shop Contract | `insurance_core.pc.Auto_Repair_Shop_Contract` | personal_auto | auto_repair_shop_contract |
| Financial Account Agreement | `insurance_core.pc.Financial_Account_Agreement` | distribution | financial_account_agreement |
| Group Agreement | `insurance_core.pc.Group_Agreement` | policy | group_agreement |
| Individual Agreement | `insurance_core.pc.Individual_Agreement` | policy | individual_agreement |
| Intermediary Agreement | `insurance_core.pc.Intermediary_Agreement` | distribution | intermediary_agreement |
| Commercial Agreement | `insurance_core.pc.Commercial_Agreement` | commercial_lines | commercial_agreement |
| Derivative Contract | `insurance_core.pc.Derivative_Contract` | underwriting | derivative_contract |
| Provider Agreement | `insurance_core.pc.Provider_Agreement` | distribution | provider_agreement |
| Commutation Agreement | `insurance_core.pc.Commutation_Agreement` | underwriting | commutation_agreement |
| Staffing Agreement | `insurance_core.pc.Staffing_Agreement` | distribution | staffing_agreement |
| Employment Agreement | `insurance_core.pc.Employment_Agreement` | distribution | employment_agreement |
| Consultant Contract | `insurance_core.pc.Consultant_Contract` | distribution | consultant_contract |
| Third Party Staffing Agreement | `insurance_core.pc.Third_Party_Staffing_Agreement` | distribution | third_party_staffing_agreement |
| Loss Triangles | `insurance_lake.pc.loss_triangles` | analytics | loss_triangles |
| Premium History | `insurance_lake.pc.premium_history` | analytics | premium_history |
| Claims Snapshots | `insurance_lake.pc.claims_snapshots` | analytics | claims_snapshots |
| Reserve Development | `insurance_lake.pc.reserve_development` | analytics | reserve_development |
| Experience Rating | `insurance_lake.pc.experience_rating` | analytics | experience_rating |

---

## 4. IRO Alignment

The IRO (Insurance Regulation Ontology) extends FIBO with insurance-specific concepts. The platform maps IRO classes to physical entities as follows:

### Policy & Contract Classes

| IRO Class | Platform Entity | Physical Table(s) |
|-----------|----------------|-------------------|
| `IRO/InsuranceContract/PropertyCasualtyPolicy` | Policy, Agreement | `Policy`, `Agreement` |
| `IRO/InsuranceContract/AutomobilePolicy` | Personal Auto Policy | `Policy` (filtered LOB=PA) |
| `IRO/InsuranceContract/PropertyPolicy` | Homeowners Policy | `Policy` (filtered LOB=HO) |
| `IRO/InsuranceContract/CommercialPolicy` | Commercial Lines Policy | `Policy` (filtered LOB IN CA, GL, WC, CP) |
| `IRO/InsuranceContract/PolicyCoverage` | Policy Coverage Detail | `Policy_Coverage_Detail`, `Coverage` |
| `IRO/InsuranceContract/PolicyEndorsement` | Endorsement | `Endorsement`, `Mid_Term`, `Full_Term` |

### Claim Classes

| IRO Class | Platform Entity | Physical Table(s) |
|-----------|----------------|-------------------|
| `IRO/Claim/PropertyCasualtyClaim` | Claim | `Claim` |
| `IRO/Claim/ClaimReserve` | Claim Reserve | `Claim_Reserve`, `Loss_Reserve`, `Expense_Reserve` |
| `IRO/Claim/ClaimPayment` | Claim Payment | `Claim_Payment`, `Loss_Payment`, `Expense_Payment` |
| `IRO/Claim/ClaimRecovery` | Recovery | `Recovery`, `Subrogation`, `Salvage` |
| `IRO/Claim/CatastropheEvent` | Catastrophe | `Catastrophe`, `Occurrence` |
| `IRO/Claim/FraudIndicator` | Fraud Assessment | `Fraud_Assessment` |

### Party Classes

| IRO Class | Platform Entity | Physical Table(s) |
|-----------|----------------|-------------------|
| `IRO/Party/InsuredParty` | Party (Insured) | `Party`, `Person`, `Organization` |
| `IRO/Party/InsuranceAgent` | Agent/Producer | `Agreement_Party_Role` (role=Agent) |
| `IRO/Party/Claimant` | Claim Party | `Claim_Party_Role` |
| `IRO/Party/Household` | Household | `Household`, `Household_Person` |
| `IRO/Party/CustomerSegment` | Customer Score | `Customer_Score`, `Demographic_Score`, `Channel_Score` |

### Underwriting & Financial Classes

| IRO Class | Platform Entity | Physical Table(s) |
|-----------|----------------|-------------------|
| `IRO/Underwriting/RiskAssessment` | Underwriting Assessment | `Underwriting_Assessment`, `Assessment`, `Assessment_Result` |
| `IRO/Underwriting/RatingTerritory` | Rating Territory | `Rating_Territory`, `Rating_Territory_Geographic_Location` |
| `IRO/Underwriting/RiskScore` | Risk Factor Score | `Risk_Factor_Score` |
| `IRO/Financial/PremiumTransaction` | Policy Amount / Premium | `Policy_Amount`, `Premium` |
| `IRO/Financial/InsuranceReserve` | Claim Reserve | `Claim_Reserve`, `Loss_Reserve`, `Expense_Reserve` |
| `IRO/Financial/Reinsurance` | Ceded/Assumed Amounts | `Ceded_Policy_Amount`, `Assumed_Policy_Amount`, `Ceded_Claim_Amount`, `Assumed_Claim_Amount` |
| `IRO/Financial/InsuranceAnalytics` | Insurance Lake | `loss_triangles`, `premium_history`, `claims_snapshots`, `reserve_development`, `experience_rating` |

### Insurable Object Classes

| IRO Class | Platform Entity | Physical Table(s) |
|-----------|----------------|-------------------|
| `IRO/InsurableObject/Vehicle` | Vehicle | `Vehicle`, `Automobile`, `Truck`, `Bus` |
| `IRO/InsurableObject/Structure` | Structure | `Structure`, `Residential_Structure`, `Commercial_Structure` |
| `IRO/InsurableObject/Dwelling` | Dwelling | `Dwelling`, `Mobile_Home` |
| `IRO/InsurableObject/WorkersCompClass` | Workers Comp Class | `Workers_Comp_Class` |
| `IRO/InsurableObject/PersonalProperty` | Household Content | `Household_Content`, `Scheduled_Item` |

### Distribution Classes

| IRO Class | Platform Entity | Physical Table(s) |
|-----------|----------------|-------------------|
| `IRO/Distribution/AgencyContract` | Agency Contract | `Agency_Contract` |
| `IRO/Distribution/BrokerageContract` | Brokerage Contract | `Brokerage_Contract` |
| `IRO/Distribution/Territory` | Territory | `Territory`, `Field_Organization_Unit` |
| `IRO/Distribution/InsuredAccount` | Account | `Account`, `Account_Agreement`, `Insured_Account` |

---

## 5. Notes

1. **Hybrid trunk + LOB branch architecture** — The P&C domain structure follows the 2025–2026 industry best practice of separating core functional domains (policy, claims, party, underwriting, distribution, analytics) from LOB-specific views (personal_auto, homeowners, commercial_lines). Core domains own the physical tables and provide cross-LOB analytics. LOB branches apply `Line_Of_Business_Code` filters to the same underlying tables and add line-specific KPIs and insurable object specializations.

2. **ACORD P&C standard version alignment** — The physical data model aligns with the ACORD P&C Data Model standard. Table names, column names, and inheritance hierarchies (via shared primary keys) follow ACORD naming conventions. Subtype relationships are implemented via FK-to-PK patterns (e.g., `Vehicle.Insurable_Object_Identifier` FK → `Insurable_Object.Insurable_Object_Identifier`). The ACORD P&C model uses a generalization/specialization pattern for Policy Amounts (Premium, Fee, Tax, Surcharge), Claim Amounts (Reserve, Payment, Recovery), and Insurable Objects (Vehicle, Structure, etc.).

3. **Cross-catalog analytics via insurance_lake** — The analytics domain bridges operational data (`insurance_core.pc.*`) with time-series analytics (`insurance_lake.pc.*`) via Trino's federated query engine. Cross-catalog joins use `lob_code` and `state_code` as common join keys, enabling queries that combine current policy/claim state with historical loss development, premium trends, and experience rating data without ETL duplication.

4. **LOB code mapping** — Lines of business are identified via `Line_Of_Business.Line_Of_Business_Code`:
   - `PA` — Personal Auto
   - `HO` — Homeowners
   - `CA` — Commercial Auto
   - `GL` — General Liability
   - `WC` — Workers Compensation
   - `CP` — Commercial Property

5. **IRO extends FIBO** — The Insurance Regulation Ontology builds on FIBO's financial concepts and adds insurance-specific classes. IRO references are used in `custom_extensions` sections of semantic model YAML files to provide ontological alignment for AI context retrieval and cross-platform semantic interoperability.

6. **P&C vs Life domain organization** — Unlike Life & Health where claims are embedded within product domains, P&C treats claims as a standalone cross-LOB functional domain. This reflects P&C operational reality where claims adjusters handle claims across multiple lines and catastrophe events affect multiple LOBs simultaneously. Similarly, underwriting in P&C is an ongoing process (renewal underwriting, rate changes) rather than a point-in-time event at policy issue.

7. **Fully-qualified source references** — All semantic model datasets reference physical tables using the Trino fully-qualified format: `insurance_core.pc.<table_name>` for operational tables and `insurance_lake.pc.<table_name>` for analytics tables. This enables the SchemaContext and AI agent to generate correct SQL without catalog/schema ambiguity.
