# ACORD Life & Annuity Data Model Mapping

## Guardian Life Insurance Intelligence Platform — Semantic Model Alignment

This document maps the platform's semantic domains to ACORD Life & Annuity Data Model standards and IRO (Insurance Regulation Ontology) references.

---

## Domain-to-ACORD Mapping

| Platform Domain | ACORD L&A Standard | IRO Reference | Description |
|----------------|-------------------|---------------|-------------|
| `individual_life` | Policy Administration | IRO/InsuranceContract/LifeInsurancePolicy | Whole Life, Term, Universal Life policies with riders, loans, dividends |
| `annuities` | Annuity Administration | IRO/InsuranceContract/AnnuityContract | Income, Fixed, RILA annuity contracts |
| `group_dental` | Group Benefits - Dental | IRO/InsuranceContract/GroupBenefitPlan | Group dental plans, CDT-coded claims |
| `group_disability` | Group Benefits - Disability | IRO/InsuranceContract/GroupBenefitPlan | STD/LTD plans, ICD-10 coded claims |
| `group_vision` | Group Benefits - Vision | IRO/InsuranceContract/GroupBenefitPlan | Group vision plans and claims |
| `group_life` | Group Benefits - Life & AD&D | IRO/InsuranceContract/GroupBenefitPlan | Group term life, voluntary, AD&D |
| `financial` | Financial Reporting | IRO/Financial/PremiumTransaction | Premium revenue, investment income, reserves |
| `party` | Party/Producer | IRO/Party/InsuredParty | Individuals, organizations, agents, employers |
| `regulatory` | Regulatory/Valuation | IRO/Financial/InsuranceReserve | LDTI, VM-22, IFRS 17, RBC, experience studies |

---

## Cross-Cutting ACORD Concepts Coverage

### Claims (ACORD L&A - Claims)

Claims are distributed across product domains (per Guardian's operational structure):

| Claim Type | Domain | Table | Key Fields |
|-----------|--------|-------|------------|
| Death Benefit (Individual) | `individual_life` | `benefit_payment` | payment_type='DEATH_BENEFIT' |
| Dental Claims | `group_dental` | `group_claim` | claim_type='DENTAL' |
| Vision Claims | `group_vision` | `group_claim` | claim_type='VISION' |
| STD Claims | `group_disability` | `group_claim` + `disability_claim_detail` | claim_type='STD' |
| LTD Claims | `group_disability` | `group_claim` + `disability_claim_detail` | claim_type='LTD' |
| Group Life Death | `group_life` | `group_claim` | claim_type='DEATH' |
| AD&D Claims | `group_life` | `group_claim` | claim_type='AD_D' |

### Underwriting (ACORD L&A - Underwriting)

Underwriting is captured at policy issue within `individual_life`:

| Concept | Table | Field | Values |
|---------|-------|-------|--------|
| Risk Classification | `individual_policy` | `risk_class` | PREFERRED_PLUS, PREFERRED, STANDARD, SUBSTANDARD |
| Tobacco Status | `individual_policy` | `smoker_status` | true/false |
| Issue Age | `individual_policy` | `issue_age` | 25-80 |
| Face Amount Limits | Knowledge Base | Rule UW-002 | Max $10M for Term |
| Age Limits | Knowledge Base | Rule UW-001 | Max age 80 for Whole Life |
| Preferred Criteria | Knowledge Base | Rule UW-003 | No tobacco 5 years |

### Reinsurance (ACORD L&A - Reinsurance)

Reinsurance is captured in the financial domain:

| Concept | Table | Field | Description |
|---------|-------|-------|-------------|
| Ceded Premium | `premium_revenue` | `ceded_premium` | Premium ceded to reinsurers |
| Net Premium | `premium_revenue` | `net_premium` | Gross minus ceded |
| Retention | Derived | `gross - ceded` | Amount retained by Guardian |

### Coverage (ACORD L&A - Coverage)

Coverage is embedded within product domains:

| Coverage Type | Domain | How Represented |
|--------------|--------|-----------------|
| Individual Life Coverage | `individual_life` | `face_amount`, `death_benefit` on `individual_policy` |
| Policy Riders | `individual_life` | `policy_rider` table (WP, ADB, Child Term, GI, LTC) |
| Annuity Guarantees | `annuities` | `guaranteed_rate`, `payout_amount` on `annuity_contract` |
| Group Dental Coverage | `group_dental` | `group_plan` with product_type='DENTAL' |
| Group Disability Coverage | `group_disability` | `group_plan` with product_type='STD'/'LTD' |
| Group Vision Coverage | `group_vision` | `group_plan` with product_type='VISION' |
| Group Life Coverage | `group_life` | `group_plan` with product_type='GROUP_LIFE' |

---

## ACORD Entity Mapping to Physical Tables

| ACORD L&A Entity | Physical Table | Schema |
|-----------------|---------------|--------|
| Party | `guardian.party` | postgres |
| Producer/Agent | `guardian.agent` | postgres |
| Employer/Group | `guardian.employer` | postgres |
| Life Policy/Holding | `guardian.individual_policy` | postgres |
| Annuity Contract | `guardian.annuity_contract` | postgres |
| Premium Transaction | `guardian.individual_premium` | postgres |
| Policy Dividend | `guardian.policy_dividend` | postgres |
| Rider/Benefit | `guardian.policy_rider` | postgres |
| Policy Loan | `guardian.policy_loan` | postgres |
| Group Plan | `guardian.group_plan` | postgres |
| Group Member/Certificate | `guardian.group_member` | postgres |
| Group Claim | `guardian.group_claim` | postgres |
| Dental Claim Detail | `guardian.dental_claim_detail` | postgres |
| Disability Claim Detail | `guardian.disability_claim_detail` | postgres |
| Premium Revenue | `guardian.premium_revenue` | postgres |
| Benefit Payment | `guardian.benefit_payment` | postgres |
| Investment Income | `guardian.investment_income` | postgres |
| Reserve | `guardian.reserve` | postgres |
| LDTI Liability | `guardian.ldti_liability` | postgres |
| VM-22 Reserve | `guardian.vm22_reserve` | postgres |
| IFRS 17 CSM | `guardian.ifrs17_csm` | postgres |
| RBC Capital | `guardian.rbc_capital` | postgres |
| Experience Study | `guardian.experience_study` | postgres |

---

## Insurance Lake Analytics Tables

| Table | ACORD Alignment | Purpose |
|-------|----------------|---------|
| `persistency_snapshots` | Policy Administration - Retention | Monthly persistency by product/vintage |
| `mortality_experience` | Underwriting - Mortality | A/E mortality by age/risk class |
| `dividend_history` | Policy Administration - Dividends | Annual dividend rates by vintage |
| `group_utilization` | Group Benefits - Utilization | Monthly dental/vision utilization |
| `premium_trends` | Financial Reporting - Premium | Quarterly premium by segment |

---

## IRO (Insurance Regulation Ontology) Alignment

The IRO extends FIBO with insurance-specific concepts. Our mapping:

| IRO Class | Platform Representation |
|-----------|----------------------|
| `IRO/InsuranceContract/LifeInsurancePolicy` | `individual_policy` table |
| `IRO/InsuranceContract/AnnuityContract` | `annuity_contract` table |
| `IRO/InsuranceContract/GroupBenefitPlan` | `group_plan` table |
| `IRO/InsuranceContract/PolicyRider` | `policy_rider` table |
| `IRO/Party/InsuredParty` | `party` table (type=INDIVIDUAL) |
| `IRO/Party/InsuranceAgent` | `agent` table |
| `IRO/Party/EmployerGroup` | `employer` table |
| `IRO/Claim/InsuranceClaim` | `group_claim` table |
| `IRO/Claim/BenefitPayment` | `benefit_payment` table |
| `IRO/Financial/PremiumTransaction` | `premium_revenue`, `individual_premium` |
| `IRO/Financial/PolicyholderDividend` | `policy_dividend` table |
| `IRO/Financial/PolicyLoan` | `policy_loan` table |
| `IRO/Financial/InsuranceReserve` | `reserve`, `ldti_liability`, `vm22_reserve` |
| `IRO/Financial/InvestmentPortfolio` | `investment_income` table |
| `IRO/Financial/InsuranceAnalytics` | Insurance Lake tables |

---

## Knowledge Base Alignment

### Business Rules by ACORD Domain

| ACORD Domain | Rules | Examples |
|-------------|-------|---------|
| Underwriting | UW-001 to UW-005 | Max issue age, face limits, risk class criteria |
| Policy Administration | DIV-001 to DIV-004 | Dividend eligibility, DIR, options |
| Claims | CLM-001 to CLM-004 | Payment timeline, contestability, exclusions |
| Group Benefits | GRP-001 to GRP-007 | Enrollment minimums, elimination periods, COBRA |
| Regulatory (LDTI) | LDTI-001 to LDTI-005 | Assumption updates, DAC, MRB, discount rates |
| Regulatory (VM-22) | VM22-001 to VM22-004 | PBR effective date, CTE 70, reserve floor |
| Regulatory (IFRS 17) | IFRS17-001 to IFRS17-004 | CSM, BBA, risk adjustment, IFIE |
| Regulatory (RBC) | RBC-001 to RBC-003 | Action levels, covariance formula, C-1 factors |
| Actuarial | EXP-001 to EXP-002 | Observation periods, credibility standards |

### Regulations by Jurisdiction

| Regulation | Jurisdiction | ACORD Domain |
|-----------|-------------|-------------|
| NAIC Model Regulation | Federal/NAIC | Policy Administration |
| NY Regulation 187 | NY | Suitability/Sales |
| California Insurance Code | CA | Policy Forms |
| HIPAA | Federal | Group Health |
| ERISA | Federal | Group Benefits |
| DOL Fiduciary Rule | Federal | Annuities |
| NAIC Annuity Suitability | Federal/NAIC | Annuities |
| ADA | Federal | Disability |
| ASU 2018-12 (LDTI) | Federal/FASB | Financial Reporting |
| VM-22 PBR | Federal/NAIC | Valuation |
| IFRS 17 | International/IASB | Financial Reporting |
| NAIC RBC | Federal/NAIC | Capital |
| VM-20 PBR | Federal/NAIC | Valuation |

---

## Notes

1. **Guardian is a Life & Health insurer** — the domain structure follows product lines (how Guardian operates) rather than functional areas (how P&C insurers organize). This is correct per ACORD Life & Annuity standards.

2. **Claims are product-embedded** — Unlike P&C where claims is a standalone domain, Life & Health claims are processed within each product line (dental claims by dental ops, disability claims by disability ops, death claims by life claims).

3. **Underwriting is point-in-time** — Life underwriting happens at policy issue and is captured as policy attributes (risk_class, smoker_status, issue_age). There's no ongoing underwriting process like P&C renewal underwriting.

4. **IRO extends FIBO** — The Insurance Regulation Ontology builds on FIBO's financial concepts and adds insurance-specific classes. We use IRO references for insurance entities and ACORD for data model alignment.
